# Inventario de c:\Users\lenovo\Documents\GACAC\procoop-relevamiento\binarios\SISTEMA_PRD\ProMod_GestionMora.dll

Tipos: 41 | Métodos: 474 | Campos: 620

## Referencias a ensamblados

- CapaDatos
- Configuracion
- DevExpress.Data.v14.1
- DevExpress.Images.v14.1
- DevExpress.Utils.v14.1
- DevExpress.XtraBars.v14.1
- DevExpress.XtraEditors.v14.1
- DevExpress.XtraGrid.v14.1
- ProMod_Cobranzas
- ReglasNegocio
- System
- System.Core
- System.Data
- System.Data.Linq
- System.Drawing
- System.Windows.Forms
- mscorlib

## Tipos por namespace

### (global) (24)

- **<>c**: <Buscar>b__46_0, <ExportarCirculares>b__62_0, <GenerarAvisoTelefonico>b__68_0, <Get_Filtro>b__45_0, <Get_Grupo>b__67_0, <MarcarEntraga>b__59_0, <NotificarTitulares>b__63_0, <Ordenar_Notificaciones>b__52_0, <Ordenar_Notificaciones>b__52_1, <Ordenar_Notificaciones>b__52_10, <Ordenar_Notificaciones>b__52_11, <Ordenar_Notificaciones>b__52_12, <Ordenar_Notificaciones>b__52_13, <Ordenar_Notificaciones>b__52_14, <Ordenar_Notificaciones>b__52_15, <Ordenar_Notificaciones>b__52_16, <Ordenar_Notificaciones>b__52_17, <Ordenar_Notificaciones>b__52_18, <Ordenar_Notificaciones>b__52_19, <Ordenar_Notificaciones>b__52_2, <Ordenar_Notificaciones>b__52_20, <Ordenar_Notificaciones>b__52_21, <Ordenar_Notificaciones>b__52_22, <Ordenar_Notificaciones>b__52_23, <Ordenar_Notificaciones>b__52_24, <Ordenar_Notificaciones>b__52_25, <Ordenar_Notificaciones>b__52_26, <Ordenar_Notificaciones>b__52_27, <Ordenar_Notificaciones>b__52_28, <Ordenar_Notificaciones>b__52_29, <Ordenar_Notificaciones>b__52_3, <Ordenar_Notificaciones>b__52_30, <Ordenar_Notificaciones>b__52_31, <Ordenar_Notificaciones>b__52_32, <Ordenar_Notificaciones>b__52_33, <Ordenar_Notificaciones>b__52_34, <Ordenar_Notificaciones>b__52_35, <Ordenar_Notificaciones>b__52_4, <Ordenar_Notificaciones>b__52_5, <Ordenar_Notificaciones>b__52_6, <Ordenar_Notificaciones>b__52_7, <Ordenar_Notificaciones>b__52_8, <Ordenar_Notificaciones>b__52_9
- **<>c**: <InicializarForm>b__25_0, <InicializarForm>b__25_2
- **<>c**: <.ctor>b__8_0, <.ctor>b__8_1, <.ctor>b__9_0, <GenerarNotificacion>b__26_0, <GenerarNotificacion_Documento>b__27_0, <GenerarNotificacion_Documento>b__27_1, <GenerarNotificacion_Documento>b__27_2, <GenerarNotificacion_Documento>b__27_3, <GenerarNotificacion_Documento>b__27_4, <GenerarNotificacion_Documento>b__27_5, <GenerarNotificacion_Documento>b__27_6, <GenerarNotificacion_MailSMS>b__28_0, <GenerarNotificacion_MailSMS>b__28_1, <GenerarNotificacion_MailSMS>b__28_2, <GenerarNotificacion_MailSMS>b__28_5, <Get_DatosForm>b__30_0
- **<>c**: <InicializarForm>b__13_0
- **<>c**: <Get_DatosForm>b__21_0, <Imprimir_Titular>b__19_0
- **<>c**: <Buscar>b__32_0, <Buscar>b__32_1, <Buscar>b__32_2, <Buscar>b__32_3, <GenerarComprobantes>b__50_0, <Get_NotificacionMarcadas>b__34_0, <NotificarTitulares>b__46_0, <Seleccionar_Operacion>b__43_0, <grdvNotificaciones_CustomSummaryCalculate>b__14_0
- **<>c**: <.ctor>b__0_0, <.ctor>b__0_1, <.ctor>b__0_2, <.ctor>b__0_3, <.ctor>b__0_4, <.ctor>b__0_5, <Guadar>b__22_0, <Guadar>b__22_1, <Guadar>b__22_2, <Validar>b__21_0
- **<>c__DisplayClass25_0**: <Confirmar>b__2
- **<>c__DisplayClass25_1**: <Confirmar>b__3, <Confirmar>b__4, <Confirmar>b__5
- **<>c__DisplayClass27_0**: <GenerarNotificacion_Documento>b__7
- **<>c__DisplayClass27_1**: <GenerarNotificacion_Documento>b__8
- **<>c__DisplayClass28_0**: <GenerarNotificacion_MailSMS>b__3
- **<>c__DisplayClass28_1**
- **<>c__DisplayClass28_2**: <GenerarNotificacion_MailSMS>b__4
- **<>c__DisplayClass28_3**: <GenerarNotificacion_MailSMS>b__6
- **<>c__DisplayClass28_4**: <GenerarNotificacion_MailSMS>b__7
- **<>c__DisplayClass46_0**: <Buscar>b__1
- **<>c__DisplayClass50_0**: <GenerarComprobantes>b__1
- **<>c__DisplayClass52_0**: <Marcar>b__0
- **<>c__DisplayClass59_0**: <MarcarEntraga>b__1
- **<>c__DisplayClass8_0**: <.ctor>b__3
- **<>f__AnonymousType0`4**: Equals, GetHashCode, ToString
- **<Module>**
- **ModoImpresion**

### ProMod_GestionMora.Forms (16)

- **abm_Exc_Mora**: Autorizar_Excepcion, Cargar, Desautorizar_Excepcion, Dispose, Guardar_Nota, Imprimir, Imprimir_Aceptar, InitializeComponent, LimpiarControles, PreSave, abm_ExcMora__GetGridViewSource, abm_ExcMora__ModificoRegistro_CargarControles, abm_ExcMora__ModificoRegistro_PreSave, abm_ExcMora__ModoForm_Change, abm_ExcMora__NuevoRegistro_PreSave, abm_ExcMora__ValidFields, abm_Exc_Mora__NuevoRegistro_CargarControles, btnAutorizar_Click, btnImprimir_Click, oCuenta_Change_IdSeleccionado
- **abm_Instanci**: Dispose, InitializeComponent, abmInstanci__ValidFields
- **frmConsultaNotificaciones**: Buscar, Dispose, Imprimir, InitializeComponent, VisualizarDeudaNotificada, btnDeudaNotificada_ItemClick, btnReimprimir_ItemClick, frmConsultaNotificaciones_Load, grdvNotificaciones_FocusedRowChanged
- **frmGestionMora**: <Cerrar_Notificacion>b__75_0, Actualizar_Notificaciones, AddAll_Notificacion, Add_Notificacion, AnularGrupo, Buscar, CambiarEstado, Cerrar_Notificacion, Dispose, ExportarCirculares, GenerarAvisoTelefonico, Get_EstadoResolucionTecnica, Get_Filtro, Get_Grupo, Get_NotificacionMarcadas, Get_Seleccionada, Imprimir_CortarServicio, Imprimir_TotalesServicio, InicializarForm, InitializeComponent, LimpiarNotificaciones, MarcarEntraga, NotificarTitulares, Ordenar_Notificaciones, QuitarNotificacion, RegistrarPromesa, RemoveAll_Notificacion, Remove_Notificacion, ReprocesarGrupo, Seleccionar_EstaSer, Seleccionar_Servicio, ValidarBuscar, VerAntecedentes, VisualizarDeudaActualizada, VisualizarDeudaNotificada, btnAddAll_ItemClick, btnAdd_ItemClick, btnAnularGrupo_ItemClick, btnAvisoTelefonico_ItemClick, btnCambiarEstado_ItemClick, btnConsultaAntecedentes_ItemClick, btnConsultaDeudaNotificada_ItemClick, btnConsultaDeudaTotal_ItemClick, btnConsultar_Click, btnExportarCirculares_ItemClick, btnImprimir_NotificacionTitular_ItemClick, btnImprimir_Notificacion_ItemClick, btnInformeCortarServicio_ItemClick, btnInformeTotalesServicio_ItemClick, btnLimpiarNotificaciones_ItemClick, btnMarcarEntrega_ItemClick, btnNotificar_ItemClick, btnPromesaPago_ItemClick, btnQuitarNotificacion_ItemClick, btnRemoveAll_ItemClick, btnRemove_ItemClick, btnReprocesarGrupo_ItemClick, chDeudaActualizada_CheckedChanged, grdvNotificaDestino_DoubleClick, grdvNotificaOrigen_DoubleClick
- **frmGestionMora_Antecedentes**: <InicializarForm>b__25_1, Calificar, CambioCalificacion, Dispose, InicializarForm, InitializeComponent, btnCuentaCorriente_Click, btnDeuda_Click, btnResumenPago_Click, cbCalificacion_SelectedIndexChanged, grdvServicios_FocusedRowChanged, ok_Cancel1_ClickAceptar
- **frmGestionMora_BajaNotificacion**: Dispose, InitializeComponent, ok_Cancel1_ClickAceptar
- **frmGestionMora_Grupo**: <.ctor>b__1_0, Dispose, InitializeComponent, cbGrupo_SelectedIndexChanged, ok_Cancel1_ClickAceptar
- **frmGestionMora_MarcarEntrega**: Dispose, InitializeComponent, cbOperacion_SelectedIndexChanged, ok_Cancel1_ClickAceptar
- **frmGestionMora_Notificar**: <.ctor>b__8_2, <Confirmar>b__25_0, <Confirmar>b__25_1, Confirmar, Dispose, GenerarNotificacion, GenerarNotificacion_Documento, GenerarNotificacion_MailSMS, Get_DatosForm, Get_PdfPath, InicializarForm, InitializeComponent, SelecionarNotificacion, Validar, ValidarTelefonos, cbNotificacion_SelectedIndexChanged, chGenerarCompVen_CheckedChanged, oInstancia_SeleccionarId, ok_Cancel1_ClickAceptar
- **frmGestionMora_OperEspeciales**: Buscar, Dispose, Eliminar_Notificacion, Eliminar_Notificaciones, InitializeComponent, LimpiarGrilla, Resolver_Notificaciones, Restablecer_Notificaciones, ValidarConsulta, barButtonItem1_ItemClick, btnConsultar_ItemClick, btnEliminar_ItemClick, btnResolver_ItemClick, btnRestablecer_ItemClick
- **frmGestionMora_PromesaPago**: Dispose, InitializeComponent, ok_Cancel1_ClickAceptar
- **frmGestionMora_VisualizarDeuda**: Dispose, Imprimir, InicializarForm, InitializeComponent, ok_Cancel1_ClickAceptar, repositoryItemButtonEdit1_ButtonClick, toolTipController1_GetActiveObjectInfo
- **frmImprimirNotificacion**: Dispose, GenerarComprobante, Get_DatosForm, Imprimir, Imprimir_Normal, Imprimir_Titular, InitializeComponent, Validar, chGenerarCompVen_CheckedChanged, ok_Cancel1_ClickAceptar
- **frmTratamientoMorosos**: <Cerrar_Notificacion>b__36_0, Buscar, CambiarCategoria, CambiarEstado, CambiarEstadoMultServicios, Carga_Servicios, Cerrar_Notificacion, Dispose, GenerarComprobantes, Generar_IncidenteTecnico, Get_EstadoResolucionTecnica, Get_NotificacionMarcadas, Get_NotificacionSeleccionada, InicializarForm, InitializeComponent, Marcar, NotificarTitulares, RealizarBajaServicio, Seleccionar_EstaSer, Seleccionar_Operacion, Seleccionar_Servicio, Seleccionar_VariosServicio, Seleccionar_VariosServicios, VisualizarDeudaActualizada, VisualizarDeudaNotificada, btnBajaServicios_ItemClick, btnCambiarCategoria_ItemClick, btnCambiarEstadoMultServicios_ItemClick, btnCambiarEstado_ItemClick, btnCerrarNotificaciones_ItemClick, btnComprobante_ItemClick, btnConsultaDeudaNotificada_ItemClick, btnConsultaDeudaTotal_ItemClick, btnConsultar_ItemClick, btnIncidenteTecnico_ItemClick, btnNotificar_ItemClick, btnSeleccionarTodo_Click, btndesSeleccionarTodo_Click, chDeudaActualizada_CheckedChanged, chPagosParciales_CheckedChanged, grdvNotificaciones_CellValueChanged, grdvNotificaciones_CustomSummaryCalculate, grdvNotificaciones_FocusedRowChanged, oServicio_SeleccionarId, objGestionMora__MostrarMensaje, repositoryItemCheckEdit1_CheckedChanged, riComboOrden_SelectedIndexChanged
- **frmTratamientoMorosos_Comprobantes**: <Eliminar>b__10_0, Confirmar, Dispose, Eliminar, InitializeComponent, NuevoItem_Producto, Validar, btnAgregar_Click, btnEliminar_Click, ok_Cancel1_ClickAceptar
- **frmTratamientoMorosos_OT**: Dispose, Get_ViaIngreso, Guadar, InitializeComponent, Validar, ok_Cancel1_ClickAceptar

### ProMod_GestionMora.Properties (1)

- **Resources**

## Cadenas SQL embebidas (0)

