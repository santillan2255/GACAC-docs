# Inventario de c:\Users\lenovo\Documents\GACAC\procoop-relevamiento\binarios\SISTEMA_PRD\ProcoopNet.exe

Tipos: 57 | Métodos: 644 | Campos: 538

## Referencias a ensamblados

- AVL
- CapaDatos
- Configuracion
- DevExpress.Data.v14.1
- DevExpress.Printing.v14.1.Core
- DevExpress.Utils.v14.1
- DevExpress.XtraBars.v14.1
- DevExpress.XtraEditors.v14.1
- DevExpress.XtraGrid.v14.1
- DevExpress.XtraPrinting.v14.1
- Microsoft.VisualBasic
- ProMod_Cobranzas
- ProMod_Facturacion
- ProMod_Tablero
- ProMod_Tickets
- ProMod_Titulares
- ReglasNegocio
- SkinsProcoopNET
- System
- System.Core
- System.Data
- System.Data.DataSetExtensions
- System.Data.Linq
- System.Drawing
- System.Web.Extensions
- System.Windows.Forms
- mscorlib

## Tipos por namespace

### (global) (41)

- **<>c**: <grdvParametros_CustomRowCellEdit>b__33_6, <grdvParametros_CustomRowCellEdit>b__33_7, <grdvTipoReporte_FocusedRowChanged>b__28_0
- **<>c**: <Arma_Columnas>b__19_0, <Arma_Columnas>b__19_1, <grdCriterio_KeyDown>b__55_0
- **<>c**: <Configuraciones_Load>b__29_0
- **<>c**: <GetControl>b__1_0, <GetControl>b__1_1, <GetControl>b__1_2
- **<>c**: <CargarTarjetasNotificaciones>b__157_0, <CargarTarjetasNotificaciones>b__157_1, <CheckButtonVisibility>b__79_0, <ChequearMails>b__147_0, <ChequearMails>b__147_1, <ChequearNotificaciones>b__159_1, <GetItems>b__73_0, <Inicio_ProCoop_Resize>b__110_0, <Inicio_ProCoop_Resize>b__110_1, <Inicio_ProCoop_Resize>b__110_2, <Inicio_ProCoop_Resize>b__110_3, <Inicio_ProCoop_Resize>b__110_4, <Inicio_ProCoop_Resize>b__110_5, <Inicio_ProCoop_Resize>b__110_7, <LevantaGrupos>b__72_0, <LevantaGrupos>b__72_2, <LevantaGrupos>b__72_4, <LevantaMenu>b__67_0, <LevantaMenu>b__67_1, <MostrarNotificaciones>b__96_0, <MostrarNotificaciones>b__96_1, <MostrarNotificaciones>b__96_2, <MostrarNotificaciones>b__96_3, <MostrarNotificaciones>b__96_4, <MostrarNotificaciones>b__96_5, <britem_ItemClick>b__114_0, <btnMasNoticias_ItemClick>b__126_0, <btnMasNoticias_ItemClick>b__126_1, <btnNotificacion_ItemClick>b__144_0, <btnNotificacion_ItemClick>b__144_1, <btnVerDerecha_ItemClick>b__113_0, <btnVerDerecha_ItemClick>b__113_1, <btnVerDerecha_ItemClick>b__113_3, <btnVerDerecha_ItemClick>b__113_4, <btnVerDerecha_ItemClick>b__113_5, <btnVerIzquierda_ItemClick>b__112_0, <btnVerIzquierda_ItemClick>b__112_1, <btnVerIzquierda_ItemClick>b__112_3
- **<>c**: <InicioCorriendo>b__2_0, <Main>b__8_0
- **<>c**: <.ctor>b__5_0, <Guardar>b__10_0, <Validar>b__11_0, <frmEncuestas_FormClosing>b__12_0
- **<>c**: <Add_DetalleFinanciacion>b__8_0, <Print>b__5_1
- **<>c**: <Iniciar>b__14_0, <Iniciar>b__14_1, <Iniciar>b__14_2
- **<>c__DisplayClass110_0**: <Inicio_ProCoop_Resize>b__6
- **<>c__DisplayClass112_0**: <btnVerIzquierda_ItemClick>b__2
- **<>c__DisplayClass126_0**: <btnMasNoticias_ItemClick>b__3
- **<>c__DisplayClass144_0**: <btnNotificacion_ItemClick>b__3
- **<>c__DisplayClass33_0**: <grdvParametros_CustomRowCellEdit>b__0, <grdvParametros_CustomRowCellEdit>b__1, <grdvParametros_CustomRowCellEdit>b__2, <grdvParametros_CustomRowCellEdit>b__3, <grdvParametros_CustomRowCellEdit>b__4, <grdvParametros_CustomRowCellEdit>b__5
- **<>c__DisplayClass33_1**: <grdvParametros_CustomRowCellEdit>b__8, <grdvParametros_CustomRowCellEdit>b__9
- **<>c__DisplayClass37_0**: <login_Load>b__0
- **<>c__DisplayClass3_0**: <button1_Click>b__1
- **<>c__DisplayClass5_0**: <Print>b__0, <Print>b__2, <Print>b__3, <Print>b__4, <Print>b__5
- **<>c__DisplayClass5_1**: <Print>b__10, <Print>b__11, <Print>b__12, <Print>b__8, <Print>b__9
- **<>c__DisplayClass67_0**: <LevantaMenu>b__2
- **<>c__DisplayClass6_0**
- **<>c__DisplayClass72_0**: <LevantaGrupos>b__1
- **<>c__DisplayClass72_1**: <LevantaGrupos>b__3
- **<>c__DisplayClass72_2**: <LevantaGrupos>b__5
- **<>c__DisplayClass82_0**: <ObtenerNoticia>b__0, MoveNext
- **<>c__DisplayClass8_0**: <Main>b__2
- **<>c__DisplayClass8_1**: <Main>b__1
- **<>c__DisplayClass8_2**: <Main>b__3
- **<>c__DisplayClass8_3**: <Main>b__4
- **<>f__AnonymousType0`6**: Equals, GetHashCode, ToString
- **<Module>**
- **<britem_ItemClick>d__114**: SetStateMachine
- **AbrirCalendarioDelegate**: BeginInvoke, EndInvoke, Invoke
- **MSGDelegate**: BeginInvoke, EndInvoke, Invoke
- **MyCellMergeHelper**: AddMergedCell, DrawMergedCells, GetMergedCell, GridControl_Paint, IsMergedCell, SafeSetCellValue, SafeSetMergedCellValue, view_CellValueChanged
- **MyGridPainter**: DrawMergedCell
- **MyMergedCell**
- **ShowPopupDelegate**: BeginInvoke, EndInvoke, Invoke
- **SimpleDelegate**: BeginInvoke, EndInvoke, Invoke
- **SkinManager**
- **TagNotificacion**

### Procoop (7)

- **Funciones**: CorregirParametros, EjecutarFuncion, EjecutarFuncion_ConErrMsg, GetControl, Invoke_CustomAction, Invoke_CustomFunction, ShowFormImportador, ShowFormulario, ShowWaitForm, ShowWaitForm_Ctrl
- **Inicio_ProCoop**: <CargarTarjetasNotificaciones>b__157_2, <CargarTarjetasNotificaciones>b__157_3, <ChequearNotificaciones>b__159_0, <InicializarForm>b__66_0, <ObtenerNoticia>b__82_1, <btnMasNoticias_ItemClick>b__126_2, <btnNotificacion_ItemClick>b__144_2, <btnVerDerecha_ItemClick>b__113_2, AbrirCalendario, AddOwnedForm, AgregarBoton, AgregarConfiguracion, BackgroundPanel, Bloquear, BuscarBoton, CargarFondosPanelNotificaciones, CargarPanelNotificaciones, CargarTarjetasNotificaciones, CheckButtonVisibility, CheckFrame, CheckTeclado, ChequearEstructura, ChequearMails, ChequearNotificaciones, ChequearVersion, ChieldFormClosed, Comando, Dispose, EstadoTimer, GetAsyncKeyState, GetCursorPos, GetImageWait, GetItems, GetPopupConfig, GetShortcut, GetVentana, InicializarForm, IniciarCalendarioTh, IniciarTeamViewer, IniciarTemporizador, Inicio_ProCoop_FormClosing, Inicio_ProCoop_Load, Inicio_ProCoop_Resize, InitializeComponent, InvokeFunction, LevantaGrupos, LevantaMenu, LevantarLogin, MostrarNotificaciones, NotificarOrdenes, Nucleo_GetMainForm, Nucleo_ShowingDynamicForm, NumNoticias, ObtenerNoticia, PanelNotificaciones_Paint, PopupCorreo_AlertClick, ProcessStart, SetNoticia, ShowPopup, SincronizarTablas
- **Program**: Application_ThreadException, CargarProcoop, CloseApplication, CloseWaitForm, InicioCorriendo, Init, LoginUsuario, Main, MostrarWaitForm
- **frmConfiguraciones**: AddImagen, CargarImagenes, CargarServers, Cargarserversth, Configuraciones_Load, Dispose, GetCarpeta, GetClaveDia, GetForm, InitializeComponent, MSG, Sincronizar, Validaciones, btnConectar_Click, btnProbar_Click, button1_Click, button1_Click_1, button2_Click, button3_Click, button4_Click, button5_Click, button6_Click, button7_Click_1, cboServers_KeyPress, chkUtilizarS3_CheckedChanged, label15_DoubleClick, label16_DoubleClick, ok_Cancel1_ClickAceptar, ok_Cancel1_ClickCancelar
- **frmInformes**: <frmInformes_Load>b__21_0, <grdvTipoReporte_FocusedRowChanged>b__28_1, Dispose, GetDt, GrdvParametros_RowCellStyle, Imprimir, InitializeComponent, RefreshParametros, frmInformes_Load, grdParametros_SizeChanged, grdvParametros_CustomRowCellEdit, grdvParametros_DataSourceChanged_1, grdvParametros_FocusedRowChanged, grdvParametros_TopRowChanged, grdvTipoReporte_CustomColumnDisplayText, grdvTipoReporte_FocusedRowChanged, grdvTipoReporte_StartSorting, objInforme_EjecutarFormulario, objInforme_EjecutarFuncion, objInforme__MostrarFileDialog, objInforme__MostrarMensaje, ok_Cancel1_ClickAceptar, ok_Cancel1_ClickCancelar, repButton_ButtonClick, repCheck_CheckedChanged, repCombo_SelectedIndexChanged, txtedit_Leave
- **frmLogin**: ChangePass, CurrentDomain_AssemblyResolve, Dispose, InitializeComponent, LevenshteinDistance, ValidarContraseña, ValidarUsoSistema, cmdAceptar_Click, cmdCancelar_Click, login_FormClosed, login_Load, timer1_Tick
- **frmTransicion**: <Cargar_barra_herramientas>b__15_0, <barEditItem1_EditValueChanged>b__44_0, <grdCriterio_KeyDown>b__55_1, <lstCriterio_SelectedIndexChanged>b__23_0, <lstTipo_SelectedIndexChanged>b__25_0, Arma_Columnas, CargarForm, Cargar_barra_herramientas, ClickBotones, Crear_Objeto, Dispose, FrmVista_Cerrar, GetParametros, InitializeComponent, Load_lv, Load_tv, barEditItem1_EditValueChanged, btnAgregar_Click, btnAgregar_ItemClick, btnConsultar_Click, btnConsultar_ItemClick, btnEliminar_Click, btnEliminar_ItemClick, btnFilaFiltrado_CheckedChanged, btnGuardarVista_ItemClick, btnImprimirRep_ItemClick, btnImprimirResultado_ItemClick, btnImprimir_Click, btnModificar_Click, btnModificar_ItemClick, btnOperación_DropDownItemClicked, btnPanelBusqueda_CheckedChanged, btnResetVista_ItemClick, btnVerAgrupar_CheckedChanged, chkVista_Prede_Click, cmdBuscar_Click, cmdVistas_Click, frmTransicion_Load, frmTransicion_Shown, grdCriterio_KeyDown, grdvCriterio_FocusedRowChanged, grdvCriterio_SelectionChanged, item_ItemClick, lstCriterio_SelectedIndexChanged, lstTipo_SelectedIndexChanged, lv_SelectedIndexChanged, oEntidad__MostrarMensaje, resultadoDeLaBusquedaToolStripMenuItem_Click, txtCantidad_Mostrar_Validated

### Procoop.Forms (7)

- **Frm_Auxilar**: <button1_Click>b__3_0, Add_DetalleFinanciacion, Add_Facturas, Clear, Dispose, Frm_Auxilar_Load, Get_Facturas, InitializeComponent, Print, button1_Click
- **IconoNotificacion**: <SincronizarPWeb>b__33_0, ChequearFacturaElectronica, ChequearProcoopWeb, ConfigurarTimer, Dispose, EjecutarTareaAPeticion_Click, Iniciar, InitializeComponent, OfrmEnvio_FormClosed, SincronizarPWeb, TimerAjusteHora_Tick, TimerPMovilVentas_Elapsed, TimerPMovil_Elapsed, Timer_5Seg_Tick, btnEstadoPmovilVentas_Click, btnFcElectronica_Click, btnProgresoWeb_Click, btnSalir_Click, btnTareasProgramadas_Click, btnVerFormPmovilVentas_Click, btnVerFormularioElectronica_Click, btnVerLog_Click, notifyIcon1_Click, objServicio_Notificar, objServicio__SincronizarWeb
- **WaitForm_Importador**: Dispose, InitializeComponent
- **frmEncuestas**: CargarEncuesta, Dispose, Guardar, InitializeComponent, Validar, btnAceptar_Click, btnNoContestar_Click, checkEdit9_CheckedChanged, frmEncuestas_FormClosing
- **frmInitialWait**: Dispose, InitializeComponent
- **frmMigrarTabla**: <ok_Cancel1_ClickAceptar>b__2_0, Dispose, InitializeComponent, Migrar, SendMessage, ok_Cancel1_ClickAceptar, ok_Cancel1_ClickCancelar
- **frmSelectConfiguracion**: CargarItems, Dispose, InitializeComponent, SetPlaceholder, frmSelectConfiguracion_Load, listView1_DoubleClick, listView1_KeyPress

### Procoop.Properties (2)

- **Resources**
- **Settings**

## Cadenas SQL embebidas (3)

- `SELECT name FROM master.dbo.sysdatabases where name not in ('Master','tempdb','model','msdb')`
- `SELECT name FROM master.dbo.sysdatabases where name  = '`
- `select COD_VAR, NOM_VAR , DES_VAR , CARACTER, LOGICA, NUMERICA, COD_MOD = 4, TIP_VAR = 'C', TIP_CTRL = 0, CONF_CTRL = '' from VARIABLE`
