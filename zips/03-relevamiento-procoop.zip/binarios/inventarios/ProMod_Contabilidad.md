# Inventario de c:\Users\lenovo\Documents\GACAC\procoop-relevamiento\binarios\SISTEMA_PRD\ProMod_Contabilidad.dll

Tipos: 37 | Métodos: 306 | Campos: 481

## Referencias a ensamblados

- CapaDatos
- Configuracion
- DevExpress.Data.v14.1
- DevExpress.Utils.v14.1
- DevExpress.XtraBars.v14.1
- DevExpress.XtraEditors.v14.1
- DevExpress.XtraGrid.v14.1
- DevExpress.XtraTreeList.v14.1
- ReglasNegocio
- System
- System.Core
- System.Data
- System.Data.Linq
- System.Drawing
- System.Windows.Forms
- mscorlib

## Tipos por namespace

### (global) (12)

- **<>c**
- **<>c**: <ValidarDatos>b__11_0
- **<>c**: <GenerarProceso>b__4_0, <GenerarProceso>b__4_1, <GenerarProceso>b__4_2, <GenerarProceso>b__4_3, <GenerarProceso>b__4_4, <GenerarProceso>b__4_5
- **<>c**: <Marcar>b__5_0, <ok_Cancel1_ClickAceptar>b__6_0
- **<>c**: <Validar>b__15_0
- **<>c__DisplayClass10_0**
- **<>c__DisplayClass10_1**: <GuardarInflacio>b__2
- **<>c__DisplayClass13_0**: <btnActualizar_Click>b__0, <btnActualizar_Click>b__1, <btnActualizar_Click>b__2, <btnActualizar_Click>b__3
- **<>c__DisplayClass5_0**: <Marcar>b__1
- **<>f__AnonymousType0`4**: Equals, GetHashCode, ToString
- **<Module>**
- **TipoCambio**

### ProMod_Contabilidad.Forms (24)

- **Estado_AsientoDetalle**
- **abm_Asiento_Personalizado**: Dispose, Guardar, InitializeComponent, abm_Asiento_Personalizado_Load, abm_Asiento_Personalizado__GetGridViewSource, abm_Asiento_Personalizado__ModificoRegistro_PreSave, abm_Asiento_Personalizado__ModoForm_Change, abm_Asiento_Personalizado__NuevoRegistro_PreSave, abm_Asiento_Personalizado__ValidFields, cboTipoCuenta_SelectedIndexChanged
- **abm_CtEjer**: Dispose, InitializeComponent, abm_CtEjer_Load, abm_CtEjer__EliminoRegistro_PreSave, abm_CtEjer__ModificoRegistro_CargarControles, abm_CtEjer__NuevoRegistro_CargarControles, abm_CtEjer__ValidFields
- **abm_CtPlan**: CargarColumnas, CargarControles, Dispose, Guardar, InitializeComponent, ShowPrintPreview, abm_CtPlan_Load, abm_CtPlan__GetGridViewSource, abm_CtPlan__ModificoRegistro_CargarControles, abm_CtPlan__ModificoRegistro_PreSave, abm_CtPlan__NuevoRegistro_PreSave, abm_CtPlan__Show_Imprimir, abm_CtPlan__ValidFields, btnUinificar_Click, cboAjustable_SelectedIndexChanged, cboImputable_SelectedIndexChanged, chkVista_CheckedChanged, simpleButton1_Click, tbcFichas_SelectedPageChanged
- **abm_CtSeccion**: Dispose, InitializeComponent, abm_CtSeccion_Load, abm_CtSeccion__ModificoRegistro_CargarControles, abm_CtSeccion__ModificoRegistro_PreSave, abm_CtSeccion__NuevoRegistro_CargarControles, cmdCategorias_Click
- **abm_CtsRubros**: Dispose, InitializeComponent
- **abm_Resulta**: Dispose, InitializeComponent, abm_Resulta_Load
- **abm_Rubcapi**: Dispose, InitializeComponent, Presave, abm_Rubcapi__ModificoRegistro_CargarControles, abm_Rubcapi__ModificoRegistro_PreSave, abm_Rubcapi__ModoForm_Change, abm_Rubcapi__NuevoRegistro_PreSave, abm_Rubcapi__ValidFields
- **abm_Tabinfl**: CargarInflacio, Dispose, GuardarInflacio, InitializeComponent, abm_Tabinfl__ModificoRegistro_CargarControles, abm_Tabinfl__ModificoRegistro_PreSave, abm_Tabinfl__NuevoRegistro_CargarControles, abm_Tabinfl__NuevoRegistro_PreSave, btnActualizar_Click, btnEliminar_Click
- **frmAsientos**: AgregarItems, Dispose, EditarItems, EliminarItems, GuardarAsiento, InitializeComponent, Validar_CierreContable, btnAgregar_Click, btnEditar_Click, btnEliminar_Click, frmAsientos_Load, ok_Cancel1_ClickAceptar, ok_Cancel1_ClickAdjuntos, ok_Cancel1_ClickCancelar
- **frmAsientos_Detalle**: CargarAsignaciones, Dispose, InitializeComponent, SetSizeForm, ValidarDatos, frmAsientos_Detalle_Load, oCuenta_SeleccionarId, ok_Cancel1_ClickAceptar, ok_Cancel1_ClickCancelar, txtDebe_Leave, txtHaber_Leave
- **frmAsignarCuentasYRubros**: ActualizarGrilla, AgruparGrilla, CargarCuentas, CargarObjetos, Dispose, InitializeComponent, ObtenerSeleccionados, Tamaño, VaciarGrilla, btnActualizarRubro_Click, btnActualizar_Click, btnGuardarCambios_Click, cboTipoCambio_SelectedIndexChanged, ckeAgrupar_CheckedChanged, ckeSinAsignar_CheckedChanged, oRubro_SeleccionarId
- **frmCierreDiario**: <CargarCierre>b__3_0, CargarCierre, Dispose, GenerarProceso, HabilitarFiltros, ImprimirAjustes, ImprimirComposicion, ImprimirComposicionStock, ImprimirComposicionVentas, ImprimirMayor, InitializeComponent, btnFiltroFactura_Click, btnValuacion_Click, cboTipo_SelectedIndexChanged, checkBox3_CheckedChanged, chkAjusteInflacion_CheckedChanged, chkBancos_CheckedChanged, chkCobranza_CheckedChanged, chkComposicionStock_CheckedChanged, chkCompras_CheckedChanged, chkDetalleXOperacion_CheckedChanged, chkFechaEmisionVentas_CheckedChanged, chkFinanciaciones_CheckedChanged, chkStock_CheckedChanged, chkVentas_CheckedChanged, frmCierreDiario_Load, oEjercicio_SeleccionarId, ok_Cancel1_ClickAceptar, ok_Cancel1_ClickCancelar
- **frmCierreDiario_Resultado**: Dispose, GenerarDataSource, InitializeComponent, ok_Cancel1_ClickAceptar, ok_Cancel1_ClickCancelar
- **frmEliminacionMasiva**: <ok_Cancel1_ClickAceptar>b__6_1, Buscar, Dispose, InitializeComponent, Marcar, btnSeleccionarTodo_Click, btndesSeleccionarTodo_Click, cmdBuscar_Click, ok_Cancel1_ClickAceptar
- **frmExportarSIRCAR**: Dispose, GetFiltros, ImprimirAsiento, InitializeComponent, ObtenerRegistros, ValidarForm, btnExportar_Click, cbFecha_SelectedIndexChanged, cbTipo_SelectedIndexChanged, frmExportarSIRCAR_Load, txtFechaDesde_DateTimeChanged, txtFechaDesde_Leave, txtFechaHasta_DateTimeChanged, txtFechaHasta_Leave, txtJuridiccionCM_EditValueChanged, txtTipoRegimen_EditValueChanged
- **frmImpresiones**
- **frmImprimirHojasRubricar**: Dispose, GuardarLineas, Imprimir, InitializeComponent, btnGuardarLineas_Click, frmImprimirHojasRubricar_Load, ok_Cancel1_ClickAceptar
- **frmInformeAnticiposAUnaFecha**: Dispose, Get_Filtros, Imprimir, InitializeComponent, ValidarFiltros, ok_Cancel1_ClickAceptar
- **frmMayor**: Dispose, InitializeComponent, ValidaDatos, botones_Abm1_ClickImprimir, botones_Abm1_ClickSalir, btnBuscar_Click, frmMayor_Load, oVerAsiento_Click
- **frmRenumerar**: Dispose, InitializeComponent, frmRenumerar_Load, oEjercicio_SeleccionarId, ok_Cancel1_ClickAceptar
- **frmRenumerarCuentas**: Confirmar, Dispose, InitializeComponent, Validar, ok_Cancel1_ClickAceptar
- **frmSumasySaldos**: Buscar, Dispose, InitializeComponent, ValidaDatos, botones_Abm1_ClickImprimir, botones_Abm1_ClickSalir, btnBuscar_Click, btnDetalleSeccion_Click, cmdConsultar1_Click, frmSumasySaldos_Load, oVerMayor_Click
- **frm_AsignarSeccion**: CargarGrilla, Dispose, Guardar, InitializeComponent, Limpiar, Set_Form, Set_Items, Set_Size, Validar, barButtonItem1_ItemClick, btnGuardar_ItemClick, cboModelo_Leave, cboModelo_SelectedIndexChanged, cboTipoElemento_SelectedIndexChanged, cboTipoOperacion_SelectedIndexChanged, chkPlantilla_CheckedChanged, frm_AsignarSeccion_Load, oElemento_SeleccionarId

### ProMod_Contabilidad.Properties (1)

- **Resources**

## Cadenas SQL embebidas (0)

