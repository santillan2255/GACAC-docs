# Inventario de c:\Users\lenovo\Documents\GACAC\procoop-relevamiento\binarios\SISTEMA_PRD\AutoGestion.exe

Tipos: 71 | Métodos: 597 | Campos: 585

## Referencias a ensamblados

- AxInterop.WMPLib
- CapaDatos
- CefSharp
- CefSharp.Core
- CefSharp.OffScreen
- Configuracion
- DevExpress.Data.v14.1
- DevExpress.Printing.v14.1.Core
- DevExpress.Utils.v14.1
- DevExpress.XtraBars.v14.1
- DevExpress.XtraEditors.v14.1
- DevExpress.XtraGrid.v14.1
- Interop.WMPLib
- ProMod_Cobranzas
- ProcoopNet
- ReglasNegocio
- System
- System.Core
- System.Data
- System.Data.Linq
- System.Drawing
- System.Windows.Forms
- mscorlib

## Tipos por namespace

### (global) (47)

- **<>c**: <Validar>b__0_0, <Validar>b__0_1, <Validar>b__0_2, <Validar>b__0_4, <Validar>b__0_6
- **<>c**: <WindowsUIView1_QueryControl>b__20_0
- **<>c**: <ActualizarTotalpagar>b__22_0, <CargarFiltro>b__20_0, <CargarFiltro>b__20_1, <CargarFiltro>b__20_2, <CargarPantallaDeuda>b__36_0, <CargarPantallaDeuda>b__36_1, <CargarPantallaDeuda>b__36_2, <GetComprobantesPagar>b__30_0, <GetComprobantesPagar>b__30_1, <GetComprobantesPagar>b__30_2, <GetComprobantesPagar>b__30_3, <GetComprobantesPagar>b__30_4, <IngresarEfectivo>b__32_0, <IngresarEfectivo>b__32_1, <IngresarEfectivo>b__32_2, <IngresarEfectivo>b__32_3, <InitForm>b__18_0, <RegistrarCobranzaEfectivo>b__27_0, <RegistrarCobranzaEfectivo>b__27_1, <RegistrarCobranzaQr>b__28_1, <RegistrarCobranzaTarjeta>b__35_0, <RegistrarPago>b__33_0, <ValidarPagoQR>b__29_0, <pnlContinuar3_ButtonClick>b__58_0, <windowsUIButtonPanel5_ButtonClick>b__61_0, <windowsUIButtonPanel5_ButtonClick>b__61_1
- **<>c**: <ActualizarTotalpagar>b__19_0, <CargarFiltro>b__17_0, <CargarFiltro>b__17_2, <CargarFiltro>b__17_3, <CargarPantallaDeuda>b__33_0, <CargarPantallaDeuda>b__33_1, <GetComprobantesPagar>b__27_0, <GetComprobantesPagar>b__27_1, <GetComprobantesPagar>b__27_2, <GetComprobantesPagar>b__27_3, <GetComprobantesPagar>b__27_4, <IngresarEfectivo>b__29_0, <IngresarEfectivo>b__29_1, <IngresarEfectivo>b__29_2, <IngresarEfectivo>b__29_3, <InitForm>b__11_0, <RegistrarCobranzaEfectivo>b__24_0, <RegistrarCobranzaEfectivo>b__24_1, <RegistrarCobranzaQr>b__25_1, <RegistrarCobranzaTarjeta>b__32_0, <RegistrarPago>b__30_0, <ValidarIIBB>b__21_0, <ValidarIIBB>b__21_1, <ValidarIIBB>b__21_2, <ValidarIIBB>b__21_4, <ValidarIIBB>b__21_6, <ValidarPagoQR>b__26_0, <pnlContinuar3_ButtonClick>b__51_0, <windowsUIButtonPanel5_ButtonClick>b__54_0, <windowsUIButtonPanel5_ButtonClick>b__54_1
- **<>c**: <CargarCuotas>b__40_0, <CargarCuotas>b__40_1, <CargarCuotas>b__40_2, <CargarCuotas>b__40_3, <CargarCuotas>b__40_4, <CargarCuotas>b__40_5, <CargarCuotas>b__40_6, <CargarCuotas>b__40_7
- **<>c**: <CargarCuotas>b__42_0, <CargarCuotas>b__42_1, <CargarCuotas>b__42_2, <CargarCuotas>b__42_3, <CargarCuotas>b__42_4, <CargarCuotas>b__42_5, <CargarCuotas>b__42_6, <CargarCuotas>b__42_7
- **<>c**: <CargarDatos>b__16_7, <GenerarQR>b__19_0
- **<>c**: <CalcularVenta>b__29_0, <CargarServicio>b__40_0, <CargarServicio>b__40_1, <CargarServicio>b__40_2, <InitForm>b__12_0, <RegistrarVenta>b__37_0, <SeleccionarServicio>b__25_0, <SeleccionarServicio>b__25_1, <pnlContinuar2_ButtonClick>b__50_0, <windowsUIButtonPanel1_ButtonClick>b__56_0
- **<>c__DisplayClass0_0**: <EnviarMailRecibo>b__0
- **<>c__DisplayClass0_0**
- **<>c__DisplayClass0_0**: <Validar>b__3
- **<>c__DisplayClass0_1**: <Validar>b__5
- **<>c__DisplayClass13_0**: <Mensaje>b__0
- **<>c__DisplayClass16_0**
- **<>c__DisplayClass17_0**
- **<>c__DisplayClass20_0**: <ActualizarImportes>b__0, <ActualizarImportes>b__1
- **<>c__DisplayClass21_0**: <ValidarIIBB>b__3
- **<>c__DisplayClass21_1**: <ValidarIIBB>b__5
- **<>c__DisplayClass22_0**: <GetDetallesMarcados>b__0
- **<>c__DisplayClass23_0**: <GetDetallesCreditos>b__0, <GetDetallesCreditos>b__1
- **<>c__DisplayClass24_0**: <ActualizarImportes>b__0, <ActualizarImportes>b__1
- **<>c__DisplayClass31_0**: <EviarMail_Recibo>b__0
- **<>c__DisplayClass33_0**: <CargarPantallaDeuda>b__2
- **<>c__DisplayClass35_0**: <CerrarVentaQR>b__0
- **<>c__DisplayClass38_0**: <cboTipNro_ButtonChecked>b__0
- **<>c__DisplayClass38_0**: <EviarMail_Recibo>b__0
- **<>c__DisplayClass39_0**
- **<>c__DisplayClass41_0**: <CargarHTML>b__0
- **<>c__DisplayClass43_0**: <ObjLector_LecturaTarjeta>b__0, <ObjLector_LecturaTarjeta>b__1
- **<>c__DisplayClass45_0**: <cboTipNro_ButtonChecked>b__0
- **<>c__DisplayClass45_0**: <ObjLector_LecturaTarjeta>b__0, <ObjLector_LecturaTarjeta>b__1
- **<>c__DisplayClass49_0**: <advBandedGridView1_CellValueChanged>b__0
- **<>c__DisplayClass53_0**: <cboTipNro_ButtonChecked>b__0
- **<>c__DisplayClass56_0**: <advBandedGridView1_CellValueChanged>b__0
- **<>c__DisplayClass58_0**: <cboFormaPago_ButtonChecked>b__0
- **<>c__DisplayClass5_0**: <cbImprimir_ButtonChecked>b__0
- **<>c__DisplayClass7_0**: <EviarMail_Recibo>b__0
- **<>f__AnonymousType0`5**: Equals, GetHashCode, ToString
- **<>f__AnonymousType1`2**: Equals, GetHashCode, ToString
- **<>f__AnonymousType2`4**: Equals, GetHashCode, ToString
- **<>f__AnonymousType3`2**: Equals, GetHashCode, ToString
- **<>f__AnonymousType4`3**: Equals, GetHashCode, Main, ToString
- **<Module>**
- **Resultado**
- **Resultado**
- **Tipo_Tarjeta**
- **Tipo_Tarjeta**

### AutoGestion (1)

- **Program**: Resolver

### AutoGestion.Controles (12)

- **DatosPersona**
- **WebPagos360**: <RegistrarPagos360>b__7_0, Dispose, Initialize, InitializeComponent, Obtener_Pago, RegistrarPagos360
- **ctrlAutoGestionBase**: CrearAnticipo, Dispose, EviarMail_Recibo, Finalizar, GetFormaPago, IngresarDinero, InitializeComponent, LeerTarjeta, ObjLector__LecturaBillete, ObjLector__LecturaTajeta, RegistrarAnticipo, ctrlAutoGestionBase_KeyDown, ctrlAutoGestionBase_KeyPress
- **ctrlCobranza_Seleccion**: <CargarPantallaDeuda>b__36_3, <GetDetallesCreditos>b__26_0, <GetDetallesCreditos>b__26_1, <GetDetallesMarcados>b__25_0, <RegistrarCobranzaQr>b__28_0, AbrirCaja, ActualizarImportes, ActualizarTotalpagar, Calc_Touch1__ClickOK, CambiarImagenFondo, CargarFiltro, CargarPantallaDeuda, ConfigBackButtonQRPanel, Dispose, EnviarTeclaPagoTarjeta, EviarMail_Recibo, GetComprobantesPagar, GetDetallesCreditos, GetDetallesMarcados, HabilitarMediosdePago, IngresarEfectivo, IngresarEfectivoPagos360, InicializarPagoTarjeta, InitForm, InitializeComponent, ObtenerCajaAbierta, PrepararPagoTarjeta, ProcesarPagoTarjeta, RegistrarCobranzaEfectivo, RegistrarCobranzaQr, RegistrarCobranzaTarjeta, RegistrarPago, ValidarIIBB, ValidarPagoQR, advBandedGridView1_CellValueChanged, advBandedGridView1_DoubleClick, advBandedGridView1_RowClick, advBandedGridView1_RowStyle, btnPreview_ButtonClick, cboTipNro_ButtonChecked, ctrlCobranza_Seleccion_KeyDown, grdvCuotas_CellValueChanged, grdvCuotas_GotFocus, grdvGrilla_CustomColumnDisplayText, pnlContinuar1_ButtonClick, pnlContinuar2_ButtonClick, pnlContinuar2_Click, pnlContinuar3_ButtonClick, repositoryItemCheckEdit1_CheckedChanged, repositoryItemCheckEdit2_CheckedChanged, windowsUIButtonPanel5_ButtonClick, windowsUIButtonPanel7_ButtonClick, windowsUIButtonPanel9_ButtonClick, xtraTabControl1_SelectedPageChanged, xtraTabControl1_SelectedPageChanging
- **ctrlCobranza_Seleccion_Vertical**: <RegistrarCobranzaQr>b__25_0, AbrirCaja, ActualizarImportes, ActualizarTotalpagar, Calc_Touch1__ClickOK, CambiarImagenFondo, CargarFiltro, CargarPantallaDeuda, CheckInertion, CheckTime, ConfigBackButtonQRPanel, Dispose, DoInertion, DoScroll, EviarMail_Recibo, GetComprobantesPagar, GetDetallesCreditos, GetDetallesMarcados, GetRowUnderCursor, HabilitarMediosdePago, IngresarEfectivo, IngresarEfectivoPagos360, InitForm, InitializeComponent, RegistrarCobranzaEfectivo, RegistrarCobranzaQr, RegistrarCobranzaTarjeta, RegistrarPago, ValidarIIBB, ValidarPagoQR, _View_Layout, _View_MouseDown, _View_MouseMove, _View_MouseUp, advBandedGridView1_CellValueChanged, advBandedGridView1_DoubleClick, advBandedGridView1_RowClick, advBandedGridView1_RowStyle, btnPreview_ButtonClick, cboTipNro_ButtonChecked, ctrlCobranza_Seleccion_KeyDown, grdvCuotas_CellValueChanged, grdvCuotas_GotFocus, grdvGrilla_CustomColumnDisplayText, inertionTimer_Tick, pnlContinuar1_ButtonClick, pnlContinuar2_ButtonClick, pnlContinuar2_Click, pnlContinuar3_ButtonClick, repositoryItemCheckEdit1_CheckedChanged, repositoryItemCheckEdit2_CheckedChanged, windowsUIButtonPanel5_ButtonClick, windowsUIButtonPanel7_ButtonClick, windowsUIButtonPanel9_ButtonClick, xtraTabControl1_SelectedPageChanged, xtraTabControl1_SelectedPageChanging
- **ctrlImpresionMail**: Dispose, Habilitar, InitializeComponent, Validar, cbImprimir_ButtonChecked
- **ctrlPagQr**: <OcultarControlesHorizontal>b__12_0, <OcultarControlesVertical>b__13_0, BuildDatosQr, CargarDatos, CentrarControlesQr, Dispose, GenerarQR, GenerarSolicitud, Inicializar, InicializarPrepaga, InicializarVertical, InitializeComponent, OcultarControlesHorizontal, OcultarControlesVertical, Resetear, ValidarDatos, barCodeControl2_Click
- **ctrlPagoQr_Vertical**: Dispose, InitializeComponent
- **ctrlPagoTarjeta**: <GenerarSolicitud>b__37_0, Browser_IsBrowserInitializedChanged, Calc_CodCVC__ClickOK, CargarCuotas, CargarHTML, ConfirmarPago, Continuar, CrearBrowser, Dispose, GenerarSolicitud, InDesignMode, Inicializar, InicializarBrowser, InitializeComponent, LeerTarjeta, ObjLector_LecturaTarjeta, ObtenerSDKPagos360, PagoRegistrado, SelectMail, Sendkey, SetMail, ValidarMail, calcDNI__ClickOK, cbocuotas_SelectedValueChanged, ctrlPagoTarjeta_KeyDown, txtNroTarjeta_KeyDown
- **ctrlPagoTarjeta2**: <GenerarSolicitud>b__36_0, Browser_IsBrowserInitializedChanged, Calc_CodCVC__ClickOK, CargarCuotas, CargarHTML, ConfirmarPago, Continuar, CrearBrowser, Dispose, GenerarSolicitud, InDesignMode, Inicializar, InicializarBrowser, InitializeComponent, LeerTarjeta, ObjLector_LecturaTarjeta, PagoRegistrado, SelectMail, Sendkey, SetMail, ValidarMail, calcDNI__ClickOK, cbocuotas_SelectedValueChanged, ctrlPagoTarjeta_KeyDown, txtNroTarjeta_KeyDown
- **ctrlPagoTarjeta_Vertical**: Dispose, InitializeComponent
- **ctrlPrepaga_Seleccion**: <panelCreditosPendientes_ButtonChecked>b__59_0, <panelCreditosPendientes_ButtonUnchecked>b__60_0, AbrirCaja, AddCreditos, Calc_Touch1__ClickOK, CalcularCapital, CalcularVenta, CargarPantallaImporte, CargarServicio, CerrarVentaCredito, CerrarVentaEfectivo, CerrarVentaQR, CerrarVentaTarjeta, ConfigBackButtonQRPanel, Dispose, Enviar_Comprobante, EsMultiploDe, EviarMail_Recibo, GetInfoCobranza, GetTileElement, GetTileSersoc, HabilitarMediosdePago, ImporteValido, InitForm, InitializeComponent, RegistrarPagoQR, RegistrarVenta, SeleccionarServicio, calc_Touch2__ClickOK, cboFormaPago_ButtonChecked, cboTipNro_ButtonChecked, ctrlCobranza_Seleccion_KeyDown, oTileServicios_ItemClick, panelCreditosPendientes_ButtonChecked, panelCreditosPendientes_ButtonUnchecked, pnlContinuar1_ButtonClick, pnlContinuar2_ButtonClick, windowsUIButtonPanel1_ButtonClick, windowsUIButtonPanel7_ButtonClick, windowsUIButtonPanel7_Click, windowsUIButtonPanel9_ButtonClick, xtraTabControl1_SelectedPageChanged, xtraTabControl1_SelectedPageChanging

### AutoGestion.Forms (1)

- **frmAutoGestion**: AddDinamicTiles, AddTileCobranza, AddTilePrepaga, CanCloseFunc, Dispose, GetItemTextTile, GoHome, IngresaClaveCierre, InitializeComponent, Mensaje, Pregunta, WindowsUIView1_QueryControl, frmAutoGestion_FormClosing, frmAutoGestion_Load, setTile, windowsUIView1_BackButtonClick, windowsUIView1_ControlReleasing

### AutoGestion.Helpers (8)

- **clsBusquedaSocio**: CrearMedioDePago
- **clsEnvioRecibo**
- **clsGridTouchScrollHelper**: <CheckInertion>b__16_0, CheckInertion, DoScroll, GetRowUnderCursor, View_Layout, View_MouseDown, View_MouseMove, View_MouseUp
- **clsMedioPagoFactory**: Buscar
- **clsServicioBusquedaSocio**
- **clsSocioIdentificado**: Limpiar, Validar
- **clsValidadorIIBB**
- **enumFormaPago**

### AutoGestion.Properties (2)

- **Resources**
- **Settings**: EnviarMailRecibo

## Cadenas SQL embebidas (0)

