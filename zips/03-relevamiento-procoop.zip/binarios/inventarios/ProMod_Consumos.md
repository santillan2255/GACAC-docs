# Inventario de c:\Users\lenovo\Documents\GACAC\procoop-relevamiento\binarios\SISTEMA_PRD\ProMod_Consumos.dll

Tipos: 102 | Métodos: 848 | Campos: 1053

## Referencias a ensamblados

- CapaDatos
- Configuracion
- DevExpress.Data.v14.1
- DevExpress.Utils.v14.1
- DevExpress.XtraBars.v14.1
- DevExpress.XtraCharts.v14.1
- DevExpress.XtraCharts.v14.1.UI
- DevExpress.XtraEditors.v14.1
- DevExpress.XtraGrid.v14.1
- DevExpress.XtraNavBar.v14.1
- ReglasNegocio
- System
- System.Core
- System.Data
- System.Data.Linq
- System.Drawing
- System.Windows.Forms
- mscorlib

## Tipos por namespace

### (global) (81)

- **<>c**: <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_1, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_10, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_11, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_14, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_15, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_16, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_2, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_3, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_5, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_6, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7_8, <abm_Cons_Ser__ModificoRegistro_CargarControles>b__6_2, <abm_Cons_Ser__ValidEliminar>b__9_1
- **<>c**: <Validar>b__23_0, <Validar>b__23_1, <Validar>b__23_2
- **<>c**: <cmdImprimir1_Click>b__11_0, <ok_Cancel1_ClickAceptar>b__8_0, <ok_Cancel1_ClickAceptar>b__8_1, <ok_Cancel1_ClickAceptar>b__8_2, <ok_Cancel1_ClickAceptar>b__8_3
- **<>c**: <FrmBonificacionEstimados__Click_Consultar>b__2_0, <grdResultado_Click>b__6_0, <grdvResultado_DataSourceChanged>b__5_0, <ok_Cancel1_ClickAceptar>b__4_0
- **<>c**: <cbServicio_SelectedValueChanged>b__27_1, <oMedTestigo_SeleccionarId>b__26_1, <oMedTestigo_SeleccionarId>b__26_2, <oMedTestigo_SeleccionarId>b__26_4
- **<>c**: <btnGuardar_Click>b__10_0, <btnInvertir_Click>b__9_0, <btnRecalcular_Click>b__8_0, <btnRecalcular_Click>b__8_1, <cmdSalir1_Click>b__12_0
- **<>c**: <btnPropieSer_Click>b__54_0, <btnPropieSer_Click>b__54_1, <cbServicio_SelectedValueChanged>b__27_1, <oCuenta_Change_IdSeleccionado>b__26_1, <oCuenta_Change_IdSeleccionado>b__26_2, <oCuenta_Change_IdSeleccionado>b__26_4
- **<>c**: <Agregar_Fila>b__41_0, <Agregar_Fila>b__41_1, <Agregar_Fila>b__41_2, <Agregar_Fila>b__41_3, <EditarFila>b__42_0, <EditarFila>b__42_1, <EditarFila>b__42_2, <EditarFila>b__42_3, <Limpiar_Columna>b__49_0, <Limpiar_Fila>b__44_0
- **<>c**: <GenerarConsumos>b__12_0
- **<>c**: <Imprimir_Consumos_CtaCorriente>b__2_0, <Imprimir_Consumos_CtaCorriente>b__2_1, <Imprimir_Consumos_CtaCorriente>b__2_2, <Imprimir_Consumos_CtaCorriente>b__2_3, <Imprimir_Consumos_CtaCorriente>b__2_4
- **<>c**: <CargarFormularioConServicio>b__24_0, <CargarSegunServicio>b__8_0
- **<>c**: <ValidarConsumos>b__30_0, <btnConsulta_Click>b__42_1, <grdvSersoc_CellValueChanged>b__41_0, <grdvSersoc_CellValueChanged>b__41_1, <grdvSersoc_CellValueChanged>b__41_2, <grdvSersoc_CellValueChanged>b__41_3, <grdvSersoc_CellValueChanged>b__41_4, <grdvSersoc_CellValueChanged>b__41_5, <grdvSersoc_CellValueChanged>b__41_6, <oCuenta_Change_IdSeleccionado>b__36_0, <oCuenta_Change_IdSeleccionado>b__36_1, <oServicios_SeleccionarId>b__37_0
- **<>c**: <Resetear_ItemClick>b__6_0, <Resetear_ItemClick>b__6_1
- **<>c**: <get_DataSource>b__1_0
- **<>c**: <Get_ChartDataSource>b__16_0, <Get_ChartDataSource>b__16_1, <Get_ChartDataSource>b__16_2, <Get_ChartDataSource>b__16_3, <Get_ChartDataSource>b__16_4, <Get_ChartDataSource>b__16_5, <Get_ConsumosImpresion>b__17_0, <Get_ConsumosImpresion>b__17_1
- **<>c**: <Get_GridDataSource>b__2_0, <Get_GridDataSource>b__2_1, <Get_GridDataSource>b__2_2, <Get_GridDataSource>b__2_3, <Get_GridDataSource>b__2_4, <Get_GridDataSource>b__2_5, <Get_GridDataSource>b__2_7
- **<>c**: <Get_GridDataSource>b__2_0, <Get_GridDataSource>b__2_1, <Get_GridDataSource>b__2_2
- **<>c**: <Get_ChartDataSource>b__5_0, <Get_ChartDataSource>b__5_1, <Get_ChartDataSource>b__5_2, <Get_ChartDataSource>b__5_3, <Get_ChartDataSource>b__5_4, <Get_GridDataSource>b__3_1
- **<>c**: <Get_ChartDataSource>b__16_0, <Get_ChartDataSource>b__16_1, <Get_ChartDataSource>b__16_2, <Get_ChartDataSource>b__16_3, <Get_ChartDataSource>b__16_4, <Get_ChartDataSource>b__16_5, <Get_ChartDataSource>b__16_6, <Get_ConsumosImpresion>b__17_0, <Get_ConsumosImpresion>b__17_1
- **<>c**: <Get_GridDataSource>b__2_0, <Get_GridDataSource>b__2_1, <Get_GridDataSource>b__2_13, <Get_GridDataSource>b__2_17, <Get_GridDataSource>b__2_2, <Get_GridDataSource>b__2_21, <Get_GridDataSource>b__2_23, <Get_GridDataSource>b__2_25, <Get_GridDataSource>b__2_3, <Get_GridDataSource>b__2_4, <Get_GridDataSource>b__2_7, <Get_GridDataSource>b__2_8
- **<>c**: <Get_GridDataSource>b__2_0, <Get_GridDataSource>b__2_1, <Get_GridDataSource>b__2_2
- **<>c**: <Get_ChartDataSource>b__5_0, <Get_ChartDataSource>b__5_1, <Get_ChartDataSource>b__5_2, <Get_ChartDataSource>b__5_3, <Get_ChartDataSource>b__5_4, <Get_GridDataSource>b__3_1
- **<>c__DisplayClass0_0**: <Imprimir_DetalleLLamadas>b__0
- **<>c__DisplayClass19_0**: <AddSersoc>b__0
- **<>c__DisplayClass19_1**: <AddSersoc>b__1
- **<>c__DisplayClass19_2**: <AddSersoc>b__2
- **<>c__DisplayClass1_0**: <get_DataSource>b__1
- **<>c__DisplayClass22_0**: <Actualizar_ComboOrden>b__1
- **<>c__DisplayClass22_1**: <Actualizar_ComboOrden>b__0
- **<>c__DisplayClass24_0**: <CargarFormularioConServicio>b__1
- **<>c__DisplayClass26_0**: <oMedTestigo_SeleccionarId>b__3
- **<>c__DisplayClass26_0**: <oCuenta_Change_IdSeleccionado>b__3
- **<>c__DisplayClass27_0**: <cbServicio_SelectedValueChanged>b__2
- **<>c__DisplayClass27_0**: <cbServicio_SelectedValueChanged>b__2
- **<>c__DisplayClass2_0**: <Get_GridDataSource>b__6
- **<>c__DisplayClass2_0**: <Get_GridDataSource>b__5, <Get_GridDataSource>b__6
- **<>c__DisplayClass2_1**
- **<>c__DisplayClass2_2**: <Get_GridDataSource>b__11, <Get_GridDataSource>b__12, <Get_GridDataSource>b__14, <Get_GridDataSource>b__15, <Get_GridDataSource>b__16, <Get_GridDataSource>b__18, <Get_GridDataSource>b__19, <Get_GridDataSource>b__20, <Get_GridDataSource>b__22, <Get_GridDataSource>b__24
- **<>c__DisplayClass31_0**
- **<>c__DisplayClass31_1**: <AplicarUltimoConsumoTestigo>b__3
- **<>c__DisplayClass3_0**: <Get_GridDataSource>b__0
- **<>c__DisplayClass3_0**: <Get_GridDataSource>b__0
- **<>c__DisplayClass45_0**: <Get_Fila>b__0
- **<>c__DisplayClass50_0**: <Get_Columnas>b__0
- **<>c__DisplayClass51_0**: <Validar_NuevaColumna>b__1
- **<>c__DisplayClass5_0**: <gridView1_ValidateRow>b__0
- **<>c__DisplayClass60_0**: <ImprimirDetalleLlamadas>b__0
- **<>c__DisplayClass6_0**: <abm_Cons_Ser__ModificoRegistro_CargarControles>b__0, <abm_Cons_Ser__ModificoRegistro_CargarControles>b__1
- **<>c__DisplayClass6_1**: <abm_Cons_Ser__ModificoRegistro_CargarControles>b__3, <abm_Cons_Ser__ModificoRegistro_CargarControles>b__4, <abm_Cons_Ser__ModificoRegistro_CargarControles>b__5
- **<>c__DisplayClass7_0**: <abm_Cons_Ser__EliminoRegistro_PreSave>b__0, <abm_Cons_Ser__EliminoRegistro_PreSave>b__4
- **<>c__DisplayClass7_1**: <abm_Cons_Ser__EliminoRegistro_PreSave>b__12, <abm_Cons_Ser__EliminoRegistro_PreSave>b__7, <abm_Cons_Ser__EliminoRegistro_PreSave>b__9
- **<>c__DisplayClass7_2**: <abm_Cons_Ser__EliminoRegistro_PreSave>b__13
- **<>c__DisplayClass8_0**: <abm_Cons_Ser__ModificoRegistro_PreSave>b__0
- **<>c__DisplayClass9_0**: <abm_Cons_Ser__ValidEliminar>b__0
- **<>f__AnonymousType0`2**: Equals, GetHashCode, ToString
- **<>f__AnonymousType10`11**: Equals, GetHashCode, ToString
- **<>f__AnonymousType11`16**: Equals, GetHashCode, ToString
- **<>f__AnonymousType12`4**: Equals, GetHashCode, ToString
- **<>f__AnonymousType13`12**: Equals, GetHashCode, ToString
- **<>f__AnonymousType14`2**: Equals, GetHashCode, ToString
- **<>f__AnonymousType15`5**: Equals, GetHashCode, ToString
- **<>f__AnonymousType1`2**: Equals, GetHashCode, ToString
- **<>f__AnonymousType2`7**: Equals, GetHashCode, ToString
- **<>f__AnonymousType3`2**: Equals, GetHashCode, ToString
- **<>f__AnonymousType4`13**: Equals, GetHashCode, ToString
- **<>f__AnonymousType5`2**: Equals, GetHashCode, ToString
- **<>f__AnonymousType6`9**: Equals, GetHashCode, ToString
- **<>f__AnonymousType7`9**: Equals, GetHashCode, ToString
- **<>f__AnonymousType8`3**: Equals, GetHashCode, ToString
- **<>f__AnonymousType9`2**: Equals, GetHashCode, ToString
- **<Module>**
- **DatosCmp**
- **DatosCmp**
- **DatosConsumo**: Get_ChartDataSource, Get_ConsumosImpresion, Get_DataSource, Get_GridDataSource, SetGridColumns
- **DatosConsumo**: Get_ChartDataSource, Get_ConsumosImpresion, Get_DataSource, Get_GridDataSource, SetGridColumns
- **DatosConsumo_Medidos**: Get_DataSource, Get_GridDataSource, SetGridColumns
- **DatosConsumo_Medidos**: Get_DataSource, Get_GridDataSource, SetGridColumns
- **DatosConsumo_Telefonico**: Get_ChartDataSource, Get_DataSource, Get_GridDataSource, SetGridColumns
- **DatosConsumo_Telefonico**: Get_ChartDataSource, Get_DataSource, Get_GridDataSource, SetGridColumns
- **DatosConsumo_Telefonico_Fact**: Get_DataSource, Get_FacturaSeleccionada, Get_GridDataSource, Get_GrupoSeleccionado, SetGridColumns
- **DatosConsumo_Telefonico_Fact**: Get_DataSource, Get_FacturaSeleccionada, Get_GridDataSource, Get_GrupoSeleccionado, SetGridColumns

### ProMod_Consumos.Controles (1)

- **listTramas**: Dispose, InitializeComponent, gridView1_KeyDown_1, gridView1_ValidateRow, lnkEliminar_OpenLink

### ProMod_Consumos.Forms (19)

- **abm_Cons_Ser**: Dispose, InitializeComponent, abm_Cons_Ser_Load, abm_Cons_Ser__EliminoRegistro_PreSave, abm_Cons_Ser__ModificoRegistro_CargarControles, abm_Cons_Ser__ModificoRegistro_PreSave, abm_Cons_Ser__ModoForm_Change, abm_Cons_Ser__ValidEliminar, txtLectActual_Leave
- **abm_DstConsumos**: Aceptar, AddSersoc, CalcularPorcentaje, Dispose, Eliminar, Get_Sersoc, Inicializar, InitializeComponent, Validar, abm_DstConsumos_Load, btnAdd_Click, btnDelete_Click, chkCategoriaCombinada_CheckedChanged, chkIgualarConsumo_CheckedChanged, ok_Cancel1_ClickAceptar
- **abm_InfoCtd**: Dispose, InitializeComponent, abm_InfoCtd__ModificoRegistro_CargarControles, abm_InfoCtd__ModificoRegistro_PreSave, abm_InfoCtd__NuevoRegistro_CargarControles, abm_InfoCtd__NuevoRegistro_PreSave
- **frmAgrupaDivideConsumos**: ConfigurarForm, Dispose, InitializeComponent, MostrarTestigo, Procesar, Validar, btnConsultar_Click, cboTipoProceso_SelectedIndexChanged, chkVerExcluidos_CheckedChanged, cmdImprimir1_Click, oServicio_SeleccionarId, ok_Cancel1_ClickAceptar
- **frmBonificacionEstimados**: Dispose, FrmBonificacionEstimados__Click_Consultar, FrmBonificacionEstimados__Click_Imprimir, InitializeComponent, grdResultado_Click, grdvResultado_DataSourceChanged, ok_Cancel1_ClickAceptar, pnlFiltros_Paint
- **frmConsultaConsumoMedido**: <cbServicio_SelectedValueChanged>b__27_0, <oCuenta_Change_IdSeleccionado>b__26_0, ActualizarCategoria, Agregar_Consumo, Agregar_ConsumoAdicional, Consultar, Dispose, Eliminar_Consumo, Eliminar_ConsumoNF, Get_ConsumoSeleccionado, Get_SERSOC_seleccionado, HabilitarControles, Imprimir, ImprimirComprobanteRecarga, ImprimirCuentaCorrienteEnergia, ImprimirDetalleLlamadas, ImprimirFactura, InitializeComponent, LoadChart, Modificar_Consumo, Modificar_ConsumoSE, Validar_ConsumoDesconectado, barButtonItem1_ItemClick, btnActualizarCategoria_ItemClick, btnAgregar_ItemClick, btnCargaTecnica_ItemClick, btnConsumoAdicional_ItemClick, btnEliminarNF_ItemClick, btnEliminar_ItemClick, btnGuardadVista_ItemClick, btnImpCtaCteEnergia_ItemClick, btnImpDetalleLlam_ItemClick, btnImpFactura_ItemClick, btnImpResSubtotalAgrupado_ItemClick, btnImpResSubtotal_ItemClick, btnImpRes_ItemClick, btnImpSinGrafico_ItemClick, btnModificarNF_ItemClick, btnModificar_ItemClick, btnPropieSer_Click, btnResetVista_ItemClick, btnVerAdjuntos_ItemClick, cbMedidor_SelectedIndexChanged, cbServicio_SelectedValueChanged, chLlamadasFacturadas_CheckedChanged, chkFijarServicio_CheckedChanged, gvConsumo_DoubleClick, oCuenta_Change_IdSeleccionado, ok_Cancel1_ClickCancelar, txtDesde_Propiedades_EditValueChanged, txtHasta_Propiedades_EditValueChanged
- **frmConsultaConsumoMedidoTestigo**: <cbServicio_SelectedValueChanged>b__27_0, <oMedTestigo_SeleccionarId>b__26_0, Agregar_Consumo, Consultar, Dispose, Eliminar_Consumo, Eliminar_ConsumoNF, Get_ConsumoSeleccionado, Get_SERSOC_seleccionado, HabilitarControles, Imprimir, InitializeComponent, LoadChart, Modificar_Consumo, Modificar_ConsumoSE, Validar_ConsumoDesconectado, btnAgregar_ItemClick, btnEliminarNF_ItemClick, btnEliminar_ItemClick, btnImpRes_ItemClick, btnModificarNF_ItemClick, btnModificar_ItemClick, cbMedidor_SelectedIndexChanged, cbServicio_SelectedValueChanged, chLlamadasFacturadas_CheckedChanged, oMedTestigo_SeleccionarId, ok_Cancel1_ClickCancelar, txtDesde_Propiedades_EditValueChanged, txtHasta_Propiedades_EditValueChanged
- **frmConsumosEstimacion**: Dispose, InitializeComponent, btnGuardar_Click, btnInvertir_Click, btnRecalcular_Click, chkSumarMes_CheckedChanged, cmdSalir1_Click, repositoryItemCheckEdit1_CheckedChanged
- **frmConsumosExportar**: <Validar_NuevaColumna>b__51_0, <Validar_NuevaFila>b__46_0, <Validar_NuevaFila>b__46_1, <Validar_NuevaFila>b__46_2, <Validar_NuevaFila>b__46_3, AgregarConfiguracion, Agregar_Columna, Agregar_Fila, CargarConfiguracion, Cargar_FilaSeleccionada, Dispose, EditarFila, Eliminar_Columna, Eliminar_Fila, Get_Columnas, Get_Fila, Get_Filtros, Get_FormatoInforme, HabilitarBotones, HabilitarComboConsumo, Imprimir, InitializeComponent, Limpiar_Columna, Limpiar_Fila, SeleccionarCategoria, SeleccionarConcepto, SeleccionarServicio, SetSizeForm, ValidarConfiguracion544, Validar_Imprimir, Validar_NuevaColumna, Validar_NuevaFila, btnAddFila_Click, btnAgregarColumna_Click, btnAgregarConfiguracion_Click, btnConfiguracion544_Click, btnDeleteFila_Click, btnEditar_Click, btnEliminarColumna_Click, btnImprimirGC_Click, cbConcepto_SelectedIndexChanged, cbInforme_SelectedIndexChanged, cbTipoFecha_SelectedIndexChanged, chPeriodo_CheckedChanged, chkSubtipo_CheckedChanged, grdvColumnas_FocusedRowChanged, grdvFilas_DoubleClick, grdvFilas_FocusedRowChanged, oCategoria_SeleccionarId, oConfiguracion_SeleccionarId, oServicio_SeleccionarId, ok_Cancel1_ClickAceptar
- **frmDistribucionConsumos**: Buscar, Dispose, GenerarConsumos, Get_Filtros, Imprimir_DetalleLLamadas, Inicializar, InitializeComponent, Validar, btnConsultar_ItemClick, ok_Cancel1_ClickAceptar
- **frmImpresiones**: Imprimir_Consumos, Imprimir_Consumos_CtaCorriente
- **frmInformeConsumoTramasCuedro**: Dispose, InitializeComponent, Print, ok_Cancel1_ClickAceptar
- **frmInformeSecretariaElectrica**: Dispose, InitializeComponent, Print, ValidateForm, ok_Cancel1_ClickAceptar
- **frmInformesConsumos**: Actualizar_ComboOrden, CargarFormularioConServicio, CargarSegunServicio, Configurar, Dispose, EstimarConsumos, EstimarConsumosTestigo, GetFiltros, Imprimir, Imprimir_AgrupadosTramas, Imprimir_Categorias, Imprimir_ConsumosXCategoria, Imprimir_ControlMedidores, Imprimir_Informes, InhabilitarControles, InitializeComponent, LimpiarCampos, PerDifPorcDesde_DateTimeChanged, PerDifPorcHasta_DateTimeChanged, SeleccionarInformeAImprimir, SetLabelTipoFecha, ValidarDatos, Validar_FiltrosEstimar, btnConsumosEstimarTestigo_Click, btnConsumosEstimar_Click, btnEstimarConPropiedad_Click, btnLimpiar_Click, btnTramas_Click, cboDifPorConsumo_SelectedIndexChanged, cboInformes_SelectedIndexChanged_1, cboOrden_SelectedIndexChanged, checkBox1_CheckedChanged, chkConSinCons_CheckedChanged, chkConsEst_CheckedChanged, chkDescConCons_CheckedChanged, chkMedInd_CheckedChanged, chkPerMay_CheckedChanged, dtPeriodoDesde_DateTimeChanged, dtPeriodoHasta_DateTimeChanged, dtPeriodo_DateTimeChanged, frmInformesConsumos_Load, gbcDifPorcDias_CheckedChanged, oPropiedadAdicional_SeleccionarId, oServicio_SeleccionarId_1, ok_Cancel1_ClickAceptar
- **frmPerdidasServiciosMedidos**: Dispose, Get_Filtros, InitializeComponent, ok_Cancel1_ClickAceptar
- **frmRegistroConsumoPropio**: Configurar, Dispose, InitializeComponent, btnConsulta_Click, btnCorrecto_Click, btnInicializar_Click, grdSersoc_EditorKeyPress, grdvConsumoP_CellValueChanged, oServicios_SeleccionarId
- **frmRegistroLecturas**: <btnConsulta_Click>b__42_0, AplicarUltimoConsumoTestigo, Cargar_Consumo, Configurar, Dispose, InitializeComponent, Limpiar, ValidarConsumos, btnConsulta_Click, btnCorrecto_Click, grdSersoc_EditorKeyPress, grdvSersoc_CellValueChanged, grdvSersoc_FocusedRowChanged, oCuenta_Change_IdSeleccionado, oObserstad_SeleccionarId, oServicios_Load, oServicios_SeleccionarId, txtFecha_DateTimeChanged
- **frmRegistroMedidoPropio**: Dispose, InitializeComponent, btnCorrecto_Click
- **frmTransgresiones**: AgregarSubItemsOperaciones, Dispose, InitializeComponent, Resetear_ItemClick, frmTransgresiones_Load, frmTransgresiones__Click_Consultar, oServicio_SeleccionarId, ok_Cancel1_ClickAceptar

### ProMod_Consumos.Properties (1)

- **Resources**

## Cadenas SQL embebidas (0)

