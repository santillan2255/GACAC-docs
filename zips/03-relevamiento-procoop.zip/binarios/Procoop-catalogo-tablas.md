# Catálogo de tablas de Procoop

Fuente: metadatos de `CapaDatos.dll` (Procoop 10.4.6.722). 659 tablas, 8286 columnas. Las descripciones se infirieron de nombres, columnas, relaciones y pantallas relevadas; validar contra el esquema real de la base.

| Módulo | Tablas |
|---|---|
| 1. Socios, cuentas y servicios | 24 |
| 2. Servicios, categorías y tarifas | 48 |
| 3. Medición y consumos | 24 |
| 4. Facturación | 35 |
| 5. Fiscal / ARCA / impuestos | 26 |
| 6. Cobranza y caja | 21 |
| 7. Entes recaudadores y pagos electrónicos | 13 |
| 8. Mora y notificaciones | 17 |
| 9. Financiación y convenios | 6 |
| 10. Técnica, reclamos y obras | 38 |
| 11. Redes (GIS) | 12 |
| 12. Telefonía e internet | 39 |
| 13. Ventas de productos y presupuestos | 13 |
| 14. Compras y proveedores | 34 |
| 15. Stock, bienes de uso y fabricación | 38 |
| 16. Tesorería y bancos | 23 |
| 17. Contabilidad | 24 |
| 18. Sueldos | 56 |
| 19. Planes de vivienda | 11 |
| 20. Ambulancias / salud | 5 |
| 21. Mesa de ayuda (tickets) | 14 |
| 22. Turnero | 7 |
| 23. Actividades y agenda | 10 |
| 24. Institucional (consejo, actas, INAES) | 7 |
| 25. Informes y tablero | 12 |
| 26. Web / CoopOnline / APIs | 8 |
| 27. Usuarios, seguridad y auditoría | 20 |
| 28. Configuración y motor de pantallas | 31 |
| 29. Sistema (general) | 10 |
| 30. Maestros generales (geografía, documentos) | 15 |
| 31. Comunicaciones (mail, SMS, WhatsApp) | 18 |

## 1. Socios, cuentas y servicios

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `ADHSOC` | Adherentes de un servicio (familiares, beneficiarios de sepelio/salud) con altas y bajas. | COD_ADH | COD_SOC, COD_SUM, COD_SER, COD_PER, COD_VIN, TITULAR, FEC_ALT, FEC_BAJ, FEC_IMP, MAR_IMP, RECUPERA, COD_TAD … (+6) |
| `BENSOC` | Beneficios asignados a un servicio del socio (ej. tarifa social), con vigencia. | COD_BEN | COD_SOC, COD_SUM, COD_SER, COD_PER, COD_VIN, FEC_ALT, FEC_BAJ, COD_CSE, OBSERVA, ACTIVO, ID_SERSOC |
| `CAPITAL` | Cuotas de capital social facturadas a cada socio. | COD_CAP | COD_SOC, COD_SUM, COD_PRO, COD_SER, FECHA, FACTURADO, COMPVEN, EMISION, VTO1, FEC_REG, USU_REG, ID_FAC … (+5) |
| `CAPITAL_RES` | Resumen de capital social suscripto, vendido y pagado. | COD_CAPRES | COD_SUM, COD_SOC, COD_SER, FECHA, SUSCRIPTO, VENDIDO, COD_COM, SUC_COM, NUM_COM, COD_R, SUC_R, NUM_R … (+9) |
| `NOTA_SUM` | Notas/observaciones de una cuenta, con bloqueo y mensaje en caja. | COD_NOT | COD_SOC, COD_SUM, COD_PER, FECHA, TITULO, USU_REG, TEXTO, BLO_CAJ, MSG_CAJ, COD_SER, ID_SERSOC, COD_NOT_ORI |
| `NOT_ELIMINADAS_HST` | Historial de notas de cuenta eliminadas. | ID_NOT_ELI | COD_NOT, COD_SOC, COD_SUM, COD_PER, FECHA, TITULO, USU_REG, TEXTO, BLO_CAJ, MSG_CAJ, COD_SER, ID_SERSOC … (+3) |
| `PERSONAS` | Personas físicas/jurídicas: documento, nombre, domicilio, contacto. | COD_PER | TIP_DNI, NUM_DNI, APELLIDOS, NOMBRES, SEXO, CIVIL, COD_CAL, NUMERO, PISO, DPTO, COD_BAR, COD_LOC … (+32) |
| `PERSONAS_EXTRAS` | Datos laborales extra de la persona. | COD_PER | LUGAR_TRABAJO, DOMI_TRABAJO, TEL_TRABAJO, FECHA_CONTROL, USUARIO_CONTROL |
| `PROPIEDA` | Datos de inmueble/catastro de la cuenta (domicilio, catastro). | COD_CTA | COD_SUM, COD_CNT, DOM_CAL, DOM_NUM, DOM_PIS, DOM_DPT, DOM_BAR, DOM_LOC, DOM_COD, PDOM_CAL, PDOM_NUM, PDOM_PIS … (+89) |
| `PTRAMITES` | Trámites iniciados por un socio/cuenta (vencimiento, presentación, acción). | TMT_SOC | COD_TMT, COD_SOC, COD_SUM, ID_SERSOC, FECHA, OBSERVA, FEC_REG, USU_REG, FECHA_VTO, PRESENTADO, COD_PROV, ID_AC_TRA … (+3) |
| `RUBCAPI` | Rubros de capital social con cuenta contable. | COD_RCC | COD_RUB, DES_RCC, COD_CTA |
| `SERSOC` | Servicio de una cuenta (energía, gas, etc.): categoría, alta/baja, medidor, última facturación. | ID_SERSOC | COD_SOC, COD_SUM, COD_SER, COD_CAT, CANTIDAD, FEC_ALTA, FEC_BAJA, ULT_FAC, OBSERVA, TRANSFER, FEC_REG, USUARIO … (+106) |
| `SERSOC_EXTRAS` | Datos extra del servicio (cuotas, unidades, generación distribuida). | ID_SERSOC | CNT_CUOTAS, CNT_UNIDADES, CNT_UNIDADES_FACTURADAS, CNT_UNIDADES_TOTALES, CNT_CUOTAS_PAGAS, PORC_INST_BASICAS, PORC_INST_REDES, GIS, ALTA_GENERA, POTENCIA_GENERA, COD_PLA, CNT_UNIDADES_ORIGINAL … (+3) |
| `SERSOC_HST` | Historial de cambios del servicio de la cuenta. | ID_SERSOC_HST | CLIENTE, COD_SOC, COD_SUM, COD_SER, COD_CAT, CANTIDAD, FEC_ALTA, FEC_BAJA, ULT_FAC, OBSERVA, TRANSFER, FEC_REG … (+109) |
| `SERSOC_PRODUCTOS` | Productos entregados en comodato con un servicio (equipos). | ID_SERPROD | ID_SERSOC, COD_PRO, COD_PTH, FECHA_ENTREGA, FECHA_DEVOLUCION, FECHA_DEVUELTO, OBSERVA, COD_DPS, PRECIO |
| `SOCIOS` | Titulares/socios: alta, baja, CUIT, persona, número de socio, acta. | COD_SOC | ALTA, CUIT, IBRUTOS, COD_PER, COD_GAR, ACCIONES, BAJA, CAUSA, ACTIVO, CAU_BAJA, ACTA, JURIDICO … (+17) |
| `SUMSOC` | Cuentas/suministros: domicilio de servicio, situación IVA, zona/sector/recorrido de facturación. | COD_SUM | COD_SOC, NUM_SUM, COD_SIT, COD_CAL, NUMERO, PISO, DPTO, COD_BAR, COD_LOC, COD_POS, CLIENTE, COD_GRU … (+59) |
| `SUMSOC_EXTRAS` | Datos extra de la cuenta (mail/teléfono web, débito Pagos360). | COD_SUM | CORREO_WEB, TELE_WEB, DEBITO_360_ID, DEBITO_360_ESTADO, NROFICHA, EXCLUIR_REDONDEO |
| `SUMSOC_HST` | Historial de cambios de la cuenta. | ID_SUMSOC_HST | COD_SOC, COD_SIT, COD_CAL, NUMERO, PISO, DPTO, COD_BAR, COD_LOC, COD_POS, CLIENTE, COD_GRU, NOF_SUM … (+61) |
| `TRAMITES` | Tipos de trámite (días de vencimiento, plantilla). | COD_TMT | DES_TMT, DIAS_VENCE, TIPO_TMT, TRAMITE_DEFAULT, COD_PLA |
| `TRAMITES_ACCIONES` | Acciones automáticas de trámites. | ID_AC_TRA | TIPO, DES_ACCION, SCRIPT_ACCION, ACCIONES_CTRL, ACCION_ALTA, ACCION_VTO |
| `TRANSFER` | Transferencias de servicios entre cuentas/titulares. | ID_TRANS | TIPO_TRA, ORIGEN, DESTINO, SERVICIO, FECHA, OBSERVAC, USU_REG, FEC_REG, ID_TRANS_CUENTA |
| `VIAINGTE` | Vías de ingreso de trámites (validar celular/mail). | COD_VIA | DES_VIA, VALIDAR_CELULAR, VALIDAR_MAIL |
| `VINCULOS` | Tipos de vínculo (titular, cónyuge, hijo). | COD_VIN | DES_VIN, TIPO_VIN |

## 2. Servicios, categorías y tarifas

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `ALTASEAU` | Configuración de altas automáticas de servicios (servicio, categoría, localidad, zona, medidor). | ID_AS | DES_AS, TIPO_AS, COD_SER, COD_CAT, COD_LOC, ZONA, TIT_SOC, COD_SAS, COD_CAS, COD_REF, COD_CLS, COD_ACT … (+12) |
| `ARTEFACTO` | Catálogo de artefactos (electrodomésticos, artefactos de gas) declarables. | COD_ART | DES_ART, ES_OBSERVA |
| `ARTEFSUMS` | Artefactos declarados en un servicio (cantidad, marca, serie, año). | IDG_ART | COD_ART, CAN_ART, MAR_ART, USU_ART, OBS_ART, ID_SERSOC, SN_ART, MD_ART, FEC_ART, FEC_REG, ESTADO, OBSERVA … (+2) |
| `CARGOS_ADICIONALES` | Cargos adicionales con fórmulas (filtro, cantidad, importe) por servicio. | COD_CAR | DES_CAR, ORDEN, FORMULA_FIL, FORMULA_CAN, FORMULA_BI, FORMULA_IMP, DESDE, HASTA, TIPO, SUMA, AFECTACION, COD_PROD … (+13) |
| `CATE_SER` | Categorías tarifarias por servicio: IVA, mínimos, tramas, impuestos asociados. | COD_CATSER | COD_SER, COD_CAT, DES_CAT, IVA_GRAL, IVA_DIF1, IVA_DIF2, IVA_EXE, IMP_MINM, IMP_CMINM, IMP_MINT, IMP_CMINT, TRAMA … (+84) |
| `CATE_SER_COEFICIENTES` | Coeficientes por categoría y fecha (ajustes tarifarios). | COD_COEF | FEC_COEF, COD_CATSER, COEFICIENTE, COEFICIENTE2, COEFICIENTE3, COEFICIENTE4 |
| `CATE_SER_EXTRAS` | Datos extra de categorías (Mikrotik, generación, viviendas). | COD_CATSER | PERFIL_MIKROTIK, GENERADOR, VIV_MIN_EVENTUAL, VIV_MIN_DESPUES_ADJ, VIV_MIN_ANTES_ENTREGA, VIV_MIN_DESPUES_ENTREGA, VIV_MAX_ANUAL_ANTES_ENTREGA, VIV_FECHA_APORTE_TEORICO, PROP_CAMBIO_CAT, ID_SE, CODIGO_TARIFA, TIPO_PRESENTACION_ARBA … (+15) |
| `CATTARIF` | Escalones/precios de la tarifa vigente por categoría: precio unitario, diurno/nocturno, rangos de consumo. | COD_CTT | COD_CAT, COD_TAR, DES_CON, COD_SER, XUNID, CADHER, CAN_ADH, PRE_UNI, PRE_DIU, PRE_NOC, CON_MIN, CON_MAX … (+31) |
| `CATTMC` | Variante de precios por cuadro tarifario y categoría (tabla de trabajo de cuadros). | COD_TMC | COD_CUA, COD_CAT, COD_TAR, DES_CAT, COD_SER, XUNID, CADHER, CAN_ADH, PRE_UNI, PRE_DIU, PRE_NOC, CON_MIN … (+13) |
| `CLASESER` | Clases de servicio (ej. tasa hospital, tipo de suministro) con valores asociados. | COD_CLS | DES_CLS, COD_SER, VALOR1, VALOR2, OBS_CLS |
| `CONCESIO` | Concesiones. | COD_CESI | NOM_CESI |
| `CONEXION` | Conceptos a facturar al conectar un servicio (cargo de conexión por categoría/localidad). | COD_CONE | CANTIDAD, COD_CAT, COD_CATSER, COD_CLS, COD_CON, COD_LOC, COD_PRO, COD_PROP, COD_REF, COD_SER, COD_TRAN, DESACTIVAR … (+19) |
| `CONE_BONIF` | Bonificaciones de conexión por cuenta y servicio. | ID_CONE_BONIF | COD_SUM, COD_SER, COD_TRAN, COD_PRO, COD_CAT, CANT_BONIFICADAS |
| `CON_TASAS` | Conceptos y tasas aplicadas. | ID_CONT | DES_CONT, TASA, COLUMNA, COD_CON |
| `CORREGAS` | Factores de corrección de gas por período, servicio y categoría. | COD_COR | PERIODO, COD_SER, COD_CAT, FACTOR |
| `CUADRI` | Catálogo de cuadros (descripción). | COD_CUA | DES_CUA |
| `CUADROS` | Cuadros tarifarios con vigencia desde/hasta; cabecera de los históricos HIS_*. | COD_CUA | FEC_DESDE, FEC_HASTA, OBSERVA, COD_USER |
| `DESCPOS` | Descuentos por servicio y categoría con prioridad. | COD_DES | DES_DES, COD_SER, COD_CAT, TIP_DES, IMP_DES, PRIORIDAD |
| `ESTASER` | Estados de un servicio (conectado, cortado, baja) y si implica desconexión. | COD_EST | COD_SER, DES_EST, DESCONEC, PRINCIPAL |
| `ESTINM` | Estados de inmueble. | COD_EST | DES_EST, DES_RED |
| `FACTOR_CAL` | Factor de corrección por período y categoría (presión, temperatura; gas). | COD_FAC | PERIODO, FACTOR, COD_SER, COD_CATSER, PRESION, TEMPERATURA |
| `FACT_EPEC` | Montos facturados por EPEC (proveedor de energía) por cuenta y período. | COD_FACEPEC | MONTO, COD_SUM, FECHA_DESDE, FECHA_HASTA, PRE_TRIFASICO, PRE_MONOFASICO |
| `GRP_CAT` | Grupos de categorías (con código ENARGAS). | COD_GRU | DES_GRU, COD_ENGAS |
| `HIS_ARTEFSUMS` | Historial de artefactos declarados. | ID_HIS_ARTEFSUMS | IDG_ART, COD_ART, CAN_ART, MAR_ART, USU_ART, OBS_ART, ID_SERSOC, SN_ART, MD_ART, FEC_ART, FEC_REG, ESTADO … (+4) |
| `HIS_CARGOS_ADICIONALES` | Cargos adicionales vigentes en cada cuadro tarifario. | COD_HISCAR | COD_CAR, DES_CAR, ORDEN, FORMULA_FIL, FORMULA_CAN, FORMULA_IMP, DESDE, HASTA, TIPO, SUMA, AFECTACION, COD_PROD … (+15) |
| `HIS_CATE_SER` | Categorías tarifarias vigentes en cada cuadro. | COD_HISCATESER | COD_SER, COD_CAT, DES_CAT, IVA_GRAL, IVA_DIF1, IVA_DIF2, IVA_EXE, IMP_MINM, IMP_CMINM, IMP_MINT, IMP_CMINT, TRAMA … (+85) |
| `HIS_CATE_SER_EXTRAS` | Datos extra de categorías por cuadro. | COD_HISCATEX | COD_CATSER, PERFIL_MIKROTIK, GENERADOR, VIV_MIN_EVENTUAL, VIV_MIN_DESPUES_ADJ, VIV_MIN_ANTES_ENTREGA, VIV_MIN_DESPUES_ENTREGA, VIV_MAX_ANUAL_ANTES_ENTREGA, VIV_FECHA_APORTE_TEORICO, PROP_CAMBIO_CAT, ID_SE, CODIGO_TARIFA … (+12) |
| `HIS_CATTARIF` | Precios/escalones de tarifa vigentes en cada cuadro tarifario. | COD_HISCTT | COD_CAT, COD_TAR, DES_CON, COD_SER, XUNID, CADHER, CAN_ADH, PRE_UNI, PRE_DIU, PRE_NOC, CON_MIN, CON_MAX … (+34) |
| `HIS_IMPUESTO` | Impuestos y tasas (porcentaje/importe) vigentes en cada cuadro. | COD_HISIMP | COD_IMP, DES_IMP, IMP_POR, IMP_IMP, COD_RUB, ORD_FAC1, ORD_FAC2, ORIGEN, COD_CUA, APLICA_UNA_VEZ, APLICA_VENTAPRODUCTOS, GRUPO_CERO … (+2) |
| `HIS_PROD_SER` | Productos/conceptos y precios vigentes en cada cuadro. | COD_HISPRO | COD_PRO, COD_RUB, DES_PRO, DES_FOR, UNI_MED, STO_MIN, STO_MAX, STO_ACT, ALM_FIS, PRE_CSI, PRE_VSI, IVA_EXE … (+72) |
| `HIS_SERVICIO` | Configuración de servicios vigente en cada cuadro. | COD_HISSER | COD_SER, DES_SER, PRE_C_AD, ADH_PRE, ADHER, BENEF, CANTIDAD, MENORES, MAYORES, DISCAPA, JUBILAD, MENSUAL … (+135) |
| `HIS_SERVICIO_EXTRAS` | Datos extra de servicios por cuadro. | COD_HSTSEREX | COD_SER, COD_EST_ALTA, COD_EST_BAJA, COD_EST_RECONEXION, COD_EST_CAMBIOMEDIDOR, COD_EST_TRANSFERENCIA, CARENCIA, TIP_CELULAR, COD_TRAN_TRANSFERENCIA, CONDICION_TRANSFERENCIA, DIVISION_CONSUMO, COD_TRAN_ALTA … (+8) |
| `HIS_TAR_ADHE` | Tarifas de adherentes vigentes en cada cuadro. | COD_HISTAD | COD_CUA, COD_TAD, COD_SER, COD_CAT, DES_TAD, PRE_TAD, EDA_INI, EDA_FIN, COD_VIN, COD_OCU, COBRAEXCEDENTE |
| `IMPUESTO` | Impuestos y tasas a facturar: porcentaje o importe fijo, orden en factura, organismo. | COD_IMP | DES_IMP, IMP_POR, IMP_IMP, COD_RUB, ORD_FAC1, ORD_FAC2, ORIGEN, COD_ENGAS, ORD_FAC3, ID_CLASIFICACION, APLICA_UNA_VEZ, APLICA_VENTAPRODUCTOS … (+2) |
| `IMPUESTOS_X_CAT` | Impuestos que aplican a cada servicio (productos y/o servicios). | ID_IMP_X_CAT | COD_SER, COD_IMP, PRODUCTOS, SERVICIOS |
| `PRCAGAS` | Cálculo de consumo de gas prorrateado (días, umbral, PCS). | COD_PRC | COD_SUM, COD_SER, COD_CAT, PERIODO, COD_COM, SUC_COM, NUM_COM, CONSUMO, DIAS, COD_COMB, SUC_COMB, NUM_COMB … (+30) |
| `PROD_SER` | Catálogo de productos y conceptos facturables: precios, IVA, stock, rubro. | COD_PRO | COD_RUB, DES_PRO, DES_FOR, UNI_MED, STO_MIN, STO_MAX, STO_ACT, ALM_FIS, PRE_CSI, PRE_VSI, IVA_EXE, IVA_DIF1 … (+77) |
| `PROD_SER_REC_DES` | Recargos/descuentos automáticos por producto según condiciones. | COD_REC_DES | COD_PROPIEITEM, VALOR, COD_PRO, TIP_REC_DES, REC_DES, COD_PRO_DES, TIPO_TITULAR, COMPROBANTES, CATIDAD_LIMITE, DIAS_DEUDA, FORMA_PAGO |
| `PROPIESER` | Propiedades de servicio (tensión, mínimos, cargo fijo). | COD_PROP | DES_PROP, NOM_PROP, COD_SER, IMP_MINM, IMP_CMINM, COD_CF, IMP_CF, CAN_CF, COD_CM, TENSION_OCEBA |
| `RECARGOS` | Recargos/descuentos por servicio, categoría, ocupación o zona. | COD_DES | DES_DES, PRO_SER, IMP_POR, IMP_DES, COD_SER, COD_PYS, COD_CAT, COD_OCU, COD_PRO, MIN_CON, MAX_CON, CON_DES … (+6) |
| `REFEREN` | Referencias de ubicación. | COD_REF | DES_REF |
| `SERVICIO` | Servicios que presta la cooperativa: medido o no, IVA, adherentes, parámetros. | COD_SER | DES_SER, PRE_C_AD, ADH_PRE, ADHER, BENEF, CANTIDAD, MENORES, MAYORES, DISCAPA, JUBILAD, MENSUAL, TECNICA … (+137) |
| `SERVICIO_EXTRAS` | Estados por defecto del servicio (alta, baja, reconexión, transferencia). | COD_SER | COD_EST_ALTA, COD_EST_BAJA, COD_EST_RECONEXION, COD_EST_CAMBIOMEDIDOR, COD_EST_TRANSFERENCIA, CARENCIA, TIP_CELULAR, COD_TRAN_TRANSFERENCIA, CONDICION_TRANSFERENCIA, DIVISION_CONSUMO, COD_TRAN_ALTA, COD_CON_DESCONECTADO … (+8) |
| `TAR_ADHE` | Tarifas de adherentes por servicio/categoría y edad. | COD_TAD | COD_SER, COD_CAT, DES_TAD, PRE_TAD, EDA_INI, EDA_FIN, COD_VIN, COD_OCU, COBRAEXCEDENTE |
| `TEMPMODIFBONIF` | Temporal de recálculo de bonificaciones por consumo. | ID | CONS_BONIF_NUEVA, CATEGORIA_PASADA, CANTIDAD_TOTAL_CONSUMOS, ID_SERSOC, COD_CAT, TIPO, PERIODO_CONSUMO, COD_CONS, COD_SUM, DES_CAT_PASADA, DES_CAT |
| `TIPOLOTE` | Tipos de lote. | COD_TIP | DES_TIP, DES_RED |
| `TIP_SERVI` | Tipos de servicio. | COD_TSER | DES_TSER |
| `USOINM` | Usos de inmueble. | COD_USO | DES_USO, DES_RED |

## 3. Medición y consumos

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `AUDITORIA_TELEMEDICION` | Log de llamadas a APIs de telemedición (request/response por medidor). | ID | IDAPI, REQUEST, SIS_TEL, ID_SERSOC, COD_SOL, FEC_REG, NUM_MED, RESPONSE |
| `CERESTAD` | Certificados/estados de lectura. | COD_CER | DES_CER |
| `CONNRUTA` | Rutas de lectura: zonas, sectores, recorridos y orden. | RUTA | DES_RUTA, COD_SER1, COD_SER2, COD_SER3, COD_SER4, REC_CAL, ZONAS, ZONA, SECTOR, ZON_DES, SEC_DES, REC_DES … (+17) |
| `CONNZONA` | Zonas que componen cada ruta. | ID_ZONA | RUTA, ZONA |
| `CONSUMOP` | Consumos propios de la cooperativa (lecturas de medidores internos). | COD_CONSP | COD_SER, FEC_ANT, EST_ANT, FEC_ACT, EST_ACT, CONSUMO, PERIODO, COD_TAR, FEC_REG, HOR_REG, USU_REG, TIP_ENE |
| `CONS_SER` | Lecturas y consumos por servicio y período (estado anterior/actual, consumo, facturado). | COD_CONS | COD_COM, SUC_COM, NUM_COM, COD_SER, COD_SUM, COD_MED, COD_CAT, FEC_ANT, EST_ANT, FEC_ACT, EST_ACT, CONSUMO … (+27) |
| `CONS_SER_TESTIGO` | Lecturas de medidores testigo (control), con GPS y observaciones. | ID_CONS | COD_TES, COD_SER, FEC_ANT, EST_ANT, FEC_ACT, EST_ACT, CONSUMO, COD_CON, TIP_ENE, FEC_REG, USU_REG, COD_RES … (+10) |
| `DISPOSI` | Dispositivos/medidores: número, marca, modelo, clase, prepago, estado. | COD_MED | COD_SER, COD_PRO, NUM_MED, MAT_MED, COD_TIP, CLA_MED, MAR_MED, MOD_MED, ANO_MED, MONOTRI, MULTITA, PREPAGO … (+14) |
| `DST_CONSUMO` | Distribución de consumo entre servicios (porcentaje, tope). | ID_DST | SERSOC_ORI, SERSOC_DES, PORCENTAJE, COMBINADA, IGUALADA, TOPE |
| `HISWORK` | Histórico de la planilla de trabajo de lecturas (rutas, estados, confirmaciones). | ID_HISWORK | EST_ACT, FEC_ACT, CONSUMO, EST_ANT, FEC_ANT, CONSANT, RUTA, DIG_MED, INDICADO, NUM_MED, COD_CAT, FAC_MED … (+36) |
| `HIS_MEDSOC` | Historial de cambios del medidor de un servicio. | COD_HISMEDSOC | ID_MEDSOC, INDICADO, COD_CON, FEC_LEC, EST_LEC, CON_TOT, ID_SERSOC, CONTRATADO, TIP_ENE, CON_ORIGINAL, FEC_ACTUALIZA, FEC_ACTUALIZA_ORIGINAL … (+2) |
| `IMP_WORK` | Planilla de trabajo de lecturas a importar (desde lectores/colectoras). | ID_WORK | COD_SUM, COD_SER, EST_ACT, FEC_ACT, CONSUMO, EST_ANT, FEC_ANT, CONSANT, RUTA, DIG_MED, INDICADO, NUM_MED … (+37) |
| `LEC_MEDTEL` | Configuración de lecturas por sistema de telemedición y tipo de medidor. | ID_LECMED | SIS_TEL, TIP_MED, COD_CATSER, TIP_ENE, COD_CON, COD_LEC, COD_LEC2, GENERADOR, COD_LEC3 |
| `MARMED` | Marcas de medidores por servicio. | COD_MAR | DES_MAR, COD_SER |
| `MEDIDORP` | Medidores propios de la cooperativa. | ID_MEDP | COD_SER, DIG_MED, FAC_MED, INDICADO, COD_CON, FEC_LEC, EST_LEC, CON_TOT, TIP_ENE |
| `MEDSOC` | Medidor instalado en un servicio: última lectura, consumo, factor multiplicador. | ID_MEDSOC | INDICADO, COD_CON, FEC_LEC, EST_LEC, CON_TOT, ID_SERSOC, CONTRATADO, TIP_ENE, CON_ORIGINAL, FEC_ACTUALIZA, FEC_ACTUALIZA_ORIGINAL, FAC_MED |
| `MED_TESTIGO` | Medidores testigo (control). | COD_TES | ID_SERSOC, DESCRIPCION, NO_INCLUIR |
| `OBSESTAD` | Observaciones de lectura (ej. medidor roto); pueden generar OT o marcar estimado. | COD_OBS | DES_OBS, TEXTO, COD_SER, GENERA_OT, COD_TRAN, MARCAR_ESTIMADO, FOTO |
| `OBSMED` | Observaciones de medidor. | COD_OBS | DES_OBS, TIP_OBS |
| `RESESTAD` | Resultados de lectura. | COD_RSU | DES_RSU, CONFIRMA |
| `SERSOC_DEMANDASXPERIODO` | Demanda de potencia registrada por servicio y período. | ID_SERDEM | ID_SERSOC, DEMANDA, TIP_MED, PERIODO |
| `TELEMEDICION` | Sistemas de telemedición configurados (URL, credenciales). | ID_TEL | DES_TEL, USER_TEL, PASS_TEL, URL_TEL, PATH, SISTEMA, DATO_EXTRA1, DATO_EXTRA2 |
| `TELEMED_COMM` | Comandos enviados a medidores (corte/reconexión remota) y respuesta. | COD_TEC | FECHA, OPERACION, COMANDO, RESPUESTA, ID_SERSOC, SUMINISTRO, OBSERVACION |
| `TIPMED` | Tipos de medidor (prepago, telemedido, máximos). | COD_TIP | DES_TIP, COD_SER, CONEX_SIST, COD_MAR, COD_PRO, SIS_TEL, TIPO_SUM, PREPAGO, COD_MED, DISPONIBLE, NOINDICADO, REDONDEO_PREPAGA … (+2) |

## 4. Facturación

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `ANTICIPOS` | Anticipos o pagos a cuenta de una cuenta (importe, saldo, aplicación). | ID_FAC | TIP_ANT, COD_SUM, IMP_ANT, SDO_ANT, FECHA, COD_PRO, TIPO, OBSERVACION, PORC_APLIC |
| `ANTIFACTU` | Aplicación de anticipos a facturas. | ID_ANTI | COD_SUM, TIP_ANT, IMP_ANT, FECFCT, VTOFCT, ID_FAC, ID_FAC_ANT |
| `ANUFAC` | Copia de cabecera de facturas anuladas (4 vencimientos, IVA, totales). | ID_FAC | COD_COM, SUC_COM, NUM_COM, TIPO, FECHA, COD_SOC, COD_PER, COD_SUM, COD_SIT, VTO1, TOTAL1, VTO2 … (+54) |
| `ANUITEMSFAC` | Renglones de facturas anuladas. | ID_ITEM | TIPO, COD_RUB, COD_PRO, CAN_ITE, PRE_VSI, ID_CUOTA, POR_IMP, COD_SER, COD_CAT, PERIODO, AGRUPAR, COD_MON … (+24) |
| `ANUITEMSFAC_EXTRAS` | Datos extra (coseno fi) de renglones anulados. | ID_ITEM | COSENO_FI, NCOS_FI, METODO_FI, TOPE_COSFI |
| `CAUBLOQ` | Causas de bloqueo de comprobantes. | COD_CAU | DES_CAU |
| `CLASIFICACION_ITEMS` | Clasificación de ítems de impuestos con coeficiente. | ID_CLASIFICACION | DES_CLASIFICACION, COEFICIENTE_MO |
| `COMPROB` | Tipos de comprobante: descripción, débito/crédito, numeración, leyendas, código ARCA. | COD_COM | DES_COM, RES_COM, DEB_CRE, ULT_NUM, ULT_SUC, IMPR_SYS, COPIAS, IMP_LEY, LEY_COP1, LEY_COP2, LEY_COP3, LEY_COP4 … (+25) |
| `COMPROBANTES_ADM` | Comprobantes administrativos asociados a una factura y período. | ID_COMP | ID_FAC, COD_SER, PERIODO, FECHA, USU_REG |
| `CONJUNTO` | Conjuntos de facturación (agrupan cuentas para facturar juntas). | COD_CNJ | DES_CNJ |
| `CREDITOS_NOAUTOMATICOS` | Notas de crédito marcadas como no automáticas. | ID_FAC | FECHA, USU_REG |
| `FACTMES` | Corridas de facturación masiva: período, filtros (zona, sector, conjunto), usuario. | ID_REC | INICIO, FIN, COD_USER, TIPFAC_GRAL, FACTURARA, FILTRACUENTAS, FEC_ALTAS, ZONA, SECTOR, CONJUNTO, EMP_POSTAL, LOC_POSTAL … (+19) |
| `FACTMES_COMP` | Rango de comprobantes generados por cada corrida masiva. | ID_CFAC | ID_REC, COD_COM, SUC_COM, NUM_COM_DESDE, NUM_COM_HASTA |
| `FACTMES_CTAS` | Cuentas incluidas en cada corrida masiva. | ID_CFAC | ID_REC, COD_SUM |
| `FACTURAS` | Cabecera de comprobantes de servicios: tipo, número, cuenta, 4 vencimientos con totales, IVA, estado. | ID_FAC | COD_COM, SUC_COM, NUM_COM, TIPO, FECHA, COD_SOC, COD_PER, COD_SUM, COD_SIT, VTO1, TOTAL1, VTO2 … (+35) |
| `FACTURAS_EXTRAS` | Moneda y cotización de la factura. | ID_FAC | COD_MON, COT_MON |
| `FAC_EXTRAS` | Datos extra de factura: códigos de barra, código Link, deuda, distrito. | ID_FAC | COD_SUM, ID_SERSOC, TOTAL, DISTRITO, CUENTA, SUBCUENTA, DV, COD_SERV, COD_FACT, CONTROL, CUIT, PERIODO … (+7) |
| `FAC_EXTRAS_ITEMS` | Ítems extra impresos en factura. | COD_ITEM | ID_FAC, DESCRIPCION, IMPORTE |
| `GRUPOS_FACTURA` | Grupos de factura: qué servicios salen juntos en un comprobante. | COD_GF | DES_GF, COD_TPFC, FORZAR_ND |
| `GRUPOS_GRAFICO` | Grupos para el gráfico de consumo impreso en la factura. | COD_GT | COD_GRUPO, DES_GRUPO |
| `HISBLOQ` | Historial de bloqueos de facturas (causa, usuario, fecha). | ID_HSTB | ID_FAC, COD_CAU, FEC_BLO, USU_BLO |
| `ITEMSFAC` | Renglones de factura: producto/concepto, cantidad, precio, IVA, servicio, período. | ID_ITEM | TIPO, COD_RUB, COD_PRO, CAN_ITE, PRE_VSI, ID_CUOTA, POR_IMP, COD_SER, COD_CAT, PERIODO, AGRUPAR, COD_MON … (+24) |
| `ITEMSFAC_EXTRAS` | Datos extra de renglones (coseno fi, penalización, cuadro aplicado). | ID_ITEM | COSENO_FI, NCOS_FI, METODO_FI, TOPE_COSFI, COD_CUA |
| `ITEMSORD` | Orden de impresión de ítems en factura. | COD_ORD | DES_ORD, DES_PIE, ORDEN |
| `OB_FACT` | Observación libre de una factura. | ID_FAC | OBSERVACION |
| `PARSERFA` | Parámetros de servicio por tipo de facturación. | COD_PAR | COD_TIP, COD_SER, COD_TPFC |
| `POSTALES` | Empresas de distribución postal de facturas. | COD_EPO | DES_EPO, IMP_EPO, PRO_EPO |
| `PREPAGA` | Facturas prepagas de energía y comprobantes de venta/crédito vinculados. | ID_FAC | COD_COM, SUC_COM, NUM_COM, COD_COMV1, SUC_COMV1, NUM_COMV1, COD_COMV2, SUC_COMV2, NUM_COMV2, COD_COMCR, SUC_COMCR, NUM_COMCR … (+12) |
| `RELACION_COMP` | Relación entre comprobantes (NC/ND sobre factura, anulaciones). | ID_RC | COD_GEN, COD_ORI, ID_GEN, ID_ORI, FEC_RC, USU_RC, ANULACION, INFORMAR_CUIT, NOMOSTRAR, BONIFICA_FACTURA |
| `SFACTME` | Servicios y período incluidos en cada corrida de facturación masiva. | COD_SFA | ID_REC, COD_SER, MES_PER, AÑO_PER, FTOMA1, FTOMA2 |
| `SUMNOFAC` | Cuentas marcadas para no facturar. | COD_SNF | COD_SUM, COD_SOC, COD_PER, USU_NOF, FEC_NOF, USU_FAC, FEC_FAC, ACTIVO |
| `TALONFAC` | Talones de pago de una factura (cuota, 4 vencimientos, importes, saldo). | COD_TAL | ID_FAC, NUMERO, USUARIO, FEC_ALTA, CUOTA, VTO1, IMPORTE1, VTO2, IMPORTE2, VTO3, IMPORTE3, VTO4 … (+2) |
| `TALONFAC_HST` | Historial de modificaciones de talones. | COD_TAL | ID_FAC, NUMERO, USUARIO, FEC_ALTA, CUOTA, VTO1, IMPORTE1, VTO2, IMPORTE2, VTO3, IMPORTE3, VTO4 … (+4) |
| `TIPO_FAC` | Tipos de facturación (mensual por servicio): reporte, parámetros, última facturación. | COD_TPFC | COD_TIP, DES_TIP, TEX_TIP, COD_SER, PARAMETROS, REPORTE, RET_PRE, COD_CTA, FECD_ULTFAC, FECH_ULTFAC, FECD_ESTADO, FECH_ESTADO … (+44) |
| `TIP_COMP` | Tipos de comprobante (agrupación). | COD_TIPC | DES_TIPC |

## 5. Fiscal / ARCA / impuestos

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `ACTAFIP` | Actividades económicas ARCA asociadas a cada servicio. | COD_ACT | DES_ACT, COD_SER |
| `ALI_IBR` | Alícuotas de Ingresos Brutos. | COD_ALI | DES_ALI, RENDIR, COD_IMP, GRUPO_IMP |
| `ALI_IBR_CF` | Porcentaje de IIBB por alícuota y situación fiscal del cliente. | COD_ACF | COD_ALI, COD_SIT, POR_IBR, COD_SIB |
| `ALI_IBR_COMP` | Alícuotas de IIBB aplicables por tipo de comprobante. | COD_ACM | COD_ALI, COD_COM, COD_SIB, CALCULO |
| `ALI_IVA` | Alícuotas de IVA con sus cuentas contables de compras y ventas. | COD_ALI | DES_ALI, CTA_COMPRAS, CTA_VENTAS, CTA_VENTAS_PER |
| `ALI_IVA_CF` | Porcentajes de IVA y percepción por alícuota y condición fiscal. | COD_ACF | COD_ALI, COD_SIT, POR_IVA, POR_IVA2, PER_IVA |
| `CAT_RETG` | Escala de retenciones de Ganancias por tramo. | ID_RET | COD_RET, IMP_MIN, IMP_MAX, RET_PES, RET_POR, EXCEDENTE, COD_TIPO |
| `CESPAFIP` | Códigos CAEA/CESP otorgados por ARCA por punto de venta y período. | ID_CESP | DES_CESP, FEC_INI, FEC_FIN, CESP, VTO_CESP, PTO_VTA, FEC_REG, USU_REG, CAEA |
| `COMPPOS` | Numeración por punto de venta y comprobante: CAE/CAI/CAEA, último número. | COD_CPO | COD_POS, COD_COM, CAE, CAI, CAI_ACTUAL, VTO_CAI, ULT_NUM, SUC_COM, CAEA |
| `CVPIIBB` | Código de Validación Provincial (CVP) de IIBB por punto de venta y período. | ID_CVP | FEC_INI, FEC_FIN, LEYENDA, CVP, PTO_VTA, FEC_REG, USU_REG, COD_COM |
| `ELECTRONICA_FC` | Facturas electrónicas enviadas a ARCA: CAE, vencimiento, errores. | ID_FAC | COD_COM, SUC_COM, NUM_COM, FECHA, IMPORTE, CAE, VTOCAE, ERRORCAE, CLIENTE_TIPDNI, CLIENTE_DNI, TIP_PRODSER, SERVICIO_DESDE … (+15) |
| `ELECTRONICA_IVA` | Detalle de IVA informado a ARCA por factura. | ID_IVA | ID_FAC, BASEIMP, IMPORTE, TIPOIVA |
| `ELECTRONICA_RELCOMP` | Comprobantes asociados informados a ARCA (ej. NC sobre factura). | COD_RELCOMP | COD_COM, SUC_COM, NUM_COM, CUIT, FECHA, ID_FAC |
| `ELECTRONICA_TRIB` | Otros tributos informados a ARCA por factura. | ID_TRIB | ID_FAC, BASEIMP, ALICUOTA, TIPO_TRIB, DES_TRIB, IMPORTE |
| `EMPAFIP` | Padrón de empresas/CUIT con situación ARCA. | CUIT | RAZ_SOC, COD_SIT, FECHA, COD_AFIP |
| `ENGAS_CANTMESES` | Cantidad por mes para informes a ENARGAS. | ID | COD_ENGAS, MES, CANTIDAD |
| `IIBB_LUA` | Padrón de IIBB (alícuotas por CUIT y régimen, con vigencia). | IDIBB | REGIMEN, FECHA_PUB, FECHA_DES, FECHA_HAS, COD_SUM, COD_SIB, CUIT, CUIT2, TIPOC, ALICUOTA, IBR |
| `IVAVTA` | Libro IVA Ventas: IVA por alícuota de cada comprobante. | ID_ITEM | ALI_IVA, TIP_IVA, IMP_IVA, IMP_NET, COD_CVC, COD_VENC, ID_FAC, COD_ALI, TIPO_INT |
| `PROD_SER_RET` | Retenciones por producto. | COD_PRODRET | COD_PRO, COD_TIPO |
| `PTOVENTA` | Puntos de venta. | COD_POS | SUC_COM, DES_POS, PAUSAR |
| `RETE_TIPO` | Tipos de retención con mínimos, porcentajes y bases. | COD_TIPO | COD_RET, TIP_RET, DES_RET, COD_REG, MIN_RET, MIN_IMP, RET_PES, RET_POR, RET_EXE, S_NETGRA, S_IMPUES, S_EXENTO … (+23) |
| `RETE_TIPO_BASE` | Bases de tipos de retención. | COD_TIP_RETE | TIP_RET, DES_TIP |
| `RETS_TIPO` | Tipos de retenciones sufridas con cuenta contable. | COD_RETE | DES_RETE, CTA_CONT |
| `RET_COM` | Retenciones practicadas a proveedores. | ID_RET_COM | COD_COM, SUC_COM, NUM_COM, COD_PROV, FECHA, COD_RET, FEC_INF, BASE_IMP, RETENCION, RET_PES, RET_POR, RET_EXE … (+17) |
| `SITIBR` | Situaciones frente a IIBB. | COD_SIT | DES_SIT, EXENTO, BASE |
| `SITIVA` | Condiciones de IVA (RI, CF, exento…) con comprobante por defecto y código ARCA. | COD_SIT | DES_SIT, IVARI, IVARNI, RES_SIT, EFIS_SIT, HFIS_SIT, COD_COM, AFIP_SIT, COM_DEF, CRE_DEF, DEB_DEF, COD_AFIP … (+12) |

## 6. Cobranza y caja

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `ANUIT_PAGSO` | Ítems de recibos de cobranza anulados (qué comprobantes cancelaban). | ID_ANUITR | ID_ANUREC, USU_ANU, FECHA_ANU, ID_ITR, COD_COM, SUC_COM, NUM_COM, PAG_CODCOM, PAG_SUCCOM, PAG_NUMCOM, SAL_ACT, ENTREGA … (+19) |
| `ANUPAG_SOC` | Recibos de cobranza anulados (cabecera). | ID_ANUREC | ID_ANUPLA, USU_ANU, FECHA_ANU, ID_REC, ID_PLA, COD_COM, SUC_COM, NUM_COM, FECHA, COD_SOC, COD_PER, COD_SUM … (+21) |
| `ANUPLAN_CAJ` | Movimientos de planilla de caja anulados. | ID_ANUPLA | USU_ANU, FECHA_ANU, ID_PLA, FECHA, NUM_CAJ, HORA, COD_OPER, COD_COM, SUC_COM, NUM_COM, ENT_EFE, ENT_CHE … (+18) |
| `CAJAS` | Cajas de cobranza por día: totales por medio de pago, apertura y cierre. | ID_CAJ | FECHA, NUM_CAJ, USUARIO, OBS_CAJ, TOT_EFE, TOT_CHE, TOT_RET, TOT_TAR, TOT_DIF, TOTAL, FEC_REG, USU_REG … (+4) |
| `CAJASJP` | Catálogo de cajas. | COD_CAJ | DES_CAJ |
| `CAJAS_QR` | Código QR asociado a cada caja (cobro por QR). | CAJA | QR, QR_ID |
| `COBRANZA_LOG` | Log de eventos de cobranza en caja. | COD_LOG | COD_AUD, FECHA, TIPO, CAJA, COD_SUM, VALOR, DESCRIPCION_ADICIONAL |
| `CUPONTAR` | Cupones de tarjeta cobrados en caja (presentación y acreditación). | ID_CUPON | ID_PLA, COD_CJ, SUC_CJ, NUM_CJ, FECHA, COD_SOC, COD_PER, COD_SUM, COD_TARJ, CUP_TARJ, AUT_TARJ, IMPORTE … (+12) |
| `DESCUENTO_CAJA` | Descuentos por pago en caja según día del mes y tipo de factura. | COD_DES | DIA_DESDE, DIA_HASTA, COD_TPFC, DESCUENTO, COD_PRO, SOLO_SOCIOS |
| `EFEC_OP` | Movimientos de efectivo en caja, en moneda local y extranjera. | ID_EFEC | ID_PLA, COD_CJ, SUC_CJ, NUM_CJ, FECHA, COD_SOC, COD_PER, COD_SUM, NUM_CAJ, TIP_MON, COT_PES, ENT_MON … (+6) |
| `ESQUEMAS_INFORMES_COBRANZAS` | Esquemas de informes de cobranzas (productos/servicios/impuestos a incluir). | ID_ESQUEMA | NOMBRE_ESQUEMA, LST_PRODUCTOS, LST_SERVICIO, LST_IMPUESTO, INFORME |
| `IT_PAGSO` | Ítems de recibos: qué comprobante/cuota cancela cada pago y saldo. | ID_ITR | COD_COM, SUC_COM, NUM_COM, PAG_CODCOM, PAG_SUCCOM, PAG_NUMCOM, SAL_ACT, ENTREGA, GEN_CAJ, NRO_CUO, DE_CUO, NETO_INIT … (+16) |
| `PAG_SOC` | Recibos de cobranza (cabecera: cuenta, total, caja, estado). | ID_REC | ID_PLA, COD_COM, SUC_COM, NUM_COM, FECHA, COD_SOC, COD_PER, COD_SUM, TOTAL, ESTADO, NETO_IN, IVARI_IN … (+17) |
| `PLAN_CAJ` | Planilla de caja: cada operación con entradas/salidas por medio de pago. | ID_PLA | FECHA, NUM_CAJ, HORA, COD_OPER, COD_COM, SUC_COM, NUM_COM, ENT_EFE, ENT_CHE, ENT_RET, ENT_TAR, SAL_EFE … (+19) |
| `RETENCIO` | Retenciones recibidas en cobranzas. | ID_RETEN | ID_PLA, COD_CJ, SUC_CJ, NUM_CJ, FECHA, COD_SOC, COD_PER, COD_SUM, TIP_RETE, NUM_RETE, FEC_RETE, IMPORTE … (+10) |
| `TALONFAC_PAGO` | Relación talón ↔ recibo de pago. | COD_TAL, ID_REC |  |
| `TARJETAS` | Tarjetas de crédito/débito aceptadas (comercio, presentación). | COD_TAR | COD_TARJ, NOM_TARJ, COD_PROV, COD_ARC, COMERCIO, PER_DEB, PRESEN, USO_CAJA, POR_CAJA, IMP_CAJA, COD_PRO |
| `TARJETAS_RECARGO` | Recargos por cuotas con tarjeta. | COD_TARJREC | COD_TARJ, DESCRIPCION, CUOTAS, RECARGO_TIPO, RECARGO_VALOR |
| `TIP_VAL` | Tipos de valores (medios de pago). | COD_TIP | DES_TIP, CTA_CONTA, DATO_MANUAL, VUELTO |
| `TRAN_OP` | Transferencias bancarias recibidas en caja. | ID_TRN | ID_PLA, FECHA, IMP_TRAN, NUM_CAJ, COD_BAN, FEC_TES, NUM_TES, FEC_DEP, NUM_DEP, ID_CHEQUE, NUM_TRAN, OBSERVAC … (+1) |
| `VALORES` | Cheques de terceros recibidos (banco, fecha, depósito). | INTERNO | ID_PLA, COD_CJ, SUC_CJ, NUM_CJ, FECHA, COD_SOC, COD_PER, COD_SUM, NUM_CHEQ, BAN_CHEQ, SUC_CHEQ, FEC_CHEQ … (+32) |

## 7. Entes recaudadores y pagos electrónicos

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `BANCOS` | Entes de cobranza/bancos externos: archivos de intercambio, comisiones, convenio. | COD_BAN | DES_BAN, COD_BANT, COD_ARC, COD_ARC2, ARC_CONFIG, IMPORTAR, FORMA_CAL, IMPO_CAL, IMPO_MIN, TRASLADAR, ID_CODBAR, IMPO_MAX … (+34) |
| `CANALES_PAGOS` | Canales de pago electrónico (APIs) con sus medios. | COD_CAN | API, DESCRIPCION, OBSERVA, ICONO, MEDIOS |
| `DEBITO_EXCLUSION` | Cuentas excluidas del débito automático por tipo de facturación. | ID | COD_SUM, COD_TPFC |
| `DEUDARED` | Cantidad de comprobantes de deuda publicados a la red (Link/Banelco) por cuenta. | COD_SUM | CANTIDAD |
| `DEUDARED_TIPO` | Redondeo de deuda publicada por cuenta y tipo de factura. | ID_RED | COD_SUM, REDONDEO, COD_TPFC |
| `FACTURAS_TERCEROS` | Facturas de terceros cobradas por la cooperativa (importe, comisión, rendición). | ID_FACTER | ID_FAC, COD_TER, COMPROBANTE, FECHA_VTO, IMPORTE, FEC_REG, USER_REG, FEC_RENDICION, IMP_COMISION, OBSERVACIONES, NRO_RESUMEN |
| `PAGOS360` | Solicitudes de pago en Pagos360 (link/código de barras, importes, vencimientos). | COD_PAG | ID_360, SISTEMA, IMPORTE1, IMPORTE2, VTO1, VTO2, NOMBRE, MAIL, CONCEPTO, URL_PAGO, URL_SUCCESS, URL_PENDING … (+24) |
| `PAGOS360_EXTRAS` | Metadata de solicitudes Pagos360. | COD_PAG | METADATA |
| `PAGOS360_ITEMS` | Comprobantes incluidos en cada solicitud Pagos360. | COD_ITEM | COD_PAG, ID_FAC, COD_COM, SUC_COM, NUM_COM, TOTAL1, TOTAL2, VTO1, VTO2, TALON, CUOTA, RECARGO_MORA … (+2) |
| `PAGOS360_PAGOS` | Pagos acreditados por Pagos360 (importe, comisión, canal). | ID_ITPAG | COD_PAG, ID_360, IMPORTE, NET_FEE, NET_AMOUNT, FEE_IVA, GROSS_FEE, FECHA_REG, FECHA_PAG, FECHA_REN, CHANNEL, COD_PAGSOC … (+5) |
| `RED_LINK` | Deuda publicada a Red Link (índice, período, concepto, identificador). | ID_LINK | INDICE, PERIODO, CONCEPTO, IDENTIFICADOR, COMPROBANTE, FEC_REG, USU_REG, ENTIDAD, MODELO |
| `SIRO_BASEDEUDA` | Envíos de base de deuda a SIRO y su resultado. | ID_BASE | Registros_correctos, Registros_erroneo, Registros_procesados, Confirma_automaticamente, Error_descripcion, Estado, Fecha_Envio, Fecha_proceso, Fecha_registro, Nro_transaccion, Total_primer_vto, Total_segundo_vto … (+3) |
| `TERCEROS` | Terceros por cuenta de quienes se cobra (municipio, otros) y cálculo de comisión. | COD_TER | DES_TER, COD_SUM, COD_BAR, NRO_TER, COD_COM, COD_PRO, FORMA_CAL, IMPO_CAL, IMPO_MIN, COD_TPFC, PARCIALES, VENCIDOS … (+5) |

## 8. Mora y notificaciones

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `CAUSAS` | Causas genéricas (de baja, de corte, etc.) por tipo. | COD_CAU | DES_CAU, TIPO |
| `CIRCUCTA` | Circulares/notificaciones enviadas a una cuenta. | COD_CIR | COD_SUM, FECHA, USUARIO |
| `CIRCULAR` | Modelos de circular (texto, deuda mínima, firma, SMS, plantilla). | COD_CIR | DES_CIR, TEXTO, TDEUDA, DEUDA, ADHER, FIR_GTE, FIR_AUD, DET_SER, COD_SER, SMS, PLANTILLA |
| `COMPNOTI` | Comprobantes incluidos en cada lote de notificaciones de mora. | ID_COMP | LOTE, CNT_NOT, COD_SUM, SALDO, ID_FAC, COD_TPFC |
| `CONCEPTOS_INT` | Conceptos (producto/impuesto) sobre los que se calcula interés por servicio. | COD_INT | COD_PRO, COD_SER, COD_IMP, TIPO |
| `EXC_MORA` | Excepciones de mora por cuenta: motivo, si reclamar/retener, vigencia. | COD_EXC | COD_SOC, COD_SUM, COD_PER, FEC_REG, USU_REG, MOTIVO, RECLAMAR, RETENER, FEC_DEUDA, VIGENCIA, FEC_VIG, USU_VIG … (+1) |
| `INDICESMORA` | Índices diarios/mensuales de las tablas de recargo por mora. | COD_MORA | COD_TAB, DIA_TAB, MES_TAB, ANO_TAB, IND_TAB, FECHA |
| `INSTANCI` | Instancias de mora (Candidatos, 1ª, 2ª) con días. | COD_INS | DES_INS, DIAS |
| `INT_DIFE` | Intereses diferidos: recibo que los genera y comprobante donde se facturan. | ID_INTDIF | COD_REC, SUC_REC, NUM_REC, COD_COMF, SUC_COMF, NUM_COMF, COD_COMV, SUC_COMV, NUM_COMV, ESTADO, COD_RECI, COD_CVEN … (+2) |
| `IT_PAGSO_INTERES` | Parámetros del cálculo de interés en cada ítem cobrado. | ID_ITI | ID_ITR, IMPUESTOS_EXCLUIDOS, MINIMO, CALCULA_CREDITO, CALCULA_ULIMO_VTO, CALCULA_JUBILADOS, REDONDEA, NO_COBRA_JUBILADO_2VTO, GASTOS_ADMINISTRAIVOS, INTERES, INTERES_IVA, INTERES_PERCEPCION … (+4) |
| `IT_PAGSO_INTERES_TRAMAS` | Detalle del interés por tramo (días, tasa, IVA). | ID_ITIR | ID_ITI, SALDO, DESDE, HASTA, DIAS, TASA, INTERES, IVA, PERCEPCION, TIPO |
| `MORATAS` | Tasas de recargo por mora con vigencia por servicio. | COD_MOT | FEDESDE, FEHASTA, TASA_CASO, TIPO, DES_MOT, COD_SER |
| `MORATAS_CATSER` | Categorías a las que aplica cada tasa de mora. | COD_MOTCAT | COD_MOT, COD_CATSER |
| `MOROSO_TEMPORAL` | Tabla temporal de morosos por lote. | ID | TITULAR, COD_SUM, LOTE |
| `NOTIFICA` | Notificaciones de mora por socio: instancia, deuda, promesa de pago, resolución. | CNT_NOT | LOTE, COD_SOC, COD_INS, FECHA, DEUDA, CALIFICA, DEUDA_AC, OBSERVA, VTO_CIR, PROMESA, RESUELTA, FEC_RES … (+14) |
| `TABMORA` | Tablas de recargo por mora (cabecera de INDICESMORA). | COD_TAB | NOM_TAB, TIPO_FAC |
| `TRAMASREC` | Tramos de recargo (desde/hasta, valor). | COD_TRM | DES_TRM, IMP_DES, IMP_HAS, VAL_TRAMA, TIPO, TIPOVALOR |

## 9. Financiación y convenios

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `DEUDAVTA` | Cuotas de deuda por ventas/financiaciones: vencimiento, capital, interés, estado. | COD_CVC | COD_COM, SUC_COM, NUM_COM, FECHA, NRO_CUO, DE_CUO, FEC_VTO, CAP_CUO, INT_CUO, CAP_RES, FAC_AUT, FAC_COD … (+23) |
| `FORMAPA` | Formas de pago (días). | COD_FPG | DES_FPG, DIA_FPG |
| `IT_RECCO` | Ítems de planes de refinanciación/convenio (comprobantes incluidos, cuotas). | ID_ITR | NRO_REF, COD_COM, SUC_COM, NUM_COM, CAP_A_REF, INT_A_REF, VTO, TOT_COM, NRO_CUO, DE_CUO, CAP_CUO, INT_CUO … (+7) |
| `PLAN_CUO` | Planes de cuotas/financiación: cantidad, tasa, mínimos, recargos. | COD_PLA | DES_PLA, TIP_PAG, PER_CUO, CAN_CUO, MIN_CUO, MAX_CUO, INT_TEM, INT_TNA, TASA, COD_CAL, MIN_VTA, MIN_ENT … (+18) |
| `REC_CON` | Convenios de refinanciación de deuda: capital, interés, cuotas, estado. | NRO_REF | FECHA, COD_SUM, COD_SOC, COD_PER, CAP_A_REF, INT_A_REF, INT_A_FEC, INT_X_REF, DEU_REF, PER_CUO, INT_TEM, INT_TNA … (+26) |
| `TIP_FIN` | Tipos de financiación (fórmula de cálculo). | COD_CAL | DES_CAL, FOR_CAL, DES_FOR |

## 10. Técnica, reclamos y obras

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `AVL_REG` | Posiciones GPS de vehículos (AVL) con estado y evento. | ID_REG | COD_MOV, UNIT, FECHA, IDSTATUS, DSTATUS, EVENTO, LATITUD, LONGITUD |
| `CAT_INCI` | Categorías de incidencias/obras con rubro y cuentas contables. | COD_CIN | DES_CIN, COD_RUB, COD_SER, COD_CTA, COD_CTH, COD_TRAN |
| `CHOFERES` | Choferes de vehículos. | COD_CHO | DES_CHO |
| `CLAS_INC` | Clases de incidencias con su numerador. | COD_CLI | DES_CLI, ULT_NUM |
| `EXPEDIENTES` | Expedientes de trámites técnicos (profesional, domicilio, contacto). | COD_EXP | COD_USER_MYSQL, COD_PROF, FECHA, COD_CAL, NUMERO, COD_BAR, COD_LOC, COD_PRO, COD_POSTAL, PISO, TORRE, DPTO … (+5) |
| `EXPEDIENTES_TRAM` | Pasos/etapas de cada expediente con resolución. | COD_TRAM | COD_EXP, COD_TRAM_ANT, PRESENTACION, FECHA, RESOLUCION, OBSERVACION, ETAPA, ADJUNTO, FECHA_RES |
| `FACTIBIL` | Solicitudes de factibilidad de servicio (domicilio, servicio, comprobante). | COD_SOL | COD_FTE, COD_COM, SUC_COM, NUM_COM, COD_SER, FECHA, COD_PER, COD_CAL, NUM_CAL, PISO, DPTO, COD_BAR … (+45) |
| `FACTIBIL_NOTA` | Notas de seguimiento de factibilidades. | COD_NOT | COD_SOL, TITULO, TEXTO, FECHA, USUARIO, COD_RES |
| `FALLAS` | Tipos de falla. | COD_FAL | DESCRIP, NOTAS |
| `GRPOBRA` | Grupos de obras con cuentas contables. | COD_GRP | DES_GRP, COD_CTA, COD_CTH |
| `GRPTAREA` | Grupos de tareas. | COD_GRP | DES_GRP |
| `MOVIL` | Vehículos (dominio, rendimiento, costo). | COD_MOV | DES_MOV, DOMINIO, NOM_AVL, KM_INICIAL, RENDIMIENTO, KG, COSTO, PROPIO, COD_PROV, TIPO_VEHICULO, PRE_VIAJESCORTOS |
| `OBRAS` | Obras (fechas, grupo, servicio). | COD_OBR | DES_OBR, FEC_INI, FEC_FIN, COD_GRP, COD_SER, COD_TIP, OCULTAR |
| `OT_REPORTE` | Reporte de impresión por tipo de orden de trabajo. | COD_REP | COD_TRAN, COD_SER, REPORTE |
| `PARTICUA` | Responsables participantes por cuadrilla. | COD_PTC | COD_CUA, COD_RES, RESPONSABLE |
| `PARTIINC` | Participantes de incidencias. | COD_PAR | COD_INC, COD_RES |
| `PARTIORD` | Horas de responsables en órdenes de trabajo. | COD_PTC | COD_RES, COD_SOL, HORAS_N, HORAS_E, FEC_REG, CONTRATADA, VALOR_HORA |
| `PROFESIO` | Profesionales/instaladores matriculados. | COD_PROF | DES_PROF, MATRICULA, DNI, COD_SER, CAT_INSTALADOR, TELEFONO, CORREO, WHATSAPP, COD_CAL, NUMERO, COD_LOC, COD_PRO … (+2) |
| `RECLAMOS` | Reclamos de socios: rubro, estado, resolución, servicio. | COD_REC | RUB_REC, DES_REC, FEC_REC, USU_REC, COD_SUM, ESTADO, FEC_EST, TXT_RES, FAVORABLE, USU_REV, FEC_REV, USU_RES … (+9) |
| `RECLAMOS_HIST` | Historial de estados de reclamos. | COD_RECH | COD_REC, FECHA, ESTADO, USUARIO, OBSERVA |
| `RECLAMOS_NOTAS` | Notas de reclamos. | COD_NOTA | COD_REC, DESCRIPCION, FECHA, COD_USER, ACCION |
| `RESOL_OT` | Resoluciones posibles de órdenes de trabajo. | ID_RLT | DES_RLT, COD_SER, COD_TRAN |
| `RESPONSA` | Responsables/técnicos/cobradores (usuarios operativos). | COD_RES | NOM_RES, ACTIVIDAD, PAS_RES, MAIL_RES, ASIGNAOT_PMOVIL, COD_DPS, INACTIVO, TEL_RES |
| `RESPONSA_NOTIFICA` | Notificaciones automáticas a responsables por tipo de orden y horario. | ID_RESPONSA_NOTIFICA | COD_SER, COD_OPER, COD_RES, TIP_ORDEN, DIAS, HORA_DESDE, HORA_HASTA, FERIADOS, NOTIFICAR_AL |
| `RUB_REC` | Rubros de reclamos. | COD_RRUB | DES_RRUB, EMAIL |
| `TAREAS` | Tareas. | COD_TAR | DES_TAR |
| `TAREASOM` | Tareas de órdenes de trabajo por grupo y servicio. | COD_TAR | DES_TAR, COD_GRP, COD_SER |
| `TAROTM` | Tareas por orden de trabajo. | ID_TAR | COD_TAR, COD_SOL |
| `TECNGREXP` | Grupos de exportación de órdenes técnicas. | COD_GRP | FEC_GEN, HOR_GEN, USU_GEN |
| `TECNICA` | Órdenes de trabajo/solicitudes técnicas: cuenta, servicio, transacción, estado. | COD_SOL | FECHA, COD_SUM, COD_SER, COD_PER, COD_TRAN, DESCRIP, OBS_ADM, OBS_TEC, NEW_CAL, NEW_NUM, NEW_PIS, NEW_DPT … (+117) |
| `TECNICA_EXTRAS` | Datos extra de OT (reclamos por daños, OCEBA). | ID | COD_SOL, FEC_PAG, CENRO_TRANSFERENCIA, NUM_LIBRO, NUM_FOLIO, MONTO_RECLAMADO, MONTO_APROBADO, DAÑOS_ANTERIORES, ACEPTADO, RECLAMO_OCEBA, CAUSA, ARTEFACTOS_DANADOS … (+11) |
| `TECNICA_MOVIL` | Vehículos asignados a cada OT. | COD_TECMOV | COD_SOL, COD_MOV |
| `TECNICA_NECESIDAD` | Materiales solicitados/autorizados/usados en OT. | COD_TEC_NEC | COD_SOL, COD_PRO, CANTIDAD_SOLICITADA, USUARIO_SOLICITO, CANTIDAD_AUTORIZADA, USUARIO_AUTORIZO, FECHA_AUTORIZO, CANTIDAD_RETIRADA, USUARIO_RETIRO, CANTIDAD_UTILIZO, USUARIO_UTILIZO, COD_DEP |
| `TECNICA_NOTA` | Notas de OT. | COD_NOT | COD_SOL, TITULO, TEXTO, FECHA, USUARIO, COD_RES |
| `TECNOTEXP` | Estados exportados de OT. | COD_GRP | COD_SOL, COD_EST, FEC_REC, HOR_REC, USU_REC |
| `TECNSEEXP` | Servicios por grupo de exportación de OT. | COD_GRP | COD_SER |
| `TPTRAB` | Tipos de trabajo/orden. | COD_TIP | DES_TIP, REPORTE, TIP_ORD |
| `TRANSAC` | Transacciones técnicas (alta, baja, corte, reconexión) y su efecto en el estado del servicio. | COD_TRAN | DES_TRAN, COD_SER, REG_EST, TIP_TRAN, MODIFICA_MATRICULA, COD_EST, AGREGAR_OBSERVACION, COD_PLA_ALTA, COD_PLA_CONFIRM, EXCLUIR_WEB, ENVIO_SMS, ALTA_PMOVIL … (+4) |

## 11. Redes (GIS)

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `NIV_CAPA` | Capas de red por servicio. | COD_CAPA | DES_CAPA, COD_SER |
| `NIV_REDES` | Elementos de la red instalada (transformadores, postes) con GPS. | INT_RED | COD_SER, DESCRIP, REFERENCIA, INT_PADRE, COD_CAL, NUMERO, MARCA, MODELO, SERIE, CAR_TEC, FEC_INST, FEC_SUST … (+13) |
| `NIV_SERV` | Niveles de red por servicio. | COD_NIS | COD_SER, NIVEL, ETIQUETA, COD_CAPA, PER_CONEC, MULT_CONEC, ICONO |
| `REDES` | Redes (eléctrica, agua, etc.). | ID_RED | DES_RED, OBS_RED |
| `REDES_ATRIBUTOS` | Atributos de elementos de red instalados. | ID_RED_INSTALADA, ID_ATRIBUTO | VALOR_CARACTER, VALOR_FECHA, VALOR_NUMERICO, VALOR_ID_TABLA |
| `REDES_ATRIBUTOS_COMPONENTES` | Definición de atributos por componente de red. | ID_ATRIBUTO | ID_COMPONENTE, DESCRIPCION, TIPO, LARGO, DECIMALES, TABLA, ID_TABLA, DES_TABLA, VISIBLE |
| `REDES_CAPAS` | Capas de cada red. | ID_CAPA | ID_RED, DES_CAPA |
| `REDES_COMPONENTES` | Tipos de componentes de red. | ID_COMPONENTE | ID_RED, ID_CAPA, DES_COMPONENTE, MULTIPLES_CONEXIONES, PERMITE_CONECTAR, MULTIPLES_ELEMENTOS, NOMBRE_ELEMENTOS, DISTRIBUYE_EN_HIJOS, ICON |
| `REDES_RED_INSTALADA` | Elementos instalados en la red (jerarquía padre-hijo, GPS). | ID_RED_INSTALADA | ID_RED, ID_CAPA, ID_COMPONENTE, ID_PADRE_RED_INSTALADA, ELEMENTO_INICIAL, ELEMENTO_FINAL, LATITUD, LONGITUD, COD_CAL, DESCRIPCION, NUMERO, ACTIVO … (+1) |
| `REDES_RELACIONES_COMPONENTES` | Relaciones permitidas entre componentes. | ID_RELACION | ID_CAPA, ID_RED, ID_PADRE, ID_HIJO |
| `REDES_SERVICIOS` | Servicios que usan cada red. | ID_REDSER | ID_RED, COD_SER |
| `SERSOC_REDES` | Conexión del servicio a un elemento de red. | ID_SERSOC_REDES | ID_SERSOC, ID_RED_INSTALADA, FECHA_CONEXION, FECHA_DESCONEXION, OBSERVACIONES, ESTADO |

## 12. Telefonía e internet

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `BANCLA` | Claves de tarifación telefónica por banda y tipo de llamada. | COD_BAN | COD_TAR, COD_TPB, COD_TLL, CLAVE |
| `BANDAS` | Bandas horarias (día, hora inicio/fin) para tarifar llamadas. | COD_BAN | DIA, HORA_INI, HORA_FIN, COD_TPB |
| `CARACTER` | Características telefónicas (prefijos/bloques de numeración). | COD_CAR | DES_CAR, COD_PRV, CLAVE, LOCAL, COD_OPE, BLOQUE, INDICATIVO, COD_MOD, COD_SERV, NUMERO |
| `CENTRALT` | Centrales telefónicas. | COD_CEN | NOM_CEN, ULT_DSK |
| `CLAVES` | Claves de tarifación telefónica. | COD_CLA | DES_CLA |
| `CORREOSINT` | Casillas de correo provistas como servicio a un socio. | COD_COR | COD_CSE, USER_ID, USER_PASS, DOMINIO, OTROS, FEC_REG, USU_REG, ID_SERSOC |
| `ENTRANTE` | Llamadas entrantes registradas por la central. | COD_LLA | ORIGEN, DESTINO, FECHA, SEGUNDOS, NCNT, NDISK, TRONCAL, COD_TSE, LOTE, COD_CEN |
| `GRATIS` | Números de llamada gratuitos. | COD_GRA | TEL_GRATIS, DES_GRATIS, COD_SER, DESHABILI |
| `INTERNAC` | Llamadas internacionales facturables. | COD_LLA | NRO_ORI, NRO_DES, DES_DES, FECHA, PREFIJO, CLAVE, SEGUNDOS, COD_BAN, COD_TLL, GRATUITO, SUBNETO, NETO … (+19) |
| `INTERNET` | Datos técnicos del servicio de internet (usuario, MAC, IP, nodo, OLT). | ID_SERSOC | COD_CSE, USER_ID, USER_PASS, MAC_ADR, IP_ADR, AP_CON, LD_CON, OTROS, FEC_REG, USU_REG, POSIC, TERMINAL … (+11) |
| `LLAMADAS` | Llamadas telefónicas tarifadas (origen, destino, segundos, importe). | COD_LLA | NRO_ORI, NRO_DES, FECHA, PREFIJO, CLAVE, SEGUNDOS, SEC_FAC, COD_BAN, COD_TPB, GRATUITO, SUBNETO, NETO … (+18) |
| `LLA_CEL` | Llamadas a celulares (CPP) facturables. | COD_LLA | GRUPO, COD_OPE, NRO_ORI, NRO_DES, FEC_LLA, SEC_LLA, SEC_CPP, IMP_CPP, CAU_REC, FAC_SOC, FAC_CPP, FEC_REG … (+8) |
| `MIKROTIK` | Credenciales de routers Mikrotik (internet). | ID_MTK | USUARIO, CONTRASEÑA, IP, PUERTO, BMU |
| `OPERADOR` | Operadores telefónicos. | COD_OPE | DES_OPE, COD_SUM, GENERICO |
| `PLANDES` | Planes de descuento telefónicos. | COD_PDES | DES_PDES, ACTIVO, IMP_POR, IMP_DES, COD_TAR, ACT_CLA, COD_CLA1, COD_CLA2, ACT_DIA, DIA, ACT_HORA, HORA1 … (+13) |
| `RECHAZOS` | Llamadas rechazadas. | COD_REC | DES_REC, PUBLICO, ABONADO, LLAMANO, LLAMAYA, IMPORTE, DURACPP, DURAREA, LLAMANT, LLAMANTNO, FECHAIN, HORAIN |
| `SERTEL` | Conceptos de servicios telefónicos. | COD_CON | COD_PRO, COD_SER, DES_CON, IMPORTE, PRE_PROV, CONSUMO, TIPO |
| `TARCLA` | Tarifas por clave telefónica. | COD_TCL | CLAVE, COD_TPB, FRACCION, IMPORTE, NUMERO, TIP_LLA |
| `TARESP` | Tarifas especiales telefónicas. | ID_TAR | COD_BAN, COD_TAR, COD_TPB, TIP_LLA |
| `TARTEL` | Tarifas telefónicas. | COD_TAR | DES_TAR, PUBLICO, COD_SER |
| `TEL_CAJAS` | Cajas de distribución telefónica. | COD_CAJA | DES_CAJA, COD_REP, COD_CAL, NUMERO, GPS_LATITUD, GPS_LONGITUD |
| `TEL_CENTRAL` | Centrales telefónicas. | COD_CEN | DES_CEN, ULTIMO_DISCO, GPS_LATITUD, GPS_LONGITUD, MODALIDAD, IMP_SEGUNDOS, IMP_CLAVE, ID_TEL, COD_PRE, COD_MON |
| `TEL_DSLAM` | Equipos DSLAM. | COD_DSLAM | DES_DESLAM, MARCA, MODELO, SERIE, OBSERVACION |
| `TEL_FRACCIONES` | Fraccionamiento de tarifación de llamadas. | COD_FRA | COD_TCL, COD_LLA, CANTIDAD, SEGUNDOS, FRACCION, IMPORTE, TOTAL |
| `TEL_GRUPOS_REPARTIDOR` | Grupos de repartidor. | COD_GRU | DES_GRU, COD_REP, TIPO |
| `TEL_MODALIDAD` | Modalidades telefónicas. | COD_MOD | DES_MOD, MOVIL |
| `TEL_NUMEROS` | Numeración telefónica disponible/asignada. | COD_NUM | NUMERO, ESTADO, FEC_ALTA, COD_PRE |
| `TEL_POS_REG_CAJA` | Posiciones de regleta en cajas. | COD_POS | COD_REG, NUMERO, COD_PTO_DSLAM, COD_POS_REG_GRU, CON_SAL, CON_ENT, INACTIVO |
| `TEL_POS_REG_GRUPOS` | Posiciones de regleta en grupos. | COD_POS | DES_POS, COD_REG, NUMERO, TER, TRM, COLOR, COD_POS_ANT, COD_PTO_DSLAM, COD_PTO_CEN, CON_SAL, CON_ENT, INACTIVO |
| `TEL_PREFIJO` | Prefijos. | COD_PRE | DES_PRE |
| `TEL_PUERTOS_CENTRAL` | Puertos de central. | COD_PTO_CEN | COD_CEN, NUMERO, COD_PTO_DSLAM, CON_SAL, INACTIVO |
| `TEL_PUERTOS_DSLAM` | Puertos de DSLAM. | COD_PTO_DSLAM | DES_PTO_DSLAM, COD_DSLAM, CON_SAL, CON_ENT, INACTIVO |
| `TEL_REGLETAS_CAJAS` | Regletas de cajas. | COD_REG | DES_REG, COD_CAJA |
| `TEL_REGLETAS_GRUPOS` | Regletas de grupos. | COD_REG | DES_REG, COD_GRU |
| `TEL_REPARTIDOR` | Repartidores. | COD_REP | DES_REP, COD_CEN, GPS_LATITUD, GPS_LONGITUD |
| `TEL_SERSOC` | Número telefónico asignado a un servicio. | COD_TSE | COD_NUM, ID_SERSOC, COD_TAR, FEC_ALTA, FEC_BAJA, OBSERVACION |
| `TEL_SERVICIO` | Servicios telefónicos. | COD_SERV | DES_SERV |
| `TIPOBAN` | Tipos de banda. | COD_TPB | DES_TPB, COLOR |
| `TIPOLLAM` | Tipos de llamada. | COD_TLL | DES_TLL, URBANA, INTERUB, INTERNA, GRATUIT, OPERADO, ESPECIA, CPP, LOCAL |

## 13. Ventas de productos y presupuestos

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `COMP_VEN` | Comprobantes de venta de productos (no servicios): cabecera, vendedor, cuotas. | ID_COMPV | COD_COM, SUC_COM, NUM_COM, DEB_CRE, FECHA, COD_SOC, COD_SUM, COD_VEN, PAGO, LOTE, SUBNETO, DTO … (+26) |
| `COMP_VEN_RENDICION` | Rendición de viajes asociada a una venta (km, flete, peajes, viáticos). | ID_RENDICION | ID_COMPV, FECHA, KM_REALES, FLETE_REAL, TIPO_FLETE, PEAJES, VIATICOS |
| `COMP_VEN_RENDICION_ITEMS` | Ítems de rendición de viaje (cargas de combustible). | ID_COMPRIT | ID_RENDICION, NUM_PUESTO, NUM_COM, LITROS, PRELITRO, CARGADOENVIAJE |
| `IT_COMPV` | Renglones de comprobantes de venta de productos. | ID_ITCOMPV | COD_COM, SUC_COM, NUM_COM, COD_PRO, CAN_ITE, PRE_VSI, CAN_PEN, ID_OBS, COD_CVI, ESTADO, DES_PRO, IVA1 … (+8) |
| `MAQUINAS` | Máquinas/equipos vendidos o en reparación. | COD_MAQ | COD_COM, SUC_COM, NUM_COM, COD_PROV, ESTADO, COD_PRO, FEC_COM, PRE_CSI, FEC_ENT, FEC_ENTP, ID_PRO, COD_CLI … (+23) |
| `OB_COMPV` | Observaciones y transporte de comprobantes de venta. | ID_COMPV | TRANSPO, NOM_TRANS, DOC_TRANS, VAL_DECLA, OBS_GRAL1, OBS_GRAL2, OBS_FAC1 |
| `PRESUIT` | Renglones de presupuestos. | ID_ITEM | COD_COM, SUC_COM, NUM_COM, COD_PRO, CAN_ITE, PRE_VSI, PENDIENTES, CAN_PEN, ID_REQUE, ID_SERIE, ID_OBS, ESTADO … (+15) |
| `PRESUIT_CONJUNTOS` | Conjuntos dentro de presupuestos. | ID_CNJ | COD_CVE, ITEM, DES_ITEM, CAN_ITEM |
| `PRESUPU` | Presupuestos a socios/clientes (cabecera). | COD_CVE | COD_COM, SUC_COM, NUM_COM, DEB_CRE, FECHA, COD_SOC, COD_SUM, COD_VEN, PAGO, LOTE, SUBNETO, DTO … (+39) |
| `PRESUPU_COMPROBANTES` | Comprobantes generados desde un presupuesto. | ID_PRESU_COMPROB | COD_CVE, ID_COMPV, ID_FAC |
| `PRESUPU_CONDICION` | Condiciones de venta de presupuestos. | COD_COND | CONDICION |
| `PRESUPU_NOTAS` | Notas de presupuestos. | COD_NOT | COD_CVE, TITULO, TEXTO, FECHA, USUARIO |
| `VENDEDOR` | Vendedores. | COD_VEN | NOM_RAZ, COD_CAL, DOM_NUM, DOM_DPT, DOM_PIS, COD_BAR, COD_PRO, COD_LOC, DOM_COD, DOM_TEL, DOM_FAX, CELULAR … (+4) |

## 14. Compras y proveedores

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `CMPORDE` | Relación entre órdenes de técnica y comprobantes de venta. | ID_CMPORDE | COD_SOL, COD_COM, SUC_COM, NUM_COM, COD_CVE, ID_COMPV |
| `COMBUSTIBLES` | Tipos de combustible. | ID_COMBUST | COMBUSTIBLE |
| `COMPRAS_RELACION` | Relación origen-destino entre documentos de compra (pedido → OC → remito → factura). | ID_REL | TIPO_ORI, ID_ORI, TIPO_DES, ID_DES, CANTIDAD |
| `COMP_COM` | Comprobantes de compra (cabecera: proveedor, netos, IVA, percepciones). | ID_COMPC | COD_EMP, FECHA, HORA, FEC_CON, COD_COM, SUC_COM, NUM_COM, COD_PROV, IMP_GRA, IMP_EXE, IMP_NGR, IMP_PER … (+25) |
| `CON_COM` | Conceptos de compra con rubro, alícuota IVA e IIBB. | COD_CON | COD_RUB, DES_CON, DES_FOR, UNI_MED, COD_ALI, CON_NOG, TIPO, TIPO_IVA, COD_IB |
| `CON_COM_RET` | Retenciones aplicables a cada concepto de compra. | COD_CONRET | COD_CON, COD_TIPO |
| `DESTINATARIO_SAPROV` | Destinatarios de solicitudes de aprovisionamiento. | COD_DES | NOM_DES |
| `FPALIC_IVA` | Alícuotas de IVA de comprobantes de proveedores. | ID_FPALIC_IVA | ID_IVACOM, PORC_IVA, IMP_IVA, IMP_BASE |
| `FPITEMS` | Renglones de comprobantes de proveedores. | ID_FPITEMS | ID_IVACOM, COD_COM, SUC_COM, NUM_COM, COD_PROV, COD_PRO, PRO_CON, CAN_PRO, PRE_UNI, IVA, COD_COMRE, SUC_COMRE … (+17) |
| `IT_APROV` | Renglones de solicitudes de aprovisionamiento. | ID_IT_SAP | ID_SAP, COD_PROD, PRO_CON, CANT_PED, CANT_REC, COSTO, OBSE, CAN_PEN, DES_PRO, USU_SOL, COD_DES, OBSE2 … (+2) |
| `IT_COMPC` | Renglones de comprobantes de compra. | ID_IT_COMP | ID_COMPC, COD_PROV, COD_COM, SUC_COM, NUM_COM, COD_PRO, PRO_CON, CAN_PRO, PRE_UNI, IVA, SAL_CANPRO, ESTADO … (+17) |
| `IT_NPED` | Renglones de notas de pedido a proveedores. | ID_IT_NPED | ID_NPEDIDO, COD_PROV, COD_COM, SUC_COM, NUM_COM, COD_PRO, PRO_CON, CAN_PRO, BULTOS, PRE_UNI, PRE_BON, POR_IVA1 … (+26) |
| `IT_SCOTIZ` | Renglones de solicitudes de cotización. | ID_IT_SCOT | ID_SCOTIZ, COD_PROD, PRO_CON, CANT, COSTO, PRE_ANT, VALIDEZ, OBSE, CAN_PEN, DES_PRO, OBSE2, CRITICIDAD … (+4) |
| `IVACOM` | Libro IVA Compras (comprobantes de proveedores con netos e impuestos). | ID_IVACOM | COD_EMP, FEC_CON, FECHA, COD_COM, SUC_COM, NUM_COM, COD_PROV, COD_RUB, IMP_GRA, IMP_EXE, IMP_NGR, IMP_PER … (+35) |
| `IVACOM_COMBUSTIBLES` | Detalle de combustible en compras (litros, km). | ID_IVACOM_COMBUSTIBLES | ID_IVACOM, COD_MOV, ID_COMBUST, LTS, KM |
| `IVACOM_WEB` | Comprobantes de proveedores recibidos por la web (aprobación/rechazo). | ID_IVACOM_WEB | CUIT, RAZON_SOCIAL, COD_PROV, COD_COM, SUC_COM, NUM_COM, FECHA, VENCIMIENTO, IMPORTE, FECHA_REGISTRADO, HORA_REGISTRADO, ID_IVACOM … (+6) |
| `NPEDIDO` | Notas de pedido a proveedores (cabecera). | ID_NPEDIDO | COD_EMP, FECHA, FEC_CON, COD_COM, SUC_COM, NUM_COM, COD_PROV, IMP_GRA, IMP_EXE, IMP_NGR, IMP_PER, IVA_RI … (+36) |
| `OBS_PRO` | Observaciones de proveedores. | COD_PROV | OBSERV |
| `OCOMPRA` | Órdenes de compra. | ID_OCOMPRA | FECHA, HORA, COD_COM, SUC_COM, NUM_COM, COD_PROV, FENTREGA, AUTORIZADO, USU_GEN, OBSE, ESTADO, TIP_MON … (+11) |
| `PREV_COM` | Previsiones de compras periódicas. | ID_PREVISION | COD_PROV, FEC_INI, FEC_FIN, PERIODICIDAD, COD_CON, COD_PRO, IMPORTE |
| `PROVEED` | Proveedores: CUIT, situación fiscal, domicilio, IIBB. | COD_PROV | COD_EMP, NOM_PRO, COD_SIT, DOM_CAL, DOM_NUM, DOM_BAR, DOM_PRO, DOM_LOC, DOM_COD, DOM_TEL, DOM_FAX, CUIT … (+55) |
| `PROVEED_AUT` | Personas autorizadas de cada proveedor. | COD_PROVAUT | COD_PROV, NOMBRE, DNI, FEC_AUT, FEC_CAD_AUT, OBSE |
| `PROVEED_CBU` | CBU de proveedores. | ID_CBU | DESCRIPCION, COD_PROV, CBU |
| `PROVEED_RET` | Retenciones que aplican a cada proveedor. | COD_PROVRET | COD_PROV, COD_TIPO |
| `PROVEED_TIPPROD` | Tipos de producto por proveedor. | COD_PROVTIP | COD_PROV, COD_TIPP |
| `PROVEED_VALORACIONES` | Evaluaciones de proveedores. | ID_PROVEED_VALORACIONES | COD_PROV, COD_USU, FECHA, CUALIDAD, PUNTUACION, OBSERVACION |
| `PROVSUM` | Relación proveedor-cuenta. | COD_PROVSUM | COD_SUM, COD_PROV, TIPO |
| `RPSPROV` | Rubros de proveedores (padrón). | COD_RUB | DES_RUB, DES_RUBR |
| `RPSXPROV` | Rubros por proveedor. | COD_RPSXP | COD_PROV, COD_RUB, FECHA |
| `RUBPROV` | Rubros de proveedores con banco y pago diferido. | COD_RUB | DES_RUB, DES_RUBR, COD_BAN, PAGDIF |
| `RUBXPRO` | Rubros asignados a proveedores. | COD_RXP | COD_PROV, COD_RUB, FECHA |
| `SAPROV` | Solicitudes de aprovisionamiento (pedido interno, autorización). | ID_SAP | FECHA, HORA, COD_COM, SUC_COM, NUM_COM, OBSE, AUTORIZADO, USU_AUTO, USU_GEN, ESTADO, ESTIMADO, DOBLE_AUTO … (+13) |
| `SCOTIZ` | Solicitudes de cotización a proveedores. | ID_SCOTIZ | FECHA, HORA, COD_COM, SUC_COM, NUM_COM, COD_PROV, USU_GEN, OBSE, FVTO, ESTADO, TIP_MON, COTIZ … (+8) |
| `UNIDADES_GASTOS` | Unidades de gasto. | ID_UNIDADES | DES_UNIDADES, OBS_UNIDADES |

## 15. Stock, bienes de uso y fabricación

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `BIENES_USO` | Bienes de uso: alta, valor de origen, vida útil, amortización. | COD_BIEN | NRO_BIEN, DES_BIEN, OBS_BIEN, NRO_SERIE, COD_PRO, FEC_ALTA, USER_ALTA, FEC_COMPRA, IVACOM_IN, FEC_AFECTA, FEC_BAJA, IMP_ORIGEN … (+20) |
| `BIENES_USO_AMORT` | Amortizaciones calculadas de cada bien de uso, con ajuste por inflación. | COD_BIAM | COD_BIEN, COD_ASI, DESDE, HASTA, ULT_IMP_AMORT, ULT_IMP_ORIGEN, AJUSTE_INFL, VAL_ORIG_AJUS, AMOR_ACUM, AMOR_ACUM_AJUS, AMOR_EJER_AJUS |
| `BIENES_USO_CTSEC` | Distribución de bienes de uso por centro de costo. | ID_SEC_BIENES | COD_BIEN, COD_SEC, POR_ASIGNACION |
| `BIENES_USO_DISM` | Disminuciones de valor de bienes de uso. | COD_DISM | COD_BIEN, IMPORTE, FECHA |
| `BIENES_USO_HST` | Historial de cambios de bienes de uso. | COD_BIEN_HST | COD_BIEN, NRO_BIEN, DES_BIEN, OBS_BEN, NRO_SERIE, COD_PRO, FEC_ALTA, USER_ALTA, FEC_COMPRA, IVACOM_IN, FEC_AFECTA, FEC_BAJA … (+23) |
| `COMBOS` | Productos que componen un combo. | ID_COM | COD_PRO, COD_COM, CAN_COM |
| `DEPAPROD` | Departamentos por producto. | COD_DPT | DES_DPT, COD_PRO |
| `DEPOSITO` | Depósitos de stock. | COD_DPS | DES_DPS, IGNORAR |
| `ESTADOS_RECEP` | Estados de recepción de equipos. | COD_EST | DESCRIP, NOTAS, ICONO, NIVEL |
| `ETAFAB` | Etapas de fabricación por producto. | COD_ETA | COD_PRO, ORDEN, DES_ETA, DURACION, OBSERVA |
| `HIS_PRODFAB` | Historial de estructuras de fabricación. | HIS_INT_RED | INT_RED, COD_PRO, DESCRIP, REFERENCIA, NIVEL, INT_PADRE, COD_COM, CAN_COM, PRE_CSI, COD_ETA, OB1_COM, OB2_COM … (+1) |
| `HIS_PRODFAB_DIVISIONES` | Historial de divisiones de productos fabricados. | HIS_COD_DIV | COD_DIV, TIPO_OPERACION, ID_OPERACION, CANTIDAD, MEDIDA, COEFICIENTE_DESCOMPOSICION, FEC_REG |
| `ITRE_EST` | Estados de ítems en recepción de equipos. | ID_ITEST | FECHA, HORA, COD_REC, COD_ITEM, COD_PRO, COD_EST |
| `ITRE_PRO` | Productos de cada recepción de equipos. | ID_ITPRO | COD_ITEM, COD_REC, COD_PRO, CAN_PRO, PRE_VSI |
| `IT_RETM` | Renglones de retiro de materiales. | COD_IT | ID_RETI, COD_RES, COD_COM, SUC_COM, NUM_COM, COD_PRO, CAN_PRO, DES_PRO, ESTADO, SAL_CANTRO, ID_ITEM, ID_UNIDADES |
| `MOV_PRO` | Movimientos de stock (entradas/salidas por depósito y comprobante). | COD_MOV | COD_OPER, COD_REF, COD_SUM, COD_PROV, COD_PRO, FECHA, COD_COM, SUC_COM, NUM_COM, ENTRADA, SALIDA, ESTADO … (+13) |
| `MOV_PRO_EXTRAS` | Datos extra de movimientos de stock (quién recibe). | COD_MOV_EXTRA | COD_MOV, USUARIO_RECIBE, FECHA_RECIBE, COD_TEC_NEC |
| `MOV_TRH` | Movimientos de productos con trazabilidad (número de serie). | COD_MOV | COD_PTH, COD_OPER, COD_REF, COD_CMP, ENTRADA, SALIDA, FECHA, FEC_REG, USU_REG, COD_DPS, OBS_MPT, COD_PRO … (+2) |
| `OF_PARTE_COMPONENTE` | Componentes consumidos en partes de producción. | ID_COMPO | ID_PPROD, COD_PRO, CANTIDAD, COD_OPR, COD_PTH |
| `OF_PARTE_ITEM` | Ítems de partes de producción. | ID_ITEM_PPROD | ID_PPROD, COD_PRO, CANTIDAD, COD_CVE, COD_ESTADO, COD_OPR, ITEM_HASTA |
| `OF_PARTE_PRODUCCION` | Partes de producción de fábrica. | ID_PPROD | COD_COM, SUC_COM, NUM_COM, FEC_REG, FECHA_INICIO, FECHA_PREVISTA, FECHA_FIN, COD_USER, COD_RES, COD_ESTADO, ITEM_HASTA |
| `ORCOFAB` | Componentes de órdenes de fabricación. | COD_ORCO | ID_ORDEF, COD_COM, SUC_COM, NUM_COM, COD_PRO, CAN_PRO, CAN_RET, PRE_CSI, DIAS, COD_OPR, CAN_PPROD |
| `ORDAFAB` | Avance de órdenes de fabricación por etapa. | COD_ORDA | ID_ORDEF, COD_COM, SUC_COM, NUM_COM, FECHA, FEC_LAN, FEC_FIN, FEC_LANR, FEC_FINR, COD_RES, COD_ETA, FEC_ETA … (+4) |
| `ORDEFAB` | Órdenes de fabricación. | ID_ORDEF | COD_COM, SUC_COM, NUM_COM, FECHA, FEC_LAN, FEC_FIN, FEC_LANR, FEC_FINR, COD_RES, COD_ETA, FEC_ETA, OBSERVA … (+8) |
| `ORDEFAB_EXT` | Extensiones de plazo de órdenes de fabricación. | COD_EXT | ID_ORDEF, FEC_FIN, DESCRIPCION, FECHA, USUARIO |
| `ORPRFAB` | Productos a producir por orden de fabricación. | COD_OPR | ID_ORDEF, COD_COM, SUC_COM, NUM_COM, COD_PRO, CAN_PRO, COD_CVE, CAN_PPROD, ESTADO, ID_ITEM, CAN_REASIGNADO, CAN_CAMBIOPROD … (+3) |
| `PRODFAB` | Estructura de productos fabricados (lista de materiales). | INT_RED | COD_PRO, DESCRIP, REFERENCIA, NIVEL, INT_PADRE, COD_COM, CAN_COM, PRE_CSI, COD_ETA, OB1_COM, OB2_COM |
| `PRODFAB_DIVISIONES` | Divisiones de productos fabricados. | COD_DIV | TIPO_OPERACION, ID_OPERACION, CANTIDAD, MEDIDA, COEFICIENTE_DESCOMPOSICION |
| `PRODPUES` | Productos por puesto/equipo. | COD_PPU | COD_EQP, USUARIO, COD_RUB, FEC_PPU, USU_PPU, COD_USER |
| `PROD_SER_UBICACION` | Ubicación de productos en depósito. | ID_PROD_SER_UBICACION | COD_PRO, ID_UBICACION, CAPACIDAD |
| `PROD_TRH` | Unidades de producto con trazabilidad (número de serie). | COD_PTH | COD_PRO, NID_PTH, OBS_PTH, USU_REG, FEC_REG, ESTADO, PRE_TRH |
| `RECEPCIONES` | Recepción de equipos de clientes (servicio técnico). | ID_REC | COD_REC, FECHA, FECHA_ING, COD_CLI1, COD_CLI2, OBS, COD_COM, SUC_COM, NUM_COM, USERS, FECHA_REG, QUIENPIDE … (+5) |
| `RETI_MAT` | Retiros de materiales del depósito (para OT u obras). | ID_RETI | FECHA, COD_COM, SUC_COM, NUM_COM, COD_RES, DEB_CRE, FEC_REG, HOR_REG, USUARIO, TIP_ORD, NRO_ORD, COD_VEN … (+5) |
| `RMA_HISTORIAL` | Historial de estados de RMA. | COD_HIS | COD_RMA, ID_ESTADO, FECHA, COD_USER, OBS_HIS |
| `RMA_PRODUCTOS` | Devoluciones/reparaciones de productos (RMA). | COD_RMA | FECHA, USER_RECIBIO, COD_SUM, NOM_CONTACTO, TEL_CONTACTO, HORA_CONTACTO, COD_PROD, MODELO, NRO_SERIE, COD_PROV, OBS_RECEPCION, OBV_PROBLEMA … (+14) |
| `RUB_PYS` | Rubros de productos/servicios (jerarquía, cuentas contables, amortización). | COD_RUB | COD_PAD, DES_RUB, NIVEL, COD_CTAV, COD_CTAC, COD_ALB, COD_ACT, INDIRECTO, CLA_RUB, COD_CTAO, VIDA_UTIL, AJUSTABLE … (+12) |
| `TIP_PROD` | Tipos de producto. | COD_TIPP | DES_TIPP |
| `UBICACIONES` | Ubicaciones dentro de depósitos. | ID_UBICACION | COD_DPS, NOMBRE, ID_PADRE, ASIGNABLE, POR_DEFECTO |

## 16. Tesorería y bancos

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `BANKOS` | Cuentas bancarias propias: saldo, chequera, cuenta contable, conciliación. | COD_BAN | COD_CTA, NOM_BAN, SAL_INI, FECHA, CHEQUE, IMP_SYS, ULT_NUM, DIFERIDO, SALDO, FEC_ULTMOV, REPORTE, COD_PROV … (+16) |
| `CAJAPAGO` | Apertura/cierre diario de la caja de pagos a proveedores y medios habilitados. | FECHA | USUARIO, APERTURA, CIERRE, PAGACHEQ, PAGAVALO, PAGAEFEC, MAXEFEC, PAGATRANSF |
| `CATB_MOVS` | Relación entre categorías bancarias y tipos de movimiento. | COD_CATMOV | COD_CATC, COD_MOV |
| `CAT_BANC` | Categorías de movimientos bancarios con cuenta contable. | CAT_COMP | COMP, DES_CAT, DES_CATR, CTA_CONTA |
| `CHEQUERAS` | Cheques propios emitidos por chequera (estado, orden de pago, electrónico). | ID_CHEQUE | ID_CHEQUERA, DES_CHEQ, COD_BAN, NUMERO, ESTADO, FESTADO, USU_GEN, FECHA, ID_PPAGO, OBSERVAC, COD_RES, CRUZADO … (+4) |
| `CONTES` | Conceptos de movimientos de tesorería (ingreso/egreso). | COD_MOV | DES_MOV, DES_MOVR, ING_EGR, SISTEMA, USUARIO, FEC_REG, HOR_REG, CON_DEFA, OBS_DEFA, OPERATIVO, TIP_CIERRE |
| `COT_DOL` | Cotizaciones de moneda extranjera por fecha. | COD_COT | FEC_COT, HOR_COT, COT_DOLAR, COD_MON, COTIZACION_VENTA |
| `CTASUCE` | Cuentas bancarias de sucursales (CBU/CUIT) para recibir pagos. | ID_CTA | COD_BAN, COD_SUC, CTA_BAN, NOM_CTA, RECIBIR, CUIT_CTA |
| `ENTFIN` | Entidades financieras. | COD_BAN | NOM_BAN |
| `INTERBANKING` | Credenciales de la API de Interbanking. | CLIENT_ID | CLIENT_SECRET, CUSTOMER_ID, ACCESS_TOKEN, EXP_TOKEN, CLAVE_SISTEMA, USUARIO_SISTEMA, PASS_SISTEMA |
| `MOV_INTERBANKING` | Movimientos bancarios recibidos por Interbanking. | COD_MOV | id, account_cbu, depositor_code, operation_code_ib, operation_code_bank, code_description_ib, customer_cuit, depositor_description, code_description_bank, amount, voucher_number, grouping_code_ib … (+12) |
| `PAGOTAR` | Liquidaciones de tarjetas de crédito (presentado, pagado, retenciones, comisión). | ID_PAGO | COD_TAR, FEC_PAG, COD_COM, SUC_COM, NUM_COM, IMP_PRE, IMP_PAG, RET_IVA, RET_GAN, RET_IBR, COMISIO, IVA … (+7) |
| `PPAGOS` | Órdenes de pago a proveedores (retenciones, firma, entrega). | ID_PPAGO | FEC_PAG, COD_PROV, COD_COM, SUC_COM, NUM_COM, COD_VEN, PAGO, POR_DES, IMP_DES, SIN_DES, RETG, RETB … (+19) |
| `PPAGOS_FIRMANTES` | Firmantes autorizados de órdenes de pago. | COD_FRMTES | COD_EMP, COD_MOD, FECHA_DESDE, FECHA_HASTA |
| `PPAGOS_FIRMAS` | Firmas de cada orden de pago. | COD_FIRM | ID_PAGO, COD_USER, FECHA |
| `PPITEMS` | Comprobantes cancelados por cada orden de pago. | ID_PITEM | ID_PPAGO, COD_C, SUC_C, NUM_C, ID_IVACOM, COD_COM, SUC_COM, NUM_COM, COD_PROV, ENTREGA, FAC_PAGA, TOTAL_C … (+7) |
| `RESBAN` | Movimientos bancarios (debe/haber, concepto, conciliación). | COD_RES | COD_BAN, FECHA, COMP, CAT_COMP, NUMERO, CONCEPTO, OBSERVAC, DEBE, HABER, COD_COM, SUC_COM, NUM_COM … (+30) |
| `RESBAN_MOVINT` | Conciliación entre movimientos bancarios e Interbanking. | COD_REL | COD_RESBAN, COD_MOVINT, FEC_CONC, COD_CONC |
| `SUCENT` | Sucursales de bancos. | ID_SUC | COD_SUC, COD_BAN, NOM_SUC, DES_LOC, DES_PRV, DIRECCION, OBSERVA |
| `TESORE` | Movimientos de tesorería (entradas/salidas, conciliación). | ID_TESO | COD_BAN, FECHA, FEC_EMI, COD_MOV, NUMERO, CONCEPTO, OBSERVAC, ENTRADA, SALIDA, IMPRESO, USUARIO, FEC_REG … (+23) |
| `TIP_MON` | Monedas y cotización. | TIP_MON | DES_MON, DES_RED, SIMBOLO, COT_PES, DIVISIBLE, POR_PER, REDONDEO, PER_VUELTO, PERMITIDO, SISTEMA |
| `VAL_ESTA` | Estados de valores. | ID_ESTA | DES_ESTA |
| `VAL_MVTO` | Movimientos de valores (cambios de estado de cheques). | ID_MVTO | INTERNO, FECHA, HORA, COD_USER, ID_ESTA, OBSE, COD_BAN, ID_TESO |

## 17. Contabilidad

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `CAT_INCI_CTSEC` | Distribución de categorías de incidencias por centro de costo. | ID_SEC_INCI | COD_CIN, COD_SEC, POR_ASIGNACION |
| `CIERRE` | Asientos de cierre de ejercicio (cuenta, debe, haber). | COD_CIE | COD_ASI, GRABO, FEC_REG, FEC_ASI, DES_ASI, COD_CTA, CON_CTA, NOM_CTA, DEB_CTA, CRE_CTA, TIPOCU |
| `CTASIEN` | Asientos contables (cabecera: fecha, descripción, estado). | COD_ASI | COD_AS, DES_ASI, FEC_REG, FEC_ASI, GRABO, REVISO, AUTORI, APERTURA, CIERRE, USER_ADD, USER_MOD, FEC_REG_MANUAL … (+1) |
| `CTCUENTA_ASIGNA` | Asignación de cuentas contables por tipo de facturación, zona y rubro. | ID_CTCUENTA_ASIGNA | COD_CTA, TIP_CTA, COD_GRU, COD_TPFC, ZON_FAC, COD_RUB, RUBRO_AFECTADO |
| `CTEJER` | Ejercicios contables (inicio, fin, asientos de cierre y apertura). | COD_EJE | FEC_INI, FEC_FIN, ABIERTO, FEC_CIE, USER_CIE, NUM_EJE, ID_ASIENTO_CIERRE1, ID_ASIENTO_CIERRE2, ID_ASIENTO_APERTURA |
| `CTITASIE` | Renglones de asientos contables (cuenta, debe, haber). | COD_ITA | COD_ASI, COD_LIN, COD_CTA, DEB_CTA, CRE_CTA, OBS_LIN |
| `CTITASIE_SECCIONES` | Distribución de renglones de asiento por centro de costo. | COD_ITS | COD_ITA, COD_SEC, IMPORTE |
| `CTPLAN` | Plan de cuentas contable (código, nombre, tipo, saldos). | COD_PLAN | COD_CTA, CON_CTA, NOM_CTA, TIP_CTA, AJU_CTA, SDO_CTA, SAL_INI, SAL_ACT, FEC_MOV, DIG_VER, COD_SCC, COD_RUB … (+7) |
| `CTPLAN_SUBRUBROS` | Subrubros del plan de cuentas. | COD_SUBRUBRO | DESCRIPCION |
| `CTRLCNC` | Control de conceptos/productos por tipo. | COD_PRO | TIPO |
| `CTSECCION` | Centros de costo (secciones). | COD_SEC | DES_SEC, ID_GRUPO_CTSECCION, Porc_IVA_Compras |
| `CTSECCION_ASIGNA` | Reglas de imputación a centros de costo por servicio/producto/impuesto. | ID_CTASEC_ASIGNA | TIPO_OPERACION, TIPO_ELEMENTO, COD_SER, COD_PRO, COD_IMP, COD_CON, COD_SEC, POR_ASIGNACION, COD_VAR, MODELO, COD_CTA |
| `CTSECCION_GP_ASIGNA` | Asignación de centros de costo a grupos. | COD_CGA | COD_SEC, ID_GRUPO_CTSECCION |
| `CTSECCION_GRUPOS` | Grupos de centros de costo. | ID_GRUPO_CTSECCION | DES_GRUPO_CTSECCION |
| `CTSECC_X_CTA` | Centros de costo habilitados por cuenta contable. | ID_SEC_CTA | COD_CTA, COD_SEC |
| `CTSRUBROS` | Rubros contables. | COD_RUB | DES_RUB, TIP_RUB |
| `FPITEMS_CTSEC` | Distribución de renglones de compra por centro de costo. | ID_SEC_ITEMS | ID_FPITEMS, COD_SEC, POR_ASIGNACION, IMP_ASIGNACION |
| `GRPOBRA_CTSEC` | Distribución de grupos de obra por centro de costo. | ID_SEC_GRPS | COD_GRP, COD_SEC, POR_ASIGNACION |
| `GRU_CON` | Grupos contables de cobranza: cuentas de caja, capital, intereses, IVA. | COD_GRU | DES_GRU, CTA_COBF, CTA_COBR, CTA_CAJ, CTA_CAPS, CTA_CAPI, CTA_DESR, CTA_TAR, CTA_VAL, CTA_INT, CTA_IVA |
| `INFLACIO` | Índices de inflación por mes (ajuste por inflación). | COD_INF | COD_TAB, MES_TAB, ANO_TAB, IND_TAB |
| `RESULTA` | Cuentas de resultados (ganancias/pérdidas). | COD_RES | DES_RES, COD_CTA, GANANCIAS, PERDIDAS |
| `SECCION` | Secciones. | COD_SEC | DES_SEC |
| `SISCONT` | Operaciones del sistema con su cuenta contable (asientos automáticos). | COD_OPEINT | DES_OPEINT, COD_CTA, COD_RUB, OPERACION, OBSERVAC |
| `TABINFL` | Tablas de índices de inflación. | COD_TAB | DES_TAB |

## 18. Sueldos

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `SU_ACTIVIDADES` | Actividades (SICOSS). | COD_ACTI | DES_ACTI |
| `SU_ANTIGUE` | Escala de antigüedad por categoría (porcentaje, días de vacaciones). | COD_ANTI | DESDE, HASTA, COD_CAT, PORCENT, IMPORTE, COD_SIN, DIAS_VAC |
| `SU_ASIENTOS` | Configuración de asientos contables de sueldos. | COD_ASIENTO | ID_ASIENTO, DES_ASIENTO, DES_GRAL, CTA_DEBE, CTA_HABER, COD_EMPR, COD_SIN, COD_CATS, EMPLEADOS, COD_SEC, COD_CAR, COD_DEPTO … (+16) |
| `SU_AUDIT_TRA_INTERBANKING` | Transferencias de sueldos por Interbanking (envío/respuesta). | COD_TRA | DESC_TRA, TOTAL, COD_BAN, ESTADO, JSON_ENVIO, JSON_RESPUESTA, FEC_REG, USUARIO |
| `SU_BENEFICIOS_SICOSS` | Beneficios SICOSS. | ID_BENEFICIO | DESCRIPCION_BENEFICIO |
| `SU_CARGO` | Cargos de empleados. | COD_CAR | DES_CAR |
| `SU_CATE` | Categorías salariales (básico, horas). | COD_CAT | DES_CAT, TIP_CAT, IMPORTE, HRS_TRB, HRS_MIN, DIAS_MIN, ADICIONAL1, ADICIONAL2, ADICIONAL, COD_SIN |
| `SU_CONCEPTOS` | Conceptos de liquidación con fórmulas. | COD_CON | DES_CON, TIP_CON, FORMULA_CAN, FORMULA_IMP, FORMULA_FIL, DESDE, HASTA, ORDEN, GANANCIAS, COD_CTA, SICOSS, AGUINALDO … (+14) |
| `SU_CONCEPTO_TIPO` | Conceptos por tipo de recibo. | COD_STC | COD_TIPO, COD_CON, NOMOSTRAR |
| `SU_CONDICION` | Condiciones del empleado (SICOSS). | COD_COND | DES_COND |
| `SU_CONTRATACION` | Modalidades de contratación. | COD_CONT | DES_CONT |
| `SU_DEDUCCIONES` | Deducciones de Ganancias por mes. | COD_DED | MES, AÑO, GAN_NO_IMP, CONYUGE, HIJO, OTROS, DED_ESP1, DED_ESP2, SEGURO, SEPELIO, COD_TIPO, IMP_DESDE … (+3) |
| `SU_DEDUCCIONES_ESPECIAL` | Deducción especial de Ganancias por sueldo promedio. | COD_DESP | AÑO, SUELDO_PROMEDIO, IMPORTE_MENSUAL |
| `SU_DEDUCCIONES_TIPOS` | Tipos de deducción. | COD_TIPO | DES_TIPO |
| `SU_DESVICULACION` | Motivos de desvinculación. | COD_DESV | DES_DESV, CATEGORIA |
| `SU_DESVIC_EXTRAS` | Importes extra por desvinculación. | COD_DEX | COD_EXTRA, COD_DESV, IMP_EXTRA |
| `SU_EMPLEADOS` | Legajos de empleados (CUIL, alta, convenio, básico, CBU). | COD_EMP | COD_PER, COD_LEG, COD_EMPR, CUIL, FEC_ALTA, FEC_ANTI, FEC_BAJA, CONVENIO, BASICO, ADICIONAL, ADICIONAL1, ADICIONAL2 … (+45) |
| `SU_EMPLEADOS_DOCUMENTOS` | Documentación de empleados. | ID_EMP_DOC | COD_EMP, ID_DOCUMENTO, FEC_REG, VENCE, AUTORIZADO |
| `SU_EMPLEADOS_SEC` | Distribución de empleados por centro de costo. | ID_SEC_EMP | COD_EMP, COD_SEC, POR_ASIGNACION |
| `SU_EMPLEADOS_SUMSOC` | Cuentas de servicio de empleados (descuentos). | ID_EMPSUM | COD_EMP, COD_SUM |
| `SU_EMPRESAS` | Empresas empleadoras. | COD_EMP | DES_EMP, CUIT, COD_CAL, NUMERO, PISO, DEPTO, COD_BAR, COD_LOC, COD_PRO, EDIFICIO, OBS_POSTAL, COD_DPTO … (+15) |
| `SU_EMP_CBU` | Cuentas bancarias de empleados. | COD_CBU | COD_BAN, COD_SUC, CTA_BAN, NOM_CTA, CBU, BANCO_ORIGEN, POR_PAG, COD_EMP |
| `SU_EMP_EXTRAS` | Importes extra por empleado. | COD_EMPEX | COD_EMP, COD_EXTRA, IMP_EXTRA |
| `SU_EMP_FAMILIARES` | Familiares a cargo (Ganancias, salario familiar). | COD_FAM | COD_EMP, COD_PER, TIP_REL, ESTUDIANTE, DISCAPACITADO, ADHERENTE, FORM_572, PORC_DEDUCIR |
| `SU_EMP_FAMILIARES_EXTRAS` | Datos anuales de familiares. | COD_FAMEX | COD_FAM, ESTUDIANTE, DISCAPACITADO, ADHERENTE, FORM_572, PORC_DEDUCIR, AÑO |
| `SU_EMP_HISCAT_EMP` | Historial de categorías del empleado. | COD_HISCATEEMP | COD_EMP, COD_CAT_ANT, DES_CAT_ANT, COD_CAT_NEW, DES_CAT_NEW, FEC_CAT_ANT, FEC_CAT_NEW, FEC_REG, USU_REG |
| `SU_EMP_NOVEDADES` | Novedades de liquidación (horas, ausencias, anticipos). | COD_NOV | COD_TIPO, COD_EMP, FECHA, CANTIDAD, OBSE, FEC_VACACION, ID_IVACOM, NRO_CUO, ID_ANTICIPO, COD_SOL |
| `SU_EMP_OBS` | Observaciones de empleados. | COD_OBS | COD_EMP, OBSERVA, FECHA, USUARIO |
| `SU_EMP_OPER` | Relación encargado-operario. | COD_OPER | COD_ENCARGADO, COD_OPERARIO |
| `SU_EMP_TURNOS` | Turnos asignados a empleados. | COD_SUNOV | COD_EMP, COD_TUR, FEC_DESDE, FEC_HASTA |
| `SU_EXTRAS` | Conceptos extra. | COD_EXTRA | DES_EXTRA, COD_GRUPO, IMP_EXTRA |
| `SU_EXTRAS_GRUPOS` | Grupos de conceptos extra. | COD_GRUPO | DES_GRUPO, UNICO, DEDUC_GAN |
| `SU_GRUPO_GRAFICO` | Grupos para gráficos de sueldos. | COD_GRUPO | DES_GRUPO |
| `SU_HORAS_LECTOR` | Fichadas de reloj (entrada/salida). | COD_HOR | FECHA, COD_EMP, ENTRADA, FEC_REG, USU_REG, PROCESADO, MANUAL |
| `SU_LICENCIAS` | Licencias solicitadas y autorizadas. | COD_SOL | COD_LICE, COD_EMP, FECHA, PERIODO, DIAS_TOTALES, DIAS_ANTER, FECHA_DESDE, FECHA_HASTA, CAUSA_DIAS, FECHA_AUT_DESDE, FECHA_AUT_HASTA, AUTORIZACION … (+6) |
| `SU_LICENCIAS_CAUSAS` | Causas de licencia. | COD_LICE | DESCRIPCION, VACACIONES, COD_TIP_NOV, DIAS_PERIOD, RET_TEMP |
| `SU_NOTIFICACIONES` | Notificaciones a empleados (recibos, firma). | COD_NOTI | FECHA, COD_USER_DEST, COD_USER_GEN, DESCRIPCION, VISTO, FECHA_FIRMA_EMP, ESTADO, OBSERVA_NOCONFORM, FIRMA, REF_PDF |
| `SU_OBRA` | Obras sociales (aportes y retenciones). | COD_OBR | DES_OBR, POR_RETENCIO, IMP_RETENCIO, POR_APORTE, IMP_APORTE |
| `SU_SALARIO_MINIMO` | Salario mínimo vital y móvil por fecha. | COD_MINIMO | DESDE, SALARIO |
| `SU_SINDICATO` | Sindicatos (aportes y retenciones). | COD_SIN | DES_SIN, POR_RETENCIO, IMP_RETENCIO, POR_APORTE, IMP_APORTE, MES_CAT, CTA_GRAL, CTA_CARGAS |
| `SU_SINIESTRADO` | Códigos de siniestrado (SICOSS). | COD_SINI | DES_SINI |
| `SU_SITUACION_REVISTA` | Situaciones de revista. | COD_SIRE | DES_SIRE |
| `SU_SIT_REVISTA_EMPLEADO` | Situación de revista de cada empleado. | COD_SRE | COD_SIRE, COD_EMP, FECHA_DESDE |
| `SU_SUELDOS` | Recibos de sueldo (cabecera por empleado y período). | COD_SUE | COD_EMP, COD_COM, SUC_COM, NUM_COM, COD_TIPO, FEC_PER, FEC_REG, FEC_PAG, FEC_IMP, COD_CAT, APORTE_PER, APORTE_FEC … (+9) |
| `SU_SUELDOSIT` | Conceptos de cada recibo de sueldo. | COD_ITEM | COD_SUE, COD_CON, IMPORTE, CANTIDAD, TIP_CON, DES_CON, BASE |
| `SU_SUELDOS_DETGAN` | Detalle de Ganancias por recibo. | ID_TIPGAN | COD_SUE, TIPO_REG_GAN, IMPORTE |
| `SU_TAREAS_EXTRAS` | Tareas extra (ej. lecturas, cortes) a pagar. | ID_TAREA | TIPO_TAREA, COD_SUM, OBSERVA, FECHA_DESDE, FECHA_HASTA, FECHA_REGISTRO, USER_REGISTRO |
| `SU_TAREAS_EXTRAS_EMPLEADOS` | Tareas extra realizadas por empleado. | ID_TAREA_EMP | ID_TAREA, COD_EMP, CANTIDAD, UNITARIO, TOTAL |
| `SU_TIPOEMPLEADOR` | Tipos de empleador. | COD_TEMP | DES_TEMP |
| `SU_TIPO_NOVEDADES` | Tipos de novedad (SIRADIG). | COD_TIPO | DES_TIPO, TIPO, COD_SIRADIG, ANTICIPO, TOPE_ANUAL, POR_GAN_NETA, PAGOS_A_CUENTA, IMP_CEDULAR |
| `SU_TIPO_RECIBOS` | Tipos de recibo (mensual, SAC, vacaciones). | COD_TIPO | DES_TIPO, COD_COM, DIA_DESDE, DIA_HASTA, PRORRATEAR, NO_DESCONTAR_ADELANTO, TIPO_LIQUIDACION, SAC, VACACIONES, TIPO_TRAMA |
| `SU_TRAMAS` | Escalas de Ganancias por mes. | COD_TRAMA | IMP_MIN, IMP_MAX, RET_PES, RET_POR, EXCEDENTE, MES, AÑO, COD_TIPO |
| `SU_TRAMAS_TIPOS` | Tipos de escala. | COD_TIPO | DES_TIPO |
| `SU_TURNOS` | Turnos de trabajo. | COD_TUR | DES_TUR, OBS_TUR |
| `SU_TURNOSIT` | Horarios de cada turno. | COD_ITEM | COD_TUR, DIA_DESDE, DIA_HASTA, HORA_DESDE, HORA_HASTA |
| `SU_VARIABLES` | Variables de liquidación con fórmula. | COD_VAR | DES_VAR, FORMULA, TIP_VAR |

## 19. Planes de vivienda

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `PLANESVIV` | Planes de vivienda por categoría (aportes mínimos/máximos). | COD_CATSER | DES_VIV, OBSERVA, MINIMO_AA, MINIMO_DA, COD_PRO, MINIMO_AE, MINIMO_DE, MAXIMO_APA, FECHA_NVO, FECHA_APORTE_TEORICO, UTILIZAR_FECHA_ENTREGA |
| `PRECIOSVIV` | Precios de vivienda por categoría y fecha. | COD_PRV | COD_CATSER, FECHA, IMPORTE |
| `VIVIENDAS` | Viviendas de planes: inscripción, adjudicación, construcción, entrega. | ID_SERSOC | COD_SOC, COD_SUM, FECINSC, FECADJU, FORMADJU, TPROPIO, ENTREGAP, ENTREGA, INICONST, FINCONST, CODPLAN, ADJUDICA … (+2) |
| `VIV_ACTIVIDAD` | Actividades de construcción por etapa. | COD_ACT | DES_ACT, COD_ETA, CAN_HORA, PRE_HORA, ORDEN |
| `VIV_ETAPA` | Etapas de construcción. | COD_ETA | DES_ETA, COD_CATSER, ORDEN |
| `VIV_MAT` | Materiales entregados por vivienda. | COD_VMAT | ID_SERSOC, CANTIDAD, PRE_CSI, COD_PRO, DES_PRO, COD_MOV, FEC_MOV, USU_REG |
| `VIV_MATACT` | Materiales por actividad. | COD_MATA | COD_ACT, COD_PRO, CANTIDAD |
| `VIV_PROGMAT` | Materiales por avance. | COD_PROMAT | COD_PROG, COD_VMAT, COD_PRO, CANTIDAD |
| `VIV_PROGRESO` | Avance de obra por vivienda. | COD_PROG | ID_SERSOC, COD_ACT, FECHA_DESDE, FECHA_HASTA, HORAS, PORCENT, OBSERVA, COD_PROV, FEC_REG, USU_REG, ID_IVACOM, ID_CERT |
| `VIV_RETM` | Retiros de materiales para vivienda. | ID_RETM | ID_SERSOC, COD_PROV, FECHA, FEC_REG, USU_REG, COD_COM, SUC_COM, NUM_COM, COD_ETA, COD_DPS, COD_RES |
| `VIV_RET_IT` | Ítems de retiro de materiales para vivienda. | ID_RETIT | ID_RETM, COD_PRO, CAN_PRO, PRE_CSI |

## 20. Ambulancias / salud

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `AMBUCARACTE` | Características de los traslados en ambulancia. | COD_CAR | DES_CAR |
| `AMBULANC` | Servicios de traslado en ambulancia (paciente, origen/destino, km, importe, médico). | COD_AMB | COD_PER, COD_BEN, APELLIDOS, SEXO, FEC_TRA, FEC_PRE, COD_ORI, COD_DES, CANT_KM, IMPORTE, COD_MED, CAUSA … (+21) |
| `AMBUMED` | Médicos asignados a cada traslado de ambulancia. | COD_AMM | COD_AMB, COD_MED |
| `ESPE_MED` | Especialidades médicas. | COD_ESP | DES_ESP |
| `MEDICOS` | Médicos. | COD_MED | DES_MED, COD_ESP |

## 21. Mesa de ayuda (tickets)

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `TICKETS` | Tickets de mesa de ayuda/incidentes. | COD_TICKET | COD_TIPO, COD_SUBTIPO, COD_ESTADO, COD_MODULO, USER_CREACION, FEC_CREA, ASUNTO, DESCRIPCION, ESTIMADO_MINUTOS, INICIO_ESTIMADO, FIN_ESTIMADO, COD_MEDIO … (+34) |
| `TICKETS_ASIGNACIONES` | Asignaciones de tickets. | COD_ASIGNACION | COD_TICKET, USER_ASIGNA, USER_ASIGNADO, FECHA_ASIGNACION |
| `TICKETS_CONTACTOS` | Contactos de tickets. | COD_CONTACTO | DES_CONTACTO, COD_SOC, TELEFONO, CELULAR, MAIL, OBSERVACION, FORMA_CONEXION, ID_REMOTO, CLAVE |
| `TICKETS_ESTADOS` | Estados de tickets. | COD_ESTADO | DES_ESTADO, ORDEN, COD_ESTADO_BASE, REASIGNAR, VUELVE, COD_TIPOESTADO, REQAPROV, TESTING, ENVIARMAIL, ESPERA_CLIENTE |
| `TICKETS_EXTRAS` | Datos extra de tickets. | COD_TICKET | DESCRIPCION, RUTA_ACCESO |
| `TICKETS_HSBONIF` | Horas bonificadas por venta. | ID_COMPV | HS_IMPLEMENTACION, HS_SOPORTE |
| `TICKETS_MEDIOSATENCION` | Medios de atención. | COD_MEDIO | DES_MEDIO |
| `TICKETS_MODULOS` | Módulos de tickets. | COD_MODULO | DES_MODULO, COD_PROYECTO |
| `TICKETS_NOTAS` | Notas de tickets. | COD_NOTA | COD_TICKET, COD_USER, FECHAINICIO, FECHAFIN, DESCRIPCION, PAUSADO, ESTESTING, ELIMINADA, FECHAADD, INTERNA, FECHAMOD, RECLAMO … (+3) |
| `TICKETS_PROYECTO` | Proyectos de tickets. | COD_PROYECTO | DES_PROYECTO |
| `TICKETS_RESPONSABLES` | Responsables de tickets. | COD_RES | COD_SOC, COD_USER, COD_PROYECTO, BONIF_VENTA |
| `TICKETS_SUBTIPOS` | Subtipos de tickets. | COD_SUBTIPO | DES_SUBTIPO, COD_TIPO, COD_ESTADO, COD_PROD, PLANTILLA, REGISTRA_CAUSA, POR_DEFECTO, BLOQUEAR_CIERRE |
| `TICKETS_TIPOS` | Tipos de tickets. | COD_TIPO | DES_TIPO, COD_PROYECTO, COD_TIPOESTADO, PLANTILLA, TIPO_BONIFICACION |
| `TICKETS_TIPOSESTADOS` | Tipos de estado. | COD_TIPOESTADO | DES_TIPOESTADO |

## 22. Turnero

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `TURNOS` | Turnos de atención al público. | COD_TUR | COD_PER, NOMBRE, COD_AREA, TURNO, NUMERO, FEC_INGRESO, COD_EST, FEC_EST, PRIORIDAD, COD_AREA_ORIG |
| `TURNOS_HISTORIAL` | Historial de turnos. | COD_HIS | COD_TUR, COD_AREA, TIP_ACCION, COD_USER, COD_BHIS, INICIO, OBSERVA |
| `TUR_AREAS` | Áreas del turnero. | COD_AREA | DES_AREA, DES_RES, TIEMPO_EST, INHABILITADA, IMAGEN |
| `TUR_AREAS_USERS` | Usuarios por área. | COD_AREA_USER | COD_AREA, COD_USER |
| `TUR_BOX` | Boxes de atención. | COD_BOX | COD_TBOX, NUM_BOX |
| `TUR_BOX_HISTORIAL` | Apertura/cierre de boxes. | COD_BHIS | COD_BOX, COD_USER, FEC_APER, FEC_CIERRE |
| `TUR_TIPO_BOX` | Tipos de box. | COD_TBOX | NOM_BOX |

## 23. Actividades y agenda

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `ACTIPREV` | Actividades previas o preventivas vinculadas a otra actividad. | COD_ACP | DES_ACP, COD_ACI, ACT_ACP |
| `ACTIV` | Actividades programadas (agenda de tareas) con tipo, responsable y fecha límite. | COD_ACT | COD_TIPO, COD_RES, DES_ACT, MAILSEXTRA, TIP_GEN, TIP_FEC, FEC_HASTA |
| `ACTIV_SEG` | Seguimiento de cada actividad: alta, cierre, revisión y observaciones. | COD_ACT_SEG | FEC_ALTA, FEC_ACT, FEC_CIERRE, COD_ACT, CODRES_CIE, REV_ACT, OBS_ACT, MANUAL_ACT, COD_RES, FEC_REALCI, COD_US_CIE |
| `ACT_AREAS` | Áreas responsables de actividades, con mails y días de envío de avisos. | COD_AREA | DES_AREA, MAILSEXTRA, COD_RES, DIAS_ENVIO |
| `ACT_FREC` | Frecuencias de repetición de actividades. | COD_FREC | TIPO_FREC, DIAS_FREC |
| `ACT_RBR` | Rubros de actividades. | COD_ACT | DES_ACT |
| `ACT_TIPOS` | Tipos de actividad con área, márgenes de aviso, frecuencia y plantilla. | COD_TIPO | COD_AREA, DES_TIPO, MARGEN_ANT, MARGEN_POS, COD_FREC, PLANTILLA, DIAS_ENVIO |
| `CALENDARIO` | Eventos de calendario de usuarios (citas, recurrencias). | COD_CAL | TODOELDIA, CAL_DES, CAL_START, CAL_END, CAL_ASUNTO, CAL_UBICA, ETIQUETA, INFO_RECUR, INFO_RECOR, COD_USER, ESTADO, TIPO … (+3) |
| `CALENDARIO_TIPO` | Tipos de evento de calendario con color. | COD_TIPO | DESCRIPCION, COLOR |
| `TIP_EVEN` | Tipos de evento. | COD_TIPE | DES_TIPE |

## 24. Institucional (consejo, actas, INAES)

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `ACTAS` | Actas de reuniones del consejo, con contenido PDF y estado de firma. | COD_ACT | FECHA_REG, COD_REU, NUM_ACT, ESTADO_FIRMA, CONTENIDO_PDF |
| `CAT_INAES` | Categorías del INAES (organismo de cooperativas). | COD_CAT | DES_CAT |
| `CONSEJO` | Integrantes del consejo de administración (cargo, documento). | ID_CSJ | TIP_CSJ, DOC_CSJ, CAR_CSJ, NOM_CSJ |
| `REUNIONES` | Reuniones del consejo/asamblea. | COD_REU | FECHA, COD_USER, FECHA_REU, FECHA_INICIO, FECHA_FIN, ESTADO, ASUNTO, OBSERVACION |
| `REUNIONES_ASIST` | Asistentes a reuniones. | COD_CON | COD_REU, ID_CSJ, COD_EMP, NOM_EXT, ASISTIO |
| `REUNIONES_PERMISOS` | Permisos de usuarios sobre reuniones. | COD_USER_PERMISO | COD_EMP, COD_REU |
| `REUNIONES_TEMAS` | Temas del orden del día y resolución. | COD_TEMA | COD_REU, ORDEN_DIA, OBSERVACIONES, RESOLUCION, TRATADO, COD_REC |

## 25. Informes y tablero

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `ESTATAB` | Estados de indicadores del tablero. | ID_ESTA | DES_ESTA |
| `GRAFTAB` | Gráficos del tablero por estado. | ID_GRA | TIP_GRA, ID_ESTADO, IMAGEN |
| `GRUPTAB` | Grupos del tablero de control. | COD_GRP | DES_GRP |
| `GRUTAB` | Agrupaciones de tablas del tablero. | COD_GRP | COD_TAB, DES_GRP, ORD_GRP, DISTANCIA |
| `INFOCTD` | Configuraciones de informes para el ente regulador por servicio. | COD_CFG | DES_CFG, COD_SER, TIP_FORM |
| `INFOCTG` | Filas del informe regulatorio (tarifa, rangos de consumo; OCEBA). | ID_CTG | FILA, COD_TAR, DESDE, HASTA, COD_CFG, COD_CATSER, CONSUMO_DESDE, CONSUMO_HASTA, FILTRO, NO_INFORMAR_OCEBA, TARIFA_BIMESTRAL, CONVENCIONAL |
| `INFOCTN` | Columnas del informe regulatorio (conceptos, impuestos). | ID_CTN | COD_SER, COLUMNA, TIP_CON, COD_CFG, COD_IMP, COD_PRO, SUBTIPO |
| `INFO_SYS` | Catálogo de informes del sistema. | COD_INF | NOM_INFO, ORIGEN, CUENTA |
| `TABLAS_POWERBI` | Tablas/reportes publicados en Power BI. | COD_TABLA | NOMBRE, URL |
| `TABLERO` | Indicadores del tablero de control. | COD_VAR | COD_TIPO, COD_GRP, TIP_VAR, DES_VAR, DEC_VAL, VAL_OPT, VAL_UMB, PER_TIEMPO, TIP_GRA, OBJETIVO, REF_1, REF_2 … (+5) |
| `TENDTAB` | Valores históricos de indicadores (tendencias). | COD_TEND | COD_TIPO, FECHA, VALOR, REF_1, REF_2, REF_3, REF_4 |
| `TIPO_TAB` | Tipos de indicador. | COD_TIPO | DES_TIPO, REF_1, REF_2, REF_3, REF_4 |

## 26. Web / CoopOnline / APIs

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `REQUISITOS` | Trámites online: requisitos, formularios y consultas (Procoop WEB). | ID | ORDEN, DESCRIPCION, PDFFILE, TIPO_TRAMITE, DATO_REQUIERE, REPETICION, INICIO_QUERY, FIN_QUERY, DATO_CONTACTO, QUERY_CONSULTA_WS, MOSTRAR_TYC, DESCRIP_TYC … (+7) |
| `REQUISITOS_ITEMS` | Campos de cada formulario de trámite online. | COD_RQT | COD_REQ, ORDEN, DES_DATO, TIPO_DATO, MASCARA, OBLIGATORIO, QUERY, COMBINADO, VISIBLE, TABLA, REGISTRA_USER, NOENVIAR_PROC … (+4) |
| `RSSFEED` | Noticias RSS. | COD_RSS | TITCHN, DESCHN, LINKCHN, PRICHN, CLACHN, LBDATE, GENERATOR, LANGUAGE, TITLE2, LINK2, DESFEED, CATEGORY … (+3) |
| `WEB_LOG` | Log de sincronización con la web (facturas, pagos, errores). | ID_LG | FEC_INI, FEC_FIN, EQUIPO, CON_OK, FACTURAS, PAGOS, ERRORES, DATOS, USU_ACT |
| `WEB_NOVEDADES` | Novedades del portal web. | ID_NOVEDAD | TITULO, DESCRIPCION, TIPO, ORDEN, MOSTRAR_TITULO |
| `WS_KEYS` | API keys de web services. | COD_API | DES_API, API_KEY, DEPOSITO_INSUMO, DEPOSITO_PRODUCTO |
| `WS_USERS` | Usuarios del portal/app (CoopOnline). | COD_USER | MAIL, PASSWORD, CELULAR, FEC_ADD, APELLIDO, FEC_VALIDACION, NOMBRE |
| `WS_USERS_ACCOUNTS` | Cuentas vinculadas a cada usuario web. | COD_ACCOUNT | COD_USER, COD_SUM, COD_SOC |

## 27. Usuarios, seguridad y auditoría

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `AUDITO` | Registro de ingresos/egresos de usuarios al sistema (login/logout, equipo, IP). | COD_AUD | FECHA_LOGIN, FECHA_LOGOUT, EQUIPO, CORRECTO, LOCALIP, USUARIO_WIN, COD_USER |
| `AUDITORIA` | Auditoría de cambios: tabla, acción, sentencia y usuario. | COD_AUD | FECHA, HORA, USUARIO, TABLA, ACCION, SENTENCIA, DESCRIP, FECHA_USUARIO, PK_TABLA |
| `AUDIT_IA` | Log de consultas a un asistente de IA (comando, respuesta, tokens). | COD_AUD | TIPO_CONSULTA, FEC_REG, COMANDO, RESPUESTA, TOKENS, USUARIO |
| `AUTORIZACIONES` | Solicitudes de autorización de operaciones y quién las autorizó. | ID_AUTORIZACION | TIPO_AUTORIZACION, NOMBRE_PERMISO, FECHA, COD_USER, FECHA_AUTORIZO, COD_USER_AUTORIZO, DESCRIPCION |
| `FIRMADIGITAL` | Solicitudes de firma digital de documentos vía API. | COD_FIRMA | FECHA, FECHA_CONFIRMACION, TOKEN, ERROR, ESTADO, CANTIDAD, ID_API, DESCRIPCION, POSX, POSY, RAZON_FIRMA, MOSTRAR_IMAGEN … (+2) |
| `FIRMADIGITAL_ITEMS` | PDFs a firmar y firmados de cada solicitud. | ID_IFD | RUTA_PDF, RUTA_PDF_FIRMADO, COD_FIRMA, FIRMADO, TIPO, ID |
| `FIRMADIGITAL_USUARIOS` | Usuarios habilitados por firma digital. | ID_FU | ID_FIRMA, COD_USER |
| `FIRMASDIGITALES` | Certificados/proveedores de firma digital configurados. | ID_FIRMA | NOMBRE, CLIENT_ID, CLIENT_SECRET, CUIL, HASH, RAZON_FIRMA, IMAGEN, INACTIVO, TIPO_PROVEEDOR |
| `FIRMASELECTRONICAS` | Firmas electrónicas realizadas por usuarios. | COD_FIRM_ELEC | COD_USER, TIPO, ID_TIPO, FEC_REG, COD_DOC |
| `FIRMASELECTRONICAS_DOCUMENTOS` | Documentos que requieren firma electrónica. | COD_DOC | DES_DOC, TIPO, POS_X, POS_Y, OBLIGATORIO |
| `FIRMASELECTRONICAS_DOC_USUARIOS` | Usuarios firmantes por documento. | COD_DUS | COD_DOC, COD_USER |
| `INFO_AUD` | Auditoría de visualización de informes. | COD_INFO | COD_AUD, COD_INF, FEC_REG, TIP_VIS |
| `MENUSYS` | Menú del sistema (opciones, comandos). | COD_MENU | MODULO, ORDEN, NOMBRE, MPROMPT, MNIVEL, MTIPO, MCOMANDO, MKEY, MSKIPFOR, ACTIVA, ICONO, SISTEMA |
| `MENUVAL` | Permisos de opciones de menú por perfil. | COD_VAL | COD_MENU, PERFIL, ACTIVO, VERIFICA |
| `PERFILES` | Perfiles de usuario (horario de acceso). | COD_PERFIL | DES_PERFIL, HORA_DESDE, HORA_HASTA, ACCESO |
| `PERFILES_TABLAS` | Tablas habilitadas por perfil. | COD_TABPERF | COD_TABLA, COD_PERFIL |
| `USERS` | Usuarios del sistema (permisos por módulo, punto de venta, depósito). | COD_USER | NOMBRE, ALIAS, PASSWORD, NIVEL, DIGIT, US_SOC, US_CON, US_CAJ, US_SIS, US_GER, US_COJ, US_SPI … (+19) |
| `USERS_AREA` | Áreas de usuarios. | COD_AREA | DES_AREA |
| `USERS_DEPOSITO` | Depósitos habilitados por usuario. | COD_USERDPS | COD_USER, COD_DPS |
| `USERS_EXTRAS` | Opciones extra de usuario. | COD_USER | TIPO_DIFERIMIENTO, NO_IMP_RECIBO, PREPAGA_AUT |

## 28. Configuración y motor de pantallas

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `ABM_VALIDACIONES` | Reglas de validación de campos en los formularios de alta/modificación (control, mensaje, valores permitidos). | COD_ABM | TIPO_MOD, FORM, CONTROL, MENSAJE, PROPIEDAD, VALORES_SI, VALORES_NO |
| `ARCHIVOS` | Tipos/definiciones de archivos de intercambio por servicio. | COD_ARC | DES_ARC, EXT_ARC, REF_ARC, COD_SER |
| `DATOSETB` | Valores de datos extendidos por elemento. | COD_ETB | COD_DTS, COD_DATO, REF_ELE, VALOR, OBSERVA |
| `DATOSEXT` | Definición de campos extendidos configurables (tipo, largo, orden). | COD_DATO | ELT_DATO, ELE_DATO, DES_DATO, TIP_DATO, LAR_DATO, DEC_DATO, ORD_DATO, UNICO |
| `DATOSINT` | Datos de interfaces. | ID_INT | TIP_INT, DES_INT, DAT_INT, REF_INT |
| `EMPRESAS` | Empresas del grupo. | COD_EMP | DES_EMP |
| `ENTIDACOL` | Columnas de entidades configurables (motor de pantallas dinámicas). | COD_COL | COD_ENT, DES_COL, TIP_COL, COL_COL, LAR_COL, ORDEN, AGRUPAR, ICON1, ICON2, ICON3, ESPRIMARYKEY |
| `ENTIDACOL_EXTRA` | Columnas calculadas extra de entidades (select/join). | COD_ENT | QUERY_SELECT, QUERY_JOIN, DES_COL, TIP_COL |
| `ENTIDACON` | Condiciones/filtros de entidades configurables. | COD_CON | COD_ENT, DES_CON, TIP_CON, COL_CON, VAL_CON, PEN_CON, REF_COL, REF_TAB, REF_DES, ACT_CON, COLUMNA |
| `ENTIDACOU` | Condiciones de entidades por usuario. | COD_CON | COD_ENT, DES_CON, TIP_CON, COL_CON, VAL_CON, PEN_CON, REF_COL, REF_TAB, REF_DES, ACT_CON, UALIAS, COLUMNA |
| `ENTIDACRIT` | Criterios de agrupación de entidades. | ID_CRIT | DES_CRIT, COD_ENT, ICONO |
| `ENTIDADCIR` | Documentos circulados por entidad. | ID_ENT | COD_ENTIDAD, DOCUMENTO, FECHA |
| `ENTIDADES` | Entidades configurables (definición de grillas/consultas dinámicas). | COD_ENT | DES_ENT, CLA_ENT, TIP_ENT, FRM_VIS, ORDEN, ESELECT, ETABLAS, EWHERE, MPRINT, COLRET, ID_GRUP |
| `ENTIDAEST` | Estados y agrupaciones de entidades (árbol de navegación). | ID_EST | COD_EST, COD_ENT, DES_EST, COD_DEP, IMG_DEP, PEN_EST, MENU_EST, REF_SELE, REF_TAB, REF_COL, REF_MOS, REF_ORDEN … (+4) |
| `ENTIDAGRUP` | Grupos de entidades. | ID_GRUP | DES_GRUP |
| `ENTIDAMEN` | Menús/acciones disponibles por entidad. | COD_MEN | COD_ENT, DES_PMT, EJECUTAR, EJECUTAR_C, PARAM_C, MOSTRAR_C |
| `ENTIDA_ESTADOS` | Estados por entidad. | COD_EST | DES_EST, COD_ENT, ESTADO, SUBESTADO |
| `EXPORTADOR` | Definiciones de exportación a archivos (origen y destino). | COD_EXP | NOMBRE, TIPO_ORIGEN, ORIGEN, TIPO_DESTINO, NOMBRE_ARCHIVO |
| `EXPORTADOR_COLUMNAS` | Columnas de cada exportación (formato, largo, relleno). | COD_COL | COD_EXP, NOMBRE_COLUMNA, INDICE_COLUMNA, NOMBRE_PROPIEDAD, LONGITUD, PRECISION, FORMATO, RELLENO_IZQ, CAMPO_OBLIGATORIO, VALOR_FIJO, CAMPO_VACIO |
| `FORMAINT` | Formato de campos de archivos de interfaz (posición, largo, decimales). | ID_FOI | ID_MOI, ID_INT, DAT_FOI, LAR_FOI, DEC_FOI, IZQ_FOI, DER_FOI, ID_ORDEN, UBICACION |
| `FORMULARIOS_PERSONALIZACIONES` | Personalizaciones de controles en formularios. | ID_FORM | NOM_CONTROL, PROPIEDAD, VALOR, NOM_FORM, ESTADO_FORM |
| `MODEINT` | Modelos de interfaz de archivos (importación/exportación con bancos, lectoras). | ID_MOI | TIPO_MOD, DES_MOI, EXT_MOI, MEDI_MOI, FROM_MOI, ORI_MOI, FIN_MOI, ARCHIVO, DET_RES, REL_CON, LINEAS_D, LINEA_H … (+1) |
| `PROPIEITEMS` | Propiedades personalizadas configurables por entidad. | COD_PROPIEITEM | NOMBRE, MOSTRAREN, USO, OBLIGATORIO, TIPO_VALOR, VALOR1, VALOR2, GRUPO |
| `PROPIEITEMS_ASIGNACIONES` | Valores de propiedades personalizadas por registro. | ID_PROPIT_ASIG | ID_ENTIDAD, COD_PROPIEITEM, ID_ITEM, VALOR |
| `PROPIEITEMS_VALORES` | Valores posibles de propiedades personalizadas. | ID_ITEM | COD_PROPIEITEM, VALOR |
| `REPORTES` | Reemplazo de reportes por equipo. | COD_REP | ORIGINAL, NUEVO, COD_EQP |
| `SERVINT` | Servicios por modelo de interfaz. | ID_SRI | ID_MOI, COD_SER |
| `TIPOMOD` | Tipos de modelo de interfaz. | TIPO_MOD | DES_TIP, TIPO |
| `TIP_ARC` | Tipos de archivo. | COD_ARC | DES_ARC |
| `VARIABLE` | Parámetros del sistema (variables por módulo). | COD_VAR | NOM_VAR, DES_VAR, CARACTER, LOGICA, NUMERICA, COD_MOD, TIP_VAR, TIP_CTRL, CONF_CTRL, OBS_VAR |
| `VARIABLE_PMOVIL` | Parámetros de la app móvil. | COD_VAR | NOM_VAR, DES_VAR, CARACTER, LOGICA, NUMERICA, COD_MOD, TIP_VAR, TIP_CTRL, CONF_CTRL, OBS_VAR, MOD_VAR |

## 29. Sistema (general)

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `ADJUNTOS` | Archivos adjuntos asociados a distintos registros del sistema. | COD_ADJ | TIPO, COD_TIP, FECHA, FECHA_CAP, OBSERVA, USUARIO, NOM_ARC |
| `BLOQUEO_FILAS` | Tablas/columnas con bloqueo de edición concurrente. | ID_BLO | TABLE_NAME, COLUMN_NAME |
| `EQUIPOS` | Equipos/terminales (PC, kioscos) con punto de venta, impresora, lectores. | COD_EQP | DES_EQP, PTO_VTA, CAPTOR, TIPOLECTORBILLETE, TIPOLECTORTARJETA, TIPOIMPRESORA, COD_USER, NRO_DISPENSER, PUERTO_IMPRESORA, ORIENTACION, QR, MOSTRAR_RECIBO … (+2) |
| `ESTADOS` | Estados genéricos. | COD_EST | DES_EST |
| `INTEGRIDAD` | Reglas de integridad referencial verificadas por el sistema. | ID_ITGD | DES_ITGD, TABLA, PK, RTABLA, COL1, COL2, TDATO, ELIMINA |
| `MODULOS` | Módulos del sistema y su versión. | COD_MOD | DES_MOD, VERSION, IMAGEN, ORDEN, SISTEMA, COD_CATEG, CATEGORIA |
| `OPERACIONES` | Tipos de operación. | COD_OPER | DES_OPER |
| `OPE_COM` | Operaciones habilitadas por comprobante. | ID_COM_OPE | COD_COM, COD_OPER |
| `PROCOOPAR_ADJUNTOS` | Adjuntos/novedades del proveedor Procoop. | COD_PADJ | COD_USER, FEC_INICIO, TIPO_ADJUNTO, FEC_FIN, NOMBRE_ADJUNTO |
| `RELACION_ENTIDADES` | Relaciones genéricas entre registros. | ID_REL | TIPO_ORIGEN, ID_ORIGEN, TIPO_DESTINO, ID_DESTINO, FECHA, USUARIO |

## 30. Maestros generales (geografía, documentos)

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `BARRIOS` | Barrios por localidad. | COD_BAR | DES_BAR, COD_LOC |
| `CALLES` | Calles con ruta, orden y sector (sirven para la ruta de lectura/reparto). | COD_CAL | DES_CAL, RUTA, ORDEN, SECTOR |
| `DEPARTA` | Departamentos (división política). | COD_DPT | DES_DPT |
| `DEPTO` | Departamentos por provincia con códigos INAES, ENARGAS y OCEBA. | COD_DPTO | DES_DPTO, COD_PRO, COD_INAES, COD_ENGAS, COD_OCEBA |
| `DISTRITO_SECCION` | Distritos y secciones (catastro). | COD_DIS | DISTRITO, SECCION, DESCRIPCION |
| `DOCUMENT` | Tipos de documento con códigos ARCA, INAES, ENARGAS. | COD_DOC | DES_DOC, COD_SEN, COD_INA, COD_AFIP, COD_ENGAS |
| `EST_CIVIL` | Estados civiles. | COD_CIVIL | DES_CIVIL |
| `FERIADOS` | Feriados (afecta vencimientos). | COD_FER | DIA, MES, DES_FER, USU_REG, FEC_REG, AÑO |
| `LOCALIDA` | Localidades con códigos postales, ARCA, INAES, ENARGAS, OCEBA. | COD_LOC | DES_LOC, COD_PCI, COD_POS, COD_DPTO, COD_INAES, COD_ENGAS, COD_ENGAS_ZON, COD_AFIP, COD_OCEBA, KILOMETROS |
| `MAPA` | Configuración de mapas por módulo. | COD_MAP | MODULO, LATITUD, LONGITUD, ZOOM, TIPO, IMAGEN, MARCAS |
| `OCUPACIO` | Ocupaciones/profesiones. | COD_OCU | DES_OCU, TIPO |
| `PAISES` | Países. | COD_PAIS | DES_PAIS |
| `PROVINC` | Provincias con códigos ARCA, INAES, ENARGAS. | COD_PRO | DES_PRO, COD_SEN, COD_AFIP, COD_INAES, COD_ENGAS |
| `RNQCALL` | Calles (variante para rutas). | COD_CAL | DES_CAL, RUTA, ORDEN, SECTOR |
| `ZONAS` | Zonas (importe, recargo por baldío). | COD_ZON | DES_ZON, IMPORTE, REC_BALDIO |

## 31. Comunicaciones (mail, SMS, WhatsApp)

| Tabla | Qué contiene | Clave | Columnas principales |
|---|---|---|---|
| `AUDIT_MAIL` | Cola y auditoría de mails enviados (destino, asunto, contenido, adjuntos). | COD_AUDIT | COD_USER, FEC_ALTA, FEC_ENVIO, DESTINO, ASUNTO, ESHTML, CONTENIDO, ADJUNTOS, PENDIENTE, RTF, OBSERVA, COPYTO … (+6) |
| `CIRCUPRO` | Circulares a proveedores. | COD_CIR | DES_CIR, TEXTO |
| `CORREOS_INTERNOS` | Cuentas SMTP del sistema por módulo (remitente, servidor, puerto). | COD_COI | DES_COI, MODULO, REMITENTE, MAIL, USUARIO, PASS, SMTP, PORT, SSL, RESPONDER_A |
| `ENCUESTAS` | Encuestas a socios (texto, vigencia, obligatoria, repetición). | ID_ENCUESTA | DES_ENCUESTA, TEX_ENCUESTA, COD_SUM, FECHA, INICIO, VENCIMIENTO, OBLIGATORIA, REPETIBLE, INTERVALO_REPITE, PROBABILIDAD, FORMULARIO |
| `ENVIOS` | Envíos de SMS por módem. | ID_ENVIO | ID_MENSAJE, FECHA, HORA, ID_MODEM, ID_RESUL |
| `IVR` | Configuración de avisos telefónicos automáticos (IVR). | COD_IVR | DES_IVR, INTENTOS, HORA_DESDE, HORA_HASTA, INTE_OCUPADO, INTE_NOCONTESTA, DIA_AVISO |
| `MENSAJES` | SMS enviados/pendientes (destino, texto, estado, lote). | ID_MENSAJE | ORIGINANTE, MOVIL_DEST, COD_SUM, TEXTO, FECHA, USUARIO, ID_RESUL, FEC_ENVIO, ID_MODEM, INTENTOS, CATEGO, PLANTILLA … (+11) |
| `MODEMS` | Módems GSM para envío de SMS. | ID_MODEM | DESC_MODEM, EQUIPO, PUERTO, VELOCIDAD, OPERATIVO, CANTSMS, DIA_ACRE, ERRORES |
| `NOTI_COOP` | Novedades/notificaciones a socios (portal). | COD_NOTI | COD_SUM, ASUNTO, DETALLE, ESTADO, LINK_ARTI, USUARIO, FEC_REG, FEC_FIN |
| `PLANTILLA` | Plantillas de mensajes (mail/SMS/WhatsApp/reporte) por módulo. | COD_PLA | NOMBRE, TIPO, DESCRIPCION, TEXTO, MODULO, DESTINO, ASUNTO, COD_CIR, REPORTE, IMPORTE, WHATSAPP |
| `PLANTILLA_WSP` | Plantillas de WhatsApp. | ID_PLANTILLA | NOMBRE, DINAMICA, COD_PLA |
| `PROMAIL` | Mails de procesos (notificaciones, tickets). | COD_MAIL | DE_MAIL, DE_FECHA, DE_HORA, A_MAIL, C_MAIL, A_FECHA, A_HORA, M_FECHA, M_HORA, ASUNTO, TEXTO, ACCION … (+5) |
| `RESPUESTAS` | Respuestas a encuestas. | ID_RESPUESTA | ID_ENCUESTA, ID_INTERNO, FECHA, COD_USER, ALIAS, NOMBRE, RESPUESTA, OBSERVA, PERFIL, COD_ESTADO |
| `RESULTADOS` | Resultados de envío de SMS. | ID_RESUL | DESC_RESUL, TIPO, ENVIADO, ERRORMODEM, ABIERTO |
| `SENDMAIL` | Envíos de mail. | ID_MAIL | TIPO_MAIL, FECHA, HORA, TEXTO, DESTINO, RESPUESTA |
| `TELEFON` | Agenda telefónica. | COD_AGE | APENOM, DOMICILIO, LOCALI, PROVINCIA, TEL1, TEL2, TEL3, CELULAR, FAX, RUBRO, OBS, PUSER … (+2) |
| `VARIABLEPLANT` | Variables usables en plantillas. | COD_VPL | NOMBRE, DES_RESUMIDA, DES_LARGA, TIPO, RUTA, MODULO, FORMATO, GRUPO, COD_VPL_CALCULO, TIPOCALCULO |
| `VARIABLES_PLANTILLA_WSP` | Variables de plantillas WhatsApp. | ID | TIPO_PLANTILLA, POSICION, ORDEN, NOMBRE_VARIABLE, CANTIDAD, ID_PLANTILLA |
