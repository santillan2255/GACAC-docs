import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from repl import apply, fpath
from conc_lib import read, write

# ---------------- M11 ----------------
apply('M11', [
    ('| `accountId`, `holderId`, `serviceContractId` | ObjectId | Sí (contrato salvo concepto `allowWithoutContract`) | Cuenta, titular y contrato (M01) |',
     '| `accountId`, `holderId`, `contractId` | ObjectId | Sí (contrato salvo concepto `allowWithoutContract`) | Cuenta y titular (M01) y contrato (`serviceContracts` de M02; antes `serviceContractId`, CTR-DAT-30) |'),
    ('serviceContractId', 'contractId', 0),
    ('IDs compuestos de ProCoop se guardan en `legacyRef` y tabla de mapeo (T07)',
     'IDs compuestos de ProCoop se guardan en el subdocumento `legacy` (T05 §19.1; antes `legacyRef`, CTR-DAT-32) y en `legacyIdMap` (T07)'),
], 'f3-g6-m11')
p = fpath('M11'); L = read(p).split('\n')
i = [k for k, l in enumerate(L) if l.startswith('| CTR-VEN-17 ')][0]
L.insert(i + 1, '| CTR-VEN-18 | Nombres de campo de M11 (`serviceContractId`, `legacyRef`) vs T05 §7.2 y §19.1 | Nombres divergentes para el contrato y para la clave de origen. | `contractId` y subdocumento `legacy`; los nombres viejos quedan solo en las notas de alias. | CTR-DAT-30, CTR-DAT-32 |')
write(p, '\n'.join(L))

# ---------------- M14 ----------------
apply('M14', [
    ('| `treasuryHandoverId` | ObjectId → `treasuryHandovers` (M07) | Sí | Entrega de caja de M07 que esta rendición recibe: M07 registra la entrega y M14 la recepción (CTR-DAT-64). |\n',
     '| `treasuryHandoverId` | ObjectId → `treasuryHandovers` (M07) | Sí | Entrega de caja de M07 que esta rendición recibe: M07 registra la entrega y M14 la recepción (CTR-DAT-64). |\n'
     '| `legalEntityTotals` | `{ legalEntityId, declaredTotal, theoreticalTotal, countedTotal, treasuryAccountId, operationId }[]` | Sí | Apertura de la rendición por entidad jurídica (DEC-064, DEC-087: un cobro de caja puede cubrir varias entidades y M07 emite un recibo por entidad). Con una sola entidad tiene un elemento. Al aceptar se genera una operación por entidad sobre una cuenta de tesorería de esa entidad (RN-TES-086). |\n'),
], 'f3-g6-m14')
p = fpath('M14'); L = read(p).split('\n')
i = [k for k, l in enumerate(L) if l.startswith('| RN-TES-085 ')][0]
L.insert(i + 1, '| RN-TES-086 | Una rendición de caja con cobros de varias entidades jurídicas se acepta con una operación de tesorería por entidad, cada una sobre una cuenta de esa entidad; nunca se mezclan fondos de entidades distintas en una misma operación ni en una misma cuenta. La diferencia de arqueo se imputa a la entidad que indique el receptor (por defecto, la de mayor importe rendido). | Rendición única por caja sin entidad (`CAJAS`). | **Adoptar** (DEC-064, DEC-087) | — | — |')
write(p, '\n'.join(L))

# ---------------- M16 ----------------
apply('M16', [
    ('A validar (PA-SUE-01)', 'Adoptado (DEC-058: dos períodos en paralelo en O9)', 1),
], 'f3-g6-m16')

# ---------------- T02 ----------------
apply('T02', [
    ('| `legacyRefs` | `{ procoopCodUser, procoopWsUser }` | No | Migración (T07) |',
     '| `legacy` | Subdocumento `legacy` de T05 §19.1 (`table`, `key` = código de usuario ProCoop o usuario de servicio web; antes `legacyRefs` con `procoopCodUser` y `procoopWsUser`, CTR-DAT-32) | No | Migración (T07) |'),
    ('Repetible (T07) e idempotente por `legacyRefs`.',
     'Repetible (T07) e idempotente por `legacy` y `legacyIdMap` (T07).'),
    ('| `pwa.planObra.ver` | Ver en la PWA el plan de cuotas de obra',
     '| `por.planObra.ver` | (antes `pwa.planObra.ver`; prefijo del módulo dueño M19) Ver en la PWA el plan de cuotas de obra'),
    ('o código enviado al contacto registrado de la persona en M01,',
     'o código de un solo uso enviado al contacto verificado del titular en M01 (RF-POR-179 de M19),'),
], 'f3-g6-t02')
p = fpath('T02'); L = read(p).split('\n')
i = [k for k, l in enumerate(L) if l.startswith('| CTR-IAM-22 ')][0]
L.insert(i + 1, '| CTR-IAM-23 | Nombres de T02 (`legacyRefs`, `pwa.planObra.ver`) vs T05 §19.1 y convención de capabilities por módulo dueño | Clave de origen ad hoc y prefijo de capability sin módulo. | Subdocumento `legacy`; capability `por.planObra.ver` (M19). Los nombres viejos quedan solo en las notas de alias. | CTR-DAT-32; convención de capabilities |')
write(p, '\n'.join(L))

# ---------------- T04 ----------------
apply('T04', [
    ('`legacyCode` (`SITIVA.COD_SIT`)', '`legacy` (`SITIVA.COD_SIT`)'),
    ('| `BARRIOS` | `neighborhoods` | Directo con `legacyCode`. |', '| `BARRIOS` | `neighborhoods` | Directo con `legacy.key`. |'),
    ('`legacyRefs` (`TABINFL.COD_TAB`, `TABMORA.COD_TAB`, `TIPO_FAC`)', '`legacy` (`TABINFL.COD_TAB`, `TABMORA.COD_TAB` o `TIPO_FAC`; antes `legacyRefs`)'),
    (', `legacyCode` |', ', `legacy` |', 0),
], 'f3-g6-t04')
p = fpath('T04'); s = read(p)
assert '`legacyCode`' not in s, 'quedan legacyCode'
L = s.split('\n')
i = [k for k, l in enumerate(L) if l.startswith('| CTR-CFG-23 ')][0]
L.insert(i + 1, '| CTR-CFG-24 | Campos de origen de T04 (`legacyCode` en geografía y tablas fiscales, `legacyRefs` en `economicIndexSeries`) vs T05 §19.1 | Campos de migración ad hoc. | Subdocumento `legacy` (`table`, `key`) en todas las colecciones de T04; `legacyIdMap` de T07 traduce claves. | CTR-DAT-32 |')
write(p, '\n'.join(L))

# ---------------- T08 ----------------
apply('T08', [
    ('A validar (PA-NFR-01)', 'Adoptado (DEC-063)', 2),
    ('con estrategia de archivo por antigüedad (en línea ≥ 24 meses, luego archivo consultable en frío según PRM-NFR-040 a 055) definida en T05;',
     'con estrategia de archivo por antigüedad (en línea 36 meses para el detalle —renglones de comprobantes, lecturas de intervalo, llamadas, bitácoras y detalle de cobranzas— y luego archivo cifrado con consulta diferida y trazabilidad según PRM-NFR-040 a 055; comprobantes, recibos y asientos con sus PDF quedan siempre en línea; DEC-087, T05 §7.8.2; antes "en línea ≥ 24 meses") definida en T05;'),
    ('Índices `{ tenantId, personId, purposeCode, status }`; `{ tenantId, purposeCode, status }`. Nunca se edita: revocar crea un estado nuevo con auditoría.',
     'Índices `{ tenantId, personId, purposeCode, status }`; `{ tenantId, purposeCode, status }`. Nunca se edita: revocar crea un estado nuevo con auditoría. '
     'Campos que usa T09 (COL-COM-50 absorbida, CTR-DAT-18): `contactPointId` (ObjectId → M01), `address` (`{ hash, masked }`), `action` (`opt_in` → `otorgado`, `opt_out` → `revocado`), `source` (enum `portal`, `counter`, `import`, `keyword_stop`, `unsubscribe_link`, `migration`, `admin`), `textShown` y `textVersion` (texto exhibido y su versión, además de `noticeId`/`noticeVersion`), `actorUserId`, `occurredAt`, `evidenceRef`; el `purpose` de T09 es `purposeCode`, el `ipHash` va en `evidence.ipTruncated` y el agente de usuario se guarda solo como `evidence.userAgentHash`. Índice adicional `{ tenantId, personId, channel, purposeCode, occurredAt }` para la consulta de preferencias vigentes de T09.'),
], 'f3-g6-t08')
p = fpath('T08'); L = read(p).split('\n')
i = [k for k, l in enumerate(L) if l.startswith('| CTR-NFR-22 ')][0]
L.insert(i + 1, '| CTR-NFR-23 | T08 RNF-NFR-259 ("en línea ≥ 24 meses") y `consentRecords` de T08 vs DEC-087 y `consentRecords` de T09 | Plazo en línea del detalle y esquema de consentimientos con dos versiones. | Detalle en línea 36 meses y archivo con consulta diferida (DEC-087); `consentRecords` de T08 admite los campos de T09 (RF-NFR-004). | DEC > anexo; CTR-DAT-18 |')
write(p, '\n'.join(L))

# ---------------- T01 ----------------
apply('T01', [
    ('Adoptado / A validar (PA-PLA-03)', 'Adoptado (DEC-063)', 1),
    ('A validar (PA-PLA-03)', 'Adoptado (DEC-063)', 2),
    ('A validar (PA-PLA-02)', 'Adoptado (DEC-063)', 1),
    ('A validar (PA-PLA-01)', 'Adoptado (DEC-062)', 1),
    ('A validar (PA-PLA-08)', 'Adoptado (DEC-065)', 2),
    ('| DEC-025 (copias entre tenants con autorización explícita del tenant origen) | Sin requisito propio: la copia es de M02 y la recibe T04 como versión en borrador; el acceso de soporte entre tenants sigue la concesión de T02 |',
     '| DEC-025 (copias entre tenants con autorización explícita del tenant origen) | Reemplazado por RF-PLA-164 y RN-PLA-051. Texto anterior: sin requisito propio: la copia es de M02 y la recibe T04 como versión en borrador; el acceso de soporte entre tenants sigue la concesión de T02 |'),
    ('| DEC-026 (plantillas de plataforma sin precios ni condiciones reguladas) | RF-PLA-070 (la oferta la crea el tenant; las plantillas las define M02) |',
     '| DEC-026 (plantillas de plataforma sin precios ni condiciones reguladas) | RF-PLA-165 y RN-PLA-052; además RF-PLA-070 (la oferta la crea el tenant; las plantillas de servicio las define M02) |'),
], 'f3-g6-t01')
p = fpath('T01'); L = read(p).split('\n')
assert not any(l.startswith('### 5.R.') for l in L)
i = [k for k, l in enumerate(L) if l.startswith('### 5.Q. ')][0]
j = i + 1
while not L[j].startswith('---'):
    j += 1
new = [
    '### 5.R. Copias entre tenants y plantillas de plataforma (DEC-025, DEC-026)',
    '',
    '| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |',
    '|---|---|---|---|---|---|---|',
    '| RF-PLA-164 | **Copia de configuración entre tenants** con autorización explícita del tenant origen: el administrador del tenant origen otorga una autorización registrada (tenant destino, alcance —capacidad o servicio y versión de configuración—, vigencia y motivo), revocable en cualquier momento; la copia la ejecuta un operador de plataforma o el tenant destino desde el tenant `PLATFORM` con un contexto de solo lectura sobre el origen; se copian solo datos de configuración (fichas de servicio, productos, planes, categorías, estados, reglas y parámetros), nunca datos personales, cuentas, contratos, saldos, documentos, credenciales ni claves de integración; el destino recibe la copia como versión en borrador (`configVersions` de T04) que su administrador revisa y publica; la autorización, la lectura y la escritura quedan en `auditLogs` de ambos tenants. El contenido funcional de la copia es de M02 (RF-CAT-104 a 108). | DEC-025; BASE §81; RF-CAT-108 | Núcleo | O2 | Adoptado (DEC-025) | Sin autorización vigente del origen la copia responde 403 y queda auditada en ambos tenants; con autorización, el destino ve un borrador y el origen ve quién leyó qué y cuándo. |',
    '| RF-PLA-165 | **Plantillas de plataforma**: catálogo global del tenant `PLATFORM` de plantillas versionadas (servicios de M02 y otras plantillas de configuración que publiquen los módulos) que no contienen precios, importes, cuadros tarifarios, condiciones reguladas (plazos legales, cargos o topes fijados por el regulador), referencias a tenants ni datos personales; las publica un rol de plataforma con una validación automática que rechaza esos campos; el tenant adopta una plantilla y obtiene una copia propia independiente, en borrador, que completa con sus precios y condiciones; publicar una versión nueva de la plantilla no modifica las copias ya adoptadas (se informa la novedad). | DEC-026; DFA M4 mejora "plantillas reutilizables"; RF-CAT-109 | Estándar | O2 | Adoptado (DEC-026) | Una plantilla con un precio o un cuadro tarifario no se puede publicar; un tenant nuevo adopta "Internet FTTH base" y define sus precios sin afectar a otros tenants. |',
    '',
]
L[j:j] = new
k = [n for n, l in enumerate(L) if l.startswith('| RN-PLA-050 ')][0]
L[k + 1:k + 1] = [
    '| RN-PLA-051 | Una copia entre tenants requiere una autorización vigente del tenant origen con alcance que cubra lo copiado; sin ella no hay lectura del origen. La copia nunca transporta datos personales ni datos de operación, y el destino la recibe en borrador. | No existe (cada cooperativa es una base aparte). | **Adoptar** (DEC-025). | PRM-CAT-103 | — |',
    '| RN-PLA-052 | Una plantilla de plataforma no contiene precios, importes ni condiciones reguladas, ni referencias a tenants; la adopción crea una copia independiente del tenant. | No existe. | **Adoptar** (DEC-026). | — | — |',
]
write(p, '\n'.join(L))
print('fase 3 G6 ok')
