﻿from repl import *
apply('M03', [('| `per.serviceContract.activated` / `suspended` / `terminated` / `holderChanged` | M01 |',
 '| `cat.contract.activated` (EVT-CAT-09) / `cat.contract.suspended` (EVT-CAT-10) / `cat.contract.terminated` (EVT-CAT-15) / `cat.contract.transferred` (EVT-CAT-17, cambio de titular) | M02 |')])
apply('M10', [('1. M08 emite `mor.suspension.ordered { contractId, orderId, mode }`.',
 '1. M08 emite `mor.interruption.approved` (EVT-MOR-12, tipo suspensión) `{ contractId, orderId, mode }`.')])
