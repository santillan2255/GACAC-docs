import sys, re, os
sys.stdout.reconfigure(encoding='utf-8')
B = r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno'
want = set(sys.argv[1:])
for f in ['06d-estados-m05-m07.md', '06e-estados-m07-m09.md', '06f-estados-m09-m12.md']:
    lines = open(os.path.join(B, f), encoding='utf-8').read().split('\n')
    for i, l in enumerate(lines):
        m = re.match(r'^### (EST-(COB|MOR|CRM|TEC|VEN)-\d+) [-—] `([^`]+)`', l)
        if m and (not want or m.group(3).split('.')[0] in want):
            info = lines[i + 2] if i + 2 < len(lines) else ''
            mm = re.search(r'Campos de estado en el §7:\*\* (.*)$', info)
            print(m.group(1), m.group(3), '|', (mm.group(1) if mm else info)[:300])
            # transiciones existentes
            for j in range(i + 3, min(i + 80, len(lines))):
                if lines[j].startswith('### '):
                    break
                if re.match(r'^\| (T|P|I)\d+ \|', lines[j]):
                    c = [x.strip() for x in lines[j].split('|')]
                    print('     ', c[2], '->', c[3])
