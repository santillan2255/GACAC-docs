import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from repl import apply

P = []

# Encabezado
P.append(("| Olas | O0 (registro de parámetros y lector tipado como librería compartida)",
          "| Olas | O0 (registro de parámetros y lector tipado como librería compartida; `legalEntities` y `branches` con `legalEntityId` obligatorio en los documentos económicos, DEC-064 / REQ-DEC-064)"))
P.append(("`seedApplications`, `legacyParameterMappings`. Esquema compartido `geoReference`",
          "`seedApplications`, `legacyParameterMappings`, `legalEntities` (COL-CFG-41), `branches` (COL-CFG-42), `workstations` (COL-CFG-43) y las tablas legales de sueldos de plataforma `payrollOfficialCodes` … `laborLawParameters` (COL-CFG-44 a 53, §7.17; CTR-DAT-73). Absorciones de T05: `vatConditions`, `vatRates`, `grossIncomeConditions`, `grossIncomeRates`, `taxRegistries` y `taxRegistryEntries` pasan a M06 (COL-FIS-15 a 21, CTR-DAT-13); `savedViews` pasa a `dataTableViews` de T03 (CTR-DAT-11); `sequences` pasa a `numberingSequences` de T11 y `numberSequences` de M05 (CTR-DAT-16). Esquema compartido `geoReference`"))

# 2.1
P.append(("| 10 | **Tablas fiscales de referencia** (condiciones de IVA, alícuotas de IVA, condiciones de IIBB, alícuotas de IIBB por jurisdicción, tipos de documento con códigos ARCA/INAES/ENARGAS/OCEBA) y **padrones** (ingesta, vigencia, consulta por CUIT). |",
          "| 10 | **Tablas fiscales de referencia** (condiciones de IVA, alícuotas de IVA, condiciones de IIBB, alícuotas de IIBB por jurisdicción, tipos de documento con códigos ARCA/INAES/ENARGAS/OCEBA) y **padrones** (ingesta, vigencia, consulta por CUIT). **Reemplazado por M06 (CTR-DAT-13)** salvo los tipos de documento (`identityDocumentTypes`) y el mecanismo de publicación y adopción de tablas de plataforma (§7.10), que siguen en CFG. |"))
P.append(("| 12 | **Personalización acotada de formularios** y **vistas guardadas** de grillas (reemplazo del motor de pantallas configurable de ProCoop). |",
          "| 12 | **Personalización acotada de formularios** y **vistas guardadas** de grillas (reemplazo del motor de pantallas configurable de ProCoop). Las vistas guardadas: **Reemplazado por `dataTableViews` de T03 (CTR-DAT-11)**. |"))
P.append(("| 15 | Vista de **completitud del perfil de configuración por servicio** (BASE §84, §93) a partir de las dependencias declaradas por cada módulo. |",
          "| 15 | Vista de **completitud del perfil de configuración por servicio** (BASE §84, §93) a partir de las dependencias declaradas por cada módulo. |\n"
          "| 16 | **Entidades jurídicas y sucursales del tenant** (DEC-064, O0): `legalEntities` con los datos legales y fiscales básicos de cada entidad emisora, la entidad por defecto creada con el tenant y el subdocumento `employer` que completa M16; `branches` con su entidad jurídica; `workstations` (puestos físicos, O1); resolución de la entidad de un documento económico (§5.18, §7.14 a §7.16). |\n"
          "| 17 | **Tablas legales de sueldos de plataforma** (códigos oficiales, alícuotas, topes, SMVM, Ganancias, embargabilidad, LCT) con fuente, vigencia y adopción por tenant (§7.17, CTR-DAT-73, O9). |"))

# 2.2
P.append(("| Ciclo de vida del tenant, licencias, módulos contratados/activados, perfil legal de la cooperativa (razón social, CUIT, domicilio, IIBB, inicio de actividades, logo — variables 518–527 y 709), sucursales como estructura organizacional, anuncios del proveedor | T01 PLA |",
          "| Ciclo de vida del tenant, licencias, módulos contratados/activados, perfil legal de la cooperativa (razón social, CUIT, domicilio, IIBB, inicio de actividades, logo — variables 518–527 y 709), sucursales como estructura organizacional, anuncios del proveedor. **Perfil legal y sucursales: Reemplazado por RF-CFG-134 y RF-CFG-140 (DEC-064)**: viven en `legalEntities` y `branches` de este anexo; T01 conserva el alta del tenant y sus datos de contratación, con los que se crea la entidad por defecto (§9.16); el logo es marca de T03 | T01 PLA |"))
P.append(("CVP por punto de venta (`CVPIIBB`), puntos de venta ARCA (`PTOVENTA`) | M06 FIS |",
          "CVP por punto de venta (`CVPIIBB`), puntos de venta ARCA (`PTOVENTA`, con `legalEntityId`), perfil fiscal completo de cada entidad jurídica (agente de percepción/retención, credenciales ARCA), tablas fiscales de referencia y padrones (CTR-DAT-13) | M06 FIS |"))

# 3 Glosario
P.append(("| Equivalencia legacy | Correspondencia `tabla + COD_VAR (+ MOD_VAR)` → clave GoodApps con regla de transformación. | `dict:cfg.glosario.equivalenciaLegacy` | — |",
          "| Equivalencia legacy | Correspondencia `tabla + COD_VAR (+ MOD_VAR)` → clave GoodApps con regla de transformación. | `dict:cfg.glosario.equivalenciaLegacy` | — |\n"
          "| Entidad jurídica | Persona jurídica del tenant que emite documentos económicos, lleva contabilidad y emplea personal (cooperativa, mutual o sociedad vinculada). Un tenant tiene una o más (DEC-064). | `dict:cfg.glosario.entidadJuridica` | `EMPRESAS`; `SU_EMPRESAS` (empleador) |\n"
          "| Entidad por defecto | Entidad jurídica marcada `isDefault`, creada con el tenant; se usa cuando ninguna regla resuelve otra. | `dict:cfg.glosario.entidadPorDefecto` | Empresa única del `.pro` |\n"
          "| Sucursal | Lugar físico de la cooperativa (atención, caja, depósito, puntos de venta) que pertenece a una entidad jurídica. | `dict:cfg.glosario.sucursal` | Sucursal de `EMPRESAS`/`CAJASJP` [VERIFICAR] |\n"
          "| Puesto | Equipo o posición física de trabajo dentro de una sucursal (mostrador, caja, oficina) al que se asocian dispositivos y el agente local. | `dict:cfg.glosario.puesto` | `EQUIPOS` |"))

# 4 Actores
P.append(("`cfg.vistas.compartir`, `cfg.tecnica.ver`, `cfg.adopciones.configurar` | Tenant completo |",
          "`cfg.vistas.compartir`, `cfg.tecnica.ver`, `cfg.adopciones.configurar`, `cfg.entidadesJuridicas.ver/editar`, `cfg.sucursales.ver/editar`, `cfg.puestos.editar` (DEC-064) | Tenant completo |"))
P.append(("| Responsable fiscal del tenant | `cfg.fiscal.ver`, `cfg.fiscal.configurar` (adopciones, alícuotas propias), `cfg.padrones.importar` | Tenant |",
          "| Responsable fiscal del tenant | `cfg.fiscal.ver`, `cfg.fiscal.configurar` (adopciones, alícuotas propias), `cfg.padrones.importar`, `cfg.entidadesJuridicas.ver` | Tenant |\n"
          "| Responsable de sueldos (M16) | `sue.estructura.configurar` para editar solo el subdocumento `employer` de `legalEntities` (API-CFG-55); `cfg.entidadesJuridicas.ver` | Entidades jurídicas que emplean personal |"))

# 5.7 DEC-046 / DEC-020
P.append(("| BASE §77 GEO-001; §79 GEO-F2 | Núcleo | O1 | A validar (PA-CFG-02) |",
          "| BASE §77 GEO-001; §79 GEO-F2; DEC-046 | Núcleo | O1 | Adoptado (DEC-046) |"))
P.append(("| BASE §77, §79 GEO-F1, GEO-F5 | Núcleo | O1 | A validar (PA-CFG-02) |",
          "| BASE §77, §79 GEO-F1, GEO-F5; DEC-046 | Núcleo | O1 | Adoptado (DEC-046) |"))
P.append(("el servicio devuelve candidatos (Georef normalización + Google geocodificación) con precisión declarada; nunca presenta precisión no disponible. | BASE §77 GEO-002, §79 GEO-F3, GEO-F4 |",
          "el servicio devuelve candidatos con precisión declarada; nunca presenta precisión no disponible. Georef normaliza y geocodifica; Google Maps se usa para el mapa y el autocompletado (corregido por DEC-046; antes \"Georef normalización + Google geocodificación\"). | BASE §77 GEO-002, §79 GEO-F3, GEO-F4; DEC-046 |"))
P.append(("| BASE §77 GEO-003; INV `ctrlMapa`, `ctrlMapaBase`, `frmVisorMapa` |",
          "| BASE §77 GEO-003; INV `ctrlMapa`, `ctrlMapaBase`, `frmVisorMapa`; DEC-046 |"))
P.append(("| BASE §77 (\"sin presuponer consultas ilimitadas\"), §80 | Núcleo | O1 | A validar (PA-CFG-04) |",
          "| BASE §77 (\"sin presuponer consultas ilimitadas\"), §80; DEC-020 | Núcleo | O1 | Adoptado (DEC-020) |"))

# 5.10 tablas fiscales
P.append(("### 5.10 Tablas fiscales comunes y padrones\n",
          "### 5.10 Tablas fiscales comunes y padrones\n\n> **Reemplazado por M06 (CTR-DAT-13).** Las tablas fiscales de referencia y los padrones son de M06 (`vatConditionSettings`, `vatRates`, `grossIncomeSettings`, `taxpayerRegistries`, `taxpayerRegistryEntries`, COL-FIS-15 a 21). Se conservan las filas como origen. Siguen en CFG RF-CFG-100 (tipos de documento), RF-CFG-101 (mecanismo de publicación de tablas de plataforma, que M06 usa) y RF-CFG-103 (enumeraciones de entes reguladores).\n"))
P.append(("| CAT `SITIVA`; INV `abm_sit_iva` | Núcleo | O2 | Adoptado |",
          "| CAT `SITIVA`; INV `abm_sit_iva` | Núcleo | O2 | Reemplazado por M06 `vatConditionSettings` (COL-FIS-15, CTR-DAT-13) |"))
P.append(("| Núcleo | O4 | Adoptado | 21 % (código 5) y 10,5 % (código 4) vigentes. |",
          "| Núcleo | O4 | Reemplazado por M06 `vatRates` (COL-FIS-16, CTR-DAT-13) | 21 % (código 5) y 10,5 % (código 4) vigentes. |"))
P.append(("| Núcleo | O4 | Adoptado | Alícuota de una actividad en Córdoba consultable a fecha. |",
          "| Núcleo | O4 | Reemplazado por M06 `grossIncomeSettings` (COL-FIS-19, CTR-DAT-13) | Alícuota de una actividad en Córdoba consultable a fecha. |"))
P.append(("| Núcleo | O4 | A validar (PA-CFG-05) | Un CUIT con dos vigencias devuelve la correcta para cada fecha. |",
          "| Núcleo | O4 | Reemplazado por M06 `taxpayerRegistries`/`taxpayerRegistryEntries` (COL-FIS-20/21, CTR-DAT-13); PA-CFG-05 pasa a M06 | Un CUIT con dos vigencias devuelve la correcta para cada fecha. |"))

# 5.13 savedViews
P.append(("| Núcleo | O1 | Adoptado | Compartir una vista por rol la ofrece a todos los usuarios del rol. |",
          "| Núcleo | O1 | Reemplazado por `dataTableViews` de T03 (CTR-DAT-11); el requisito se conserva como criterio para T03 | Compartir una vista por rol la ofrece a todos los usuarios del rol. |"))

# 5.18 nueva sección
P.append(("| RNF-CFG-008 | Accesibilidad y diccionario: ninguna etiqueta fija en pantallas de CFG; todas por `dict:`. | BASE §65 | Núcleo | O1 | Adoptado | Linter de i18n. |\n",
          "| RNF-CFG-008 | Accesibilidad y diccionario: ninguna etiqueta fija en pantallas de CFG; todas por `dict:`. | BASE §65 | Núcleo | O1 | Adoptado | Linter de i18n. |\n\n"
          "### 5.18 Entidades jurídicas, sucursales y puestos (DEC-064)\n\n"
          "| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |\n"
          "|---|---|---|---|---|---|---|\n"
          "| RF-CFG-134 | **Entidades jurídicas del tenant** (`legalEntities`, §7.14): cada tenant tiene una o más entidades jurídicas con código, razón social, nombre de fantasía, CUIT, condición frente al IVA, régimen de IIBB, domicilio legal, inicio de actividades, estado, entidad por defecto y vigencia. El CUIT es único dentro del tenant. ABM en PAN-CFG-33 con `cfg.entidadesJuridicas.ver/editar`. | DEC-064; REQ-DEC-064 (PRO-O0-13); CTR-DAT-06, CTR-DAT-48; T05 COL-CFG-41; HUE fase 2 G6 | Núcleo | O0 | Adoptado | Un segundo alta con el mismo CUIT en el tenant se rechaza; el mismo CUIT en otro tenant se acepta. |\n"
          "| RF-CFG-135 | **Entidad por defecto**: al consumir `pla.tenant.created` se crea en la misma unidad idempotente la entidad jurídica por defecto (`isDefault = true`) con los datos fiscales de `tenants` (razón social, CUIT, forma jurídica, matrícula INAES, domicilio). Hay exactamente una entidad por defecto activa por tenant; cambiarla es una operación explícita que desmarca la anterior. | DEC-064; REQ-DEC-064 | Núcleo | O0 | Adoptado | TEN-001 tiene su entidad por defecto apenas se crea y no ve la de TEN-002; reprocesar el evento no crea una segunda. |\n"
          "| RF-CFG-136 | **`legalEntityId` obligatorio** en el esquema base de los documentos económicos (paquete compartido de esquemas Zod, `packages/shared`) desde O0: `pointsOfSale`, `numberSequences`, `fiscalProfiles`, `arcaCredentials`, `invoices`, `invoiceDrafts`, `paymentSlips`, `receipts`, `obligations`, `ledgerEntries`, `currentAccounts`, `fiscalAuthorizations`, `withholdingsApplied`, `vatLedgers`, `regimeFilings`, `taxObligations`, `journalEntries`, `chartOfAccounts`, `fiscalYears`, `treasuryAccounts`, `treasuryMovements`, `supplierInvoices`, `paymentOrders`, `purchaseOrders`, `salesOrders`, `payrollRuns`, `payslips`, `employees` (como empleador), `statutoryFilings`, `capitalMovements` (lista de T05 §7.1). El validador comprueba que la entidad exista, sea del mismo tenant y esté activa a la fecha del documento. Un documento emitido no cambia de entidad: se corrige con documento vinculado. | DEC-064; REQ-DEC-064; T05 §7.1 | Núcleo | O0 | Adoptado | Un documento económico sin `legalEntityId` no valida; uno con la entidad de otro tenant devuelve 422. |\n"
          "| RF-CFG-137 | **Resolución de la entidad** de un documento nuevo (servicio interno `legalEntities.resolve({ branchId, serviceId, at })`, API-CFG-58): 1) la indicada explícitamente por el usuario con permiso; 2) la emisora del servicio (PRM-CFG-040, ámbito `service`); 3) la de la sucursal (`branches.legalEntityId`); 4) la entidad por defecto. Con PRM-CFG-039 = false (una sola entidad) los selectores se ocultan y siempre se usa la por defecto. | DEC-064 | Núcleo | O0 | Adoptado | Un servicio de la mutual configurado con su entidad emite con ella aunque la sucursal sea de la cooperativa. |\n"
          "| RF-CFG-138 | **Datos fiscales por entidad**: T04 guarda solo los datos legales básicos de REQ-DEC-064. El perfil fiscal completo (agente de percepción o retención, puntos de venta ARCA, credenciales, CAEA) es de M06 por `legalEntityId` y se construye en O4; la contabilidad (M15), la tesorería (M14) y los sueldos (M16) se segmentan por la misma entidad. Los documentos guardan una copia de los datos de la entidad al emitirse. | DEC-064; REQ-DEC-064 (\"NO CONSTRUIR TODAVÍA: datos fiscales completos, M06 en O4\") | Núcleo | O0 | Adoptado | Cambiar el domicilio legal no altera las facturas ya emitidas. |\n"
          "| RF-CFG-139 | **Subdocumento `employer`** de `legalEntities` para sueldos (tipo de empleador, actividad principal, zona, régimen de contribuciones, ART, seguro de vida, agente de retención de Ganancias, recibos y firma, convenios bancarios, LSD), que define y edita M16 con `sue.estructura.configurar` por API-CFG-55. Absorbe `employers` de M16 (CTR-DAT-06); `employerId` se reemplaza por `legalEntityId`. | CTR-DAT-06; DEC-064; M16 RF-SUE-022 | Núcleo | O9 | Adoptado | Dos entidades del tenant generan LSD, SICOSS y asientos de sueldos por separado. |\n"
          "| RF-CFG-140 | **Sucursales** (`branches`, §7.15): código, nombre, entidad jurídica, localidad, domicilio georreferenciado, usos (atención, caja, depósito, punto de venta, base técnica), horarios, calendario local y estado. Al crear el tenant se crea la sucursal \"Casa central\" de la entidad por defecto. Es la referencia del ámbito `branch` de parámetros (§14.3) y de la dimensión de alcance por sucursal de T02. | DEC-064; T05 COL-CFG-42; T01 §2 (sucursales → T04) | Núcleo | O0 | Adoptado | Una sucursal no puede apuntar a una entidad inactiva; inactivar una sucursal con cajas abiertas se rechaza. |\n"
          "| RF-CFG-141 | **Puestos** (`workstations`, §7.16): puestos físicos de cada sucursal con su agente local (M09) y dispositivos declarados; el puesto no es ámbito de configuración (PA-CFG-06). ABM con `cfg.puestos.editar`. | T05 COL-CFG-43; T02 §4.4 `cfg.puestos.editar` | Estándar | O1 | Adoptado | Un puesto pertenece a una sola sucursal y su código es único en el tenant. |\n"
          "| RF-CFG-142 | **Migración**: `EMPRESAS` → `legalEntities` (la empresa principal queda `isDefault`); `SU_EMPRESAS` → subdocumento `employer` de la entidad con el mismo CUIT, o entidad nueva si no existe; sucursales de `EMPRESAS`/`CAJASJP` → `branches` [VERIFICAR origen]; `EQUIPOS`/puestos → `workstations` [VERIFICAR]. Lo ejecuta T07. | DEC-064; CTR-DAT-48; T05 COL-CFG-41 a 43 | Núcleo | O11 | Adoptado | Cada fila de `EMPRESAS` y `SU_EMPRESAS` tiene destino; ningún CUIT queda duplicado. |\n"
          "| RF-CFG-143 | **Tablas legales de sueldos de plataforma** (§7.17): códigos oficiales, alícuotas de aportes y contribuciones, bases mínima y máxima, SMVM, deducciones y escalas de Ganancias, reglas de Ganancias, escala cedular, escala de embargabilidad y parámetros de la LCT, con fuente, vigencia y publicación por `platformTableRelease`; el tenant las adopta por `platformTableAdoptions` (absorbe `officialTableAdoptions` de M16). | CTR-DAT-73; T05 COL-CFG-44 a 53; M16 §7.45 | Núcleo | O9 | Adoptado | Un cambio de SMVM con vigencia futura no afecta liquidaciones de períodos anteriores. |\n"))

# 6 Reglas
P.append(("| Variables 518–527, 709 (RN-09 §3, §6.3). | Reemplazar por T01. | — | — |",
          "| Variables 518–527, 709 (RN-09 §3, §6.3). | Reemplazar por T01. **Corregido (DEC-064):** la identidad legal y fiscal vive en `legalEntities` de este anexo (RF-CFG-134); T01 conserva los datos de contratación del tenant y T03 el logo. | — | — |"))
P.append(("| RN-CFG-050 | Zonas, barrios y distritos son maestros territoriales sin importes; los cargos por zona se configuran en tarifas (M04). | `ZONAS.IMPORTE`, `REC_BALDIO`. | Reemplazar. | — | — |\n",
          "| RN-CFG-050 | Zonas, barrios y distritos son maestros territoriales sin importes; los cargos por zona se configuran en tarifas (M04). | `ZONAS.IMPORTE`, `REC_BALDIO`. | Reemplazar. | — | — |\n"
          "| RN-CFG-051 | Siempre existe exactamente una entidad jurídica activa con `isDefault = true` por tenant; no se puede inactivar la entidad por defecto sin marcar antes otra. | Empresa única por `.pro`. | Mejorar (DEC-064). | PRM-CFG-039 | — |\n"
          "| RN-CFG-052 | El CUIT de una entidad no se edita después de que la entidad tenga documentos económicos: un CUIT distinto es una entidad nueva (PA-CFG-14). Razón social, domicilio y condición fiscal cambian con vigencia y quedan en la historia. | `EMPRESAS` editable sin control. | Mejorar (DEC-064, AGR-010). | — | — |\n"
          "| RN-CFG-053 | Una entidad jurídica o una sucursal referenciada por documentos no se borra: se inactiva; inactiva no se puede asignar a documentos nuevos. | Borrado físico. | Mejorar. | — | — |\n"
          "| RN-CFG-054 | Una sucursal pertenece a una sola entidad jurídica a la vez; cambiarla tiene fecha efectiva y no altera documentos emitidos. | — | Adoptar (DEC-064). | — | — |\n"
          "| RN-CFG-055 | La entidad jurídica no es un ámbito del motor de parámetros: lo que varía por entidad se configura en el dueño (M06 perfil fiscal, M15 planes, M16 `employer`) o por servicio (PRM-CFG-040). | — | Adoptar. | — | — |\n"))

# 7.9 / 7.11 / 7.13
P.append(("### 7.9 Tablas fiscales y padrones\n",
          "### 7.9 Tablas fiscales y padrones\n\n> **Reemplazado por M06 (CTR-DAT-13):** `vatConditions` → `vatConditionSettings` (COL-FIS-15), `vatRates` → `vatRates` de M06 (COL-FIS-16), `grossIncomeConditions` y `grossIncomeRates` → `grossIncomeSettings` (COL-FIS-19), `taxRegistries` → `taxpayerRegistries` (COL-FIS-20), `taxRegistryEntries` → `taxpayerRegistryEntries` (COL-FIS-21). La tabla se conserva como referencia de origen; `identityDocumentTypes` sigue en T04.\n"))
P.append(("`savedViews`: `screenKey`, `ownerUserId` (null si compartida)",
          "**Reemplazado por `dataTableViews` de T03 (CTR-DAT-11).** `savedViews`: `screenKey`, `ownerUserId` (null si compartida)"))
P.append(("| `MAPA` | `parameterValues` (`cfg.geo.centroMapa`, `cfg.geo.zoomInicial` por módulo) | — |\n",
          "| `MAPA` | `parameterValues` (`cfg.geo.centroMapa`, `cfg.geo.zoomInicial` por módulo) | — |\n"
          "| `EMPRESAS` | `legalEntities` (§7.14) | La principal queda `isDefault`; CUIT único (RF-CFG-142). |\n"
          "| `SU_EMPRESAS`, `SU_TIPOEMPLEADOR` | `legalEntities.employer` (match por CUIT) | CTR-DAT-06. |\n"
          "| Sucursales de `EMPRESAS`/`CAJASJP` [VERIFICAR] | `branches` (§7.15) | — |\n"
          "| `EQUIPOS` / puestos [VERIFICAR] | `workstations` (§7.16) | Dispositivos y agente local en M09. |\n"
          "| `SU_ACTIVIDADES`, `SU_CONDICION`, `SU_CONTRATACION`, `SU_SITUACION_REVISTA`, `SU_SINIESTRADO`, `SU_BENEFICIOS_SICOSS`, `SU_OBRA`, `SU_SALARIO_MINIMO`, `SU_DEDUCCIONES*`, `SU_TRAMAS*` | Tablas legales de sueldos (§7.17) | CTR-DAT-73. |\n"))

# 7.14-7.17 antes de ## 8
P.append(("\n## 8. Estados y transiciones\n",
          "\n### 7.14 `legalEntities` (tenant; COL-CFG-41; DEC-064; O0)\n\n"
          "Entidades jurídicas emisoras del tenant. Campos comunes de T05 (`tenantId`, auditoría, `version`).\n\n"
          "| Campo | Tipo | Oblig. | Descripción |\n|---|---|---|---|\n"
          "| `code` | string (`^[A-Z0-9-]{2,12}$`) | Sí | Código corto único en el tenant (ej. `COOP`, `MUTUAL`). |\n"
          "| `legalName` | string | Sí | Razón social. |\n"
          "| `tradeName` | string | No | Nombre de fantasía para documentos. |\n"
          "| `legalForm` | enum `cooperativa`, `mutual`, `asociacionCivil`, `sociedad`, `otra` | Sí | Forma jurídica (mismos valores que `tenants.legalForm` de T01). |\n"
          "| `inaesRegistration` | string | No | Matrícula INAES (cooperativas y mutuales). |\n"
          "| `fiscal` | objeto | Sí | `cuit` (11 dígitos con dígito verificador), `ivaConditionCode` (código ARCA de condición frente al IVA; desde O4 validado contra `vatConditionSettings` de M06), `iibbRegime` (`local`, `multilateral`, `simplified`, `exempt`, `notRegistered`), `iibbNumber`, `activityStartDate` (date). |\n"
          "| `address` | subdocumento domicilio con `geoReference` (§7.6) | Sí | Domicilio legal y fiscal. |\n"
          "| `contact` | `{ email, phone }` | No | Contacto institucional para documentos. |\n"
          "| `brandingVariantKey` | string | No | Variante de marca de `tenantBrandings` (T03) para los documentos de esta entidad; sin valor usa la del tenant. |\n"
          "| `isDefault` | boolean | Sí | Entidad por defecto (RN-CFG-051). |\n"
          "| `status` | enum `active`, `inactive` | Sí | §8.9. |\n"
          "| `validFrom`, `validTo` | date | Sí / No | Vigencia de la entidad. |\n"
          "| `changeHistory[]` | `{ field, oldValue, newValue, validFrom, recordedAt, by, reason }` | No | Historia bitemporal de razón social, domicilio y datos fiscales (RN-CFG-052, AGR-010). |\n"
          "| `employer` | objeto | No (lo completa M16 en O9) | Absorbe `employers` de M16 (CTR-DAT-06): `employerTypeCode`, `mainActivityCode`, `zoneCode`, `contributionRegime`, `workplaceAddresses[]`, `workRiskInsurance`, `lifeInsurance`, `incomeTaxAgent`, `payslipVoucherTypeId`, `payslipNumbering`, `payslipSigner` (firmante habilitado en T11, DEC-078), `bankAgreements[]` (con `treasuryAccountId` de M14), `lsdSettings`, `status`. El esquema del subdocumento lo define M16 §7.1. |\n"
          "| `legacy` | `{ table: EMPRESAS\\|SU_EMPRESAS, code }` | No | Origen de migración. |\n\n"
          "Índices: `{ tenantId, code }` único; `{ tenantId, 'fiscal.cuit' }` único; `{ tenantId, isDefault }` único parcial (`isDefault: true, status: 'active'`); `{ tenantId, status }`.\n\n"
          "Los nombres de REQ-DEC-064 (`cuit`, `ivaCondition`, `iibbRegime`, `activityStartDate`, `address`) corresponden a `fiscal.cuit`, `fiscal.ivaConditionCode`, `fiscal.iibbRegime`, `fiscal.activityStartDate` y `address` (CTR-CFG-19).\n\n"
          "### 7.15 `branches` (tenant; COL-CFG-42; DEC-064; O0)\n\n"
          "| Campo | Tipo | Oblig. | Descripción |\n|---|---|---|---|\n"
          "| `code` | string | Sí | Código único en el tenant (ej. `SUC-01`). |\n"
          "| `name` | string | Sí | Nombre visible (por diccionario si el tenant lo traduce). |\n"
          "| `legalEntityId` | ObjectId → `legalEntities` | Sí | Entidad jurídica de la sucursal (RN-CFG-054). |\n"
          "| `localityId` | ObjectId → `localities` | Sí | Localidad. |\n"
          "| `address` | subdocumento domicilio con `geoReference` | Sí | Domicilio de la sucursal. |\n"
          "| `uses` | array enum `attention`, `cashier`, `warehouse`, `pointOfSale`, `technicalBase` | Sí | Usos habilitados; los dueños (M07 cajas, M13 depósitos, M06 puntos de venta, M09 turnero) validan contra estos usos. |\n"
          "| `isHeadquarters` | boolean | Sí | Casa central (una por entidad). |\n"
          "| `openingHours[]` | `{ weekday, from, to }` | No | Horario de atención. |\n"
          "| `calendarCode` | string → `calendars` | No | Calendario local para días hábiles; sin valor usa el del tenant. |\n"
          "| `contact` | `{ email, phone }` | No | — |\n"
          "| `status` | enum `active`, `inactive` | Sí | §8.9. |\n"
          "| `validFrom`, `validTo` | date | Sí / No | Vigencia. |\n"
          "| `legalEntityHistory[]` | `{ legalEntityId, validFrom, validTo, recordedAt, by }` | No | Cambios de entidad con fecha efectiva. |\n"
          "| `legacy` | `{ table, code }` | No | Origen de migración [VERIFICAR]. |\n\n"
          "Índices: `{ tenantId, code }` único; `{ tenantId, legalEntityId, status }`; `{ tenantId, localityId }`.\n\n"
          "### 7.16 `workstations` (tenant; COL-CFG-43; O1)\n\n"
          "Campos: `code` (único en el tenant), `name`, `branchId` → `branches`, `kind` (`counter`, `cashier`, `office`, `kiosk`, `field`), `localAgentId` (agente local de M09, opcional), `devices[]` `{ kind (printer, fiscalPrinter, reader, scanner, cardTerminal), name, localAgentDeviceKey }`, `status` (`active`, `inactive`), `legacy` (`EQUIPOS`). Índices `{ tenantId, code }` único; `{ tenantId, branchId }`. Las cajas (M07) y el turnero (M09) referencian `workstationId`; los atributos técnicos del dispositivo los mantiene M09.\n\n"
          "### 7.17 Tablas legales de sueldos de plataforma (COL-CFG-44 a 53; CTR-DAT-73; O9)\n\n"
          "Tenant `PLATFORM`, con `source` (norma, resolución, URL), `validFrom`, `validTo`, `publishedAt`; publicadas por `platformTableReleases` y adoptadas por `platformTableAdoptions` (§7.10), que absorbe `officialTableAdoptions` de M16. Los feriados que M16 listaba en su §7.45 son los `holidays` de §7.7. El contenido funcional de cada tabla lo define M16 §7.45.\n\n"
          "| COL | Colección | Contenido | Índice | Origen ProCoop |\n|---|---|---|---|---|\n"
          "| COL-CFG-44 | `payrollOfficialCodes` | Códigos oficiales por `type` (actividad, condición, modalidad de contratación, situación de revista, siniestrado, beneficio SICOSS, tipo de empleador, zona, obra social RNOS, concepto ARCA, motivo de egreso, tipo de liquidación) | `{ type, code, validFrom }` | `SU_ACTIVIDADES`, `SU_CONDICION`, `SU_CONTRATACION`, `SU_SITUACION_REVISTA`, `SU_SINIESTRADO`, `SU_BENEFICIOS_SICOSS`, `SU_TIPOEMPLEADOR`, `SU_OBRA` |\n"
          "| COL-CFG-45 | `contributionRates` | Alícuotas de aportes y contribuciones por subsistema, régimen y tipo de empleador | `{ subsystem, regime, employerType, validFrom }` | Clasificaciones SICOSS |\n"
          "| COL-CFG-46 | `contributionBaseLimits` | Bases imponibles mínima y máxima por período | `{ period }` | P2437, P2438 |\n"
          "| COL-CFG-47 | `minimumWages` | SMVM mensual, diario y por hora | `{ validFrom }` | `SU_SALARIO_MINIMO` |\n"
          "| COL-CFG-48 | `incomeTaxDeductionTables` | Deducciones de Ganancias por tipo, año y mes | `{ type, year, month }` | `SU_DEDUCCIONES*` |\n"
          "| COL-CFG-49 | `incomeTaxScales` | Escalas de Ganancias por tipo, año, mes y tramo | `{ type, year, month, from }` | `SU_TRAMAS*` |\n"
          "| COL-CFG-50 | `incomeTaxRules` | Reglas generales de Ganancias | `{ validFrom }` | `clsGanancias` |\n"
          "| COL-CFG-51 | `cedularTaxScales` | Escala de impuesto cedular | `{ validFrom }` | `Impuesto_Cedular` |\n"
          "| COL-CFG-52 | `garnishmentScales` | Escala de embargabilidad | `{ validFrom }` | — |\n"
          "| COL-CFG-53 | `laborLawParameters` | Vacaciones art. 150, licencias art. 158, topes de horas extra, plazos de pago, límite art. 133 | `{ validFrom }` | — |\n\n"
          "## 8. Estados y transiciones\n"))

# 8.9
P.append(("Campo extra: `draft` → `active` (por versión) → `deprecated` (deja de pedirse; valores conservados). Semilla: `applied` → `removed` (retiro en bloque de lo creado por la semilla).\n",
          "Campo extra: `draft` → `active` (por versión) → `deprecated` (deja de pedirse; valores conservados). Semilla: `applied` → `removed` (retiro en bloque de lo creado por la semilla).\n\n"
          "### 8.9 `legalEntities`, `branches` y `workstations`\n\n"
          "| Origen | Destino | Actor | Precondición | Efectos | Reversión |\n|---|---|---|---|---|---|\n"
          "| — | `active` | Sistema (alta del tenant) o administrador (`cfg.entidadesJuridicas.editar`) | CUIT válido y no repetido en el tenant | EVT-CFG-19 `cfg.legalEntity.created` | Inactivar |\n"
          "| `active` | `inactive` | Administrador | No es la entidad por defecto (RN-CFG-051); sin sucursales activas ni documentos abiertos que la requieran | EVT-CFG-19 `cfg.legalEntity.deactivated`; no se asigna a documentos nuevos | Reactivar |\n"
          "| `inactive` | `active` | Administrador | — | EVT-CFG-19 `cfg.legalEntity.updated` | — |\n"
          "| Sucursal `active` | `inactive` | Administrador (`cfg.sucursales.editar`) | Sin cajas abiertas (M07) ni depósitos con stock (M13) | EVT-CFG-20 `cfg.branch.deactivated` | Reactivar |\n\n"
          "Los puestos (`workstations`) siguen el mismo par `active`/`inactive` sin evento propio (EVT-CFG-08 `cfg.masterRecord.changed`).\n"))

# 9.16 / 9.17 antes de ## 10
P.append(("\n## 10. Pantallas\n",
          "\n### 9.16 Alta de la entidad jurídica por defecto (consumo de `pla.tenant.created`)\n\n"
          "1. CFG recibe `pla.tenant.created` (EVT-PLA-01) y lee el tenant con sus datos fiscales (`legalName`, `cuit`, `legalForm`, `inaesRegistration`, `fiscalAddress`).\n"
          "2. En una transacción idempotente por `tenantId` crea la entidad `isDefault = true`, `status = active`, `validFrom` = fecha de alta, y la sucursal `SUC-01` \"Casa central\" (`isHeadquarters = true`, usos `attention` y `cashier`).\n"
          "3. Publica EVT-CFG-19 y EVT-CFG-20 por outbox. Si el tenant es `platform`, no crea entidad. Si falta el CUIT (tenant `demo`), usa los datos ficticios de la semilla (§18.7).\n"
          "4. Reprocesar el evento no duplica: la clave natural es `{ tenantId, isDefault: true }`.\n\n"
          "### 9.17 Resolución de la entidad jurídica de un documento (RF-CFG-137)\n\n"
          "El módulo que crea un documento económico llama a `legalEntities.resolve({ branchId, serviceId, at })`; el resultado se guarda en `legalEntityId` y en la copia de datos del emisor del documento. El validador del esquema base (RF-CFG-136) rechaza el documento si la entidad falta, es de otro tenant o está inactiva a la fecha `at`.\n\n"
          "## 10. Pantallas\n"))

# 10 PAN
P.append(("Mapa, punto actual, \"usar mi ubicación\", motivo. | Confirmar, corregir. | — |\n",
          "Mapa, punto actual, \"usar mi ubicación\", motivo. | Confirmar, corregir. | — |\n"
          "| PAN-CFG-33 | admin `/admin/cfg/entidades-juridicas` | `cfg.entidadesJuridicas.ver` / `.editar` | Entidades jurídicas del tenant (RF-CFG-134 a 139). | Grilla: código, razón social, CUIT, condición IVA, régimen IIBB, por defecto, sucursales, estado. Filtro por estado. | Nueva/editar (modal lg con pestañas Datos legales, Domicilio, Historia; pestaña Empleador de solo lectura con enlace a PAN-SUE-05); marcar por defecto (confirmación); inactivar. | — (`EMPRESAS` sin ABM relevado [VERIFICAR]) |\n"
          "| PAN-CFG-34 | admin `/admin/cfg/sucursales` | `cfg.sucursales.ver` / `.editar` | Sucursales (RF-CFG-140). | Grilla: código, nombre, entidad jurídica, localidad, usos, casa central, estado. Filtros: entidad, localidad, uso. | Nueva/editar (modal md con `GeoAddressPicker`); cambiar entidad con fecha efectiva; inactivar. | — |\n"
          "| PAN-CFG-35 | admin `/admin/cfg/puestos` | `cfg.puestos.editar` | Puestos por sucursal (RF-CFG-141). | Grilla: código, nombre, sucursal, tipo, agente local, dispositivos, estado. | Nuevo/editar (modal md); inactivar. | `abm_Equipos` (parte de puesto) |\n"))

# 11 API
P.append(("| API-CFG-54 | GET/POST | `/api/admin/cfg/sequences` | `cfg.secuencias.configurar` | Definición de secuencias y contadores (§14.7). | Sí |\n",
          "| API-CFG-54 | GET/POST | `/api/admin/cfg/sequences` | `cfg.secuencias.configurar` | Definición de secuencias y contadores (§14.7). Reemplazado por la API de `numberingSequences` de T11 (CTR-DAT-16). | Sí |\n"
          "| API-CFG-55 | GET/POST/PATCH | `/api/admin/cfg/legal-entities[/:id]` · `/:id/set-default` · `/:id/deactivate` · `PATCH /:id/employer` | `cfg.entidadesJuridicas.ver` / `.editar`; `PATCH /employer` con `sue.estructura.configurar` | Entidades jurídicas (RF-CFG-134 a 139). | Sí (`Idempotency-Key` en POST; `If-Match`) |\n"
          "| API-CFG-56 | GET/POST/PATCH | `/api/admin/cfg/branches[/:id]` · `/:id/change-legal-entity` · `/:id/deactivate` | `cfg.sucursales.ver` / `.editar` | Sucursales (RF-CFG-140). | Sí |\n"
          "| API-CFG-57 | GET/POST/PATCH | `/api/admin/cfg/workstations[/:id]` | `cfg.puestos.editar` | Puestos (RF-CFG-141). | Sí |\n"
          "| API-CFG-58 | GET | `/api/internal/cfg/legal-entities/resolve?branchId&serviceId&at` | Identidad de servicio | Resolución de la entidad de un documento (RF-CFG-137, §9.17). | Sí |\n"))

# 12.1 / 12.2
P.append(("| EVT-CFG-18 | `cfg.integrity.issueDetected` | JOB-CFG-13 | `tenantId`, hallazgos | T01, T09 |\n",
          "| EVT-CFG-18 | `cfg.integrity.issueDetected` | JOB-CFG-13 | `tenantId`, hallazgos | T01, T09 |\n"
          "| EVT-CFG-19 | `cfg.legalEntity.created` / `.updated` / `.deactivated` | Alta, cambio de datos (incluido marcar por defecto o cambiar `employer`) o inactivación | `legalEntityId`, `code`, `cuit`, `legalName`, `isDefault`, `status`, `changedFields`, `validFrom` | M06 (perfil fiscal y puntos de venta), M05, M15, M14, M16, T03 (pie de documentos), T10 |\n"
          "| EVT-CFG-20 | `cfg.branch.created` / `.updated` / `.deactivated` | Alta, cambio (incluido cambio de entidad) o inactivación de sucursal | `branchId`, `code`, `name`, `legalEntityId`, `uses`, `status` | T02 (alcance por sucursal), T03 (slots de marca por sucursal), M06, M07, M09, M13 |\n"))
P.append(("| `pla.tenant.created` | T01 | Crear adopciones por defecto, calendario del tenant, defaults; si demo, ofrecer semilla. |",
          "| `pla.tenant.created` (EVT-PLA-01) | T01 | Crear adopciones por defecto, calendario del tenant, defaults; si demo, ofrecer semilla. Crear la entidad jurídica por defecto y la sucursal casa central (§9.16, RF-CFG-135, DEC-064). |"))

# 14.3
P.append(("| Sucursal | `branch` | `branchId` (T01) |",
          "| Sucursal | `branch` | `branchId` → `branches` de T04 (RF-CFG-140; corregido por DEC-064, antes \"T01\") |"))

# 14.5
P.append(("| PRM-CFG-038 | `cfg.indices.reglaValorAusente` | enum (`ultimoAnterior`, `exacto`) | tenant, service | `ultimoAnterior` | Regla por defecto si falta valor de la serie. | — |\n",
          "| PRM-CFG-038 | `cfg.indices.reglaValorAusente` | enum (`ultimoAnterior`, `exacto`) | tenant, service | `ultimoAnterior` | Regla por defecto si falta valor de la serie. | — |\n"
          "| PRM-CFG-039 | `cfg.entidadesJuridicas.multiplesHabilitado` | boolean | tenant | `false` | Habilita operar con más de una entidad jurídica; con `false` se ocultan los selectores y se usa la entidad por defecto (RF-CFG-137). | — |\n"
          "| PRM-CFG-040 | `cfg.entidadesJuridicas.emisoraPorServicio` | reference (`legalEntities`) | service | sin valor (usa sucursal o por defecto) | Entidad que emite los documentos del servicio (RF-CFG-137). | — |\n"))

# 14.7
P.append(("T04b remite a CFG la numeración configurable (titulares, lotes de archivos de integración). Colección `sequences`:",
          "**Reemplazado por `numberingSequences` de T11 (numeración no fiscal) y `numberSequences` de M05 (numeración fiscal, por `legalEntityId` y punto de venta) (CTR-DAT-16).** El texto siguiente se conserva como requisito que deben cumplir esas colecciones. T04b remite a CFG la numeración configurable (titulares, lotes de archivos de integración). Colección `sequences`:"))

# 17
P.append(("| ESC-CFG-30 | Vista compartida usada por usuario sin alcance | No amplía datos visibles. |\n",
          "| ESC-CFG-30 | Vista compartida usada por usuario sin alcance | No amplía datos visibles. |\n"
          "| ESC-CFG-31 | Alta de TEN-001 (`pla.tenant.created`) y reproceso del mismo evento | Una sola entidad `isDefault` y una sola casa central. |\n"
          "| ESC-CFG-32 | Factura sin `legalEntityId` o con la entidad de TEN-002 | No valida (422); nada se persiste. |\n"
          "| ESC-CFG-33 | Usuario de TEN-001 lista entidades jurídicas | Solo ve las de TEN-001. |\n"
          "| ESC-CFG-34 | Segunda entidad con el CUIT de la primera; inactivar la entidad por defecto | Ambas operaciones se rechazan con motivo. |\n"
          "| ESC-CFG-35 | Servicio SOC con PRM-CFG-040 = entidad \"MUTUAL\" en sucursal de \"COOP\" | El documento resuelve \"MUTUAL\". |\n"))

# 18.7
P.append(("| Vistas | \"Mora > 60 días\" (cuentas) compartida con rol Gestor de mora. |",
          "| Vistas | \"Mora > 60 días\" (cuentas) compartida con rol Gestor de mora. |\n"
          "| Entidades y sucursales | `COOP` \"Cooperativa Demo Ltda.\" (por defecto) y `MUTUAL` \"Mutual Demo\", con CUIT ficticios generados por la semilla (no corresponden a contribuyentes reales); sucursales `SUC-01` \"Casa central\" (COOP) y `SUC-02` \"Sucursal Norte\" (COOP); puesto `CAJA-01` en SUC-01. |"))

# 19.1
P.append(("| `EMPRESAS` | T01 (entidades legales del tenant) | — | — |",
          "| `EMPRESAS` | `legalEntities` (RF-CFG-142; antes \"T01 (entidades legales del tenant)\", corregido por DEC-064 y CTR-DAT-48) | La principal queda `isDefault` | Filas origen = entidades; CUIT sin duplicados |\n"
          "| `SU_EMPRESAS`, `SU_TIPOEMPLEADOR` | `legalEntities.employer` | Match por CUIT; sin match, entidad nueva | Toda empresa empleadora con entidad |\n"
          "| Sucursales (`EMPRESAS`/`CAJASJP`) [VERIFICAR] | `branches` | — | Conteo |\n"
          "| Tablas oficiales de sueldos (`SU_ACTIVIDADES` … `SU_TRAMAS*`) | §7.17 (plataforma) | Se cargan desde fuente oficial; las de ProCoop solo se comparan | Diferencias reportadas |"))

# 20
P.append(("| CTR-CFG-17 | CAT `ENTIDADES`/`ENTIDACON`/`ENTIDACOL_EXTRA` vs T08 |",
          "| CTR-CFG-18 | §2.2, RN-CFG-045 y §19.1 de este anexo vs DEC-064 | El perfil legal y las sucursales se asignaban a T01. | `legalEntities` y `branches` en T04 desde O0 (RF-CFG-134 a 142); T01 conserva los datos de contratación del tenant. | DEC > anexo. |\n"
          "| CTR-CFG-19 | REQ-DEC-064 (`03-plan-de-olas`) vs T05 COL-CFG-41 | El plan nombra `cuit`, `ivaCondition`, `iibbRegime`, `activityStartDate` en la raíz; T05 referencia `fiscal.cuit`. | Se adopta el subdocumento `fiscal` de T05; los nombres del plan son equivalentes (§7.14). | T05 (modelo canónico) > plan. |\n"
          "| CTR-CFG-20 | §5.10, §7.9 de este anexo vs M06 | Tablas fiscales y padrones duplicados. | M06 (COL-FIS-15 a 21). | CTR-DAT-13. |\n"
          "| CTR-CFG-21 | `savedViews` y `sequences` de este anexo vs T03, T11 y M05 | Vistas de grilla y numeración duplicadas. | `dataTableViews` (T03); `numberingSequences` (T11) y `numberSequences` (M05). | CTR-DAT-11, CTR-DAT-16. |\n"
          "| CTR-CFG-22 | T01 EVT-PLA-21 `pla.branch.created` vs dueño de `branches` | T01 publicaba los eventos de sucursal sin ser dueño. | Los publica T04 (EVT-CFG-20); EVT-PLA-21 queda reemplazado. | DEC-064; dueño del dato. |\n"
          "| CTR-CFG-23 | RF-CFG-073 vs DEC-046 | Google figuraba como geocodificador. | Georef normaliza y geocodifica; Google para mapa y autocompletado. | DEC > anexo. |\n"
          "| CTR-CFG-17 | CAT `ENTIDADES`/`ENTIDACON`/`ENTIDACOL_EXTRA` vs T08 |"))

# 21
P.append(("- **Bloquea:** RF-CFG-067, RF-CFG-068, RN-CFG-029, JOB-CFG-05, O1.\n",
          "- **Bloquea:** RF-CFG-067, RF-CFG-068, RN-CFG-029, JOB-CFG-05, O1.\n- **Estado:** Respondida por DEC-046 (Georef para normalizar y geocodificar; Google Maps para mapa y autocompletado), coherente con la opción A.\n"))
P.append(("- **Bloquea:** RF-CFG-082, PRM-CFG-017/018, O1.\n",
          "- **Bloquea:** RF-CFG-082, PRM-CFG-017/018, O1.\n- **Estado:** Respondida por DEC-020 (clave de plataforma con opción de clave propia del tenant), coherente con la opción A.\n"))
P.append(("- **Bloquea:** RF-CFG-056, RF-CFG-102, JOB-CFG-08, O4.\n",
          "- **Bloquea:** RF-CFG-056, RF-CFG-102, JOB-CFG-08, O4.\n- **Estado:** Trasladada a M06 junto con los padrones (CTR-DAT-13).\n"))
P.append(("- **Bloquea:** RF-CFG-069, PAN-CFG-12, O1.\n\n## 22. Trazabilidad de fuentes",
          "- **Bloquea:** RF-CFG-069, PAN-CFG-12, O1.\n\n"
          "### PA-CFG-14 — Cambio de CUIT o de entidad emisora con documentos emitidos\n"
          "- **Pregunta:** ¿Qué pasa cuando una entidad jurídica cambia de CUIT o un servicio pasa a ser emitido por otra entidad del tenant?\n"
          "- **Contexto:** DEC-064 exige `legalEntityId` en todos los documentos económicos; los documentos emitidos no cambian de emisor y la cuenta corriente es por entidad (DEC-087).\n"
          "- **Opciones:**\n"
          "  - A) El CUIT no se edita: un CUIT nuevo es una entidad nueva; el cambio de emisora de un servicio tiene fecha efectiva y los saldos anteriores quedan en la entidad original **(Recomendada)** — trazable y sin reescribir documentos.\n"
          "  - B) Permitir editar el CUIT y reasignar documentos abiertos — menos altas; rompe la trazabilidad fiscal.\n"
          "  - C) Prohibir cambiar la emisora de un servicio — simple; no cubre escisiones ni fusiones.\n"
          "- **Impacto si no se responde:** se asume A (RN-CFG-052).\n"
          "- **Bloquea:** RF-CFG-137, RN-CFG-052, O0.\n"
          "- **Estado:** Asumida la recomendada (DEC-072) salvo respuesta del solicitante.\n\n"
          "## 22. Trazabilidad de fuentes"))

# 22
P.append(("| `EMPRESAS` | T01, §19.1 |",
          "| `EMPRESAS` | RF-CFG-134, RF-CFG-142, §7.14, §19.1 (antes T01; DEC-064) |"))
P.append(("| V2 #383 | Descartado (reemplazado por 742, RF-CFG-015) |",
          "| V2 #383 | Descartado (reemplazado por 742, RF-CFG-015) |\n\n"
          "### 22.9 Decisiones y contraposiciones del modelo de datos\n\n"
          "| Fuente | Destino |\n|---|---|\n"
          "| DEC-064 (varias entidades jurídicas por tenant) y REQ-DEC-064 / PRO-O0-13 del plan de olas | RF-CFG-134 a 142, RN-CFG-051 a 055, §7.14 a §7.16, §8.9, §9.16, §9.17, PAN-CFG-33 a 35, API-CFG-55 a 58, EVT-CFG-19/20, PRM-CFG-039/040, ESC-CFG-31 a 35, CTR-CFG-18/19/22, PA-CFG-14 |\n"
          "| DEC-046 (Georef y Google Maps) | RF-CFG-067, 068, 073, 074; CTR-CFG-23; PA-CFG-02 |\n"
          "| DEC-020 (claves de mapas por plataforma con opción propia) | RF-CFG-082; PA-CFG-04 |\n"
          "| CTR-DAT-06 (`employers` → `legalEntities.employer`) | RF-CFG-139, §7.14 |\n"
          "| CTR-DAT-11 (`savedViews` → `dataTableViews` T03) | §2.1 fila 12, RF-CFG-115, §7.11 |\n"
          "| CTR-DAT-13 (tablas fiscales → M06) | §2.1 fila 10, §5.10, §7.9, CTR-CFG-20 |\n"
          "| CTR-DAT-16 (`sequences` → T11/M05) | §14.7, API-CFG-54 |\n"
          "| CTR-DAT-48 (`legalEntities` es de T04) | RF-CFG-142, §19.1 |\n"
          "| CTR-DAT-73 (tablas legales de M16 §7.45) | RF-CFG-143, §7.17 |"))

apply('T04', P, 'f2-g6-t04')
