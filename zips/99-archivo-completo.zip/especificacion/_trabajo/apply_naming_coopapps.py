#!/usr/bin/env python3
"""Respaldo canónico + renombrado GoodApps → CoopApps según decisión de marca."""
from __future__ import annotations

import re
import shutil
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]  # docs/
REPO = ROOT.parent
ESPEC = REPO / "docs" / "especificacion"
PRES = REPO / "docs" / "presentacion-stakeholders"
STAMP = "2026-11-19-pre-naming-coopapps"
OLD_ESPEC = ESPEC / "OLD" / STAMP
OLD_PRES = PRES / "OLD" / STAMP

# Frases donde GoodApps es la empresa / responsable legal (no el producto).
PROTECT_PHRASES = [
    "GoodApps es prestador",
    "GoodApps nunca recibe",
    "Ningún componente de GoodApps",
    "GoodApps se mantiene en SAQ",
    "GoodApps prestador",
    "GoodApps mantiene cuentas",
    "costo para GoodApps",
    "GoodApps (art.",
]

PLACEHOLDER = "§§GOODAPPS_LEGAL§§"


def is_canonical_espec(path: Path) -> bool:
    rel = path.relative_to(ESPEC).as_posix()
    if rel.startswith("OLD/") or rel.startswith("_trabajo/"):
        return False
    if "backup-" in rel or "/backup-" in rel:
        return False
    if not path.suffix == ".md":
        return False
    if "/" not in rel:
        return True
    if rel.startswith("anexos/") and rel.count("/") == 1:
        return True
    return False


def is_canonical_pres(path: Path) -> bool:
    if path.suffix != ".md":
        return False
    rel = path.relative_to(PRES).as_posix()
    if rel.startswith("OLD/") or rel.startswith("_insumos/"):
        return False
    return True


def collect_targets() -> list[Path]:
    out: list[Path] = []
    for p in ESPEC.rglob("*.md"):
        if is_canonical_espec(p):
            out.append(p)
    if PRES.is_dir():
        for p in PRES.rglob("*.md"):
            if is_canonical_pres(p):
                out.append(p)
    return sorted(out)


def protect_legal(text: str) -> str:
    for phrase in PROTECT_PHRASES:
        text = text.replace(phrase, phrase.replace("GoodApps", PLACEHOLDER))
    # Caso: "GoodApps es prestador" ya cubierto; variante en tabla Alojamiento
    text = re.sub(
        r"(GoodApps es prestador de servicios de tratamiento)",
        lambda m: m.group(1).replace("GoodApps", PLACEHOLDER),
        text,
    )
    return text


def restore_legal(text: str) -> str:
    return text.replace(PLACEHOLDER, "GoodApps")


def apply_naming(text: str) -> str:
    text = protect_legal(text)
    # Orden: forma larga primero
    replacements = [
        ("GoodApps Cooperativas", "CoopApps"),
        ("GoodApps", "CoopApps"),
    ]
    for old, new in replacements:
        text = text.replace(old, new)
    return restore_legal(text)


def backup_file(src: Path, old_root: Path, base: Path) -> None:
    rel = src.relative_to(base)
    dest = old_root / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        shutil.copy2(src, dest)


def main() -> None:
    targets = collect_targets()
    OLD_ESPEC.mkdir(parents=True, exist_ok=True)
    OLD_PRES.mkdir(parents=True, exist_ok=True)

    changed = 0
    for path in targets:
        if path.is_relative_to(ESPEC):
            backup_file(path, OLD_ESPEC, ESPEC)
        else:
            backup_file(path, OLD_PRES, PRES)
        original = path.read_text(encoding="utf-8")
        updated = apply_naming(original)
        if updated != original:
            path.write_text(updated, encoding="utf-8", newline="\n")
            changed += 1

    log = ESPEC / "_trabajo" / f"naming-coopapps-{date.today().isoformat()}.txt"
    log.write_text(
        f"Archivos canónicos procesados: {len(targets)}\n"
        f"Archivos modificados: {changed}\n"
        f"Respaldo: {OLD_ESPEC}\n"
        f"Respaldo presentación: {OLD_PRES}\n",
        encoding="utf-8",
    )
    print(log.read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()