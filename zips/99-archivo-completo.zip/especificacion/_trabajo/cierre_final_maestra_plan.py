"""Cierre de la corrección de inconsistencias: cifras de la maestra y del plan (05-11-2026)."""
import os
os.chdir(os.path.join(os.path.dirname(__file__), '..'))


def editar(F, reemplazos):
    raw = open(F, 'rb').read()
    bom = raw.startswith(b'\xef\xbb\xbf')
    t = raw.decode('utf-8-sig')
    for a, b, n in reemplazos:
        c = t.count(a)
        assert c == n, (F, a[:80], c)
        t = t.replace(a, b)
    open(F, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + t.encode('utf-8'))
    print('ok', F, len(reemplazos))


C = 'cierre de la corrección de inconsistencias, 05-11-2026'

editar('00-ESPECIFICACION-MAESTRA.md', [
    ('consolida 1.104 filas de colecciones de los demás anexos, de las que se crean 1.053 (39 en la base analítica `bi_*`)',
     'consolida 1.108 filas de colecciones de los demás anexos (antes 1.104), de las que se crean 1.057 (antes 1.053; 39 en la base analítica `bi_*`); '
     'en el ' + C + ' se suman `costCenterModels` (M15), `bundleSubscriptions` (M02), `fiscalClasses` (M06) y `collectionAccountingGroups` (M07)', 1),
    ('que cubren los 4.203 RF y los 292 RNF de los anexos',
     'que cubren los 4.204 RF (antes 4.203; se suma RF-POR-180 de M19, Comunidad en la tabbar del socio, en O2, ' + C + ') y los 292 RNF de los anexos', 1),
    ('Reparto de RF por ola: O0 305, O1 458, O2 613, O3 319,',
     'Reparto de RF por ola: O0 305, O1 458, O2 614 (antes 613), O3 319,', 1),
    ('Las preguntas que surjan de aquí en adelante se agregan al final de la tabla con el mismo criterio (DEC-047).',
     'Las preguntas que surjan de aquí en adelante se agregan al final de la tabla con el mismo criterio (DEC-047). '
     'Actualización por el ' + C + ': 555 preguntas (antes 516), 98 respondidas (antes 93), 456 asumidas (antes 423) y 1 reemplazada; '
     'se agregan las 38 PA que los anexos registraron durante la corrección y pasan a respondidas PA-IAM-12, PA-CFG-02, PA-CFG-04, '
     'PA-MOR-20 y PA-POR-04, cuyos anexos ya aplican la DEC correspondiente.', 1),
])

P = 'cierre de la corrección de inconsistencias del 05-11-2026'
editar('03-plan-de-olas-y-prompts.md', [
    # encabezado
    ('| Cobertura | 4.203 RF de 29 anexos con RF',
     '| Cobertura | 4.204 RF (antes 4.203; RF-POR-180 nuevo en O2, ' + P + ', §21.6) de 29 anexos con RF', 1),
    # §1
    ('| Un socio se registra en la landing y solicita Internet; el contrato queda `requested` | O0, O1 | 19 | 613 | 15 |',
     '| Un socio se registra en la landing y solicita Internet; el contrato queda `requested` | O0, O1 | 19 | 614 (antes 613) | 15 |', 1),
    ('| **Total** | | | | **172** | **4.203** | **292** |',
     '| **Total** | | | | **172** | **4.204** (antes 4.203) | **292** |', 1),
    ('4.203 RF y 292 RNF, cada uno en exactamente un prompt. Ver §21.5.*',
     '4.203 RF y 292 RNF, cada uno en exactamente un prompt. Ver §21.5.*\r\n\r\n'
     '*Reemplazado (' + P + '): O2 613 y total 4.203 RF. RF-POR-180 (M19, Comunidad en la tabbar del socio, O2) se agrega a PRO-O2-17; '
     'O2 queda en 614 y el total en 4.204 RF; RNF y prompts no cambian. Ver §21.6.*', 1),
    # §6.4
    ('121..126, 134, 137..156, 158, 160 (v1.1: se agregan RF-POR-174, 179) | PAN-POR-01..104 (*reemplazado, corrección 05-11-2026:* antes PAN-POR-01..97; 104 definidos en el anexo)',
     '121..126, 134, 137..156, 158, 160 (v1.1: se agregan RF-POR-174, 179; cierre 05-11-2026: se agrega RF-POR-180) | PAN-POR-01..105 (*reemplazado, cierre 05-11-2026:* antes PAN-POR-01..104, que reemplazaba a PAN-POR-01..97; 105 definidos en el anexo, PAN-POR-105 Comunidad)', 1),
    ('| M19 POR | 96 | RF-POR-001..011,', '| M19 POR | 97 (antes 96) | RF-POR-001..011,', 1),
    ('| **Total** | **613** | | | |', '| **Total** | **614** (antes 613) | | | |', 1),
    # tabla de secuencia O2 y prompt
    ('| PRO-O2-17 | Portal del socio: inicio, servicios, gestiones, comunidad y administración | 64 |',
     '| PRO-O2-17 | Portal del socio: inicio, servicios, gestiones, comunidad y administración | 65 (antes 64) |', 1),
    ('| 0 (verifica 613) |', '| 0 (verifica 614; antes 613) |', 1),
    ('IMPLEMENTAR: ningún RF nuevo. Verificar los 613 RF de O2 (versión 1.0: 607).',
     'IMPLEMENTAR: ningún RF nuevo. Verificar los 614 RF de O2 (antes 613; versión 1.0: 607).', 1),
    ('además (v1.1): RF-POR-174 (M19 es dueño de la ruta, la navegación y la composición de cada pantalla de `pwa-socio` y `landing`).',
     'además (v1.1): RF-POR-174 (M19 es dueño de la ruta, la navegación y la composición de cada pantalla de `pwa-socio` y `landing`); '
     'además (cierre 05-11-2026): RF-POR-180 (tabbar del socio Inicio · Cuentas y servicios · (+) · Gestiones · Comunidad con FAB = Pagar, y PAN-POR-105 `/app/comunidad` que agrega muro, encuestas y novedades de T09; PA-POR-20).', 1),
    # §15 y verificación final
    ('| 0 (verifica 89 y 4.203; *reemplazado, corrección 05-11-2026:* antes 90) |',
     '| 0 (verifica 89 y 4.204; *reemplazado, corrección 05-11-2026:* antes 90; cierre 05-11-2026: antes 4.203) |', 1),
    ('verificación final de los 4.203 RF y 292 RNF del plan (versión 1.0: 4.120).',
     'verificación final de los 4.204 RF y 292 RNF del plan (antes 4.203; versión 1.0: 4.120).', 1),
    # §16
    ('| M19 POR | — | — | 96 | 9 | 9 | 19 | 10 | 8 | 1 | 7 | 15 | 5 | 179 |',
     '| M19 POR | — | — | 97 | 9 | 9 | 19 | 10 | 8 | 1 | 7 | 15 | 5 | 180 |', 1),
    ('| **Total RF** | **305** | **458** | **613** | **319** | **424** | **469** | **244** | **274** | **462** | **163** | **383** | **89** | **4.203** |',
     '| **Total RF** | **305** | **458** | **614** | **319** | **424** | **469** | **244** | **274** | **462** | **163** | **383** | **89** | **4.204** |', 1),
    ('Recalculada con `_trabajo/plan_recuento.py`; las filas RNF y Prompts no cambian.',
     'Recalculada con `_trabajo/plan_recuento.py`; las filas RNF y Prompts no cambian. *Reemplazado (' + P + '): M19 POR O2 96 y total 179; Total RF O2 613 y total 4.203 (RF-POR-180, §21.6).*', 1),
    # §17
    ('| T03 UXD | 179 | 179 | 0 | 3 (RF-UXD-139, 163, 171) |',
     '| T03 UXD | 179 | 179 | 0 | 3 (RF-UXD-139, 163, 171; desde el cierre 05-11-2026 la celda de RF-UXD-163 en T03 ya dice `O6 (DEC-056)` y coincide con el prompt) |', 1),
    ('| M19 POR | 179 | 179 | 0 | 0 |', '| M19 POR | 180 (antes 179) | 180 (antes 179) | 0 | 0 |', 1),
    ('| **Total** | **4.203** | **4.203** | **0** | **16** (*reemplazado, corrección 05-11-2026:* antes 15) |',
     '| **Total** | **4.204** (antes 4.203) | **4.204** (antes 4.203) | **0** | **16** (*reemplazado, corrección 05-11-2026:* antes 15) |', 1),
])
