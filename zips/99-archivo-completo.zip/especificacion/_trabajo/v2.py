﻿import re, glob
from conc_lib import *
for pat, ids in (('M08-*', ['JOB-MOR-05']), ('M15-*', ['JOB-CON-10']), ('T04-*', ['JOB-CFG-05'])):
    for f in glob.glob(os.path.join(ANX, pat)):
        L = read(f).split('\n')
        for i, l in enumerate(L):
            if any(l.startswith('| ' + x) for x in ids):
                h = next(L[j] for j in range(i, 0, -1) if L[j].startswith('#'))
                print(os.path.basename(f)[:20], i + 1, h[:60], '||', l[:110])
