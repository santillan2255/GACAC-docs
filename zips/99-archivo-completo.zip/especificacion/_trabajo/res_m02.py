from res_m0106_lib import Doc

d = Doc('M02')

# --- Categoría 1: estados ---
# §7: valores en las fichas que no los enumeraban
d.rep("| `status` | enum | Sí | Ex `ESTADO` | — |",
      "| `status` | enum | Sí | `active`, `removed` (ex `ESTADO`; inicial `active`, §8.5). | — |", '1')
OLD_CSC = "| `validTo` | date | [VERIFICAR] | — | — |\n| `status` | enum | Sí | — | — |\n\n### 7.25"
d.rep(OLD_CSC, "| `validTo` | date | [VERIFICAR] | — | — |\n| `status` | enum | Sí | `draft`, `approved`, `expired`, `cancelled` (inicial `draft`, §8.5). | — |\n\n### 7.25", '1')
# §7.20: equivalencias de M13 fuera de código para que no se lean como estados propios (INC-06-03)
d.rep("Equivalencia con los estados de M13 §8.4: `active` = `delivered`, `pendingReturn` = `returnPending`, `returnedIncomplete` = `returned` con `returnCondition = incomplete`, `notRecovered` = `chargedAsLost`, `swapped` = `replaced`;",
      "Equivalencia con los estados de M13 §8.4 (nombres de M13 entre comillas, no son valores de este campo): «active» = `delivered`, «pendingReturn» = `returnPending`, «returnedIncomplete» = `returned` con `returnCondition = incomplete`, «notRecovered» = `chargedAsLost`, «swapped» = `replaced`;", '1')
# §8.4: catálogo serviceStatuses no tiene ciclo de vida propio
d.rep("| `serviceStatuses` | `canonicalStatus` | `requested`, `feasibility`, `pendingInstallation`, `active`, `suspended`, `reactivationPending`, `pendingTermination`, `terminated`, `cancelled`, `superseded` | — (catálogo) | Estados canónicos de §8.1. |",
      "| `serviceStatuses` | `canonicalStatus` | Los diez estados canónicos de §8.1 (clasificación del estado operativo, no ciclo de vida del registro; antes se enumeraban aquí y el índice de cobertura los leía como estados sin transiciones, ver §8.5) | — (catálogo) | Estados canónicos de §8.1. |", '1')

TAB = '''
### 8.5 Estados iniciales y transiciones completadas (residuales del 05-11-2026)

Ronda de residuales del 05-11-2026 (PA-CAT-23, DEC-072): estado de alta explícito de las máquinas de §8.3 y §8.4 que no lo indicaban y transiciones de las colecciones que solo enumeraban estados. `serviceStatuses` es un catálogo: su `canonicalStatus` clasifica el estado operativo del contrato (§8.1) y no tiene transiciones; el registro sigue el patrón de tablas maestras (alta y desactivación). `generationAgreements` no se crea (CTR-DAT-59): su ciclo es el de `distributedGenerationContracts` de M03.

| Entidad | Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |
|---|---|---|---|---|---|
| `serviceCapabilities` | — | `draft` | Alta de la capacidad en plataforma | — | — |
| `tenantServices.enablement` | — | `enabled` | Habilitación del servicio para el tenant | Licencia vigente (RN-CAT-003) | — |
| `tenantServices.offerStatus` | — | `notPublished` | Alta del servicio del tenant | — | — |
| `serviceConfigVersions` | — | `draft` | Nueva versión de configuración | — | — |
| `servicePlans` | — | `draft` | Alta del plan | — | — |
| `contractDeclaredAppliances` | — | `active` | Declaración del artefacto en el contrato (DDJJ) | Potencia y unidad obligatorias en GAS y ELE (HUE-GAS-01) | — |
| `contractDeclaredAppliances` | `active` | `removed` | Retiro o reemplazo del artefacto declarado | Queda en `history[]` | — |
| `contractSpecialConditions` | — | `draft` | Alta de condiciones especiales (MER-003) | — | — |
| `contractSpecialConditions` | `draft` | `approved` | Aprobación (`approvedBy`, `approvedAt`) | Exige aprobación para aplicarse | — |
| `contractSpecialConditions` | `approved` | `expired` | Vence `validTo` | — | — |
| `contractSpecialConditions` | `draft`/`approved` | `cancelled` | Anulación con motivo | — | — |
| `serviceCopyRuns` | — | `requested` | Solicitud de copia entre tenants | — | — |
| `bulkContractOperations` | — | `draft` | Alta de la operación masiva | — | — |
| `bundleSubscriptions` | — | `active` | Alta del combo con sus contratos | — | — |
'''
d.insert_before('\n## 9. ', TAB, '1')

# --- Categoría 2: referencias ---
d.rep("| `requiresProductIds[]`, `excludesProductIds[]` | ObjectId[] | No | Compatibilidad. |",
      "| `requiresProductIds[]`, `excludesProductIds[]` | ObjectId[] | No | Compatibilidad. Referencia: → `serviceProducts` (M02, autorreferencia). |", '2')
d.rep("| `declaredAffidavitRef` | ObjectId | No | DD JJ. Referencia: `documents` (T11) [VERIFICAR]. |",
      "| `declaredAffidavitRef` | ObjectId | No | DD JJ. Referencia: → `documents` (T11), confirmada en PA-CAT-23 (DEC-072; antes [VERIFICAR]). |", '2')
d.rep("| `feasibilityRef` | ObjectId | No | ex `COD_SOL` (`FACTIBIL`, TEC). Referencia: `feasibilityRequests` (M10) [VERIFICAR]. |",
      "| `feasibilityRef` | ObjectId | No | ex `COD_SOL` (`FACTIBIL`, TEC). Referencia: → `feasibilityRequests` (M10, COL-TEC-01), confirmada en PA-CAT-23 (DEC-072; antes [VERIFICAR]). |", '2')
d.rep("Referencia: `billableItems` (M05). |\n| `saleDocumentRef`",
      "Referencia: → `approvalRequests` (T11): la propuesta es la solicitud de aprobación del cargo (RN-STK-038); el ítem aprobado queda en `billableItems` (M05) (PA-CAT-23; antes «Referencia: `billableItems` (M05)»). |\n| `saleDocumentRef`", '2')

# --- Categoría 3: tablas de campos asociadas a su colección ---
d.rep("\n`servicePlanVersions`:\n", "\n**`servicePlanVersions`**:\n", '3')
d.anchor_field_tables('3')

PA = '''
### PA-CAT-23 - Residuales de estados y referencias (ronda del 05-11-2026)
- **Pregunta:** ¿Se confirman los estados iniciales y las transiciones que faltaban, el tratamiento de `serviceStatuses.canonicalStatus` como clasificación y los destinos de las referencias sin colección?
- **Contexto:** al regenerar los entregables, 06a §7 marcó 10 máquinas de M02 sin estado inicial, `serviceStatuses`, `contractDeclaredAppliances` y `contractSpecialConditions` con estados sin transiciones, y `contractEquipmentAssignments` con valores de §7 inalcanzables (eran los nombres de M13 de la equivalencia); 03-er marcó sin destino `requiresProductIds`, `excludesProductIds`, `declaredAffidavitRef` y `chargeProposalId`.
- **Opciones:**
  - A) **(Recomendada)** Declarar en §8.5 el estado de alta de cada máquina y las transiciones de `contractDeclaredAppliances` (`active` → `removed`) y `contractSpecialConditions` (`draft` → `approved` → `expired`; → `cancelled`); tratar `canonicalStatus` como clasificación sin ciclo; escribir la equivalencia con M13 fuera de código; `requiresProductIds`/`excludesProductIds` → `serviceProducts`; `declaredAffidavitRef` → `documents` (T11); `feasibilityRef` → `feasibilityRequests` (M10); `chargeProposalId` → `approvalRequests` (T11).
  - B) Dejar los estados iniciales implícitos y `chargeProposalId` apuntando a `billableItems`.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** 06 (estados), 03 (ER), T05 §7.2.1.
- **Estado:** Asumida (DEC-072): opción A. Aplicado en §7.5, §7.8, §7.18, §7.20, §7.21, §7.24, §8.4 y §8.5. T05 debe registrar los destinos; M13 §7 (`chargeProposalId`) debe citar `approvalRequests` (T11).
'''
d.insert_before('\n## 22. ', PA, 'PA')
d.save()
