﻿from conc_lib import *
d = json.load(open('occ.json',encoding='utf-8'))
names = d['names']
for f in files():
    b = os.path.basename(f)
    if not (b.startswith('T12') or b.startswith('T04b')): continue
    for ln, l in enumerate(read(f).split('\n'), 1):
        hits = [n for n in set(expand(l)) if n in names]
        if hits: print(b[:22], ln, hits, '::', l[:250])
