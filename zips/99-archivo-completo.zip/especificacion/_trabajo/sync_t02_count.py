import glob, os, re, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
ROOT = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
BK = glob.glob(os.path.join(ROOT, 'anexos', 'backup-sync-T02T03T05T11-*'))[0]
p = glob.glob(os.path.join(ROOT, 'anexos', 'T02-*.md'))[0]
for f in (os.path.join(BK, os.path.basename(p)), p):
    L = open(f, encoding='utf-8').read().split('\n')
    sec, cnt, caps = None, {}, set()
    for l in L:
        m = re.match(r'^#{2,4} (4\.4(?:\.\d+)?|4\.5|5)\b', l)
        if m:
            sec = m.group(1)
        elif re.match(r'^#{2,3} ', l):
            sec = None
        if sec and re.match(r'^\| `[a-z]+\.[A-Za-z.]+` \|', l):
            cnt[sec] = cnt.get(sec, 0) + 1
            if sec == '4.4' or sec == '4.4.2':
                caps.add(l.split('`')[1])
    print(os.path.basename(os.path.dirname(f)), cnt, 'capabilities distintas en 4.4/4.4.2:', len(caps))
