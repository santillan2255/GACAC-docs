import sys, io, glob, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
pref, s, e = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
L = open(glob.glob(r"..\anexos\%s-*" % pref)[0], encoding="utf-8-sig").read().split("\n")
cur = None
for i in range(s - 1, e):
    l = L[i]
    m = re.match(r"^\*\*`([A-Za-z]+)`\*\*|^#{3,5} .*?`([A-Za-z]+)`", l)
    if m:
        cur = m.group(1) or m.group(2)
    if re.match(r"^\| `[A-Za-z.]*([sS]tatus|[sS]tate)`", l):
        print(i + 1, cur, "::", l[:230])
