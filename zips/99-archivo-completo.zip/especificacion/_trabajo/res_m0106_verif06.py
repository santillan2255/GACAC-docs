# Verificación de estados (06) para M01-M06: corre gen06_build en una copia temporal y lista residuales.
import json, os, re, subprocess, sys
TMP = os.path.join(os.environ['TEMP'], 'g06')
MODS = ('M01', 'M02', 'M03', 'M04', 'M05', 'M06')
r = subprocess.run([sys.executable, 'gen06_build.py'], cwd=os.path.join(TMP, '_trabajo'), capture_output=True, text=True, encoding='utf-8')
print(r.stdout.strip().splitlines()[-1][:400] if r.stdout else r.stderr[-2000:])
out = []
for fn in sorted(os.listdir(TMP)):
    if not re.match(r'^06[b-d]-estados', fn):
        continue
    t = open(os.path.join(TMP, fn), encoding='utf-8').read()
    for s in re.split(r'\n(?=### )', t):
        h = s.splitlines()[0]
        if not re.search(r'EST-(PER|CAT|MED|TAR|FAC|FIS)-', h):
            continue
        if 'no explícito' in s:
            out.append('INICIAL ' + h)
    for l in t.splitlines():
        if l.startswith('|') and re.search(r'\| M0[1-6] \|', l) and re.search(r'solo estados|Excluida', l):
            out.append('CLASIF ' + l)
idx = open(os.path.join(TMP, '06a-indice-cobertura-secuencias-estados.md'), encoding='utf-8').read()
for l in idx.splitlines():
    if l.startswith('| M0') and re.match(r'^\| M0[1-6] ', l) and ('sin valores' in l or 'COL-' in l and '§8' in l):
        out.append('IDX ' + l[:300])
d = json.load(open(os.path.join(TMP, '_trabajo', 'gen06_data.json'), encoding='utf-8'))
for x in d.get('svc_nocaller', []):
    if re.match(r'^`?(per|cat|med|tar|fac|fis)\.', str(x[0] if isinstance(x, list) else x)):
        out.append('SVC ' + str(x))
for x in d.get('nonconv_types', []):
    out.append('EVT ' + str(x)) if re.search(r'M0[1-6]', str(x)) else None
print('\n'.join(out))
print('total', len(out))
