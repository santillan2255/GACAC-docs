import sys, json
from conc_lib import *

LOG = os.path.join(BASE, '_trabajo', 'repl-log.jsonl')


def fpath(code):
    m = [f for f in files() if os.path.basename(f).startswith(code + '-')]
    assert len(m) == 1, (code, m)
    return m[0]


def apply(code, pairs, tag='alias'):
    p = fpath(code)
    s = read(p)
    stats = 0
    for item in pairs:
        old, new = item[0], item[1]
        exp = item[2] if len(item) > 2 else 1
        c = s.count(old)
        if exp == 0:
            if c < 1:
                raise SystemExit('NO ENCONTRADO en %s: %r' % (code, old[:120]))
        elif c != exp:
            raise SystemExit('CUENTA %d != %d en %s: %r' % (c, exp, code, old[:120]))
        s = s.replace(old, new)
        stats += 1
    write(p, s)
    with open(LOG, 'a', encoding='utf-8') as o:
        for item in pairs:
            o.write(json.dumps({'file': code, 'tag': tag, 'old': item[0][:200], 'new': item[1][:200]}, ensure_ascii=False) + '\n')
    print(code, tag, stats, 'reemplazos')
