import sys, re, glob, os
sys.stdout.reconfigure(encoding='utf-8')
A = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
BOM = b'\xef\xbb\xbf'
CNT = {}


def path_of(mod):
    return glob.glob(os.path.join(A, mod + '-*.md'))[0]


class Doc:
    def __init__(self, mod):
        self.mod = mod
        self.path = path_of(mod)
        raw = open(self.path, 'rb').read()
        self.bom = raw.startswith(BOM)
        txt = raw.decode('utf-8-sig')
        self.crlf = '\r\n' in txt
        self.lines = txt.replace('\r\n', '\n').split('\n')
        self.log = []

    def save(self):
        txt = '\n'.join(self.lines)
        if self.crlf:
            txt = txt.replace('\n', '\r\n')
        data = txt.encode('utf-8')
        if self.bom:
            data = BOM + data
        open(self.path, 'wb').write(data)

    def count(self, cat, n=1):
        CNT[(self.mod, cat)] = CNT.get((self.mod, cat), 0) + n

    def find_heading(self, prefix):
        idx = [i for i, l in enumerate(self.lines) if l.startswith(prefix)]
        if len(idx) != 1:
            raise SystemExit('heading %r encontrado %d veces' % (prefix, len(idx)))
        i = idx[0]
        lvl = len(re.match(r'^(#+)', self.lines[i]).group(1))
        j = i + 1
        while j < len(self.lines):
            m = re.match(r'^(#+) ', self.lines[j])
            if m and len(m.group(1)) <= lvl:
                break
            j += 1
        return i, j

    def row_idx(self, heading, field):
        a, b = self.find_heading(heading)
        hits = [k for k in range(a, b) if self.lines[k].startswith('| `%s` |' % field) or self.lines[k].startswith('| `%s`|' % field)]
        if len(hits) != 1:
            raise SystemExit('fila %r en %r: %d' % (field, heading, len(hits)))
        return hits[0]

    def set_row(self, heading, field, new_row, cat):
        k = self.row_idx(heading, field)
        self.lines[k] = new_row
        self.count(cat)

    def add_rows_after(self, heading, field, rows, cat=None):
        k = self.row_idx(heading, field)
        self.lines[k + 1:k + 1] = rows
        if cat:
            self.count(cat, len(rows))

    def add_rows_end_of_table(self, heading, rows, cat=None):
        a, b = self.find_heading(heading)
        last = max(k for k in range(a, b) if self.lines[k].startswith('|'))
        self.lines[last + 1:last + 1] = rows
        if cat:
            self.count(cat, len(rows))

    def replace_in_line(self, contains, old, new, cat=None, n=1, start=0):
        hits = [k for k, l in enumerate(self.lines) if k >= start and contains in l and old in l]
        if len(hits) != n:
            raise SystemExit('replace_in_line %r/%r: %d (esperado %d)' % (contains[:50], old[:50], len(hits), n))
        for k in hits:
            self.lines[k] = self.lines[k].replace(old, new, 1)
        if cat:
            self.count(cat, n)

    def replace_line_no(self, lineno, old, new, cat=None):
        l = self.lines[lineno - 1]
        if old not in l:
            raise SystemExit('linea %d sin %r' % (lineno, old[:60]))
        self.lines[lineno - 1] = l.replace(old, new)
        if cat:
            self.count(cat)

    def insert_before_heading(self, prefix, block):
        idx = [i for i, l in enumerate(self.lines) if l.startswith(prefix)]
        if len(idx) != 1:
            raise SystemExit('insert_before %r: %d' % (prefix, len(idx)))
        i = idx[0]
        self.lines[i:i] = block + ['']

    def table_to3(self, heading, typecol):
        """Convierte una tabla `| Campo | Referencia |` en `| Campo | Tipo | Referencia |`."""
        a, b = self.find_heading(heading)
        for k in range(a, b):
            l = self.lines[k]
            if l.startswith('| Campo | Referencia |'):
                self.lines[k] = '| Campo | Tipo | Referencia |'
                self.lines[k + 1] = '|---|---|---|'
                j = k + 2
                while j < b and self.lines[j].startswith('|'):
                    cells = self.lines[j].split(' | ')
                    m = re.match(r'^\| `([^`]+)`', self.lines[j])
                    t = typecol.get(m.group(1), 'ObjectId') if m else 'ObjectId'
                    self.lines[j] = cells[0] + ' | ' + t + ' | ' + ' | '.join(cells[1:])
                    j += 1
                return
        raise SystemExit('tabla 2 columnas no encontrada en %r' % heading)


def report():
    for k in sorted(CNT):
        print(k, CNT[k])
