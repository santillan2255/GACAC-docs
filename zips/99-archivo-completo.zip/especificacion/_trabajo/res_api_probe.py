import re, glob
pats = ['T01-*', 'T02-*', 'T03-*', 'T04*', 'T06-*', 'T07-*', 'T08-*', 'T10-*', 'T12-*']
files = [f for p in pats for f in glob.glob('../anexos/' + p + '.md')]
CAP = re.compile(r'`[a-z][A-Za-z0-9]*(\.[A-Za-z0-9*]+)+`|`public: true`|`[a-z]+:[a-z]+`')
for f in files:
    t = open(f, encoding='utf-8-sig').read()
    n = 0
    for i, l in enumerate(t.split('\n'), 1):
        if not re.match(r'\| API-[A-Z]{3}-\d+[a-z]? \|', l):
            continue
        c = l.split(' | ')
        if len(c) < 5:
            continue
        cell = c[3]
        if 'Reemplazado por' in l or 'sin destino de API' in l or 'no tiene API' in l:
            continue
        if not CAP.search(cell):
            n += 1
            print(f[11:40], i, c[0][2:], '::', cell[:120])
    if n:
        print('  ->', n)
