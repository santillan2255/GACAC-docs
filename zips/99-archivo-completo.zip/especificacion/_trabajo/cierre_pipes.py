# Escapa barras verticales dentro de código en celdas de tabla (rompen las columnas en GFM).
import re, sys
for P in sys.argv[1:]:
    raw = open(P, 'rb').read()
    t = raw.decode('utf-8')
    L = t.split('\n')
    n = 0
    for i, l in enumerate(L):
        if not l.startswith('|'):
            continue
        def fix(m):
            global n
            s = m.group(0)
            s2 = re.sub(r'(?<!\\)\|', r'\\|', s)
            if s2 != s:
                n += 1
            return s2
        L[i] = re.sub(r'`[^`\n]+`', fix, l)
    open(P, 'wb').write('\n'.join(L).encode('utf-8'))
    print(P, 'spans corregidos', n)
