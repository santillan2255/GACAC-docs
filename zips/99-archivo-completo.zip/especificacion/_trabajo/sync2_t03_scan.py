import glob, re
ROOT = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
p = glob.glob(ROOT + r'\anexos\T03-*.md')[0]
L = open(p, encoding='utf-8').read().split('\n')
out = open(ROOT + r'\_trabajo\sync2_t03.txt', 'w', encoding='utf-8')
i = 0
while i < len(L):
    if L[i].startswith('|') and i + 1 < len(L) and re.match(r'^\|[\s:|-]+\|\s*$', L[i + 1]):
        n = L[i].replace('\\|', '').count('|')
        j = i + 2
        while j < len(L) and L[j].startswith('|'):
            m = L[j].replace('\\|', '').count('|')
            if m != n:
                out.write('LINEA %d esperadas %d tiene %d | encabezado L%d: %s\n' % (j + 1, n, m, i + 1, L[i]))
                out.write('    ' + L[j] + '\n')
            j += 1
        i = j
    else:
        i += 1
# celdas mal formadas: comillas o backticks desbalanceados, "antes" anidados raros
for k, l in enumerate(L):
    if l.startswith('|') and (l.count('`') % 2 or l.count('"') % 2 or '""' in l or '((' in l or '))' in l):
        out.write('CELDA %d: %s\n' % (k + 1, l[:1200]))
