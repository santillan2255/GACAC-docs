﻿P='anexos/T02-IAM-identidad-roles-auditoria.md'
raw=open(P,'rb').read(); assert not raw.startswith(b'\xef\xbb\xbf') and b'\r\n' not in raw
t=raw.decode('utf-8')
for c in ['pla.cfg.tablasPlataforma.publicar','pla.cfg.tablasPlataforma.importar']: assert '`'+c+'`' not in t, c
a='| `pla.cfg.tablasPlataforma.editar` | Tablas de plataforma y releases | — | P-SUP, P-ADM | global | PAN-CFG-26 |\n'
assert t.count(a)==1
t=t.replace(a,
 '| `pla.cfg.tablasPlataforma.importar` | Ingesta de tablas de plataforma (geo, feriados nacionales y provinciales, índices oficiales, tablas fiscales, padrones públicos, reguladores) desde fuentes oficiales; también la usan los workers de ingesta (T04 §4) | — | P-SUP, P-ADM (curador de datos de plataforma), S-SYS | global | PAN-CFG-26, T04 §4 |\n'
 + a +
 '| `pla.cfg.tablasPlataforma.publicar` | Publicar un release de tablas de plataforma; segundo par de ojos, distinto de quien lo editó (T04 §4) | S D | P-SUP, P-ADM (curador, si no editó el release) | global | API-CFG-51 (`/:id/publish`), PAN-CFG-26 |\n')
b='| pla | `pla.cfg.tablasPlataforma.*` | — (explicitar las capabilities concretas por acción) |'
assert t.count(b)==1
t=t.replace(b,'| pla | `pla.cfg.tablasPlataforma.*` | — (explicitar: `pla.cfg.tablasPlataforma.editar`, `.importar`, `.publicar`; T04 API-CFG-51 ya lo explicitó) |')
c='| ledger | `ledger:read` | `con.asientos.ver` |'
assert t.count(c)==1
t=t.replace(c,'| ledger | `ledger:read` | `cob.cuentaCorriente.ver` (antes `con.asientos.ver`: los endpoints API-BIA-79, 80 y 97 exponen el auxiliar de cuenta corriente de M07, no asientos contables) |')
open(P,'wb').write(t.encode('utf-8')); print('OK')
