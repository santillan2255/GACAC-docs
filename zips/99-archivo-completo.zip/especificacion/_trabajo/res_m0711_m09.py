from res_m0711_lib import *

d = Doc('M09')
PA = 'PA-CRM-20'
H = lambda n: '#### 7.44.%s ' % n
V = '[VERIFICAR] destino no deducible (identificador externo o interno)'
A = '(%s; antes "%s")' % (PA, V)

# ---- categoría 2: referencias
d.set_row('### 7.3 ', 'externalThreadId', '| `externalThreadId` | string | No | Id del proveedor (número, hilo de email, id de chat). No es referencia: identificador externo del hilo (%s). |' % PA, 2)
d.set_row('### 7.8 ', 'workflowRef', '| `workflowRef` | ObjectId → T11 `workflowDefinitions` | No | Definición de máquina de estados en T11 (%s; antes "ObjectId (T11)"). |' % PA, 2)
d.set_row('### 7.12 ', 'dependsOnCommandId', '| `dependsOnCommandId` | ObjectId → M09 `crmCommandRequests` | No | Orden de ejecución: comando del mismo caso que debe terminar antes (%s). |' % PA, 2)
d.set_row('### 7.13 ', 'mergedInto', '| `mergedInto` | ObjectId → M09 `crmContacts` | No | Unificación: contacto que sobrevive (%s). |' % PA, 2)
d.set_row('### 7.14 ', 'failureTypeId', '| `failureTypeId` | ObjectId → M10 `incidentCategories` | No | Tipo de falla. M10 no define `failureTypes`: la tipificación técnica de la causa es `incidentCategories` (%s; antes "ObjectId (M10)"). |' % PA, 2)
d.set_row('### 7.20 ', 'saleRef', '| `saleRef` | ObjectId → M05 `invoices` | No | Comprobante de venta que la otorgó (`ID_COMPV`) (%s; antes "ObjectId (M11/M05)"). |' % PA, 2)
d.replace_in_line('| `workOrders`, `incidentCategories`, `failureTypes`,', '`failureTypes`, ', '', 2)
d.replace_in_line('| `workOrders`, `incidentCategories`, `workOrderResolutions`,', 'alcance de incidentes |', 'alcance de incidentes (antes también `failureTypes`, que M10 no define: el tipo de falla es `incidentCategories`; %s) |' % PA)

d.table_to3(H(7), {})
d.set_row(H(7), 'workflowRef', '| `workflowRef` | ObjectId | → T11 `workflowDefinitions` %s |' % A, 2)
d.table_to3(H(9), {})
d.set_row(H(9), 'dependsOnCommandId', '| `dependsOnCommandId` | ObjectId | → M09 `crmCommandRequests` (comando previo del mismo caso) %s |' % A, 2)
d.table_to3(H(10), {})
d.set_row(H(10), 'failureTypeId', '| `failureTypeId` | ObjectId | → M10 `incidentCategories` %s |' % A, 2)
d.table_to3(H(12), {})
d.set_row(H(12), 'saleRef', '| `saleRef` | ObjectId | → M05 `invoices` (comprobante de venta `ID_COMPV`) %s |' % A, 2)
d.table_to3(H(17), {'targetType': 'enum'})
d.set_row(H(17), 'targetType', '| `targetType` | enum | No es referencia: discriminador de `targetId` (`case`, `conversation`, `message`, `attachment`) %s |' % A, 2)
d.set_row(H(17), 'targetId', '| `targetId` | ObjectId | Polimórfica según `targetType`: → M09 `crmCases` · `crmConversations` · `crmMessages` · T01 `storedFiles` (%s; antes "[VERIFICAR] polimórfica según el tipo de destino") |' % PA, 2)
d.add_rows_end_of_table(H(17), ['| `aiUsageLogId` | ObjectId | → T06 `aiUsageLogs` (llamada al proveedor de IA, CTR-DAT-04). Declarado en T05 (COL-CRM-26); no figuraba en el anexo (%s). |' % PA], 2)
d.set_row(H(29), 'closedByResponsibleId', '| `closedByResponsibleId` | ObjectId | [VERIFICAR] | `CODRES_CIE` | → T02 `memberships` (responsable que cerró, como `responsibleUserId`) %s |' % A, 2)
d.set_row(H(33), 'communicationRunIds', '| `communicationRunIds` | array | [VERIFICAR] | T09 | → T09 `campaigns` (envío masivo de la corrida, COL-COM-47) (%s; antes "[VERIFICAR] corridas de comunicación de T09 (colección no identificada en T05)") |' % PA, 2)
d.set_row(H(33), 'workOrderCommandIds', '| `workOrderCommandIds` | array | [VERIFICAR] | — | → M09 `crmCommandRequests` (comandos de OT que emite la corrida) %s |' % A, 2)

# ---- §7.45 resumen
d.insert_before_heading('## 8. Estados y transiciones', [
    '### 7.45 Residuales del 5-11-2026: referencias y nombres de T05 (%s)' % PA,
    '',
    'Ronda de residuales detectados al regenerar los entregables (categorías 2 y 4 de `_trabajo/residuales-instrucciones.md`). Las filas de §7.3 a §7.20 y de §7.44 quedaron corregidas en su lugar con "antes"; esta tabla las resume.',
    '',
    '| Colección | Campo | Tipo | Referencia | Antes |',
    '|---|---|---|---|---|',
    '| `crmConversations` | `externalThreadId` | string | No es referencia (identificador externo) | sin destino |',
    '| `crmStatusSets` | `workflowRef` | ObjectId | → T11 `workflowDefinitions` | "ObjectId (T11)" |',
    '| `crmCommandRequests` | `dependsOnCommandId` | ObjectId | → M09 `crmCommandRequests` | sin destino |',
    '| `crmContacts` | `mergedInto` | ObjectId | → M09 `crmContacts` | sin destino |',
    '| `crmIncidents` | `failureTypeId` | ObjectId | → M10 `incidentCategories` | "ObjectId (M10)" |',
    '| `crmHourBanks` | `saleRef` | ObjectId | → M05 `invoices` | "ObjectId (M11/M05)" |',
    '| `crmAiSuggestions` | `targetType` / `targetId` | enum / ObjectId | Discriminador / polimórfica (`crmCases`, `crmConversations`, `crmMessages`, `storedFiles`) | sin destino |',
    '| `crmAiSuggestions` | `aiUsageLogId` | ObjectId | → T06 `aiUsageLogs` | solo en T05 |',
    '| `crmActivityOccurrences` | `closedByResponsibleId` | ObjectId | → T02 `memberships` | sin destino |',
    '| `crmCircularRuns` | `communicationRunIds` | ObjectId[] | → T09 `campaigns` | sin destino |',
    '| `crmCircularRuns` | `workOrderCommandIds` | ObjectId[] | → M09 `crmCommandRequests` | sin destino |',
    '',
    'Campos que T05 cita con otro nombre (prevalece el anexo; T05 debe reflejarlo): `caseId` de COL-CRM-02, 04, 12, 17, 19 y 26 es `crmCaseId` (nombre canónico de la propia T05 §7.2, CTR-DAT-30; en `crmAiSuggestions` el caso es `targetType` = `case` + `targetId`); `crmAreas.branchId` es `branchIds[]`; `crmSlaPolicies.caseSubtypeId` es `scope.caseSubtypeIds[]`; `crmRoutingRules.areaId` es `target.areaId`; `crmChannels.connectionId` es `providerConnectionId`; `crmWorkLogs.projectId` no existe (el proyecto se toma del caso, `crmCases.projectId`); `crmCommandRequests.operationId` y `crmProcedureTypes.documentRequirementTypeIds[]` no existen en el anexo y T05 debe quitarlos (los requisitos documentales de M09 se declaran en `crmCaseTypes.requirementsTemplate`). Los `code` que T05 declara único ya figuran en §7.44 como "Declarado en T05".',
])

# ---- §8.14
rows = []
def r(c, f, t, trig, g='—', e='—'):
    rows.append('| `%s` | %s | %s | %s | %s | %s |' % (c, f, t, trig, g, e))
N = '(nuevo)'
r('crmCases.baseStatus', N, '`draft`', 'Socio (portal o app) o bot inicia la gestión sin enviarla', '—')
r('crmCases.baseStatus', N, '`received`', 'Alta directa por socio, agente, bot, sistema o público', 'Datos mínimos del tipo', '`crm.case.created`')
r('crmConversations', N, '`botActive`', 'Primer mensaje entrante en un canal con bot (`botFlowId`)')
r('crmConversations', N, '`queued`', 'Primer mensaje entrante en un canal sin bot o fuera del bot')
r('crmConversations', '`botActive`', '`queued`', 'Traspaso a humano')
r('crmConversations', '`queued`', '`assigned`', 'Asignación a un agente')
r('crmConversations', '`assigned`', '`active`', 'El agente responde')
r('crmConversations', '`active`', '`waitingCustomer`', 'Mensaje del agente que espera respuesta')
r('crmConversations', '`waitingCustomer`', '`active`', 'Respuesta del socio')
r('crmConversations', '`active` · `waitingCustomer`', '`closed`', 'Cierre por el agente', 'No cambia el caso (RN-CRM-003)')
r('crmConversations', '`active` · `waitingCustomer`', '`expired`', 'Vence la ventana del canal sin respuesta', 'WhatsApp 24 h; chat web PRM-CRM-064')
r('crmConversations', '`closed` · `expired`', '`queued`', 'Mensaje entrante nuevo', 'Se vincula al último caso abierto de la persona')
r('crmProcedureRecords', N, '`notPresented`', 'Alta del trámite exigido sin documentación')
r('crmProcedureRecords', N, '`presented`', 'Carga del trámite con documentación')
r('crmProcedureRecords', '`notPresented`', '`presented`', 'Carga de la documentación')
r('crmProcedureRecords', '`presented`', '`expired`', 'Job de vencimientos', 'Sin otro trámite vigente del mismo tipo; ejecuta `onExpiry`')
r('crmProcedureRecords', '`presented`', '`superseded`', 'Carga de un trámite nuevo del mismo tipo')
r('crmProcedureRecords', '`notPresented` · `presented` · `expired` · `superseded`', '`voided`', 'Anulación por error de carga', 'Motivo obligatorio')
r('crmWorkLogs.billingStatus', N, '`pending`', 'Cierre del registro de tiempo con minutos a facturar', '`billableMinutes` mayor que cero y tipo facturable')
r('crmWorkLogs.billingStatus', N, '`notBillable`', 'Cierre del registro de tiempo no facturable', 'Tipo no facturable o `billableMinutes` = 0')
r('crmWorkLogs.billingStatus', '`pending`', '`coveredByBank`', 'Consumo de una bolsa de horas (`hourBankId`)', 'Bolsa vigente con saldo (RN-CRM-050)')
r('crmWorkLogs.billingStatus', '`pending`', '`requested`', 'Solicitud de facturación a M05 (API-CRM-44)', '`crm.horas.facturar`')
r('crmWorkLogs.billingStatus', '`requested`', '`billed`', 'M05 emite el comprobante (`invoiceRef`)')
r('crmWorkLogs.billingStatus', '`requested`', '`pending`', 'M05 rechaza o anula el cargo pedido')
r('crmWorkLogs.billingStatus', '`pending`', '`notBillable`', 'El responsable bonifica el tiempo', 'Nota obligatoria')
r('crmQueueAppointments', N, '`booked`', 'Reserva desde web, app, WhatsApp o recepción', 'Franja con cupo')
r('crmQueueAppointments', '`booked`', '`confirmed`', 'Confirmación del socio o automática')
r('crmQueueAppointments', '`booked` · `confirmed`', '`checkedIn`', 'Check-in del socio', 'Genera turno `appointment` con prioridad de hora')
r('crmQueueAppointments', '`booked` · `confirmed`', '`cancelled`', 'Cancelación del socio o del tenant', 'Con aviso')
r('crmQueueAppointments', '`booked` · `confirmed`', '`noShow`', 'Job: pasó `slotEnd` más la tolerancia', 'PRM-CRM-111')
r('crmActivityOccurrences', N, '`pending`', 'Generación automática o alta manual de la ocurrencia')
r('crmActivityOccurrences', '`pending`', '`dueSoon`', 'Job diario', 'Hoy mayor o igual a fecha menos margen anterior')
r('crmActivityOccurrences', '`dueSoon`', '`overdue`', 'Job diario', 'Hoy mayor que fecha más margen posterior')
r('crmActivityOccurrences', '`pending` · `dueSoon` · `overdue`', '`closedOnTime`', 'Cierre por el responsable', 'Cierre hasta fecha más margen posterior')
r('crmActivityOccurrences', '`pending` · `dueSoon` · `overdue`', '`closedLate`', 'Cierre por el responsable', 'Cierre posterior al margen')
r('crmActivityOccurrences', '`pending` · `dueSoon` · `overdue`', '`closedWithReview`', 'Cierre con revisión', 'Aprobación de otro usuario si la actividad la exige')
r('crmActivityOccurrences', '`pending` · `dueSoon` · `overdue`', '`voided`', 'Anulación por el responsable del área', 'Motivo obligatorio')
r('crmActivityOccurrences', '`closedOnTime` · `closedLate` · `closedWithReview`', '`pending`', 'Reapertura por el responsable del área', 'Nota obligatoria')
r('crmCircularRuns', N, '`draft`', 'Alta de la corrida sobre un modelo de circular')
r('crmCircularRuns', '`draft`', '`pendingApproval`', 'Envío a aprobación', 'El modelo exige aprobación')
r('crmCircularRuns', '`draft` · `pendingApproval`', '`approved`', 'Aprobación (o confirmación si no exige aprobación)')
r('crmCircularRuns', '`approved`', '`generating`', 'Inicio de la generación')
r('crmCircularRuns', '`generating`', '`sent`', 'Envío completo por T09')
r('crmCircularRuns', '`generating`', '`partiallyFailed`', 'Envío con destinatarios fallidos', 'Los fallidos se reintentan por T09 o en una corrida nueva')
r('crmCircularRuns', '`draft` · `pendingApproval`', '`cancelled`', 'Cancelación')
r('crmBotFlows', N, '`draft`', 'Alta del flujo por el configurador')
r('crmBotFlows', '`draft`', '`published`', 'Publicación', 'Flujo validado; la versión publicada no se edita (se crea otra `version`)')
r('crmBotFlows', '`published`', '`archived`', 'Publicación de la versión sucesora o retiro', '—')
d.insert_before_heading('## 9. Procesos y flujos', [
    '### 8.14 Máquinas completadas y altas explícitas (residuales del 5-11-2026, %s)' % PA,
    '',
    'Traslada a tabla las máquinas que §8.1, §8.4, §8.6, §8.7, §8.9 y §8.10 daban en texto (el estado inicial solo figuraba como "Estado inicial: x" o "—"), agrega las transiciones de `crmWorkLogs.billingStatus` (solo tenía valores) y la tabla de `crmBotFlows` (patrón de publicación). Las filas `(nuevo)` fijan el estado inicial. Valores asumidos en %s (DEC-072); coinciden con §7. Prevalece esta tabla sobre el texto de las secciones citadas cuando difieran.' % PA,
    '',
    '`crmCaseSubtypes.defaultStatus` no es un campo de estado del subtipo: es un parámetro que indica el estado visible con el que nace un caso del subtipo (un `code` de `crmStatusSets.states[]`, §7.7); no tiene máquina propia. La tabla "Estados visibles" de §8.1 y los pases de §8.11 no son colecciones aparte.',
    '',
    '| Colección | Desde | Hacia | Disparador | Guarda | Evento |',
    '|---|---|---|---|---|---|',
] + rows)
d.count(1, len(rows) + 1)

d.insert_before_heading('## 22. Trazabilidad de fuentes', [
    '### %s — Residuales de los entregables: referencias, nombres de T05 y estados (5-11-2026)' % PA,
    '- **Pregunta**: ¿Qué destino tienen las referencias que los entregables marcaron sin colección en M09 (§7.45), cómo se concilian los campos que T05 nombra distinto y cuáles son el estado inicial y las transiciones de las máquinas que el §8 daba solo en texto?',
    '- **Contexto**: residuales de `docs/entregables-analisis-diseno/03-er/M09-CRM-atencion.md` §7 y de `06a-indice-cobertura-secuencias-estados.md` §7 (INC-06-02 y INC-06-08).',
    '- **Opciones**: A) **(Recomendada)** Destinos de §7.45 (T11 `workflowDefinitions`, M10 `incidentCategories`, M05 `invoices`, T09 `campaigns`, T02 `memberships`, autorreferencias), `aiUsageLogId` incorporado y máquinas de §8.14. B) Mantener `[VERIFICAR]` y el texto.',
    '- **Impacto si no se responde**: A.',
    '- **Bloquea**: diagrama ER y diagramas de estados de M09; T05 COL-CRM-02, 04, 09, 10, 11, 12, 16, 17, 19, 23 y 26.',
    '- **Estado**: Asumida (DEC-072): opción A. Aplicado en §7.3, §7.8, §7.12 a §7.14, §7.20, §7.43, §7.44, §7.45 y §8.14. T05 debe reflejar las equivalencias de §7.45 (en especial `crmCaseId` en lugar de `caseId`) y quitar `operationId` de COL-CRM-12 y `documentRequirementTypeIds[]` de COL-CRM-16; en §7.2.1, `externalThreadId` y `targetType` como "no es referencia".',
    '',
])
d.count(9, 1)
d.save()
report()
