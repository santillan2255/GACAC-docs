import re, os, glob, json
BASE = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
ANX = os.path.join(BASE, 'anexos')
T11 = os.path.join(ANX, 'T11-WFL-workflow-eventos-documentos.md')
MODS = 'per|cat|med|tar|fac|fis|cob|mor|crm|tec|ven|cmp|stk|tes|con|sue|ins|soc|por|com|wfl|bia|int|cfg|iam|pla|uxd|nfr|mig|col|cli|pag|inv|ten'
NAME_RE = re.compile(r'`((?:%s)\.[a-z][A-Za-z]*\.[a-z][A-Za-z-]*)`' % MODS)


def read(p):
    with open(p, encoding='utf-8') as f:
        return f.read()


def write(p, s):
    with open(p, 'w', encoding='utf-8', newline='') as f:
        f.write(s)


def expand(cell):
    out, base = [], ''
    for m in re.finditer(r'`([^`]+)`', cell):
        t = m.group(1).strip()
        if re.match(r'^[a-z]{3}\.[A-Za-z]+\.[A-Za-z.\-*]+$', t):
            p = t.split('.')
            base = p[0] + '.' + p[1]
            out.append('.'.join(p[:3]))
        elif base and re.match(r'^\.?[a-z][A-Za-z-]+$', t):
            out.append(base + '.' + t.lstrip('.'))
    return out


def t11_catalog():
    L = read(T11).split('\n')
    cat = {}
    s = e = None
    for i, l in enumerate(L):
        if l.startswith('### 12.2 '):
            s = i
        if l.startswith('### 12.4 '):
            e = i
            break
    for i in range(s, e):
        m = re.match(r'^\|\s*(EVT-[A-Z]{3}-\d+)[^|]*\|([^|]*)\|', L[i])
        if m:
            for n in expand(m.group(2)):
                cat.setdefault(n, m.group(1))
    return cat


def files():
    return sorted(glob.glob(os.path.join(ANX, '*.md')))
