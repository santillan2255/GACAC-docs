"""Segunda consolidación (ronda de residuales, 05-11-2026): PA nuevas en 02 y totales en 02 y en la maestra."""
import os, re, collections
os.chdir(os.path.join(os.path.dirname(__file__), '..'))
A = 'Asumida (DEC-072)'
R = 'Residuales del 05-11-2026: '
nuevas = [
    ('PA-PER-19', 'M01', R + 'estados, referencias y nombres', 'Estado inicial `received`; `streetRequestId` → `streetProposals` (T04); subsecciones absorbidas como referencia del circuito con dueño del estado (T08, T02); `subjectPersonId`/`target` sin cambios'),
    ('PA-CAT-23', 'M02', R + 'estados y referencias', 'Estado de alta de cada máquina (§8.5); `contractDeclaredAppliances` `active` → `removed`; `contractSpecialConditions` `draft` → `approved` → `expired` / `cancelled`; destinos `serviceProducts`, `documents` (T11), `feasibilityRequests` (M10) y `approvalRequests` (T11)'),
    ('PA-MED-15', 'M03', R + 'estados y referencias', 'Estado de alta y transiciones en §8.13; lecturista → `memberships` (T02); `deviceId` → `fieldDevices` (M10); expedientes → `documents` (T11); fotos → `storedFiles` (T01); `routeIds` → `readingRoutes`'),
    ('PA-TAR-21', 'M04', R + 'estados, referencias y nombres', '`subsidyEnrollments` inicial `active`; `calculationRuns` inicial `queued`; `rightId` → `burialRights` (M18); usar `fis.service.calculateTaxes`; API-TAR-061 con `public: true`'),
    ('PA-FAC-23', 'M05', R + 'estados, referencias y API reemplazada', 'Estados de alta y transiciones en §8.13; `ownerRole` → `roles` y `assigneeId` → `memberships` (T02); `serviceBlockId` obligatorio; API-FAC-023 reemplazada por API-MOR-25'),
    ('PA-FIS-22', 'M06', R + 'estados, servicios internos y referencias', 'Estado de alta en §8.12; `provincialValidationCodes` `active` → `expired`; máquina de `regulatoryReportRuns`; consumidores de `calculateTaxes`, `resolveDocumentClass` y `checkRegistryCoverage`; destinos en M12 y M06'),
    ('PA-COB-21', 'M07', R + 'referencias, nombres canónicos y estados', 'Destinos de §7.37 según T05 §7.2.1; nombres canónicos con alias "antes"; `collectors` y `gatewayConnectors` con `active`, `suspended`, `inactive` (§8.19)'),
    ('PA-MOR-22', 'M08', R + 'referencias, nombres canónicos, estados y alias', 'Destinos de §7.38; máquinas de §8.15; evento `int.network.provisioningResult` (alias con guiones); comando `tec.workOrder.request`; `billableItemId` (antes `pendingChargeId`)'),
    ('PA-CRM-20', 'M09', R + 'referencias, nombres de T05 y estados', 'Destinos de §7.45; `aiUsageLogId` incorporado; máquinas de §8.14; `crmCaseId` y `associateMembershipId` (antes `memberId`)'),
    ('PA-TEC-23', 'M10', R + 'referencias, estados, rutas de API, comando de OT y alias', 'Destinos de §7.23; máquinas de §8.16; comando `tec.workOrder.request`; evento `int.cdr.batchReceived` (alias con guiones)'),
    ('PA-VEN-12', 'M11', R + 'referencias, estados y API reemplazadas', 'Destinos de §7.15; máquinas de §8.6; API-VEN-006 → API-FAC-105 y API-VEN-007 → API-FAC-044'),
    ('PA-CMP-16', 'M12', R + 'estados, referencias y nombres de campo', '§8.8 con estados de `supplierAdvances`, `supplyBalances`, `signalRightsContracts` y `signalRightsSettlements`; facturas y recepciones de compra → `supplierInvoices` y `supplierReceipts`'),
    ('PA-STK-11', 'M13', R + 'estados, referencias, nombres de campo y evento bajo mínimo', '§8.14 (`stockState`, `revaluations`, `serviceReceptions`); `projectId` → `works` (M10); `requisitionId(s)` → `supplyRequests` y `purchaseReceiptId` → `supplierReceipts` (M12); evento `stk.item.belowMinimum`'),
    ('PA-TES-19', 'M14', R + 'estados, referencias, nombres de campo, CU duplicado y capability de API', 'Estado inicial explícito; §8.16.11 y §8.16.12; nombres de T05 con "antes"; CU-TES-17 (antes CU-13); API-TES-87 exige `tes.posicion.ver`'),
    ('PA-CON-19', 'M15', R + 'estados, referencias, nombres de campo y eventos de M17', 'Estado inicial de cada máquina; nombres de T05 con "antes"; `seriesId` → `economicIndexSeries` (T04); eventos de M17 con el nombre nuevo (alias el viejo)'),
    ('PA-SUE-18', 'M16', R + 'estados, referencias y nombres de campo', '§8.12.11 a §8.12.13; `shifts` `active`/`inactive`; `extraTasks` `draft`, `confirmed`, `voided`; nombres de T05 con alias'),
    ('PA-INS-13', 'M17', R + 'estados, referencias, nombres de campo y tipos de evento', 'Estado inicial explícito; §8.1 sobre `associateMemberships.status`; destinos (`accountRubrics`, `creditBalances`, `withholdingsApplied`, `dataTableViews`, `documentTemplates`); nombres de T05 (`*AssociateMembershipId`, `storedFileId`)'),
    ('PA-SOC-19', 'M18', R + 'estados, referencias, nombres de campo y evento GPS', '§8.2 completo; vínculos → `enumerationItems` (T04); tarifa → `tariffCategoryRates` (M04); plantillas → `documentTemplates` (T11); evento `int.fleet.positionsReceived`'),
    ('PA-POR-22', 'M19', R + 'estados, referencias, rótulo corto y nombre de PAN-POR-105', '`portalForms` inicial `borrador` y `kioskDevices` inicial `activo`; `cashboxId` → `cashRegisters` (M07); PAN-POR-105 "Comunidad"; rótulo corto "Cuentas" en la tabbar; consumir `ins.capitalMovement.recorded`'),
    ('PA-PLA-15', 'T01', 'Cierre de residuales del anexo (estados, referencias, API, colas y CU)', '§8.13; destinos y nombres canónicos de T05; `public: true` y capabilities implícitas o técnicas de T02 (PA-IAM-18); excepción de JOB-PLA-01 en la tabla de colas; CU propio renumerado a CU-PLA-15 (antes CU-ARQ-01)'),
    ('PA-IAM-18', 'T02', 'Cierre de residuales del anexo (capabilities, estados, referencias y CU)', '`public: true` en rutas sin sesión; capabilities implícitas (`iam.sesion.autenticada`, `pla.archivos.*`, `pla.misProcesos.ver`…) y técnicas (`pla.salud.sondear`, `mig.clavesHeredadas.resolver`); mapeo de scopes `erp`; §8.11; CU propio renumerado a CU-IAM-11 (antes CU-SEG-01)'),
    ('PA-UXD-18', 'T03', 'Cierre de residuales del anexo (mapa del sitio, tabbar, estados, API y CU)', 'Capability y ruta del anexo dueño (AL-01); rótulo corto "Cuentas"; tabla 8.8; CU propio renumerado a CU-UXD-07 (antes CU-ACC-01); PAN-UXD-15, 16 y 17 asignadas a RF-UXD-064, 063 y 055 (O0, PRO-O0-15), sin RF nuevos'),
    ('PA-CFG-15', 'T04', 'Cierre de residuales del anexo (pantalla sin ruta, servicios, API, estados y tablas de campos)', 'PAN-CFG-31 cita las rutas anfitrionas de M19; servicio `economicIndexes.valueAt({ seriesId, at })`; API-CFG-58 reemplazada por servicio interno; §8.11 y tablas de campos de §7.18'),
    ('PA-DAT-04', 'T05', 'Destinos de referencia pendientes y alineación del catálogo con los anexos dueños', 'Destino único por colección o módulo; el catálogo se alinea al anexo dueño cuando usa un nombre canónico y conserva el de §7.2 cuando no (el anexo renombra)'),
    ('PA-INT-27', 'T06', 'Cierre de residuales del anexo (tipos de evento, estados, referencias y API)', 'Tipos de evento en camelCase con alias en T11 §12.4; §8.13; `externalTransactionNumber` (antes `externalTransactionId`); tablas de campos de §7.18; `int.agentes.ejecutar`'),
    ('PA-MIG-21', 'T07', 'Cierre de residuales del anexo (estados, referencias, tablas de campos y API)', '§8.8; destinos (`billingRuns`, `documents`, `legacySnapshots`, `migrationMappingSets`); `mappingSetId` y `ruleCode` con "antes"; §7.14; `mig.clavesHeredadas.resolver` y `mig.miHistorial.ver`'),
    ('PA-NFR-24', 'T08', 'Cierre de residuales del anexo (estados, referencias, tablas de campos y API)', 'Transiciones en §15.2 y valores en §15.1; destinos `processingActivities` y `privacyNotices`; §15.1.1; `public: true` y `pla.salud.sondear`; CU-ARQ-01 citado como de T11'),
    ('PA-COM-19', 'T09', 'Cierre de residuales: carga rápida de reclamos por SMS, destinos de referencia y estados', 'Carga rápida habilitada por un canal `crmChannels` de M09 con `kind = sms`; `fieldAssignmentId` → `workOrders` (M10); `categoryIds[]` → `postCategories`; `targetTenants` → `tenants` (T01); estados completos en §8'),
    ('PA-BIA-17', 'T10', 'Cierre de residuales del anexo (estados, referencias, tablas de campos y API)', '§8.12; `scenarioId` → `simulationScenarios` (M15) y `templateOriginId` → `customReports`; `catalogQuestionCode` y `date` con "antes"; §7.26; `bia.reportes.ver`, `bia.exportaciones.crear`, `bia.apis.consumir`'),
    ('PA-WFL-23', 'T11', 'Cierre de residuales: nombres de eventos, alias con un solo canónico y máquinas de estado', 'Eventos en camelCase en §12.3 con el nombre viejo como alias en §12.4, un solo canónico por alias y todas las máquinas de §8 en tabla'),
]

F = '02-preguntas-abiertas.md'
raw = open(F, 'rb').read()
bom = raw.startswith(b'\xef\xbb\xbf')
t = raw.decode('utf-8-sig')
NL = '\r\n' if '\r\n' in t else '\n'
assert '| PA-PER-19 |' not in t, 'ya aplicado'
L = t.split(NL)
ult = max(i for i, l in enumerate(L) if l.startswith('| PA-'))
assert L[ult].startswith('| PA-WFL-22 |')
L[ult + 1:ult + 1] = ['| %s | %s | %s | %s | %s |' % (a, b, c, d, A) for a, b, c, d in nuevas]
c = collections.Counter()
for l in L:
    if re.match(r'\| PA-[A-Z0-9-]+?-\d+ \|', l):
        c[l.rstrip().rsplit('|', 2)[-2].strip().split(' ')[0]] += 1
tot = sum(c.values())
print(c, tot)
idx = next(i for i, l in enumerate(L) if l.startswith('**Actualización por el cierre de la corrección de inconsistencias (05-11-2026):**'))
nota = ('**Actualización por la ronda de residuales (05-11-2026):** %d preguntas registradas (antes 555); %d respondidas (sin cambios), '
        '%d asumidas con la opción recomendada (DEC-072; antes 456) y %d reemplazada. Se agregaron al final de la tabla las %d PA de cierre de residuales '
        'que los anexos registraron en su §21: %s.') % (tot, c['Respondida'], c['Asumida'], c['Reemplazada'], len(nuevas), ', '.join(x[0] for x in nuevas))
L[idx + 1:idx + 1] = ['', nota]
open(F, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + NL.join(L).encode('utf-8'))

M = '00-ESPECIFICACION-MAESTRA.md'
raw = open(M, 'rb').read()
t = raw.decode('utf-8-sig')
a = 'PA-MOR-20 y PA-POR-04, cuyos anexos ya aplican la DEC correspondiente.'
assert t.count(a) == 1
t = t.replace(a, a + (' Actualización por la ronda de residuales (05-11-2026): %d preguntas (antes 555), %d respondidas (sin cambios), %d asumidas (antes 456) '
                      'y %d reemplazada; se agregan las %d PA de cierre de residuales de los anexos.') % (tot, c['Respondida'], c['Asumida'], c['Reemplazada'], len(nuevas)))
open(M, 'wb').write((b'\xef\xbb\xbf' if raw.startswith(b'\xef\xbb\xbf') else b'') + t.encode('utf-8'))
print('ok')
