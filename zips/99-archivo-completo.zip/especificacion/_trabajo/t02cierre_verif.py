import re
P = 'anexos/T02-IAM-identidad-roles-auditoria.md'
raw = open(P, 'rb').read()
print('BOM', raw.startswith(b'\xef\xbb\xbf'), 'CRLF', raw.count(b'\r\n'))
t = raw.decode('utf-8')
L = t.split('\n')
i441 = L.index('#### 4.4.1 Alias de capabilities (nombre anterior → canónico)')
i442 = L.index('#### 4.4.2 Capabilities registradas por los anexos (mínimo obligatorio ampliado)')
i443 = L.index('#### 4.4.3 Nombres fuera de convención o sinónimos (canónica propuesta)')
i45 = next(i for i, l in enumerate(L) if l.startswith('### 4.5 '))
i44 = next(i for i, l in enumerate(L) if l.startswith('### 4.4 '))
defs = {}
for i in list(range(i44, i441)) + list(range(i442, i443)):
    m = re.match(r'\| `([^`]+)` \|', L[i])
    if m:
        defs.setdefault(m.group(1), []).append(i + 1)
dups = {k: v for k, v in defs.items() if len(v) > 1}
print('capabilities definidas', len(defs), 'duplicadas', dups)
alias = {}
parcial = set()
for i in range(i441, i442):
    m = re.match(r'\| `([^`]+)` \| `([^`]+)` \| ([^|]*)\|', L[i])
    if m:
        alias.setdefault(m.group(1), []).append(m.group(2))
        if m.group(3).startswith('Solo'): parcial.add(m.group(1))
print('alias', len(alias), 'alias duplicados', {k: v for k, v in alias.items() if len(v) > 1})
print('alias parciales (por ruta)', sorted(parcial))
print('alias totales que también son capability', [a for a in alias if a in defs and a not in parcial])
print('alias a canónica inexistente', [(a, c) for a, cs in alias.items() for c in cs if c not in defs])
# tablas: columnas coherentes
bad = []
for i, l in enumerate(L):
    if l.startswith('|') and i > 0 and not L[i - 1].startswith('|'):
        n = l.count('|') - l.count('\\|')
        j = i
        while j < len(L) and L[j].startswith('|'):
            nj = L[j].count('|') - L[j].count('\\|') - len(re.findall(r'`[^`]*\|[^`]*`', L[j]))
            if L[j].count('|') - L[j].count('\\|') != n:
                bad.append((j + 1, n, L[j].count('|') - L[j].count('\\|')))
            j += 1
print('filas con columnas distintas', bad[:20], len(bad))
print('SIGUE', t.count('<!-- SIGUE -->'), 'mojibake', len(re.findall('Ã|Â|â€', t)))
req = """tec.ext.ordenes.crear tec.telefonia.llamadas.ver crm.turnero.pantalla.ver crm.webhooks.recibir crm.ivr.consultar crm.config.canales.configurar crm.config.tramites.configurar mor.plataforma.restricciones.configurar mor.ext.expedientes.ver mor.ext.expedientes.registrar mor.ext.condicionMora.ver mor.bloqueos.ver mor.excepciones.editar mor.protecciones.ver mor.protecciones.editar mor.restricciones.configurar mor.incobrables.ver mor.informes.ver mor.informes.exportar cmp.concursos.ver cmp.concursos.editar cmp.reportes.exportar stk.lotes.editar stk.rendiciones.editar stk.inventarios.cerrar stk.revaluaciones.ver stk.revaluaciones.aprobar stk.fabricacion.estructuras.editar stk.fabricacion.ordenes.editar iam.directorio.ver mig.proyectos.configurar mig.paralelo.aprobar mig.bypass.aprobar mig.corte.aprobar mig.actaAceptacion.firmar int.operaciones.resolverManual int.bitacora.verPayload bia.datosAbiertos.publicar bia.datosSensibles.ver bia.reportes.programarExternos wfl.instancias.iniciar wfl.instancias.administrar wfl.firmas.solicitar per.documentacion.registrar per.documentacion.validar sue.novedades.editar sue.liquidaciones.crear sue.liquidaciones.anular por.conformidades.firmar por.totem.operar uxd.plataforma.diccionarioBase.ver uxd.plataforma.diccionarioBase.editar uxd.plataforma.diccionarioBase.publicar uxd.plataforma.flags.configurar uxd.plataforma.marca.ver uxd.plataforma.marca.asistir uxd.plataforma.tokens.ver uxd.plataforma.tokens.editar uxd.plataforma.ayudaBase.editar tec.ordenes.crearDerivada tec.cuadrillas.gestionar tec.servicioTecnico.ver tec.servicioTecnico.editar tec.guardias.gestionar tec.calidadAgua.gestionar tec.telefonia.numeracion.configurar tec.materiales.autorizar tec.materiales.solicitar tec.conflictos.resolver""".split()
print('faltan', [r for r in req if r not in defs])
# canónicas de 4.4.3 que no existen
miss = []
for i in range(i443, i45):
    m = re.match(r'\| [^|]+ \| `([^`]+)` \| `([^`]+)`', L[i])
    if m and m.group(2) not in defs:
        miss.append((m.group(1), m.group(2)))
print('4.4.3 canónica no registrada', len(miss), miss)
