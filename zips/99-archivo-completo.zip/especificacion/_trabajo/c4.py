﻿from repl import *
apply('M01', [
 ('| JOB-PER-02 | `per:geocodificar-domicilios` | Alta/cambio de domicilio; lote nocturno de pendientes | Normaliza y busca candidato con el proveedor configurado; respeta cuotas. |',
  '| JOB-PER-02 | `per:geocodificar-domicilios` | Alta/cambio de domicilio | Reacción: pide la geocodificación a T04 por API y aplica el resultado al recibir EVT-CFG-15 `cfg.geoReference.updated`; no llama al proveedor ni administra cuotas. Ver JOB-CFG-09 (dueño). |'),
 ('| JOB-PER-05 | `per:mayoria-edad-adherentes` | Diario | Lista adherentes que cumplen la edad (PRM-PER-067) y envía el aviso por T09 (PRM-PER-066). | Por adherente + año | 3 | Por tenant |',
  '| JOB-PER-05 | `per:mayoria-edad-adherentes` | — | **Retirado.** La mayoría de edad la detecta y avisa M18; M01 solo muestra el dato. Ver JOB-SOC-01 (dueño). | — | — | — |'),
 ('| JOB-PER-10 | `per:revalidar-padron-arca` | Mensual (PRM-PER-014) | Revalida identificaciones fiscales y lista diferencias de condición IVA sin cambiarlas (RF-PER-029). | Por identificación + período | 3 | Por tenant |',
  '| JOB-PER-10 | `per:revalidar-padron-arca` | — | **Retirado.** T04 guarda el padrón, T06 lo descarga y M06 revalida la condición; M01 muestra las diferencias al recibir EVT-FIS-19 `fis.padron.differenceDetected` (RF-PER-029). Ver JOB-CFG-08 y JOB-FIS-19 (dueños). | — | — | — |'),
], tag='job')
apply('M04', [
 ('| Avisos de último ciclo / fin de promoción. |', '| Avisos de último ciclo / fin de promoción; publica EVT-TAR-012. Dueño único del fin de promociones: M02 solo reacciona (JOB-CAT-10). |'),
], tag='job')
apply('M05', [
 ('| JOB-FAC-10 | `fac:recategorizar` | Operación aprobada | `operationId + contractId` | 3 | Simulación y confirmación. |',
  '| JOB-FAC-10 | `fac:recategorizar` | Operación aprobada | `operationId + contractId` | 3 | Solo simulación de facturación de la recategorización; M04 propone y M02 aplica el cambio al contrato. Ver JOB-TAR-05 (dueño). |'),
], tag='job')
apply('M06', [
 ('| JOB-FIS-08 | `fis:importar-padron` | A demanda / mensual | Padrones IIBB y offline |',
  '| JOB-FIS-08 | `fis:importar-padron` | — | **Retirado.** T04 guarda el padrón y T06 lo descarga (JOB-INT-25/26); M06 revalida con JOB-FIS-19. Ver JOB-CFG-08 (dueño). |'),
 ('| JOB-FIS-17 | `fis:sincronizar-parametros-arca` | Semanal (plataforma) | Tablas `FEParamGet*` |',
  '| JOB-FIS-17 | `fis:sincronizar-parametros-arca` | Evento EVT-INT-06 `int.arca.params-synced` | Reacción: adopta las tablas `FEParamGet*` que trae T06. Ver JOB-INT-18 (dueño). |'),
], tag='job')
apply('M09', [
 ('| JOB-CRM-01 | `crm:sla-monitor` | Cada minuto | Alertas, vencimientos y escalamientos SLA |',
  '| JOB-CRM-01 | `crm:sla-monitor` | Eventos EVT-WFL-020 / EVT-WFL-021 | Reacción: proyecta en el caso el aviso y el vencimiento SLA que calcula T11 y publica EVT-CRM-06/07 (PA-WFL-12). Ver JOB-WFL-04 (dueño). |'),
 ('| JOB-CRM-15 | `crm:appointment-reminders` | Cada 15 minutos | Recordatorios y ausencias de reservas |',
  '| JOB-CRM-15 | `crm:appointment-reminders` | Cada 15 minutos | Solo marca ausencias de reservas; los recordatorios los envía T09 a partir de la cita publicada. Ver JOB-COM-13 `com:recordatorios-agenda` (dueño). |'),
 ('| JOB-CRM-18 | `crm:whatsapp-templates-sync` | Diario | Sincroniza estado de plantillas aprobadas |',
  '| JOB-CRM-18 | `crm:whatsapp-templates-sync` | — | **Retirado.** M09 lee de T09 el estado de las plantillas. Ver JOB-COM-14 `com:sincronizar-plantillas-whatsapp` (dueño). |'),
], tag='job')
apply('M10', [
 ('| JOB-TEC-08 | `tec:recordatorios-visitas` | cada 15 min | Recordatorios previos a la visita. | `(visitId, reminderKind)`. |',
  '| JOB-TEC-08 | `tec:recordatorios-visitas` | — | **Retirado.** M10 solo publica la visita (EVT-TEC-13); el recordatorio lo envía T09. Ver JOB-COM-13 `com:recordatorios-agenda` (dueño). | — |'),
 ('| JOB-TEC-09 | `tec:importar-cdr` | a demanda / programado para fuentes online | Parseo, deduplicación y atribución de CDR. |',
  '| JOB-TEC-09 | `tec:importar-cdr` | Evento EVT-INT-16 `int.cdr.batch-received`; a demanda | Parseo, deduplicación y atribución de CDR (dueño); publica EVT-TEC-27. T06 solo recibe el archivo (JOB-INT-23 `int:recibir-cdr`). |'),
 ('| JOB-TEC-10 | `tec:geocodificar-pendientes` | cada hora | Enriquecer puntos pendientes respetando cuotas. | Por domicilio. |',
  '| JOB-TEC-10 | `tec:geocodificar-pendientes` | Evento EVT-CFG-15 | Reacción: pide la geocodificación a T04 por API y actualiza los puntos al recibir EVT-CFG-15 `cfg.geoReference.updated`. Ver JOB-CFG-09 (dueño). | Por domicilio. |'),
], tag='job')
apply('M14', [
 ('| JOB-TES-14 | `tes:reintentar-eventos` | Cada 5 min | Reprocesa eventos consumidos fallidos; envía a bandeja tras N intentos. |',
  '| JOB-TES-14 | `tes:reintentar-eventos` | — | **Retirado.** Los reintentos de eventos consumidos los hace T01 (`deadLetters`) y los agotados van a la bandeja operativa de T11. Ver `deadLetters` de T01 (dueño). |'),
], tag='job')
apply('T01', [
 ('| JOB-PLA-04 | `pla:expirar-accesos-soporte` | `maintenance` | plataforma | Cada minuto | Vence grants y revoca tokens |',
  '| JOB-PLA-04 | `pla:expirar-accesos-soporte` | `events` | plataforma | Evento EVT-IAM-11 | Reacción: al recibir EVT-IAM-11 (`iam.supportAccess.ended` / `.revoked`) emite EVT-PLA-12 `pla.supportGrant.expired`; no revoca tokens. Ver JOB-IAM-02 (dueño). |'),
], tag='job')
apply('T06', [
 ('| JOB-INT-23 | `int:importar-cdr` | Cron/buzón por central | CDR de centrales |',
  '| JOB-INT-23 | `int:recibir-cdr` | Cron/buzón por central | Recibe o descarga el archivo de CDR de la central y publica EVT-INT-16; no parsea ni atribuye. Ver JOB-TEC-09 (dueño del parseo). |'),
 ('| JOB-INT-27 | `int:vencer-intenciones` | Horario | Vence/limpia intenciones impagas (RN-INT-033) |',
  '| JOB-INT-27 | `int:vencer-intenciones` | Horario | Solo limpia la bitácora técnica de intenciones (RN-INT-033); el vencimiento de negocio es de M07. Ver JOB-COB-12 (dueño). |'),
], tag='job')
apply('T08', [
 ('| JOB-NFR-05 | `nfr:verificar-cadena-auditoria` | Diario 04:00 UTC | Verifica encadenamiento de hash y anclaje WORM (RNF-NFR-113) | Solo lectura |',
  '| JOB-NFR-05 | `nfr:verificar-cadena-auditoria` | — | **Retirado como job.** T08 define el control (RNF-NFR-113) y T02 lo ejecuta. Ver JOB-IAM-05 (dueño). | — |'),
 ('| JOB-NFR-12 | `nfr:antivirus-analizar` | Por archivo subido (cola `critical`) | Analiza, mueve o retiene (RNF-NFR-079) | Por objeto; reintento sin duplicar |',
  '| JOB-NFR-12 | `nfr:antivirus-analizar` | — | **Retirado.** T08 fija la política (RNF-NFR-079) y T01 analiza. Ver JOB-PLA-21 (dueño). | — |'),
 ('| JOB-NFR-19 | `nfr:conciliar-tras-restauracion` | Tras restauración selectiva | Consulta ARCA, pasarelas, entes y mensajería y reconcilia (RNF-NFR-044) | No reanuda jobs hasta terminar |',
  '| JOB-NFR-19 | `nfr:conciliar-tras-restauracion` | — | **Retirado.** T08 fija los controles (RNF-NFR-044) y T01 concilia. Ver JOB-PLA-12 (dueño). | — |'),
 ('| JOB-NFR-21 | `nfr:medir-consumo` | Cada hora y cierre mensual | Consolida `tenantUsageSnapshots` y evalúa cuotas y topes (RNF-NFR-250, 251); emite EVT-NFR-14 |',
  '| JOB-NFR-21 | `nfr:medir-consumo` | Evento EVT-PLA-10 | Reacción: evalúa cuotas y topes (RNF-NFR-250, 251) sobre la medición de T01 y emite EVT-NFR-14. Ver JOB-PLA-05 (dueño). |'),
], tag='job')
