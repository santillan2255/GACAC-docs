﻿import sys, re
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from repl import fpath
from conc_lib import read, write

p = fpath('T08')
s = read(p)

def rep(old, new, exp=1):
    global s
    c = s.count(old)
    if exp == 0:
        assert c >= 1, old[:80]
    else:
        assert c == exp, (c, old[:80])
    s = s.replace(old, new)

# 1) renombres globales a las colecciones canónicas (CTR-DAT-21, CTR-DAT-24)
rep('auditEvents', 'auditLogs', 0)
rep('restoreDrills', 'restoreTests', 0)
rep('processedEvents', 'inboxReceipts', 0)
rep('alertEvents', 'alerts', 0)
rep('tenantUsageSnapshots', 'usageSnapshots', 0)

# 2) notas de dueño en el modelo (15.1)
rep('**`restoreTests`** **[global]** (RF-NFR-015):',
    '**`restoreTests`** **[global]** (RF-NFR-015; dueño T01 COL-PLA-20, antes `restoreDrills` en T08, CTR-DAT-21; T08 fija los campos que necesita):')
rep('**`idempotencyKeys`** (RNF-NFR-212):',
    '**`idempotencyKeys`** (RNF-NFR-212; dueño T01 COL-PLA-28, CTR-DAT-21; T08 fija los requisitos):')
rep('**`inboxReceipts`** (RNF-NFR-214):',
    '**`inboxReceipts`** (RNF-NFR-214; dueño T01 COL-PLA-25, absorbe `processedEvents` de T08, CTR-DAT-21):')
rep('**`locks`** (RNF-NFR-216):',
    '**`locks`** (RNF-NFR-216; queda en T08 como respaldo de los locks de BullMQ, CTR-DAT-21):')
rep('**`alertRules`** **[global y por tenant]**:',
    '**`alertRules`** **[global y por tenant]** (dueño T01 COL-PLA-15, CTR-DAT-21):')
rep('**`alerts`**: `ruleCode`',
    '**`alerts`** (dueño T01 COL-PLA-16, antes `alertEvents` en T08, CTR-DAT-21): `ruleCode`')

# 3) bloque repetido: statusNotices y usageSnapshots aparecen dos veces
un = '**`usageSnapshots`** (RF-NFR-025, RNF-NFR-250):'
assert s.count(un) == 2
i1 = s.find(un)
s = s[:i1] + '**`usageSnapshots`** (RF-NFR-025, RNF-NFR-250; dueño T01 COL-PLA-09, antes `tenantUsageSnapshots` en T08, CTR-DAT-21):' + s[i1 + len(un):]
i2 = s.find(un)
s = s[:i2] + '**`usageSnapshots`** (repetición de la definición anterior; se conserva el texto) (RF-NFR-025, RNF-NFR-250):' + s[i2 + len(un):]
sn = '**`statusNotices`** **[global]** (RF-NFR-019, RNF-NFR-032):'
assert s.count(sn) == 2
j1 = s.find(sn)
j2 = s.find(sn, j1 + len(sn))
s = s[:j2] + '**`statusNotices`** **[global]** (repetición de la definición anterior; se conserva el texto) (RF-NFR-019, RNF-NFR-032):' + s[j2 + len(sn):]

# 4) auditoría
rep('### 11.1 Auditoría (metas sobre el registro `auditLogs` de T02)\n',
    '### 11.1 Auditoría (metas sobre el registro `auditLogs` de T02)\n\nNombre canónico `auditLogs` de T02 (antes citado en este anexo como `auditEvents`; CTR-DAT-24).\n')

# 5) DEC
rep('| RNF-NFR-199 | PDF y documentos generados:',
    '| RNF-NFR-199 | PDF y documentos generados (HTML + CSS renderizado con Chromium sin interfaz en workers dedicados, con validación PDF/A posterior, DEC-080):')
rep('A validar (PA-NFR-07)', 'Adoptado (DEC-076)', 2)
s_lines = s.split('\n')
for i, l in enumerate(s_lines):
    if l.startswith('| RNF-NFR-056 ') and 'DEC-074' not in l:
        s_lines[i] = l.replace('| RNF-NFR-056 |', '| RNF-NFR-056 | (Bóveda y cifrado de campos con cifrado por sobre en MongoDB y clave maestra en AWS KMS detrás de una interfaz agnóstica, DEC-074.)', 1)
        break
else:
    raise SystemExit('RNF-NFR-056 no encontrado')
est = {
    'PA-NFR-03': 'Respondida (DEC-075): tenant estándar 25.000 suministros y grande 150.000; diseño para 100 tenants y hasta 300 sin rediseño.',
    'PA-NFR-07': 'Respondida (DEC-076): GoodApps es prestador de servicios de tratamiento por cuenta de la cooperativa (art. 25): contrato tipo de encargo, registro público de subencargados y destrucción o devolución al fin del encargo.',
}
for pa, txt in est.items():
    h = [i for i, l in enumerate(s_lines) if l.startswith('### ' + pa + ' ')]
    assert len(h) == 1, pa
    i = h[0] + 1
    while not s_lines[i].startswith('- **Bloquea:**'):
        assert not s_lines[i].startswith('### '), pa
        i += 1
    if not s_lines[i + 1].startswith('- **Estado:**'):
        s_lines.insert(i + 1, '- **Estado:** ' + txt)
s = '\n'.join(s_lines)
write(p, s)
print('T08 ok')
