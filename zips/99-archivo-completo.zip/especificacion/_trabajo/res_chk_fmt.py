import glob, os
from res_lib_m12m19 import MOJI
B = 'backup-residuales-M12M19-202611051600'
for f in sorted(glob.glob('../anexos/M1[2-9]-*.md')):
    n = os.path.basename(f)
    a, b = open(os.path.join(B, n), 'rb').read(), open(f, 'rb').read()
    ta, tb = a.decode('utf-8-sig'), b.decode('utf-8')
    lf = lambda t: (t.count('\r\n'), t.count('\n') - t.count('\r\n'))
    print(n[:3], 'BOM', a[:3] == b'\xef\xbb\xbf', b[:3] == b'\xef\xbb\xbf', 'CRLF/LF antes', lf(ta), 'ahora', lf(tb),
          'moji', sum(ta.count(m) for m in MOJI), sum(tb.count(m) for m in MOJI))
