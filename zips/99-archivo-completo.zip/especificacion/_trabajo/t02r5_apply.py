# Ronda final de cierre en T02: asistentes, preferencias, accesos al portal, recurso único de cajas y comodines de actores de M10.
import re, sys
sys.stdout.reconfigure(encoding='utf-8')
P = 'anexos/T02-IAM-identidad-roles-auditoria.md'
raw = open(P, 'rb').read(); assert not raw.startswith(b'\xef\xbb\xbf') and b'\r\n' not in raw
t = raw.decode('utf-8')
def rep(a, b):
    global t
    assert t.count(a) == 1, a[:80]
    t = t.replace(a, b)

for c in ['uxd.preferencias.editar', 'por.asistente.ver', 'wfl.asistente.ver', 'cob.caja.abrir', 'cob.caja.cerrar',
          'cob.caja.supervisar', 'cob.caja.configurar']:
    assert not re.search(r'^\| `' + re.escape(c) + '`', t, re.M), c
for c in ['por.portal.ver', 'por.empleado.ver', 'por.preferencias.editar']:
    assert not re.search(r'^\| `' + re.escape(c) + '` \| [^`]', t, re.M), c

NEW = {
    'T03': ['| `uxd.preferencias.editar` | Editar preferencias propias de interfaz (tema, densidad, tamaño de texto, fijados, vistas, modo de feed); implícita para todo usuario autenticado | — | Todos staff y comunidad (implícita) | self | T03 §4, PAN-UXD-08, SM-PWS-036 |'],
    'T11': ['| `wfl.asistente.ver` | Ver y usar el asistente IA de la PWA del empleado; solo con flag `pwa.asistente` (PA-UXD-16) | — | C-EMP | self | T03 PAN-UXD-15, SM-PWE-017 |'],
    'M19': [
        '| `por.asistente.ver` | Ver y usar el asistente IA de la PWA del socio; solo con flag `pwa.asistente` (PA-UXD-16) | — | C-SOC, C-REP, C-ADH | self / rel | T03 PAN-UXD-15, SM-PWS-041 |',
        '| `por.portal.ver` | Acceso al portal y a la PWA del socio (inicio, tabbar, destino Comunidad); la exigen todas las pantallas del espacio socio. Alias parcial a `com.inbox.ver` solo en `/app/avisos` (4.4.1) | — | C-SOC, C-REP, C-ADH, C-VIS | self / rel | M19 §4, PAN-POR-105, API-POR-92 |',
        '| `por.empleado.ver` | Acceso al espacio del empleado en la PWA (inicio, muro interno, avisos). Alias parcial a `com.inbox.ver` solo en `/app/empleado/avisos` (4.4.1) | — | C-EMP | self | M19 §4, PAN-POR-69, API-POR-93 (+2) |',
        '| `por.preferencias.editar` | Preferencias propias del portal (apariencia, API-POR-25) y de envío de comprobantes (adhesión a factura digital, M05 API-FAC-153 `/api/fac/my-delivery-preferences`). Capability propia; su alias a `com.preferences.editar` vale solo para PAN-POR-60 (4.4.1) | — | C-SOC, C-REP, C-ADH, C-VIS | self / rel | M05 §4, API-FAC-153, API-POR-25, PAN-POR-62 |',
    ],
}
L = t.split('\n')
def sec_range(an):
    i = next(k for k, l in enumerate(L) if l.startswith('##### ' + an + ' '))
    j = i + 1
    while not L[j].startswith('| Capability |'): j += 1
    j += 2; s = j
    while L[j].startswith('| `'): j += 1
    return s, j
def resort(an, extra=()):
    s, e = sec_range(an)
    block = L[s:e] + list(extra)
    names = [re.match(r'\| `([^`]+)`', x).group(1) for x in block]
    assert len(names) == len(set(names)), an
    L[s:e] = [x for _, x in sorted(zip(names, block))]
for an, rows in NEW.items(): resort(an, rows)
t = '\n'.join(L)

# Recurso único de cajas: cob.caja (11 capabilities registradas frente a 4 de cob.cajas)
for act, old in [('abrir', '| `cob.cajas.abrir` | Abrir caja del turno |'), ('cerrar', '| `cob.cajas.cerrar` | Cerrar caja y arqueo |'),
                 ('supervisar', '| `cob.cajas.supervisar` | Ver/forzar cierre de cajas ajenas |'),
                 ('configurar', '| `cob.cajas.configurar` | ABM de cajas y QR estático. |')]:
    desc = old.split(' | ')[1].rstrip(' |').rstrip('.')
    rep(old, f'| `cob.caja.{act}` | {desc} (antes `cob.cajas.{act}`; recurso único `cob.caja`, alias en 4.4.1) |')
L = t.split('\n'); resort('M07'); t = '\n'.join(L)

ali = [(f'cob.cajas.{a}', f'cob.caja.{a}', u) for a, u in
       [('abrir', 'M07 (§4, API-COB-27, PAN-COB-09), T03'), ('cerrar', 'M07 (§4, API-COB-29, API-COB-30)'),
        ('supervisar', 'T02 §4.4'), ('configurar', 'M07 (API-COB-26, PAN-COB-08), T03'), ('ver', 'M14 §4, T03 (SM-ADM-061)')]]
L = t.split('\n')
i = L.index('#### 4.4.2 Capabilities registradas por los anexos (mínimo obligatorio ampliado)')
j = i - 1
while not L[j].startswith('| `'): j -= 1
L[j + 1:j + 1] = [f'| `{o}` | `{c}` | Total | {u} | Ronda final de cierre: recurso único `cob.caja` (el de más capabilities registradas en M07) |' for o, c, u in ali]
t = '\n'.join(L)

rep('| cob | `cob.caja.abrir` | `cob.cajas.abrir` | Variante singular/plural de una capability existente |',
    '| cob | `cob.caja.abrir` | `cob.caja.abrir` (Reemplazado: ahora es la canónica, recurso único `cob.caja`; antes canónica `cob.cajas.abrir`, que queda como alias en 4.4.1) | Variante singular/plural (resuelta en la ronda final) |')
rep('| cob | `cob.caja.cerrar` | `cob.cajas.cerrar` | Variante singular/plural de una capability existente |',
    '| cob | `cob.caja.cerrar` | `cob.caja.cerrar` (Reemplazado: ahora es la canónica, recurso único `cob.caja`; antes canónica `cob.cajas.cerrar`, que queda como alias en 4.4.1) | Variante singular/plural (resuelta en la ronda final) |')
rep('| cob | `cob.cajas.ver` | `cob.caja.ver` | Duplica una capability existente (M07 registra `cob.caja.*` en singular) |',
    '| cob | `cob.cajas.ver` | `cob.caja.ver` (alias en 4.4.1) | Duplica una capability existente (recurso único `cob.caja`) |')

# Alias parcial de por.preferencias.editar
rep('`por.preferencias.editar` sigue vigente para las preferencias del portal (API-POR-25) |',
    '`por.preferencias.editar` es capability propia (4.4.2 M19: preferencias del portal API-POR-25 y de envío de comprobantes M05 API-FAC-153) y el alias no aplica fuera de PAN-POR-60 |')
rep('`por.portal.ver` sigue exigido como acceso al portal |', '`por.portal.ver` sigue exigido como acceso al portal (registrada en 4.4.2 M19) |')
rep('`por.empleado.ver` sigue exigido como acceso al espacio del empleado |', '`por.empleado.ver` sigue exigido como acceso al espacio del empleado (registrada en 4.4.2 M19) |')

# Comodines de actores de M10 en 4.4.3
add = [
    '| cob | `cob.campo.*` | — (explicitar: `cob.cobranzaCampo.ver`, `cob.cobranzaCampo.cobrar`, `cob.cobradores.rendir`; rol Cobrador de M07 §4) | Comodín de actor: no es una capability asignable y `cob.campo` no es recurso registrado | M10 | M10 §4 (Cobrador, app de campo) |',
    '| med | `med.lecturas.*` | — (explicitar: lecturista `med.lecturas.ver`, `.capturar`, `.crear`; supervisor de consumos `.corregir`, `.anular`, `.importar`) | Comodín de actor: no es una capability asignable | M10 | M10 §4 (Lecturista, app de campo) |',
    '| tec | `tec.campo.*` | — (explicitar para inspección: `tec.campo.ver`, `.ejecutar`, `.evidencia`, `.marcarEnCamino`, `.registrarConformidad`, `.registrarMateriales`, `.crearOrden`, `.cerrar`; `.cerrarCuadrilla` es del líder de cuadrilla) | Comodín de actor: no es una capability asignable | M10 | M10 §4 (Inspector) |',
]
L = t.split('\n')
k3 = L.index('#### 4.4.3 Nombres fuera de convención o sinónimos (canónica propuesta)')
s = k3
while not L[s].startswith('| Módulo | Nombre usado'): s += 1
s += 2; e = s
while e < len(L) and L[e].startswith('| '): e += 1
block = L[s:e] + add
keys = [(x.split(' | ')[0], re.search(r'`([^`]+)`', x.split(' | ')[1]).group(1)) for x in block]
assert len(keys) == len(set(keys))
L[s:e] = [x for _, x in sorted(zip(keys, block))]
t = '\n'.join(L)
open(P, 'wb').write(t.encode('utf-8')); print('OK')
