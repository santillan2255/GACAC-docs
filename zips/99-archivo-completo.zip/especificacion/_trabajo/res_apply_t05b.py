import sys, io, glob
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
F = glob.glob(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T05-*")[0]
txt = open(F, "rb").read().decode("utf-8")
NL = "\r\n"
assert "\n" not in txt.replace("\r\n", "")
lines = txt.split(NL)
n = 0

def al(mod, antes):
    return "(5-11-2026, residuales: alineado a %s §7; antes %s)" % (mod, antes)

def row(colid, mod, claves=None, unicos=None):
    """claves/unicos: (valor_actual_esperado, valor_nuevo)"""
    global n
    idx = [i for i, l in enumerate(lines) if l.startswith("| " + colid + " |")]
    assert len(idx) == 1, colid
    i = idx[0]
    parts = lines[i].split("|")
    assert len(parts) == 13, (colid, len(parts))
    for j, spec in ((5, claves), (6, unicos)):
        if spec is None:
            continue
        old, new = spec
        cur = parts[j].strip()
        assert cur == old, (colid, j, cur)
        parts[j] = " " + new + " " + al(mod, "`" + old.replace("`", "") + "`" if "`" in old else old) + " "
    lines[i] = "|".join(parts)
    n += 1

# T01
row("COL-PLA-03", "T01", claves=("`moduleCodes[]`", "`modules[]`"))
row("COL-PLA-24", "T01", claves=("`eventType`, `aggregateId`", "`type`, `aggregateId`"))
row("COL-PLA-27", "T01", claves=("`jobDefinitionCode`", "`jobName`"), unicos=("`{jobId}`", "`{jobKey}` p. (no terminales)"))
# T02
row("COL-IAM-08", "T02", claves=("`membershipId`, `screenProfileId`", "`membershipId`, `profileId`"))
row("COL-IAM-09", "T02", claves=("`moduleCode`", "`module`"))
row("COL-IAM-10", "T02", claves=("`capabilities[]`", "`requiredAny[]`"), unicos=("`code`", "`screenId`"))
row("COL-IAM-13", "T02", unicos=("`refreshFamilyId`", "`familyId`"))
row("COL-IAM-18", "T02", claves=("`entityRef`", "`entity` (`{collection, id}`)"), unicos=("`{entityRef, membershipId}`", "`{entity.collection, entity.id, membershipId}`"))
row("COL-IAM-23", "T02", unicos=("`keyPrefix`", "`secretPrefix`"))
row("COL-IAM-24", "T02", claves=("`entityRef`, `actorId`", "`entity`, `actor` (`actor.membershipId` → `memberships`)"))
# T04
row("COL-CFG-01", "T04", claves=("`moduleCode`", "`module`"))
row("COL-CFG-02", "T04", unicos=("`{key, scopeType, scopeId, validFrom}`", "`{key, scope.type, scope.refId, validFrom}`"))
row("COL-CFG-06", "T04", claves=("`enumerationId`", "`enumCode`"), unicos=("`{enumerationId, code}` p.", "`{enumCode, code}` p."))
row("COL-CFG-08", "T04", claves=("`countryId`", "`countryIso2`"))
row("COL-CFG-09", "T04", claves=("`provinceId`", "`provinceCode`"))
row("COL-CFG-10", "T04", claves=("`departmentId`", "`departmentCode`"))
row("COL-CFG-11", "T04", claves=("`localityId`", "`localityCodes[]`"), unicos=("`{code, localityId}`", "`code`"))
row("COL-CFG-12", "T04", claves=("`localityId`", "`localityCode`"), unicos=("`{localityId, code}`", "`{localityCode, normalizedName}`"))
row("COL-CFG-15", "T04", claves=("`localityId`", "`localityCode`"), unicos=("`{localityId, code}`", "`{localityCode, code}`"))
row("COL-CFG-17", "T04", claves=("`localityId`", "`localityCode`"))
row("COL-CFG-20", "T04", claves=("`calendarId`", "`calendarCode`"), unicos=("`{calendarId, date}`", "`{calendarCode, date}`"))
row("COL-CFG-38", "T04", claves=("`seedPackId`", "`seedPackCode`"), unicos=("`{seedPackId, version}`", "`{seedPackCode, version}`"))
row("COL-CFG-39", "T04", unicos=("`{legacyKey}`", "`{legacyTable, modVar, codVar}`"))
# T06
row("COL-INT-02", "T06", claves=("`providerCode`, `credentialRef`", "`providerCode`, `secretRefs` (→ `integrationSecrets`)"))
row("COL-INT-09", "T06", unicos=("`{endpointId, dedupeKey}`", "`{endpointId, dedupKey}`"))
row("COL-INT-11", "T06", claves=("`fileLayoutId`, `storedFileId`", "`layoutCode` + `layoutVersion`, `storedFileId`"), unicos=("`{connectionId, fileHash}`", "`{connectionId, sha256}`"))
row("COL-INT-15", "T06", claves=("`entityRef`, `providerCode`", "`entity` (`{type, id}`), `system`"), unicos=("`{providerCode, externalId, entityType}`", "`{system, externalId, entity.type}`"))
row("COL-INT-17", "T06", claves=("`localAgentId`", "`agentId` (→ `localAgents`)"))
# T08
row("COL-NFR-04", "T08", claves=("`personId`, `purpose`, `channel`", "`personId`, `purposeCode`, `channel`"))
row("COL-NFR-21", "T08", claves=("`platformIncidentId`", "`incidentId` (→ `platformIncidents`)"))
# T10
for cid in ("COL-BIA-04", "COL-BIA-06", "COL-BIA-10"):
    row(cid, "T10", claves=("`reportDefinitionId`", "`reportCode`"))
row("COL-BIA-02", "T10", claves=("`reportDefinitionId`", "`reportCode`"), unicos=("`{reportDefinitionId, name}`", "`{reportCode, name}`"))
row("COL-BIA-03", "T10", claves=("`reportDefinitionId`", "`reportCode`"), unicos=("`{ownerId, name}`", "`{ownerUserId, name}`"))
row("COL-BIA-05", "T10", claves=("`reportRunId`, `storedFileId`", "`runId` (→ `reportRuns`), `storedFileId`"))
row("COL-BIA-12", "T10", claves=("`indicatorId`", "`indicatorCode`"), unicos=("`{indicatorId, date, scopeKey}`", "`{indicatorCode, periodKey, dimensionKey}`"))
row("COL-BIA-14", "T10", claves=("`dashboardId`, `membershipId`", "`dashboardCode`, `userId`"), unicos=("`{dashboardId, membershipId}`", "`{dashboardCode, userId}`"))
row("COL-BIA-15", "T10", claves=("`indicatorId`", "`indicatorCode`"))
row("COL-BIA-16", "T10", claves=("`kpiAlertRuleId`", "`ruleId` (→ `kpiAlertRules`)"))
row("COL-BIA-29", "T10", unicos=("`{period, metric}`", "`{indicatorCode, periodKey, segmentKey}`"))
# M07
row("COL-COB-21", "M07", claves=("`fileLayoutIds[]`", "`exportLayoutId`, `importLayoutId`, `controlLayoutId`"))
row("COL-COB-34", "M07", claves=("`items.obligationId`, `gatewayConnectorId`", "`items.obligationId`, `connectorId`"))
# M09
row("COL-CRM-02", "M09", claves=("`caseId`", "`crmCaseId`"), unicos=("`{caseId, seq}`", "`{crmCaseId, seq}`"))
row("COL-CRM-04", "M09", claves=("`caseId`, `conversationId`", "`crmCaseId`, `conversationId`"))
row("COL-CRM-09", "M09", claves=("`branchId`", "`branchIds[]`"))
row("COL-CRM-12", "M09", claves=("`caseId`, `operationId`", "`crmCaseId`, `operationId`"))
row("COL-CRM-17", "M09", claves=("`procedureTypeId`, `caseId`", "`procedureTypeId`, `crmCaseId`"))
row("COL-CRM-19", "M09", claves=("`caseId`, `projectId`, `userId`", "`crmCaseId`, `projectId`, `userId`"))
row("COL-CRM-23", "M09", claves=("`connectionId`", "`providerConnectionId`"))
row("COL-CRM-26", "M09", claves=("`caseId`, `aiUsageLogId`", "`crmCaseId`, `aiUsageLogId`"))
# M10
row("COL-TEC-14", "M10", claves=("`entityRef`, `storedFileId`", "`entityType` + `entityId`, `storedFileId`"))
# M13
row("COL-STK-26", "M13", claves=("`itemGroupId`, `serialUnitId`, `costCenterId`", "`itemGroupId`, `serialUnitId`, `costCenterAllocation[].costCenterId`"))
# M14 (canónicos de §7.2: `accountId` queda prohibido para cuenta de tesorería)
row("COL-TES-14", "M14", unicos=("`{accountId, fingerprint}`", "`{treasuryAccountId, fingerprint}`"))
row("COL-TES-21", "M14", claves=("`treasuryAccountId`, `storedFileId`", "`originTreasuryAccountId` (canónico de §7.2.1; M14 lo llama `originAccountId` y debe renombrarlo), `storedFileId`"),
    unicos=("`{accountId, sequence}`", "`{originTreasuryAccountId, sequence}`"))
row("COL-TES-22", "M14", unicos=("`{institutionId, branchId, accountNumber, checkNumber}` p.; `echeqId` p.", "`{institutionId, bankBranchId, accountNumber, checkNumber}` p.; `echeqId` p."))
# M15
row("COL-CON-14", "M15", claves=("`ledgerAccountId`", "`targetAccountId` (→ `ledgerAccounts`, §7.2.1)"))
row("COL-CON-24", "M15", claves=("`chartId`", "`targetChartId`"))
row("COL-CON-25", "M15", unicos=("`{chartId, accountId, periodId, costCenterId, serviceId}`", "`{chartId, ledgerAccountId, periodId, costCenterId, serviceId}`"))
row("COL-CON-27", "M15", unicos=("`{budgetId, accountId, costCenterId, serviceId, month}`", "`{budgetId, ledgerAccountId, costCenterId, serviceId, month}`"))
row("COL-CON-37", "M15", claves=("`fileLayoutId`, `storedFileId`", "`layoutId`, `storedFileId`"))
# M16
row("COL-SUE-14", "M16", claves=("`extraGroupId`", "`groupId` (→ `extraGroups`)"))
row("COL-SUE-24", "M16", claves=("`officialCodeId`", "`officialCode` (código de `payrollOfficialCodes`, no ObjectId)"))
row("COL-SUE-39", "M16", claves=("`legalEntityId`, `payPeriodId`", "`legalEntityId`, `periodKey`"))

open(F, "wb").write(NL.join(lines).encode("utf-8"))
print("filas alineadas:", n)
