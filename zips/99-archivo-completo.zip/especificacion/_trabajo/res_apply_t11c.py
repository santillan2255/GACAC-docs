import sys, io, glob, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
F = glob.glob(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T11-*")[0]
raw = open(F, "rb").read()
assert raw.startswith(b"\xef\xbb\xbf")
t = raw[3:].decode("utf-8")
cnt = {}
def rep(old, new, k, n=1):
    global t
    c = t.count(old)
    assert c == n, (k, old[:100], c)
    t = t.replace(old, new)
    cnt[k] = cnt.get(k, 0) + 1

H = "| Desde | Hacia | Disparador | Guarda (RN) | Evento |\n|---|---|---|---|---|\n"
NOTE = "Tabla agregada el 5-11-2026 (PA-WFL-23); repite en formato de tabla lo que dice el texto anterior.\n\n"

# 8.3 bulkRuns
rep("Una corrida `cancelled` conserva los ítems ya confirmados; no se deshacen salvo con una operación de reversión del módulo dueño.\n",
    "Una corrida `cancelled` conserva los ítems ya confirmados; no se deshacen salvo con una operación de reversión del módulo dueño.\n\n" + NOTE + H +
    "| — | `draft` | Alta de la corrida por el módulo dueño | — | — |\n"
    "| `draft` | `preparing` | Inicio de la preparación | — | — |\n"
    "| `preparing` | `ready` | Universo congelado | — | — |\n"
    "| `ready` | `running` | Ejecución (job de clase `batch`, §12.8) | — | — |\n"
    "| `running` | `paused` | Pausa `manual`, `systemic` o `threshold` | Motivo obligatorio | EVT-WFL-048 `.paused` |\n"
    "| `paused` | `running` | Reanudación desde el cursor | — | — |\n"
    "| `running` | `succeeded` / `succeededWithExceptions` | Fin del universo | Con excepciones si hay ítems `failed` | EVT-WFL-048 `.completed` |\n"
    "| `running` | `failed` | Error que impide seguir | — | EVT-WFL-048 `.failed` |\n"
    "| `draft` / `preparing` / `ready` / `running` / `paused` | `cancelled` | Cancelación por el solicitante o un administrador | Conserva los ítems confirmados | EVT-WFL-048 `.cancelled` |\n"
    "| `succeededWithExceptions` | `succeededWithExceptions` (corrida hija `reprocess`) | Reproceso de las excepciones resueltas | La corrida madre no cambia; la hija nace en `draft` | — |\n", "cat1-tabla")

# 8.5 tasks
rep("Completar exige checklist y evidencias obligatorias. Las ocurrencias recurrentes vencidas pasan a la vista \"Vencida\" sin cambiar de estado y se cierran \"en término\" o \"fuera de término\" según la fecha real de cierre (RN-WFL-039).\n",
    "Completar exige checklist y evidencias obligatorias. Las ocurrencias recurrentes vencidas pasan a la vista \"Vencida\" sin cambiar de estado y se cierran \"en término\" o \"fuera de término\" según la fecha real de cierre (RN-WFL-039).\n\n" + NOTE + H +
    "| — | `open` | Creación de la tarea | — | EVT-WFL-023 |\n"
    "| `open` | `inProgress` | La toma o la inicia el asignado | — | EVT-WFL-024 `.claimed` |\n"
    "| `open` / `inProgress` | `blocked` | Espera de un tercero | — | — |\n"
    "| `blocked` | `inProgress` | Fin de la espera | — | — |\n"
    "| `inProgress` | `completed` | Cierre por el asignado | Checklist y evidencias obligatorias (RN-WFL-039) | EVT-WFL-025 `.completed` |\n"
    "| `open` / `inProgress` | `cancelled` | Cancelación con motivo | Motivo obligatorio | EVT-WFL-025 `.cancelled` |\n"
    "| `completed` | `reopened` | Reapertura | El origen la admite y dentro de PRM-WFL-026 días | EVT-WFL-025 `.reopened` |\n"
    "| `reopened` | `inProgress` | El asignado retoma la tarea | — | — |\n", "cat1-tabla")

# 8.7 signatureRequests
rep("Con `completed` se crea la versión firmada (`signedVersionId`) y se marca como aceptada (EVT-WFL-042).\n",
    "Con `completed` se crea la versión firmada (`signedVersionId`) y se marca como aceptada (EVT-WFL-042).\n\n" + NOTE + H +
    "| — | `draft` | Alta del pedido de firma | — | — |\n"
    "| `draft` | `sent` | Envío a los firmantes | Al menos un participante | EVT-WFL-041 `.requested` |\n"
    "| `sent` | `partiallySigned` | Firma de un participante sin completar el circuito | RN-WFL-050 (firmante vigente) | EVT-WFL-041 `.participantSigned` |\n"
    "| `sent` / `partiallySigned` | `completed` | Firma del último participante | — | EVT-WFL-042 |\n"
    "| `sent` | `providerPending` | Firma digital enviada al proveedor (T06) | Perfil de firma digital | — |\n"
    "| `providerPending` | `completed` / `failed` | `int.signature.completed` / `int.signature.rejected` (EVT-INT-18) | — | EVT-WFL-042 / EVT-WFL-043 |\n"
    "| `sent` / `partiallySigned` | `rejected` | Un firmante rechaza | Motivo obligatorio | EVT-WFL-043 `.rejected` |\n"
    "| `sent` / `partiallySigned` | `expired` | Vence `expiresAt` | — | EVT-WFL-043 `.expired` |\n"
    "| `draft` / `sent` | `cancelled` | Cancelación por el solicitante | — | EVT-WFL-043 `.cancelled` |\n", "cat1-tabla")

# 8.8 dossiers
rep("- `archived` → `inProgress`: solo por operación aprobada.\n",
    "- `archived` → `inProgress`: solo por operación aprobada.\n\n" + NOTE + H +
    "| — | `open` | Apertura del expediente | — | EVT-WFL-044 `.opened` |\n"
    "| `open` | `inProgress` | Primer pase | — | — |\n"
    "| `inProgress` | `closed` | Respuesta final o resolución | — | EVT-WFL-044 `.closed` |\n"
    "| `closed` | `archived` | Pasan PRM-WFL-050 días | — | EVT-WFL-044 `.archived` |\n"
    "| `closed` | `inProgress` | Reapertura | Motivo obligatorio | — |\n"
    "| `archived` | `inProgress` | Reapertura de un archivado | Operación aprobada (§8.1) | — |\n", "cat1-tabla")

# 8.9 operationalInboxItems
rep("### 8.9 Ítem de bandeja operativa\n\n`open` → `inProgress` (lo toma alguien) → `resolved` | `discarded` (con motivo). Si la misma causa reaparece después de `resolved`, se reabre el ítem (`dedupeKey`).\n",
    "### 8.9 Ítem de bandeja operativa (`operationalInboxItems.status`)\n\n`open` → `inProgress` (lo toma alguien) → `resolved` | `discarded` (con motivo). Si la misma causa reaparece después de `resolved`, se reabre el ítem (`dedupeKey`). (Título con la colección agregado el 5-11-2026; antes \"8.9 Ítem de bandeja operativa\".)\n\n" + NOTE + H +
    "| — | `open` | Excepción de un proceso (corrida, operación, render, conector) | `dedupeKey` sin ítem abierto | EVT-WFL-046 `.itemOpened` |\n"
    "| `open` | `inProgress` | Lo toma un responsable | — | — |\n"
    "| `open` / `inProgress` | `resolved` | Causa resuelta | — | EVT-WFL-046 `.itemResolved` |\n"
    "| `open` / `inProgress` | `discarded` | Descarte | Motivo obligatorio | EVT-WFL-046 `.itemResolved` |\n"
    "| `resolved` | `open` | La misma causa reaparece | Mismo `dedupeKey` | EVT-WFL-046 `.itemOpened` |\n", "cat1-tabla")

# 8.10 delegations
rep("### 8.10 Delegación\n\n`scheduled` → `active` (al llegar `from`) → `ended` (al llegar `to`). Además, `scheduled`/`active` → `revoked` (por el delegante o un administrador).\n",
    "### 8.10 Delegación (`delegations.status`)\n\n`scheduled` → `active` (al llegar `from`) → `ended` (al llegar `to`). Además, `scheduled`/`active` → `revoked` (por el delegante o un administrador). (Título con la colección agregado el 5-11-2026; antes \"8.10 Delegación\".)\n\n" + NOTE + H +
    "| — | `scheduled` / `active` | Alta de la delegación | `active` si `from` ya llegó | EVT-WFL-013 `.activated` (si nace activa) |\n"
    "| `scheduled` | `active` | Llega `from` | — | EVT-WFL-013 `.activated` |\n"
    "| `active` | `ended` | Llega `to` | — | EVT-WFL-013 `.ended` |\n"
    "| `scheduled` / `active` | `revoked` | Revocación por el delegante o un administrador | — | EVT-WFL-013 `.revoked` |\n", "cat1-tabla")

# 8.11: subtítulos en negrita -> encabezados
ini = t.index("### 8.11 Máquinas de estado")
fin = t.index("### 8.12 Estado inicial")
sec = t[ini:fin]
lines = sec.split("\n")
k = 0
for i, l in enumerate(lines):
    if l.startswith("**`") and not l.startswith("**`agendaEntries.status`** (proyección): copia"):
        k += 1
        lines[i] = "#### 8.11.%d %s" % (k, l.replace("**", ""))
    elif l.startswith("**`agendaEntries.status`** (proyección): copia"):
        k += 1
        rest = l[len("**`agendaEntries.status`** (proyección): "):]
        lines[i] = "#### 8.11.%d `agendaEntries.status` (proyección)\n\n%s%s" % (k, rest[0].upper(), rest[1:])
sec = "\n".join(lines)
cnt["cat1-encabezados-8.11"] = k
sec = sec.replace('Agregado el 5-11-2026: estas colecciones declaraban estados en el §7 sin tabla de transiciones.',
                  'Agregado el 5-11-2026: estas colecciones declaraban estados en el §7 sin tabla de transiciones. En el cierre de residuales del mismo día los subtítulos en negrita pasaron a encabezados numerados (8.11.1 a 8.11.%d) y se agregaron 8.11.%d y 8.11.%d.' % (k, k + 1, k + 2), 1)
sec = sec.rstrip("\n") + "\n\n" + \
    "#### 8.11.%d `workflowVersions.status`, `templateVersions.status` y `formVersions.status`\n\n" % (k + 1) + \
    "Agregado el 5-11-2026 (PA-WFL-23). `formVersions` no tiene `inReview` (§7.4).\n\n" + H + \
    "| — | `draft` | Nueva versión de la definición, plantilla o formulario | — | — |\n" \
    "| `draft` | `inReview` | Envío a revisión (solo `workflowVersions` y `templateVersions`) | La publicación exige aprobación | EVT-WFL-007 |\n" \
    "| `inReview` | `draft` | Aprobación rechazada | — | — |\n" \
    "| `draft` / `inReview` | `published` | Publicación o aprobación decidida | Validación sin errores; `formVersions` queda inmutable | EVT-WFL-018 `.published` (workflow), EVT-WFL-036 `.published` (plantilla); — (formulario) |\n" \
    "| `published` | `retired` | Se publica otra versión o se retira la definición | Sin instancias, renders ni presentaciones en curso con esa versión | EVT-WFL-018 `.retired` (workflow), EVT-WFL-036 `.retired` (plantilla); — (formulario) |\n\n" + \
    "#### 8.11.%d `documentVersions.scanStatus`\n\n" % (k + 2) + \
    "Agregado el 5-11-2026 (PA-WFL-23). Espejo de `storedFiles.scanStatus` (T01); mueve `documents.status` según §8.6.\n\n" + H + \
    "| — | `pending` | Alta de la versión | — | — |\n" \
    "| `pending` | `clean` | Escaneo sin hallazgos (`pla:escanear-archivo`) | — | EVT-WFL-028 |\n" \
    "| `pending` | `infected` | Escaneo con hallazgos o tipo real no admitido | — | — (el documento pasa a `quarantined`, §8.6) |\n" \
    "| `pending` | `failed` | Error del escáner | Reintentos agotados | — |\n" \
    "| `failed` | `pending` | Reintento del escaneo | — | — |\n\n" + \
    "`operationTypes` no tiene campo de estado: `cat.contract.forceStatus` (§7.3) es un código de operación, no un estado (aclarado el 5-11-2026).\n\n"
t = t[:ini] + sec + t[fin:]

# 8.12 fuentes
rep("| `workflowVersions.status`, `templateVersions.status`, `formVersions.status` | `draft` | §7.4, §7.8 |",
    "| `workflowVersions.status`, `templateVersions.status`, `formVersions.status` | `draft` | §8.11.%d (antes §7.4, §7.8) |" % (k + 1), "cat1-8.12")
rep("| `documentVersions.scanStatus` | `pending` | Espejo de `storedFiles` (T01) |",
    "| `documentVersions.scanStatus` | `pending` | §8.11.%d; espejo de `storedFiles` (T01) |" % (k + 2), "cat1-8.12")

open(F, "wb").write(b"\xef\xbb\xbf" + t.encode("utf-8"))
print(cnt)
