﻿import glob,os,re
for f in glob.glob('**/*.md',recursive=True):
    if '_trabajo' in f: continue
    for i,l in enumerate(open(f,encoding='utf-8').read().split('\n'),1):
        if re.search(r'int:importar-cdr|fac\.cycle\.closed|\(prov\.\)|<!-- SIGUE', l):
            print(f,i,l[:220])
