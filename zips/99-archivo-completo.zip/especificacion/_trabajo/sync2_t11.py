from sync_lib import Doc

d = Doc('T11-*.md')
S = '5-11-2026, pendientes de la sincronización'

EV = [
    ('EVT-PER-25', 'EVT-PER-26', 'per.person.fiscalLookupRequested', 'per.person.fiscal-lookup-requested', 'M01',
     '`personId`, `identifierId` (alta o cambio de CUIT/CUIL, o verificación manual, JOB-PER-01)',
     'T06 (consulta el padrón de ARCA con `getPersona`; con el resultado M01 publica EVT-PER-08)'),
    ('EVT-MED-29', 'EVT-MED-30', 'med.readingRoute.published', 'med.reading-route.published', 'M03',
     '`readingRouteId`, `readingBatchId`, `meteringSystemId`, `period` (lote exportado a telemedición o colectora de terceros, §8.3 de M03)',
     'T06 (entrega la ruta al sistema remoto o colectora)'),
    ('EVT-FIS-24', 'EVT-FIS-25', 'fis.regimeFile.requested', 'fis.regime-file.requested', 'M06',
     '`filingId`, `legalEntityId`, `regimeCode`, `period`, `storedFileIds[]` (`regimeFilings` en `approved` con entrega por conector, §8.7 de M06; PA-FIS-22)',
     'T06 (entrega el archivo al organismo y registra el acuse)'),
    ('EVT-COB-27', 'EVT-COB-28', 'cob.paymentIntent.requested', 'cob.payment-intent.requested', 'M07',
     '`paymentIntentId`, `gatewayConnectorId`, `currentAccountId`, `amount`, `expiresAt` (intención en `draft` a emitir en el proveedor, §8.4 de M07)',
     'T06 (crea la intención en la pasarela; responde `int.paymentIntent.created`, EVT-INT-08)'),
    (None, 'EVT-COB-29', 'cob.debtPublication.requested', 'cob.debt-publication.requested', 'M07',
     '`agencyDebtExportId`, `agencyId`, `operation`, `period` (exportación de deuda en `generated` con entrega por conector, §8.6 de M07)',
     'T06 (aplica el layout y entrega al ente; responde `int.debtPublication.acknowledged` / `.rejected`, EVT-INT-09)'),
    (None, 'EVT-COB-30', 'cob.directDebit.batchRequested', 'cob.direct-debit.batch-requested', 'M07',
     '`directDebitBatchId`, `agencyId` o `connectorId`, `exportId`, `debitDate` (lote de débito de `draft` a `presented`, §8.8 de M07)',
     'T06 (presenta el lote; responde `int.directDebit.resultReceived`, EVT-INT-11)'),
    ('EVT-TES-23', 'EVT-TES-24', 'tes.bankSync.requested', 'tes.bank-sync.requested', 'M14',
     '`interbankingSyncRunId`, `connectionId`, `treasuryAccountId`, `kind`, `dateSince` (corrida Interbanking en `running`, JOB-TES-04, §8.16.11 de M14)',
     'T06 (consulta saldos y movimientos; responde `int.bank.movementsReceived` / `int.bank.balancesReceived`, EVT-INT-12)'),
    (None, 'EVT-TES-25', 'tes.paymentFile.requested', 'tes.payment-file.requested', 'M14',
     '`paymentFileId`, `purpose`, `format`, `originTreasuryAccountId`, `executionDate` (`paymentFiles` en `generated`, JOB-TES-05, §8.10 de M14)',
     'T06 (aplica el layout de Interbanking o del banco y lo entrega, FI-INT-59)'),
    ('EVT-SUE-27', 'EVT-SUE-28', 'sue.payrollFiles.requested', 'sue.payroll-files.requested', 'M16',
     '`statutoryFilingId`, `legalEntityId`, `kind`, `periodKey`, `payrollRunIds` (LSD, SICOSS/F.931 u otro `kind` de `statutoryFilings`; JOB-SUE-10, API-SUE-63)',
     'T06 (aplica el diseño oficial vigente y deja el archivo descargable, FI-INT-16; la presentación en ARCA sigue manual, RN-SUE-080)'),
    ('EVT-COM-39', 'EVT-COM-40', 'com.message.dispatchRequested', 'com.message.dispatch-requested', 'T09',
     '`communicationId`, `communicationAttemptId`, `channel`, `providerConnectorId`, `idempotencyKey` (comunicación `queued` lista para un canal con conector, §8.10 de T09)',
     'T06 (envía por el conector del canal; devuelve `int.message.*`)'),
]

prev = None
for after, eid, name, alias, prod, payload, cons in EV:
    row = '| %s | `%s` (antes `%s`, nombre con guion que T06 consumía sin productor; %s, PA-WFL-24) | %s | %s |' % (
        eid, name, alias, S, payload, cons)
    d.after_line('| %s |' % (after or prev), [row], 'evento')
    prev = eid

al = []
for _, eid, name, alias, prod, _, _ in EV:
    al.append('| `%s` | %s (productor), T06 | `%s` (%s) | Alias (%s, PA-WFL-24, Asumida DEC-072): nombre con guion que T06 §12 consumía; %s §12.1 declara el canónico en camelCase (convención `<mod>.<agregado>.<hecho>`, INC-06-11). El productor y T06 ya usan el nombre nuevo |'
              % (alias, prod, name, eid, S, prod))
d.after_line('| `stk.item.below-minimum` |', al, 'alias')

def pre(old, new):
    assert old.startswith(new[0]), old[:40]
    return new[1] + old[len(new[0]):]


d.cell('| IDs de eventos de M01', 1, lambda c: pre(c, ('437 (antes 436;', '446 (%s: suma EVT-PER-26, EVT-MED-30, EVT-FIS-25, EVT-COB-28 a 30, EVT-TES-24 y 25 y EVT-SUE-28; antes 437. Antes 436;' % S)), 'totales')
d.cell('| IDs de eventos de T01, T02', 1, lambda c: pre(c, ('173 (antes 172;', '174 (%s: COM pasa a 40 con EVT-COM-40; antes 173. Antes 172;' % S)), 'totales')
d.rep('| **Total de IDs EVT** | **658** (antes 656; antes 653) |',
      '| **Total de IDs EVT** | **668** (antes 658; antes 656; antes 653) |', 'totales')
d.cell('| Filas de conciliación en §12.4 |', 1, lambda c: pre(c, ('204, una por canónico (', '214, una por canónico (%s: suma los 10 alias con guion de EVT-PER-26, EVT-MED-30, EVT-FIS-25, EVT-COB-28 a 30, EVT-TES-24 y 25, EVT-SUE-28 y EVT-COM-40, PA-WFL-24; antes 204. ' % S)), 'totales')

# Línea en PA-WFL-24: se agrega como último ítem del bloque
t = d.t.split('\n')
s = [i for i, l in enumerate(t) if l.startswith('### PA-WFL-24')]
assert len(s) == 1
j = s[0] + 1
while j < len(t) and not (t[j].startswith('### ') or t[j].startswith('## ')):
    j += 1
while t[j - 1].strip() == '':
    j -= 1
t[j:j] = ['  - %s: §12.3 suma 10 eventos que T06 consumía con guion y sin productor (EVT-PER-26, EVT-MED-30, EVT-FIS-25, EVT-COB-28 a 30, EVT-TES-24 y 25, EVT-SUE-28 y EVT-COM-40), con nombre, payload y consumidor tomados del §12.1 de M01, M03, M06, M07, M14, M16 y T09; §12.4 registra los 10 alias con guion (una fila por canónico); §12.10 pasa a 446, 174 y 668 IDs EVT y a 214 filas de conciliación.' % S]
d.t = '\n'.join(t)
d._k('PA')
d.save()
