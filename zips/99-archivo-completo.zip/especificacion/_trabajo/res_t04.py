from res_lib import Doc

d = Doc(r'anexos\T04-CFG-configuracion-parametros-maestros.md')

# --- PAN-CFG-31: ruta del flujo anfitrión ---
d.rep('| PAN-CFG-31 | pwa-socio y landing, componente sin ruta propia: se abre al tocar el campo "Dirección" de los flujos de M19 y M01 que piden domicilio (solicitud de servicio, alta de titular, cambio de domicilio);',
      '| PAN-CFG-31 | pwa-socio y landing, componente sin ruta propia que se monta en las rutas de los flujos anfitriones: `/app/tramites/nuevo/:formCode` (PAN-POR-32) y `/app/contratar` (PAN-POR-31) de M19, y el alta o cambio de domicilio de M01; se abre al tocar el campo "Dirección" de los flujos de M19 y M01 que piden domicilio (solicitud de servicio, alta de titular, cambio de domicilio; antes sin ruta citada);')

# --- Servicio interno sin nombre técnico ---
d.rep('| Valor de índice a fecha con regla de ausencia | Mismo cálculo que API-CFG-40 | §7 `economicIndexValues` |',
      '| `economicIndexes.valueAt({ seriesId, at })` | Valor de índice a fecha con regla de ausencia (antes fila sin nombre técnico); mismo cálculo que API-CFG-40 | §7 `economicIndexValues` |')

# --- Cat. 5: celdas de capability y filas reemplazadas ---
api = {
    'API-CFG-05': '`iam.sesion.autenticada` (antes "Usuario autenticado")',
    'API-CFG-06': '`public: true` (antes "Público")',
    'API-CFG-28': '`iam.sesion.autenticada` (antes "Usuario autenticado")',
    'API-CFG-29': '`iam.sesion.autenticada`; `public: true` acotado para la landing (antes "Usuario autenticado / público acotado")',
    'API-CFG-30': '`iam.sesion.autenticada`; `public: true` acotado para la landing (antes "Usuario autenticado / público acotado")',
    'API-CFG-33': '`iam.sesion.autenticada` (antes "Usuario autenticado")',
    'API-CFG-34': '`iam.sesion.autenticada` con cuota (antes "Usuario autenticado (cuota)")',
    'API-CFG-38': '`iam.sesion.autenticada` (los módulos del backend usan el servicio interno de días hábiles, ver abajo; antes "Usuario autenticado")',
    'API-CFG-40': '`iam.sesion.autenticada` (los módulos del backend usan `economicIndexes.valueAt`, ver abajo; antes "Usuario autenticado")',
    'API-CFG-45': '`iam.sesion.autenticada` (antes "Usuario autenticado")',
    'API-CFG-53': '`bia.apis.consumir` (cliente API de tercero con scope de T10; antes "Token de tercero con scope")',
}
for a, c in api.items():
    d.cell('| %s |' % a, 3, c)
d.rep('Reemplazado por la API de `numberingSequences` de T11 (CTR-DAT-16).',
      'Reemplazado por API-WFL-71 (y API-WFL-72, API-WFL-73), la API de `numberingSequences` de T11 (CTR-DAT-16; antes "Reemplazado por la API de `numberingSequences` de T11").')
d.rep('Motivo: lo consumen solo los módulos del backend, no es un endpoint HTTP de usuario.',
      'Motivo: lo consumen solo los módulos del backend, no es un endpoint HTTP de usuario. No hay API destino: el reemplazo es el servicio interno de la tabla de servicios de esta sección (PA-CFG-15).')

# --- Cat. 1: estados iniciales ---
d.before_line('## 9. Procesos y flujos', '''### 8.11 Estados iniciales de las máquinas de §8.2, §8.4, §8.6, §8.7 y §8.8

Corrección del cierre de residuales (05-11-2026; PA-CFG-15): explicita el estado de alta de las máquinas descritas en texto. Las transiciones siguen en cada subsección.

| Colección | Desde | Hacia | Disparador | Guarda (RN) | Evento |
|---|---|---|---|---|---|
| `parameterDefinitions` | — | `active` | Despliegue del manifiesto del módulo que declara la clave | — | — |
| `streets` | — | `pendingValidation` | Alta local de la calle por el tenant | — | — |
| `streets` | — | `active` | Carga desde Georef o migración validada | — | — |
| `masterImportJobs` | — | `uploaded` | Carga del archivo de importación | Formato admitido | — |
| `platformTableReleases` | — | `draft` | Plataforma prepara un release de tabla oficial | — | — |
| `customFieldDefinitions` | — | `draft` | Alta del campo extra en una `configVersion` | — | — |
| `seedApplications` | — | `applied` | Aplicación de la semilla al tenant | — | — |
'''.split('\n'))

# --- PA-CFG-15 ---
d.before_line('## 22. Trazabilidad de fuentes', '''### PA-CFG-15 — Cierre de residuales del anexo (pantalla sin ruta, servicios, API, estados y tablas de campos)

- **Pregunta:** ¿cómo se cierran los residuales del anexo detectados por los entregables de análisis?
- **Contexto:** PAN-CFG-31 no citaba ninguna ruta; una fila de servicios internos no tenía nombre técnico; 11 filas de §11 citaban "Usuario autenticado", "Público" o "Token de tercero"; API-CFG-54 no citaba la API destino por ID y API-CFG-58 no tiene API destino; 6 máquinas no declaraban el estado de alta; 38 colecciones del §7 no tenían tabla de campos.
- **Opciones:**
  - A) Citar en PAN-CFG-31 las rutas de los flujos anfitriones de M19; nombrar el servicio `economicIndexes.valueAt({ seriesId, at })`; usar `iam.sesion.autenticada`, `public: true` y `bia.apis.consumir` (T02 PA-IAM-18); citar API-WFL-71 a 73 en API-CFG-54 y declarar que API-CFG-58 se reemplaza por un servicio interno sin API; agregar §8.11 y las tablas de campos de §7.18 (derivadas del texto y de T05, obligatoriedad por regla). **(Recomendada)**.
  - B) Dar a PAN-CFG-31 una ruta propia de modal.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** catálogo de pantallas, contratos OpenAPI y diagramas de estados de T04.
- **Estado:** Asumida (DEC-072): opción A.
'''.split('\n'))
print('T04 cambios', d.save())
