from res_lib import Doc

d = Doc(r'anexos\T07-MIG-*.md')

PROY = ['draft', 'inventoried', 'mapping', 'rehearsing', 'parallel', 'bypassing', 'cutover', 'live', 'closed', 'cancelled']
RUN = ['queued', 'extracting', 'reading', 'transforming', 'validating', 'awaitingApproval', 'loading', 'loaded',
       'reconciling', 'accepted', 'rejected', 'cancelled', 'failed', 'purged']

# --- Cat. 1: valores en §7 ---
d.rep('| `status` | enum (§8.1) | Sí | |',
      '| `status` | enum (§8.1) | Sí | %s; inicial `draft` (§8.8). |' % '\\|'.join('`%s`' % s for s in PROY))
d.rep('| `status` | enum (§8.2) | Sí | |',
      '| `status` | enum (§8.2) | Sí | %s; inicial `queued` (§8.8). |' % '\\|'.join('`%s`' % s for s in RUN))

# --- Cat. 4: nombres canónicos de T05 en la tabla de §7.3 ---
d.rep('| `setId` | ObjectId | Sí | |', '| `mappingSetId` | ObjectId | Sí | → `migrationMappingSets` (antes `setId`; nombre canónico de T05). |')
d.rep('| `ruleId` | string | Sí | Ej. `MAP-PER-SOCIOS-001`. |',
      '| `ruleCode` | string | Sí | Ej. `MAP-PER-SOCIOS-001`; clave natural, no referencia (antes `ruleId`). |')

# --- Cat. 2: destinos ---
d.rep('| `baseSnapshotId` | ObjectId | No | Para deltas. |', '| `baseSnapshotId` | ObjectId | No | Para deltas; → `legacySnapshots`. |')
d.rep('`baseSetId` (para overrides)', '`baseSetId` (para overrides; → `migrationMappingSets`)')
d.rep('`goodappsBatchId` (lote simulado M05)', '`goodappsBatchId` (lote simulado; → `billingRuns` de M05)')
d.rep('`freezeAt`, `finalSnapshotId`, `goDecision', '`freezeAt`, `finalSnapshotId` (→ `legacySnapshots`), `goDecision')
d.rep('`migrationMappingRules.ruleId` → código de regla (clave natural, no referencia)',
      '`migrationMappingRules.ruleCode` (antes `ruleId`) → código de regla (clave natural, no referencia)')
d.rep('`parallelRuns.goodappsBatchId` → lote simulado de facturación de M05',
      '`parallelRuns.goodappsBatchId` → `billingRuns` (M05; lote simulado; antes "lote simulado de facturación de M05")')

# --- Cat. 5: capabilities ---
d.cell('| API-MIG-34 |', 3, '`mig.clavesHeredadas.resolver` (identidad de servicio de M07 y redes de cobro; sin acceso de usuario; antes "Identidad de servicio (M07, redes de cobro)…")')
d.cell('| API-MIG-36 |', 3, '`mig.miHistorial.ver` (sesión del socio; solo sus cuentas por relación autorizada de M01; antes "Sesión del socio…")')

# --- Cat. 1: tabla normalizada de §8.1 a §8.6 ---
T = []
def r(c, a, b, disp, g='—', e='—'):
    T.append('| `%s` | %s | %s | %s | %s | %s |' % (c, a if a == '—' else ', '.join('`%s`' % x for x in a.split(',')), '`%s`' % b, disp, g, e))

P = 'migrationProjects.status'
r(P, '—', 'draft', 'Alta del proyecto por `mig.proyectos.crear`')
for a, b, t in [('draft', 'inventoried', 'Inventario con snapshot `full` listo'), ('inventoried', 'draft', 'Volver a borrador'),
                ('inventoried', 'mapping', 'Perfilado ejecutado'), ('mapping', 'rehearsing', 'Conjunto de mapeo publicado'),
                ('rehearsing', 'parallel', 'Ensayo integral con conciliaciones aprobadas'), ('parallel', 'rehearsing', 'Volver a ensayo'),
                ('parallel', 'bypassing', 'Paralelo aprobado del primer dominio'), ('bypassing', 'cutover', 'Doble aprobación del corte'),
                ('cutover', 'live', 'Acta de aceptación firmada'), ('live', 'closed', 'ProCoop apagado y archivo verificado')]:
    r(P, a, b, t)
r(P, 'draft,inventoried,mapping,rehearsing,parallel,bypassing,cutover,live', 'cancelled', 'Cancelación con motivo (líder + responsable)')

R = 'migrationRuns.status'
r(R, '—', 'queued', 'Alta de la corrida')
for a, b, t in [('queued', 'extracting', 'Inicio con extracción'), ('queued', 'reading', 'Inicio leyendo un snapshot existente'),
                ('extracting', 'transforming', 'Fin de extracción'), ('reading', 'transforming', 'Fin de lectura'),
                ('transforming', 'validating', 'Fin de transformación'), ('validating', 'awaitingApproval', 'Hay rechazos o exclusiones'),
                ('validating', 'loading', 'Sin rechazos'), ('awaitingApproval', 'loading', 'Aprobación'),
                ('loading', 'loaded', 'Todos los lotes `committed`'), ('loaded', 'reconciling', 'Inicio de conciliación'),
                ('reconciling', 'accepted', 'Conciliaciones aprobadas'), ('reconciling', 'rejected', 'Conciliación rechazada'),
                ('failed', 'loading', '`resume` desde el último lote')]:
    r(R, a, b, t)
r(R, 'queued,extracting,reading,transforming,validating,awaitingApproval,loading', 'cancelled', 'Cancelación')
r(R, 'extracting,reading,transforming,validating,loading', 'failed', 'Error no recuperable')
r(R, 'accepted,rejected,cancelled', 'purged', 'Purga de una corrida `dryRun` (RF-MIG-046)', 'Solo `dryRun`; `accepted` real es inmutable')

S = 'migStagingRecords.status'
r(S, '—', 'extracted', 'Extracción del registro')
for a, b, t in [('extracted', 'transformed', 'Transformación'), ('transformed', 'valid', 'Validación sin observaciones'),
                ('transformed', 'warning', 'Validación con advertencias'), ('transformed', 'rejected', 'Validación con error'),
                ('rejected', 'transformed', 'Corrección y reproceso'), ('valid,warning', 'loaded', 'Carga'),
                ('valid,warning,rejected', 'excluded', 'Exclusión'), ('valid,warning', 'conflict', 'El destino cambió en GoodApps (RN-MIG-042)'),
                ('conflict', 'loaded', 'Decisión explícita ("conservar GoodApps" o "aplicar origen")')]:
    r(S, a, b, t)

C = 'migrationReconciliations.status'
r(C, '—', 'draft', 'Cálculo de la conciliación de la corrida')
r(C, 'draft', 'submitted', 'Envío a aprobación')
r(C, 'submitted', 'approved', 'Aprobación', 'Aprobador distinto del ejecutor (RN-MIG-041)')
r(C, 'submitted', 'rejected', 'Rechazo')
r(C, 'rejected', 'draft', 'Nueva corrida')

Q = 'parallelComparisons.classification'
r(Q, '—', 'pending', 'Comparación ítem a ítem')
for b in ['equal', 'rounding', 'configuration', 'migratedData', 'intendedFix', 'goodappsDefect', 'procoopKnownDefect']:
    r(Q, 'pending', b, 'Clasificación del ítem', 'Explicación si no es `equal` ni `rounding`' if b not in ('equal', 'rounding') else '—')

M = 'migrationMappingSets.status'
r(M, '—', 'draft', 'Alta o copia del conjunto')
r(M, 'draft', 'published', 'Publicación (queda inmutable)')
r(M, 'published', 'retired', 'Reemplazo por otra versión')

bloque = ['### 8.8 Tabla normalizada de las máquinas de §8.1 a §8.4 y §8.6', '',
          'Corrección del cierre de residuales (05-11-2026; PA-MIG-21): una fila por transición, con el estado de alta explícito (`—`). Prevalece el texto de cada subsección si hay diferencia. El rol de convivencia de §8.5 es un campo del plan (`strategy.domains[].coexistenceRole`) y no se repite. Se agrega `migrationMappingSets`, que tenía estados sin transiciones.', '',
          '| Colección | Desde | Hacia | Disparador | Guarda (RN) | Evento |', '|---|---|---|---|---|---|'] + T + ['']
d.before_line('Referencias de §7 sin destino explícito: `migrationProjects.acceptanceActId`', bloque)

pa = '''### PA-MIG-21 — Cierre de residuales del anexo (estados, referencias, tablas de campos y API)

- **Pregunta:** ¿cómo se cierran los residuales del anexo detectados por los entregables de análisis?
- **Contexto:** las máquinas de §8.1 a §8.6 estaban en texto sin estado de alta explícito; `migrationProjects` y `migrationRuns` no listaban valores en §7; 5 referencias no tenían destino en la definición del campo; 11 colecciones no tenían tabla de campos; API-MIG-34 y 36 citaban reglas de acceso en lugar de capabilities; `setId` y `ruleId` no usaban el nombre canónico de T05.
- **Opciones:**
  - A) Agregar §8.8 con una fila por transición y estado inicial; listar valores en §7; declarar destinos (`goodappsBatchId` → `billingRuns` de M05, `acceptanceActId` → `documents`, snapshots → `legacySnapshots`, `baseSetId` → `migrationMappingSets`); renombrar a `mappingSetId` y `ruleCode` (con "antes"); agregar §7.14 con tablas derivadas del texto y de T05 (obligatoriedad por regla: clave única, `status`, `code`, `name` y referencias de T05 = Sí); usar `mig.clavesHeredadas.resolver` y `mig.miHistorial.ver` (registradas en T02 §4.4.2). **(Recomendada)**.
  - B) Dejar las máquinas solo en texto.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** diagramas de estados, contratos y ER de T07.
- **Estado:** Asumida (DEC-072): opción A.
'''
d.before_line('## 22. Trazabilidad de fuentes', pa.split('\n'))
print('T07 cambios', d.save(), 'filas §8.8', len(T))
