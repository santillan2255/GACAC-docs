import sys, io, glob, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
f = glob.glob(os.path.join(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos", "T05-*"))[0]
L = open(f, encoding="utf-8").read().split("\n")
names = sys.argv[1:]
for i, l in enumerate(L, 1):
    if l.startswith("| COL-"):
        c = l.split("|")
        if c[2].strip().strip("`") in names:
            print(i, l.rstrip("\r"))
