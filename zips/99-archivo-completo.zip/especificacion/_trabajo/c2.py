﻿from conc_lib import *
import re, json
NEW = {
 'M05': ('EVT-FAC-20', [
   ('EVT-FAC-21', '`fac.billingRun.discarded`', 'Lote descartado antes de emitir', '`runId, cycleId, reason, discardedBy`', 'M04 (descarta cálculos `draft`/`observed`/`approved` del lote), T10')]),
 'M06': ('EVT-FIS-21', [
   ('EVT-FIS-22', '`fis.misComprobantes.reconciled`', None, 'período, CUIT del proveedor, comprobantes conciliados y con diferencia', 'M12 (marca facturas de proveedor conciliadas con Mis Comprobantes de ARCA)'),
   ('EVT-FIS-23', '`fis.withholdingComputation.updated`', None, 'orden de pago o ejecución, retenciones calculadas por régimen, base, importe', 'M14 (actualiza `fiscalComputation` de la ejecución de pago)')]),
 'M07': ('EVT-COB-23', [
   ('EVT-COB-24', '`cob.payment.informed`', 'El socio o un canal informa un pago a verificar (comprobante subido, transferencia sin conciliar)', 'operación informada, cuenta, importe, canal, evidencia', 'M08 (suspende acciones de mora mientras se verifica), M19'),
   ('EVT-COB-25', '`cob.cashSession.reopened`', 'Reapertura de una sesión de caja cerrada', 'sesión, motivo, autorizante', 'M14 (anula la rendición no aceptada)'),
   ('EVT-COB-26', '`cob.unidentified.resolved`', 'Un cobro no identificado se asigna a una cuenta', 'cobro no identificado, cuenta, operación de cobro resultante', 'M14 (concilia el crédito con el cobro)'),
   ('EVT-COB-27', '`cob.refund.approved`', 'Reintegro al socio aprobado (deriva de `wfl.operation.approved` con `typeCode = cob.refund.execute`)', 'reintegro, cuenta, importe, medio de pago', 'M14 (crea la ejecución de reintegro), T06 (reintegro por pasarela)')]),
 'M10': ('EVT-TEC-31', [
   ('EVT-TEC-32', '`tec.crewTimesheet.approved`', None, 'timesheetId, crewId, workOrderIds, integrantes, fechas, horas normales, extra y guardias', 'M16 (novedades propuestas, JOB-SUE-07)'),
   ('EVT-TEC-33', '`tec.provisioning.requested`', None, 'commandId, contractId, action, systemId, profile', 'T06 (ejecuta el comando en el sistema de red); la respuesta vuelve como EVT-INT-15 y M10 publica EVT-TEC-21'),
   ('EVT-TEC-34', '`tec.work.completed`', None, 'workId, completedAt, costTotal, destino (bien de uso o gasto)', 'M15 (obra en curso a bien de uso o gasto, M-79), M13 (alta de bien de uso si corresponde)')]),
 'M11': ('EVT-VEN-14', [
   ('EVT-VEN-15', '`ven.salesOrder.invoiced`', 'M11', 'M13 (entrega pendiente), T10', '`salesOrderId, invoiceId`')]),
 'M12': ('EVT-CMP-14', [
   ('EVT-CMP-15', '`cmp.paymentOrder.prepared`', 'M12', 'M06 (cálculo previo de retenciones)', '`paymentOrderId, supplierId, items, amount`')]),
 'M13': ('EVT-STK-22', [
   ('EVT-STK-23', '`stk.reservation.failed`', 'No se pudo reservar stock para una OT o una venta (payload: `reservationRequestId`, `sourceRef`, `itemId`, `missingQty`)', 'M10 (bloquea la etapa), M11 (avisa en la orden de venta)'),
   ('EVT-STK-24', '`stk.goods.rejected`', 'Ingreso de mercadería rechazado en depósito (payload: `receiptId`, `items`, `reason`)', 'M12 (`stockStatus = rejected` y alerta)')]),
 'M14': ('EVT-TES-22', [
   ('EVT-TES-23', '`tes.advance.paid`', 'Adelanto de sueldo pagado (payload: `advanceId`, `employeeId`, `amount`, `paidAt`)', 'M16 (plan de descuento del adelanto, RN-SUE-049)')]),
 'M16': ('EVT-SUE-26', [
   ('EVT-SUE-27', '`sue.paymentRequest.cancelled`', 'Anulación de un pedido de pago de sueldos aún no ejecutado (payload: `paymentRequestId`, `reason`)', 'M14 (anula el lote)')]),
 'T01': ('EVT-PLA-20', [
   ('EVT-PLA-21', '`pla.branch.created` / `.updated`', None, 'branchId, code, name, status', '`uxd` (slots de marca por sucursal), `cfg`'),
   ('EVT-PLA-22', '`pla.tenantProfile.updated`', None, 'tenantId, changedFields (razón social, CUIT, domicilio legal, logo)', '`uxd` (pie y documentos), `wfl` (plantillas), `fis`')]),
}
t11rows = {}
for code, (last, rows) in NEW.items():
    f = [x for x in files() if os.path.basename(x).startswith(code+'-')][0]
    L = read(f).split('\n')
    for r in rows:
        assert not any(re.match(r'^\|\s*%s\s*\|' % r[0], l) for l in L), (code, r[0])
    i = [k for k,l in enumerate(L) if re.match(r'^\|\s*%s\s*\|' % last, l)][0]
    out = []
    for r in rows:
        if code in ('M05', 'M07'):
            out.append('| %s | %s | %s | %s | %s |' % r)
        elif code in ('M06', 'M10', 'T01'):
            out.append('| %s | %s | %s | %s |' % (r[0], r[1], r[3], r[4]))
        elif code in ('M11', 'M12'):
            out.append('| %s | %s | %s | %s | %s |' % r)
        else:
            out.append('| %s | %s | %s | %s |' % r)
    L[i+1:i+1] = out
    write(f, '\n'.join(L))
    print(code, [r[0] for r in rows])
