import sys
sys.stdout.reconfigure(encoding='utf-8')
f, a, b = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
w = int(sys.argv[4]) if len(sys.argv) > 4 else 100000
L = open(f, encoding='utf-8').read().replace('\r', '').split('\n')
for i in range(a - 1, min(b, len(L))):
    print(i + 1, L[i][:w])
