import sys, io, os, re, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
BASE = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion"
BK = os.path.join(BASE, "backup-sincronizacion-202611051645")
MOJ = re.compile("Ã[\u0080-\u00bf]|Â[\u00a0-\u00bf]|â€|├|┬|\ufffd")
IDRE = re.compile(r"^\|\s*((?:RF|RN|PA|CU|API|EVT|JOB|PAN|COL|PRM|CTR)-[A-Z0-9]+-\d+)\s*\|")


def cells(l):
    return len(re.findall(r"(?<!\\)\|", re.sub(r"`[^`]*`", "", l)))


def table_issues(t):
    out = []
    ls = t.split("\n")
    i = 0
    while i < len(ls):
        if ls[i].startswith("|") and i + 1 < len(ls) and re.match(r"^\|[\s:|-]+\|\s*$", ls[i + 1]):
            n = cells(ls[i]); j = i + 2
            while j < len(ls) and ls[j].startswith("|"):
                if cells(ls[j]) != n:
                    out.append(ls[j][:120])
                j += 1
            i = j
        else:
            i += 1
    return out


def ids(t):
    c = collections.Counter()
    for l in t.split("\n"):
        m = IDRE.match(l)
        if m:
            c[m.group(1)] += 1
    for m in re.finditer(r"^#+ (PA-[A-Z]+-\d+)", t, re.M):
        c["H:" + m.group(1)] += 1
    return c


for f in sorted(glob.glob(os.path.join(BK, "*.md"))):
    n = os.path.basename(f)
    a = open(f, "rb").read(); b = open(os.path.join(BASE, "anexos", n), "rb").read()
    if a == b:
        continue
    ta = a.decode("utf-8-sig"); tb = b.decode("utf-8-sig")
    probs = []
    if a.startswith(b"\xef\xbb\xbf") != b.startswith(b"\xef\xbb\xbf"):
        probs.append("BOM cambió")
    ca, cb = a.count(b"\r\n"), b.count(b"\r\n")
    la, lb = a.count(b"\n"), b.count(b"\n")
    if (ca == la) != (cb == lb) or (cb not in (0, lb)):
        probs.append("EOL cambió %d/%d -> %d/%d" % (ca, la, cb, lb))
    ma, mb = len(MOJ.findall(ta)), len(MOJ.findall(tb))
    if mb > ma:
        probs.append("mojibake %d -> %d" % (ma, mb))
    ia = set(table_issues(ta.replace("\r\n", "\n"))); ib = table_issues(tb.replace("\r\n", "\n"))
    new = [x for x in ib if x not in ia]
    if new:
        probs.append("tablas: " + " || ".join(new[:5]))
    da, db = ids(ta), ids(tb)
    dup = [k for k, v in db.items() if v > 1 and v > da.get(k, 0)]
    if dup:
        probs.append("IDs duplicados nuevos: %s" % dup[:10])
    lost = [k for k in da if k not in db]
    if lost:
        probs.append("IDs perdidos: %s" % lost[:10])
    print(n, "líneas %d -> %d" % (la, lb), "OK" if not probs else probs)
