# Pendientes cruzados para el cierre de la corrección de inconsistencias

## Del plan de olas y la maestra
- M19 §10: alinear la tabbar del socio a T03 §10.1.4 / RF-UXD-066 (Inicio, Cuentas y servicios, "+" central con Pagar por defecto, Gestiones, Comunidad; Perfil desde el avatar).
- M10 RF-TEC-062: barra vertical sin escapar dentro de código en una celda.
- T03 RF-UXD-026: barra vertical sin escapar; RF-UXD-163: celda de ola `O6 (DEC-056)`.
- Después de que termine el grupo M14–M19: volver a correr `_trabajo/plan_recuento.py` (olas de M15).

## De M07–M13
- T02: agregar capabilities nuevas: `tec.ext.ordenes.crear`, `tec.telefonia.llamadas.ver`; `crm.turnero.pantalla.ver`, `crm.webhooks.recibir`, `crm.ivr.consultar`, `crm.config.canales.configurar`, `crm.config.tramites.configurar`; `mor.plataforma.restricciones.configurar`, `mor.ext.expedientes.ver`, `mor.ext.expedientes.registrar`, `mor.ext.condicionMora.ver`, `mor.bloqueos.ver`, `mor.excepciones.editar`, `mor.protecciones.ver`, `mor.protecciones.editar`, `mor.restricciones.configurar`, `mor.incobrables.ver`, `mor.informes.ver`, `mor.informes.exportar`; `cmp.concursos.ver`, `cmp.concursos.editar`, `cmp.reportes.exportar`; `stk.lotes.editar`, `stk.rendiciones.editar`, `stk.inventarios.cerrar`, `stk.revaluaciones.ver`, `stk.revaluaciones.aprobar`, `stk.fabricacion.estructuras.editar`, `stk.fabricacion.ordenes.editar`.
- T11: consumidor M10 → T09 en EVT-COB-02, 04, 16, 17, 18, 20; agregar M07 en EVT-INT-04; M08 en EVT-COM-29, EVT-CRM-05, EVT-TEC-14; sincronizar payloads EVT-COB-01..27 y EVT-MOR-01, 04..08, 10, 11, 14, 17 con M07/M08.
- T03: PAN-MOR-19, 23, 33, 34, 35 alinear al anexo (AL-01).
- M19: `crm.openCase(type=solicitudAlta)` → `caseTypeCode=serviceActivation`.
- M17: renumerar su CU-INS-01 (ingreso como asociado).
- PA propuestas (asumir recomendada):
  5. Dueño de CU-CIC-01 (suspensión/reactivación): M08 (recomendada) / M02 / M09.
  6. Dueño de CU-SOL-01 (alta Internet y baja TV): M09 (recomendada) / M02.
  7. Vocabulario de capabilities de M10: español según T02 (`tec.ot.ver/editar/cerrar`, `tec.servicioTecnico.ver/editar`) (recomendada) / mantener inglés. (Coincide con la PA 4 de T02.)
  8. Estados de `collectorSettlements`, `gatewayTransactions`, `thirdPartyCollections`, `externalObligationImports`, `crmCalendarEvents`, `technicalProcedures`, `fixedAssetValueChanges`, `mrpRuns` y transiciones de `agreementInstallments`: definir máquina por colección (recomendada) / declarar sin máquina.

## De T01, T03, T04, T06–T08, T10
- Conflicto T08/T05 de proyección resuelto por el coordinador: T08 §7.1 vuelve a 3 M / 9 M con mezcla 96/4 y 288/12 (igual que T05); demás filas de volumen recalculadas.
- T02: `iam.directorio.ver`; capabilities de UXD; `uxd.plataforma.*` (T02) vs `plt.uxd.*` (T03); capabilities MIG `mig.proyectos.configurar`, `mig.paralelo.aprobar`, `mig.bypass.aprobar`, `mig.corte.aprobar`, `mig.actaAceptacion.firmar`; renombres camelCase INT/BIA (`int.operaciones.resolverManual`, `int.bitacora.verPayload`, `bia.datosAbiertos.publicar`, `bia.datosSensibles.ver`, `bia.reportes.programarExternos`).
- T11: consumidores T03 en EVT-IAM-04, 05, EVT-PLA-08; T07 en EVT-COB-04, EVT-FAC-02; T10 en EVT-CFG-05, EVT-COB-12, EVT-IAM-03, 04, 05, EVT-PLA-08.
- T05: `seriesCode` (T04) vs `seriesId` (T05).
- M19: API-POR-01 `?app=` y campos de T01/T03; POR-71 `sue.recibos.ver` vs M16 `sue.portal.recibos.ver`; POR-61 "Sesión" → `iam.miCuenta.gestionar`; citar CU-MAR-01 (dueño T03).
- T02: citar CU-GOB-01 (dueño T11) y CU-API-01 (dueño T10). M01: citar CU-GEO-01 (dueño T04).
- M10: PAN-TEC-49 reemplazada por PAN-CRM-04 en la app.
- Entregables: ítems de navegación 549 → 558.
- PA propuestas (asumir recomendada):
  12. Factor de simultaneidad del pico de plataforma (T08 §7.1): 0,6 con prueba de carga antes de O4 (recomendada) / 1,0.
  13. Copias anuales de 10 años (RNF-NFR-038): datos en línea + archivo en frío según DEC-087 (recomendada) / además copia anual inmutable.
  14. Estados de `aiUsageLogs` (T06): `ok`, `error`, `blocked` (recomendada) / solo código de resultado.
  15. Acta de aceptación de la migración: `documents` de T11 con tipo "acta" (recomendada) / colección propia.

## De T11 y T05
- Segunda pasada T11 hecha (M10→T09 en EVT-COB, payloads COB/MOR sincronizados, `workflowInstanceId`).
- Nombres no canónicos según T05 §7.2 a corregir en M07/M08 y luego en T11: `sessionId` → `cashSessionId` (EVT-COB-12, 14, 25); `transactionId` → `gatewayTransactionId` (EVT-COB-18); `batchId` → `delinquencyBatchId` (EVT-MOR-07).
- T02: capabilities `wfl.instancias.iniciar`, `wfl.instancias.administrar`, `wfl.firmas.solicitar`.
- T01: confirmar payload definido para EVT-PLA-04.
- M06/M07/M08: adoptar nombres de payload FIS/COB/MOR (segunda pasada de T11 sincroniza COB/MOR).
- T08: `documentTypes.retentionClass` vs `retentionPolicyCode`.
- EVT-IAM-10 consumidor [VERIFICAR] (T02 no lista módulos con autorización diferida); EVT-CFG-16 consumidor [VERIFICAR] (T04 no lista entidades con campos extendidos).
- PA propuestas (asumir recomendada):
  9. `membershipId` de M17 → renombrar a `associateMembershipId` (recomendada) / mantener.
  10. `costCenterModelId` (M15) sin colección: M15 la declara como colección (recomendada) / código.
  11. `responsibleAreaId` (T11) → `crmAreas` (recomendada) / `workAreas`.

## De T02 y T09
- 187 nombres de capability no canónicos (T02 §4.4.3, con canónica propuesta): los anexos dueños deben renombrar (comodines, acciones en inglés de M10, prefijos `ext`/`plt`/`platform`/`pwa`/`public`, sinónimos, scopes T10 `recurso:acción`, sin recurso).
- T11: agregar T09 como consumidor de EVT-COB-01, EVT-FAC-15, EVT-FIS-01, EVT-INS-18, EVT-INT-04, EVT-INT-23, EVT-MOR-08, EVT-PER-03, EVT-PER-06, EVT-PER-18; M08 consumidor de EVT-COM-29.
- CU duplicados: M09 renumerar su CU-26; M17 renumerar su CU-INS-01 (dueños: T09 CU-26, M10 CU-INS-01).
- T03: alinear a la tabla de correspondencia PAN-COM de T09 §10.3.
- PA propuestas para `02` (asumir recomendada, DEC-072):
  1. Estados de `platformNotices`: `draft`, `published`, `expired`, `withdrawn` (recomendada) vs estados de T01.
  2. `communicationTypeId` en plantillas de campaña/libres: obligatorio con tipo genérico "campaña" (recomendada) vs opcional.
  3. Errores de T05: unicidad de `version` en `communityGuidelines`/`messageTemplateVersions`; único `{surveyId, personId}` en `surveyInvitations`; `outageNotices.serviceId` singular; clave única de `messagingUsage` gruesa → corregir en T05 (recomendada).
  4. Capabilities de M10 con acción en inglés: renombrar al español con alias (recomendada) vs excepción.

## De M01-M06 y T12
- Informe: `_trabajo/informe-correccion-grupo-M01-M06-T12.md`.
- T02: agregar `per.documentacion.registrar` y `per.documentacion.validar`.
- T11: agregar M02 como consumidor de EVT-CRM-11 y M03 de EVT-STK-04.
- T05: revisar los 9 casos que el informe marca como posible error de T05 (no corregidos en los anexos).
- CU: M13, M10, T11, M12, M14 y M15 deben citar al anexo dueño de los CU listados en el informe.
- T03: la nota SM-ADM-394 sobre la ruta de PAN-FAC-47 quedó desactualizada.
- No corregibles sin decisión: capability de exportación de API-FIS-80 (PA-FIS-19); comodín `fis.*.ver` de PAN-FIS-40 se mantiene por AL-08 de T03.
- PA propuestas (asumir recomendada, DEC-072): PA-PER-17, PA-CAT-20 (dueños de CU-MER-01, CU-PRO-01, CU-CIC-01, CU-ESP-CEM, CU-ESP-SAN; coordinar con PA 5 "CU-CIC-01 dueño M08"), PA-CAT-21, PA-TAR-20, PA-FAC-21, PA-FIS-19, PA-FIS-20.

## De M14-M19
- T02: agregar `sue.novedades.editar`, `sue.liquidaciones.crear`, `sue.liquidaciones.anular`, `por.conformidades.firmar`, `por.totem.operar`.
- T11: T09 consumidor de EVT-INS-18 (M17); payload EVT-SOC-12 agregar `vehicleId`, `driverId`, `hours`; payload EVT-SOC-17 agregar `replacedByUsageId`.
- T03: PAN-POR-71 `sue.portal.recibos.ver` (prevalece anexo); PAN-POR-61 `iam.miCuenta.gestionar`; PAN-POR-78 ruta `/totem`; corregir correspondencia de PAN-SUE-43, PAN-POR-19, 52, 55, 91.
- T01/T03: API-PLA-64 y API-UXD-01 duplican API-POR-01 (dueño M19, `:tenantSlug`) → marcar como referencia.
- T10: CU-ERP-01 / SIM-ERP-001 total 38.000 vs M15 41.800 → T10 cita a M15.
- T05: COL-INS-01 `memberships` vs `associateMemberships` (CTR-DAT-09, M17); con PA 9 renombrar `membershipId` → `associateMembershipId` en T05 y M17.
- No corregibles: API-TES-87 y API-SUE-86 usan scopes de token externo (OK); PAN-POR-77 depende de capabilities de campo de M10/M03/M07.
- PA propuestas (asumir recomendada, DEC-072):
  16. Barra inferior del portal: versión maestra/T03 (Inicio · Cuentas y servicios · + · Gestiones · Comunidad); crear PAN Comunidad en M19 como agregador de muro, encuestas y novedades, y alinear M19 §10.2.
  17. Pantallas de empleado duplicadas (PAN-SUE-41..46 vs PAN-POR-69..76): dueño M16, M19 las incrusta.
  18. Versiones de formularios del portal en `formVersions` de T11 (no embebidas en `portalForms`).
  19. Confirmar estados propuestos de `cashFlowScenarios`, `payslipNotifications`, `performanceReviews`, `objectives`, `providerAgreements`, `donationCampaigns`, `housingPlans`.
  20. M18 usa `inventoryItemId` (nombre de M13) en lugar de `productId`.
  21. API-SOC-006 se mantiene como endpoint HTTP (citado por M04 y T12).

## Residuales de la pasada de cierre
- T11/T05 hechos (PA-WFL-22, PA-DAT-03). Pendiente para otros anexos:
  - T07: registrar PA 15 (dueño de MIG).
  - T01: adoptar en §12.1 el payload de EVT-PLA-04 definido en T11.
  - T04: `economicIndexValues.seriesCode` → `seriesId`.
  - M17: declarar `associateMemberships` y usar `associateMembershipId`.
  - M15: `costCenterModelId` → `distributionModels` (COL-CON-19); quitar su [VERIFICAR].
  - [VERIFICAR] abiertos: EVT-IAM-10 (lista completa de módulos con autorización diferida); cuentas de `vatRates`/`taxDefinitions` vs `entityAccountAssignments` (M06/M15).
- T02/T09 hechos (35 capabilities nuevas, 91 alias; PA-COM-17, PA-COM-18). Pendiente para otros anexos:
  - M10: la canónica final es `tec.ordenes.*` (`tec.ot.*` queda como alias en T02 §4.4.1). Si M10 aplicó `tec.ot.*`, pasar a `tec.ordenes.*`. `tec.ot.confirmar` y `tec.ot.exportar` sin capability registrada [VERIFICAR]; `tec.factibilidades.*`, `tec.activos.*`, `tec.interrupciones.*` usados en M10 §4 no están en T02 → agregar a T02 o renombrar.
  - T03: `plt.uxd.*` → `uxd.plataforma.*`; SM-ADM-004 exige "sesión" → `com.inbox.ver`.
  - M05: decidir `ext.fac.importar` → `fac.comprobantes.importar` (registrar en T02 si se adopta).
- M01-M09 hechos (PA-COB-19, PA-MOR-21, PA-CRM-19; 51 renombres; 6 máquinas). Pendiente:
  - T02: registrar `fis.reportes.exportar`.
  - T05: referencias asumidas en PA-PER-17, PA-CAT-21, PA-TAR-20, PA-FAC-21, PA-FIS-20; valores de `status` de `collectorSettlements`, `gatewayTransactions`, `thirdPartyCollections`, `externalObligationImports` (M07 §8.17), `agreementInstallments` (M08 §8.14), `crmCalendarEvents` (M09 §8.13).
  - T11: nombres de M06 en EVT-FIS-01, 02, 03, 05; `validTo` en EVT-FIS-11; `withholdingTypeId` en EVT-FIS-12.
  - M10/M13: máquinas de `technicalProcedures`, `fixedAssetValueChanges`, `mrpRuns` citando PA-COB-19.
  - M19: citar a M08 para CU-CIC-01.
  - Matriz 04: CU-CAT-13 (antes CU-MER-01 de M02) y CU-CRM-21 (antes CU-26 de M09).
  - [VERIFICAR] sin PA: `externalClientId`, `bundleSubscriptionId` (M02); estados de `premises` (M01), `meteringSystems` (M03), `provincialValidationCodes` (M06).
- T05/T11 segunda ronda hecha (11 destinos nuevos en §7.2.1, §8.1 de estados, payloads EVT-FIS). [VERIFICAR] por colección no declarada en el dueño, a resolver como PA de cierre (recomendada entre paréntesis):
  - `accountingGroupId`: M15 declara colección de grupos contables (`accountingGroups`).
  - `exceptionId`: M01 declara `uniquenessExceptions` (RN-PER-005) o usa `approvals` de T11 (recomendada: `approvals` de T11).
  - `fiscalClassId`: M06 declara `fiscalClasses`.
  - `activityId`: apunta a `arcaActivities` en `normativeTables` de M06 (no T04).
  - `adjustmentRequestIds`: `invoiceAnnulmentRequests` de M05.
  - `externalClientId` → `persons`; `bundleSubscriptionId` → colección de suscripciones de combos de M02 (confirmar nombre en M02).
- Grupo T hecho (PA-INT-26, PA-MIG-20, PA-NFR-22, PA-NFR-23; 99 renombres). Respaldos en `_trabajo/backup-cierre-T-20261105/` (excluir de scripts de conteo; eliminar al final si el usuario lo aprueba). Pendiente:
  - M19: `?app=` en API-POR-01; PAN Comunidad con ruta `/app/comunidad`; citar CU-MAR-01 (T03).
  - M16/M19: confirmar ruta de PAN-SUE-43 (`/app/empleado/datos`; `legajo` alias).
  - T10: scope `ledger:read` [VERIFICAR] en "Capability mapeada".
  - Plan/maestra: pico HTTP de plataforma 1.000 → 2.088 con factor 0,6 (T08 §7.1); reflejar donde se cite. Correr `plan_recuento.py` (RF-UXD-163 → O6).
- M10-M19 hecho (13 PA: PA-TEC-21, 22, PA-STK-10, PA-TES-18, PA-CON-18, PA-SUE-16, 17, PA-INS-12, PA-SOC-16, 17, 18, PA-POR-20, 21; PAN-POR-105 Comunidad; RF-POR-180 O2; CU-INS-15 antes CU-INS-01 de M17). Respaldo en `_trabajo/backup-cierre-M10M19-202611051500`. Decisión del coordinador: `costCenterModelId` → `costCenterModels` (M15 lo declaró; prevalece sobre `distributionModels` que había puesto T05).
- Pendiente para M01-M09 (cuando termine su segunda ronda): M01, M04, M05 adoptar `associateMembershipId` si consumen `ins.membership.*`.
- Plan: sumar RF-POR-180 (O2) en el recuento.
- M01-M09 ronda 2 hecha (PA-PER-18, PA-CAT-22, PA-MED-14, PA-FAC-22, PA-FIS-21). Pendiente T05: agregar `bundleSubscriptions` (M02 §7.29) y `fiscalClasses` (M06 §7.38); destinos `exceptionId` → `approvalRequests` (T11), `externalClientId` → `persons`, `bundleSubscriptionId` → `bundleSubscriptions`, `activityId` → `normativeTables` (`arcaActivities`, M06), `fiscalClassId` → `fiscalClasses`, `adjustmentRequestIds` → `invoiceAnnulmentRequests`; estados de `premises`, `meteringSystems`, `provincialValidationCodes`, `bundleSubscriptions`, `fiscalClasses`.
- Grupo T ronda 2 hecha (T03: Comunidad PAN-POR-105, tabbars empleado/registrado alineadas a M19 §10.1, PA-SUE-16). Capability del muro: canónica `com.wall.ver` (T02 §4.4.1), `com.muro.ver` alias. PAN-SUE-43 ruta `/app/empleado/legajo` (M19 PAN-POR-74).
- Pendiente de siembra: claves de diccionario nuevas `dict:nav.pwe.recibos`, `dict:nav.pwe.solicitudes`, `dict:nav.pwe.perfil`, `dict:nav.pws.contratar`, `dict:nav.pws.perfil` (catálogo base de T03).
- M01-M09 ronda 5 hecha (13 renombres). Para la ronda final de T02: confirmar que `por.preferencias.editar` (M05, preferencias de envío de comprobantes, `/api/fac/my-delivery-preferences`) esté registrada como capability propia; su alias a `com.preferences.editar` vale solo para PAN-POR-60.
- M10-M19 ronda 4 hecha (37 renombres; `tec.servicioTecnico.*` canónica). Para la ronda final de T02:
  - Recurso de cajas: M14 usa `cob.caja.ver` y M07 `cob.cajas.abrir`/`cob.cajas.cerrar`; T02 debe fijar un solo recurso (singular o plural) y dejar alias.
  - Comodines de actores en M10: `tec.campo.*` (inspector), `med.lecturas.*` (lecturista), `cob.campo.*` (cobrador): listarlos en §4.4.3 con las concretas o declarar que caen en AL-08.

## Residuales detectados al regenerar entregables (5-11-2026 tarde)
- ER (03): T05 marca como `R` las 6 colecciones renombradas aunque los anexos ya adoptaron el nombre → pasar a `C`.
- M17: `capitalTransfers`/`proxies` usan `from/to/grantor/proxyMembershipId` → variantes `…AssociateMembershipId` de T05.
- M13: `stockMovements`/`stockBalances` usan `itemId` → `inventoryItemId` (T05).
- `apiUsageDaily`: `day` (anexo) vs `date` (T05). `relationships`: T05 cita `fromPersonId`/`toPersonId` pero su único usa `subjectPersonId`/`target`.
- 211 referencias sin destino (ej. `cashSessions.closeGroupId`, `taxExemptions.partyId`, `worksInstallmentPlans.levyEventId`); [VERIFICAR] en T05 §7.2.1 (`templateId`, `deviceId`, `importBatchId`, `projectId`, `paymentId`, `memberId`); `taxRateIds` con dos destinos.
- 393 campos que figuran solo en T05 (detalle en `03-er/`).
- Vista por dominio 03a–03e desactualizada (423 entidades; `fiscalClassId` "a confirmar").
- Pantallas (05/17): total PAN 1.051 (PAN-POR-105 + PAN-UXD-15 Asistente IA, 16 Directorio interno, 17 Alertas activas en T03 §10.6). Verificar que la maestra/plan citen 1.051 si citan total y que PAN-UXD-15..17 tengan RF y ola.
- Rótulo corto "Cuentas y servicios" (19 car.) excede el máximo de 12 de RN-UXD-006 → definir rótulo corto (propuesta: "Cuentas").
- T03 dice `iam.directorio.ver` "pendiente de alta en T02": ya está registrada.
- Plan: párrafo con "PAN-POR-01..104" → 01..105.
- M19: fila de PAN-POR-105 sin columna de nombre ("Comunidad").
- T03 cita PAN-COM-35..39 inexistentes (7 citas); 7 capabilities difieren anexo vs T03 (PER-10, TEC-51, 54, 55, 56, 63, BIA-21); 4 rutas difieren; 47 ítems de mapa del sitio a otra app; PAN-CFG-31 sin ruta.
- Wireframes 05: 1.598 líneas (> 1.500) y 12 bloques manuales de ancho irregular.
- Procesos (04): 341/341, sin inconsistencias vigentes. Observación: `tec.workOrder.create` es nombre de comando en M10 §9.11.1/§12 y alias de capability en T02 (doble sentido) → renombrar el comando a `tec.workOrders.create`/servicio o aclarar. T09 §9.11 `[VERIFICAR en RN-07]` abierto. `04-procesos-bpmn.md` 1.765 líneas.
- Secuencias/estados (06): 582/625 máquinas. Inconsistencias en `06a` §7: 42 campos de estado sin valores (INC-06-01), 74 con estados sin transiciones (INC-06-02), 18 §7 vs §8 (INC-06-03), 10 + 4 dueño/colección (INC-06-04/05), 205 sin estado inicial (INC-06-08), 16 servicios sin invocador (INC-06-09), 31 tipos de evento fuera de convención en 24 eventos (INC-06-11, ej. `ins.capital.movement.recorded`, `int.debt-publication.*`). `provincialValidationCodes` sin transición `active → expired`.
- Índice: las partes de 06 ahora son 06b–06n (estados), 06o–06v (eventos), 06w (servicios), 06x–06y (FI-INT) → actualizar 00-INDICE.
- ER vista por dominio 03a–03e v1.1 (426 entidades). Residual adicional: M08 §7 `delinquencyNotices.batchId` → `delinquencyBatchId`; ER §28.2 puntos 1, 2, 4–8, 10 abiertos (incluye `rightId`).
- 20–24 regenerados (5.710 CP, 467 CU, 558 ítems de navegación, ≈37.743 h, costos sin cambio). Residuales: CU con mismo ID y objeto distinto sin dueño: CU-13 (M07/M14), CU-ACC-01 (T02/T03), CU-ARQ-01 (T01/T11), CU-SEG-01 (T02/T08). T03 mapa del sitio: SM-PWE-013/016/018 deben pasar al grupo "Tabbar". Maestra §9.2: nota "M19 debe alinear su tabbar" desactualizada. `07-estrategia-pruebas.md` AC-06 corregido a `ESC-FIS-32`.
- 18/19 regenerados (2.223 filas, 4.189 operaciones; 658 eventos). Residuales: T02 sin scopes `erp.catalog:read`, `erp.finance:read`; 85 celdas de capability con rol/texto; M10 API-TEC-26, 29, 39, 40, 47 con menos grupos de método que rutas; reemplazadas sin destino por ID: API-FAC-023, API-VEN-006, 007, API-CFG-54, 58; T04 servicio sin nombre técnico; M06 §11.1 tres consumidores [VERIFICAR]; 274 colecciones sin tabla de campos en §7; 24 alias de evento con más de un canónico; colas fuera de clases T01 (JOB-PLA-01). Detalle en `18-openapi/_inconsistencias.md`.
