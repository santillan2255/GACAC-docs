"""Cierre de la corrección de inconsistencias: actualiza 04-matriz-trazabilidad.md (05-11-2026).

Regenera las filas afectadas de §15 con el mismo control que _trabajo/plan_recuento.py y agrega a §18
las PA nuevas de la corrección (menciones, anexos que citan y RF -> prompt calculados leyendo anexos/*.md;
los respaldos _trabajo/backup-* no se leen).
"""
import os, re, sys, glob, collections
sys.path.insert(0, os.path.dirname(__file__))
import plan_recuento as pr  # noqa

ESPEC = pr.ESPEC
F = os.path.join(ESPEC, '04-matriz-trazabilidad.md')
raw = open(F, 'rb').read()
bom = raw.startswith(b'\xef\xbb\xbf')
t = raw.decode('utf-8-sig')
NL = '\r\n' if '\r\n' in t else '\n'
assert '## 21. Cierre de la corrección de inconsistencias' not in t, 'ya aplicado'

C = 'cierre 05-11-2026'


def rep(a, b, n=1):
    global t
    c = t.count(a)
    assert c == n, (a[:90], c)
    t = t.replace(a, b)


# Encabezado
rep('| Versión | 1.1 (reemplaza la 1.0 del 04-11-2026; los cambios están en la sección 20) |',
    '| Versión | 1.1 (reemplaza la 1.0 del 04-11-2026; los cambios están en la sección 20). Actualizada el 05-11-2026 por el cierre de la corrección de inconsistencias (sección 21) |')
rep('plan de olas v1.1 (172 prompts, 4.203 RF y 292 RNF)', 'plan de olas v1.1 (172 prompts, 4.204 RF y 292 RNF; antes 4.203)')
rep('20. Cambios de la versión 1.1' + NL + NL + '---',
    '20. Cambios de la versión 1.1' + NL + '21. Cierre de la corrección de inconsistencias (05-11-2026)' + NL + NL + '---')

# §15.1
rep('| RF definidos en los anexos | 4.203 (29 anexos;', '| RF definidos en los anexos | 4.204 (antes 4.203; 29 anexos;')
rep('| RF y RNF con exactamente un prompt | 4.495 de 4.495 |', '| RF y RNF con exactamente un prompt | 4.496 de 4.496 (antes 4.495) |')
# §15.2
rep('| O2 | 19 | 613 | 15 | 19 / 613 / 15 | Sí |', '| O2 | 19 | 614 (antes 613) | 15 | 19 / 614 / 15 | Sí |')
rep('| O5 | 14 | 468 | 13 | 14 / 468 / 13 | Sí |', '| O5 | 14 | 469 (antes 468; RF-CON-160, plan §21.5) | 13 | 14 / 469 / 13 | Sí |')
rep('| O11 | 10 | 90 | 7 | 10 / 90 / 7 | Sí |', '| O11 | 10 | 89 (antes 90; RF-CON-160, plan §21.5) | 7 | 10 / 89 / 7 | Sí |')
rep('| **Total** | **172** | **4.203** | **292** | 172 / 4.203 / 292 | Sí |',
    '| **Total** | **172** | **4.204** (antes 4.203) | **292** | 172 / 4.204 / 292 | Sí |')
# §15.3
rep('| M19 | 179 | — | 179 | 0 | 0 | 17 | 179 / 179 / 0 |', '| M19 | 180 (antes 179) | — | 180 | 0 | 0 | 17 | 180 / 180 / 0 |')
rep('| **Total** | **4.203** | **292** | **4.495** | **0** | **0** | | **4.203 / 4.203 / 0** |',
    '| **Total** | **4.204** (antes 4.203) | **292** | **4.496** | **0** | **0** | | **4.204 / 4.204 / 0** |')
# §15.4
rep('| RF-CON-160 | M15 | O11 (O5 para saldos de apertura) | PRO-O11-06 (O11) | — | Celda con dos olas: el plan toma O11 como inicio y deja los saldos de apertura como extensión en O5 (§9.4); por la regla §0.1 el inicio sería O5 |',
    '| RF-CON-160 | M15 | O11 (O5 para saldos de apertura) | PRO-O5-11 (O5; antes PRO-O11-06) | Plan §18 y §21.5: reasignado a la ola más temprana de la celda | Celda con dos olas: por la regla §0.1 empieza en O5 y la migración completa queda como extensión en PRO-O11-06 (corregido en el plan §21.5; antes el plan tomaba O11 como inicio) |')
rep('| RF-UXD-163 | T03 | O9+ (cuando haya bot) | PRO-O6-09 (O6) | §18: DEC-056 adelanta el bot y el omnicanal a O6 | Reasignación declarada |',
    '| RF-UXD-163 | T03 | O6 (DEC-056; antes `O9+ (cuando haya bot)`) | PRO-O6-09 (O6) | §18: DEC-056 adelanta el bot y el omnicanal a O6 | Reasignación declarada; desde el ' + C + ' la celda de T03 coincide con el prompt |')

# §15.7
prompts = {p['id']: p for p in pr.leer_prompts()}
assert 'RF-CON-160' in prompts['PRO-O11-06']['ext'], prompts['PRO-O11-06']['ext']
rep('| PRO-O2-17 | Portal del socio: inicio, servicios, gestiones, comunidad y administración | 64 | 9 | RF-POR-047, 048, 051..054, 056..065, 067, 070, 071, 109..112, 114, 116, 117, 121..126, 134, 137..156, 158, 160, 174;',
    '| PRO-O2-17 | Portal del socio: inicio, servicios, gestiones, comunidad y administración | 65 | 9 | RF-POR-047, 048, 051..054, 056..065, 067, 070, 071, 109..112, 114, 116, 117, 121..126, 134, 137..156, 158, 160, 174, 180;')
rep('| PRO-O5-11 | Asientos manuales y automáticos, conciliaciones e informes base | 56 | 0 | RF-CON-035..040, 042..045, 048, 050..067, 092..094, 100..102, 112, 114, 115, 121, 124..126, 139..141, 153..157, 159;',
    '| PRO-O5-11 | Asientos manuales y automáticos, conciliaciones e informes base | 57 | 0 | RF-CON-035..040, 042..045, 048, 050..067, 092..094, 100..102, 112, 114, 115, 121, 124..126, 139..141, 153..157, 159, 160;')
rep('| PRO-O11-06 | Migración por dominio: históricos y equivalencias | 19 | 0 | RF-MIG-006, 060, 061, 063, 064; RF-CFG-132, 142; RF-TAR-101, 102; RF-CON-160; RF-COB-155;',
    '| PRO-O11-06 | Migración por dominio: históricos y equivalencias | 18 | 0 | RF-MIG-006, 060, 061, 063, 064; RF-CFG-132, 142; RF-TAR-101, 102; RF-COB-155;')
rep('RF-POR-020, 127, 171, 172; RF-WFL-163; RF-FIS-163 | RF-CAT-113; RF-COM-090; RF-MOR-218; RF-STK-136 |',
    'RF-POR-020, 127, 171, 172; RF-WFL-163; RF-FIS-163 | RF-CAT-113; RF-COM-090; RF-MOR-218; RF-STK-136; RF-CON-160 (antes en Implementa con 19 RF; plan §21.5) |')

# BASE: CU renumerados en los anexos que citan
rep('| › Caso de uso de ejemplo — CU-26 (§26) (L1456) | M09, T09, T11 | M09: RF-CRM-140, RF-CRM-236, §16 … ·',
    '| › Caso de uso de ejemplo — CU-26 (§26) (L1456) | M09, T09, T11 | M09: RF-CRM-140, RF-CRM-236, §16 (CU-CRM-21, antes CU-26; el CU-26 lo define T09, ' + C + ') … ·')
rep('| › Caso de uso integrado — CU-INS-01 (§73) (L3930) | M10, M11, M13, M17, T09 | M10: §9.1, §16, RF-TEC-085 … · M11: encab., RF-VEN-011, §16 … · M13: §9.2, §16, RF-STK-054 … · M17: §16 ·',
    '| › Caso de uso integrado — CU-INS-01 (§73) (L3930) | M10, M11, M13, M17, T09 | M10: §9.1, §16, RF-TEC-085 … · M11: encab., RF-VEN-011, §16 … · M13: §9.2, §16, RF-STK-054 … · M17: §16 (CU-INS-15, antes CU-INS-01; el CU-INS-01 lo define M10, ' + C + ') ·')

# §18: PA nuevas de la corrección
t02 = open(os.path.join(ESPEC, '02-preguntas-abiertas.md'), encoding='utf-8-sig').read()
fila02 = {}
for l in t02.split('\n'):
    m = re.match(r'\| (PA-[A-Z0-9-]+?-\d+) \| ([^|]+) \| ([^|]+) \|', l)
    if m:
        fila02[m.group(1)] = (m.group(2).strip(), m.group(3).strip(), l.rstrip().rsplit('|', 2)[-2].strip())
NUEVAS = ['PA-PER-17', 'PA-PER-18', 'PA-CAT-20', 'PA-CAT-21', 'PA-CAT-22', 'PA-MED-14', 'PA-TAR-20', 'PA-FAC-21', 'PA-FAC-22',
          'PA-FIS-19', 'PA-FIS-20', 'PA-FIS-21', 'PA-COB-19', 'PA-COB-20', 'PA-MOR-21', 'PA-CRM-19', 'PA-TEC-21', 'PA-TEC-22',
          'PA-STK-10', 'PA-TES-18', 'PA-CON-18', 'PA-SUE-16', 'PA-SUE-17', 'PA-INS-12', 'PA-SOC-16', 'PA-SOC-17', 'PA-SOC-18',
          'PA-POR-20', 'PA-POR-21', 'PA-CFG-14', 'PA-DAT-03', 'PA-INT-26', 'PA-MIG-20', 'PA-NFR-22', 'PA-NFR-23', 'PA-COM-17',
          'PA-COM-18', 'PA-WFL-22']
assert len(NUEVAS) == 38
textos = {}
for f in sorted(glob.glob(os.path.join(ESPEC, 'anexos', '*.md'))):
    b = os.path.basename(f)
    cod = b[:3] if not b.startswith('T04b') else 'T04b'
    textos.setdefault(cod, []).append(open(f, encoding='utf-8-sig').read())
rf_prompt = {}
for p in prompts.values():
    for r in p['rf']:
        rf_prompt.setdefault(r, p['id'])
filas = []
for pa in NUEVAS:
    dueno, tema, est = fila02[pa]
    menc = sum(x.count(pa) for x in textos[dueno])
    otros = sorted(k for k, v in textos.items() if k != dueno and any(pa in x for x in v))
    rfs = collections.defaultdict(list)
    for v in textos.values():
        for x in v:
            for l in x.split('\n'):
                m = re.match(r'^\|\s*\**(RF-[A-Z]+-\d{3})\**\s*\|', l)
                if m and re.search(re.escape(pa) + r'(?!\d)', l) and m.group(1) in rf_prompt:
                    rfs[rf_prompt[m.group(1)]].append(m.group(1))
    if rfs:
        rfc = '; '.join('%s: %s' % (k, ', '.join(sorted(set(v)))) for k, v in sorted(rfs.items()))
        res = 'Trazada (dueño la registra)'
    else:
        rfc = '—'
        res = 'Trazada en el dueño; ningún RF la cita (solo PA, RN, PRM o §21)'
    if menc == 0:
        res = 'Falta en el dueño'
    filas.append('| %s | %s | %s | %s | — (corrección de inconsistencias) | %d | %s | %s | %s |' % (
        pa, dueno, tema, est, menc, ', '.join(otros) or '—', rfc, res))
ancla = '| PA-DAT-02 | T05 | Detalle histórico de más de 36 meses |'
i = t.index(ancla)
j = t.index(NL, i)
t = t[:j] + NL + NL.join(filas) + t[j:]
rep('El plan no cita estas PA por ID (aplica R7 y R8 sobre el estado de cada PA en `02-preguntas-abiertas.md`); por eso la columna de prompts muestra los que implementan los RF que la citan.',
    'El plan no cita estas PA por ID (aplica R7 y R8 sobre el estado de cada PA en `02-preguntas-abiertas.md`); por eso la columna de prompts muestra los que implementan los RF que la citan. '
    'Desde el ' + C + ' se agregan al final las 38 PA que los anexos registraron durante la corrección de inconsistencias (todas `Asumida (DEC-072)`).')

# §21 nueva
sec = [
    '',
    '## 21. Cierre de la corrección de inconsistencias (05-11-2026)',
    '',
    'Insumo: `_trabajo/correccion-inconsistencias-pendientes-cierre.md`. Las filas de §15 se recalcularon con `_trabajo/plan_recuento.py` y `_trabajo/matriz_verif_157.py` (lectura de `anexos/*.md` y del plan; los respaldos `_trabajo/backup-*` no se leen); §18 con `_trabajo/cierre_final_matriz.py`. Las matrices de fuentes (secciones 3 a 13) no se regeneraron: ninguna unidad de fuente cambia de estado por estos cambios (los anexos siguen citando las mismas secciones de BASE).',
    '',
    '### 21.1 Casos de uso renumerados y dueños de CU compartidos',
    '',
    '| CU vigente | Anexo | Antes | Dueño del ID anterior | Fundamento | Efecto en esta matriz |',
    '|---|---|---|---|---|---|',
    '| CU-CAT-13 | M02 §16 | CU-MER-01 (de M02) | M03 §16 (CU-MER-01, usuario-generador) | PA-CAT-20 | Sin cambio de estado; BASE no tiene fila propia de CU-MER-01 en la sección 7 |',
    '| CU-CRM-21 | M09 §16 | CU-26 (de M09) | T09 (CU-26 de BASE §26) | Pendiente de cierre (CU duplicados) | Fila BASE §26 "CU-26": M09 sigue citando BASE §26; se anota el ID nuevo |',
    '| CU-INS-15 | M17 §16 | CU-INS-01 (de M17) | M10 (CU-INS-01 de BASE §73, instalación integral) | Pendiente de cierre (CU duplicados) | Fila BASE §73 "CU-INS-01": M17 sigue citando BASE §73; se anota el ID nuevo |',
    '| CU-CIC-01 | M08 §16 (dueño) | Definiciones parciales en M02, M09 y M19 | — | PA-MOR-21 (reemplaza para este CU la opción de PA-CAT-20) | M02, M09 y M19 citan la parte que les toca |',
    '| CU-SOL-01 | M09 §16 (dueño) | Definiciones parciales en M02 y M09 | — | PA-CRM-19 | M02 cita su parte de contrato |',
    '',
    '### 21.2 Requisito y pantalla nuevos',
    '',
    '| RF | Pantalla | Anexo | Ola | Prompt | Fuente | Estado |',
    '|---|---|---|---|---|---|---|',
    '| RF-POR-180 (Comunidad en la tabbar del socio) | PAN-POR-105 `/app/comunidad` | M19 | O2 | PRO-O2-17 | PA-POR-20; maestro §9.2; T03 RF-UXD-066, CTR-UXD-12 | Trazado: el RF cita la PAN y la PA, y el prompt lo implementa (plan §21.6) |',
    '',
    '### 21.3 Colecciones nuevas',
    '',
    'Esta matriz no tiene una sección de colecciones: las colecciones se trazan en T05 y las tablas de ProCoop en la sección 13 desde T07 §19. Se registran aquí para la próxima regeneración.',
    '',
    '| Colección | T05 | Dueño | Ola | PA | Tabla ProCoop | Efecto en la sección 13 |',
    '|---|---|---|---|---|---|---|',
    '| `costCenterModels` | COL-CON-39 | M15 §7.19.1 | O5 | PA-CON-18 | — | Ninguno |',
    '| `bundleSubscriptions` | COL-CAT-29 | M02 §7.29 | O4 | PA-CAT-22 | — (no existe en ProCoop) | Ninguno (`COMBOS` sigue → `products.bundle`) |',
    '| `fiscalClasses` | COL-FIS-47 | M06 §7.38 | O2 | PA-FIS-21 | — | Ninguno |',
    '| `collectionAccountingGroups` | COL-COB-47 | M07 §7.36 | O5 | PA-COB-20 | `GRU_CON` | La fila `GRU_CON` sigue el destino de T07 §19.17 (`postingRules`); T05 y M15 ya la mandan a `collectionAccountingGroups` (cuentas en `entityAccountAssignments`). Pendiente de T07 |',
    '',
    '### 21.4 Cifras',
    '',
    '| Sección | Valor vigente | Valor anterior (reemplazado) |',
    '|---|---|---|',
    '| Encabezado, 15.1 a 15.3 | 4.204 RF; 4.496 RF y RNF con un prompt; O2 614; M19 180 | 4.203; 4.495; O2 613; M19 179 |',
    '| 15.2 | O5 469 y O11 89 (alineado con el plan §21.5, que esta matriz no había tomado) | O5 468 y O11 90 |',
    '| 15.4 | RF-CON-160 en PRO-O5-11; RF-UXD-163 con celda `O6 (DEC-056)` en T03 | PRO-O11-06; `O9+ (cuando haya bot)` |',
    '| 15.7 | PRO-O2-17 65 RF (con RF-POR-180); PRO-O5-11 57 (con RF-CON-160); PRO-O11-06 18 (RF-CON-160 como extensión). Verificación: los 172 prompts coinciden con el plan | 64, 56 y 19 |',
    '| 18 | 48 PA (10 de los huecos y 38 de la corrección) | 10 |',
]
fin = NL if t.endswith(NL) else ''
t = t.rstrip('\r\n') + NL + NL.join(sec) + fin
open(F, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + t.encode('utf-8'))
print('ok', len(filas))
for f in filas:
    if 'Falta' in f:
        print('FALTA', f[:80])
