import glob, os, re
OLD = [r'ins\.capital\.movement', r'ins\.capital\.transfer', r'ins\.capital\.refund', r'ins\.surplus\.distribution',
       r'ins\.inaes\.report', r'stk\.item\.below-minimum', r'int\.fleet\.positions-received', r'\bCU-13\b']
PA = re.compile(r'PA-(CMP-16|STK-11|TES-19|CON-19|SUE-18|INS-13|SOC-19|POR-22)\b')
for f in sorted(glob.glob('../anexos/M1[2-9]-*.md')):
    t = open(f, encoding='utf-8').read().split('\n')
    n = os.path.basename(f)[:3]
    for i, l in enumerate(t, 1):
        for o in OLD:
            if re.search(o, l) and 'antes' not in l.lower() and 'Reemplazado' not in l:
                print(n, i, o, l[:160])
    pa = [i for i, l in enumerate(t, 1) if re.match(r'^#+ .*PA-', l) and PA.search(l)]
    print(n, 'encabezado PA', pa)
