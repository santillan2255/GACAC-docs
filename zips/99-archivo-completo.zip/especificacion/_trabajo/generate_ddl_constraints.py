#!/usr/bin/env python3
"""Genera índices únicos (T05) y FK diferidas explícitas (referencias T05 → colección)."""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import date
from pathlib import Path

from ddl_type_map import camel_to_pascal
from generate_07_catalog_from_t05 import (
    collection_to_table,
    parse_t05,
    pk_name,
    tenant_column,
)
from anexo_fk_hints import load_mega_fk_hints
from ddl_type_map import mongo_field_to_sql as map_field
from generate_exhaustive_ddl import build_columns, needs_tenant

ESPEC = Path(__file__).resolve().parents[1]
DDL = ESPEC / "07-ddl" / "sql"
IDX_OUT = DDL / "200-all-unique-indexes.sql"
FK_OUT = DDL / "201-deferred-foreign-keys.sql"
FK_INTRA = DDL / "203-foreign-keys-intramodule.sql"
FK_CYCLES_MD = ESPEC / "07-ddl" / "FK-CYCLES.md"

FIELD_IN_BRACES = re.compile(r"\{([^}]+)\}")
BACKTICK_FIELDS = re.compile(r"`([a-z][a-zA-Z0-9_]*)`")
REF_TARGET = re.compile(
    r"`([a-z][a-zA-Z0-9_]*)`\s*(?:→|->)\s*`([a-z][a-zA-Z0-9_]*)`"
)
SKIP_UNIQUE = re.compile(r"\bd\.|parcial|\[VERIFICAR\]", re.I)


def unique_specs(raw: str) -> list[list[str]]:
    """Devuelve listas de nombres de campo lógico (camelCase) por índice único."""
    raw = raw.strip()
    if not raw or raw == "—" or raw.startswith("—"):
        return []
    if SKIP_UNIQUE.search(raw):
        return []
    specs: list[list[str]] = []
    if FIELD_IN_BRACES.search(raw):
        for inner in FIELD_IN_BRACES.findall(raw):
            fields = [f.strip().split()[0] for f in inner.split(",")]
            fields = [f for f in fields if f and not f.startswith("_")]
            if fields:
                specs.append(fields)
        return specs
    for chunk in re.split(r";", raw):
        chunk = chunk.strip().strip("`")
        if not chunk or SKIP_UNIQUE.search(chunk):
            continue
        if chunk.startswith("{"):
            continue
        # `code` o code
        m = re.match(r"^`?([a-zA-Z][a-zA-Z0-9_]*)`?", chunk.split()[0])
        if m:
            specs.append([m.group(1)])
    return specs


def to_sql_cols(fields: list[str], with_tenant: bool) -> list[str]:
    cols = []
    for f in fields:
        if f in ("_id",):
            continue
        if f == "tenantId":
            cols.append("TenantId")
        else:
            cols.append(camel_to_pascal(f))
    if with_tenant and "TenantId" not in cols:
        cols.insert(0, "TenantId")
    return cols


def build_catalog_maps() -> tuple[dict[str, dict], dict[str, str]]:
    """collection -> row meta; collection -> fq table schema.Table"""
    by_coll: dict[str, dict] = {}
    fq_by_coll: dict[str, str] = {}
    for r in parse_t05():
        if "A→" in r["est"]:
            continue
        by_coll[r["collection"]] = r
        fq_by_coll[r["collection"]] = f"{r['schema']}.{r['table']}"
    return by_coll, fq_by_coll


def render_unique_index(
    schema: str, table: str, cols: list[str], seq: int
) -> str:
    iname = f"UX_{schema}_{table}_{seq}"
    if len(iname) > 120:
        iname = f"UX_{schema}_{table}_{seq}"[:120]
    cols_s = ", ".join(f"[{c}]" for c in cols)
    fq = f"{schema}.{table}"
    return f"""IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'{iname}' AND object_id = OBJECT_ID(N'{fq}')
)
    CREATE UNIQUE INDEX [{iname}] ON [{schema}].[{table}] ({cols_s});
GO
"""


FK_INFER: dict[str, str] = {
    "identityId": "identities",
    "personId": "persons",
    "membershipId": "memberships",
    "roleId": "roles",
    "holderId": "holders",
    "accountId": "accounts",
    "contractId": "serviceContracts",
    "tenantId": "tenants",
    "legalEntityId": "legalEntities",
    "moduleCatalogId": "moduleCatalog",
    "formDefinitionId": "formDefinitions",
    "formVersionId": "formVersions",
    "documentId": "documents",
    "servicePointId": "servicePoints",
    "ledgerAccountId": "ledgerAccounts",
    "supplierId": "suppliers",
    "employeeId": "employees",
}


def parse_fk_pairs(refs: str) -> list[tuple[str, str]]:
    if not refs or refs.strip() in ("—", "-"):
        return []
    pairs: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for fm, tc in REF_TARGET.findall(refs):
        key = (fm, tc)
        if key not in seen:
            seen.add(key)
            pairs.append(key)
    for fm in BACKTICK_FIELDS.findall(refs):
        if fm in FK_INFER and fm != "tenantId":
            tc = FK_INFER[fm]
            key = (fm, tc)
            if key not in seen:
                seen.add(key)
                pairs.append(key)
    return pairs


def render_fk(
    schema: str,
    table: str,
    col: str,
    ref_schema: str,
    ref_table: str,
    ref_col: str,
    nocheck: bool = False,
) -> str:
    cname = f"FK_{schema}_{table}_{col}_{ref_table}"
    if len(cname) > 120:
        cname = cname[:120]
    fq = f"{schema}.{table}"
    nc = " WITH NOCHECK" if nocheck else ""
    return f"""IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'{cname}'
)
BEGIN
    ALTER TABLE [{schema}].[{table}]{nc}
        ADD CONSTRAINT [{cname}]
        FOREIGN KEY ([{col}]) REFERENCES [{ref_schema}].[{ref_table}] ([{ref_col}]);
END;
GO
"""


def fq_table(schema: str, table: str) -> str:
    return f"{schema}.{table}"


def topo_table_order(fks: list[dict]) -> dict[str, int]:
    """Orden: tablas referenciadas (padre) antes que hijas."""
    parents_of: dict[str, set[str]] = defaultdict(set)
    children_of: dict[str, set[str]] = defaultdict(set)
    nodes: set[str] = set()
    for fk in fks:
        child = fq_table(fk["schema"], fk["table"])
        parent = fq_table(fk["ref_schema"], fk["ref_table"])
        nodes.add(child)
        nodes.add(parent)
        if child != parent:
            parents_of[child].add(parent)
            children_of[parent].add(child)
    in_deg = {n: len(parents_of.get(n, ())) for n in nodes}
    q = sorted(n for n in nodes if in_deg[n] == 0)
    order: dict[str, int] = {}
    rank = 0
    while q:
        n = q.pop(0)
        order[n] = rank
        rank += 1
        for ch in sorted(children_of.get(n, ())):
            in_deg[ch] -= 1
            if in_deg[ch] == 0:
                q.append(ch)
                q.sort()
    for n in nodes:
        if n not in order:
            order[n] = rank
            rank += 1
    return order


def cycle_edge_keys(fks: list[dict]) -> set[str]:
    """Aristas en ciclos del grafo tabla→tabla referenciada."""
    graph: dict[str, set[str]] = defaultdict(set)
    nodes: set[str] = set()
    key_of: dict[tuple[str, str], str] = {}
    for fk in fks:
        child = fq_table(fk["schema"], fk["table"])
        parent = fq_table(fk["ref_schema"], fk["ref_table"])
        nodes.add(child)
        nodes.add(parent)
        if child == parent:
            continue
        graph[child].add(parent)
        key_of[(child, parent)] = fk["key"]
    color = {n: 0 for n in nodes}
    cycle_edges: set[str] = set()

    def dfs(u: str, stack: list[str]) -> None:
        color[u] = 1
        stack.append(u)
        for v in graph.get(u, ()):
            if color[v] == 1:
                i = stack.index(v)
                cyc = stack[i:] + [v]
                for a, b in zip(cyc, cyc[1:]):
                    cycle_edges.add(key_of.get((a, b), f"{a}->{b}"))
            elif color[v] == 0:
                dfs(v, stack)
        stack.pop()
        color[u] = 2

    for n in sorted(nodes):
        if color[n] == 0:
            dfs(n, [])
    return cycle_edges


def sort_fks(fks: list[dict], order: dict[str, int]) -> list[dict]:
    def sort_key(fk: dict) -> tuple:
        child = fq_table(fk["schema"], fk["table"])
        parent = fq_table(fk["ref_schema"], fk["ref_table"])
        return (order.get(parent, 9999), order.get(child, 9999), child, fk["col"])

    return sorted(fks, key=sort_key)


def write_fk_sql(
    fks: list[dict],
    cycle_keys: set[str],
    header_lines: list[str],
) -> str:
    lines = header_lines + [""]
    order = topo_table_order(fks)
    for fk in sort_fks(fks, order):
        nocheck = fk["key"] in cycle_keys
        lines.append(
            render_fk(
                fk["schema"],
                fk["table"],
                fk["col"],
                fk["ref_schema"],
                fk["ref_table"],
                fk["ref_pk"],
                nocheck=nocheck,
            ).rstrip()
        )
        lines.append("")
    return "\n".join(lines) + "\n"


def main() -> None:
    by_coll, fq_by_coll = build_catalog_maps()
    idx_lines = [
        f"-- Índices únicos desde T05 — {date.today().isoformat()}",
        "-- Regenerar: python docs/especificacion/_trabajo/generate_ddl_constraints.py",
        "",
    ]
    header_full = [
        f"-- FK diferidas (completo, orden topológico) — {date.today().isoformat()}",
        "-- Después de 200-all-unique-indexes.sql",
        "-- Bloque 1: T05 | Bloque 2: anexos §7 Referencia",
        "-- Ciclos: WITH NOCHECK (ver FK-CYCLES.md)",
    ]
    header_intra = [
        f"-- FK intra-módulo (mismo esquema) — {date.today().isoformat()}",
        "-- Variante conservadora: sin FK cruzadas entre esquemas",
        "-- Sustituye a 201-deferred-foreign-keys.sql en deploy si se desea",
    ]
    idx_count = 0
    fk_t05 = 0
    fk_anexo = 0
    seen_fk: set[str] = set()
    fks: list[dict] = []
    col_cache: dict[str, set[str]] = {}

    def table_col_names(r: dict) -> set[str]:
        cache_key = f"{r['schema']}.{r['table']}"
        if cache_key not in col_cache:
            cols, _, _ = build_columns(
                r["table"],
                r["collection"],
                r["owner"],
                r["alc"],
                tenant_column(r["alc"]),
            )
            col_cache[cache_key] = {c[0] for c in cols}
        return col_cache[cache_key]

    def add_fk(
        schema: str,
        table: str,
        col: str,
        target_coll: str,
        source: str,
        col_check: set[str] | None = None,
    ) -> None:
        nonlocal fk_t05, fk_anexo
        if col_check is not None and col not in col_check:
            return
        if target_coll not in fq_by_coll:
            return
        ref_schema, ref_table = fq_by_coll[target_coll].split(".")
        key = f"{schema}.{table}.{col}->{ref_schema}.{ref_table}"
        if key in seen_fk:
            return
        seen_fk.add(key)
        ref_pk = pk_name(ref_table)
        fks.append(
            {
                "schema": schema,
                "table": table,
                "col": col,
                "ref_schema": ref_schema,
                "ref_table": ref_table,
                "ref_pk": ref_pk,
                "key": key,
                "source": source,
            }
        )
        if source == "t05":
            fk_t05 += 1
        else:
            fk_anexo += 1

    # T05: columnas Únicos y Claves y referencias
    text = (ESPEC / "anexos" / "T05-DAT-modelo-datos.md").read_text(encoding="utf-8")
    ROW = re.compile(
        r"^\| (COL-[A-Z0-9]+-\d+) \| `([^`]+)` \| ([^|]+) \|"
    )
    for line in text.splitlines():
        m = ROW.match(line)
        if not m:
            continue
        col_id, coll, _owner = m.groups()
        if coll not in by_coll:
            continue
        r = by_coll[coll]
        if "A→" in r["est"] or r["schema"] == "pla":
            continue
        parts = [p.strip() for p in line.split("|")]
        unique_raw = parts[6] if len(parts) > 6 else ""
        refs_raw = parts[5] if len(parts) > 5 else ""
        with_tenant = needs_tenant(r["alc"], tenant_column(r["alc"]))
        schema, table = r["schema"], r["table"]

        for n, fields in enumerate(unique_specs(unique_raw), 1):
            sql_cols = to_sql_cols(fields, with_tenant)
            if not sql_cols:
                continue
            idx_lines.append(
                render_unique_index(schema, table, sql_cols, n).rstrip()
            )
            idx_lines.append("")
            idx_count += 1

        for fk_field, target_coll in parse_fk_pairs(refs_raw):
            if not fk_field.endswith("Id") or fk_field == "tenantId":
                continue
            if target_coll == coll:
                continue
            col = camel_to_pascal(fk_field)
            add_fk(schema, table, col, target_coll, "t05", table_col_names(r))

    anexo_hints = load_mega_fk_hints()
    for source_coll, hints in sorted(anexo_hints.items()):
        if source_coll not in by_coll:
            continue
        r = by_coll[source_coll]
        if "A→" in r["est"] or r["schema"] == "pla":
            continue
        schema, table = r["schema"], r["table"]
        table_cols = table_col_names(r)
        for field, typ, target_coll in hints:
            if target_coll == source_coll or target_coll == "tenants":
                continue
            mapped = map_field(field, typ)
            if not mapped:
                continue
            col, sql_type, _ = mapped
            if sql_type != "UNIQUEIDENTIFIER":
                continue
            add_fk(schema, table, col, target_coll, "anexo", table_cols)

    IDX_OUT.write_text("\n".join(idx_lines) + "\n", encoding="utf-8")

    cycle_keys = cycle_edge_keys(fks)
    fks_intra = [fk for fk in fks if fk["schema"] == fk["ref_schema"]]
    FK_OUT.write_text(write_fk_sql(fks, cycle_keys, header_full), encoding="utf-8")
    FK_INTRA.write_text(
        write_fk_sql(fks_intra, cycle_edge_keys(fks_intra), header_intra),
        encoding="utf-8",
    )

    cycle_fks = [fk for fk in fks if fk["key"] in cycle_keys]
    cyc_lines = [
        f"# Ciclos FK detectados — {date.today().isoformat()}",
        "",
        f"- Total FK completo: **{len(fks)}**",
        f"- En ciclo (`WITH NOCHECK`): **{len(cycle_fks)}**",
        f"- FK intra-módulo (`203`): **{len(fks_intra)}**",
        "",
        "Las restricciones en ciclo se crean con `ALTER TABLE ... WITH NOCHECK` "
        "para permitir el despliegue inicial; EF/migraciones pueden endurecer después.",
        "",
    ]
    if cycle_fks:
        cyc_lines.append("## Aristas en ciclo")
        cyc_lines.append("")
        for fk in cycle_fks[:80]:
            cyc_lines.append(f"- `{fk['key']}`")
        if len(cycle_fks) > 80:
            cyc_lines.append(f"- … y {len(cycle_fks) - 80} más")
    else:
        cyc_lines.append("No se detectaron ciclos en el grafo tabla→referencia.")
    FK_CYCLES_MD.write_text("\n".join(cyc_lines) + "\n", encoding="utf-8")

    deploy = ESPEC / "07-ddl" / "deploy-coopapps-full.sql"
    body = deploy.read_text(encoding="utf-8")
    if "203-foreign-keys-intramodule.sql" not in body:
        body = body.replace(
            ":r sql/201-deferred-foreign-keys.sql",
            ":r sql/201-deferred-foreign-keys.sql\n"
            "-- Conservador (solo mismo esquema): comentar 201 y descomentar:\n"
            "-- :r sql/203-foreign-keys-intramodule.sql",
        )
        deploy.write_text(body, encoding="utf-8")

    print(
        f"Wrote {idx_count} UX, {len(fks)} FK full, {len(fks_intra)} FK intra, "
        f"{len(cycle_fks)} NOCHECK (t05={fk_t05}, anexo={fk_anexo})"
    )


if __name__ == "__main__":
    main()