import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from repl import apply

P = []
P.append(("| Dueño de datos | Empresas empleadoras, legajos",
          "| Dueño de datos | Empresas empleadoras (como subdocumento `employer` de `legalEntities` de T04: M16 define y edita el subdocumento, T04 es dueño de la colección; CTR-DAT-06, DEC-064), legajos"))
P.append(("### 5.2. Empresas empleadoras (multiempleador)\n",
          "### 5.2. Empresas empleadoras (multiempleador)\n\n> **DEC-064 (empleador = entidad jurídica):** cada empresa empleadora es una entidad jurídica del tenant (`legalEntities` de T04, RF-CFG-134); sus datos de empleador se guardan en el subdocumento `employer` (T04 RF-CFG-139, CTR-DAT-06). CUIT, razón social y domicilio fiscal se leen de la entidad y no se duplican. Toda referencia a la empresa empleadora en este anexo es `legalEntityId` (antes `employerId`).\n"))
P.append(("firma y sello del empleador, responsable de firma de recibos. | DFA M20; CAT `SU_EMPRESAS`, `SU_TIPOEMPLEADOR` |",
          "firma y sello del empleador, responsable de firma de recibos. Se guarda en `legalEntities.employer` (T04 RF-CFG-139); los datos legales y fiscales son los de la entidad jurídica. | DFA M20; CAT `SU_EMPRESAS`, `SU_TIPOEMPLEADOR`; DEC-064; CTR-DAT-06 |"))
P.append(("| RF-SUE-023 | Todo legajo pertenece a una empresa; liquidaciones, períodos, presentaciones, pagos y asientos se segmentan por empresa. | DFA M20; CAT `SU_SUELDOS` |",
          "| RF-SUE-023 | Todo legajo pertenece a una empresa (entidad jurídica, `legalEntityId`); liquidaciones, períodos, presentaciones, pagos y asientos se segmentan por empresa. | DFA M20; CAT `SU_SUELDOS`; DEC-064 |"))

# 7.1
P.append(("### 7.1. `employers` — Empresas empleadoras\n",
          "### 7.1. `employers` — Empresas empleadoras\n\n> **Reemplazado por `legalEntities.employer` (T04 COL-CFG-41, RF-CFG-139; CTR-DAT-06, DEC-064).** La tabla siguiente queda como esquema del subdocumento `employer`, que M16 define y edita por API-CFG-55 (`PATCH /legal-entities/:id/employer`). `code`, `legalName`, `cuit`, `fiscalAddress` y `status` se leen de la entidad jurídica (`legalEntities.code`, `.legalName`, `.fiscal.cuit`, `.address`, `.status`); `personId` no se usa.\n"))
P.append(("Índices: `{tenantId, code}` único; `{tenantId, cuit}` único.\n\n### 7.2. `employees`",
          "Índices: `{tenantId, code}` único; `{tenantId, cuit}` único (los aplica `legalEntities` en T04: `{tenantId, code}` y `{tenantId, 'fiscal.cuit'}`).\n\n### 7.2. `employees`"))
P.append(("| `employerId` | ObjectId | Sí | Empresa empleadora. |",
          "| `legalEntityId` | ObjectId → `legalEntities` (T04) | Sí | Empresa empleadora: entidad jurídica con subdocumento `employer` (reemplaza `employerId`; CTR-DAT-06, DEC-064). |"))
P.append(("| `payrollRunId`, `employeeId`, `employerId`, `payrollTypeId` |",
          "| `payrollRunId`, `employeeId`, `legalEntityId`, `payrollTypeId` |"))
P.append(("| `employerId` | ObjectId | Sí | — |",
          "| `legalEntityId` | ObjectId | Sí | Entidad jurídica empleadora (DEC-064). |"))
# resto de employerId y employerIds
P.append(("employerIds", "legalEntityIds", 0))
P.append(("employerId", "legalEntityId", 0))

# 7.45
P.append(("### 7.45. Colecciones de plataforma consumidas (dueño T04 CFG / M06 FIS)\n",
          "### 7.45. Colecciones de plataforma consumidas (dueño T04 CFG / M06 FIS)\n\n> **Definidas en T04 §7.17 (COL-CFG-44 a 53, RF-CFG-143; CTR-DAT-73).** `officialTableAdoptions` se absorbe en `platformTableAdoptions` de T04 (§7.10) y `holidays` es la colección de T04 §7.7. La tabla siguiente queda como descripción funcional del contenido que M16 consume; `statutoryFileLayouts` no está entre las absorbidas por T04 y sigue descrita aquí.\n"))

# claves PRM y procesos
P.append(("`employers.legalName` / `employers.cuit`", "`legalEntities.legalName` / `legalEntities.fiscal.cuit`"))
P.append(("`employers.", "`legalEntities.employer.", 0))
# API
P.append(("| API-SUE-01 | GET | `/api/admin/sue/employers` | `sue.estructura.configurar` | Listar empresas | — |",
          "| API-SUE-01 | GET | `/api/admin/sue/employers` | `sue.estructura.configurar` | Listar empresas. Reemplazado por API-CFG-55 de T04 (`GET /api/admin/cfg/legal-entities`, filtro con `employer`; CTR-DAT-06). | — |"))
P.append(("| API-SUE-02 | POST/PATCH | `/api/admin/sue/employers[/:id]` | `sue.estructura.configurar` | Crear/editar empresa | Sí (POST) |",
          "| API-SUE-02 | POST/PATCH | `/api/admin/sue/employers[/:id]` | `sue.estructura.configurar` | Crear/editar empresa. Reemplazado por API-CFG-55 de T04 (`PATCH /api/admin/cfg/legal-entities/:id/employer`; la entidad se crea en T04; CTR-DAT-06). | Sí (POST) |"))

# migración
P.append(("| `SU_EMPRESAS` | `employers` | Domicilio a formato M01;",
          "| `SU_EMPRESAS` | `legalEntities.employer` (T04 RF-CFG-142; antes `employers`, CTR-DAT-06) | Match por CUIT con la entidad jurídica; domicilio a formato M01;"))
P.append(("| `SU_EMPRESAS` | `employers` (§7.1) |",
          "| `SU_EMPRESAS` | `legalEntities.employer` (T04; esquema en §7.1) |"))

# PA-SUE-01
P.append(("- **Bloquea:** RF-SUE-140 a 145; O8, O9.\n",
          "- **Bloquea:** RF-SUE-140 a 145; O8, O9.\n- **Estado:** Respondida (DEC-058): O8 importa la liquidación del sistema externo; O9 liquida con el módulo propio con dos períodos en paralelo (opción A).\n"))
P.append(("| BASE §28 vs BASE §104 | §28 trata sueldos como módulo opcional que podía limitarse a importar resultados; §104 lo incorpora completo al alcance. | Alcance completo SUE-001 a SUE-014 en O9; CU-28 se mantiene como alternativa (O8). |",
          "| BASE §28 vs BASE §104 | §28 trata sueldos como módulo opcional que podía limitarse a importar resultados; §104 lo incorpora completo al alcance. | Alcance completo SUE-001 a SUE-014 en O9; CU-28 se mantiene como alternativa (O8), según DEC-058. |"))

# CTR nueva
P.append(("| BASE SUE-009 + PA-SUE-05 |\n", "| BASE SUE-009 + PA-SUE-05 |\n| CTR-SUE-29 | `employers` de este anexo vs DEC-064 y T04 `legalEntities` | Dos registros de la misma persona jurídica (empresa empleadora y entidad emisora). | El empleador es la entidad jurídica: subdocumento `employer` de `legalEntities` (T04), `legalEntityId` en legajos, períodos, liquidaciones, recibos, presentaciones y pagos; tablas legales de §7.45 en T04 §7.17. | DEC-064; CTR-DAT-06; CTR-DAT-73 |\n"))
apply('M16', P, 'f2-g6-m16')
