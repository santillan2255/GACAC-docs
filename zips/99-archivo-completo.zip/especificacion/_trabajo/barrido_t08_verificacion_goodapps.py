# -*- coding: utf-8 -*-
"""T08: sustitución stack solo en columna de verificación (RF criterio / RNF criterio verificable)."""
from __future__ import annotations

import re
from pathlib import Path

T08 = Path(__file__).resolve().parents[1] / "anexos" / "T08-NFR-no-funcionales-seguridad.md"

NOTE_T08 = (
    "> **Barrido T08 verificación (19-11-2026, DEC-111).** En tablas RF-NFR/RNF-NFR, la columna "
    "**criterio de aceptación / criterio verificable** usa mecanismos **Azure SQL, EF Core, .NET y CI** "
    "equivalentes al texto histórico Connectia; las columnas *Requisito* y *Métrica* no se reinterpretan.\n\n"
)

ROW_RF = re.compile(r"^\| RF-NFR-\d+ \|")
ROW_RNF = re.compile(r"^\| RNF-NFR-\d+ \|")

VERIFY_REPLACEMENTS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"\bprofiler de Mongo\b", re.I), "Query Store / planes EF Core en Azure SQL"),
    (re.compile(r"\bMongoDB\b"), "Azure SQL"),
    (re.compile(r"\bMongo\b"), "Azure SQL"),
    (re.compile(r"\bMongoose\b"), "EF Core"),
    (re.compile(r"\bCOLLSCAN\b"), "table scan sin índice"),
    (re.compile(r"`explain` sin `COLLSCAN`"), "plan SQL/EF sin table scan"),
    (re.compile(r"`plan de ejecución \(EF/SQL\)` sin `table scan sin índice`"), "plan SQL/EF sin table scan"),
    (re.compile(r"\*\.int\.test\.js"), "tests con Category=Integration"),
    (re.compile(r"`dependency-cruiser`"), "NetArchTest / análisis de referencias"),
    (re.compile(r"\bBullMQ\b"), "colas Azure"),
    (re.compile(r"\bRedis\b"), "Azure Cache / cola"),
    (re.compile(r"kill -9 al worker", re.I), "detener la instancia del worker .NET"),
    (re.compile(r"\bnpm\b"), "dotnet test / pipeline CI"),
    (re.compile(r"\bSupertest\b"), "WebApplicationFactory"),
    (re.compile(r"\bnode --test\b"), "dotnet test --filter Category=Unit"),
    (re.compile(r"\bVitest\b"), "xUnit o Vitest (React)"),
    (re.compile(r"URI de Mongo/Redis"), "cadena de conexión SQL/Azure sin TLS en producción"),
    (re.compile(r"\bMongo/Redis\b"), "Azure SQL / cola"),
    (re.compile(r"replica set", re.I), "Azure SQL (geo-replicación o PITR)"),
    (re.compile(r"\boplog\b", re.I), "registro de transacciones / PITR"),
    (re.compile(r"writeConcern: majority", re.I), "transacción SQL confirmada (COMMIT)"),
    (re.compile(r"lint de rutas", re.I), "análisis estático en CI"),
    (re.compile(r"readPreference: secondaryPreferred", re.I), "réplica de lectura Azure SQL"),
    (re.compile(r"método de Mongoose", re.I), "método de DbContext/EF"),
    (re.compile(r"inyección NoSQL", re.I), "inyección SQL/NoSQL"),
    (re.compile(r"payloads.*\$ne", re.I), "payloads de inyección parametrizados (OWASP)"),
    (re.compile(r"javascriptEnabled: false", re.I), "sin SQL dinámico ni procedimientos inseguros"),
    (re.compile(r"usuarios de base por componente", re.I), "identidades SQL por componente con mínimo privilegio"),
    (re.compile(r"colecciones de negocio", re.I), "tablas de negocio"),
    (re.compile(r"inserción en `auditLogs`", re.I), "inserción en `pla.AuditLogs`"),
    (re.compile(r"traceparent.*BullMQ", re.I), "traceparent en colas Azure"),
    (re.compile(r"jobs BullMQ", re.I), "jobs en worker .NET"),
    (re.compile(r"en los datos del job", re.I), "en el payload del mensaje de cola"),
    (re.compile(r"vacuar Redis", re.I), "vaciar la cola de desarrollo"),
    (re.compile(r"reencolando desde Mongo", re.I), "reencolando desde tablas de jobs en SQL"),
    (re.compile(r"profiler de staging", re.I), "telemetría SQL en staging"),
]


def transform_verify(text: str) -> str:
    out = text
    for pat, repl in VERIFY_REPLACEMENTS:
        out = pat.sub(repl, out)
    return out


def patch_row(line: str) -> str:
    if not line.strip().startswith("|") or line.strip().startswith("|---"):
        return line
    parts = line.split("|")
    if len(parts) < 4:
        return line
    rid = parts[1].strip()
    if ROW_RF.match(line):
        if len(parts) < 9:
            return line
        col = transform_verify(parts[-2])
        parts[-2] = col
        return "|".join(parts)
    if ROW_RNF.match(line):
        if len(parts) < 10:
            return line
        parts[4] = transform_verify(parts[4])
        return "|".join(parts)
    return line


def insert_note(content: str) -> str:
    if "Barrido T08 verificación" in content:
        return content
    anchor = "## 5. Requisitos funcionales de soporte"
    if anchor not in content:
        return content
    return content.replace(
        anchor + " y mapa de requisitos no funcionales\n\n",
        anchor + " y mapa de requisitos no funcionales\n\n" + NOTE_T08,
        1,
    )


def main() -> None:
    raw = T08.read_text(encoding="utf-8")
    lines = [patch_row(ln) for ln in raw.splitlines(keepends=True)]
    new = "".join(lines)
    new = insert_note(new)
    if new != raw:
        T08.write_text(new, encoding="utf-8", newline="\n")
    n_rf = sum(1 for ln in new.splitlines() if ROW_RF.match(ln))
    n_rnf = sum(1 for ln in new.splitlines() if ROW_RNF.match(ln))
    print(f"T08 OK: {n_rf} RF-NFR rows, {n_rnf} RNF-NFR rows (verificación).")


if __name__ == "__main__":
    main()