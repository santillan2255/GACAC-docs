# -*- coding: utf-8 -*-
"""Correcciones T09 (parte 3): tablas existentes de §7 (cat. 3/4), estados §8 (cat. 5), PAN §10.3 (cat. 8),
servicio interno com.notify §11.7, consumos para T11 §12.2 (cat. 7)."""
import sys
sys.stdout.reconfigure(encoding='utf-8')
P = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T09-COM-comunidad-comunicaciones.md'
t = open(P, 'rb').read().decode('utf-8')


def rep(old, new, cnt=1):
    global t
    n = t.count(old)
    assert n == cnt, (n, old[:140])
    t = t.replace(old, new)


# ---------- §7.0 nota ----------
rep('- El tenant `PLATFORM` usa las mismas colecciones para los avisos de plataforma (`platformNotices`).',
    '- El tenant `PLATFORM` usa las mismas colecciones para los avisos de plataforma (`platformNotices`).\n'
    '- Cada ficha indica su COL-ID de T05. Las fichas que antes estaban solo en prosa tienen tabla de campos con columna **Referencia** (colección destino, COL-ID y anexo dueño). En esas tablas, “Oblig.” se dedujo de los únicos de T05, de los índices y del flujo; “Sistema” = lo completa el motor. Cuando T05 usa otro nombre para el mismo campo, prevalece T05 y la fila dice “antes `x`”.')

# ---------- posts ----------
rep('| `authorUserId`, `authorDisplay` | ObjectId; { `kind`: `institution`/`person`, `name` } | Sí | Autor real y autor visible. |',
    '| `authorUserId`, `authorDisplay` | ObjectId; { `kind`: `institution`/`person`, `name` } | Sí | Autor real (→ `memberships`, COL-IAM-04, T02) y autor visible (`authorDisplay` no es referencia: objeto de presentación). |')
rep('| `approval` | { `required`, `requestedAt`, `requestedBy`, `wflRequestId`, `decision` (`approved`/`rejected`), `decidedBy`, `decidedAt`, `note` } | No | RF-COM-007. |',
    '| `approval` | { `required`, `requestedAt`, `requestedBy`, `wflRequestId`, `decision` (`approved`/`rejected`), `decidedBy`, `decidedAt`, `note` } | No | RF-COM-007. `wflRequestId` → `approvalRequests` (COL-WFL-24, T11). |')
rep('| `audienceSnapshotId` | ObjectId | Sistema | Al publicar. |\n| `notify`',
    '| `audienceSnapshotId` | ObjectId | Sistema | Al publicar. → `audienceSnapshots` (COL-COM-33). |\n'
    '| `audienceSegmentId` | ObjectId | No | Segmento guardado usado como audiencia → `audienceSegments` (COL-COM-30). Según T05. |\n'
    '| `slug` | String | Sí al publicar en `landing` | Identificador legible único por tenant para la ruta pública `/posts/:slug` (API-COM-112). Según T05. |\n| `notify`')
rep('**`posts`** — publicaciones (CNX §5.2 `Post` adaptado).', '**`posts`** (COL-COM-01) — publicaciones (CNX §5.2 `Post` adaptado).')
rep('único parcial `{tenantId, greeting.runKey}`; texto `{tenantId, title, bodyText}`.',
    'único parcial `{tenantId, greeting.runKey}`; único parcial `{tenantId, slug}` (T05); texto `{tenantId, title, bodyText}`.')

# ---------- comments ----------
rep('**`comments`**\n', '**`comments`** (COL-COM-09)\n')
rep('| `mentions[]` | ObjectId[] (userId) | No | ≤10 (RN-COM-011). |',
    '| `mentions[]` | ObjectId[] (userId) | No | ≤10 (RN-COM-011). → `memberships` (COL-IAM-04, T02). |')
rep('| `authorUserId`, `authorPersonId` | ObjectId | Sí / No | |',
    '| `authorUserId`, `authorPersonId` | ObjectId | Sí / No | → `memberships` (COL-IAM-04, T02) / `persons` (COL-PER-01, M01). |')

# ---------- moderationCases ----------
rep('**`moderationCases`**\n', '**`moderationCases`** (COL-COM-12)\n')
rep('| `subjectType` | enum `comment`, `comment_image` | Sí | |\n| `subjectId`, `postId`, `authorUserId` | ObjectId | Sí | |',
    '| `targetRef` | { `type` (`comment`, `comment_image`), `id` } | Sí | Sujeto del caso → `comments` (COL-COM-09). Antes `subjectType` + `subjectId`; nombre según T05. |\n'
    '| `postId`, `authorUserId` | ObjectId | Sí | → `posts` (COL-COM-01) / `memberships` (COL-IAM-04, T02). |')
rep('| `crmCaseId`, `sanctionId`, `evidenceRemovalWflId` | ObjectId | No | |',
    '| `crmCaseId`, `sanctionId`, `evidenceRemovalWflId` | ObjectId | No | → `crmCases` (COL-CRM-01, M09) / `communitySanctions` (COL-COM-14) / `approvalRequests` (COL-WFL-24, T11). |')
rep('`{tenantId, subjectType, subjectId}` único parcial con `status ≠ closed`',
    '`{tenantId, targetRef.type, targetRef.id}` único parcial con `status ≠ closed` (antes `subjectType`, `subjectId`)')

# ---------- surveys ----------
rep('**`surveys`** (CNX §7.3 `Survey` + extensiones de la cooperativa)', '**`surveys`** (COL-COM-20) (CNX §7.3 `Survey` + extensiones de la cooperativa)')
rep('| `kind` | enum `survey`, `poll`, `consultation`, `field_form` | Sí | RF-COM-088, 089, 092. |',
    '| `code` | String | Sí | Código único por tenant (según T05). |\n| `kind` | enum `survey`, `poll`, `consultation`, `field_form` | Sí | RF-COM-088, 089, 092. |')
rep('| `languages[]`, `defaultLanguage`, `webhookConnectorId`, `templateId`, `categoryId`, `tags[]`, `estimatedMinutes` | | No | |',
    '| `languages[]`, `defaultLanguage`, `webhookConnectorId`, `templateId`, `categoryId`, `tags[]`, `estimatedMinutes` | String[], String, ObjectId, ObjectId, ObjectId, String[], Int | No | `webhookConnectorId` → `integrationConnections` (COL-INT-02, T06); `templateId` → `surveyTemplates` (COL-COM-23); `categoryId` → `surveyCategories` (COL-COM-24) [VERIFICAR: el ER lo dibuja hacia `serviceCategories` de M02]. |')
rep('| `audienceSnapshotId` | ObjectId | Sistema | |\n| `startsAt`, `endsAt`, `timezone`',
    '| `audienceSnapshotId` | ObjectId | Sistema | → `audienceSnapshots` (COL-COM-33). |\n| `startsAt`, `endsAt`, `timezone`')

# ---------- communicationTypes ----------
rep('**`communicationTypes`** (catálogo,', '**`communicationTypes`** (COL-COM-35) (catálogo,')
rep('| `platformTypeId`, `overridden` | ObjectId, Bool | No | Herencia. |',
    '| `platformTypeId`, `overridden` | ObjectId, Bool | No | Herencia: `platformTypeId` → `communicationTypes` (COL-COM-35, fila del tenant `PLATFORM`); `overridden` no es referencia. |')

# ---------- communications ----------
rep('**`communications`** — un envío', '**`communications`** (COL-COM-39) — un envío')
rep("| `origin` | { `kind` (`event`, `command`, `campaign`, `newsletter`, `manual`, `survey`, `system`), `eventId`, `eventName`, `module`, `businessRef` { `type`, `id` } (ej. `invoice`, `noticeId`), `campaignId`, `requestedBy` } | Sí | |",
    "| `origin` | { `kind` (`event`, `command`, `campaign`, `newsletter`, `manual`, `survey`, `system`), `eventId`, `eventName`, `module`, `campaignId`, `requestedBy` } | Sí | `campaignId` → `campaigns` (COL-COM-47). |\n"
    "| `sourceRef` | { `type`, `id` } (ej. `invoice`, `noticeId`) | Sí | Objeto de negocio que origina la comunicación. Antes `origin.businessRef`; nombre según T05. En el comando (API-COM-75, `com.notify`) y en los eventos el parámetro se sigue llamando `businessRef`. Referencia polimórfica al objeto del módulo emisor. |\n"
    "| `personId` | ObjectId | Sí si el destinatario es persona | Copia indexable de `recipient.personId` → `persons` (COL-PER-01, M01). Según T05. |")
rep('| `providerConnectorId`, `providerMessageId` | | No | |',
    '| `providerConnectorId`, `providerMessageId` | ObjectId, String | No | `providerConnectorId` → `integrationConnections` (COL-INT-02, T06); `providerMessageId` es identificador externo del proveedor. |')
rep('| `priority`, `scheduledFor`, `expiresAt` | | Sí | |', '| `priority`, `scheduledFor`, `expiresAt` | enum (igual que el tipo), Date, Date | Sí | |')
rep('| `proofDocumentRef` | objeto privado (PDF de constancia) | No | |',
    '| `proofDocumentRef` | objeto privado (PDF de constancia) | No | → `documents` (COL-WFL-34, T11). |')
rep('`{tenantId, recipient.personId, createdAt}`; `{tenantId, recipient.accountId, createdAt}`; `{tenantId, origin.businessRef.type, origin.businessRef.id}`',
    '`{tenantId, personId, createdAt}` (antes `recipient.personId`); `{tenantId, recipient.accountId, createdAt}`; `{tenantId, sourceRef.type, sourceRef.id}` (antes `origin.businessRef`)')

# ---------- campaigns ----------
rep('**`campaigns`**\n', '**`campaigns`** (COL-COM-47)\n')
rep('| `name`, `description` | String | Sí | |\n| `purpose` | enum `community`, `marketing`, `operational`, `service_outage` | Sí | |',
    '| `code` | String | Sí | Código único por tenant (según T05). |\n| `name`, `description` | String | Sí | |\n| `purpose` | enum `community`, `marketing`, `operational`, `service_outage` | Sí | |')
rep('| `approval` | { `required`, `reasons[]` (`purpose`, `size`, `cost`), `wflRequestId`, `decidedBy`, `decidedAt`, `note` } | No | |',
    '| `approval` | { `required`, `reasons[]` (`purpose`, `size`, `cost`), `wflRequestId`, `decidedBy`, `decidedAt`, `note` } | No | `wflRequestId` → `approvalRequests` (COL-WFL-24, T11). |')
rep('| `audienceSnapshotId` | ObjectId | Sistema | |\n| `metrics`',
    '| `audienceSnapshotId` | ObjectId | Sistema | → `audienceSnapshots` (COL-COM-33). |\n| `metrics`')

# ---------- outageNotices ----------
rep('**`outageNotices`** (RF-COM-160)', '**`outageNotices`** (COL-COM-56) (RF-COM-160)')
rep('| `kind` | enum `scheduled`, `unscheduled` | Sí | |\n| `serviceIds[]` | ObjectId[] | Sí | |',
    '| `number` | String | Sistema | Número correlativo del aviso por tenant (según T05; numeración de T11). |\n'
    '| `kind` | enum `scheduled`, `unscheduled` | Sí | |\n'
    '| `serviceIds[]` | ObjectId[] | Sí | → `tenantServices` (COL-CAT-02, M02). T05 declara `serviceId` (singular); un corte puede afectar varios servicios de la misma red, por lo que se conserva la lista y se informa para corregir T05 [VERIFICAR]. |\n'
    '| `zoneIds[]` | ObjectId[] | No | Zonas afectadas → `zones` (COL-CFG-16, T04). Antes `area.zoneIds[]`; nombre y ubicación según T05. |')
rep("| `area` | { `zoneIds[]`, `localityIds[]`, `streetSegments[]`", "| `area` | { `localityIds[]`, `streetSegments[]`")
rep('| `postId`, `audienceSnapshotId` | ObjectId | Sistema | |\n| `notifyChannels[]`',
    '| `postId`, `audienceSnapshotId` | ObjectId | Sistema | → `posts` (COL-COM-01) / `audienceSnapshots` (COL-COM-33). |\n| `notifyChannels[]`')
rep('| `minNoticeHoursApplied`, `lateNoticeAcknowledgedBy` | Int, ObjectId | No | RF-COM-162. |',
    '| `minNoticeHoursApplied`, `lateNoticeAcknowledgedBy` | Int, ObjectId | No | RF-COM-162. `minNoticeHoursApplied` no es referencia (horas aplicadas de PRM-COM-060); `lateNoticeAcknowledgedBy` → `memberships` (COL-IAM-04, T02). |')
rep('| `rescheduledFromId` | ObjectId | No | |', '| `rescheduledFromId` | ObjectId | No | Aviso original reprogramado → `outageNotices` (COL-COM-56). |')

# ---------- otros textos con nombres de T05 ----------
rep('entonces `surveyResponses.userId` y `personId` son nulos y solo existe `respondentHash`',
    'entonces `surveyResponses.userId` y `personId` son nulos y solo existe `respondentKey` (antes `respondentHash`)')
rep('`NOMBRE`/`RUTA` → `path` según tabla de equivalencias', '`NOMBRE`/`RUTA` → `key` (antes `path`) según tabla de equivalencias')
rep('`TIPO`/`MODULO`/`DESTINO` → `communicationTypeCode` y canal (mail/SMS/WhatsApp/reporte)',
    '`TIPO`/`MODULO`/`DESTINO` → `communicationTypeId` (antes `communicationTypeCode`) y canal (mail/SMS/WhatsApp/reporte)')

# ---------- §8: resumen de máquinas de estado ----------
rep('Formato AGR-003: origen → destino | actor | precondición | efectos | reversión.\n',
    'Formato AGR-003: origen → destino | actor | precondición | efectos | reversión. Las precondiciones citan la RN que actúa como guarda y los efectos el evento EVT que se emite.\n\n'
    '### 8.0 Resumen de campos de estado\n\n'
    'Todo campo de estado de §7 figura aquí con sus valores, su estado inicial y la sección de transiciones. Los valores coinciden con §7.\n\n'
    '| Colección.campo | Valores | Estado inicial | Transiciones |\n'
    '|---|---|---|---|\n'
    '| `posts.status` | `draft`, `pending_review`, `scheduled`, `published`, `rejected`, `archived` | `draft` | §8.1 |\n'
    '| `comments.status` | `pending_review`, `visible`, `hidden`, `rejected`, `deleted_by_author`, `removed` | `pending_review`, `visible` o `rejected` según moderación (RN-COM-002) | §8.2 |\n'
    '| `moderationCases.status` | `open`, `assigned`, `decided`, `escalated`, `appealed`, `closed` | `open` | §8.3 |\n'
    '| `contentReports.status` | `open`, `upheld`, `dismissed` | `open` | §8.3.1 |\n'
    '| `communitySanctions.status` | `active`, `expired`, `revoked`, `appeal_pending`, `appeal_upheld`, `appeal_revoked` | `active` | §8.4 |\n'
    '| `communityGuidelines.status` | `draft`, `published`, `retired` | `draft` | §8.4.1 |\n'
    '| `surveys.status` | `draft`, `published`, `paused`, `closed`, `archived` | `draft` | §8.5 |\n'
    '| `surveyInvitations.status` | `created`, `delivered`, `opened`, `responded`, `expired`, `cancelled` | `created` | §8.5 |\n'
    '| `surveyResponses.status` | `draft`, `submitted`, `invalidated` | `draft` | §8.5 |\n'
    '| `newsletters.status` | `pending_review`, `approved`, `sending`, `sent`, `rejected`, `cancelled` | `pending_review` (o `approved` si `requireReview=false`) | §8.6 |\n'
    '| `events.status` | `draft`, `published`, `cancelled`, `finished` | `draft` | §8.7 |\n'
    '| `eventRegistrations.status` | `registered`, `pending_approval`, `waitlisted`, `cancelled`, `rejected`, `checked_in`, `no_show` | `registered`, `waitlisted` o `pending_approval` según cupo y modo | §8.7 |\n'
    '| `benefits.status` | `draft`, `published`, `paused`, `expired`, `cancelled` | `draft` | §8.8 |\n'
    '| `benefitRedemptions.status` | `issued`, `redeemed`, `expired`, `cancelled` | `issued` | §8.8 |\n'
    '| `audienceImportLists.status` | `uploaded`, `validated`, `confirmed`, `discarded` | `uploaded` | §8.8.1 |\n'
    '| `audienceImportRows.matchStatus` | `matched`, `unmatched`, `ambiguous`, `duplicate` | Resultado del cruce (sin transiciones: se recalcula al revalidar la lista) | §8.8.1 |\n'
    '| `communicationTypes.status` | `active`, `inactive` | `active` | §8.9.1 |\n'
    '| `messageTemplates.status` | `active`, `retired` | `active` | §8.9.1 |\n'
    '| `messageTemplateVersions.status` | `draft`, `published`, `retired` | `draft` | §8.9 |\n'
    '| `messageTemplates.whatsapp.approvalStatus` | `draft`, `submitted`, `approved`, `rejected`, `paused`, `disabled` | `draft` | §8.9 (lo fija el proveedor) |\n'
    '| `senderIdentities.verificationStatus` | `pending`, `verified`, `failed` | `pending` | §8.9.1 |\n'
    '| `communications.status` | §8.10 | `created` (o `suppressed`/`undeliverable` si no hay canal) | §8.10 |\n'
    '| `campaigns.status` | `draft`, `pending_approval`, `approved`, `scheduled`, `sending`, `paused`, `completed`, `cancelled`, `failed` | `draft` | §8.11 |\n'
    '| `invoiceMessages.status` | `draft`, `approved`, `active`, `expired`, `cancelled` | `draft` | §8.11.1 |\n'
    '| `outageNotices.status` | `draft`, `published`, `in_progress`, `restored`, `cancelled`, `rescheduled` | `draft` | §8.12 |\n'
    '| `suppressionEntries.status` | `active`, `lifted` | `active` | §8.13 |\n'
    '| `pushSubscriptions.status` | `active`, `expired` | `active` | §8.13.1 |\n'
    '| `platformNotices.status` | `draft`, `published`, `expired`, `withdrawn` [VERIFICAR: §7.10 declaraba `status` sin valores; se proponen estos] | `draft` | §8.13.1 |\n')

# 8.3.1 denuncias
rep('### 8.4 Sanción (`communitySanctions.status`)\n',
    '#### 8.3.1 Denuncia (`contentReports.status`)\n\n'
    '| Origen → Destino | Actor | Precondición | Efectos | Reversión |\n|---|---|---|---|---|\n'
    '| — → `open` | Socio/empleado (`com.reports.crear`) | Una denuncia por usuario y comentario; el autor no cuenta (RN-COM-005) | Se vincula al caso abierto o crea uno (`com.report.created`, EVT-COM-09) | — |\n'
    '| `open` → `upheld` | Moderador (`com.reports.resolver`) | Caso decidido con acción `hide`/`hide_and_reply`/`derive_crm` | Aviso al denunciante (`com.report.resolved`, EVT-COM-10) | — |\n'
    '| `open` → `dismissed` | Moderador (`com.reports.resolver`) | Caso decidido con acción `approve`/`ignore_ai` | Aviso al denunciante (`com.report.resolved`, EVT-COM-10) | — |\n\n'
    '### 8.4 Sanción (`communitySanctions.status`)\n')
rep('| `appeal_pending` → `appeal_upheld` / `appeal_revoked` | Revisor distinto del que sancionó | — | Revocada: rehabilita y borra la infracción del cómputo de reincidencia; se avisa | — |',
    '| `appeal_pending` → `appeal_upheld` / `appeal_revoked` | Revisor distinto del que sancionó | — | Revocada: rehabilita y borra la infracción del cómputo de reincidencia; se avisa | — |\n'
    '| `active` → `revoked` | Responsable de comunidad (`com.sanctions.revocar`) | Motivo obligatorio (`revokeReason`) | Rehabilita; `com.sanction.revoked` (EVT-COM-11) | — |\n\n'
    'Una apelación `reduced` (§7.2, `appeal.decision`) deja la sanción en `appeal_upheld` con `endsAt` acortado.\n\n'
    '#### 8.4.1 Reglas de comunidad (`communityGuidelines.status`)\n\n'
    '| Origen → Destino | Actor | Precondición | Efectos | Reversión |\n|---|---|---|---|---|\n'
    '| — → `draft` | Responsable de comunidad (`com.moderation.configurar`) | — | — | — |\n'
    '| `draft` → `published` | Responsable de comunidad | Versión semver mayor que la vigente | La anterior pasa a `retired`; si PRM-COM-002 = true, se exige nueva aceptación (`guidelineAcceptances`) | — |\n'
    '| `published` → `retired` | Sistema | Otra versión publicada | Deja de mostrarse | — |\n')

# 8.7 inscripciones faltantes
rep('| `registered` → `checked_in` | Gestor/validador | QR válido, día del evento | — | Deshacer check-in el mismo día |',
    '| `registered` → `checked_in` | Gestor/validador | QR válido, día del evento | — | Deshacer check-in el mismo día |\n'
    '| `pending_approval` → `registered` / `waitlisted` | Gestor (`com.events.gestionar`) | Modo `approval`; cupo | Aviso `com.event.registrationChanged` (EVT-COM-17) | — |\n'
    '| `pending_approval` → `rejected` | Gestor (`com.events.gestionar`) | Motivo | Aviso al socio (EVT-COM-17) | — |\n'
    '| `registered`/`waitlisted`/`pending_approval` → `cancelled` | Socio / sistema (evento cancelado) | Antes del inicio | Libera lugar (RN-COM-052); EVT-COM-17 | — |\n'
    '| `registered` → `no_show` | JOB-COM-09 | Evento `finished` sin check-in | Métrica de asistencia (EVT-COM-19) | — |')

# 8.8 separar beneficio y canje
rep('Beneficio: `draft` → `published` → `paused` ↔ `published`;',
    'Los estados `issued` y `redeemed` son del canje (`benefitRedemptions`), no del beneficio (`benefits`).\n\n'
    'Beneficio (`benefits.status`): `draft` → `published` → `paused` ↔ `published`;')
rep('(vuelve a `issued` si el beneficio sigue vigente).\n',
    '(vuelve a `issued` si el beneficio sigue vigente).\n\n'
    '| Colección | Origen → Destino | Actor | Precondición | Efectos | Reversión |\n|---|---|---|---|---|---|\n'
    '| `benefits` | — → `draft` | Gestor (`com.benefits.gestionar`) | — | — | — |\n'
    '| `benefits` | `draft`/`paused` → `published` | Gestor | Vigencia y comercio activos | Visible a la audiencia elegible | `published` → `paused` |\n'
    '| `benefits` | `published` → `expired` | JOB-COM-10 | `validTo` pasado o cupo total agotado | Códigos `issued` vencen | — |\n'
    '| `benefits` | cualquiera → `cancelled` | Gestor | Motivo | Códigos emitidos → `cancelled` y aviso | — |\n'
    '| `benefitRedemptions` | — → `issued` | Socio (`com.benefits.canjear`) | Elegible; cupo por persona y total | `com.benefit.redemptionIssued` (EVT-COM-20) | — |\n'
    '| `benefitRedemptions` | `issued` → `redeemed` | Validador (`com.benefits.validarCanje`) o link del comercio | Código válido y no usado (RN-COM-053) | `com.benefit.redeemed` (EVT-COM-21) | `redeemed` → `issued` solo gestor, con motivo, dentro de 24 h |\n'
    '| `benefitRedemptions` | `issued` → `expired` | JOB-COM-10 | `expiresAt` pasado | — | — |\n'
    '| `benefitRedemptions` | `issued` → `cancelled` | Socio o gestor | — | Libera cupo | — |\n\n'
    '#### 8.8.1 Lista importada de audiencia (`audienceImportLists.status`)\n\n'
    '| Origen → Destino | Actor | Precondición | Efectos | Reversión |\n|---|---|---|---|---|\n'
    '| — → `uploaded` | Operador (`com.audiences.usar`) | Archivo con columna de cruce `matchBy` | Filas en `audienceImportRows` | — |\n'
    '| `uploaded` → `validated` | Sistema | Cruce terminado | Conteos `rowsMatched`/`rowsUnmatched`; cada fila con `matchStatus` | `validated` → `uploaded` al recargar el archivo |\n'
    '| `validated` → `confirmed` | Operador | Revisión de no cruzadas y ambiguas | Usable en `AudienceDefinition.importListIds` | — |\n'
    '| `uploaded`/`validated` → `discarded` | Operador | — | Filas purgadas por JOB de retención | — |\n')

# 8.9.1 catálogo, plantillas, remitentes
rep('### 8.10 Comunicación (`communications.status`) — AGR-024\n',
    '#### 8.9.1 Tipo de comunicación, plantilla y remitente\n\n'
    '| Colección | Origen → Destino | Actor | Precondición | Efectos | Reversión |\n|---|---|---|---|---|---|\n'
    '| `communicationTypes` | `active` → `inactive` | Administrador de plantillas (`com.catalog.configurar`) | `optOut ≠ never` y finalidad distinta de `security`/`regulatory` | El motor deja de generar comunicaciones del tipo | `inactive` → `active` |\n'
    '| `messageTemplates` | `active` → `retired` | Administrador de plantillas (`com.templates.editar`) | El tipo tiene otra plantilla activa para el canal y el idioma | No se usa en nuevas comunicaciones | `retired` → `active` |\n'
    '| `senderIdentities` | — → `pending` | Administrador de canales (`com.channels.configurar`) | — | Verificación por T06 (dominio, número o alfanumérico) | — |\n'
    '| `senderIdentities` | `pending` → `verified` / `failed` | Sistema (T06) | Resultado del proveedor | Solo `verified` se usa para enviar (RN-COM-020) | `failed` → `pending` (reintentar) |\n\n'
    '### 8.10 Comunicación (`communications.status`) — AGR-024\n')

# 8.11.1 mensajes en factura
rep('### 8.12 Aviso de interrupción (`outageNotices.status`)\n',
    '#### 8.11.1 Mensaje en factura (`invoiceMessages.status`)\n\n'
    '| Origen → Destino | Actor | Precondición | Efectos | Reversión |\n|---|---|---|---|---|\n'
    '| — → `draft` | Operador (`com.invoiceMessages.crear`) | Texto ≤ PRM-COM-047 por área | — | — |\n'
    '| `draft` → `approved` | Aprobador (`com.invoiceMessages.aprobar`) | Distinto del creador | — | → `draft` |\n'
    '| `approved` → `active` | Sistema | Llega `validFrom` o el período de facturación | `com.invoiceMessage.activated` (EVT-COM-39) | — |\n'
    '| `active` → `expired` | Sistema | Pasa `validTo` o el último período | `com.invoiceMessage.expired` (EVT-COM-39) | — |\n'
    '| `draft`/`approved`/`active` → `cancelled` | Aprobador | Motivo | Deja de resolverse en M05 (EVT-COM-39) | — |\n\n'
    '### 8.12 Aviso de interrupción (`outageNotices.status`)\n')

# 8.13.1 push y avisos de plataforma
rep('`purged` por JOB-COM-18 al vencer `validUntil` (salvo `actionPending`).\n',
    '`purged` por JOB-COM-18 al vencer `validUntil` (salvo `actionPending`).\n\n'
    '#### 8.13.1 Suscripción push y aviso de plataforma\n\n'
    '| Colección | Origen → Destino | Actor | Precondición | Efectos | Reversión |\n|---|---|---|---|---|---|\n'
    '| `pushSubscriptions` | — → `active` | Usuario (API-COM-104) | Permiso del navegador | — | — |\n'
    '| `pushSubscriptions` | `active` → `expired` | Sistema | Respuesta 404/410 del servicio push o baja del usuario | No se usa más (RF-COM-137) | Nueva suscripción |\n'
    '| `platformNotices` | — → `draft` | Plataforma (`pla.notices.publicar`) | — | — | — |\n'
    '| `platformNotices` | `draft` → `published` | Plataforma | `startsAt` alcanzado | `com.platformNotice.published` (EVT-COM-38) | → `withdrawn` |\n'
    '| `platformNotices` | `published` → `expired` | Sistema | `endsAt` o permanencia vencida | Sale de la campana | — |\n'
    '| `platformNotices` | `draft`/`published` → `withdrawn` | Plataforma | Motivo | Sale de la campana | — |\n')

# ---------- §10.3 correspondencia con T03 ----------
rep('Equivalencias PWA ProCoop: `Inicio_ProCoop` (panel de noticias y notificaciones) → PAN-COM-32/33; portal CoopOnline novedades (`WEB_NOVEDADES`) → PAN-COM-40/53; `NOTI_COOP` → PAN-COM-42.\n',
    'Equivalencias PWA ProCoop: `Inicio_ProCoop` (panel de noticias y notificaciones) → PAN-COM-32/33; portal CoopOnline novedades (`WEB_NOVEDADES`) → PAN-COM-40/53; `NOTI_COOP` → PAN-COM-42.\n\n'
    '### 10.3 Correspondencia con T03 (AL-01)\n\n'
    'T09 es la fuente de PAN-COM-01..34 y PAN-COM-40..53: el ID, la ruta y la capability de este anexo prevalecen y T03 §10.8/§10.9 debe alinearse. T03 usa una numeración propia que no coincide (cita PAN-COM-35..39, que T09 no define). Correspondencia para corregir T03:\n\n'
    '| ID citado en T03 | Ruta o capability en T03 | PAN de T09 | Ruta y capability canónicas (T09) |\n|---|---|---|---|\n'
    '| PAN-COM-28 | `/admin/avisos` | PAN-COM-32 | Campana + `/admin/avisos`, `com.inbox.ver` |\n'
    '| PAN-COM-10 | — | PAN-COM-08 | §10.1 |\n'
    '| PAN-COM-21 | `/admin/com/comunicaciones` | PAN-COM-24 | `/admin/com/historial`, `com.communications.ver` |\n'
    '| PAN-COM-17 | — | PAN-COM-21 | §10.1 |\n'
    '| PAN-COM-20 | — | PAN-COM-18 | §10.1 |\n'
    '| PAN-COM-11 | — | PAN-COM-10 | §10.1 |\n'
    '| PAN-COM-13 | — | PAN-COM-12 | §10.1 (capability `com.surveys.resultados`; T03 cita `com.surveys.crear` y ruta `modal`) |\n'
    '| PAN-COM-16 | `/admin/com/audiencias` | PAN-COM-17 | `/admin/com/segmentos` |\n'
    '| PAN-COM-23 | `/admin/com/interrupciones`, `com.outages.gestionar` | PAN-COM-27 | `/admin/com/avisos-corte`, `com.outages.ver` |\n'
    '| PAN-COM-22 | — | PAN-COM-26 | §10.1 |\n'
    '| PAN-COM-24 | `/admin/com/consentimientos` | PAN-COM-25 | `/admin/com/preferencias` |\n'
    '| PAN-COM-30 | `/app/muro` | PAN-COM-40 | `/app/muro`, `com.wall.ver` |\n'
    '| PAN-COM-31 | `/app/muro/:id` | PAN-COM-41 | `/app/muro/:id`, `com.wall.ver` |\n'
    '| PAN-COM-32 | `/app/guardados` | PAN-COM-40 | Vista “Guardados” dentro de `/app/muro` |\n'
    '| PAN-COM-34 | — | PAN-COM-44 | `/app/novedades(/:id)`, `com.wall.ver` |\n'
    '| PAN-COM-35, PAN-COM-36 | — (no definidos en T09) | PAN-COM-43 | `/app/encuestas(/:id)`, `com.surveys.responder` |\n'
    '| PAN-COM-33 | — | PAN-COM-42 | `/app/avisos`, `com.inbox.ver` |\n'
    '| PAN-COM-40 | Preferencias | PAN-COM-47 | `/app/perfil/comunicaciones`, `com.preferences.editar` |\n'
    '| PAN-COM-38 (SM-PWS-043) | `com.wall.ver` | PAN-COM-45 | `/app/agenda`, `com.events.ver` |\n'
    '| PAN-COM-39 (SM-PWS-044) | `com.wall.ver` | PAN-COM-46 | `/app/beneficios(/:id)`, `com.benefits.ver` |\n'
    '| PAN-COM-12 (SM-PWE-010) | modal | PAN-COM-52 | FAB del supervisor, `com.posts.publicarEquipo` / `com.surveys.rapidaEquipo` |\n'
    '| PAN-COM-43, PAN-COM-44 (landing) | — | PAN-COM-53 | `/noticias(/:slug)`, pública |\n'
    '| PAN-COM-37 (PAN-COM-37 de T03, no definido en T09) | — | PAN-COM-49 | `/e/:token`, pública (token) |\n'
    '| PAN-COM-45 | `/preferencias/:token` | PAN-COM-50 | `/comunicaciones/:token`, pública (token) |\n'
    '| PAN-COM-46 | `/admin/plataforma/avisos` | PAN-COM-33 | Ruta de §10.1 (`/admin/platform/avisos`) |\n'
    '| PAN-COM-47 | — | PAN-COM-34 | §10.1 |\n')
rep('| PAN-COM-51 | pwa | `/app/comunidad/reglas` | `com.wall.ver` |', '| PAN-COM-51 | pwa | `/app/comunidad/reglas` | `com.wall.ver` / `com.sanctions.apelar` |')

# ---------- §11.7 servicio interno com.notify ----------
rep('## 12. Eventos y jobs\n',
    '### 11.7 Servicios internos\n\n'
    'Servicios que otros módulos invocan en proceso (mismo monolito modular, DEC-003) en lugar de llamar a HTTP. Cada uno tiene su equivalente HTTP interno para procesos separados.\n\n'
    '#### `com.notify` — emitir comunicaciones (alias `com.services.notify`)\n\n'
    'Fachada del comando de envío API-COM-75 (`POST /api/internal/com/communications`, capability `com.communications.emit`). La citan T11 (INT-WFL-12/13, `com.notify()`) y T01 (`com.services.notify()`); ambos nombres refieren a este servicio. Es la única vía, junto con los eventos del catálogo §9.6, por la que un módulo pide un envío (RF-COM-181).\n\n'
    '```ts\n'
    'notify(ctx: ServiceContext, input: NotifyInput): Promise<NotifyResult>\n'
    '```\n\n'
    '| Parámetro | Tipo | Oblig. | Descripción |\n|---|---|---|---|\n'
    '| `ctx` | `ServiceContext` (T01) | Sí | `tenantId`, actor (usuario o cuenta técnica con `com.communications.emit`), `correlationId`, `environment`. |\n'
    '| `input.typeCode` | String | Sí | Código del tipo de §9.6 (`<modulo>.<entidad>.<hecho>`). |\n'
    '| `input.recipients[]` | [{ `personId`?, `accountId`?, `userId`?, `supplierId`?, `contactPointId`?, `role`? }] | Sí (≥1) | Destinatarios; la dirección se resuelve con `recipientRule` del tipo. |\n'
    '| `input.businessRef` | { `type`, `id` } | Sí | Objeto de negocio (se guarda como `communications.sourceRef`). |\n'
    '| `input.variables` | Objeto | Sí | Valores para las variables de la plantilla (validadas contra `templateVariables`). |\n'
    '| `input.channelsOverride[]` | enum[] de canal | No | Subconjunto de `allowedChannels` del tipo; nunca amplía. |\n'
    '| `input.attachments[]` | [{ `kind`, `documentId` \\| `objectKey`, `mode` (`attach`, `signed_link`) }] | No | Adjuntos por referencia (T11). |\n'
    '| `input.evidenceRequired` | Bool | No | Fuerza constancia PDF aunque el tipo no la exija. |\n'
    '| `input.requiredMilestone` | enum `accepted`, `delivered`, `read`, `physical_ack` | No | Sobrescribe el hito del tipo solo hacia uno más exigente. |\n'
    '| `input.scheduledFor` | Date | No | Envío diferido; respeta horario de no molestar salvo tipos exentos. |\n'
    '| `input.idempotencyKey` | String | Sí | Clave del emisor; misma clave = mismo resultado (RF-COM-145). |\n\n'
    '| Salida (`NotifyResult`) | Tipo | Descripción |\n|---|---|---|\n'
    '| `requestId` | String | Identificador del pedido (correlación). |\n'
    '| `communications[]` | [{ `communicationId`, `recipientIndex`, `channel`, `status` }] | Una por destinatario y canal; `status` inicial `created`, `queued`, `suppressed` o `undeliverable` (§8.10). |\n'
    '| `undeliverable[]` | [{ `recipientIndex`, `reason` (`no_contact`, `opt_out`, `suppressed`, `sanction`, `sensitive_filter`) }] | Destinatarios sin canal posible. |\n'
    '| `deduplicated` | Bool | `true` si la `idempotencyKey` ya existía (devuelve el resultado original). |\n\n'
    'Los cambios posteriores llegan por eventos (EVT-COM-27, EVT-COM-28 `com.communication.milestoneReached`, EVT-COM-29 `com.communication.allChannelsFailed`), no por la respuesta.\n\n'
    '| Error | HTTP equivalente | Cuándo |\n|---|---|---|\n'
    '| `COM_TYPE_NOT_FOUND` | 404 | `typeCode` inexistente en el tenant ni en plataforma. |\n'
    '| `COM_TYPE_INACTIVE` | 409 | Tipo `inactive` (§8.9.1). |\n'
    '| `COM_IDEMPOTENCY_REQUIRED` | 400 | Falta `idempotencyKey`. |\n'
    '| `COM_IDEMPOTENCY_CONFLICT` | 409 | Misma clave con otro contenido. |\n'
    '| `COM_NO_RECIPIENTS` | 422 | `recipients[]` vacío o sin datos resolubles. |\n'
    '| `COM_VARIABLE_MISSING` | 422 | Falta una variable con `nullPolicy=block_send`. |\n'
    '| `COM_CHANNEL_NOT_ALLOWED` | 422 | `channelsOverride` fuera de `allowedChannels`. |\n'
    '| `COM_FORBIDDEN` | 403 | El actor no tiene `com.communications.emit` o el tipo no pertenece a su módulo. |\n'
    '| `COM_TENANT_SUSPENDED` | 423 | Tenant suspendido y tipo no regulatorio (EVT-PLA-03). |\n\n'
    'Los errores siguen RFC 9457 en la vía HTTP. Un destinatario sin canal no es error: va en `undeliverable[]` y genera la acción de PRM-COM-023.\n\n'
    '## 12. Eventos y jobs\n')

# ---------- §12.2 nota para T11 ----------
rep('| `mor.notice.*` delivery manual (EVT-MOR-08) | M08 | Registra acuse físico (`physical_ack`). |\n',
    '| `mor.notice.*` delivery manual (EVT-MOR-08) | M08 | Registra acuse físico (`physical_ack`). |\n\n'
    'Consumos de T09 que la tabla de eventos de T11 todavía no registra (se informan para agregar T09 como consumidor en T11): EVT-COB-01, EVT-FAC-15, EVT-FIS-01, EVT-INS-18, EVT-INT-04, EVT-INT-23, EVT-MOR-08, EVT-PER-03, EVT-PER-06 y EVT-PER-18. A la inversa, M08 consume EVT-COM-29 `com.communication.allChannelsFailed` (P-COM-06 paso 11) y T11 no lo lista como consumidor.\n')

open(P, 'wb').write(t.encode('utf-8'))
print('ok', t.count('\n') + 1)
