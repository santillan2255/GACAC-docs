import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from repl import fpath
from conc_lib import read, write

p = fpath('T08')
L = read(p).split('\n')
assert not any(l.startswith('| CTR-NFR-22 ') for l in L)
i = [k for k, l in enumerate(L) if l.startswith('| CTR-NFR-21 ')][0]
L.insert(i + 1, '| CTR-NFR-22 | T08 15.1 (`tenantUsageSnapshots`, `processedEvents`, `restoreDrills`, `idempotencyKeys`, `alertRules`/`alertEvents`, `auditEvents`) vs. T01 y T02 (CTR-DAT-21 y CTR-DAT-24 de T05) | Colecciones técnicas definidas dos veces con nombres distintos. | Dueño T01: `usageSnapshots` (COL-PLA-09), `inboxReceipts` (COL-PLA-25), `restoreTests` (COL-PLA-20), `idempotencyKeys` (COL-PLA-28), `alertRules`/`alerts` (COL-PLA-15/16); `auditLogs` de T02; `locks` queda en T08. T08 conserva los requisitos y los campos que necesita; los nombres se corrigieron en el lugar. | Catálogo de datos (T05). |')
write(p, '\n'.join(L))
print('ok')
