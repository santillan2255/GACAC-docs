﻿from conc_lib import *
import re
for code, last in [('M05','EVT-FAC-20'),('M06','EVT-FIS-21'),('M07','EVT-COB-23'),('M10','EVT-TEC-31'),('M11','EVT-VEN-14'),('M12','EVT-CMP-14'),('M13','EVT-STK-22'),('M14','EVT-TES-22'),('M16','EVT-SUE-26'),('T01','EVT-PLA-20')]:
    f = [x for x in files() if os.path.basename(x).startswith(code+'-')][0]
    L = read(f).split('\n')
    idx = [i for i,l in enumerate(L) if re.match(r'^\|\s*`?%s`?\s*\|' % last, l)]
    for i in idx:
        j = i
        while not L[j].startswith('|---'): j -= 1
        print(code, i+1, 'HDR:', L[j-1])
        print('   LAST:', L[i][:200])
        print('   NEXT:', L[i+1][:120])
