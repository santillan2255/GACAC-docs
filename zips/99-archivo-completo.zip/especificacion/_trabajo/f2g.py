﻿import re,glob
for f in sorted(glob.glob('anexos/*.md')):
    s=open(f,encoding='utf-8').read()
    for c in ['planObra','revisionPrevia','cambiarRegimenMedicion','tec.onCall.manage','tec.phone.numbering','tec.waterQuality.manage','derechosSenales','tec.config.manage']:
        for l in s.split('\n'):
            if c in l: print(f[7:10],c,'|',l[:260]); break
