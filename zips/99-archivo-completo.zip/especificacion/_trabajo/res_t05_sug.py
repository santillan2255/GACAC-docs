import json, difflib, io, sys, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
d = json.load(open(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo\res_t05_solo.json", encoding="utf-8"))

def stem(s):
    return re.sub(r"(Ids|Id|Code|Ref|Refs|No|Number|Key|Name)$", "", s).lower()

for r in d:
    f = r["field"]
    a = r["anexo"]
    st = stem(f)
    c = [x for x in a if stem(x) == st or (len(st) > 3 and (stem(x).startswith(st) or st.startswith(stem(x)) and len(stem(x)) > 3))]
    if not c:
        c = difflib.get_close_matches(f, a, n=2, cutoff=0.6)
    print("%s|%s|%s|%s|%s|%d" % (r["owner"], r["id"], r["col"], f, ",".join(c), r["parsed"]))
