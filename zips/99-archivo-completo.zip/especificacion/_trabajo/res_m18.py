import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from res_lib_m12m19 import Doc

d = Doc('M18-SOC-servicios-sociales-flota.md')
PA = 'PA-SOC-19'


def _idx(after, field):
    ls = d.t.split('\n')
    st = [i for i, l in enumerate(ls) if after in l]
    assert st, ('ancla', after)
    for j in range(st[0], len(ls)):
        if ls[j].startswith('| `%s` |' % field):
            return ls, j
    raise AssertionError(('fila', after, field))


def add_after(after, field, rows, cat=4):
    ls, j = _idx(after, field)
    ls[j + 1:j + 1] = rows
    d.t = '\n'.join(ls)
    d.n += 1
    d.cats[cat] = d.cats.get(cat, 0) + len(rows)


def set_row(after, field, new_field=None, desc=None, ref=None, cat=2):
    ls, j = _idx(after, field)
    cells = ls[j].split(' | ')
    if new_field:
        cells[0] = '| `%s`' % new_field
    if desc is not None:
        cells[-2] = desc
    if ref is not None:
        cells[-1] = ref + ' |'
    ls[j] = ' | '.join(cells)
    d.t = '\n'.join(ls)
    d.n += 1
    d.cats[cat] = d.cats.get(cat, 0) + 1


# Cat 6
d.rep('`int.fleet.positions-received`', '`int.fleet.positionsReceived` (antes `int.fleet.positions-received`)', count=3, cat=6)

# Cat 2: referencias
set_row('#### `serviceDependents`', 'relationshipTypeId', ref='`enumerationItems` (T04) (vínculos, CTR-DAT-12; antes `[VERIFICAR]`)')
set_row('#### `serviceDependents`', 'assignedTariffId', ref='`tariffCategoryRates` (M04) (tarifa por categoría; antes `[VERIFICAR]`; ' + PA + ')')
set_row('Campos de `serviceBeneficiaries`', 'relationshipTypeId', ref='`enumerationItems` (T04) (vínculos `VINCULOS`, CTR-DAT-12; antes "M01, colección [VERIFICAR]")')
set_row('Campos de `dependentEvents`', 'batchId', desc='Lote de la operación masiva que generó el evento.', ref='— (identificador del lote que agrupa eventos de esta colección; no es referencia; antes `[VERIFICAR]`)')
set_row('**`housingPrices`**', 'batchId', desc='Lote de actualización de precios.', ref='— (identificador del lote que agrupa precios de esta colección; no es referencia; antes `[VERIFICAR]`)')
set_row('**`housingMaterialWithdrawals`**', 'voucherRef', ref='`voucherTypes` (M05) (solo `docTypeId`; `pointOfSale` y `number` son numeración)')
set_row('**`housingPlanChanges`**', 'templateId', ref='`documentTemplates` (T11) (antes `[VERIFICAR]`)')
set_row('**`housingTerminations`**', 'templateId', ref='`documentTemplates` (T11) (antes `[VERIFICAR]`)')
set_row('**`gpsDevices`**', 'externalUnitId', ref='— (identificador externo del proveedor GPS; no es referencia)')
set_row('**`gpsPositions`**', 'statusId', ref='— (código externo del proveedor GPS; no es referencia)')

# Cat 4: campos clave de T05
for anchor, after in [('Campos de `providerAgreements`', 'providerId'), ('**`cemeteryRegulations`**', 'documentId'),
                      ('**`vehicleDocuments`**', 'vehicleId')]:
    add_after(anchor, after, ['| `documentRefId` | ObjectId | [VERIFICAR] | Expediente documental en T11 (clave de T05; ' + PA + '). | `documents` (T11) |'])
set_row('**`housingContributions`**', 'invoiceRef', new_field='invoiceId',
        desc='Antes `invoiceRef` (nombre de T05; ' + PA + ').', cat=4)
for anchor, after in [('**`housingProgress`**', 'activityId'), ('**`housingCertificates`**', 'providerId'),
                      ('**`vehicleMaintenances`**', 'vehicleId')]:
    add_after(anchor, after, ['| `supplierId` | ObjectId | [VERIFICAR] | Proveedor de la obra o del servicio (clave de T05; ' + PA + '). | `suppliers` (M12) |'])
set_row('**`fuelTypes`**', 'vatRate', new_field='vatRateId',
        desc='Antes `vatRate` (Enum); referencia a la alícuota con el nombre de T05 (' + PA + '). Canónica; absorbe el tipo `fuel` de `purchaseLookups` de M12, CTR-DAT-54.',
        ref='`vatRates` (M06)', cat=4)
set_row('**`fuelLoads`**', 'purchaseInvoiceRef', new_field='supplierInvoiceId',
        desc='`ID_IVACOM`. Antes `purchaseInvoiceRef` → `invoices` (M05); la factura de combustible es de compra (nombre de T05; ' + PA + ').',
        ref='`supplierInvoices` (M12)', cat=4)
add_after('**`gpsPositions`**', 'statusId',
          ['| `meta` | Object | Sí | `{ tenantId, vehicleId }`: metaField de la serie temporal (claves de T05; ' + PA + '). | `fleetVehicles` (M18) (solo `meta.vehicleId`) |'])

# Cat 1: estados
d.rep('## 9. Procesos y flujos\n\n### 9.1 Alta y mantenimiento del grupo',
      '''### 8.2 Estados iniciales, máquinas faltantes y estados sin origen (corrección 05-11-2026)

Corrección del 05-11-2026 (%s): la tabla general del §8 no declara el estado inicial de sus máquinas, deja sin origen `extinguished` (derecho de sepultura), `cancelled` (acto de cementerio), `transferred` (vivienda) y `retired` (vehículo), y el §7 enumera valores sin transiciones para siete colecciones. Esta tabla lo explicita sin cambiar la tabla general. Estado inicial: ver las filas `(alta)`.

| Colección | Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |
|---|---|---|---|---|---|
| `serviceDependents` | (alta) | `pendingValidation` | Alta del adherente | — | — |
| `serviceBeneficiaries` | (alta) | `active` | Alta del beneficiario | — | — |
| `benefitRequests` | (alta) | `requested` | Solicitud de prestación | — | — |
| `deathSubsidyCases` | (alta) | `draft` | Carga del subsidio | — | — |
| `burialUnits` | (alta) | `available` | Alta de la unidad | — | — |
| `burialRights` | (alta) | `reserved` | Reserva del derecho | — | — |
| `burialRights` | `active`, `inTransfer` | `extinguished` | Extinción con aprobación jurídica | — | — |
| `burialOccupancies` | (alta) | `occupied` | Acto de inhumación realizado | — | — |
| `cemeteryActs` | (alta) | `requested` | Solicitud del acto | — | — |
| `cemeteryActs` | `requested`, `documentationPending`, `scheduled` | `cancelled` | Cancelación antes de realizarse | — | — |
| `orthopedicLoans` | (alta) | `active` | Entrega del elemento | — | — |
| `housingUnits` | (alta) | `enrolled` | Inscripción en el plan | — | — |
| `housingUnits` | `enrolled`, `allocated`, `underConstruction`, `partiallyDelivered` | `transferred` | Cesión aprobada a otro asociado | — | — |
| `housingUnits` | `enrolled`, `allocated`, `underConstruction`, `partiallyDelivered` | `terminated` | Rescisión aprobada (`housingTerminations` `executed`) | — | — |
| `housingMaterialWithdrawals` | (alta) | `issued` | Emisión del retiro | — | — |
| `housingCertificates` | (alta) | `draft` | Carga del certificado | — | — |
| `fleetVehicles` | (alta) | `available` | Alta del vehículo | — | — |
| `fleetVehicles` | `available`, `maintenance`, `unfit` | `retired` | Baja definitiva | — | — |
| `tripSettlements` | (alta) | `draft` | Carga de la rendición | — | — |
| `housingPrices` | (alta) | `draft` | Carga del precio de la tipología | — | — |
| `housingPrices` | `draft` | `approved` | Aprobación (`approvalId`, T11) | — | — |
| `housingContributions` | (alta) | `billed` | Facturación del aporte (M05) | — | — |
| `housingContributions` | `billed` | `paid` | Cobro del aporte (M07) | — | — |
| `housingContributions` | `billed` | `voided` | Anulación de la factura | — | — |
| `housingMaterialAllocations.state` | (alta) | `assigned` | Asignación del material a la unidad | — | — |
| `housingMaterialAllocations.state` | `assigned` | `reserved` | Reserva en M13 | — | — |
| `housingMaterialAllocations.state` | `reserved` | `withdrawn` | Retiro de materiales (`housingMaterialWithdrawals`) | — | — |
| `housingMaterialAllocations.state` | `withdrawn` | `used` | Certificación del avance que lo consume | — | — |
| `housingMaterialAllocations.state` | `assigned`, `reserved` | `released` | Liberación (cambio de plan o rescisión) | — | — |
| `housingTerminations` | (alta) | `draft` | Carga de la baja o rescisión | — | — |
| `housingTerminations` | `draft` | `approved` | Aprobación (`approvalId`, T11) | — | — |
| `housingTerminations` | `approved` | `executed` | Liquidación de la devolución y baja de la unidad | — | — |
| `housingTerminations` | `draft`, `approved` | `cancelled` | Desistimiento | — | — |
| `vehicleMaintenances` | (alta) | `planned` | Programación por km o fecha | — | — |
| `vehicleMaintenances` | `planned` | `inProgress` | Ingreso del vehículo al taller | — | — |
| `vehicleMaintenances` | `inProgress` | `done` | Fin del mantenimiento | — | — |
| `vehicleMaintenances` | `planned` | `cancelled` | Cancelación | — | — |
| `fuelLoads` | (alta) | `active` | Registro de la carga | — | — |
| `fuelLoads` | `active` | `voided` | Anulación por carga errónea | — | EVT-SOC-17 `soc.vehicle.usageVoided` |
| `contractRegistrations` | (alta) | `active` | Registro asociado al contrato | — | — |
| `contractRegistrations` | `active` | `ended` | Baja del contrato o del registro | — | — |

## 9. Procesos y flujos

### 9.1 Alta y mantenimiento del grupo''' % PA, cat=1)

d.insert_before('## 22. Trazabilidad', '''### PA-SOC-19 - Residuales del 05-11-2026 (estados, referencias, nombres de campo y evento GPS)

**Pregunta:** ¿Cómo se cierran los residuales de M18 que detectaron los entregables regenerados?
**Contexto:** el índice de estados marcó sin estado inicial a la mayoría de las máquinas de la tabla general del §8, cuatro estados sin origen y siete colecciones con valores sin transiciones; el modelo entidad-relación dejó referencias sin destino; T05 declara campos clave (`documentRefId`, `supplierId`, `invoiceId`, `vatRateId`, `supplierInvoiceId`, `meta`) que este §7 no tenía o llamaba distinto; el evento GPS de T06 tenía guion.
**Opciones:**
- A) **(Recomendada)** §8.2 con estado inicial, orígenes y transiciones faltantes; vínculos → `enumerationItems` (T04); tarifa asignada → `tariffCategoryRates` (M04); plantillas → `documentTemplates` (T11); lotes y códigos externos marcados como "no es referencia"; nombres de T05 con "antes"; consumir `int.fleet.positionsReceived` (EVT-INT-17; alias en T11 §12.4).
- B) Mantener el texto y resolver en los entregables.
**Impacto si no se responde:** se aplica A.
**Bloquea:** §7, §8, §12.
**Estado:** Asumida la recomendada (DEC-072). Las transiciones nuevas de `housingMaterialAllocations` y `housingContributions` deben validarse con el responsable de planes de vivienda; T06 §12 todavía publica `int.fleet.positions-received` y debe adoptar el nombre nuevo.

''', cat=0)
d.save()
