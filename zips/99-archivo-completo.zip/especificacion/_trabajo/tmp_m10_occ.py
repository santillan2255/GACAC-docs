import re, sys
sys.stdout.reconfigure(encoding='utf-8')
t2 = open('anexos/T02-IAM-identidad-roles-auditoria.md', encoding='utf-8').read()
s = t2[t2.index('#### 4.4.3'):t2.index('### 4.5 ')]
names = [m.group(1) for m in re.finditer(r'^\| \w+ \| `([^`]+)` \|', s, re.M)]
extra = ['tec.material.authorize', 'tec.material.request', 'tec.syncConflict.resolve', 'tec.onCall.manage',
         'tec.waterQuality.manage', 'tec.phone.plant', 'tec.phone.numbering', 'tec.phone.lines',
         'tec.workOrder.read/update/close', 'tec.serviceTechnical.read/update']
f = sys.argv[1]
lines = open(f, encoding='utf-8').read().split('\n')
pat = re.compile(r'(?<![\w.])(tec\.(?:ot|factibilidades)\.[A-Za-z/]+|' + '|'.join(re.escape(n) for n in names + extra) + r')(?![\w*])')
for i, l in enumerate(lines, 1):
    hs = pat.findall(l)
    if hs:
        print(i, sorted(set(hs)), '::', l[:160])
