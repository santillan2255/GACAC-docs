﻿from repl import *
apply('T09', [
 ('COM envía la convocatoria como transaccional `ins.assembly.convened`;', 'COM envía la convocatoria como transaccional al recibir `ins.meeting.convened` (EVT-INS-14);'),
 ('post-instalación (`tec.installation.completed`), post-cierre de reclamo/OT (`crm.claim.closed`, `tec.workOrder.closed`)', 'post-instalación (`tec.installation.activationConfirmed`, EVT-TEC-16), post-cierre de reclamo/OT (`crm.case.closed`, EVT-CRM-09; `tec.workOrder.closed`, EVT-TEC-07)'),
 ('automática desde `tec.outage.scheduled` (M10);', 'automática desde `tec.outage.notified` (EVT-TEC-23, M10);'),
 ('Replicar como notificación interna `soc.dependent.cameOfAge` (O10).', 'Replicar como notificación interna disparada por `soc.dependent.majorityReached` (EVT-SOC-02, M18) (O10).'),
 ('| `cob.remittanceImport.failed` | Alerta de job de rendición (ex V2 3025,', '| `cob.remittanceImport.failed` | EVT-COB-22 `cob.exception.opened` con tipo importación de rendición (ex V2 3025,'),
])
apply('T10', [
 ('| `cat.serviceContract.*` |\n', '| `cat.contract.*` (EVT-CAT-09 a EVT-CAT-23) |\n'),
 ('| `cob.ledgerEntry.posted` |', '| `cob.obligation.registered` / `cob.payment.confirmed` / `cob.receipt.voided` / `cob.allocation.reversed` (EVT-COB-01/04/05/06) |'),
 ('| `con.journalEntry.posted` |', '| `con.entry.posted` (EVT-CON-01) |'),
 ('| liquidación, concepto, centro, importe, horas | `sue.payroll.closed` |', '| liquidación, concepto, centro, importe, horas | `sue.payrollRun.closed` (EVT-SUE-13) |'),
 ('consumidor de `fac.billingBatch.closed`, `cob.cashbox.closed`, `con.period.closed`, `mor.notificationBatch.generated` dispara', 'consumidor de `fac.billingRun.closed` (EVT-FAC-06), `cob.cashSession.closed` (EVT-COB-12), `con.period.closed` (EVT-CON-07), `mor.batch.generated` (EVT-MOR-07) dispara'),
 ('| `fac.billingBatch.closed`, `cob.cashbox.closed`, `con.period.closed`, `mor.notificationBatch.generated`, `sue.payroll.closed`, `med.readingCycle.closed` |', '| `fac.billingRun.closed` (EVT-FAC-06), `cob.cashSession.closed` (EVT-COB-12), `con.period.closed` (EVT-CON-07), `mor.batch.generated` (EVT-MOR-07), `sue.payrollRun.closed` (EVT-SUE-13), `med.readingBatch.closed` (EVT-MED-07) |'),
 ('| `iam.membership.deactivated`, `iam.roleAssignment.revoked`, `iam.roleAssignment.changed` |', '| `iam.membership.suspended` / `.revoked` (EVT-IAM-03), `iam.role.unassigned` / `iam.role.assigned` (EVT-IAM-04), `iam.role.changed` (EVT-IAM-05) |'),
 ('| `pla.license.changed` (T01) |', '| `pla.license.updated` (EVT-PLA-08, T01) |'),
 ('| `cfg.version.published` (T04) |', '| `cfg.configVersion.published` (EVT-CFG-05, T04) |'),
 ('| `cat.serviceContract.*` | `contracts:read` |', '| `cat.contract.activated` / `.suspended` / `.reactivated` / `.terminated` (EVT-CAT-09/10/12/15) | `contracts:read` |'),
 ('| `fac.invoice.issued`, `fis.authorization.granted`, `fac.invoice.voided` |', '| `fac.invoice.issued` (EVT-FAC-07), `fis.invoice.authorized` (EVT-FIS-01), `fac.invoice.annulled` (EVT-FAC-08) |'),
 ('| `cob.payment.confirmed`, `cob.payment.reversed` |', '| `cob.payment.confirmed` (EVT-COB-04), `cob.receipt.voided` (EVT-COB-05) |'),
 ('| `mor.interruption.executed`, `mor.reconnection.executed` |', '| `mor.interruption.executed` (EVT-MOR-13; tipo suspensión o reconexión) |'),
 ('| `request.processed` | `crm.request.processed` |', '| `request.processed` | `crm.case.statusChanged` (EVT-CRM-05) |'),
])
