﻿from conc_lib import *
p = os.path.join(BASE, '05-registro-huecos.md')
L = read(p).split('\n')
notes = {
 'HUE-SRV-01': 'Corregido en anexo: T11 §12.4 y §12.4.1 redactados; M02, T09, M10 y demás consumidores usan el nombre canónico con su EVT-ID.',
 'HUE-SRV-02': 'Corregido en anexo: M02 §12.1 numera EVT-CAT-01..25 (mismo orden que T11) y agrega EVT-CAT-26/27.',
 'HUE-SRV-03': 'Corregido en anexo: M10 §12 ya lista M02 como consumidor; T05 de DEC-064 es el modelo de datos vigente.',
 'HUE-INT-02': 'Corregido en anexo: JOB-TAR-11 (M04) es dueño; JOB-CAT-10 reacciona a EVT-TAR-012 (T11 §12.9).',
 'HUE-TEL-01': 'Corregido en anexo: JOB-INT-23 renombrado `int:recibir-cdr` (T06 recibe); M10 parsea y atribuye con JOB-TEC-09.',
 'HUECO-TRV-02': 'Corregido en anexo: consumidores de M02, M17 y M18 usan el canónico; `soc.dependent.cameOfAge` figura como alias en T11 §12.4.',
 'HUECO-TRV-03': 'Corregido en anexo: M02 adoptó EVT-CAT-01..25 sin "(prov.)" en T11 (CTR-WFL-04 resuelto).',
}
done = set()
for i, l in enumerate(L):
    for k, n in notes.items():
        if l.startswith(f'| {k} |'):
            assert l.rstrip().endswith('| Abierto |'), k
            L[i] = l.rstrip()[:-len('| Abierto |')] + f'| {n} |'; done.add(k)
assert done == set(notes), set(notes) - done
write(p, '\n'.join(L)); print('ok', len(done))
