<!-- CATALOGO GENERADO DESDE LAS SECCIONES 12 DE LOS ANEXOS M01-M19, T01-T10 (4/11/2026) -->

#### 12.A.1 Eventos de dominio emitidos por los módulos (con ID de origen)

**Emisor T01** (20 eventos; fuente: anexo T01 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-PLA-01 | `pla.tenant.created` | Payload: tenantId, code, kind, planCode | `iam` (invitación admin), `uxd` (branding), `com` (aviso), `pla` (checklist) |
| EVT-PLA-02 | `pla.tenant.statusChanged` | Payload: from, to, reason | `iam` (tokens), `core/http` (caché de estado), `bia`, `com` |
| EVT-PLA-03 | `pla.tenant.suspended` | Payload: mode, portalMode, reasonCode | `core/jobs` (pausa), `com`, `por` (banda) |
| EVT-PLA-04 | `pla.tenant.reactivated` | Payload: — | `core/jobs` (reanuda), `com` |
| EVT-PLA-05 | `pla.tenant.closed` | Payload: stage (`closing`/`closed`/`purged`) | `iam` (revoca), `int` (desactiva webhooks), `com` |
| EVT-PLA-06 | `pla.capability.activated` | Payload: moduleCode, mode | módulo activado (fan-out de jobs), `uxd` (menú), `com` |
| EVT-PLA-07 | `pla.capability.deactivated` | Payload: moduleCode, newMode | módulo afectado (detiene jobs), `uxd` |
| EVT-PLA-08 | `pla.license.updated` | Payload: moduleCode, validFrom, validTo, status | `pla` (activaciones), `com` |
| EVT-PLA-09 | `pla.saasContract.approved` | Payload: contractId, version | `pla` (licencias, checklist), `con` de `PLATFORM` (si PA-PLA-08 A) |
| EVT-PLA-10 | `pla.usage.thresholdReached` | Payload: dimension, pct, level (`soft`/`hard`) | `pla` (alertas), módulos (flag de cupo), `com` |
| EVT-PLA-11 | `pla.supportCase.opened` / `.updated` / `.resolved` | Payload: caseId, status, priority | `com` (notificaciones), `pla` (SLA) |
| EVT-PLA-12 | `pla.supportGrant.requested` / `.approved` / `.activated` / `.revoked` / `.expired` | Payload: grantId, mode, breakGlass | `iam` (tokens de soporte y revocación), `com` (aviso al tenant), `pla` (alertas) |
| EVT-PLA-13 | `pla.backup.completed` / `pla.backup.failed` | Payload: runId, type, tenantId | `pla` (checklist, alertas) |
| EVT-PLA-14 | `pla.restore.requested` / `.completed` | Payload: requestId, mode, point | módulos con `restoreHooks`, `com` |
| EVT-PLA-15 | `pla.sandbox.created` | Payload: sandboxTenantId, environment | `com` |
| EVT-PLA-16 | `pla.release.deployed` | Payload: version, environment, ring | `com` (notas), PWA (aviso de versión) |
| EVT-PLA-17 | `pla.alert.raised` / `pla.alert.resolved` | Payload: alertId, ruleCode, severity | `com` (canales) |
| EVT-PLA-18 | `pla.tenantExport.ready` | Payload: exportId, purpose | `com` |
| EVT-PLA-19 | `pla.incident.updated` | Payload: incidentId, status, affectedTenantIds | `pla` (casos vinculados), `com` |
| EVT-PLA-20 | `pla.checklist.changed` | Payload: capabilityCode, overallStatus, itemsChanged | `com`, `bia` (configuraciones pendientes) |

**Emisor T02** (16 eventos; fuente: anexo T02 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-IAM-01 | `iam.identity.created` / `iam.identity.activated` | Registro, invitación | T09 (bienvenida) |
| EVT-IAM-02 | `iam.identity.locked` / `iam.identity.unlocked` | Bloqueo | T09 (aviso), alertas |
| EVT-IAM-03 | `iam.membership.invited` / `activated` / `suspended` / `revoked` | Estados | T09, T11 (reasignación de tareas), M19 |
| EVT-IAM-04 | `iam.role.assigned` / `iam.role.unassigned` | Asignaciones | Caché de permisos, T09 (aviso al usuario) |
| EVT-IAM-05 | `iam.role.changed` / `iam.profile.changed` | Edición de rol/perfil | Caché (`authzVersion++` masivo) |
| EVT-IAM-06 | `iam.session.started` / `iam.session.revoked` | Sesiones | Analítica de uso |
| EVT-IAM-07 | `iam.login.failed` (agregado por ventana) | Fallos | Alertas |
| EVT-IAM-08 | `iam.mfa.enrolled` / `iam.mfa.removed` | Factores | T09 (aviso a todos los medios) |
| EVT-IAM-09 | `iam.password.changed` / `iam.password.resetCompleted` | Contraseña | T09 |
| EVT-IAM-10 | `iam.authorization.requested` / `granted` / `rejected` / `expired` / `consumed` | Autorizaciones | T09 (push a supervisores), módulo dueño (ejecución automática) |
| EVT-IAM-11 | `iam.supportAccess.requested` / `granted` / `started` / `ended` / `revoked` | Soporte | T09 (T-ADM), T01 (ticket) |
| EVT-IAM-12 | `iam.apiClient.created` / `credentialRotated` / `revoked` | API | T10 |
| EVT-IAM-13 | `iam.idp.activated` / `iam.idp.disabled` | SSO | — |
| EVT-IAM-14 | `iam.securityAlert.raised` | Detección | T09, T01 dashboard |
| EVT-IAM-15 | `iam.portal.accountLinked` / `iam.portal.accountUnlinked` | Vinculación | M01, M19 |
| EVT-IAM-16 | `iam.audit.integrityFailed` | Verificación | P-SEC, T-ADM |

**Emisor T03** (8 eventos; fuente: anexo T03 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-UXD-01 | `uxd.branding.published` | Payload: `tenantId`, `releaseNumber`, `changedSlots[]` | Clientes (push de versión), M05/T09 (logos de documentos y emails), CDN |
| EVT-UXD-02 | `uxd.branding.reverted` | Payload: `tenantId`, `releaseNumber`, `revertedFrom` | Ídem |
| EVT-UXD-03 | `uxd.asset.processed` | Payload: `tenantId`, `assetId`, `status` | Editor de marca (actualiza slot) |
| EVT-UXD-04 | `uxd.dictionary.published` | Payload: `tenantId`, `releaseNumber`, `changedKeys[]` | Clientes, T09 (plantillas), M05 (documentos), T10 (metadatos BI), bot/IA (M09) |
| EVT-UXD-05 | `uxd.dictionary.reverted` | Payload: `tenantId`, `releaseNumber`, `revertedFrom` | Ídem |
| EVT-UXD-06 | `uxd.dictionary.missingKeyDetected` | Payload: `tenantId`, `key`, `channel`, `count` | Plataforma (alerta si supera umbral) |
| EVT-UXD-07 | `uxd.flag.changed` | Payload: `scope`, `tenantId?`, `key`, `enabled`, `reason` | Clientes, auditoría |
| EVT-UXD-08 | `uxd.catalog.updated` | Payload: `catalogVersion`, `added[]`, `renamed[]`, `deprecated[]` | JOB-UXD-03 (recompilar todos los tenants), aviso a administradores (RF-UXD-159) |

**Emisor T04** (18 eventos; fuente: anexo T04 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-CFG-01 | `cfg.configVersion.created` | Alta de borrador | T10 (auditoría) |
| EVT-CFG-02 | `cfg.configVersion.submitted` | Envío a revisión | T11 |
| EVT-CFG-03 | `cfg.configVersion.approved` / `.rejected` | Decisión | T09 (aviso al autor) |
| EVT-CFG-04 | `cfg.configVersion.scheduled` | Programación | — |
| EVT-CFG-05 | `cfg.configVersion.published` | Publicación | Todos los módulos (invalidación de caché), M02, M04, M05 |
| EVT-CFG-06 | `cfg.configVersion.failed` / `.cancelled` / `.rolledBack` | Ídem | T09 |
| EVT-CFG-07 | `cfg.parameter.changed` | Por clave publicada o al iniciar/terminar vigencia | Módulo dueño de la clave |
| EVT-CFG-08 | `cfg.masterRecord.changed` | Alta/edición/inactivación/cierre | Consumidores de la tabla |
| EVT-CFG-09 | `cfg.masterRecord.merged` | Fin de unificación | M01, M03, M10 |
| EVT-CFG-10 | `cfg.platformTable.updated` | Release publicado | Tenants (aviso), M06, M08 |
| EVT-CFG-11 | `cfg.holiday.changed` | Alta/corrección de feriado | M05, M08, M09, M10 (SLA) |
| EVT-CFG-12 | `cfg.economicIndex.valuePublished` / `.valueRevised` | Ingesta o carga | M08, M15, M05, M14 |
| EVT-CFG-13 | `cfg.taxRegistry.imported` | Fin de ingesta de padrón | M06 |
| EVT-CFG-14 | `cfg.geo.streetProposed` / `.streetDecided` | Propuesta/decisión | Plataforma / tenant |
| EVT-CFG-15 | `cfg.geoReference.updated` | Confirmación/corrección de punto | M01, M10, T10 |
| EVT-CFG-16 | `cfg.customField.defined` / `.deprecated` | Publicación | Módulo dueño de la entidad, T10 |
| EVT-CFG-17 | `cfg.seedPack.applied` / `.removed` | Semilla | T01 |
| EVT-CFG-18 | `cfg.integrity.issueDetected` | JOB-CFG-13 | T01, T09 |

**Emisor T06** (23 eventos; fuente: anexo T06 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-INT-01 | `int.connection.activated` / `int.connection.suspended` / `int.connection.mode-changed` | Cambios de estado/modo de conexión | Módulos dueños (habilitan funciones), T01 (consumo), T02 (auditoría) |
| EVT-INT-02 | `int.connection.blocked` | Credencial o certificado inválido/vencido | M05/M06 (pausar emisión), M07, T09, alertas |
| EVT-INT-03 | `int.operation.succeeded` / `int.operation.failed` / `int.operation.uncertain` / `int.operation.manually-resolved` / `int.operation.cancelle`… | Fin de operación | Módulo dueño de `businessRef` |
| EVT-INT-04 | `int.circuit.opened` / `int.circuit.closed` | Circuit breaker | Tableros, alertas, contingencia |
| EVT-INT-05 | `int.certificate.expiring` / `int.certificate.expired` / `int.credential.expiring` / `int.credential.rotated` | Vencimientos y rotación | Alertas, T09 (aviso a responsables) |
| EVT-INT-06 | `int.arca.cae-obtained` / `int.arca.cae-rejected` / `int.arca.caea-obtained` / `int.arca.caea-informed` / `int.arca.params-synced` | ARCA | M05, M06 |
| EVT-INT-07 | `int.padron.persona-retrieved` | Consulta de padrón | M01, M12 |
| EVT-INT-08 | `int.payment-intent.created` / `int.payment.confirmed` / `int.payment.rejected` / `int.payment.reversed` / `int.payment.refunded` / `int.pay`… | Pasarelas, QR, redes | M07, M19 (estado al socio) |
| EVT-INT-09 | `int.debt-publication.acknowledged` / `int.debt-publication.rejected` | Publicación de deuda | M07 |
| EVT-INT-10 | `int.remittance.line-received` / `int.remittance.file-applied` | Rendiciones | M07 |
| EVT-INT-11 | `int.direct-debit.adhesion-updated` / `int.direct-debit.result-received` | Débitos | M07, M01 |
| EVT-INT-12 | `int.bank.movements-received` / `int.bank.balances-received` | Interbanking/extractos | M14 |
| EVT-INT-13 | `int.message.sent` / `int.message.delivered` / `int.message.read` / `int.message.bounced` / `int.message.failed` / `int.message.inbound-rece`… | Mensajería | T09, M09 (bot/CRM) |
| EVT-INT-14 | `int.meter.reading-received` / `int.meter.command-result` / `int.prepaid.credit-issued` | Telemedición y prepago | M03, M08, M10 |
| EVT-INT-15 | `int.network.provisioning-result` | ISP | M10, M08 |
| EVT-INT-16 | `int.cdr.batch-received` | Telefonía | M03/M05 (tasación) |
| EVT-INT-17 | `int.fleet.positions-received` | GPS | M18 |
| EVT-INT-18 | `int.signature.completed` / `int.signature.rejected` | Firma | M16, M08, M12, T11 |
| EVT-INT-19 | `int.file.generated` / `int.file.delivered` / `int.file.received` / `int.file.rejected` | Archivos | Módulo dueño del lote |
| EVT-INT-20 | `int.reconciliation.closed` / `int.reconciliation.differences-found` | Conciliación | M07, M14, M06 |
| EVT-INT-21 | `int.contingency.started` / `int.contingency.ended` | Contingencia | M05, M06, M07, tableros |
| EVT-INT-22 | `int.agent.online` / `int.agent.offline` / `int.agent.command-result` | Agente local | M09 (turnero), M07 (caja), M11 (POS) |
| EVT-INT-23 | `int.ai.completion-ready` | Respuesta IA (propuesta) | Módulo que la pidió |

**Emisor T07** (9 eventos; fuente: anexo T07 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-MIG-01 | `mig.snapshot.ready` | Snapshot extraído | Perfilado automático |
| EVT-MIG-02 | `mig.run.started` / `mig.run.loaded` / `mig.run.failed` / `mig.run.accepted` | Ciclo de la corrida | Notificaciones a responsables (T09), auditoría |
| EVT-MIG-03 | `mig.issue.assigned` | Issue asignado | Bandeja del usuario |
| EVT-MIG-04 | `mig.reconciliation.approved` / `rejected` | Aprobación | Tablero del proyecto |
| EVT-MIG-05 | `mig.parallel.compared` / `approved` | Paralelo | Tablero |
| EVT-MIG-06 | `mig.domain.switched` | By-pass de un dominio | Módulos dueños (activan procesos reales), M07 (resolutor), T06 (habilita integraciones) |
| EVT-MIG-07 | `mig.cutover.completed` | Corte | M05/M06 (emisión real), M07 (publicación a entes), M19 (invitaciones), T09 |
| EVT-MIG-08 | `mig.rollback.executed` | Rollback | Todos los módulos del alcance (vuelven a modo no maestro) |
| EVT-MIG-09 | `mig.person.merged` | Fusión aprobada | M01 y módulos que referencian personas |

**Emisor T08** (17 eventos; fuente: anexo T08 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-NFR-01 | `nfr.privacyNotice.published` | Publicación de aviso | POR (mostrar y solicitar aceptación), COM |
| EVT-NFR-02 | `nfr.consent.granted` | Otorgamiento | COM (audiencias), CRM |
| EVT-NFR-03 | `nfr.consent.revoked` | Revocación | COM (excluir en ≤ 5 min, RF-NFR-004), BIA |
| EVT-NFR-04 | `nfr.dataSubjectRequest.received` | Alta de solicitud | Notificaciones al responsable |
| EVT-NFR-05 | `nfr.dataSubjectRequest.completed` / `.rejected` | Cierre | POR (aviso al titular), auditoría |
| EVT-NFR-06 | `nfr.personData.erasureRequested` | Ejecución de supresión/anonimización aprobada | Todos los módulos con `x-pii`: cada uno suprime/anonimiza lo propio y responde `<mod>.personData.erased` |
| EVT-NFR-07 | `nfr.legalHold.activated` / `.released` | Transición de bloqueo | Todos los módulos dueños de datos alcanzados |
| EVT-NFR-08 | `nfr.retentionRun.completed` | Fin de ejecución | Tablero, auditoría |
| EVT-NFR-09 | `nfr.securityIncident.notified` | Notificación a tenant | Admin del tenant (aviso), correo |
| EVT-NFR-10 | `nfr.restoreDrill.completed` | Fin de simulacro | Tablero de plataforma |
| EVT-NFR-11 | `nfr.key.rotated` | Rotación | Workers (recarga de DEK), JOB-NFR-08 |
| EVT-NFR-12 | `nfr.alert.fired` / `.resolved` | Alerta | Guardia, tablero, página de estado |
| EVT-NFR-13 | `nfr.invariant.violated` | JOB-NFR-06 detecta diferencia | Tablero del tenant, alerta SEV2 |
| EVT-NFR-14 | `nfr.quota.exceeded` | Superación de cuota | Tablero del tenant, plataforma |
| EVT-NFR-15 | `nfr.subprocessor.added` | Alta de subencargado | Admin de todos los tenants |
| EVT-NFR-16 | `nfr.file.infected` | Antivirus detecta malware | Seguridad, usuario que subió |
| EVT-NFR-17 | `nfr.auditChain.broken` | JOB-NFR-05 detecta ruptura del encadenamiento de auditoría | Guardia (alerta SEV2), oficial de seguridad |

**Emisor T10** (18 eventos; fuente: anexo T10 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-BIA-01 | `bia.report.published` | Publicación de versión de un reporte de sistema o personalizado | Programaciones (avisan cambio de versión), T02 (catálogo de pantallas) |
| EVT-BIA-02 | `bia.report.deprecated` | Reporte deprecado | Propietarios de programaciones |
| EVT-BIA-03 | `bia.reportRun.completed` | Corrida `succeeded` | Notificación in-app (T09), programador |
| EVT-BIA-04 | `bia.reportRun.failed` | Corrida `failed` | Notificación, bandeja técnica T01 si `retriable=false` repetido |
| EVT-BIA-05 | `bia.export.ready` | Exportación `ready` | T09 (in-app/email con enlace) |
| EVT-BIA-06 | `bia.export.downloaded` | Descarga con datos personales | T02 (`auditReads.category=export`) |
| EVT-BIA-07 | `bia.schedule.suspended` | Programación suspendida por fallos o permisos | Propietario y administrador (T09) |
| EVT-BIA-08 | `bia.indicator.certified` | Versión certificada | Tableros (refrescan definición) |
| EVT-BIA-09 | `bia.kpiAlert.opened` | Alerta abierta o reabierta | T09 (canales de la regla), webhooks públicos `metric.alert.opened` |
| EVT-BIA-10 | `bia.kpiAlert.resolved` | Alerta resuelta | T09 |
| EVT-BIA-11 | `bia.apiClient.activated` / `.suspended` / `.revoked` | Transición §8.6 | T02 (invalida caché de credenciales), contacto técnico (email) |
| EVT-BIA-12 | `bia.webhookSubscription.disabled` | Suscripción deshabilitada por fallas | Contacto técnico, PAN-BIA-17 |
| EVT-BIA-13 | `bia.dataset.freshnessBreached` | Frescura > `PRM-BIA-031` | T01 (bandeja técnica), PAN-BIA-23 |
| EVT-BIA-14 | `bia.reconciliation.mismatch` | Diferencia operativo vs analítico > `PRM-BIA-029` | T01, dueño del indicador |
| EVT-BIA-15 | `bia.customReport.submitted` / `.published` | Ciclo del generador | Bandeja de aprobaciones T11 |
| EVT-BIA-16 | `bia.bulkExport.ready` | Exportación masiva lista | Webhook público `export.ready`, T01 (salida del tenant) |
| EVT-BIA-17 | `bia.openData.published` / `.withdrawn` | Publicación de datos abiertos | M19 (landing) |
| EVT-BIA-18 | `bia.exitExport.delivered` | Paquete de salida del tenant entregado | T01 (cierre del tenant, MER-020) |

**Emisor M01** (25 eventos; fuente: anexo M01 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-PER-01 | `per.person.created` | Alta de persona | M17, M19, BI |
| EVT-PER-02 | `per.person.updated` | Cambio de datos | M05 (datos para documentos futuros), M06, T09 |
| EVT-PER-03 | `per.person.deceased` | Fallecimiento | M02, M09 (tareas), M17, M19 |
| EVT-PER-04 | `per.person.deathReverted` | Reversión | M02, M09, M17 |
| EVT-PER-05 | `per.person.mergeRequested` | Fusión aprobada | Todos los módulos con referencias a personas |
| EVT-PER-06 | `per.person.merged` / `per.person.mergeReverted` | Fin de fusión / reversión | Todos |
| EVT-PER-07 | `per.person.anonymized` | Anonimización | BI, T09, M19 |
| EVT-PER-08 | `per.taxId.verified` / `per.taxId.mismatch` | Resultado ARCA | M06, M05 |
| EVT-PER-09 | `per.holder.created` / `per.holder.activated` | Alta / activación | M04 (cargo alta titular), M17, M19 |
| EVT-PER-10 | `per.holder.closed` / `per.holder.reopened` | Baja / reactivación | M02, M05, M17, M19 |
| EVT-PER-11 | `per.account.created` | Alta de cuenta | M02 (altas automáticas), M04 (cargo alta cuenta), M05, M07 |
| EVT-PER-12 | `per.account.updated` | Cambio de datos de cuenta | M05, M06, M07, T09 |
| EVT-PER-13 | `per.account.principalChanged` | Cambio de principal | M05, M17 |
| EVT-PER-14 | `per.account.closed` | Cierre | M02, M05, M07 |
| EVT-PER-15 | `per.address.geoConfirmed` / `per.address.changed` | Ubicación confirmada / domicilio cambiado | M10 (GIS), M03 (rutas), M09 |
| EVT-PER-16 | `per.premises.created` / `per.premises.updated` | Inmueble | M02, M10, M04 (cuotas de obra) |
| EVT-PER-17 | `per.servicePoint.created` / `per.servicePoint.relocated` | Punto | M02, M03, M10 |
| EVT-PER-18 | `per.relationship.granted` / `revoked` / `expired` | Relaciones | T02 (alcance), M19, M07 |
| EVT-PER-19 | `per.adherent.added` / `per.adherent.removed` | Adherentes | M04, M05, M17 |
| EVT-PER-20 | `per.block.applied` / `lifted` / `expired` | Bloqueos | M02, M05, M07, M08, M19 |
| EVT-PER-21 | `per.document.presented` / `validated` / `expired` | Documentación | M02, M04 (beneficios), M09 |
| EVT-PER-22 | `per.transfer.executed` / `per.transfer.reverted` | Transferencias | M02, M04 (cargo tipo 7), M05, M07, M17 |
| EVT-PER-23 | `per.ownership.changed` | Cambio de titularidad de un contrato | M02, M05, M07, M19 |
| EVT-PER-24 | `per.userLink.verified` / `per.userLink.revoked` | Vínculo usuario | T02, M19 |
| EVT-PER-25 | `per.contact.changed` | Contacto cambiado o verificado | T09, M19 |

**Emisor M03** (29 eventos; fuente: anexo M03 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-MED-01 | `med.meter.installed` | Instalación activa creada | M13 (salida de stock), M01 (punto con medidor), T06 (alta en sistema remoto) |
| EVT-MED-02 | `med.meter.removed` | Instalación cerrada | M13 (entrada/estado), M01 |
| EVT-MED-03 | `med.installation.voided` | Anulación | M13, M01 |
| EVT-MED-04 | `med.installation.categoryChangeRequested` | OT trae categoría nueva | M01/M02 |
| EVT-MED-05 | `med.readingBatch.generated` | Lote generado | T09 (aviso al lecturista) |
| EVT-MED-06 | `med.readingBatch.confirmed` | Lote confirmado | Tablero, M05 (avance de pre-facturación) |
| EVT-MED-07 | `med.readingBatch.closed` | Lote cerrado | M05 (ciclo), T10 |
| EVT-MED-08 | `med.reading.captured` | Lectura recibida | Tablero |
| EVT-MED-09 | `med.reading.corrected` | Nueva versión | M04/M05 (recalcular si en simulación), auditoría |
| EVT-MED-10 | `med.readingObservation.workOrderRequested` | Observación que pide OT | M10 |
| EVT-MED-11 | `med.consumption.approved` | Consumo aprobado | M04/M05 |
| EVT-MED-12 | `med.consumption.blocked` | Consumo bloqueado | M05 (observado en lote) |
| EVT-MED-13 | `med.consumption.voided` | Anulado | M04/M05 |
| EVT-MED-14 | `med.consumptionException.raised` | Excepción creada | Tablero, T09 (alerta interna) |
| EVT-MED-15 | `med.consumptionAdjustment.approved` | Ajuste aprobado | M04/M05 |
| EVT-MED-16 | `med.point.inspectionRequested` | Estimaciones consecutivas / no leído reiterado | M10 |
| EVT-MED-17 | `med.point.suspicionRaised` | Patrón de consumo no registrado | M10 (inspección), M09 |
| EVT-MED-18 | `med.demand.transgressionDetected` | Transgresión | M09 (aviso), M04 |
| EVT-MED-19 | `med.injectionBalance.approved` | Balance GD aprobado | M04, M05, M07, M06 |
| EVT-MED-20 | `med.dgContract.statusChanged` | Cambio de estado GD | M01, M06 |
| EVT-MED-21 | `med.remoteOperation.succeeded` | Operación remota confirmada | M08, M10, M01 |
| EVT-MED-22 | `med.remoteOperation.failed` | Operación remota fallida | M08, M10, T06 (bandeja) |
| EVT-MED-23 | `med.prepaidTopUp.delivered` | Token/crédito entregado | M07, M19, T09 |
| EVT-MED-24 | `med.prepaidTopUp.failed` | Recarga fallida tras cobro | M07 (devolución), T09 |
| EVT-MED-25 | `med.prepaidAccount.lowBalance` | Saldo bajo | T09 |
| EVT-MED-26 | `med.selfReadingWindow.opened` | Ventana abierta | T09 |
| EVT-MED-27 | `med.selfReading.accepted` / `med.selfReading.rejected` | Resultado | T09, M19 |
| EVT-MED-28 | `med.syncConflict.raised` | Conflicto offline | Supervisor (T09 interno) |
| EVT-MED-29 | `med.meteringSystem.healthChanged` | Salud de conector | T06, plataforma |

**Emisor M04** (21 eventos; fuente: anexo M04 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-TAR-001 | `tar.schedule.submitted` | Versión enviada a aprobación. | T11 (autorización), T09 (aviso a aprobadores) |
| EVT-TAR-002 | `tar.schedule.approved` | Firmas completas. | T11, auditoría |
| EVT-TAR-003 | `tar.schedule.rejected` | Rechazo. | T09 (autor) |
| EVT-TAR-004 | `tar.schedule.published` | Publicación (programada o inmediata). | M05 (planificación de lotes), M19 (landing), T10 |
| EVT-TAR-005 | `tar.schedule.activated` | Entra en vigencia. | M05, M19, T10 |
| EVT-TAR-006 | `tar.schedule.superseded` | Reemplazada. | T10 |
| EVT-TAR-007 | `tar.rule.published` | Regla publicada. | T10, auditoría |
| EVT-TAR-008 | `tar.calculation.completed` | Corrida de cálculo terminada. | M05 |
| EVT-TAR-009 | `tar.simulation.completed` | Simulación masiva terminada. | T09 (usuario), PAN-TAR-16 |
| EVT-TAR-010 | `tar.promotion.assigned` | Asignación activa. | M09, M19 |
| EVT-TAR-011 | `tar.promotion.consumed` | Ciclo consumido al emitir. | M19 |
| EVT-TAR-012 | `tar.promotion.ended` | Agotada/finalizada/cancelada. | T09 (aviso al socio), M19 |
| EVT-TAR-013 | `tar.subsidyRoll.imported` | Padrón confirmado. | M06 (rendición), T10 |
| EVT-TAR-014 | `tar.enrollment.changed` | Alta/baja/cambio de inscripción. | M02 (recategorización si aplica), M19 |
| EVT-TAR-015 | `tar.retroactiveDiff.computed` | Diferencias calculadas. | T11 (aprobación) |
| EVT-TAR-016 | `tar.retroactiveDiff.approved` | Diferencias aprobadas. | M05 (NC/ND) |
| EVT-TAR-017 | `tar.contractedDemand.updateProposed` | Propuesta de nueva demanda contratada confirmada con la emisión. | M02/M03 |
| EVT-TAR-018 | `tar.category.changeProposed` | Recategorización automática (adherentes por edad, padrón) confirmada. | M02 |
| EVT-TAR-019 | `tar.calls.rated` | Lote de llamadas tasado/retasado. | M10 |
| EVT-TAR-020 | `tar.roundingCarry.confirmed` | Arrastre de redondeo confirmado al emitir. | M07 |
| EVT-TAR-021 | `tar.injectedCredit.recorded` | Crédito de usuario-generador registrado (modo MER-001). | M07, M06 |

**Emisor M05** (20 eventos; fuente: anexo M05 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-FAC-01 | `fac.billingRun.prepared` | Universo congelado | T10 (métricas) |
| EVT-FAC-02 | `fac.billingRun.prebilled` | Prefacturación terminada | T09 (aviso al responsable) |
| EVT-FAC-03 | `fac.billingRun.approved` | Aprobado | T02 auditoría |
| EVT-FAC-04 | `fac.billingRun.paused` | Pausa | T09 (alerta) |
| EVT-FAC-05 | `fac.billingRun.issued` | Emisión terminada | M06, T10 |
| EVT-FAC-06 | `fac.billingRun.closed` | Acta aprobada | M17 (capital), T10 |
| EVT-FAC-07 | `fac.invoice.issued` | Comprobante emitido | M06 (autorizar, libro IVA), M07 (obligaciones), M03 (marca facturado), M11 (cuotas facturadas), M19 |
| EVT-FAC-08 | `fac.invoice.annulled` | Anulado | M07, M06, M03, M11 |
| EVT-FAC-09 | `fac.invoice.reversed` | Revertido total o parcial | M07, M06 |
| EVT-FAC-10 | `fac.creditNote.issued` | NC emitida | M06, M07 |
| EVT-FAC-11 | `fac.debitNote.issued` | ND emitida | M06, M07 |
| EVT-FAC-12 | `fac.invoice.blocked` / `fac.invoice.unblocked` | Cambio de bloqueo | M07 (caja), M14 (rendiciones), M08 |
| EVT-FAC-13 | `fac.invoice.dueDatesChanged` | Modificación masiva de vencimientos | M07, M08, M19 |
| EVT-FAC-14 | `fac.invoice.published` | Disponible para el socio | M19 (portal), T09 (push) |
| EVT-FAC-15 | `fac.invoice.delivered` / `fac.invoice.deliveryFailed` | Resultado de entrega | M01 (contactabilidad), T10 |
| EVT-FAC-16 | `fac.billingException.opened` / `fac.billingException.resolved` | Excepción | Módulo dueño (bandeja), T09 |
| EVT-FAC-17 | `fac.billingCycle.closed` | Ciclo cerrado | M17, T10, M06 (cierre de período) |
| EVT-FAC-18 | `fac.paymentSlip.generated` / `fac.paymentSlip.cancelled` | Documento de pago | M07, M19 |
| EVT-FAC-19 | `fac.recategorization.confirmed` | Recategorización aplicada | M02 (categoría del contrato), M04 |
| EVT-FAC-20 | `fac.billableItem.billed` | Ítem facturado | Módulo origen (M08, M11, M13) |

**Emisor M06** (21 eventos; fuente: anexo M06 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-FIS-01 | `fis.invoice.authorized` | Payload: `documentId`, kind, CAE/CAEA/CAI/CESP, vencimiento, observaciones, `qrData`, `barcodeData` | M05 (marca emitido, PDF, distribución), M07 (cobrable), M15 (asiento), M19 (publica), T10 |
| EVT-FIS-02 | `fis.authorization.rejected` | Payload: `documentId`, códigos y mensajes | M05 (bandeja de lote), T09 (notificación a responsables) |
| EVT-FIS-03 | `fis.authorization.detained` | Payload: `documentId`, motivos de prevalidación | M05, M01 (corrección de datos), T09 |
| EVT-FIS-04 | `fis.authorization.uncertain` | Payload: `documentId`, `submissionId` | T06 (bandeja de operaciones), FIS JOB-FIS-04 |
| EVT-FIS-05 | `fis.authorization.reconciled` | Payload: `documentId`, cambio aplicado, aprobador | M05, M15, auditoría |
| EVT-FIS-06 | `fis.caea.obtained` / `fis.caea.reported` | Payload: período, orden, puntos | M05 (numeración en contingencia) |
| EVT-FIS-07 | `fis.contingency.activated` / `deactivated` | Payload: puntos, motivo | M05, T09 |
| EVT-FIS-08 | `fis.credential.expiring` / `expired` | Payload: ambiente, días | T09, T01 (salud del tenant) |
| EVT-FIS-09 | `fis.normativeVersion.published` | Payload: tabla, versión, vigencia | Todos los tenants (bandeja de adopción) |
| EVT-FIS-10 | `fis.normativeAdoption.approved` | Payload: tabla, versión, fecha efectiva | M04, M05, M12 (invalidan cachés) |
| EVT-FIS-11 | `fis.registry.activated` | Payload: jurisdicción, régimen, vigencia | M05 (validación de masiva) |
| EVT-FIS-12 | `fis.withholding.confirmed` / `cancelled` | Payload: OP, proveedor, tipo, importe, certificado | M12/M14 (neto), M15 (obligación) |
| EVT-FIS-13 | `fis.obligation.created` | Payload: régimen, período, importe, vencimiento | M14 (pago), T09 |
| EVT-FIS-14 | `fis.filing.generated` / `submitted` / `accepted` / `rejected` | Payload: régimen, período, rectificativa | T09, auditoría, T10 |
| EVT-FIS-15 | `fis.vatLedger.closed` / `reopened` | Payload: período, hash | M15, T10 |
| EVT-FIS-16 | `fis.thirdPartyCharge.collected` | Payload: convenio, documento, importe imputado | M15 (pasivo) |
| EVT-FIS-17 | `fis.remittance.approved` / `paid` | Payload: convenio, período, neto | M14 (OP), M15 |
| EVT-FIS-18 | `fis.regulatoryReport.generated` / `submitted` | Payload: informe, período | T09 |
| EVT-FIS-19 | `fis.padron.differenceDetected` | Payload: persona, condición actual y de padrón | M01, M12 |
| EVT-FIS-20 | `fis.taxCalculation.blocked` | Payload: documento, motivo (alícuota sin mapeo, tributo sin fundamento, padrón vencido) | M04, M05 |
| EVT-FIS-21 | `fis.authorization.globalFailure` / `globalRecovered` | Payload: causa (credencial vencida, servicio no disponible, punto de venta inhabilitado), alcance | M05 (pausa y reanuda lotes en fase de autorización), T09 |

**Emisor M07** (23 eventos; fuente: anexo M07 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-COB-01 | `cob.obligation.registered` | P-COB-01 | COB (publicación a entes), M19 |
| EVT-COB-02 | `cob.obligation.settled` | Saldo llega a 0 | M08 (reconexión, instancias), M05, COB (deuda publicada), M10 |
| EVT-COB-03 | `cob.obligation.reopened` | Reverso que reabre saldo | M08, COB |
| EVT-COB-04 | `cob.payment.confirmed` | Cobro confirmado (cualquier canal) | M15 (asiento), M08, M10 (aviso), M19, M14 (caja virtual) |
| EVT-COB-05 | `cob.receipt.voided` | Anulación | M15, M08, M05 (anular recargos facturados) |
| EVT-COB-06 | `cob.allocation.reversed` | Reverso / reasignación | M15, M08 |
| EVT-COB-07 | `cob.surcharge.deferred` | Recargo diferido | M08 (ND de intereses diferidos) |
| EVT-COB-08 | `cob.minimumPayment.evaluated` | Evaluación del mínimo | M08 |
| EVT-COB-09 | `cob.creditBalance.created` / `.consumed` | Saldos a favor | M15, M05 (próxima factura) |
| EVT-COB-10 | `cob.retention.received` | Retención sufrida en cobro | M06 |
| EVT-COB-11 | `cob.settlement.expected` | Confirmación de rendición / débito / pasarela | M14 |
| EVT-COB-12 | `cob.cashSession.closed` | Cierre de caja | M14, M15 |
| EVT-COB-13 | `cob.treasuryHandover.delivered` | Rendición entregada | M14 |
| EVT-COB-14 | `cob.cashDifference.recorded` | Quebranto o sobrante | M15 |
| EVT-COB-15 | `cob.agencyFee.recorded` | Comisión de ente o pasarela | M15, M14 |
| EVT-COB-16 | `cob.directDebit.rejected` | Rechazo de débito | M10 (aviso), M08 |
| EVT-COB-17 | `cob.directDebitMandate.changed` | Alta/baja/suspensión | M05 (leyenda en factura), M10 |
| EVT-COB-18 | `cob.chargeback.applied` | Contracargo aplicado | M08 (cargos), M15, M10 |
| EVT-COB-19 | `cob.refund.executed` | Devolución ejecutada | M14, M15, M09 |
| EVT-COB-20 | `cob.paymentIntent.statusChanged` | Cambio de estado | M19, M10 |
| EVT-COB-21 | `cob.thirdPartyCollection.recorded` | Cobro de tercero | M14, M15 |
| EVT-COB-22 | `cob.exception.opened` | Nueva excepción | T09 (alertas) |
| EVT-COB-23 | `cob.audit.*` | Acciones sensibles (cambio de recargo, desmarcar nota, anulación, reapertura) | T02 |

**Emisor M08** (20 eventos; fuente: anexo M08 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-MOR-01 | `mor.policy.published` | Payload: tipo (interés/mora/esquema/plan), id, versión | T04 (auditoría), M05/M07 (cachés) |
| EVT-MOR-02 | `mor.interest.settled` | Payload: calculationId, documentos, componentes, modo, receiptRef | M05 (emitir cargo), M15 |
| EVT-MOR-03 | `mor.deferredInterest.created` · `.billed` · `.cancelled` | Payload: id, cuenta, neto, pendingChargeId | M05, M15 |
| EVT-MOR-04 | `mor.interestRun.completed` · `.failed` | Payload: runId, totales | M05, M15, T10 |
| EVT-MOR-05 | `mor.hold.applied` · `.released` | Payload: documento, causa, origen | M07, M19 |
| EVT-MOR-06 | `mor.evaluation.closed` | Payload: cuenta, decisiones por servicio | T10, M09 |
| EVT-MOR-07 | `mor.batch.generated` · `.annulled` | Payload: lote, instancia, cantidad, deuda | T10 |
| EVT-MOR-08 | `mor.notice.created` · `.processed` · `.paid` · `.excluded` · `.closed` | Payload: noticeId, cuenta, instancia | M07 (aviso de notificado), M19, M09 |
| EVT-MOR-09 | `mor.notice.dispatchRequested` | Payload: noticeId, canal, destinatarios, modelo, variables, evidenceRequired | T09 |
| EVT-MOR-10 | `mor.notice.evidenceMissing` | Payload: noticeId, motivo | M09 (tarea canal alternativo) |
| EVT-MOR-11 | `mor.promise.registered` · `.broken` · `.kept` | Payload: noticeId, fecha, importe | M09 |
| EVT-MOR-12 | `mor.interruption.requested` · `.blocked` · `.approved` · `.scheduled` | Payload: caseId, tipo, servicio, decisión | M10 (orden), M09, M19 |
| EVT-MOR-13 | `mor.interruption.executed` · `.executionFailed` · `.cancelled` | Payload: caseId, resultado, fecha real | M01/M02 (estado), M05 (prorrateo, no facturar), T09 (aviso), M19 |
| EVT-MOR-14 | `mor.agreement.created` · `.activated` · `.completed` · `.defaulted` · `.rehabilitated` · `.refinanced` · `.annulled` | Payload: agreementId, importes | M05 (cuotas, cargos), M07 (sustitución de obligaciones), M15, M17 (capital social) |
| EVT-MOR-15 | `mor.installment.due` · `.overdue` | Payload: installmentId | M05, T09 |
| EVT-MOR-16 | `mor.guarantee.executed` · `.applied` · `.refunded` | Payload: guaranteeId, importes | M07, M14, M15 |
| EVT-MOR-17 | `mor.collectionCase.opened` · `.closed` · `.costRegistered` | Payload: caseId | M15, T10 |
| EVT-MOR-18 | `mor.writeOff.approved` · `.reverted` | Payload: writeOffId, documentos, importes | M15, M07 |
| EVT-MOR-19 | `mor.prescription.executed` | Payload: runId, documentos, importes | M05, M07, M15 |
| EVT-MOR-20 | `mor.protection.expiring` · `.expired` | Payload: protectionId | M09 (tarea) |

**Emisor M09** (25 eventos; fuente: anexo M09 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-CRM-01 | `crm.case.created` | Alta de caso | T09 (aviso recibido), T10, IA |
| EVT-CRM-02 | `crm.case.classified` | Clasificación aceptada/corregida | T10 |
| EVT-CRM-03 | `crm.case.derived` | Derivación | T09 (aviso al área) |
| EVT-CRM-04 | `crm.case.assigned` | Asignación | T09 (aviso al asignado) |
| EVT-CRM-05 | `crm.case.statusChanged` | Toda transición | T09 (aviso al socio si notificable), T10, M19 |
| EVT-CRM-06 | `crm.case.slaWarning` | Umbral SLA | T09 |
| EVT-CRM-07 | `crm.case.slaBreached` | Vencimiento SLA | T09, T10 |
| EVT-CRM-08 | `crm.case.resolved` | Resolución | T09, M19 |
| EVT-CRM-09 | `crm.case.closed` | Cierre | T09 (encuesta), T10 |
| EVT-CRM-10 | `crm.case.reopened` | Reapertura | T10 |
| EVT-CRM-11 | `crm.case.cancelled` | Cancelación | M11 (presupuesto), T10 |
| EVT-CRM-12 | `crm.case.merged` | Fusión | T10 |
| EVT-CRM-13 | `crm.commandRequest.requested` | Comando emitido | Módulo destino |
| EVT-CRM-14 | `crm.cancellationRequest.received` | Baja recibida (pública o autenticada) | T09 (constancia), T10 (indicador regulatorio) |
| EVT-CRM-15 | `crm.cancellationRequest.receiptDelivered` / `receiptFailed` | Resultado de constancia | T10, supervisión |
| EVT-CRM-16 | `crm.incident.confirmed` / `updated` / `restored` / `closed` | Ciclo del incidente | T09 (avisos), M10, T10, M19 (cortes vigentes) |
| EVT-CRM-17 | `crm.message.received` / `crm.message.sent` | Mensajería | T10 |
| EVT-CRM-18 | `crm.conversation.handedOff` | Traspaso bot → humano | T10 |
| EVT-CRM-19 | `crm.aiSuggestion.recorded` / `decided` | IA | T08 (auditoría), T10 |
| EVT-CRM-20 | `crm.queueTicket.issued` / `called` / `finished` | Turnero | T09 (aviso remoto), T10 |
| EVT-CRM-21 | `crm.activityOccurrence.generated` / `overdue` / `closed` | Actividades | T09 (recordatorios), T10 |
| EVT-CRM-22 | `crm.deskEntry.registered` / `transferred` / `answered` | Mesa de entradas | T10 |
| EVT-CRM-23 | `crm.procedureRecord.expired` | Trámite vencido | M02/M04/M07 según acción |
| EVT-CRM-24 | `crm.circularRun.generated` | Corrida | T09 |
| EVT-CRM-25 | `crm.survey.negativeReceived` | Encuesta negativa | Supervisión |

**Emisor M10** (31 eventos; fuente: anexo M10 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-TEC-01 | `tec.feasibility.requested` | Payload: feasibilityId, serviceType, personId, addressId | M09 (seguimiento), T09 |
| EVT-TEC-02 | `tec.feasibility.verdictIssued` | Payload: feasibilityId, verdict, validUntil, estimateId? | M09, M11, T09 |
| EVT-TEC-03 | `tec.feasibility.cancelled` | Payload: feasibilityId, reason | M09 |
| EVT-TEC-04 | `tec.workOrder.created` | Payload: workOrderId, operationTypeId, contractId?, origin, caseId? | M09, M15, T09 |
| EVT-TEC-05 | `tec.workOrder.statusChanged` | Payload: workOrderId, from, to, at | M09 (estado del caso), portal |
| EVT-TEC-06 | `tec.workOrder.executed` | Payload: workOrderId, executedAt, resourceId | M09, M13 |
| EVT-TEC-07 | `tec.workOrder.closed` | Payload: workOrderId, effect, contractId?, closedAt, resolutionCodeId | M09, M05 (cargos "luego"), M03 (lectura), M15 |
| EVT-TEC-08 | `tec.workOrder.cancelled` | Payload: workOrderId, reason | M09, M13 (liberar reservas) |
| EVT-TEC-09 | `tec.workOrder.reopened` | Payload: workOrderId, reason | M09, M05 |
| EVT-TEC-10 | `tec.charge.proposed` | Payload: workOrderId, contractId, conceptId, moment (before/after), quantity | M04/M05 |
| EVT-TEC-11 | `tec.material.requested` / `tec.material.returned` / `tec.material.used` | Payload: workOrderId, itemId, serial?, qty | M13 |
| EVT-TEC-12 | `tec.equipment.installed` / `tec.equipment.retrieved` | Payload: workOrderId, serial, contractId, propertyId, modality | M13, contrato |
| EVT-TEC-13 | `tec.visit.statusChanged` | Payload: visitId, status, eta? | T09 (aviso "En camino", recordatorio), portal |
| EVT-TEC-14 | `tec.visit.failed` | Payload: visitId, reason, chargeable | M09, M04/M05 (si regla de cobro) |
| EVT-TEC-15 | `tec.conformity.signed` / `tec.conformity.refused` | Payload: workOrderId, documentHash | M09, contrato |
| EVT-TEC-16 | `tec.installation.activationConfirmed` | Payload: contractId, workOrderId, effectiveAt | Contrato (T05), M05, M09, T09 (encuesta) |
| EVT-TEC-17 | `tec.survey.requested` | Payload: workOrderId, personId, channel | T09 |
| EVT-TEC-18 | `tec.disconnection.executed` | Payload: contractId, orderId (M08), mode, at | M08, M05/M04 (proporcional), contrato |
| EVT-TEC-19 | `tec.reconnection.executed` | Payload: contractId, orderId, mode, at | M08, M05/M04, contrato |
| EVT-TEC-20 | `tec.dependentDisconnection.requested` | Payload: parentContractId, dependentContractIds | M08/contrato |
| EVT-TEC-21 | `tec.provisioning.confirmed` / `tec.provisioning.failed` | Payload: commandId, contractId, action, systemId | M08, M09, contrato |
| EVT-TEC-22 | `tec.meter.changed` | Payload: contractId, oldMeterId, newMeterId, readings, at | M03, M13 |
| EVT-TEC-23 | `tec.outage.notified` / `tec.outage.finished` | Payload: outagePlanId, affectedCount, window | T09, T10, M09 |
| EVT-TEC-24 | `tec.networkDevice.down` | Payload: deviceId, since, affectedCount | M09 (incidente de zona), T09 |
| EVT-TEC-25 | `tec.levy.approved` | Payload: workId, beneficiaries[{contractId, amount}] | M05/M08 |
| EVT-TEC-26 | `tec.inspection.recoveryApproved` | Payload: caseId, contractId, method, period | M04 (cálculo), M05 |
| EVT-TEC-27 | `tec.cdr.attributed` | Payload: importId, count, period | M04 |
| EVT-TEC-28 | `tec.mobileUsage.imported` | Payload: importId, operator, period | M04/M05 |
| EVT-TEC-29 | `tec.syncConflict.opened` / `tec.syncConflict.resolved` | Payload: conflictId, workOrderId, resolution? | M09, supervisor (T09) |
| EVT-TEC-30 | `tec.geo.pointUpdated` | Payload: addressId, location, confidence | M01, M03 (rutas) |
| EVT-TEC-31 | `tec.phoneLine.changed` | Payload: contractId, number, portId, at | M04 |

**Emisor M11** (14 eventos; fuente: anexo M11 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-VEN-01 | `ven.operationCharge.created` | Payload: `chargeId, accountId, contractId, conceptId, amount, billingMode` | M09 (ficha), M05 (pendientes) |
| EVT-VEN-02 | `ven.operationCharge.cancelled` | Payload: `chargeId, reason` | M05, M09 |
| EVT-VEN-03 | `ven.operationCharge.invoiced` | Payload: `chargeId, invoiceIds` | M09 |
| EVT-VEN-04 | `ven.quote.created` / `ven.quote.sent` | Payload: `quoteId, version, channels` | T09, M09 |
| EVT-VEN-05 | `ven.quote.accepted` | Payload: `quoteId, version, acceptanceId, items` | M10 (OT), M09 (caso), M13 (reserva), T09 |
| EVT-VEN-06 | `ven.quote.rejected` / `ven.quote.expired` / `ven.quote.cancelled` | Payload: `quoteId, reason` | M09, M13 (liberar), T09 |
| EVT-VEN-07 | `ven.salesOrder.confirmed` | Payload: `salesOrderId, items, paymentTerms` | M13 (reserva/egreso), M05 (comprobante), M15 (si corresponde) |
| EVT-VEN-08 | `ven.salesOrder.delivered` | Payload: `salesOrderId, deliveryId, items, serials` | M13, M15 |
| EVT-VEN-09 | `ven.salesOrder.returned` | Payload: `salesOrderId, returnId, items, installmentActions` | M13 (reingreso), M05 (NC), M07 |
| EVT-VEN-10 | `ven.salesOrder.cancelled` | Payload: `salesOrderId, reason` | M13, M05, M15 |
| EVT-VEN-11 | `ven.installmentPlan.created` | Payload: `originType, originId, installments[]` | M07 (saldo proyectado), M15 |
| EVT-VEN-12 | `ven.installment.updated` (masivo, cancelación) | Payload: `installmentIds, batchId, type` | M07, M15 |
| EVT-VEN-13 | `ven.posSession.closed` | Payload: `sessionId, totals` | M07 (caja), M15 |
| EVT-VEN-14 | `ven.priceList.updated` | Payload: `priceListId, batchId` | M09, pwa-campo (caché) |

**Emisor M12** (14 eventos; fuente: anexo M12 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-CMP-01 | `cmp.supplier.created` / `cmp.supplier.updated` | Payload: `supplierId, taxId, changes` | M06 (padrón, asignaciones), M14 (beneficiarios), M15 |
| EVT-CMP-02 | `cmp.supplier.bankAccountApproved` | Payload: `supplierId, accountId, cbu` | M14 |
| EVT-CMP-03 | `cmp.supplyRequest.approved` / `.cancelled` | Payload: `requestId, items` | M10, M13 (origen), T09 |
| EVT-CMP-04 | `cmp.purchaseOrder.approved` | Payload: `orderId, supplierId, total, currency, estimatedPaymentDate, allocations` | M14 (compromiso), M15 (comprometido), T09 |
| EVT-CMP-05 | `cmp.purchaseOrder.cancelled` / `.closed` | Payload: `orderId, remainingAmount` | M14 (libera remanente), M15 |
| EVT-CMP-06 | `cmp.receipt.confirmed` | Payload: `receiptId, items, warehouseId, serials` | M13 (ingreso/egreso por devolución), M15 (pendientes) |
| EVT-CMP-07 | `cmp.receipt.voided` | Payload: `receiptId` | M13, M15 |
| EVT-CMP-08 | `cmp.supplierInvoice.registered` | Payload: `invoiceId, supplierId, amounts, items, allocations` | M06 (libro IVA compras), M15 (asiento), M14 (devengado, proyección), M13 (ajuste de costo) |
| EVT-CMP-09 | `cmp.supplierInvoice.released` / `.voided` | Payload: `invoiceId, releasedAmount` | M14, M06, M15 |
| EVT-CMP-10 | `cmp.matchException.raised` / `.decided` | Payload: `exceptionId, type, amount` | T11, T09 |
| EVT-CMP-11 | `cmp.paymentOrder.approved` | Payload: `paymentOrderId, supplierId, gross, withholdings, net, bankAccount, dueDate` | M14 (ejecución), M06 (confirmar retenciones), M15 |
| EVT-CMP-12 | `cmp.paymentOrder.cancelled` | Payload: `paymentOrderId, reason` | M14, M06 (anular retenciones), M15 |
| EVT-CMP-13 | `cmp.paymentOrder.paid` | Payload: `paymentOrderId, paidAt` | T09 (aviso al proveedor), M16 (si integra sueldos) |
| EVT-CMP-14 | `cmp.portalSubmission.received` / `.decided` | Payload: `submissionId, status, reason` | T09 |

**Emisor M13** (22 eventos; fuente: anexo M13 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-STK-01 | `stk.goods.received` | Ingreso por compra o vale de entrada | M15 (asiento), M12 (cierre de pendiente) |
| EVT-STK-02 | `stk.materials.consumed` | Consumo contabilizado (OT, OM, obra, unidad de gasto) | M15, M10 (costo de OT), T10 |
| EVT-STK-03 | `stk.custody.transferred` | Entrega/devolución de cuadrilla, transferencia | M10 (tablero de cuadrilla), T10 |
| EVT-STK-04 | `stk.equipment.applied` | Aplicación a contrato | M10 (aprovisionamiento, conformidad), M02 (contrato), M19, M15 (si cambia custodia contable comodato) |
| EVT-STK-05 | `stk.equipment.retrieved` | Retiro o devolución | M10 (desaprovisionar), M02, M15 |
| EVT-STK-06 | `stk.equipment.swapped` | Cambio de equipo | M10 (reaprovisionar con MAC nueva) |
| EVT-STK-07 | `stk.equipment.returnOverdue` | Vence plazo de devolución | M09 (contacto), T09 (aviso al socio) |
| EVT-STK-08 | `stk.equipment.chargeProposed` / `stk.equipment.chargeApproved` | Propuesta y aprobación de cargo por no devolución | M05 (concepto facturable), T11 |
| EVT-STK-09 | `stk.equipment.sold` | Venta de equipo | M15 (costo de mercadería vendida) |
| EVT-STK-10 | `stk.reservation.created` / `released` / `expired` | Reservas | M10 |
| EVT-STK-11 | `stk.adjustment.posted` | Ajuste aprobado | M15 |
| EVT-STK-12 | `stk.item.belowMinimum` | Saldo bajo mínimo | M12, T09 |
| EVT-STK-13 | `stk.reorder.suggested` | Nuevas sugerencias | M12 |
| EVT-STK-14 | `stk.valuation.changed` | Revaluación o diferencia de precio | M15 |
| EVT-STK-15 | `stk.period.closed` / `reopened` | Cierre de stock | M15, T04 |
| EVT-STK-16 | `stk.physicalCount.closed` | Cierre de inventario | M15, T10 |
| EVT-STK-17 | `stk.fixedAsset.registered` / `disposed` / `valueChanged` | Alta, baja, mejora, disminución | M15 |
| EVT-STK-18 | `stk.depreciation.posted` / `reversed` | Corrida de amortización | M15 |
| EVT-STK-19 | `stk.rma.statusChanged` | Cambio de estado RMA | T09 (notificación), M12 (nota de crédito/reposición) |
| EVT-STK-20 | `stk.manufacturing.inProcess` / `finished` | Fabricación | M15, M11 (comprobante de venta vinculado) |
| EVT-STK-21 | `stk.fieldConflict.raised` / `resolved` | Conflicto offline | M10, bandeja de supervisión |
| EVT-STK-22 | `stk.crewSettlement.closed` | Cierre de rendición con diferencias | M15, M16 (si PA-STK-04 habilita cargo al empleado) |

**Emisor M14** (22 eventos; fuente: anexo M14 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-TES-01 | `tes.operation.posted` | Operación registrada | M15 (asiento), T10 |
| EVT-TES-02 | `tes.operation.voided` | Operación anulada | M15 (reversa) |
| EVT-TES-03 | `tes.account.created` / `tes.account.closed` | Alta/cierre de cuenta | M15, T10 |
| EVT-TES-04 | `tes.statement.imported` | Extracto importado | Job de conciliación |
| EVT-TES-05 | `tes.reconciliation.closed` / `tes.reconciliation.reopened` | Cierre/reapertura | M15 (conciliación contable) |
| EVT-TES-06 | `tes.statementLine.unidentified` | Crédito no identificado enviado | M07 (bandeja de identificación) |
| EVT-TES-07 | `tes.gatewayCredit.reconciled` | Acreditación de pasarela conciliada | M07 (cierre de conciliación comercial) |
| EVT-TES-08 | `tes.cashRemittance.accepted` / `tes.cashRemittance.observed` / `tes.cashRemittance.voided` | Rendición | M07 (estado de caja), M15 |
| EVT-TES-09 | `tes.deposit.registered` / `tes.deposit.credited` | Depósito | M15 |
| EVT-TES-10 | `tes.thirdPartyCheck.stateChanged` / `tes.thirdPartyCheck.rejected` | Valores | M07 (ND al socio), M12 (rechazo entregado), M15 |
| EVT-TES-11 | `tes.ownCheck.issued` / `tes.ownCheck.debited` / `tes.ownCheck.voided` | Cheques propios | M15 (pendiente de débito), M12 |
| EVT-TES-12 | `tes.echeq.stateChanged` | eCheq | M12 (repudio), M07 |
| EVT-TES-13 | `tes.cardVoucher.presented` / `tes.cardSettlement.recorded` / `tes.cardVoucher.rejected` | Tarjetas | M12 (comprobante de gastos), M07 (rechazo), M15 |
| EVT-TES-14 | `tes.receivedWithholding.registered` / `tes.receivedWithholding.presented` / `tes.receivedWithholding.presentationVoided` | Retenciones recibidas | M06 (cómputo), M15 |
| EVT-TES-15 | `tes.paymentExecution.signed` / `tes.paymentExecution.executed` / `tes.paymentExecution.rejected` / `tes.paymentExecution.voided` | Pagos | M12 (OP), M06 (obligación pagada), M07 (reintegro ejecutado), M15 |
| EVT-TES-16 | `tes.paymentFile.generated` / `tes.paymentFile.sent` / `tes.paymentFile.responseReceived` | Archivos | T06 (auditoría), M16 |
| EVT-TES-17 | `tes.payrollPayment.confirmed` / `tes.payrollPayment.rejected` | Haberes por empleado | M16 |
| EVT-TES-18 | `tes.cashClosing.closed` / `tes.cashClosing.reopened` | Cierre de caja de tesorería | M15 |
| EVT-TES-19 | `tes.exchangeRate.published` | Nueva cotización | M05, M07, M12, M15 |
| EVT-TES-20 | `tes.commitment.created` / `tes.commitment.consumed` / `tes.commitment.released` | Compromisos | M15 (presupuesto) |
| EVT-TES-21 | `tes.cashFlow.alertRaised` | Saldo proyectado bajo mínimo | T09 (notificación) |
| EVT-TES-22 | `tes.period.closed` / `tes.period.reopened` | Períodos | M15, T04 |

**Emisor M15** (18 eventos; fuente: anexo M15 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-CON-01 | `con.entry.posted` | Asiento contabilizado | Módulos de origen (guardan `journalRef`: STK amortizaciones, CMP, TES, SUE), T10, JOB-CON-10 |
| EVT-CON-02 | `con.entry.reversed` | Contraasiento registrado | STK (revierte acumulados, RN-CON-061), módulos de origen, T10 |
| EVT-CON-03 | `con.entry.voided` | Asiento anulado | Ídem EVT-CON-02 |
| EVT-CON-04 | `con.event.pendingConfiguration` | Evento sin cuenta/centro/equivalencia | T09 (alerta al contador), PAN-CON-01 |
| EVT-CON-05 | `con.event.failed` | Evento en error tras reintentos | T09, soporte (T08) |
| EVT-CON-06 | `con.period.locked` / `con.period.unlocked` | Bloqueo por módulo | Todos los módulos (cachean `periodGuard`), T04 |
| EVT-CON-07 | `con.period.closed` | Cierre mensual | Todos los módulos, M06 (cierre fiscal), T10 |
| EVT-CON-08 | `con.period.reopened` | Reapertura | Todos los módulos, T10 (auditoría) |
| EVT-CON-09 | `con.fiscalYear.closed` / `con.fiscalYear.reopened` | Cierre/reapertura de ejercicio | M17 (resultado a distribuir en asamblea), T10 |
| EVT-CON-10 | `con.chart.approved` / `con.chart.promoted` | Plan aprobado/promovido | Selectores de cuentas de otros módulos (invalidan caché) |
| EVT-CON-11 | `con.config.published` | Versión de configuración publicada | JOB-CON-03 (reproceso), JOB-CON-19 |
| EVT-CON-12 | `con.inflationAdjustment.posted` | Ajuste contabilizado | T10 |
| EVT-CON-13 | `con.reconciliation.differenceDetected` | Diferencia sin explicar | T09 (responsable), PAN-CON-01 |
| EVT-CON-14 | `con.budget.approved` / `con.budget.reformulated` | Presupuesto aprobado | CMP, TES, SUE (control de disponibilidad), T10 |
| EVT-CON-15 | `con.commitment.exceeded` / `con.commitment.excessAuthorized` | Exceso de presupuesto | CMP (bloquea o continúa la OC), T11 |
| EVT-CON-16 | `con.simulation.completed` | Simulación terminada | T09 (aviso al analista) |
| EVT-CON-17 | `con.export.completed` / `con.export.failed` | Exportación a sistema externo | T06 (bandeja de operaciones) |
| EVT-CON-18 | `con.statements.issued` | Estados contables emitidos | M17 (memoria y asamblea), M19 (publicación si se decide), T10 |

**Emisor M16** (26 eventos; fuente: anexo M16 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-SUE-01 | `sue.employee.hired` | Legajo pasa a `active` | T02 (perfil empleado), M10 (cuadrillas), T09 (audiencia «empleados») |
| EVT-SUE-02 | `sue.employee.assignmentChanged` | Cambio laboral con fecha efectiva | M10, T10 |
| EVT-SUE-03 | `sue.employee.terminated` | Egreso aprobado (fecha de egreso) | T02 (revocación), M13 (equipos asignados), M10, T09 |
| EVT-SUE-04 | `sue.employee.reinstated` | Reincorporación | T02, M10 |
| EVT-SUE-05 | `sue.payrollConfig.published` | Publicación de versión | T10 (auditoría), SUE (sugerir complementaria) |
| EVT-SUE-06 | `sue.salaryScale.published` | Escala publicada | SUE, M15 (proyección) |
| EVT-SUE-07 | `sue.novelty.approved` | Novedad aprobada | T10 |
| EVT-SUE-08 | `sue.leave.requested` / `sue.leave.approved` / `sue.leave.rejected` | Ciclo de licencia | T09 (notificación), M10 (disponibilidad de agenda) |
| EVT-SUE-09 | `sue.payrollRun.calculated` | Cálculo terminado | T09 (aviso al liquidador) |
| EVT-SUE-10 | `sue.payrollRun.submitted` | Enviada a aprobación | T11 (bandeja) |
| EVT-SUE-11 | `sue.payrollRun.approved` | Aprobación (con líneas de imputación por cuenta, centro de costo, servicio y plan) | M15 (asiento de devengamiento), T10 |
| EVT-SUE-12 | `sue.payrollRun.voided` | Anulación | M15 (contraasiento) |
| EVT-SUE-13 | `sue.payrollRun.closed` | Cierre | T10 |
| EVT-SUE-14 | `sue.payslip.issued` | Recibo emitido | T09 (notificación «recibo disponible») |
| EVT-SUE-15 | `sue.payslip.acknowledged` | Firma o conformidad del empleado | T10 |
| EVT-SUE-16 | `sue.payslip.voided` | Rectificación | T09 |
| EVT-SUE-17 | `sue.paymentRequest.created` (comando `tes.paymentRequest.create`) | Solicitud de pago | M14 |
| EVT-SUE-18 | `sue.filing.generated` / `sue.filing.filed` | Presentaciones | M14 (VEP como obligación), T10 |
| EVT-SUE-19 | `sue.incomeTax.annualSettled` | Liquidación anual | T09 (formulario disponible) |
| EVT-SUE-20 | `sue.termination.approved` | Egreso aprobado | M13, T02, SUE (certificados) |
| EVT-SUE-21 | `sue.certificate.issued` | Certificado emitido | T09 |
| EVT-SUE-22 | `sue.accident.reported` | Accidente denunciado | T09 (RRHH), T10 |
| EVT-SUE-23 | `sue.lawsuit.provisionChanged` | Cambio de provisión de juicio | M15 (provisión), M08 (expediente) |
| EVT-SUE-24 | `sue.externalPayroll.approved` | Liquidación externa aprobada | M15 (asiento), M14 (pago) |
| EVT-SUE-25 | `sue.laborCost.projected` | Proyección de costo publicada | M15 (presupuesto, AGR-028) |
| EVT-SUE-26 | `sue.serviceDebt.deducted` | Descuento de deuda de servicios en recibo aprobado | M07 (cobro imputado) — solo con PA-SUE-06 |

**Emisor M17** (21 eventos; fuente: anexo M17 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-INS-01 | `ins.membership.requested` | Payload: membershipId, personId, canal | T09, T11 |
| EVT-INS-02 | `ins.membership.approved` | Payload: membershipId, personId, memberNumber, admissionDate | M01, M04 (beneficios por condición de asociado), M05, M19, T09 |
| EVT-INS-03 | `ins.membership.rejected` | Payload: membershipId, motivo | T09 |
| EVT-INS-04 | `ins.membership.suspended` / `ins.membership.reinstated` | Payload: membershipId, fecha | M19 |
| EVT-INS-05 | `ins.membership.exitRequested` | Payload: membershipId, causa | T11 |
| EVT-INS-06 | `ins.membership.exited` | Payload: membershipId, causa, fecha efectiva | M01, M04, M05, M18, M19 |
| EVT-INS-07 | `ins.member.withoutServices` | Payload: membershipId | Bandeja secretaría |
| EVT-INS-08 | `ins.capital.movement.recorded` | Payload: movementId, tipo, importe, rubro, cuenta contable | M15, M19 |
| EVT-INS-09 | `ins.capital.movement.reversed` | Payload: movementId, reversesId | M15 |
| EVT-INS-10 | `ins.capital.transfer.executed` | Payload: transferId | M15, M01 (si transfiere servicios) |
| EVT-INS-11 | `ins.capital.refund.approved` | Payload: refundId, importe | M14, M05 (comprobante de rescate) |
| EVT-INS-12 | `ins.capital.refund.paid` | Payload: refundId | M15, T09 |
| EVT-INS-13 | `ins.surplus.distribution.approved` / `.executed` | Payload: distributionId, totales | M15, M07, M14 |
| EVT-INS-14 | `ins.meeting.convened` | Payload: meetingId, tipo, fecha | T09, M19, landing |
| EVT-INS-15 | `ins.meeting.closed` | Payload: meetingId | T11 |
| EVT-INS-16 | `ins.minute.signed` | Payload: minuteId, meetingId | T11, objetos vinculados |
| EVT-INS-17 | `ins.resolution.created` | Payload: resolutionId, categoría, affectedRefs | M09, mesa de entradas, M17 (lotes de ingreso/egreso) |
| EVT-INS-18 | `ins.roster.finalized` | Payload: rosterId, totales | M19 |
| EVT-INS-19 | `ins.mandate.started` / `ins.mandate.ended` | Payload: mandateId, personId, cargo | T02 (asignación de roles institucionales), M17 honorarios |
| EVT-INS-20 | `ins.fee.settled` | Payload: settlementId, importe | M14, M15, M06 |
| EVT-INS-21 | `ins.inaes.report.submitted` | Payload: reportId | T11 |

**Emisor M18** (16 eventos; fuente: anexo M18 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-SOC-01 | `soc.dependent.added` / `.ended` / `.categoryChanged` / `.restored` | Payload: dependentId, contractId, fecha, causa | M04, M19, M17 (alerta sin servicios) |
| EVT-SOC-02 | `soc.dependent.majorityReached` | Payload: dependentId | T09 |
| EVT-SOC-03 | `soc.benefitRequest.decided` | Payload: requestId, resultado, costos | M04/M05 (cargo al socio), T09, M19 |
| EVT-SOC-04 | `soc.deathSubsidy.approved` | Payload: caseId, beneficiarios, importes | M14 |
| EVT-SOC-05 | `soc.burialRight.formalized` / `.holderChanged` / `.extinguished` | Payload: rightId | M01 (contrato de mantenimiento), M04, M19 |
| EVT-SOC-06 | `soc.cemeteryAct.performed` | Payload: actId, tipo, unidad | M05 (cargo del acto), M19 |
| EVT-SOC-07 | `soc.trip.completed` | Payload: tripId, km, importe, cubierto | M04/M05, M15 |
| EVT-SOC-08 | `soc.housing.allocated` / `.delivered` / `.terminated` / `.transferred` / `.planChanged` | Payload: unitId | M04, M05, M07, M19 |
| EVT-SOC-09 | `soc.housing.materialWithdrawn` / `.materialReturned` | Payload: withdrawalId, ítems | M13, M15 |
| EVT-SOC-10 | `soc.housing.certificateLiquidated` | Payload: certificateId, proveedor, total | M12, M14, M15 |
| EVT-SOC-11 | `soc.housing.priceUpdated` | Payload: planId, categoría, fecha | M04 |
| EVT-SOC-12 | `soc.vehicle.usageRecorded` | Payload: usageId, km, costo, OT | M15, M10 |
| EVT-SOC-13 | `soc.vehicle.unfit` / `.fit` | Payload: vehicleId, motivo | M10 |
| EVT-SOC-14 | `soc.tripSettlement.approved` | Payload: settlementId, viáticos, costos | M16, M15 |
| EVT-SOC-15 | `soc.driver.timeReported` | Payload: driverId, horas, período | M16 |
| EVT-SOC-16 | `soc.agreementCost.recorded` | Payload: agreementId, período, importe | M12, M15 |

**Emisor M19** (16 eventos; fuente: anexo M19 §12)

| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |
|---|---|---|---|
| EVT-POR-01 | `por.accountAccess.granted` | Acceso activo creado | T09 (aviso al titular), T02 auditoría, T10 |
| EVT-POR-02 | `por.accountAccess.revoked` | Revocación/desvinculación | T09, caché de sesiones (purga), T10 |
| EVT-POR-03 | `por.accountAccess.expired` | Vencimiento | T09 |
| EVT-POR-04 | `por.accountAccess.suspended` | Suspensión por operador | T09 |
| EVT-POR-05 | `por.linkAttempt.blocked` | Bloqueo por intentos | T02 (seguridad), T09 (alerta al usuario) |
| EVT-POR-06 | `por.delegation.invited` / `.accepted` / `.revoked` | Representaciones | T09 |
| EVT-POR-07 | `por.formSubmission.submitted` | Envío de formulario | M09 (si no se invocó sincrónicamente), T09 (correo PRM-POR-078), T10 |
| EVT-POR-08 | `por.formSubmission.accepted` / `.rejected` / `.cancelled` | Cambios de estado | T09, T10 |
| EVT-POR-09 | `por.publicSubmission.received` | Baja/contacto público | M09, T09 (envío del código) |
| EVT-POR-10 | `por.publicSubmission.receiptIssued` | Constancia emitida | T09 (envío por el mismo medio), T10 |
| EVT-POR-11 | `por.publicSubmission.deadlineAtRisk` | Plazo en riesgo | M09 supervisión, T09 |
| EVT-POR-12 | `por.landing.published` | Publicación/reversión | CDN (invalidación), T10 |
| EVT-POR-13 | `por.legacyImport.completed` | Fin de importación | T07, T10 |
| EVT-POR-14 | `por.legacyUser.activated` | Activación de migrado | T10 |
| EVT-POR-15 | `por.memberView.opened` | "Ver como socio" | T02 auditoría |
| EVT-POR-16 | `por.kiosk.statusChanged` | Tótem fuera de servicio/activo | M07 (caja), T09 (alerta) |

#### 12.A.2 Eventos emitidos sin ID en su anexo de origen (ID asignado por T11)

M02 (§12.1), T09 y T10 publican estos eventos sin numerarlos. T11 les asigna un ID `EVT-WFL-1NN` solo para trazabilidad; el `type` (nombre) es el del anexo de origen y no cambia. Si el anexo de origen los numera en una versión posterior, se registra la equivalencia y se conserva el EVT-WFL como alias documental.

| EVT-ID | Evento (`type`) | Emisor | Cuándo / disparo | Consumidores declarados | Fuente |
|---|---|---|---|---|---|
| EVT-WFL-101 | `cat.tenantService.enabled` / `.disabled` | M02 | Habilitación de capacidad | PLA, UXD (menú), POR | M02 §12.1 L1276 |
| EVT-WFL-102 | `cat.tenantService.published` | M02 | Oferta abierta | POR, landing, CRM, TAR | M02 §12.1 L1277 |
| EVT-WFL-103 | `cat.tenantService.withdrawn` | M02 | Oferta cerrada / retiro | POR, CRM | M02 §12.1 L1278 |
| EVT-WFL-104 | `cat.configVersion.published` | M02 | Versión vigente | TAR, FAC, MOR, TEC, CRM (caché de perfil) | M02 §12.1 L1279 |
| EVT-WFL-105 | `cat.plan.published` / `.discontinued` | M02 | Ciclo del plan | POR, CRM, TAR | M02 §12.1 L1280 |
| EVT-WFL-106 | `cat.contract.requested` | M02 | T01 | CRM, TEC (si factibilidad) | M02 §12.1 L1281 |
| EVT-WFL-107 | `cat.contract.feasibilityRequested` | M02 | T02 | TEC | M02 §12.1 L1282 |
| EVT-WFL-108 | `cat.contract.installationRequested` | M02 | T03/T05 técnico | TEC, STK | M02 §12.1 L1283 |
| EVT-WFL-109 | `cat.contract.activated` | M02 | T06 | FAC, TAR, MED, COB, CRM, PER (estado de socio), INS, CAT (altas automáticas) | M02 §12.1 L1284 |
| EVT-WFL-110 | `cat.contract.suspended` | M02 | T08 | FAC, TEC, MOR, CRM, POR | M02 §12.1 L1285 |
| EVT-WFL-111 | `cat.contract.reactivationRequested` | M02 | T09 | TEC | M02 §12.1 L1286 |
| EVT-WFL-112 | `cat.contract.reactivated` | M02 | T10/T11 | FAC, MOR, CRM | M02 §12.1 L1287 |
| EVT-WFL-113 | `cat.contract.terminationRequested` | M02 | T12 | TEC, CRM | M02 §12.1 L1288 |
| EVT-WFL-114 | `cat.contract.terminationWithdrawn` | M02 | Desiste baja | TEC, CRM | M02 §12.1 L1289 |
| EVT-WFL-115 | `cat.contract.terminated` | M02 | T14 | FAC (factura final), MED, COB, PER, INS, CRM, CAT (cascada/altas) | M02 §12.1 L1290 |
| EVT-WFL-116 | `cat.contract.cancelled` | M02 | T04/T13 | CRM, TEC, STK | M02 §12.1 L1291 |
| EVT-WFL-117 | `cat.contract.transferred` | M02 | T15 | FAC, COB, PER, MED, integraciones | M02 §12.1 L1292 |
| EVT-WFL-118 | `cat.contract.planChanged` | M02 | Cambio de plan | TAR, FAC, TEC (reprovisión), POR | M02 §12.1 L1293 |
| EVT-WFL-119 | `cat.contract.categoryChanged` | M02 | Cambio de categoría | TAR, FAC, FIS, CAT (altas) | M02 §12.1 L1294 |
| EVT-WFL-120 | `cat.contract.addressChanged` | M02 | Traslado | TEC, MED, FIS (jurisdicción), CAT (altas) | M02 §12.1 L1295 |
| EVT-WFL-121 | `cat.contract.flagChanged` | M02 | Marcas No facturar / Provisorio / etc. | FAC, TAR, MED | M02 §12.1 L1296 |
| EVT-WFL-122 | `cat.contract.equipmentAssigned` / `.equipmentReturned` / `.equipmentLost` | M02 | Comodato | STK, FAC (si cargo), CON (vía STK) | M02 §12.1 L1297 |
| EVT-WFL-123 | `cat.contract.memberAdded` / `.memberRemoved` | M02 | Adherentes/beneficiarios | TAR (cargo adherente), FAC, SOC | M02 §12.1 L1298 |
| EVT-WFL-124 | `cat.bulkOperation.completed` | M02 | Fin de trámite masivo | Notificación al solicitante, TAR/MOR origen | M02 §12.1 L1299 |
| EVT-WFL-125 | `cat.serviceCopy.completed` | M02 | Fin de copia | Plataforma, tenant destino | M02 §12.1 L1300 |
| EVT-WFL-126 | `com.post.published` | T09 | Publicación del muro publicada (con o sin `notifyAudience`) | T09 (`com:notificar-publicacion`), M19 (muro del portal), T10 | T09 §8, §9 paso 6 |
| EVT-WFL-127 | `com.comment.replied` | T09 | Respuesta institucional o de otro usuario a un comentario | T09 (aviso in-app al autor) | T09 tipo 81 (en RF figura `com.comment.reply`) |
| EVT-WFL-128 | `com.comment.moderated` | T09 | Comentario ocultado o rechazado por moderación | T09 (aviso al autor), T02 (auditoría) | T09 §8 moderación, tipo 82 |
| EVT-WFL-129 | `com.report.resolved` | T09 | Resultado de un reporte de contenido | T09 (aviso al denunciante) | T09 tipo 83 |
| EVT-WFL-130 | `com.preference.changed` | T09 | Cambio de preferencias o consentimientos de comunicación | M05 (factura digital / papel), M19, T10 | T09 RF de preferencias, tipo 90 |
| EVT-WFL-131 | `com.communication.statusChanged` | T09 | Estado de entrega normalizado desde webhook del proveedor | Módulo emisor del aviso, T10 | T09 §9 paso 6 |
| EVT-WFL-132 | `com.communication.milestoneReached` | T09 | La comunicación alcanzó el estado exigido (`proofRequired`) | Módulo emisor (M08 habilita corte, M05, M09), T11 (constancia al expediente) | T09 §9 paso 9; AGR-024 |
| EVT-WFL-133 | `com.communication.failed` | T09 | No se alcanzó el hito en plazo o falló definitivamente | Módulo emisor (reintento, otro canal, carta), T11 (tarea) | T09 §9 paso 9 |

