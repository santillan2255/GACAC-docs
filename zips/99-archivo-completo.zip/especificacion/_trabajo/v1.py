﻿import re, glob, collections
from conc_lib import *
bad = 0
for f in sorted(glob.glob(os.path.join(ANX, '*.md'))):
    s = read(f); b = os.path.basename(f)[:3]
    c = collections.Counter(re.findall(r'^\| ((?:EVT|JOB)-[A-Z]{3}-\d+)\b', s, re.M))
    d = [k for k, v in c.items() if v > 1]
    if 'T11' in b:
        for a, z in (('### 12.2 ', '### 12.4 '), ('### 12.7 ', '### 12.9 ')):
            sec = s[s.index(a):s.index(z)]
            c2 = collections.Counter(re.findall(r'^\| ((?:EVT|JOB)-[A-Z]{3}-\d+) \|', sec, re.M))
            d2 = [k for k, v in c2.items() if v > 1]
            print('T11', a.strip(), 'ids', len(c2), 'dup', d2); bad += len(d2)
    elif d:
        print(b, 'dup', d); bad += len(d)
    if '<!-- SIGUE' in s: print(b, 'SIGUE')
    if '(prov.)' in s: print(b, 'prov', s.count('(prov.)'))
t = read(T11); m2 = read(glob.glob(os.path.join(ANX, 'M02-*.md'))[0])
tc = dict(re.findall(r'^\| (EVT-CAT-\d+) \| (`[^|]+`) \|', t, re.M))
mc = dict(re.findall(r'^\| (EVT-CAT-\d+) \| (`[^|]+`) \|', m2, re.M))
diff = {k: (mc.get(k), tc.get(k)) for k in set(tc) | set(mc) if mc.get(k, '').strip() != tc.get(k, '').strip()}
print('EVT-CAT T11', len(tc), 'M02', len(mc), 'difieren', diff)
print('duplicados totales', bad)
