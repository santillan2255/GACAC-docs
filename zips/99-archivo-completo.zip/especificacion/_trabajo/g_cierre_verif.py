import re, glob, os, difflib
os.chdir(r'c:\Users\lenovo\Documents\GACAC\docs\especificacion')
files = sorted(glob.glob('anexos/T0[1346-8]-*.md') + glob.glob('anexos/T10-*.md') + glob.glob('anexos/T12-*.md'))
bk = '_trabajo/backup-cierre-T-20261105/'
t02 = open('anexos/T02-IAM-identidad-roles-auditoria.md', encoding='utf-8-sig').read()
sec = t02[t02.index('#### 4.4.3'):t02.index('### 4.5 ')]
names = [c.split('|')[2].strip().strip('`') for c in sec.splitlines() if c.startswith('| ') and '`' in c.split('|')[2]]
moj = re.compile('Ã[\x80-\xbf]|Â[\x80-\xbf ]|â€|\ufffd')
for f in files:
    raw = open(f, 'rb').read()
    old = open(bk + os.path.basename(f), 'rb').read()
    bom_ok = raw.startswith(b'\xef\xbb\xbf') == old.startswith(b'\xef\xbb\xbf')
    crlf_ok = (b'\r\n' in raw) == (b'\r\n' in old)
    t = raw.decode('utf-8-sig')
    o = old.decode('utf-8-sig')
    print('==', f, 'BOM ok' if bom_ok else 'BOM CAMBIO', 'EOL ok' if crlf_ok else 'EOL CAMBIO',
          'mojibake', len(moj.findall(t)) - len(moj.findall(o)), 'SIGUE', t.count('<!-- SIGUE -->'))
    # residuales no canónicos fuera de "antes"
    for n in names:
        if ':' in n:
            continue
        for m in re.finditer(r'`' + re.escape(n) + r'`', t):
            pre = t[max(0, m.start() - 7):m.start()]
            if 'antes ' not in pre:
                ln = t.count('\n', 0, m.start()) + 1
                print('   residual', n, 'línea', ln)
    # IDs definidos
    for pid in re.findall(r'^### (PA-[A-Z]+-\d+)', t, re.M):
        k = len(re.findall(r'^### ' + pid + r'\b', t, re.M))
        if k > 1:
            print('   PA duplicada', pid)
    ids = re.findall(r'^\| ((?:RF|RNF|RN|API|PAN|EVT|JOB|SM|CU|PRM|CTR|AL)-[A-Z]*-?\d+[a-z]?) \|', t, re.M)
    from collections import Counter
    dup = [k for k, v in Counter(ids).items() if v > 1]
    dup_old = [k for k, v in Counter(re.findall(r'^\| ((?:RF|RNF|RN|API|PAN|EVT|JOB|SM|CU|PRM|CTR|AL)-[A-Z]*-?\d+[a-z]?) \|', o, re.M)).items() if v > 1]
    nd = sorted(set(dup) - set(dup_old))
    if nd:
        print('   IDs duplicados nuevos', nd)
    # columnas de tablas en líneas cambiadas
    tl = t.split('\n')
    sm = difflib.SequenceMatcher(None, o.split('\n'), tl, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            continue
        for j in range(j1, j2):
            line = tl[j]
            if not line.startswith('|'):
                continue
            # buscar separador de la tabla
            k = j
            while k > 0 and tl[k - 1].startswith('|'):
                k -= 1
            hdr = tl[k]
            def cols(s):
                s = re.sub(r'\\\|', '', s)
                return s.count('|')
            if cols(line) != cols(hdr):
                print('   columnas distintas línea', j + 1, cols(line), cols(hdr))
