﻿import sys, glob, re
out = open(sys.argv[2], 'w', encoding='utf-8')
t = open(glob.glob(r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T05-*.md')[0], encoding='utf-8-sig').read().replace('\r\n', '\n')
L = t.split('\n')
for pat in sys.argv[1].split(';;'):
    out.write('##### ' + pat + '\n')
    for i, l in enumerate(L):
        if re.search(pat, l):
            out.write('%d: %s\n' % (i + 1, l[:700]))
