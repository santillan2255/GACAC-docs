import re, io, sys
from collections import defaultdict
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T11-WFL-workflow-eventos-documentos.md"
L = open(P, encoding="utf-8-sig").read().split("\n")
s = next(i for i, l in enumerate(L) if l.startswith("#### 12.4.1 "))
e = next(i for i, l in enumerate(L) if l.startswith("### 12.5 "))

def expand(names):
    full, base = [], None
    for n in names:
        if n.startswith(".") and base:
            full.append(base.rsplit(".", 1)[0] + n)
        else:
            full.append(n); base = n
    return full

for i in range(s, e):
    l = L[i]
    if not l.startswith("| CNC-"):
        continue
    c = [x.strip() for x in l.strip().strip("|").split("|")]
    st = c[4]
    if not st.startswith("Conciliado"):
        continue
    canon = [n for n in expand(re.findall(r"`([^`]+)`", st)) if "." in n]
    if len(set(canon)) > 1:
        print(i + 1, c[0], c[1], "->", canon)
