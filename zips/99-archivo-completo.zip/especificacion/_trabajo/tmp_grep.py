import sys, re, glob
sys.stdout.reconfigure(encoding='utf-8')
pat = re.compile(sys.argv[1])
globp = sys.argv[2] if len(sys.argv) > 2 else 'anexos/M1[0-9]-*.md'
width = int(sys.argv[3]) if len(sys.argv) > 3 else 260
for f in sorted(glob.glob(globp)):
    L = open(f, encoding='utf-8').read().replace('\r', '').split('\n')
    for i, l in enumerate(L, 1):
        if pat.search(l):
            print(f.split('\\')[-1][:3], i, l[:width])
