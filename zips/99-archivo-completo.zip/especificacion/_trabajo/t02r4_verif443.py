import sys
sys.stdout.reconfigure(encoding='utf-8')
P = 'anexos/T02-IAM-identidad-roles-auditoria.md'
raw = open(P, 'rb').read(); assert not raw.startswith(b'\xef\xbb\xbf') and b'\r\n' not in raw
t = raw.decode('utf-8')
pairs = [
    ("| ext | `ext.fac.importar` | `fac.comprobantes.importar` [VERIFICAR] |",
     "| ext | `ext.fac.importar` | `bia.fac.importaciones.crear` (antes `fac.comprobantes.importar` [VERIFICAR]; M05 API-FAC-156 ya usa la canónica) |"),
    ("| tec | `tec.ot.confirmar` | `tec.ordenes.confirmar` [VERIFICAR con M10] | Sinónimo (`ot` por `ordenes`); acción sin capability registrada |",
     "| tec | `tec.ot.confirmar` | `tec.ordenes.cerrar` (antes `tec.ordenes.confirmar` [VERIFICAR con M10]; M10 §4 lo reemplazó por `tec.ordenes.cerrar`) | Sinónimo (`ot` por `ordenes`) de una capability existente |"),
    ("| tec | `tec.ot.exportar` | `tec.ordenes.exportar` [VERIFICAR con M10] | Sinónimo (`ot` por `ordenes`); acción sin capability registrada |",
     "| tec | `tec.ot.exportar` | `tec.ordenes.imprimir` (antes `tec.ordenes.exportar` [VERIFICAR con M10]; M10 §4 lo reemplazó por `tec.ordenes.imprimir`) | Sinónimo (`ot` por `ordenes`) de una capability existente |"),
]
for a, b in pairs:
    assert t.count(a) == 1, a
    t = t.replace(a, b)
open(P, 'wb').write(t.encode('utf-8')); print('OK')
