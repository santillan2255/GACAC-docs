"""Analiza §7 de M12-M19: colecciones sin tabla, campos de T05 ausentes, ...Id sin referencia."""
import re, os, sys, glob, json
sys.stdout.reconfigure(encoding='utf-8')
ANX = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
FILES = {'CMP': 'M12', 'STK': 'M13', 'TES': 'M14', 'CON': 'M15', 'SUE': 'M16', 'INS': 'M17', 'SOC': 'M18', 'POR': 'M19'}


def read(p):
    return open(p, encoding='utf-8-sig').read().replace('\r\n', '\n').split('\n')


def t05_rows():
    L = read(os.path.join(ANX, 'T05-DAT-modelo-datos.md'))
    rows = {}
    for l in L:
        m = re.match(r'^\| (COL-([A-Z]+)-\d+) \| `([A-Za-z0-9]+)` \| (M\d\d|T\d\d) \|', l)
        if m and m.group(2) in FILES:
            c = [x.strip() for x in l.strip().strip('|').split('|')]
            rows[m.group(1)] = dict(col=m.group(3), mod=m.group(2), keys=c[4], uniq=c[5], st=c[-1])
    return rows


def sec7(path):
    L = read(path)
    a = next(i for i, l in enumerate(L) if re.match(r'^## 7\.', l))
    b = next(i for i in range(a + 1, len(L)) if re.match(r'^## \d', L[i]))
    return L, a, b


def tables(path):
    L, a, b = sec7(path)
    res = {}
    cur = []
    i = a
    while i < b:
        l = L[i]
        mh = re.match(r'^(#{3,5})\s+(.*)$', l)
        mb = re.match(r'^\*\*`([A-Za-z0-9_]+)`\*\*', l.strip())
        if mh:
            ns = [n for n in re.findall(r'`([^`]+)`', mh.group(2)) if re.fullmatch(r'[a-zA-Z][A-Za-z0-9_]*', n)]
            if ns:
                cur = ns
        elif mb:
            cur = [mb.group(1)]
        elif l.startswith('|') and i + 1 < b and re.match(r'^\|[\s:|-]+\|$', L[i + 1].strip()):
            hdr = [h.strip().lower() for h in l.strip().strip('|').split('|')]
            if hdr and hdr[0] == 'campo' and cur:
                j = i + 2
                fl = []
                while j < b and L[j].startswith('|'):
                    cells = [c.strip() for c in L[j].strip().strip('|').split('|')]
                    fl.append((j + 1, cells, hdr))
                    j += 1
                res.setdefault(cur[0], []).extend(fl)
                i = j
                continue
        i += 1
    return res


if __name__ == '__main__':
    rows = t05_rows()
    only = sys.argv[1:] or list(FILES)
    for mod, m in FILES.items():
        if mod not in only:
            continue
        path = glob.glob(os.path.join(ANX, m + '-*.md'))[0]
        tb = tables(path)
        print('=====', m)
        for cid, r in rows.items():
            if r['mod'] != mod or r['st'].startswith('A') or r['st'].startswith('R'):
                continue
            col = r['col']
            if col not in tb:
                print('  SIN TABLA', cid, col, r['st'])
                continue
            names = set()
            for ln, cells, hdr in tb[col]:
                for n in re.findall(r'`([^`]+)`', cells[0]):
                    names.add(n.replace('[]', '').split('.')[0])
            want = set(re.findall(r'`([A-Za-z][A-Za-z0-9]*)(?:\[\])?(?:\.[A-Za-z]+)?`', r['keys'] + ' ' + r['uniq']))
            miss = sorted(w for w in want if w not in names and w not in ('tenantId',))
            if miss:
                print('  T05 SOLO', col, miss, '| keys:', r['keys'][:150], '| uniq:', r['uniq'][:80])
        for col, fl in tb.items():
            for ln, cells, hdr in fl:
                if 'referencia' not in hdr:
                    continue
                ri = hdr.index('referencia')
                ref = cells[ri] if ri < len(cells) else ''
                for n in re.findall(r'`([^`]+)`', cells[0]):
                    if re.search(r'(Id|Ids|Ref)$', n) and (ref in ('', '—', '-') or ref.startswith('[VERIFICAR]') or 'colección [VERIFICAR]' in ref):
                        print('  SIN REF L%d %s.%s -> %s' % (ln, col, n, ref[:60]))
