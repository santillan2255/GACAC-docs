﻿import re
L=open('anexos/T02-IAM-identidad-roles-auditoria.md',encoding='utf-8').read().split('\n')
s=L.index('#### 4.4.3 Nombres fuera de convención o sinónimos (canónica propuesta)')
while not L[s].startswith('| Módulo |'): s+=1
s+=2; e=s
while L[e].startswith('|'): e+=1
def k(r):
    m=re.match(r'\| ([^|]+) \| `([^`]+)`',r); return (m.group(1).strip().lower(),m.group(2).lower())
b=L[s:e]; print(len(b), b==sorted(b,key=k))
for i in range(len(b)-1):
    if k(b[i])>k(b[i+1]): print('desorden',b[i][:60],'|',b[i+1][:60])
