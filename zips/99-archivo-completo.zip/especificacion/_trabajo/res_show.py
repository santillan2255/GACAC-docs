import sys, re
f, pat = sys.argv[1], sys.argv[2]
n = int(sys.argv[3]) if len(sys.argv) > 3 else 0
L = open('../anexos/' + f, encoding='utf-8').read().split('\n')
for i, l in enumerate(L):
    if re.search(pat, l):
        for j in range(i, min(len(L), i + n + 1)):
            print(j + 1, L[j][:260])
        print('--')
