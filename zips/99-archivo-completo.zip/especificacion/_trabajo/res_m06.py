from res_m0106_lib import Doc

d = Doc('M06')

# --- Categoría 1: estados ---
d.rep("| `mipymeStatus` | object | No | `{ isMipyme, category, validFrom }` |",
      "| `mipymeStatus` | object | No | `{ isMipyme, category, validFrom }`. No es un campo de estado: objeto de condición MiPyME sin máquina (§8.11; PA-FIS-22). |", '1')
d.rep("| `status` | enum | Sí | Igual a §8.7 | — |",
      "| `status` | enum | Sí | `draft`, `generated`, `validated`, `validationFailed`, `approved`, `submitted`, `accepted`, `rejected`, `rectified` (los de `regimeFilings`, §8.7; inicial `draft`, §8.12; PA-FIS-22). Antes: «Igual a §8.7». | — |", '1')

TAB = '''
### 8.12 Estados iniciales y transiciones completadas (residuales del 05-11-2026)

Ronda de residuales del 05-11-2026 (PA-FIS-22, DEC-072): estado de alta explícito de las máquinas de §8.2 a §8.10 y §8.11 que no lo indicaban, transición `active` → `expired` de `provincialValidationCodes` por vencimiento de `validTo`, baja de `fiscalClasses` y máquina de `regulatoryReportRuns` (los valores de `regimeFilings`, §8.7). Las transiciones de §8.2 a §8.10 no cambian.

| Entidad | Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |
|---|---|---|---|---|---|
| `normativeTableVersions` | — | `draft` | Alta de una versión de tabla normativa (plataforma) | — | — |
| `normativeAdoptions` | — | `proposed` | El tenant o un job prepara la adopción | — | — |
| `arcaCredentials` | — | `pendingCertificate` | Alta de la credencial (CSR generado) | — | — |
| `caeaPeriods` | — | `requested` | Solicitud del CAEA de la quincena | — | — |
| `provincialValidationCodes` | — | `active` | Alta del CVP con vigencia (`validFrom`/`validTo`) | — | — |
| `provincialValidationCodes` | `active` | `expired` | Job diario de vigencias: vence `validTo` | `validTo` anterior a la fecha; desde entonces no se imprime en comprobantes (RF-FIS-090) | — |
| `taxpayerRegistries` | — | `importing` | Carga o descarga del padrón (JOB-FIS-08) | — | — |
| `withholdingsApplied` | — | `calculated` | Cálculo en la OP en preparación (`fis.service.calculateWithholdings`) | — | — |
| `vatLedgers` | — | `draft` | Apertura del libro del período | — | — |
| `regimeFilings` | — | `draft` | Generación de la presentación del período | — | — |
| `regulatoryReportRuns` | — | `draft` | Inicio del informe al regulador del período | — | — |
| `regulatoryReportRuns` | `draft` | `generated` | Generación de archivos | — | — |
| `regulatoryReportRuns` | `generated` | `validated` | Validación de formato superada | — | — |
| `regulatoryReportRuns` | `generated` | `validationFailed` | Validación de formato con errores | — | — |
| `regulatoryReportRuns` | `validationFailed` | `draft` | Corrección de datos | — | — |
| `regulatoryReportRuns` | `validated` | `approved` | Aprobación del responsable fiscal | — | — |
| `regulatoryReportRuns` | `approved` | `submitted` | Carga del acuse (`acknowledgment`) | Exige acuse o número de transacción | — |
| `regulatoryReportRuns` | `submitted` | `accepted` | El regulador acepta | — | — |
| `regulatoryReportRuns` | `submitted` | `rejected` | El regulador rechaza | — | — |
| `regulatoryReportRuns` | `accepted` | `rectified` | Se presenta una rectificativa posterior (`rectificationNo` + 1) | — | — |
| `thirdPartyAgreements` | — | `draft` | Alta del convenio con tercero | — | — |
| `thirdPartyRemittances` | — | `draft` | Inicio de la rendición del período | — | — |
| `fiscalClasses` | — | `active` | Alta de la clase fiscal | — | — |
| `fiscalClasses` | `active` | `inactive` | Baja del catálogo | Los conceptos que la usan conservan la referencia histórica | — |
'''
d.insert_before('\n## 9. ', TAB, '1')

# --- Categoría 2: referencias ---
d.rep("| `arcaVatId` | ObjectId | Sí | (3, 4, 5, 6, 8, 9), `accounts{ sales, purchases, salesPerception }` (M15) | no es referencia interna: código ARCA de alícuota (`normativeTables`, M06) |",
      "| `arcaVatId` | int (antes ObjectId) | Sí | (3, 4, 5, 6, 8, 9), `accounts{ sales, purchases, salesPerception }` (M15) | no es referencia: código ARCA de alícuota de la tabla normativa (`normativeTables`, M06); por eso el tipo es entero |", '2')
d.rep("| `perceptionTaxId` | ObjectId | [VERIFICAR] | — | `taxDefinitions` (M06) |",
      "| `perceptionTaxId` | ObjectId | No | Tributo de percepción aplicable a la combinación. | → `taxDefinitions` (M06) |", '2')
d.rep("| `paymentOrderId` | ObjectId | Sí | OP de M12/M14 |",
      "| `paymentOrderId` | ObjectId | Sí | OP de M12/M14. Referencia: → `paymentOrders` (M12). |", '2')
d.rep("| `supplierId` / `supplierCuit` | ObjectId / string | Sí | Sujeto retenido |",
      "| `supplierId` / `supplierCuit` | ObjectId / string | Sí | Sujeto retenido. Referencia: `supplierId` → `suppliers` (M12); `supplierCuit` no es referencia (CUIT del sujeto a la fecha de la retención). |", '2')
d.rep("| `withholdingTypeId` | ObjectId | Sí | Tipo |",
      "| `withholdingTypeId` | ObjectId | Sí | Tipo. Referencia: → `withholdingTypes` (M06). |", '2')
d.rep("| `filingId` | ObjectId | No | Declaración donde se informó |",
      "| `filingId` | ObjectId | No | Declaración donde se informó. Referencia: → `regimeFilings` (M06). |", '2')
d.rep("| `obligationId` | ObjectId | No | Obligación fiscal |",
      "| `obligationId` | ObjectId | No | Obligación fiscal. Referencia: → `taxObligations` (M06). |", '2')

# --- Categoría 3: tablas de campos asociadas a su colección ---
d.anchor_field_tables('3')

# --- Categoría 4: nombres canónicos de servicios internos (§11.1) ---
d.rep("### 9.6 Cálculo de impuestos de un comprobante (servicio síncrono `fis.taxEngine.calculate`)",
      "### 9.6 Cálculo de impuestos de un comprobante (servicio síncrono `fis.service.calculateTaxes`, antes `fis.taxEngine.calculate`)", '4')
d.rep("5. Antes de cada masiva, M05 consulta `fis.registries.validateCoverage` (RF-FIS-088).",
      "5. Antes de cada masiva, M05 consulta `fis.service.checkRegistryCoverage` (antes `fis.registries.validateCoverage`; RF-FIS-088).", '4')
d.rep("### 9.8 Retenciones en órdenes de pago (servicio `fis.withholding.calculate`)",
      "### 9.8 Retenciones en órdenes de pago (servicio `fis.service.calculateWithholdings`, antes `fis.withholding.calculate`)", '4')
d.rep("2. M14 invoca `fis.withholding.calculate` (§9.8);",
      "2. M14 invoca `fis.service.calculateWithholdings` (antes `fis.withholding.calculate`; §9.8);", '4')

# --- §11.1: consumidores sin [VERIFICAR] ---
d.rep("los de `resolveDocumentClass`, `checkRegistryCoverage` y `calculateTaxes` son [VERIFICAR], porque la fila original decía solo \"Interno\".",
      "los de `resolveDocumentClass`, `checkRegistryCoverage` y `calculateTaxes` se confirmaron en la ronda de residuales del 05-11-2026 (PA-FIS-22) con las invocaciones que declaran los anexos consumidores (antes [VERIFICAR], porque la fila original decía solo \"Interno\").", 'svc')
d.rep("| `fis.service.resolveDocumentClass` | `fis.service.resolveDocumentClass(request)` | M05, M11 |",
      "| `fis.service.resolveDocumentClass` | `fis.service.resolveDocumentClass(request)` | M05 (emisión de comprobantes), M11 (ventas y punto de venta) |", 'svc')
d.rep("| `fis.service.checkRegistryCoverage` | `fis.service.checkRegistryCoverage({ serviceIds, date })` | M05 (antes de la facturación masiva) |",
      "| `fis.service.checkRegistryCoverage` | `fis.service.checkRegistryCoverage({ serviceIds, date })` | M05 (antes de la facturación masiva, §9.7 paso 5) |", 'svc')
d.rep("| `fis.service.calculateTaxes` | `fis.service.calculateTaxes(document)` | M05, M07, M11 |",
      "| `fis.service.calculateTaxes` | `fis.service.calculateTaxes(document)` | M04 (paso fiscal del motor, RN-TAR-167), M05 (emisión y recargos, RN-FAC-066), M11 (ventas, RN-VEN-025). Antes también M07: M07 no lo invoca; informa las retenciones sufridas con `cob.retention.received` (EVT-COB-10) |", 'svc')

# --- Categoría 6: tipo de evento con guion ---
d.rep("| JOB-FIS-17 | `fis:sincronizar-parametros-arca` | Evento EVT-INT-06 `int.arca.params-synced` |",
      "| JOB-FIS-17 | `fis:sincronizar-parametros-arca` | Evento EVT-INT-06 `int.arca.paramsSynced` (antes `int.arca.params-synced`) |", '6')

PA = '''
### PA-FIS-22 - Residuales de estados, servicios internos y referencias (ronda del 05-11-2026)
- **Pregunta:** ¿Se confirman los estados iniciales y las transiciones que faltaban (incluida `active` → `expired` de `provincialValidationCodes`), los valores de `regulatoryReportRuns.status`, los consumidores de los servicios internos de §11.1 y los destinos de las referencias que no lo indicaban?
- **Contexto:** al regenerar los entregables, 06a §7 marcó 12 máquinas sin estado inicial, `provincialValidationCodes` con estados sin transiciones, `regulatoryReportRuns` sin valores y `fiscalProfiles.mipymeStatus` como estado sin valores; 18 §11 marcó [VERIFICAR] los consumidores de tres servicios; 06w marcó `fis.taxEngine.calculate` y `fis.withholding.calculate` sin invocador (son los nombres anteriores de `fis.service.calculateTaxes` y `fis.service.calculateWithholdings`); 03-er marcó referencias sin destino.
- **Opciones:**
  - A) **(Recomendada)** Declarar en §8.12 el estado de alta de cada máquina, `provincialValidationCodes` `active` → `expired` por vencimiento de `validTo` y la máquina de `regulatoryReportRuns` con los valores de `regimeFilings`; aclarar que `mipymeStatus` no es estado; usar en §9 los nombres de §11.1; fijar consumidores según las invocaciones de los anexos (M04, M05 y M11 para `calculateTaxes`; M05 y M11 para `resolveDocumentClass`; M05 para `checkRegistryCoverage`); declarar destinos (`paymentOrders` y `suppliers` de M12; `withholdingTypes`, `regimeFilings`, `taxObligations`, `taxDefinitions` de M06) y tipar `arcaVatId` como código ARCA.
  - B) Dejar los estados iniciales implícitos (primer valor) y los consumidores como [VERIFICAR].
- **Impacto si no se responde:** se asume A.
- **Bloquea:** 06 (estados y servicios), 18 (contratos internos), T05 §7.2.1 y §8.1.
- **Estado:** Asumida (DEC-072): opción A. Aplicado en §7.4, §7.14, §7.16, §7.24, §7.32, §8.12, §9.6 a §9.8, §11.1 y §12 (JOB-FIS-17 consume `int.arca.paramsSynced`, antes `int.arca.params-synced`). T11 debe registrar el alias en §12.4; T05 debe reflejar los destinos y los valores de `regulatoryReportRuns.status`; M04, M12 y M14 deben citar `fis.service.calculateTaxes` y `fis.service.calculateWithholdings`.
'''
d.insert_before('\n## 22. ', PA, 'PA')
d.save()
