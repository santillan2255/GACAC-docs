"""Utilidades de edición que conservan BOM y finales de línea."""
import os, re, glob

ROOT = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'


def ruta(pat):
    p = glob.glob(os.path.join(ROOT, pat))
    assert len(p) == 1, (pat, p)
    return p[0]


class Doc:
    def __init__(self, pat):
        self.path = ruta(pat)
        raw = open(self.path, 'rb').read()
        self.bom = raw.startswith(b'\xef\xbb\xbf')
        self.t = raw.decode('utf-8-sig')
        assert '\r\n' not in self.t, 'CRLF en ' + self.path
        self.n = 0

    def rep(self, old, new, count=1):
        c = self.t.count(old)
        assert c == count, 'esperaba %d y hay %d: %r' % (count, c, old[:160])
        self.t = self.t.replace(old, new)
        self.n += 1

    def after_line(self, starts, new_lines):
        """Inserta líneas después de la línea que empieza con `starts` (única)."""
        ls = self.t.split('\n')
        idx = [i for i, l in enumerate(ls) if l.startswith(starts)]
        assert len(idx) == 1, (starts, idx)
        ls[idx[0] + 1:idx[0] + 1] = new_lines
        self.t = '\n'.join(ls)
        self.n += 1

    def before_line(self, starts, new_lines):
        ls = self.t.split('\n')
        idx = [i for i, l in enumerate(ls) if l.startswith(starts)]
        assert len(idx) == 1, (starts, idx)
        ls[idx[0]:idx[0]] = new_lines
        self.t = '\n'.join(ls)
        self.n += 1

    def line(self, starts):
        ls = self.t.split('\n')
        idx = [l for l in ls if l.startswith(starts)]
        assert len(idx) == 1, (starts, len(idx))
        return idx[0]

    def cell(self, rowstart, col, new, keep_antes=True):
        """Reemplaza la celda `col` (0 = primera) de la fila que empieza con `rowstart`."""
        old = self.line(rowstart)
        cells = old.split(' | ')
        prev = cells[col]
        cells[col] = new
        self.rep(old + '\n', ' | '.join(cells) + '\n')
        return prev

    def save(self):
        open(self.path, 'wb').write((b'\xef\xbb\xbf' if self.bom else b'') + self.t.encode('utf-8'))
        return self.n
