import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from repl import apply

P = []
P.append(("`posTerminals`, `posSessions`, `freightSettlements` (rendición de viajes y fletes de una venta) |",
          "`posTerminals`, `posSessions`, `freightSettlements` (rendición de viajes y fletes de una venta; **Reemplazado por `tripSettlements` de M18 con `source.kind = salesDocument`, CTR-DAT-53**) |"))
# DEC-016
P.append(("| BASE §72 PRO-004, §73 (\"instalación: hito, pago contado o cuotas\"); MER-010 | Núcleo | O4 | Adoptado |",
          "| BASE §72 PRO-004, §73 (\"instalación: hito, pago contado o cuotas\"); MER-010; DEC-016 (la instalación contado se factura en la primera factura del ciclo posterior a la OT confirmada) | Núcleo | O4 | Adoptado |"))
P.append(("- **Bloquea:** RF-VEN-005, §9.1, CU-INS-01.\n",
          "- **Bloquea:** RF-VEN-005, §9.1, CU-INS-01.\n- **Estado:** Respondida (DEC-016): opción A, en la primera factura del ciclo posterior a la OT confirmada.\n"))
# DEC-018
P.append(("| RN-09 403, 727; RN-02 §14 | Estándar | O8 | A validar (PA-VEN-02) | Una venta no se entrega como \"facturada\" mientras su comprobante no tenga CAE, si P727 está activo. |",
          "| RN-09 403, 727; RN-02 §14; DEC-018 | Estándar | O8 | A validar (PA-VEN-02) | Una venta no se entrega como \"facturada\" mientras su comprobante no tenga CAE, si P727 está activo. Según DEC-018 la espera tiene un tiempo máximo (lo fija M05); vencido, M05 emite con CAEA de contingencia o deja el comprobante pendiente, que no se entrega como fiscal. |"))
P.append(("| RN-VEN-039 | Con P727, la venta espera el CAE antes de considerarse emitida y entregable. | P727 (`clsComprobanteVenta.Guardar`). | Replicar | P727 | — |",
          "| RN-VEN-039 | Con P727, la venta espera el CAE antes de considerarse emitida y entregable, hasta el tiempo máximo de M05; vencido, rige la contingencia CAEA o el comprobante pendiente no entregable como fiscal (DEC-018). | P727 (`clsComprobanteVenta.Guardar`). | Replicar (ajustado por DEC-018) | P727 | — |"))
# DEC-064 salesOrders
P.append(("| `pointOfSaleId`, `branchId` | ObjectId | Sí | |\n| `kind` | Enum | Sí | `standard`, `quick`, `pos`, `field`, `imported`, `fromQuote`, `fromWorkOrder` |",
          "| `pointOfSaleId`, `branchId` | ObjectId | Sí | `pointOfSaleId` → `pointsOfSale` (M06); `branchId` → `branches` (T04) |\n"
          "| `legalEntityId` | ObjectId → `legalEntities` (T04) | Sí | Entidad jurídica que vende; la resuelve T04 (RF-CFG-137) y debe coincidir con la del punto de venta (DEC-064) |\n"
          "| `kind` | Enum | Sí | `standard`, `quick`, `pos`, `field`, `imported`, `fromQuote`, `fromWorkOrder` |"))
# freightSettlements
P.append(("### 7.12 `freightSettlements` — rendiciones\n\n",
          "### 7.12 `freightSettlements` — rendiciones\n\n> **Reemplazado por `tripSettlements` de M18 (CTR-DAT-53).** La rendición de viaje es una sola colección, de M18, con `source.kind = salesDocument` y `source.docId = salesOrderId` para las ventas; M11 la crea por comando a M18 y la consulta. El esquema siguiente queda como requisito de los datos que la venta necesita; PA-VEN-07 sigue vigente para el proceso, no para la colección.\n\n"))
P.append(("salesOrders ─▶ salesDeliveries · salesReturns · salesInstallments · invoices · serializedItems (M13) · freightSettlements",
          "salesOrders ─▶ salesDeliveries · salesReturns · salesInstallments · invoices · serializedItems (M13) · tripSettlements (M18; antes freightSettlements)"))
P.append(("| `COMP_VEN_RENDICION`, `_ITEMS` | `freightSettlements` |",
          "| `COMP_VEN_RENDICION`, `_ITEMS` | `tripSettlements` de M18 con `source.kind = salesDocument` (antes `freightSettlements`; CTR-DAT-53) |"))
# PRCAGAS
P.append(("| `PRCAGAS` (pendientes) | `operationCharges` (`valued`/`scheduled`) | Solo pendientes no facturados | Σ pendientes |",
          "| `PRCAGAS` (pendientes) | `billableItems` pendientes de M05 (CTR-DAT-38; antes `operationCharges` `valued`/`scheduled`) | Solo pendientes no facturados; `operationCharges` nace en GoodApps sin origen migrado | Σ pendientes |"))
P.append(("`{tenantId, status, billingMode}`. Origen ProCoop: `PRCAGAS` (cargos adicionales pendientes) y comprobantes de técnica de reconexión.",
          "`{tenantId, status, billingMode}`. Origen ProCoop: `PRCAGAS` (cargos adicionales pendientes) y comprobantes de técnica de reconexión. **Corregido (CTR-DAT-38):** las filas pendientes de `PRCAGAS` migran como `billableItems` pendientes de M05; `operationCharges` no tiene origen migrado."))
P.append(("| `COMP_VEN_RENDICION` | §13 | `freightSettlements` (§7.12) |",
          "| `COMP_VEN_RENDICION` | §13 | `tripSettlements` de M18 (§7.12, CTR-DAT-53) |"))
P.append(("| `COMP_VEN_RENDICION_ITEMS` | §13 | `freightSettlements.fuelItems` |",
          "| `COMP_VEN_RENDICION_ITEMS` | §13 | `tripSettlements` de M18 (ítems de combustible; antes `freightSettlements.fuelItems`) |"))
P.append(("| `PRCAGAS` | Facturación | `operationCharges` |",
          "| `PRCAGAS` | Facturación | `billableItems` de M05 para las pendientes (CTR-DAT-38); `operationCharges` sin origen migrado |"))
# CTR
P.append(("| CTR-VEN-15 | RN-09 #67 (fecha de cierre por parámetro) vs AGR/T04 | Cierre por variable suelta | Entidad unificada de períodos | AGR > RN |\n",
          "| CTR-VEN-15 | RN-09 #67 (fecha de cierre por parámetro) vs AGR/T04 | Cierre por variable suelta | Entidad unificada de períodos | AGR > RN |\n"
          "| CTR-VEN-16 | `freightSettlements` (M11) vs `tripSettlements` (M18) | Dos colecciones para la rendición de un viaje | `tripSettlements` de M18 con `source.kind = salesDocument` | CTR-DAT-53 |\n"
          "| CTR-VEN-17 | `PRCAGAS` → `operationCharges` (M11) vs `billableItems` (M05) | Destino de los cargos pendientes migrados | `billableItems` pendientes de M05; `operationCharges` sin origen migrado | CTR-DAT-38 (M05 es dueño de lo a facturar) |\n"))
apply('M11', P, 'f2-g6-m11')
