# Sincronización posterior a la ronda de residuales

## De M01-M06 (PA-PER-19, PA-CAT-23, PA-MED-15, PA-TAR-21, PA-FAC-23, PA-FIS-22)
- T05: `deviceId` (M03) → `fieldDevices` (M10), cerrar [VERIFICAR]; destinos nuevos de M03, M05, M06; valores de `regulatoryReportRuns.status`; `relationships` sin cambios.
- T11 §12.4: alias `int.arca.params-synced` → `int.arca.paramsSynced` (EVT-INT-06).
- T02: `fac.bloqueosCausas.configurar` reemplazada por `mor.causas.configurar`; servicios `fis.service.*` con nombres nuevos (`resolveDocumentClass`, `checkRegistryCoverage`, `calculateTaxes`, `calculateWithholdings`; antes `fis.taxEngine.calculate`, `fis.registries.validateCoverage`, `fis.withholding.calculate`).
- M12, M14: citar `fis.service.calculateTaxes` / `fis.service.calculateWithholdings` (M12 usa `fis.withholding.calculate`).
- M13 §7: `chargeProposalId` → `approvalRequests` (T11).
- Entregable ER: el generador debe reconocer "no es referencia" y referencias polimórficas (`taxExemptions.partyId`).

## De M07-M11 (PA-COB-21, PA-MOR-22, PA-CRM-20, PA-TEC-23, PA-VEN-12)
- T05, equivalencias de nombre (prevalece el anexo): M08 `scope.*`, `origin.noticeId`, `execution.*`; COL-MOR-02 sin `policyId`/`validFrom`; `financialInstitutionId` en COL-MOR-27. M09 `crmCaseId` (no `caseId`); quitar `operationId` de COL-CRM-12 y `documentRequirementTypeIds` de COL-CRM-16. M10 `assignment.crewId`, `assignedCrewId`, `targetRef.workOrderId`, `entityType`+`entityId`, `userId`, `connectorId`; quitar `calendarId`. M07 `cashSessionId` en COL-COB-11; tres campos de layout en COL-COB-21 (no `fileLayoutIds[]`). Campos nuevos declarados por el anexo: `personSensitiveDataId`, `signatureRequestId`, `suspensionRestrictionRules.code` (M08), `aiUsageLogId` (M09), `serviceConformities.signatureRequestId` (M10); renombres `directDebitBatchId`, `gatewayConnectorId` (M07), `billableItemId` antes `pendingChargeId` (M08), `associateMembershipId` antes `memberId` (M09).
- T05 §7.2.1 "no es referencia": M07 `closeGroupId`, `externalQrId`, `externalPaymentId`; M08 `planSnapshot`, `noticeModelVersion`, `policyVersion`, `rates[].rateId`, `adminFee.*`, `debtCollectionAgencies.taxId`; M09 `externalThreadId`, `targetType`; M10 `prospect`, `cancelReason`, `entityType`, `casPackageIds`, `fieldDevices.deviceId`; M11 `sourceType`, `originType`, `quoteVersion`, `installmentType`, `discountAmount`, `discountReason`.
- T05 §7.2.1 destinos nuevos: `deviceIds` → `fieldDevices`; `productIds`, `surchargeProductId` → `serviceProducts`; `billingTypeId` → `voucherTypes`; M11 `premiseAddressId`, `creditNoteRequestId`, `freightSettlementId`, `discountApprovalId` (ver M11 §7).
- T11 §12.4: alias `int.network.provisioning-result` → `int.network.provisioningResult`; `int.cdr.batch-received` → `int.cdr.batchReceived`; comando `tec.workOrder.request` (antes `tec.workOrder.create`) en payload de EVT-CRM-13.
- T02: alias `tec.workOrder.create` ya no es comando en M10 (ahora `tec.workOrder.request`); conservar el alias de capability.
- Generador 06: `crmCaseSubtypes.defaultStatus` es parámetro; tabla "Estados visibles" de M09 §8.1 no es colección.

## De T05/T09/T11 (PA-DAT-04, PA-COM-19, PA-WFL-23)
- T05 hecho: 0 colecciones R; destinos §7.2.1 resueltos; 64 nombres alineados. T11: 35 tipos de evento renombrados (24 filas) con alias en §12.4; 24 alias con un solo canónico (25 filas "retirado como alias"); §12.10 = 203 filas.
- Adoptar tipos de evento nuevos (mapeo en T11 §12.4): productores M17 (EVT-INS) y T06 (EVT-INT); consumidores M06, M08, M10, M15, M18, M19, T12 → aplicar por script con el mapeo, sin tocar notas "antes".
- Consumidores de alias retirados: suscribirse al canónico (M17 → `fac.debitNote.issued`; T10 → EVT-COB-04/05/06, EVT-IAM-05).
- M04: separar `taxRateIds` (solo IVA) de `taxIds` (→ `taxDefinitions`).
- M06: retirar cuentas de `vatRates`/`taxDefinitions`; M15: `entityAccountAssignments` admite `entityType` `vatRate` y `taxDefinition`.
- Renombres a canónico: M05 y M09 `memberId` → `associateMembershipId`; M14 `originAccountId` → `originTreasuryAccountId`; T01 `tenantExports.fileId` → `storedFileId`; M13, M16, M17, M18 según PA-DAT-04.
- Generador ER: ignorar nombres dentro de notas "antes `x`" (como el de AsyncAPI).

## De M12-M19 (PA-CMP-16, PA-STK-11, PA-TES-19, PA-CON-19, PA-SUE-18, PA-INS-13, PA-SOC-19, PA-POR-22)
- CU-TES-17 (antes CU-13 de M14). API-TES-87 → `tes.posicion.ver`; API-SUE-86 → `sue.costoLaboral.ver`.
- T11: verificar que §12.3 use los 8 tipos nuevos de M17 (`ins.capitalMovement.*`, `ins.capitalTransfer.executed`, `ins.capitalRefund.*`, `ins.surplusDistribution.*`, `ins.inaesReport.submitted`) y adoptar `stk.item.belowMinimum` (antes `stk.item.below-minimum`).
- T06 §12: `int.fleet.positions-received` → `int.fleet.positionsReceived`.
- T05: `*AssociateMembershipId` y `storedFileId` (M17); `inventoryItemId`, `stockDocumentId` (M13); `projectId` de M13 → `works` (M10) en lugar de `crmProjects`; COL-CMP-23 `declarationFileId`; unicidad de `bankStatementImports` y `payrollPaymentBatches`; estados nuevos de `serviceReceptions`, `revaluations`, `signalRightsContracts`, `shifts`, `extraTasks`; `matchExceptions.decision`.
- T03: rótulo "Cuentas" en SM-PWS; PAN-POR-19, 52, 55, 91 en el mapa.

## De T01-T04, T06-T08, T10, T12, maestra y plan (PA-PLA-15, PA-IAM-18, PA-UXD-18, PA-CFG-15, PA-INT-27, PA-MIG-21, PA-NFR-24, PA-BIA-17)
- CU nuevos: CU-PLA-15 (antes CU-ARQ-01 de T01), CU-IAM-11 (antes CU-SEG-01 de T02), CU-UXD-07 (antes CU-ACC-01 de T03).
- T06: 27 tipos de evento renombrados con alias en la fila → T11 §12.4 debe registrarlos.
- T05: campos renombrados `refreshFamilyId`, `screenProfileId`, `supportAccessGrantId`, `jobId`, `promptTemplateCode`, `catalogQuestionCode`, `ruleCode`, `mappingSetId`, `externalTransactionNumber`; `apiUsageDaily.date` (antes `day`; T05 había alineado a `day` → T10 es dueño, decidir uno); destinos `goodappsBatchId` → `billingRuns`, `indicatorSnapshots.scenarioId` → `simulationScenarios`, `acceptanceActId` → `documents`; `kpiAlertRules` `indicatorCode` vs `indicatorId`; `migrationIssues.ruleId` vs `ruleCode`.
- Plan: PAN-UXD-15/16/17 con RF-UXD-064, 063, 055 en PRO-O0-15 → verificar con `plan_recuento.py` que esos RF no queden duplicados en otro prompt.
- T12 cita `ins.capital.refund.paid` → `ins.capitalRefund.paid`.
- Generadores: T08 tiene tablas de campos y estados en §15 (no §7/§8).

## Pendientes tras la sincronizaci?n de anexos (5-11-2026)

- T11 ?12.4: registrar 10 eventos nuevos (con alias en guion): EVT-FIS-25 `fis.regimeFile.requested`, EVT-COB-28 `cob.paymentIntent.requested`, EVT-COB-29 `cob.debtPublication.requested`, EVT-COB-30 `cob.directDebit.batchRequested`, EVT-MED-30 `med.readingRoute.published`, EVT-COM-40 `com.message.dispatchRequested`, EVT-PER-26 `per.person.fiscalLookupRequested`, EVT-TES-24 `tes.bankSync.requested`, EVT-TES-25 `tes.paymentFile.requested`, EVT-SUE-28 `sue.payrollFiles.requested`. Consumidor: T06.
- T05: `taxIds` (destino `taxDefinitions`) en `tariffCategoryRates`, `tariffRows`, `productPrices` (M04); `entityType` de COL-CON-38 admite `taxDefinition` (antes `tax`) y `entityId` polim?rfica; `fuelTypes.vatRateId` ObjectId ? `vatRates` (M18); `employeePayAccounts.cbuHmac` y unicidad `{tenantId, employeeId, cbuHmac}` (M16).
- T05: `signalRightsContracts.packageIds` → `serviceProducts` (antes `servicePlans`) en §7.2.1 y COL-CMP-22 (M02 PA-CAT-23); quitar de §21 la nota de pendientes de M13/T10 (cerrados).
