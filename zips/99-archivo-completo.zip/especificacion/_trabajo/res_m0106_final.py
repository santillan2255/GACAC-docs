import glob, os, re, sys
from collections import Counter
sys.path.insert(0, r'C:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo')
import contratos_lib as cl

AN = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'anexos')
COLS = {'M01': ['personIdentifierIndex', 'documentSubmissions'],
        'M02': ['servicePlanVersions'],
        'M04': ['benefitGroupMembers', 'subsidyRollImports', 'subsidyEnrollments', 'promotionAssignments',
                'roundingCarryEntries', 'phoneTimeBands', 'phoneBandAssignments', 'phoneRates',
                'phoneDiscountPlans', 'phoneFreeNumbers', 'calculations', 'simulationResults'],
        'M05': ['billingImportRows']}
for m in ('M01', 'M02', 'M03', 'M04', 'M05', 'M06'):
    p = glob.glob(os.path.join(AN, m + '-*.md'))[0]
    raw = open(p, 'rb').read()
    t = raw.decode('utf-8-sig')
    print('==', m, 'BOM' if raw.startswith(b'\xef\xbb\xbf') else 'sinBOM', 'CRLF' if b'\r\n' in raw else 'LF',
          'LF sueltos' if b'\r\n' in raw and raw.count(b'\n') != raw.count(b'\r\n') else '')
    moj = re.findall(r'Ã.|Â.|â€|ï»¿|\ufffd', t)
    print(' mojibake', len(moj), 'SIGUE', t.count('<!-- SIGUE -->'))
    pa = Counter(re.findall(r'^#{3,4} (PA-[A-Z]+-\d+)', t, re.M))
    print(' PA dup', [k for k, v in pa.items() if v > 1], 'max', max(pa, key=lambda x: int(x.split('-')[2])))
    hd = Counter(l for l in t.splitlines() if re.match(r'^#{2,4} ', l))
    print(' encabezados dup', [k for k, v in hd.items() if v > 1][:5])
    ids = Counter(re.findall(r'^\| ((?:RF|RN|API|EVT|JOB|PAN|CU|PRM|REP)-[A-Z]+-\d+) \|', t, re.M))
    print(' IDs dup', [k for k, v in ids.items() if v > 1][:8])
    # coherencia de columnas en tablas
    bad = 0
    ls = t.replace('\r\n', '\n').split('\n')
    i = 0
    while i < len(ls):
        if ls[i].startswith('|') and i + 1 < len(ls) and re.match(r'^\|[-| :]+\|$', ls[i + 1]):
            n = len(re.split(r'(?<!\\)\|', ls[i])) 
            j = i + 2
            while j < len(ls) and ls[j].startswith('|'):
                k = len(re.split(r'(?<!\\)\|', ls[j]))
                if k != n:
                    bad += 1
                    if bad <= 3:
                        print('  col', j + 1, n, k, ls[j][:100])
                j += 1
            i = j
        else:
            i += 1
    print(' filas con columnas distintas', bad)
    if m in COLS:
        f = cl.leer_campos_seccion7(p) if hasattr(cl, 'leer_campos_seccion7') else {}
        print(' campos', {c: len(f.get(c, [])) for c in COLS[m]})
