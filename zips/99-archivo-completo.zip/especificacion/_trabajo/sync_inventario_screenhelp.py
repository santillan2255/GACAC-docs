#!/usr/bin/env python3
"""Marca inventario ScreenHelp según borrador / T03b."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOR = ROOT / "_trabajo" / "screenhelp-borrador-nucleo.md"
INV = ROOT / "_trabajo" / "inventario-screenhelp-m01-t02.md"
T03B = ROOT / "anexos" / "T03-UXD-screenhelp-base-m01-t02.md"

HEADING = re.compile(r"^### (PAN-(?:PER|IAM)-\d+) —")
CU_LINE = re.compile(r"^- \*\*CU:\*\* (.+)$")
ROW = re.compile(r"^\| (PAN-(?:PER|IAM)-\d+) \|")


def ids_from_borrador() -> dict[str, str]:
    text = BOR.read_text(encoding="utf-8")
    out: dict[str, str] = {}
    current = ""
    for line in text.splitlines():
        hm = HEADING.match(line)
        if hm:
            current = hm.group(1)
            continue
        cm = CU_LINE.match(line)
        if cm and current:
            out[current] = cm.group(1).strip()
    return out


def main() -> None:
    cu_map = ids_from_borrador()
    t03_ids = set(re.findall(r"^## `(PAN-(?:PER|IAM)-\d+)`", T03B.read_text(encoding="utf-8"), re.M))
    lines = INV.read_text(encoding="utf-8").splitlines()
    out: list[str] = []
    updated = 0
    for line in lines:
        rm = ROW.match(line)
        if not rm:
            out.append(line)
            continue
        sid = rm.group(1)
        if sid not in cu_map:
            out.append(line)
            continue
        cu = cu_map[sid]
        status = "Revisado export (T03b)" if sid in t03_ids else "Borrador (T03b)"
        parts = [p.strip() for p in line.split("|")]
        if len(parts) >= 7:
            old = parts[2]
            if parts[2] != status or parts[3] == "—":
                parts[2] = status
                parts[3] = cu
                updated += 1
            line = "| " + " | ".join(parts[1:-1]) + " |"
        out.append(line)

    # Resumen al final
    body = "\n".join(out)
    if "**Cobertura T03b:**" not in body:
        body += f"\n\n**Cobertura T03b:** {len(cu_map)}/60 pantallas con borrador; artículos en anexo: {len(t03_ids)}.\n"
    else:
        body = re.sub(
            r"\*\*Cobertura T03b:\*\*.*",
            f"**Cobertura T03b:** {len(cu_map)}/60 pantallas con borrador; artículos en anexo: {len(t03_ids)}.",
            body,
        )
    INV.write_text(body, encoding="utf-8")
    print(f"Updated {updated} rows; map {len(cu_map)} screens; T03b {len(t03_ids)} articles")


if __name__ == "__main__":
    main()