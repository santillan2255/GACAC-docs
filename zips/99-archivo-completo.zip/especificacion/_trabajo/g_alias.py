﻿import re
t=open('anexos/T02-IAM-identidad-roles-auditoria.md',encoding='utf-8-sig').read()
a=t.index('#### 4.4.1'); b=t.index('#### 4.4.2')
m={}
for l in t[a:b].splitlines():
    c=[x.strip() for x in l.split('|')]
    if len(c)>4 and c[1].startswith('`') and c[2].startswith('`'):
        old=c[1].strip('`'); new=re.match(r'`([^`]+)`',c[2]).group(1)
        m[old]=new
print(len(m))
import json; json.dump(m,open('_trabajo/g_cierre_alias.json','w',encoding='utf-8'),ensure_ascii=False,indent=0)
for k in ['tec.crew.manage','tec.dispatch.manage','tec.fieldForm.manage','tec.networkDevice.manage','tec.phone.plant','tec.syncConflict.resolve','tec.onCall.manage','tec.phone.numbering','tec.waterQuality.manage','tec.workOrder.read','cob.caja.abrir','bia.ia.preguntar','pla.accesos.ver','plt.uxd.flags.configurar','nfr.incidentes.*','tec.config.manage','tec.cdr.import','tec.work.manage']:
    print(k,'->',m.get(k))
