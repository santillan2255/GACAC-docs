# Informes de la fase 1 del pase de huecos (copia textual de cada agente)

## G1 (M02, M19, T03)

Corregí los 21 huecos de G1 en los tres archivos asignados (M02, M19 y T03), sin tocar ningún otro archivo. La verificación final dio:
- Ningún ID nuevo está definido dos veces. Los IDs que se repiten son las filas de las tablas de alineación (T03 §10.9 y M19 §10.6.A), que repiten el ID a propósito.
- No hay encabezados duplicados.
- No queda ningún `<!-- SIGUE -->`.

Solo queda una parte sin resolver: la API de lectura de llamadas, que les corresponde a M10 y M04.

**Informe (punto 9)**

```
HUE-SRV-04 / HUECO-TRV-04 | M19, T03, M02 | RF-POR-174, PAN-POR-98..103, §10.6.A, API-POR-126/127, SM-PWS-038/039 modificados, SM-PWS-046..048; PAN-CAT-21/22/23 marcadas | M19 es dueño de la ruta y la composición; tabla de componentes embebidos y API por pantalla
HUE-SRV-05 | M02 §18, M19 §18.3 | seed TEN-001 (CLO-RES, ALU-MUN, GAS-RES), INT-100 | Seed único de los ocho servicios; INT-100 de M19 alineado a M02 (texto original conservado)
HUE-SRV-07 | M02 §14 | PRM-CAT-013 | Pasa a lectura derivada de PRM-TEC-024
HUE-SRV-09 | T03 §10.9.12, M02 glosario | RF-UXD-179, 44 claves nuevas | Estados canónicos (estado.servicio.* con alias cat.contract.lifecycle.*), dominios y motivos de baja
HUE-TEL-02 | M19 | RF-POR-175, PAN-POR-103, API-POR-122, SM-PWS-003 | Detalle de llamadas del socio (solo lectura)
HUE-TEL-03 | M02 §14 | PRM-CAT-091/092 | Solo lectura; alias de PRM-TAR-081/082
HUE-TV-02 | M02 §14 | PRM-CAT-093 → cat.equipmentDefaultModality | Generalizado por servicio; comodato en INT y TV (DEC-013)
HUE-ELE-04 | M02 §14 | PRM-CAT-015 | Lectura derivada de PRM-TEC-043
HUE-AG-03 | M02 | RF-CAT-114, RN-CAT-078, EVT-CAT-28, capability cat.contratos.cambiarRegimenMedicion, API-CAT-35 | Comando changeMeteringRegime
HUE-CLO-03 / HUE-ALU-03 | T03 §10.9.12, M02 fichas CLO y ALU | crm.claimType.* (4 claves) | Tipos de reclamo por servicio; ALU con agreement.claimHandler
HUE-GAS-01 | M02, M19 | RF-CAT-095, PRM-CAT-096/110, PAN-CAT-25, API-CAT-41, RN-POR-042, CU-POR-14, API-POR-125, FRM-DDJJ-GAS, §19.1 ARTEFSUMS | DDJJ por servicio (GAS en kcal/h; ELE con vehículos eléctricos)
HUE-ALU-02 | M02 | RN-CAT-076, PRM-CAT-111 | Criterio de cobro de alumbrado por tenant, sin doble cobro
HUECO-TRV-01 (parte M02) | M02, M19 | RF-CAT-080, RN-CAT-045/056..060, PRM-CAT-060..067, JOB-CAT-11, EVT-CAT-23, API-CAT-40, PAN-CAT-20 marcados como reemplazados; ADHSOC → M18 | Adherentes pasan a M18 (DEC-071)
HUECO-OBR-01 (parte M02) | M02 | RF-CAT-115, JOB-CAT-13 | Contratos de obra creados desde EVT-TEC-25
HUECO-OBR-03 | M19 | RF-POR-176, PAN-POR-30, API-POR-123 | Bloque de plan de cuotas sobre API-TAR-066
HUECO-CEM-02 | M19, T03 | RF-POR-177, PAN-POR-104, API-POR-124, SM-LND-034, seed CEM-BUSCAR-DEMO | Buscador público de difuntos condicionado a PRM-SOC-050
HUECO-SAN-01 | M02 | RN-CAT-077 | Prohibido el precio por unidad de sangre
HUECO-OTR-02 | M02 ficha OTR | — | Los traslados no médicos van a viaje RF-SOC-074 + RF-SOC-076
HUECO-SEP-02 / HUECO-TAS-03 | M02 §19.1 | — | Solo constancia; BENSOC y CLASESER sin editar
HUE-GAS-02 | M02 §21 | PA-CAT-17, PRM-CAT-112 | Gas envasado; se asume la recomendada (DEC-072)
HUECO-TAS-01 | M02 §21 | PA-CAT-18 | Se asume la recomendada (DEC-072)
HUECO-OTR-03 | M02 §21 | PA-CAT-19, PRM-CAT-113 | Correo y SMS; se asume la recomendada (DEC-072)
```

**(a) Eventos y jobs nuevos para T11**
- **EVT-CAT-28 `cat.contract.meteringRegimeChanged`:** lo produce M02. Payload: `contractId`, `tenantServiceId`, `fromRegime`, `toRegime`, `effectiveAt`, `meteringPointId`, `commandId`. Lo consumen M03, M04, M05 y POR.
- **JOB-CAT-13 `cat:crear-contratos-obra`:** se dispara con EVT-TEC-25 (`tec.levy.approved`) y es idempotente por (`workId`, `propertyId`).
- **Ya marcados como reemplazados:** EVT-CAT-23 pasa a EVT-SOC-01 y JOB-CAT-11 pasa a M18.

**(b) Referencias cruzadas que otros anexos deben agregar**
- M03 y M05 deben consumir EVT-CAT-28.
- M04:
  - Validación recíproca de ALU (RN-CAT-076) y base de cálculo según el régimen de medición.
  - API de tasación de llamadas para API-POR-122.
- M10: API de lectura de llamadas atribuidas.
- M18:
  - Marcar PAN-SOC-30..33 como embebidas en PAN-POR-98..101.
  - API-SOC-061 la consume PAN-POR-104.
- M17: marcar PAN-INS-30 como embebida en PAN-POR-102.
- M09: configurar los subtipos de reclamo con `crm.claimType.*`.
- T05: colección `contractMembers` reemplazada y campos nuevos (`meteringRegime`, `agreement`, `workRef`/`levyRef`, `templateRef`/`power`/`vehicle`).
- T07: ADHSOC pasa a M18 y ARTEFSUMS a M02.

**(c) Partes no resueltas y motivo**
- BENSOC y CLASESER en M02 §19.1 quedan para G5 (HUECO-SEP-02 y HUECO-TAS-03).
- API-POR-122 declara la fachada, pero sus APIs de origen todavía no existen en M10 y M04.

**(d) [REF-PENDIENTE] de T12**
- Línea 688 (CLO): `dict:crm.claimType.clo.desborde` y `dict:crm.claimType.clo.obstruccion`, en T03 §10.9.12 (RF-UXD-179).
- Línea 906 (ALU): `dict:crm.claimType.alu.luminariaApagada`, en T03 §10.9.12, junto con PRM-CAT-111 y `agreement.claimHandler` de M02.

## G2 (M03, M04, M05, M06)

Terminé los huecos del grupo G2 en M03, M04, M05 y M06; no quedó ninguno sin tratar. La verificación salió limpia en los cuatro anexos: ningún ID definido dos veces, ningún encabezado repetido, ningún `<!-- SIGUE -->` y ningún carácter UTF-8 dañado. No borré contenido: lo que cambia de dueño quedó marcado como "Reemplazado por… (HUE-ID)" o "Componente embebido en…", con el texto original conservado.

## Informe (punto 9 de las reglas comunes)

| HUE-ID | Archivo(s) | IDs creados / modificados | Resumen |
|---|---|---|---|
| HUE-SRV-04 | M03, M05 | PAN-MED-31/32/33 → embebidos en PAN-POR-47/48/49; PAN-FAC-43/44/45 → PAN-POR-38/39/12 | Las pantallas del socio pasan a ser componentes del portal (M19) y se conservan API-MED-70..73 y API-FAC-150..154. |
| HUE-SRV-05 | M04 | §9.3.9 (texto original conservado), ESC-TAR-03, fila INT-100 de §18 | El ejemplo usa los valores de M02 §18 (abono 15.000, instalación 20.000, PROMO-INT-50x3) y el primer comprobante da **ARS 30.000,00**. |
| HUE-INT-01 | M04 | RF-TAR-115, RN-TAR-246, PRM-TAR-169, ESC-TAR-31; `eventCharges` (`equipment_not_returned`, `equipmentKinds`, `returnGraceDays`), `preloadedCharges.origin`, PAN-TAR-18, §12.2 | Cargo por equipo no devuelto, apagado por defecto, con aprobación según RN-MOR-101; consume EVT-STK-07 y EVT-STK-08 y usa PRM-CAT-094 como plazo. |
| HUE-TEL-03 | M04 | RN-TAR-083, PRM-TAR-081/082, fila 081/082 de §14.3 | M04 es el único dueño de los conceptos CPP e internacional; PRM-CAT-091/092 quedan como alias de solo lectura. |
| HUE-ELE-02 | M05 | RF-FAC-174, RN-FAC-154, PRM-FAC-161/162, PAN-FAC-47, API-FAC-158/159, `billingRunItems.preReview`, estado `reviewPending` (§8.3), motivo `PRE_REVIEW_RETURNED`, escenario 19 | Cola de revisión previa por categoría o condición especial (grandes usuarios, MER-003) antes de pedir el CAE. |
| HUE-ELE-03 | M04 | PA-TAR-14 (opciones nuevas y Estado), RF-TAR-045, RN-TAR-231 | Compensación monetaria (Ley 27.424) por defecto y balance neto como opción del régimen, según DEC-060. |
| HUE-AG-03 (parte M03) | M03, M04 | RF-MED-128, ESC-MED-36, fila EVT-CAT-28 en §12.2 de M03 y de M04, nota en RF-MED-012 | Al cambiar el régimen de medición se crea el punto de medición (RF-MED-012) o se registra el retiro (RF-MED-022); el reproceso no duplica. |
| HUE-CLO-02 | M04, M05 | RN-TAR-247, error `TAR-E-RELATED-MISSING` (§9.11), RN-TAR-015, ESC-TAR-32; RF-FAC-175, RN-FAC-155, JOB-FAC-01, §9.1, motivo `RELATED_SERVICE_MISSING`, `serviceDependencies`, escenario 20 | Si falta el agua relacionada, esa cuenta queda excluida y el lote sigue; JOB-FAC-01 procesa CLO después de AG. |
| HUE-GAS-03 | M04, M03 | PRM-TAR-168, RN-TAR-035, §7.10, PAN-TAR-09, CTR-TAR-38, PA-TAR-19 (Estado "Resuelta por HUE-GAS-03"); en M03 se marcan como reemplazados PAN-MED-20, PRM-MED-070..072, `gasCorrectionFactors`, API-MED-66, fila `FACTOR_CAL` de §19, y se ajustan RN-MED-069 y CTR-MED-06 | M04 es dueño de los factores de gas y M03 los lee. |
| HUE-ALU-02 (M04) | M04 | RF-TAR-057 | Antes de publicar una regla de alumbrado se aplica la "RN-CAT de exclusión ALU (HUE-ALU-02)". |
| HUE-ELE-01 / HUE-GAS-04 (M03) | M03 | RF-MED-129, API-MED-78, ESC-MED-37 | Volumen comprado por punto de compra/frontera, disponible para que M12 controle la factura del mayorista. |
| HUECO-OBR-01 | M04 | RF-TAR-116, JOB-TAR-14, campos nuevos de `worksInstallmentPlans`, §12.2, ESC-TAR-33 | Al aprobarse la obra se crea un plan de cuotas por beneficiario, sin duplicar (clave `workId + propertyId`); si todavía no hay contrato, el plan queda `pendingContract`. |
| HUECO-OBR-03 | M04 | RF-TAR-119, API-TAR-066 | Plan de cuotas de obra en solo lectura para el portal (cuota n/N, saldo, unidades). |
| HUECO-OBR-05 | M04 | RN-TAR-071, §7.16, fila nueva en §19.2 (`SERSOC_EXTRAS.CNT_*`) | `worksInstallmentPlans` es la única fuente del plan. |
| HUECO-CEM-01 | M04 (+M06) | RF-TAR-117, RN-TAR-248, disparador `social_act`, `planKind = right_acquisition`, `productPrices.kind` (`cemetery_*`), ESC-TAR-34 | Adquisición del derecho al contado o en cuotas (reutiliza el plan de RF-TAR-031), mantenimiento periódico y cargo por acto disparado por EVT-SOC-06. |
| HUECO-SAL-01 | M04 | RF-TAR-118, RN-TAR-249, PRM-TAR-170, `tripPricing`, disparador `social_trip`, advertencia `TAR-W-TRIP-DATA-MISSING`, ESC-TAR-35 | Cargo por traslado: km × tarifa, importe fijo, viaje corto, característica, cubierto con coseguro o no cubierto, y lista de no asociados. |
| HUECO-VIV-01 | M04 | RN-TAR-075 | El precio vigente es el último con fecha ≤ fecha del período facturado. |
| HUECO-VIV-02 | M04 | RN-TAR-075; reemplazados PAN-TAR-29 (→ PAN-SOC-17), PRM-TAR-072/073 (→ PRM-SOC-019/018), `productPrices` de vivienda (→ API-SOC-034), filas de §2, §7.23, §14.3 y §19.2 | M18 es dueño de los precios y mínimos de vivienda; M04 solo calcula. |
| HUECO-TAS-02 | M06 | RF-FIS-164, RN-FIS-127, `thirdPartyAgreements.moraPolicy`, escenario 43 | El saldo de terceros queda fuera del saldo elegible de mora por defecto; los recargos solo se aplican si el convenio los define. |
| HUECO-TAS-03 | M06 | RF-FIS-163, RN-FIS-126, `taxDefinitions.nature` (`thirdPartyTax`, `pendingClassification`) y `classification`, filas `IMPUESTO`/`CON_TASAS` de §7.36, escenario 42 | Regla para clasificar cada fila como tributo propio, percepción, tributo de terceros o concepto de terceros, según el organismo de `ORIGEN` y la existencia de convenio. |
| HUECO-CAP-04 | M06 | RF-FIS-161, RN-FIS-124, PRM-FIS-122, §7.37 `conceptFiscalCases`, escenario 40 | El aporte de capital es no gravado, queda fuera del neto y de todas las bases, y se informa en `ImpTotConc` (o fuera del comprobante, si se configura). |
| Derechos de sepultura | M06 | RF-FIS-162, RN-FIS-125, PRM-FIS-123, §7.37, escenario 41 | Tratamiento de IVA por concepto (adquisición, mantenimiento y actos), con momento fiscal configurable e independiente del diferimiento contable de PA-CON-17. |

**(a) Eventos y jobs nuevos para T11.** No creé eventos nuevos. El único job nuevo es **JOB-TAR-14 `tar:crear-planes-obra`**:
- Productor: M04.
- Se dispara con EVT-TEC-25 y con EVT-CAT-09 de contratos tipo 17.
- Es idempotente por (`workId`, `propertyId`).

**(b) Referencias cruzadas que otros anexos deben agregar:**
- **T11 §12.3:** agregar M04 como consumidor de EVT-STK-07, EVT-STK-08 (`chargeApproved`), EVT-TEC-25 y EVT-SOC-06.
- **M10, M13 y M18 (productores):** mismas altas de consumidor.
- **M18 / T11:** EVT-SOC-07 debería incluir también `characteristicCode`, `memberStatus` y `originalTripId` en el payload (lo necesita RN-TAR-249).
- **M13:** puede usar `tar.quote` (API-TAR-064) para obtener el importe del cargo por equipo no devuelto (RN-TAR-246).
- **M19:** el bloque "Plan de cuotas de obra" de PAN-POR-30 usa API-TAR-066; PAN-POR-47/48/49, 38/39 y 12 deben citar los componentes PAN-MED-31..33 y PAN-FAC-43..45.
- **M12:** consumir API-MED-78 / RF-MED-129 para el control de la factura del mayorista (HUE-ELE-01, HUE-GAS-04).
- **M02:**
  - Marcar PRM-CAT-091/092 como de solo lectura, con alias a PRM-TAR-081/082.
  - Aclarar en §18 el alcance de PROMO-INT-50x3: el texto del seed es ambiguo y lo interpreté como aplicado al abono.
- **M08:** en RF-MOR-068, excluir el saldo de terceros según RN-FIS-127 / `moraPolicy`.
- **T07 (G5):** migrar `SERSOC_EXTRAS.CNT_*` a `worksInstallmentPlans`; clasificar `CON_TASAS` e `IMPUESTO` con RN-FIS-126; migrar `FACTOR_CAL` a M04 y `PRECIOSVIV` a M18.
- **T03:** dar de alta las capabilities nuevas `fac.revisionPrevia.ver`, `fac.revisionPrevia.aprobar` y `pwa.planObra.ver`.
- **M15 / M17:** el asiento del aporte de capital va al capital social (RN-FIS-124).

**(c) Partes no resueltas:**
- **Corrección de gas:** CTR-MED-06 dice que M03 calcula la cantidad corregida y RN-TAR-035 de M04 también la describe. Resolví quién es dueño de los factores, pero no quién aplica la corrección. Hace falta una decisión para evitar que se corrija dos veces.
- **Encuadre fiscal:** el del aporte de capital y el de los conceptos de sepultura quedó marcado [VERIFICAR] con el contador. Los conceptos de sepultura no tienen clase fiscal por defecto: el tenant tiene que adoptarla.
- **PA-TAR-19, cargos por evento:** la parte de cargos por evento (CTR-TAR-39) sigue con la opción A como supuesto; HUE-GAS-03 solo resolvió la de factores de gas.

**(d) IDs que resuelven las [REF-PENDIENTE] de T12 parte 2:**
- **Ficha CEM** (tratamiento de IVA del derecho y del mantenimiento): **RF-FIS-162 / RN-FIS-125** (y `conceptFiscalCases`, §7.37 de M06).
- **Ficha CAP** (aporte de capital): **RF-FIS-161 / RN-FIS-124**.

Encoding checks out fine, no stray markers found. Cross-referencing the other IDs against the summary confirms they all exist, though the new revisionPrevia capabilities seem worth flagging separately.

Now I'm ready to put together the final report, organizing it as a table with columns for hueco ID, affected files, relevant IDs, and a brief summary per rule 9.



## G3 (M07, M08, M12, M15)

Terminé los 19 huecos de G3 dentro de M07, M08, M12 y M15. No toqué el registro de huecos, las preguntas abiertas, el maestro, T05, T11 ni T12. En la verificación final no aparecen IDs ni encabezados duplicados, ni marcas `<!-- SIGUE -->`, y la codificación UTF-8 está bien. Los JOB que se repiten en M08 y M15 ya venían así: cada job figura en la tabla de procesos y en la de §12.3.

## Informe por hueco

| Hueco | Archivo(s) | IDs creados / modificados | Resumen |
|---|---|---|---|
| HUE-SRV-04 | M08 | PAN-MOR-39, -40, -41 (mod.); nota en §10 | Pasan a ser componentes embebidos: los dos primeros en PAN-POR-46 y el tercero en PAN-POR-37. Las API-MOR-86 a 95 no cambian. |
| HUE-TEL-04 | M08 | RN-MOR-137, RF-MOR-222, PRM-MOR-199, ESC-MOR-51; ampliación de §7.10, §7.18 y §7.21 | La suspensión es un bloqueo de llamadas salientes; entrantes y emergencias siguen habilitadas siempre; requiere validación legal. |
| HUE-TV-03 | M08 | RN-MOR-138, RF-MOR-222, PRM-MOR-200, ESC-MOR-52 | Dos modos: `restricted` (grilla mínima) e `interrupted`; el decodificador no se retira. |
| HUE-AG-02 | M08 | RN-MOR-139, RN-MOR-085 (mod.), PRM-MOR-201, ESC-MOR-53 | Reducción de caudal o interrupción, habilitables por concesión y con caudal mínimo vital. |
| HUE-CLO-01 | M08 | RN-MOR-140, RF-MOR-222, ESC-MOR-54 | Sin suspensión física (`noSuspension`); solo avisos, intereses, convenio y gestión. |
| HUE-ALU-01 | M08 | RN-MOR-141, RF-MOR-223, PRM-MOR-202, ESC-MOR-55 | La deuda de terceros no habilita el corte, salvo que lo prevean el convenio y la norma. |
| HUECO-TAS-02 | M08 | RN-MOR-142, RF-MOR-068 (mod.), PRM-MOR-202, -203 | Lo de terceros queda fuera del saldo elegible por defecto; inclusión y recargos solo si el convenio lo autoriza. |
| HUECO-SEP-01 | M08 | RN-MOR-143, RF-MOR-224, PRM-MOR-204, ESC-MOR-56 | Restricción `tenantPolicy` de cobertura social; M18 la evalúa en RF-SOC-032. |
| HUECO-SAN-02 | M08 | RN-MOR-144, RN-MOR-088 (mod.), PRM-MOR-205, ESC-MOR-57 | Se genera una tarea de revisión en T11 para el responsable del servicio social; nunca hay suspensión. |
| HUE-ELE-05 | M08 | RN-MOR-145, RF-MOR-221, RF-MOR-119 (mod.), PRM-MOR-206, PA-MOR-10 (avance), ESC-MOR-58 | Plantilla de plataforma ERSeP marcada `toValidate`; mientras no se valide, cada caso va a revisión. |
| HUECO-OBR-02 (M08) | M08 | RN-MOR-146, PRM-MOR-207, ESC-MOR-59 | El convenio solo refinancia cuotas de obra vencidas; el cobro normal sigue por el plan tipo 17. |
| HUE-TV-01 | M12, M15 | RF-CMP-154, -155; RN-CMP-075; JOB-CMP-09; EVT-CMP-17; PAN-CMP-26; API-CMP-123, -124; PRM-CMP-115, -116; ESC-CMP-24, -25; M-128; PRM-CON-188 | Liquidación mensual de derechos de señales por abonados activos por paquete, con devengo del costo en M15. |
| HUE-ELE-01 | M12, M15 | RF-CMP-149, -150, -151, -153; RN-CMP-073, -074; JOB-CMP-10; EVT-CMP-16; PAN-CMP-25; API-CMP-121, -122; PRM-CMP-113; ESC-CMP-21, -23; M-126; PRM-CON-186; RN-CON-121 | La factura del mayorista (FI-INT-33) se controla contra la medición de frontera de M03, con balance de lo comprado contra lo facturado. |
| HUE-GAS-04 | M12, M15 | RF-CMP-152; PRM-CMP-114; ESC-CMP-22; M-127; PRM-CON-187 | Mismo circuito que la energía, con m³ corregidos. |
| HUECO-SEP-03 | M15 | RN-CON-122; M-129, -130, -131; PRM-CON-189, -190, -191, -194; ESC-CON-25 | Rol `socialSubsidy` con contrapartida `socialSubsidyFund`; consume EVT-SOC-04. |
| HUECO-OTR-04 | M15, M07, M08 | RN-CON-123; M-132, -133; M-45 y PRM-CON-169 (mod.); RF-COB-190; enum de `creditBalances.origin` (mod.); RF-MOR-179 y EVT-MOR-16 (mod.); `refundMode`; ESC-CON-26, ESC-MOR-60 | El depósito es pasivo y se devuelve como crédito a la cuenta. M-45 deja de asentar la devolución en ese modo, para no duplicarla. |
| HUECO-CAP-01 | M15 | RF-CON-098, -150, -151 (pasan a O5); RF-CON-161 (nuevo, O10); RF-CON-075 (nota) | Suscripción, integración y conciliación pasan a O5; rescate, reservas y distribución quedan en O10. |
| HUECO-CAP-02 | M07 | RF-COB-176 (mod., pasa a O5) | Queda solo como conciliación de cierre, sin efecto en el auxiliar; la integración la registra M17 desde `cob.payment.confirmed`. |
| HUECO-CEM-04 | M15 | PA-CON-17; RN-CON-124; M-134, -135; PRM-CON-192, -193; JOB-CON-23; ESC-CON-27 | La opción A, ingreso al otorgar el derecho, queda por defecto y configurable. La B, ingreso diferido, se activa con un parámetro. |

## (a) Eventos y jobs nuevos para registrar en T11
- **EVT-CMP-16** `cmp.supplyBalance.approved`. Productor: M12. Payload: `balanceId, kind, serviceId, zoneId, period, purchasedQty, boundaryMeasuredQty, billedToUsersQty, lossQty, lossPct`. Consumidores: M03, M06 y T10.
- **EVT-CMP-17** `cmp.signalRightsSettlement.approved` / `.voided`. Productor: M12. Payload: `settlementId, contractId, supplierId, period, lines[{packageId, activeSubscribers, amount}], total, currency, serviceId`. Consumidores: M15, M14 y T10.
- **EVT-MOR-16** cambia: en `.refunded` el payload suma `refundMode`.
- **Jobs nuevos:** `cmp:liquidar-derechos-senales` (JOB-CMP-09), `cmp:controlar-compra-mayorista` (JOB-CMP-10) y `con:devengar-derechos-sepultura` (JOB-CON-23).

## (b) Referencias cruzadas que otros anexos deben agregar
- **M19 (G1):** que PAN-POR-46 y PAN-POR-37 citen los componentes PAN-MOR-39, -40 y -41.
- **M02 (G1):**
  - Un informe o servicio de abonados activos por paquete a una fecha de corte, para JOB-CMP-09.
  - El paquete de grilla mínima de TV que usa PRM-MOR-200.
- **M03 (G2):** un servicio interno de medición propia por punto y período (puntos `purchase`/`boundary`) y el consumo de EVT-CMP-16 en RF-MED-101.
- **M04 y T07:** el `FACT_EPEC`, hoy mapeado a `energyPurchaseBills` con dueño M04, debería apuntar a M12, donde queda `supplierInvoices.wholesaleSupply`.
- **M05 (G2):** las clases de ítem facturable "depósito en garantía", "aporte al fondo de subsidio" y "derecho de sepultura".
- **M06 (G2):**
  - La marca del convenio con terceros que autoriza la inclusión en el saldo elegible, los recargos y el corte.
  - La clase fiscal del depósito y del derecho de sepultura.
- **M10 (G4):** la regla de HUECO-OBR-02 (plan tipo 17 por defecto) y la OT de reducción de caudal.
- **M18 (G5):**
  - El parámetro de carencia de rehabilitación.
  - El consumo de la condición "cobertura suspendida por mora" en RF-SOC-032.
  - Agregar M15 como consumidor de EVT-SOC-04 y EVT-SOC-05.
  - Registrar el depósito ortopédico como garantía de M08.
- **M17:** registrar que RF-COB-176 ya es solo una conciliación.
- **T11:** el tipo de tarea `review` para el banco de sangre y los consumidores nuevos de EVT-COB-09 y EVT-MOR-16.
- **T06:** que FI-INT-33 apunte a RF-CMP-149 y se agregue la integración con la distribuidora de gas.
- **`02-preguntas-abiertas.md`:** registrar PA-CON-17.

## (c) Partes no resueltas
- **Días, horarios y umbrales climáticos de la ventana ERSeP, grilla mínima de TV, caudal mínimo de agua, régimen de emergencias de telefonía y meses de cobertura social:** quedan como parámetros sin valores legales. Dejé todo marcado "requiere validación legal" o `toValidate`, porque no hay fuente normativa relevada.
- **Carencia de rehabilitación de la cobertura social:** corresponde a G5 (M18).
- **Regla principal de HUECO-OBR-02:** corresponde a G4 (M10).
- **Disparador de la devolución del depósito ortopédico:** M18 no tiene un evento de devolución del préstamo. Lo resolví vía la garantía de M08, pero M18 tiene que registrarla.

## (d) IDs reales para las marcas [REF-PENDIENTE] de T12 parte 2
- **Ficha SEP, línea 188** (fondo de subsidio): RN-CON-122, M-129 a M-131, PRM-CON-189 a PRM-CON-191 y PRM-CON-194.
- **Ficha CEM, línea 284** (venta del derecho): PA-CON-17, RN-CON-124, M-134 y M-135, PRM-CON-193 y JOB-CON-23.
- **Ficha OTR, línea 828** (depósito en garantía): PRM-CON-169 (`guaranteesHeld`), RN-CON-123, M-132 y M-133, y RF-COB-190.

Confirming there's no existing git repo and encoding is fine, and double-checking that the new RN-MOR, RF-CMP, and M-126 IDs don't collide with anything pre-existing, plus verifying the M12 §14.9 heading is new. Everything checks out, so I'm ready to compose the final report.



## G4 (M09, M10, T06, T09, T10)

Terminé los huecos de G4. Edité solo M09, M10, T06, T09 y T10. En la verificación final los cinco archivos no tienen IDs ni encabezados duplicados, no quedan marcas `<!-- SIGUE -->` y la codificación UTF-8 está intacta: T06 conserva su BOM original y el resto sigue sin BOM. No toqué `05-registro-huecos.md`, T11, T12 ni los archivos de otros grupos. Abajo va el informe del punto 9.

## Informe por hueco

| HUE-ID | Archivo(s) | IDs creados / modificados | Resumen |
|---|---|---|---|
| HUE-SRV-04 | M10 | PAN-TEC-57, 58 y 59 (modificados) y una regla de composición | Las tres pantallas pasan a ser componentes que M19 monta en sus propias pantallas: reservar visita en PAN-POR-34, seguimiento en PAN-POR-35 y factibilidad en PAN-POR-34/35 y en la gestión PAN-POR-33. Las rutas de M10 no se publican y las API API-TEC-40 y 41 no cambian. |
| HUE-SRV-06 | T09 | JOB-COM-34 a 41 (nuevos), nota de equivalencia, §9.7, §9.8, §12.3 y §16 | Se mantiene vigente la tabla 01 a 24, igual al catálogo de T11. Los jobs del borrador `_trabajo/t11gen-job.md` sin equivalente se numeraron desde 34. La nota mapea cada número del borrador (01 a 33) a su número vigente. Las referencias sueltas ahora apuntan a JOB-COM-34 (`com:consumir-eventos`), JOB-COM-15 (`com:campana-lote`) y JOB-COM-35 (`com:enviar-mensajes`). |
| HUE-SRV-07 | M10 | RF-TEC-011, RN-TEC-005 y PRM-TEC-024 (modificados) | PRM-TEC-024 es el único dueño del requisito de factibilidad, con valor por servicio. Es `required` en INT, TV, TEL, ELE, AG, GAS y también, explícitamente, en CLO. ALU y los servicios sin red quedan en `never`. PRM-CAT-013 de M02 pasa a ser solo lectura derivada. |
| HUE-ELE-04 | M10 | RF-TEC-106 y PRM-TEC-043 (modificados), RN-TEC-114 (nuevo) | PRM-TEC-043 es el único parámetro del certificado de instalador, por servicio y jurisdicción. Vale `require` en ELE Córdoba (Ley 10281) y en GAS, y `warn` en el resto. PRM-CAT-015 queda como lectura derivada. |
| HUE-SRV-08 | T10 | REP-BIA-015 a 024 (nuevos, §15.5.1), RF-BIA-090, conteo del catálogo | Hay un código de informe por regulador y servicio, enlazado a RF-FIS-139 y 144 a 150. M06 no se editó. |
| HUECO-TRV-05 | T10 | Nota de verificación en §15.4 | REP-SOC-01 a 23, REP-INS-01 a 20, REP-VEN y REP-CMP ya estaban consolidados e iguales a sus anexos. M13 a M16 y M19 no tienen REP propios. |
| HUE-INT-03 | M09 | RF-CRM-258, PRM-CRM-132, §18.1 (nuevos); PAN-CRM-14 y `crmSlaPolicies` (`templateCode`, `legalValidation`) | La plantilla de plataforma ENACOM (Res. 733/2017) trae cinco motivos con plazos iniciales, todos marcados "a validar legalmente". El tenant la adopta desde PAN-CRM-14. |
| HUE-CLO-03 / HUE-ALU-03 | M09 | RF-CRM-259, PRM-CRM-134 (nuevos); `crmCaseSubtypes` (`claimTypeKey`, `externalDerivation`, `regulatoryReasonCode`); §18 | Se agregan los reclamos de desborde, obstrucción y luminaria apagada. La derivación a la cooperativa, al municipio o según convenio sale del convenio del servicio en M02 (`domainAttributes.agreement.claimHandler`). |
| HUE-TV-04 | M10, T06 | RF-TEC-183 y 194, `provisioningProfiles`, `decoders[]`, código de error nuevo; FI-INT-86 | M10 agrega los perfiles de TV (paquete, grilla, decodificadores, paquetes del CAS). En T06, FI-INT-86 tiene ahora el contrato del conector CAS: comandos, solicitud y respuesta, idempotencia, errores normalizados y conciliación. |
| HUE-GAS-05 | M10, M09, T09, T10 | M10: RF-TEC-231 a 233, RN-TEC-116, §9.11.1, PRM-TEC-152 a 154, PAN-TEC-61 y 62, API-TEC-51 y 52, EVT-TEC-35 y 36, JOB-TEC-17, REP-TEC-30. M09: RF-CRM-122 (precisión), RF-CRM-260, PRM-CRM-133, `continuous`. T09: tres tipos `tec.emergency.*`. T10: REP-TEC-030 | M10 cubre guardias, escalamiento y protocolo de emergencia. M09 suma un SLA de seguridad 24×7. T09 suma la plantilla de aviso de emergencia. |
| HUECO-OBR-01 | M10, T09 | RF-TEC-173, §9.10, EVT-TEC-25 (payload y consumidores); tipo T09 `tec.levy.approved` | El evento EVT-TEC-25 lo consumen M02, que crea los contratos tipo 17 (JOB-CAT-13), y M04 (`worksInstallmentPlans`). M08 deja de consumirlo y T09 avisa al frentista. |
| HUECO-OBR-02 | M10 | RN-TEC-115, PRM-TEC-155 | Por defecto la obra se cobra con un plan de cuotas tipo 17. El convenio de M08 solo refinancia cuotas vencidas. |
| HUE-TEL-05 | M10 | PA-TEC-19, RF-TEC-234, `numberPortings`, PRM-TEC-156, PAN-TEC-63, API-TEC-53 | Recomendada la opción A: "No aplica" por defecto, habilitable por tenant con numeración propia. |
| HUE-AG-01 | M10, T10 | PA-TEC-20, §5.20 (RF-TEC-235 y 236), PRM-TEC-157, PAN-TEC-64, API-TEC-54, EVT-TEC-37, REP-TEC-29; T10 REP-TEC-029 y REP-BIA-024 | Recomendada la opción A: los controles de calidad se registran en M10 y el informe sale por M06 y T10. |
| Ficha GAS paso 6 (T12) | T06 | FI-INT-114 (nueva), §13.1, §13.2 y resumen (114 fichas) | Nueva ficha para el intercambio de formularios con la distribuidora de gas de referencia. |
| Tipos T09 de T12 parte 2 | T09 | `soc.cemeteryAct.scheduled`, `soc.cemeteryAct.performed`, `soc.housing.allocated`, `soc.housing.delivered`, `soc.loan.overdue`; §12.2 | Se usan los nombres canónicos de M18 y T11. Los tipos que no tienen evento entran por el comando `com.communications.emit`. |
| HUECO-SEP-02 (parte T09) | — | Sin cambios | Las filas de BENSOC afectadas están en T09: glosario "Beneficio" (línea 95), RF-COM-106 (línea 259), CTR-COM-18 (cerca de la línea 1950) y la trazabilidad (cerca de la línea 2205). G5 define su destino. |

## (a) Eventos y jobs nuevos para T11

- **EVT-TEC-35** `tec.emergency.declared` / `tec.emergency.closed`.
  - Productor: M10.
  - Payload: workOrderId, caseId?, kind, serviceCode, contractId?, zoneId?, onCallResourceId, protocolVersion, declaredAt; al cerrar se agregan arrivedAt, safeAt y preventiveCutoff?.
  - Consumidores: T09, M09 y T10.
- **EVT-TEC-36** `tec.onCall.escalated`.
  - Productor: M10.
  - Payload: workOrderId, level, notifiedResourceId, at.
  - Consumidores: T09 y M09.
- **EVT-TEC-37** `tec.waterSample.outOfLimit`.
  - Productor: M10.
  - Payload: sampleId, samplingPointId, parameters[{code, value, limit}], takenAt.
  - Consumidores: M09, T09 y M06.
- **EVT-TEC-25** cambia respecto de lo que hoy dice T11:
  - Payload nuevo: workId, levyVersion, installments, firstDueDate?, beneficiaries[{beneficiaryId, propertyId, accountId, holderPersonId, amount}]. Ya no lleva `contractId`, porque el contrato todavía no existe.
  - Consumidores: M02, M04 y T09. Salen M05 y M08.
- **Jobs nuevos:**
  - JOB-TEC-17 `tec:escalar-guardia`, cada minuto.
  - JOB-COM-34 a 41: `com:generar-comunicaciones`, `com:despachar`, `com:reintentar`, `com:verificar-hitos`, `com:notificar-publicacion`, `com:informe-encuesta`, `com:evaluar-audiencia` y `com:avisos-interrupcion`.

## (b) Referencias cruzadas para otros anexos

- **M02 (G1):** PRM-CAT-013 y PRM-CAT-015 deben quedar como lectura derivada de PRM-TEC-024 y PRM-TEC-043. JOB-CAT-13 y RF-CAT-115 ya están alineados.
- **M04 (G2):** debe consumir EVT-TEC-25 y crear `worksInstallmentPlans`.
- **M08 (G3):** debe quitar EVT-TEC-25 de sus eventos consumidos y dejar el convenio solo para refinanciar cuotas vencidas.
- **M19 (G1):** debe declarar que PAN-POR-33, 34 y 35 montan los componentes de M10 (PAN-TEC-57, 58 y 59).
- **T03 (G1):** debe publicar `dict:crm.claimType.clo.desborde`, `.clo.obstruccion` y `.alu.luminariaApagada`. Hoy esas claves no existen en T03.
- **M06:** puede citar REP-BIA-015 a 024 en RF-FIS-139 y 144 a 150.
- **M18 (G5):** si prefiere un evento en lugar del comando para programar un acto de cementerio, tendría que crearlo.
- **T05:** faltan las colecciones nuevas de M10 (`onCallShifts`, `emergencyProtocols`, `numberPortings`, `waterSamplingPoints`, `waterSamples`).

## (c) No resuelto y por qué

- La ola de HUE-INT-03 figura como O2 en el registro, pero el RF quedó en O3 para coincidir con los SLA de reclamos de M09 (RF-CRM-103).
- Los plazos ENACOM, los tiempos del SLA de seguridad y los de guardia son valores iniciales a validar legal y operativamente. No existe fuente normativa relevada.
- Los formularios y el canal de la distribuidora de gas en FI-INT-114 quedan "a relevar" con el tenant piloto.

## (d) IDs reales para los [REF-PENDIENTE] de T12

| Ficha | Referencia |
|---|---|
| INT | REP-BIA-015 |
| TEL | REP-BIA-016 |
| TV | REP-BIA-017 |
| ELE | REP-BIA-018 (ERSeP) y REP-BIA-019 (Secretaría de Energía) |
| AG | REP-BIA-020 y REP-BIA-024 (calidad del agua) |
| CLO | REP-BIA-021 |
| GAS | REP-BIA-022; aviso de emergencia: tipo T09 `tec.emergency.notice` (EVT-TEC-35); intercambio de formularios: FI-INT-114 |
| ALU | REP-BIA-023 |
| OBR (parte 2) | Tipo T09 `tec.levy.approved` (EVT-TEC-25) |
| CEM (parte 2) | `soc.cemeteryAct.scheduled` (por comando) y `soc.cemeteryAct.performed` (EVT-SOC-06) |
| VIV (parte 2) | `soc.housing.allocated` y `soc.housing.delivered` (EVT-SOC-08) |
| OTR (parte 2) | `soc.loan.overdue` (JOB-SOC-10, por comando) |

Ahora voy a redactar el informe final en español, que debe ser completo según el punto 9, incluyendo una tabla por cada hueco con los apartados (a)-(d), manteniendo todo claro y legible.



## G5 (M01, M13, M17, M18, T07)

Terminé los cinco anexos de G5. La verificación final no encontró IDs ni encabezados duplicados, ni restos de `<!-- SIGUE -->`, y todos los IDs propios citados existen. Hay un punto que tenés que arbitrar: T05 divide `BENSOC` entre M18 y M04 (CTR-DAT-27), y eso contradice el destino único que fijé con el diccionario de ProCoop (detalle en "Ajustes para T05").

## Informe por hueco

| HUE-ID | Archivo(s) | IDs creados/modificados | Resumen |
|---|---|---|---|
| HUE-SRV-04 | M13 | PAN-STK-40 (mod.) | Pasa a ser un componente embebido en PAN-POR-30 (bloque "Equipos"). La ruta original queda marcada como reemplazada. |
| HUECO-TRV-01 | M18, M01, T07 | M18: §2.2 y RF-SOC-149 (nuevo). M01: RF-PER-109 a 117, RN-PER-082 a 091, PRM-PER-064 a 072, EVT-PER-19, JOB-PER-06, API-PER-38 a 40, PAN-PER-10, REP-PER-10, AC-PER-23, §7.10, §8.7, §19 y encabezado. T07: ADHSOC y RN-MIG-054 | M18 es dueño único (DEC-071). En M01 todo queda como "Reemplazado por <ID de M18>" con el texto original. PAN-PER-10 queda de solo lectura. RF-SOC-149 reemplaza la importación de RF-PER-114. |
| HUECO-TRV-06 | M18, T07 | M18: §2.2, RF-SOC-088, EVT-SOC-05, `serviceDependents.serviceContractId`, `burialRights.maintenanceContractId`, §9.1 y §9.7. T07: SERSOC, SERSOC_HST y SERSOC_EXTRAS | El contrato pasa de M01 a M02 en todos los lugares. |
| HUECO-SEP-01 (M18) | M18 | RF-SOC-032 (mod.), RN-SOC-054, PRM-SOC-052, ESC-SOC-24 | Carencia de rehabilitación evaluada en RF-SOC-032, alineada con RN-MOR-143 de M08. No afecta urgencias. |
| HUECO-SEP-02 | M18, T07, M01 | M18: RF-SOC-024, `serviceBeneficiaries`, §19 y CTR-SOC-03. T07: RN-MIG-054 | Destino único `serviceBeneficiaries`. `COD_CSE` es el código compuesto del servicio, no una causa. Se retira el tipo `socialTariff`: la tarifa social sale de la categoría social y de la segmentación. |
| HUECO-SAN-02 (M18) | M18 | RF-SOC-146, RN-SOC-055, ESC-SOC-25 | La tarea de RN-MOR-144 llega al Responsable de servicios sociales, que decide mantener la cobertura, gestionar la deuda o revisar el convenio. Nunca hay suspensión automática. |
| HUECO-CEM-03 | T07, M18 | RF-MIG-099, §19.33 (TPL-MIG-CEM-01 a 05), fila Cementerio de la §19 de M18 | Cinco plantillas con orden de carga. La conciliación por unidad controla capacidad, un derecho vigente por unidad y ocupaciones sin derecho. |
| HUECO-SAL-02 | T07 | §19.20 | Se usan los nombres de M18: `transportTrips`, `tripLegs`, `tripCharacteristics` y `medicalProfessionals`. |
| HUECO-VIV-02 (T07) | T07 | §19.19 | `PRECIOSVIV` → `housingPrices` (M18). También alineé con M18 los destinos de `VIV_MAT`, `VIV_MATACT`, `VIV_PROGMAT`, `VIV_RETM` y `VIV_RET_IT`. |
| HUECO-VIV-03 | T07 | RN-MIG-052, PRM-MIG-063 | Un contrato de M02 por vivienda. La adjudicación y la entrega solo cambian el estado de `housingUnits`. Una vivienda sin `FECINSC` se rechaza. |
| HUECO-OBR-04 | T07 | §19.10, §9.1 | `OBRAS` y `GRPOBRA` pasan a la ola O7. |
| HUECO-OBR-05 | T07 | RN-MIG-053, fila SERSOC_EXTRAS | Las columnas `CNT_*` van a `worksInstallmentPlans` de M04. |
| HUECO-TAS-03 (T07) | T07 | RN-MIG-051, filas IMPUESTO, CON_TASAS y CLASESER | T07 arma las entradas y cita la "regla de clasificación de M06 (HUECO-TAS-03)". Una fila sin clasificar es rechazo bloqueante. |
| HUECO-CAP-03 | M17, T07 | §7.33 `capitalBalances`, §19 y RUBCAPI/CAPITAL/CAPITAL_RES | Proyección de saldos de capital. No es fuente de verdad. |
| HUECO-OTR-01 | T07, M18 | §19.33 (TPL-MIG-OTR-01 a 03), filas de SERSOC_PRODUCTOS | Los préstamos ortopédicos ya existen en `SERSOC_PRODUCTOS`. El dispenser no tiene tabla propia y va por plantilla. |
| HUECO-OTR-02 (M18) | M18 | RF-SOC-147 y precarga | El traslado no médico es un viaje con la característica `NON_MEDICAL`, sin datos sensibles. |
| HUECO-OTR-05 | M18 | RF-SOC-148, `contractRegistrations`, API-SOC-062, RF-SOC-115 (mod.), RF-SOC-116 (reemplazado) | La entidad de registración (vehículo eléctrico, equipo u otro) es de M18 y se elimina la dependencia de M01. |
| DEC-078 | M17 | RF-INS-088, PRM-INS-052, PA-INS-08, §7.22 | Perfil SIG-ACTA-INSTITUCIONAL de T11 §18.5. No dupliqué la línea de integraciones de la §13. |

**(a) Eventos y jobs nuevos para T11:** ninguno. La tarea de SAN-02 la crea M08 con RN-MOR-144.

**(b) Referencias cruzadas para otros anexos:**
- **M08:** RN-MOR-143 no define el canal (evento o API) por el que M18 se entera de la condición "cobertura suspendida por mora" que necesita RF-SOC-032.
- **M02:**
  - La fila `BENSOC` de §19 sigue en `contractMembers` (pendiente) y debe pasar a `serviceBeneficiaries` de M18.
  - La ficha del servicio debe declarar si admite beneficiarios y qué tipos de registración acepta.
  - El ítem §6.C.17 debe apuntar a RF-SOC-147.
- **T09:** el glosario, RF-COM-106 y CTR-COM-18 tratan `BENSOC` como tarifa social, y no lo es.
- **M04:** llama `adherentRates` a la tarifa de adherente y T07 usa `dependentTariffs` (no lo corregí). Además, no debe recibir ninguna fila de `BENSOC`.
- **T11:** SIG-ACTA-INSTITUCIONAL prevé presidente y secretario como firmantes, pero las actas de sindicatura las firma el síndico.
- **M19:** debe componer PAN-STK-40 dentro de PAN-POR-30.

**(c) Lo no resuelto (queda como [VERIFICAR]):**
- Si `CON_TASAS` se administra desde Compras y qué valores de `IMPUESTO.ORIGEN` usa cada cooperativa.
- El valor de `CONDICION_TRANSFERENCIA`. Encontré que `CONDICION = 5` significa "No vigente", no "transferido", y lo traté como `terminated`.
- Si el dispenser registra sus consumos en la tabla de consumos del servicio (V2 2581 a 2584).
- Dónde guarda ProCoop los datos del vehículo eléctrico.

**(d) IDs que resuelven `[REF-PENDIENTE]`:** el de T12 parte 2, ficha OTR ("dispositivos de M01"), se resuelve con RF-SOC-148, la colección `contractRegistrations` (M18 §7.5) y API-SOC-062. RF-SOC-116 queda reemplazado.

## Ajustes para T05

- **COL-SOC-02 y CTR-DAT-27 (el punto a arbitrar):** T05 divide `BENSOC` entre M18 y `benefitGroupMembers` de M04, y COL-TAR-14 dice "`BENSOC` (tarifa social)". El diccionario y el código de ProCoop muestran que `BENSOC` solo guarda beneficiarios-persona, así que el destino debería ser único: `serviceBeneficiaries`. Habría que coordinarlo con G2, que tiene M04.
- **COL-SOC-30 `housingPrices`:** T05 la trata como alias de `productPrices` de M04. En M18 y T07 (HUECO-VIV-02) M18 es el dueño de los precios, así que debería ser una colección propia de M18.
- **COL-SOC-22:** `maintenanceContractId` debe apuntar a M02.
- **COL-PER-11 `adherents`:** debe redirigir a COL-SOC-01 y también a COL-SOC-02.
- **Colección nueva de M18:** `contractRegistrations`, con `serviceContractId` (→ M02), `type`, `vehicle.plate` y `device.serialNumber`; ola O10.
- **Colección nueva de M17:** `capitalBalances`, proyección materializada de `capitalMovements` con índice único `{membershipId, capitalItemId, accountId, serviceContractId}`.
- **COL-CAT-18:** en el origen `SERSOC_EXTRAS`, aclarar que las columnas `CNT_*` van a COL-TAR-20.
- **Campo nuevo en `serviceBeneficiaries`:** `legacy.codCse`.

T05 splits BENSOC (CTR-DAT-27), which contradicts my single-destination assumption, so I need to flag this in the report. The old field names no longer appear in T05 since those were moved to T07, which I already corrected, so I'm ready to write the final summary table now.



## T05 (modelo de datos)

El anexo `docs/especificacion/anexos/T05-DAT-modelo-datos.md` quedó completo. Tiene las secciones 1 a 22, no quedó el marcador `<!-- SIGUE -->` y solo edité ese archivo. Antes de seguir releí lo ya escrito y continué desde el catálogo de M11 a M19, sin repetir nada.

**Colecciones.** El catálogo tiene 1.092 filas:
- 1.040 se crean: 1.021 canónicas, 5 con otro nombre y 14 nuevas que propone T05.
- 52 se absorben en otra colección.
- De las 1.040, 39 son colecciones `bi_*` de la base analítica.

| Anexo | Filas | A crear | Absorbidas | Renombradas | Nuevas T05 |
|---|---|---|---|---|---|
| T01 | 32 | 31 | 1 | 0 | 1 |
| T02 | 31 | 31 | 0 | 0 | 0 |
| T03 | 11 | 10 | 1 | 0 | 0 |
| T04 | 55 | 45 | 10 | 0 | 13 |
| T06 | 18 | 18 | 0 | 0 | 0 |
| T07 | 20 | 20 | 0 | 0 | 0 |
| T08 | 23 | 17 | 6 | 0 | 0 |
| T09 | 56 | 55 | 1 | 0 | 0 |
| T10 | 69 | 67 | 2 | 1 | 0 |
| T11 | 53 | 51 | 2 | 0 | 0 |
| M01 | 21 | 17 | 4 | 0 | 0 |
| M02 | 28 | 24 | 4 | 0 | 0 |
| M03 | 37 | 35 | 2 | 0 | 0 |
| M04 | 36 | 34 | 2 | 0 | 0 |
| M05 | 42 | 38 | 4 | 0 | 0 |
| M06 | 45 | 45 | 0 | 1 | 0 |
| M07 | 46 | 44 | 2 | 0 | 0 |
| M08 | 39 | 38 | 1 | 1 | 0 |
| M09 | 42 | 42 | 0 | 0 | 0 |
| M10 | 70 | 70 | 0 | 1 | 0 |
| M11 | 15 | 14 | 1 | 0 | 0 |
| M12 | 20 | 20 | 0 | 0 | 0 |
| M13 | 40 | 39 | 1 | 0 | 0 |
| M14 | 43 | 42 | 1 | 0 | 0 |
| M15 | 38 | 35 | 3 | 0 | 0 |
| M16 | 61 | 59 | 2 | 0 | 0 |
| M17 | 35 | 34 | 1 | 1 | 0 |
| M18 | 52 | 51 | 1 | 0 | 0 |
| M19 | 14 | 14 | 0 | 0 | 0 |

**Excepciones de índices únicos globales (en §7.8.1).** Son las que sirven para saber a qué tenant pertenece un pedido antes de tener sesión:
- `crmChannels` por `{kind, address}`.
- `landingPages` por `slug` y por `customDomain`.
- `portalDelegationInvites` por `tokenHash`.
- `memberCredentials` por `qrTokenHash`.

**Contraposiciones (CTR-DAT): 74.** Están en §20, cada una con su resolución y el anexo donde hay que aplicarla.

**Preguntas nuevas para el cuestionario (PA-DAT): 2.** Antes de esta parte no había ninguna. Mientras no se respondan, se asume la opción recomendada.
- **PA-DAT-01 — Cuenta corriente y cobro cuando hay varias entidades jurídicas.** Recomendada: una cuenta corriente por titular y por entidad. En caja, un mismo cobro puede cubrir facturas de varias entidades, pero se emite un recibo por cada una. Bloquea la ola O5 y la numeración de recibos.
- **PA-DAT-02 — Consulta del detalle histórico de más de 36 meses.** El detalle de facturas, la telemedición, las llamadas y las bitácoras más viejas se archivan y se recuperan a pedido. Las facturas, recibos y asientos, con sus PDF, quedan siempre en línea.

**Errores detectados en otros anexos (para corregir en cada uno):**
- **Maestra §12:** pone `outboxEvents` bajo T11 y usa `vaultSecrets`; la bóveda es `integrationSecrets` de T06.
- **M01:**
  - Declara como colecciones catálogos que son enumeraciones de T04.
  - Usa `legacyCode` en lugar del subdocumento `legacy`.
  - Tiene una colección `consents` duplicada con T08.
- **M02:**
  - Define `contractMembers` y `generationAgreements`, que no se crean.
  - Usa `holderPersonId` y `serviceAddress.propertyId` en lugar de `holderId` y `servicePointId`.
- **M03:**
  - Atribuye el contrato a M01 cuando el dueño es M02.
  - Usa `serialItems` en lugar de `serialUnits`.
  - Ubica la bóveda en T01.
  - Duplica `meterSeals` (es `seals` de M10) y `meteringConnectorLogs` (va a T06).
- **M04:**
  - Atribuye las cotizaciones a "M07/T04" (son de M14).
  - Atribuye `TIPOLOTE` a M05 (es de M13).
  - Usa `DEUDARED` como origen de `roundingCarryEntries` (es de M07).
- **M05:**
  - Atribuye `CLASIFICACION_ITEMS` a M06 (es de M13).
  - Duplica el punto de venta, el cupón único y los bloqueos.
  - Guarda períodos como `{year, month}`.
- **M06:** cita `documentSequences`, que no existe, y usa `documentTypeId` para tipos de comprobante (debe ser `voucherTypeId`).
- **M07:**
  - Duplica `fileLayouts` y `cashDiscountRules`.
  - No contempla entidades jurídicas en cuenta corriente ni recibos (origen de PA-DAT-01).
- **M08:**
  - Toma `PPAGOS`, `PPITEMS` y `PPAGOS_FIRMANTES` como convenios con socios; por sus columnas son órdenes de pago a proveedores.
  - Hay choque de nombre en `collectionAgencies` y duplicado en `financialEntities`.
- **M10:**
  - Dice "dueño según T05" para `serviceContracts`.
  - Cita `callRatings`, que no existe en M04.
  - Hay choque de nombre en `operationTypes`.
- **M11:** `freightSettlements` duplica `tripSettlements` de M18.
- **M12:** `purchaseLookups` duplica `UNIDADES_GASTOS` (va a M13) y `COMBUSTIBLES` (va a M18).
- **M13:** `equipmentAssignments` duplica la colección de equipos en contratos de M02.
- **M14:** `cardPlans` duplicada con M07.
- **M15:**
  - `capitalRubricAccounts` choca con `capitalItems.ledgerAccountId` de M17.
  - Duplica los índices de inflación de T04.
- **M16:** `employers` choca con `legalEntities`, y las tablas legales de §7.45 no están en T04.
- **M17:** hay choque de nombre en `memberships` y la numeración en `insNumberingSeries` está duplicada.
- **M18:**
  - Usa `serviceContractId` y `holderPersonId`.
  - Tiene `housingPrices` duplicada.
  - El TTL de GPS por tenant no se puede aplicar en una colección de serie temporal de MongoDB.
- **T01:** usa el nombre `brandingRef` y `tenantParameters`, y cita `configPackages`, `masterTables`, `branches` y `pointsOfSale`, que no están definidas en ningún anexo.
- **T04:** duplica tablas fiscales de M06, `sequences`, `savedViews` y `featureFlags`, y no define `legalEntities` ni `branches`.
- **T07:**
  - Asigna `legalEntities` a T01 (es de T04).
  - Usa nombres de destino que no coinciden con M18 y M17.
  - Usa `tenantParameters`.
- **T08:** duplica `tenantUsageSnapshots`, `processedEvents`, `restoreDrills` e `idempotencyKeys`, y usa `auditEvents` en lugar de `auditLogs`.
- **T10:** propone `bia_runResults_<tenant>`, una colección por tenant, que va contra DEC-002.
- **T11:** cita `EXPEDIENTES` como origen de `dossiers`; corresponde a `technicalProcedures` de M10. En T05 ya lo corregí.

## Plan de olas

Terminé el plan en `docs/especificacion/03-plan-de-olas-y-prompts.md`. Tiene 172 prompts que cubren los 4.120 RF y los 292 RNF, sin faltantes. Para confirmarlo, un script extrae todos los IDs de las líneas "IMPLEMENTAR" y los cruza con las tablas de los anexos: cada RF y cada RNF aparece en exactamente un prompt, ninguno se repite y no hay IDs que no existan en los anexos. Solo edité ese archivo y quité el marcador de continuación.

Antes de seguir releí el archivo y corregí cuatro cosas:
- Los conteos de RF de siete prompts de O0 estaban mal en la tabla de secuencia; la suma de la ola sigue dando 299.
- Los títulos de O2 y O3 no coincidían con el índice.
- Faltaban RF-INT-061 y 064 en O4 y RF-FIS-154..156 en O11; quedaron asignados.
- Dos prompts decían "los RF listados" y ahora listan los IDs explícitos.

**Por ola**

| Ola | Prompts | RF |
|---|---|---|
| O0 | 21 | 299 |
| O1 | 20 | 457 |
| O2 | 19 | 607 |
| O3 | 13 | 315 |
| O4 | 16 | 419 |
| O5 | 14 | 463 |
| O6 | 11 | 241 |
| O7 | 10 | 256 |
| O8 | 15 | 454 |
| O9 | 9 | 161 |
| O10 | 14 | 360 |
| O11 | 10 | 88 |
| **Total** | **172** (más 3 PRO-GEN) | **4.120** |

**Control de cobertura**

| Tipo | En los anexos | Asignados | Faltantes |
|---|---|---|---|
| RF (29 anexos) | 4.120 | 4.120 | 0 |
| RNF (PLA, CFG, NFR, WFL, CRM) | 292 | 292 | 0 |

Hay 17 RF y un RNF con ola ausente, inválida o reasignada, todos documentados en §18. Además agregué REQ-DEC-064: es el requisito de razón social (`legalEntities` y `legalEntityId`) que pide DEC-064 en O0 y que ningún anexo define como RF.

**Contradicciones de olas entre anexos, DEC y maestro** (16 en total, todas en §19 con su resolución):
1. **Razón social:** DEC-064 la exige desde O0, pero ningún anexo tiene un RF que la defina.
2. **Adherentes:** M01 (RF-PER-109..117) y M02 (RF-CAT-080) los ponen en O10, mientras DEC-071 y HUECO-TRV-01 piden una versión mínima en O4 con M18 como dueño.
3. **Capital social contable:** RF-CON-025, 075, 150 y 151 estaban en O10, pero DEC-019 y HUECO-CAP-01 llevan el capital mínimo a O5. Los reasigné a O5.
4. **Pasarelas:** las listas de RF-FAC-146 y RF-COB-132 no coinciden con DEC-015 (prioritarias en O5, el resto en O11).
5. **Maestro desactualizado respecto de los anexos y las DEC:**
   - Tesorería (M14) figura solo en O8, pero DEC-059 la divide en O5 y O8.
   - CRM (M09) no menciona O6, aunque DEC-056 adelanta IA y omnicanal a esa ola.
   - Medición (M03) dice "O3 equipos", pero el anexo tiene todo en O7.
   - Sueldos (M16) figura en O9, pero DEC-058 pone legajo mínimo en O3 e importación externa en O8.
   - Compras (M12) figura en O8, pero dos RF están en O3.
6. **Encabezados condicionales:** M17 y M18 dicen "solo si…", aunque DEC-019 y DEC-071 ya están firmes.
7. **PA ya resuelta:** RF-PLA-040 sigue "A validar PA-PLA-08", aunque DEC-065 la resolvió.
8. **Migración de obras (HUECO-OBR-04):** T07 la pone en O8 y M10/M02 ubican obras en O7. Dejé obras en O7 y su migración en O11.
9. **Corte:** el maestro dice "corte definitivo" en O11, pero DEC-068 lo define por etapas (comercial y luego administrativo).
10. **Número de decisión:** el núcleo contable en O5 aparece citado como DEC-006, pero en el registro es DEC-009.
11. **Nombres de tenants demo:** M02 y T12 usan "Demo Norte/Sur" y T01 usa "Ejemplo A/B" (HUE-SRV-05); el plan usa los de T01.
12. **Eventos de M02:** el anexo no define EVT-CAT y otros anexos los consumen; el plan usa los provisionales de T11 §12.3.
