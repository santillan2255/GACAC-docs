﻿from repl import *
apply('M01', [
 ('| JOB-PER-05 | `per:mayoria-edad-adherentes` | — | **Retirado.** La mayoría de edad la detecta y avisa M18; M01 solo muestra el dato. Ver JOB-SOC-01 (dueño). | — | — | — |',
  '| JOB-PER-05 | `per:mayoria-edad-adherentes` | — (antes: Diario) | **Reemplazado por JOB-SOC-01** (M18, dueño único; no se ejecuta). Texto original: lista adherentes que cumplen la edad (PRM-PER-067) y envía el aviso por T09 (PRM-PER-066). M01 solo muestra el dato. | Por adherente + año | 3 | Por tenant |'),
], tag='job')
apply('M02', [
 ('| JOB-CAT-07 `cat:mayoria-edad-adherentes` | — | **Retirado.** La mayoría de edad de adherentes la detecta y avisa M18. Ver JOB-SOC-01 (dueño). | — |',
  '| JOB-CAT-07 `cat:mayoria-edad-adherentes` | — (antes: Diario, V2 3186) | **Reemplazado por JOB-SOC-01** (M18, dueño único; no se ejecuta). Texto original: lista adherentes que cumplen 21 años; envía correo/notificación. | — |'),
 ('| JOB-CAT-08 `cat:fin-suspension-voluntaria` | Diario | Solicita reactivación al vencer la suspensión voluntaria. | — |',
  '| JOB-CAT-08 `cat:fin-suspension-voluntaria` | Diario | Dueño único del vencimiento de la suspensión voluntaria: al vencer, reactiva el contrato (T10/T11) y publica EVT-CAT-12 `cat.contract.reactivated`; M08 solo reacciona a ese evento (JOB-MOR-08) y cierra su caso. | Idempotente por (`contractId`, fin de suspensión). |'),
], tag='job')
