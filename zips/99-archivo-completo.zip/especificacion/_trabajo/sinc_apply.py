"""Sincronización posterior a residuales (5-11-2026): eventos, alias, renombres, M04/M06/M15, servicios fis."""
import sys, io, os, re, glob, json, collections

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos"
CNT = collections.defaultdict(collections.Counter)
PENDING = []


class Doc:
    def __init__(self, pat):
        p = glob.glob(os.path.join(ROOT, pat))
        assert len(p) == 1, (pat, p)
        self.path = p[0]
        self.key = os.path.basename(self.path)
        raw = open(self.path, "rb").read()
        self.bom = raw.startswith(b"\xef\xbb\xbf")
        t = raw.decode("utf-8-sig")
        self.crlf = "\r\n" in t
        if self.crlf:
            assert t.count("\r\n") == t.count("\n"), "EOL mixto " + self.path
            t = t.replace("\r\n", "\n")
        self.t = t

    def rep(self, old, new, cat, count=1):
        c = self.t.count(old)
        assert c == count, "%s: esperaba %d y hay %d: %r" % (self.key, count, c, old[:200])
        self.t = self.t.replace(old, new)
        CNT[self.key][cat] += count

    def pa_line(self, pa, text, cat="PA"):
        ls = self.t.split("\n")
        h = [i for i, l in enumerate(ls) if l.startswith("### ") and pa in l]
        assert len(h) == 1, (self.key, pa, h)
        i = h[0] + 1
        while not re.match(r"^(- )?\*\*Estado", ls[i]):
            assert not ls[i].startswith("#"), (self.key, pa)
            i += 1
        bullet = ls[i].startswith("- ")
        new = ("- **Sincronización (5-11-2026), Asumida (DEC-072):** " if bullet
               else "**Sincronización (5-11-2026), Asumida (DEC-072):** ") + text
        ls[i + 1:i + 1] = [new]
        self.t = "\n".join(ls)
        CNT[self.key][cat] += 1

    def save(self):
        PENDING.append(self)

    def write(self):
        t = self.t.replace("\n", "\r\n") if self.crlf else self.t
        open(self.path, "wb").write((b"\xef\xbb\xbf" if self.bom else b"") + t.encode("utf-8"))


EV = "1-eventos"

# ---------- T06 ----------
d = Doc("T06-*.md")
for old, new in [
    ("fis.regime-file.requested", "fis.regimeFile.requested"),
    ("cob.payment-intent.requested", "cob.paymentIntent.requested"),
    ("cob.debt-publication.requested", "cob.debtPublication.requested"),
    ("cob.direct-debit.batch-requested", "cob.directDebit.batchRequested"),
    ("med.reading-route.published", "med.readingRoute.published"),
    ("com.message.dispatch-requested", "com.message.dispatchRequested"),
    ("per.person.fiscal-lookup-requested", "per.person.fiscalLookupRequested"),
    ("tes.bank-sync.requested", "tes.bankSync.requested"),
    ("tes.payment-file.requested", "tes.paymentFile.requested"),
    ("sue.payroll-files.requested", "sue.payrollFiles.requested"),
]:
    d.rep("`%s`" % old, "`%s` (antes `%s`)" % (new, old), EV)
d.rep("- **Flujo:** `mor.cut-order.approved` →",
      "- **Flujo:** `mor.interruption.approved` (EVT-MOR-12; antes `mor.cut-order.approved`) →", EV)
d.pa_line("PA-INT-27",
          "los tipos de evento que T06 consume con guion (§12, eventos consumidos) pasan a camelCase con el nombre anterior "
          "como \"antes\": `fis.regimeFile.requested`, `cob.paymentIntent.requested`, `cob.debtPublication.requested`, "
          "`cob.directDebit.batchRequested`, `med.readingRoute.published`, `com.message.dispatchRequested`, "
          "`per.person.fiscalLookupRequested`, `tes.bankSync.requested`, `tes.paymentFile.requested` y "
          "`sue.payrollFiles.requested`; CU-INT-09 dispara con el canónico `mor.interruption.approved` (EVT-MOR-12; antes "
          "`mor.cut-order.approved`). Los productores (M06, M07, M03, T09, M01, M14, M16) deben declarar esos nombres en su §12 "
          "y T11 §12.4 registrar los alias.")
d.save()

# ---------- T12 ----------
d = Doc("T12-*parte2.md")
d.rep("PAN-INS-08, `ins.capital.refund.paid` (T09, EVT-INS-12)",
      "PAN-INS-08, `ins.capitalRefund.paid` (antes `ins.capital.refund.paid`) (T09, EVT-INS-12)", EV)
for evt, old, new in [
    ("EVT-INS-08", "ins.capital.movement.recorded", "ins.capitalMovement.recorded"),
    ("EVT-INS-09", "ins.capital.movement.reversed", "ins.capitalMovement.reversed"),
    ("EVT-INS-10", "ins.capital.transfer.executed", "ins.capitalTransfer.executed"),
    ("EVT-INS-11", "ins.capital.refund.approved", "ins.capitalRefund.approved"),
    ("EVT-INS-12", "ins.capital.refund.paid", "ins.capitalRefund.paid"),
]:
    d.rep("%s `%s`" % (evt, old), "%s `%s` (antes `%s`)" % (evt, new, old), EV)
d.save()

# ---------- M17 (alias retirados) ----------
d = Doc("M17-*.md")
d.rep("`fac.invoice.annulled` (EVT-FAC-08) / `fac.creditNote.issued` / `fac.debitNote.issued` (EVT-FAC-10/11) | M05 | Contramovimiento o ajuste del capital de la cuenta del asociado.",
      "`fac.invoice.annulled` (EVT-FAC-08) / `fac.creditNote.issued` / `fac.debitNote.issued` (EVT-FAC-10/11) | M05 | Contramovimiento o ajuste del capital de la cuenta del asociado. M17 se suscribe directamente a `fac.debitNote.issued` (EVT-FAC-11) para el ajuste en contra: el alias `fac.invoice.adjusted` resuelve solo a `fac.creditNote.issued` (T11 §12.4, PA-WFL-23).",
      "2-alias")
d.rep("`fac.invoice.adjusted` → `fac.creditNote.issued` / `fac.debitNote.issued`;",
      "`fac.invoice.adjusted` → `fac.creditNote.issued` (el ajuste en contra se consume directamente como `fac.debitNote.issued`, EVT-FAC-11; antes \"`fac.invoice.adjusted` → `fac.creditNote.issued` / `fac.debitNote.issued`\");",
      "2-alias")
d.rep("`cob.payment.reversed` → `cob.receipt.voided` / `cob.allocation.reversed`;",
      "`cob.payment.voided` → `cob.receipt.voided`; `cob.payment.reversed` → `cob.allocation.reversed` (antes \"`cob.payment.reversed` → `cob.receipt.voided` / `cob.allocation.reversed`\");",
      "2-alias")
d.pa_line("PA-INS-13",
          "cada alias de evento resuelve a un solo canónico (T11 §12.4, PA-WFL-23): M17 se suscribe directamente a "
          "`fac.debitNote.issued` (EVT-FAC-11) y la nota de alias de §12 se corrige con \"antes\".", "2-alias")
d.save()

# ---------- T10 (alias retirados) ----------
d = Doc("T10-*.md")
d.rep("| `iam.membership.suspended` / `.revoked` (EVT-IAM-03), `iam.role.unassigned` / `iam.role.assigned` (EVT-IAM-04), `iam.role.changed` (EVT-IAM-05) | Revalidación de programaciones y presets compartidos (RF-BIA-038) |",
      "| `iam.membership.suspended` / `.revoked` (EVT-IAM-03), `iam.role.unassigned` / `iam.role.assigned` (EVT-IAM-04), `iam.role.changed` / `iam.profile.changed` (EVT-IAM-05; suscripción directa al canónico, antes solo `iam.role.changed` y el alias `iam.roleAssignment.changed`, CNC-WFL-089) | Revalidación de programaciones y presets compartidos (RF-BIA-038) |\n"
      "| `cob.payment.confirmed` (EVT-COB-04), `cob.receipt.voided` (EVT-COB-05), `cob.allocation.reversed` (EVT-COB-06) | Proyecciones `bi_fact_payment`, `bi_fact_allocation` y `bi_fact_ledgerEntry` (suscripción directa a los canónicos; antes el alias `cob.ledgerEntry.posted`, CNC-WFL-083) |",
      "2-alias")
d.rep("| `bi_fact_payment` | pago | paymentId, canal, ente, fechas (pago, confirmación, acreditación), importe, comisión, estado | `cob.payment.*` |",
      "| `bi_fact_payment` | pago | paymentId, canal, ente, fechas (pago, confirmación, acreditación), importe, comisión, estado | `cob.payment.confirmed` (EVT-COB-04) / `cob.receipt.voided` (EVT-COB-05) (antes `cob.payment.*`) |",
      "2-alias")
d.rep("| `bi_fact_allocation` | imputación | paymentId, invoiceId, importe, fecha efectiva | `cob.allocation.*` |",
      "| `bi_fact_allocation` | imputación | paymentId, invoiceId, importe, fecha efectiva | `cob.payment.confirmed` (EVT-COB-04, `allocations[]`) / `cob.allocation.reversed` (EVT-COB-06) (antes `cob.allocation.*`) |",
      "2-alias")
d.rep("| `fac.invoice.issued/authorized/voided` |",
      "| `fac.invoice.issued` (EVT-FAC-07) / `fis.invoice.authorized` (EVT-FIS-01) / `fac.invoice.annulled` (EVT-FAC-08) (antes `fac.invoice.issued/authorized/voided`) |",
      "2-alias")
d.pa_line("PA-BIA-17",
          "T10 se suscribe directamente a los canónicos de EVT-COB-04, EVT-COB-05, EVT-COB-06 y EVT-IAM-05 (`iam.role.changed` / "
          "`iam.profile.changed`), porque los alias `cob.ledgerEntry.posted` e `iam.roleAssignment.changed` resuelven a un solo "
          "canónico (T11 §12.4.1, CNC-WFL-083 y CNC-WFL-089); las fuentes de `bi_fact_payment`, `bi_fact_allocation` y "
          "`bi_fact_invoice` citan los canónicos con \"antes\".", "2-alias")
d.save()

R = "3-renombres"
# ---------- M05 ----------
d = Doc("M05-*.md")
d.rep("| `accountId`, `holderId`, `memberId` | ObjectId → M01 | Sí / Sí / No | — |",
      "| `accountId`, `holderId`, `associateMembershipId` | ObjectId → M01 / M01 / M17 | Sí / Sí / No | `associateMembershipId` (antes `memberId`; nombre canónico de T05 §7.2.1, PA-DAT-04) → `associateMemberships` (M17). |",
      R)
d.rep("`{ personId, holderId, memberId, accountId, name,",
      "`{ personId, holderId, associateMembershipId (antes memberId; → associateMemberships, M17), accountId, name,", R)
d.pa_line("PA-FAC-23",
          "`billingRunItems` y `invoices.customer` usan `associateMembershipId` (antes `memberId`) → `associateMemberships` (M17), "
          "nombre canónico de T05 §7.2.1 (PA-DAT-04).", R)
d.save()

# ---------- M14 ----------
d = Doc("M14-*.md")
d.rep("`period`, `companyRef`, `originAccountId`, `transferDate`",
      "`period`, `companyRef`, `originTreasuryAccountId` (antes `originAccountId`), `transferDate`", R)
d.rep("| `originAccountId` | ObjectId | Sí | — | `treasuryAccounts` (M14) |",
      "| `originTreasuryAccountId` | ObjectId | Sí | Antes `originAccountId`; nombre canónico de T05 §7.2.1 (PA-DAT-04). | `treasuryAccounts` (M14) |", R)
d.rep("| **M12 CMP** (con **M06 FIS** para el cálculo de retenciones) |",
      "| **M12 CMP** (con **M06 FIS** para el cálculo de retenciones: servicio interno `fis.service.calculateWithholdings`, antes sin nombre de servicio; confirmación y anulación con `fis.service.confirmWithholdings` / `fis.service.cancelWithholdings`) |",
      "5-servicios")
d.pa_line("PA-TES-19",
          "`payrollPaymentBatches.originAccountId` pasa a `originTreasuryAccountId` (antes `originAccountId`), como `paymentFiles`; "
          "la clave de parámetro `tes.payroll.originAccountId` (PRM-TES-070) no cambia. El §3 cita los servicios internos de M06 "
          "`fis.service.calculateWithholdings`, `fis.service.confirmWithholdings` y `fis.service.cancelWithholdings` (M06 §11.1): "
          "los invoca M12 al preparar, aprobar o anular la OP; TES ejecuta el pago neto y no recalcula retenciones.", R)
d.save()

# ---------- T01 ----------
d = Doc("T01-*.md")
d.rep("`files` [{fileId, module, part, sizeBytes, sha256}], `manifestFileId`,",
      "`files` [{storedFileId (antes `fileId`), module, part, sizeBytes, sha256}], `storedFileId` del manifiesto (antes `manifestFileId`),", R)
d.rep("| `files` | array | No | — | Según la definición en texto del §7 |\n| `storedFileId` | ObjectId | Sí | `storedFiles` (T01) | antes `manifestFileId`",
      "| `files` | array | No | — | Según la definición en texto del §7; cada parte con `storedFileId` → `storedFiles` (T01) (antes `fileId`; nombre canónico de T05 COL-PLA-21, PA-DAT-04) |\n| `storedFileId` | ObjectId | Sí | `storedFiles` (T01) | antes `manifestFileId`", R)
d.pa_line("PA-PLA-15",
          "`tenantExports.files[].fileId` pasa a `storedFileId` → `storedFiles` (antes `fileId`), nombre canónico de T05 COL-PLA-21 (PA-DAT-04).", R)
d.save()

# ---------- M16 ----------
d = Doc("M16-*.md")
d.rep("`validFrom`, `validTo`, `status`. Índice `{tenantId, employeeId, cbu}` único.",
      "`validFrom`, `validTo`, `status`, `cbuHmac` (HMAC del CBU cifrado, para unicidad y búsqueda). Índice `{tenantId, employeeId, cbuHmac}` único (antes `{tenantId, employeeId, cbu}`; clave de T05 COL-SUE-06, PA-DAT-04).", R)
d.rep("| `cbu` | String | [VERIFICAR] | 22 dígitos validados. | — |\n",
      "| `cbu` | String | [VERIFICAR] | 22 dígitos validados. | — |\n| `cbuHmac` | String | Sí | HMAC del CBU (el CBU se guarda cifrado); clave de unicidad `{employeeId, cbuHmac}` de T05 COL-SUE-06 (PA-DAT-04). No es referencia. | — |\n", R)
d.pa_line("PA-SUE-18",
          "`employeePayAccounts` agrega `cbuHmac` y su índice único pasa a `{tenantId, employeeId, cbuHmac}` (antes con `cbu`), "
          "como T05 COL-SUE-06; `laborLawsuits` ya usaba `number` (PA-DAT-04).", R)
d.save()

# ---------- M18 ----------
d = Doc("M18-*.md")
d.rep("| `fuelTypes` | `code`, `name`, `vatRate` (canónica;",
      "| `fuelTypes` | `code`, `name`, `vatRateId` (antes `vatRate`) (canónica;", R)
d.rep("| `vatRateId` | Enum | [VERIFICAR] | Antes `vatRate` (Enum);",
      "| `vatRateId` | ObjectId (antes Enum) | [VERIFICAR] | Antes `vatRate` (Enum);", R)
d.pa_line("PA-SOC-19",
          "`fuelTypes.vatRateId` se tipa ObjectId (antes Enum) y el resumen del §7 usa el nombre de T05 (PA-DAT-04); "
          "T06 §12 ya publica `int.fleet.positionsReceived` (EVT-INT-17).", R)
d.save()

# ---------- M13 ----------
d = Doc("M13-*.md")
d.rep("| `chargeProposalId` | ObjectId | — | Propuesta de cargo por no devolución. |",
      "| `chargeProposalId` | ObjectId → `approvalRequests` (T11) | — | Propuesta de cargo por no devolución: solicitud de aprobación de T11 (RN-STK-038; antes sin destino). |",
      "5-chargeProposal")
d.pa_line("PA-STK-11",
          "`chargeProposalId` → `approvalRequests` (T11): la propuesta de cargo por no devolución es una solicitud de aprobación (RN-STK-038).",
          "5-chargeProposal")
d.save()

# ---------- M12 ----------
d = Doc("M12-*.md")
S = "5-servicios"
d.rep("M12 invoca `fis.withholding.calculate` al preparar la OP",
      "M12 invoca `fis.service.calculateWithholdings` (antes `fis.withholding.calculate`) al preparar la OP", S)
d.rep("invocando el motor de M06 (`fis.withholding.calculate`)",
      "invocando el motor de M06 (`fis.service.calculateWithholdings`, antes `fis.withholding.calculate`)", S)
d.rep("OP en borrador → `fis.withholding.calculate` devuelve",
      "OP en borrador → `fis.service.calculateWithholdings` (antes `fis.withholding.calculate`) devuelve", S)
d.pa_line("PA-CMP-16",
          "M12 cita el servicio interno de M06 `fis.service.calculateWithholdings` (antes `fis.withholding.calculate`; M06 §11.1, PA-FIS-22).", S)
d.save()

# ---------- M04 ----------
d = Doc("M04-*.md")
T = "4-impuestos"
d.rep("`accountId`, `conceptId`, `taxRateId`…);",
      "`accountId`, `conceptId`, `taxRateIds` (solo IVA → `vatRates`), `taxIds` (otros tributos → `taxDefinitions`)…; antes `taxRateId`…);", T)
d.rep("| `taxRateIds` | object | No | IVA/IIBB de la categoría (cascada RN-TAR-166). |",
      "| `taxRateIds` | ObjectId[] (antes object) | No | Solo alícuotas de IVA de la categoría (cascada RN-TAR-166) → `vatRates` (M06). Antes \"IVA/IIBB de la categoría\" (PA-TAR-21). |\n"
      "| `taxIds` | ObjectId[] | No | IIBB, percepciones y demás tributos de la categoría (cascada RN-TAR-166) → `taxDefinitions` (M06); separado de `taxRateIds` (T05 PA-DAT-04, PA-TAR-21). |", T)
d.rep("| `taxRateIds` | object | No | IVA/IIBB de la fila. |",
      "| `taxRateIds` | ObjectId[] (antes object) | No | Solo alícuotas de IVA de la fila → `vatRates` (M06). Antes \"IVA/IIBB de la fila\" (PA-TAR-21). |\n"
      "| `taxIds` | ObjectId[] | No | IIBB, percepciones y demás tributos de la fila → `taxDefinitions` (M06) (T05 PA-DAT-04, PA-TAR-21). |", T)
d.rep("`priceIncludesVat` (bool), `taxRateIds`, `perceptionRate`,",
      "`priceIncludesVat` (bool), `taxRateIds` (solo IVA), `taxIds` (otros tributos; separado el 5-11-2026), `perceptionRate`,", T)
d.rep("| `taxRateIds` | ObjectId[] | [VERIFICAR] | — | `vatRates` o `taxDefinitions` (M06), asumido en PA-TAR-20 (DEC-072); antes [VERIFICAR] |",
      "| `taxRateIds` | ObjectId[] | [VERIFICAR] | Solo alícuotas de IVA (PA-TAR-21; T05 PA-DAT-04). | `vatRates` (M06); antes \"`vatRates` o `taxDefinitions` (M06), asumido en PA-TAR-20 (DEC-072); antes [VERIFICAR]\" |\n"
      "| `taxIds` | ObjectId[] | No | IIBB, percepciones y demás tributos del precio (PA-TAR-21; T05 PA-DAT-04). | `taxDefinitions` (M06) |", T)
d.pa_line("PA-TAR-21",
          "`taxRateIds` queda solo para alícuotas de IVA (→ `vatRates`) y se agrega `taxIds` (→ `taxDefinitions`) para IIBB, "
          "percepciones y demás tributos en `tariffCategoryRates`, `tariffRows` y `productPrices`, como T05 §7.2.1 (PA-DAT-04); "
          "reemplaza el doble destino de PA-TAR-20.", T)
d.save()

# ---------- M06 ----------
d = Doc("M06-*.md")
d.rep("`arcaVatId` (3, 4, 5, 6, 8, 9), `accounts{ sales, purchases, salesPerception }` (M15), `validFrom/validTo`. Origen `ALI_IVA`.",
      "`arcaVatId` (3, 4, 5, 6, 8, 9), `validFrom/validTo`. Origen `ALI_IVA`. Sin cuentas contables: van en `entityAccountAssignments` de M15 (`entityType = vatRate`, `usage` `sales`, `purchases`, `salesPerception`; antes `accounts{ sales, purchases, salesPerception }` (M15) en esta colección).", T)
d.rep("| `arcaVatId` | int (antes ObjectId) | Sí | (3, 4, 5, 6, 8, 9), `accounts{ sales, purchases, salesPerception }` (M15) |",
      "| `arcaVatId` | int (antes ObjectId) | Sí | (3, 4, 5, 6, 8, 9) (antes la celda incluía `accounts{ sales, purchases, salesPerception }` (M15), que pasan a `entityAccountAssignments`) |", T)
d.rep("> **Alineación con T05 (05-11-2026):** T05 usa `ledgerAccountIds`; la ficha lo modela como `accounts{ sales, purchases, salesPerception }` (`ledgerAccounts`, M15).",
      "> **Alineación con T05 (05-11-2026):** `vatRates` no guarda cuentas contables; las cuentas de ventas, compras y percepción de cada alícuota viven en `entityAccountAssignments` (COL-CON-38, M15, `entityType = vatRate`; PA-FIS-22, T05 PA-DAT-04). Antes: \"T05 usa `ledgerAccountIds`; la ficha lo modela como `accounts{ sales, purchases, salesPerception }` (`ledgerAccounts`, M15)\".", T)
d.rep("| `accountMap` | object | Sí | Cuentas contables |",
      "| `accountMap` | object | — | **Reemplazado por `entityAccountAssignments`** (COL-CON-38, M15, `entityType = taxDefinition`): `taxDefinitions` no guarda cuentas contables (PA-FIS-22, T05 PA-DAT-04). Antes obligatorio, \"Cuentas contables\" |", T)
d.rep("> **Alineación con T05 (05-11-2026):** T05 usa `ledgerAccountIds`; la ficha lo modela como `accountMap` (`ledgerAccounts`, M15).",
      "> **Alineación con T05 (05-11-2026):** las cuentas contables del tributo viven en `entityAccountAssignments` (COL-CON-38, M15, `entityType = taxDefinition`); M06 no guarda `ledgerAccountId` (PA-FIS-22, T05 PA-DAT-04). Antes: \"T05 usa `ledgerAccountIds`; la ficha lo modela como `accountMap` (`ledgerAccounts`, M15)\".", T)
d.pa_line("PA-FIS-22",
          "las cuentas contables de `vatRates` (antes `accounts{ sales, purchases, salesPerception }`) y de `taxDefinitions` "
          "(antes `accountMap`) se retiran de M06 y pasan a `entityAccountAssignments` de M15 (`entityType` `vatRate` y "
          "`taxDefinition`), como T05 COL-FIS-16 y COL-FIS-18 (PA-DAT-04).", T)
d.save()

# ---------- M15 ----------
d = Doc("M15-*.md")
d.rep("`incidentCategory`, `instrumentType`, `treasuryCategory`, `tax`, `thirdPartyAgreement`, `service`, `product` | Sí | Dimensión de la cascada (RN-CON-022, paso 1). | — |",
      "`incidentCategory`, `instrumentType`, `treasuryCategory`, `taxDefinition` (antes `tax`), `thirdPartyAgreement`, `service`, `product` | Sí | Dimensión de la cascada (RN-CON-022, paso 1). `vatRate` → `vatRates` (M06; `usage` `sales`, `purchases`, `salesPerception`) y `taxDefinition` → `taxDefinitions` (M06): M06 no guarda cuentas en esas colecciones (T05 COL-FIS-16 y COL-FIS-18, PA-DAT-04). | — |", T)
d.rep("| `entityId` | ObjectId (de la colección del módulo dueño) | Sí | — | `identities` (T02) |",
      "| `entityId` | ObjectId (de la colección del módulo dueño) | Sí | — | Polimórfica según `entityType` (p. ej. `vatRates` y `taxDefinitions` de M06, `suppliers` de M12, `treasuryAccounts` de M14); antes `identities` (T02) |", T)
d.rep("`vatRates` (FIS, `ALI_IVA`), `withholdingTypes`",
      "`vatRates` (FIS, `ALI_IVA`), `taxDefinitions` (FIS, `IMPUESTO`, `ALI_IBR`), `withholdingTypes`", T)
d.pa_line("PA-CON-19",
          "`entityAccountAssignments.entityType` admite `vatRate` y `taxDefinition` (antes `tax`) con las cuentas que M06 deja de "
          "guardar en `vatRates` y `taxDefinitions`; `entityId` es polimórfica según `entityType` (antes `identities` de T02).", T)
d.save()

for doc in PENDING:
    doc.write()
json.dump({k: dict(v) for k, v in CNT.items()}, open(os.path.join(os.path.dirname(__file__), "sinc_apply_cnt.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for k, v in sorted(CNT.items()):
    print(k, dict(v))
