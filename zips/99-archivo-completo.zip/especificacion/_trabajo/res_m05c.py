from res_m0106_lib import Doc

d = Doc('M05')
d.rep("`authorizationPhase` y `distributionPhase` avanzan en paralelo después de `issuing`: `pending → inProgress → completed | completedWithIssues` (estado inicial y valores alineados con §7 en §8.12).",
      "`authorizationPhase` y `distributionPhase` avanzan en paralelo después de `issuing`; la máquina de cada fase, con su estado inicial, está en §8.13 (antes se escribía aquí la cadena común «pending → inProgress → completed | completedWithIssues», alineada con §7 en §8.12).", '1')
d.rep("**Subestados del lote:** §8.2 decía que `authorizationPhase` y `distributionPhase` avanzan `pending → inProgress → completed | completedWithIssues`. Se alinea con §7 (`billingRuns`): `authorizationPhase` empieza en `notRequired` (lote sin comprobantes a autorizar) o `pending`; `distributionPhase` empieza en `notStarted`. Ambos siguen `→ inProgress → completed | completedWithIssues`.",
      "**Subestados del lote:** §8.2 decía que `authorizationPhase` y `distributionPhase` avanzan «pending → inProgress → completed | completedWithIssues». Se alinea con §7 (`billingRuns`): `authorizationPhase` empieza en `notRequired` (lote sin comprobantes a autorizar) o `pending`; `distributionPhase` empieza en `notStarted`. Ambos siguen hacia «inProgress» y terminan en «completed» o «completedWithIssues». Tabla de transiciones de cada fase en §8.13.", '1')
d.save()
