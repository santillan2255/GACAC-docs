from res_m0106_lib import Doc

d = Doc('M03')

TAB = '''
### 8.13 Estados iniciales y transiciones completadas (residuales del 05-11-2026)

Ronda de residuales del 05-11-2026 (PA-MED-15, DEC-072): estado de alta explícito de las máquinas de §8.4, §8.7, §8.8 y §8.11, y transiciones de `readingImportJobs` y `consumptionClassReviews`, que solo enumeraban estados en §7. Las cadenas de §8.4 a §8.11 no cambian.

| Entidad | Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |
|---|---|---|---|---|---|
| `readingTasks` | — | `pending` | Generación del lote de lectura (§8.3) | — | — |
| `consumptionExceptions` | — | `open` | Regla de validación de consumo con hallazgo | — | — |
| `consumptionAdjustments` | — | `proposed` | Propuesta de ajuste o regularización | — | — |
| `distributedGenerationContracts` | — | `requested` | Solicitud del usuario-generador (MER-001) | — | — |
| `readingImportJobs` | — | `uploaded` | Carga del archivo con un perfil de importación | Perfil `active`; `fileHash` no repetido para el perfil | — |
| `readingImportJobs` | `uploaded` | `previewed` | Vista previa con filas válidas, con error y duplicadas | — | — |
| `readingImportJobs` | `previewed` | `confirmed` | Confirmación del operador (`approvedBy` en importación directa de consumos) | — | — |
| `readingImportJobs` | `confirmed` | `processed` | Lecturas o consumos registrados en el lote (`batchId`) | — | — |
| `readingImportJobs` | `uploaded`/`previewed`/`confirmed` | `failed` | Error de formato o de procesamiento | — | — |
| `readingImportJobs` | `uploaded`/`previewed` | `cancelled` | Cancelación por el operador | — | — |
| `consumptionClassReviews` | — | `draft` | Revisión periódica que genera candidatos (PA-MED-10) | — | — |
| `consumptionClassReviews` | `draft` | `approved` | Aprobación (`approvalRequestId`, T11) | — | — |
| `consumptionClassReviews` | `approved` | `applied` | Cambio de categoría aplicado en los contratos (M02) | — | — |
| `consumptionClassReviews` | `draft` | `discarded` | Descarte de la propuesta | — | — |
'''
d.insert_before('\n## 9. ', TAB, '1')

# --- Categoría 2: referencias ---
d.rep("| `documents` | [ObjectId] (expediente T11) | No | Fotos, certificados. |",
      "| `documents` | [ObjectId] (expediente T11) | No | Fotos, certificados. Referencia: → `documents` (T11). |", '2')
d.rep("| `reading` | {`zone` String, `sector` String, `sequence` Int, `routeIds` [ObjectId]} | Cond. | ZSR (ej. zona 30, sector 1, recorrido 250). |",
      "| `reading` | {`zone` String, `sector` String, `sequence` Int, `routeIds` [ObjectId]} | Cond. | ZSR (ej. zona 30, sector 1, recorrido 250). Referencia: `routeIds` → `readingRoutes` (M03); el resto no es referencia. |", '2')
d.rep("| `defaultReaderIds` | [ObjectId] | No | — Referencia: `memberships` (T02) [VERIFICAR]. |",
      "| `defaultReaderIds` | [ObjectId] | No | — Referencia: → `memberships` (T02): usuario de la app de campo del lecturista, confirmado en PA-MED-15 (DEC-072; antes [VERIFICAR]). |", '2')
d.rep("| `readerId` | ObjectId (persona/empleado) | Sí | — Referencia: `memberships` (T02) [VERIFICAR]. |",
      "| `readerId` | ObjectId (persona/empleado) | Sí | — Referencia: → `memberships` (T02): usuario de la app de campo del lecturista; el legajo, si es empleado, se obtiene de la membresía (PA-MED-15, DEC-072; antes [VERIFICAR]). |", '2')
d.rep("| `downloadedAt` / `deviceId` | Date / String | No | — |",
      "| `downloadedAt` / `deviceId` | Date / ObjectId (antes String) | No | Referencia: `deviceId` → `fieldDevices` (M10), PA-MED-15 (DEC-072). |", '2')
d.rep("| `photoIds` | [ObjectId] | No | Expediente (fotos). Referencia: `storedFiles` (T01). |",
      "| `photoIds` | [ObjectId] | No | Expediente (fotos). Referencia: → `storedFiles` (T01). |", '2')
d.rep("| `consumptionId` / `readingId` / `meteringPointId` | ObjectId | Sí (al menos uno) | — |",
      "| `consumptionId` / `readingId` / `meteringPointId` | ObjectId | Sí (al menos uno) | Referencia: → `consumptions`, → `meterReadings` y → `meteringPoints` (M03). |", '2')
d.rep("| `vendorTransactionId` | String | No | — Referencia: externa: identificador del proveedor de prepago (sin colección). |",
      "| `vendorTransactionId` | String | No | — Referencia: externa: identificador del proveedor de prepago (sin colección); no es referencia interna. |", '2')
d.rep("| `documents` | [ObjectId] | No | — |\n| `status` | enum `requested`/`underReview`",
      "| `documents` | [ObjectId] | No | Referencia: → `documents` (T11). |\n| `status` | enum `requested`/`underReview`", '2')

d.anchor_field_tables('3')

PA = '''
### PA-MED-15 - Residuales de estados y referencias (ronda del 05-11-2026)
- **Pregunta:** ¿Se confirman los estados iniciales y las transiciones de `readingImportJobs` y `consumptionClassReviews`, y los destinos de las referencias del lecturista, del dispositivo y de los expedientes?
- **Contexto:** al regenerar los entregables, 06a §7 marcó 6 máquinas de M03 sin estado inicial y 2 colecciones con estados sin transiciones; 03-er marcó sin destino `meters.documents`, `meteringPoints.reading`, `defaultReaderIds`, `readerId`, `photoIds`, `readingId`, `vendorTransactionId` y `distributedGenerationContracts.documents`; T05 §7.2.1 tiene `deviceId` de M03 con [VERIFICAR].
- **Opciones:**
  - A) **(Recomendada)** Declarar en §8.13 el estado de alta y las transiciones; lecturista → `memberships` (T02); `deviceId` → `fieldDevices` (M10, tipo ObjectId); expedientes → `documents` (T11); fotos → `storedFiles` (T01); `routeIds` → `readingRoutes`; `vendorTransactionId` es un identificador externo.
  - B) Lecturista → `employees` (M16), que excluye lecturistas tercerizados.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** 06 (estados), 03 (ER), T05 §7.2.1 (`deviceId`).
- **Estado:** Asumida (DEC-072): opción A. Aplicado en §7.2 a §7.6 y §8.13. T05 debe cerrar el [VERIFICAR] de `deviceId` (M03 → `fieldDevices`).
'''
d.insert_before('\n## 22. ', PA, 'PA')
d.save()
