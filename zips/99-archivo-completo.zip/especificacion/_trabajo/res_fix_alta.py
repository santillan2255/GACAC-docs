"""El parser de 06 toma "(alta → `x`; ...)" como etiqueta: se reescribe como "alta → `x` (...)"."""
import re
from res_lib_m12m19 import Doc

R1 = re.compile(r'`(\w+)` \(alta → `\1`(?:[;,] ?)([^)]*)\)')
R2 = re.compile(r'`(\w+)` \(alta → `\1`\)')

for name in ('M13-*', 'M14-*', 'M15-*', 'M16-*', 'M17-*', 'M19-*'):
    d = Doc(name)
    n = 0
    def f1(m):
        return 'alta → `%s` (%s)' % (m.group(1), m.group(2)) if m.group(2) else 'alta → `%s`' % m.group(1)
    d.t, k1 = R1.subn(f1, d.t)
    d.t, k2 = R2.subn(lambda m: 'alta → `%s`' % m.group(1), d.t)
    d.n += k1 + k2
    d.cats[1] = k1 + k2
    d.save()
