# Barrido: capabilities usadas en anexos (filas PAN/API/SM y §4) que no están en T02 (ni alias).
import re, glob, json, collections
MODS = 'pla iam uxd cfg dat int mig nfr com bia wfl per cat med tar fac fis cob mor crm tec ven cmp stk tes con sue ins soc por srv'.split()
T2 = open('anexos/T02-IAM-identidad-roles-auditoria.md', encoding='utf-8').read().split('\n')
i441 = T2.index('#### 4.4.1 Alias de capabilities (nombre anterior → canónico)')
i442 = T2.index('#### 4.4.2 Capabilities registradas por los anexos (mínimo obligatorio ampliado)')
i443 = T2.index('#### 4.4.3 Nombres fuera de convención o sinónimos (canónica propuesta)')
i44 = next(i for i, l in enumerate(T2) if l.startswith('### 4.4 '))
i45 = next(i for i, l in enumerate(T2) if l.startswith('### 4.5 '))
defs, alias, non = set(), set(), set()
for i in range(i44, i45):
    l = T2[i]
    if i441 <= i < i442:
        m = re.match(r'\| `([^`]+)` \|', l)
        if m: alias.add(m.group(1))
    elif i >= i443:
        m = re.match(r'\| [^|]+ \| `([^`]+)`', l)
        if m: non.add(m.group(1))
    else:
        m = re.match(r'\| `([^`]+)`', l)
        if m: defs.add(m.group(1))

tok = re.compile(r'`([a-z]{3}(?:\.[A-Za-z0-9]+){2,3}(?:\.\*)?(?:\.\{[A-Za-z0-9,]+\})?(?:/[A-Za-z0-9]+)*)`')
def expand(s):
    out = []
    m = re.match(r'^(.*)\.\{([^}]+)\}$', s)
    if m:
        return [m.group(1) + '.' + a for a in m.group(2).split(',')]
    if '/' in s:
        head, *rest = s.split('/')
        base = head.rsplit('.', 1)[0]
        return [head] + [base + '.' + r for r in rest]
    return [s]

used = collections.defaultdict(set)
for f in sorted(glob.glob('anexos/*.md')):
    name = f.split('\\')[-1].split('/')[-1]
    if name.startswith('T02-'):
        continue
    L = open(f, encoding='utf-8').read().split('\n')
    sec = ''
    for l in L:
        if l.startswith('## '):
            sec = l[3:6]
        ctx = l.startswith(('| PAN-', '| API-', '| SM-')) or (sec.startswith('4.') and l.startswith('|'))
        if not ctx:
            continue
        for m in tok.finditer(l):
            for c in expand(m.group(1)):
                if c.split('.')[0] not in MODS:
                    continue
                used[c].add(name.split('-')[0])
miss = {c: sorted(v) for c, v in used.items() if c not in defs and c not in alias}
json.dump(miss, open('_trabajo/t02r4_miss.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0, sort_keys=True)
print('usadas', len(used), 'faltan', len(miss))
for c in sorted(miss):
    print(('NC ' if c in non else '   ') + c, ','.join(miss[c]))
