﻿import re,glob
terms=['legalEntit','branches','branchId','pointsOfSale','brandingRef','tenantParameters','configPackages','masterTables','featureFlags','savedViews','sequences','vatConditions','employers','employerId','cardPlans','freightSettlements','tripSettlements','operationCharges','PRCAGAS','tenantUsageSnapshots','processedEvents','restoreDrills','idempotencyKeys','auditEvents','auditLogs','alertEvents','supportAccessGrants','retentionPolicies','legalHolds','bankAccountId','bankAccountRef','vaultRef','credentialRef','fileId','assetId','depotId','stockItemId','documentTypeId','treasuryHandover','EMPRESAS','SU_EMPRESAS','holidays','officialTableAdoptions','payrollOfficialCodes','DEC-043','PPAGOS','paymentOrders','financialEntities','exchangeRates','RN-09 §14','CNX §25','DFA §3']
files={}
for f in sorted(glob.glob('anexos/*.md')):
    b=f[7:]
    if re.match(r'(M11|M14|M16|T01|T02|T04|T08)',b): files[b[:10]]=open(f,encoding='utf-8').read()
print('term'.ljust(24),' '.join(k[:5].ljust(6) for k in files))
for t in terms:
    print(t.ljust(24),' '.join(str(s.count(t)).ljust(6) for s in files.values()))
