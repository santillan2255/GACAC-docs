﻿import glob,re
pat=r'crm\.request\.(admitted|cancelled|received)|tec\.feasibility\.resolved|tec\.installation\.completed|mor\.suspension\.(ordered|scheduled)|mor\.reconnection\.ordered|stk\.unit\.returned|cat\.service\.activated|mor\.service\.suspended|per\.service\.terminated|int\.provisioning\.succeeded|Contrato \(T05\)|soc\.dependent\.cameOfAge|per\.serviceContract\.|fac\.invoice\.voided|cob\.payment\.reversed|fac\.batch\.issued|cmp\.purchaseInvoice\.posted|tes\.paymentOrder\.paid|stk\.movement\.posted'
for f in sorted(glob.glob('anexos/*.md'))+['01-registro-decisiones.md']:
    if 'T11' in f or 'T12' in f: continue
    for i,l in enumerate(open(f,encoding='utf-8').read().split('\n'),1):
        for m in re.finditer(pat,l): print(f[7:10] if f.startswith('anexos') else f[:6],i,m.group(0),'|',l[max(0,m.start()-60):m.end()+40])
