# -*- coding: utf-8 -*-
"""Genera T02 §4.4.2 (capabilities registradas por los anexos) y §4.4.3 (fuera de convención / sinónimos)
a partir de t02caps_a.json (regenerar antes con t02caps_a.py)."""
import json, os, re, sys
from collections import defaultdict, OrderedDict
sys.stdout.reconfigure(encoding='utf-8')
AQUI = os.path.dirname(os.path.abspath(__file__))
T02 = os.path.normpath(os.path.join(AQUI, '..', 'anexos', 'T02-IAM-identidad-roles-auditoria.md'))
d = json.load(open(os.path.join(AQUI, 't02caps_a.json'), encoding='utf-8'))
falt, caps_t02 = d['faltantes'], set(d['caps_t02'])
lines = open(T02, 'rb').read().decode('utf-8').split('\n')

MODS = OrderedDict([
    ('pla', ('T01', 'PLA', 'Plataforma', 'T01 PLA (vista tenant)', 'global')),
    ('iam', ('T02', 'IAM', 'Identidad, roles y auditoría', 'T02 IAM', 'tenant')),
    ('uxd', ('T03', 'UXD', 'Experiencia, marca y diccionario', 'T03 UXD', 'tenant')),
    ('cfg', ('T04', 'CFG', 'Configuración, parámetros y maestros', 'T04 CFG', 'tenant')),
    ('int', ('T06', 'INT', 'Integraciones', 'T06 INT', 'tenant')),
    ('mig', ('T07', 'MIG', 'Migración', 'T07 MIG', 'tenant')),
    ('nfr', ('T08', 'NFR', 'Privacidad y seguridad operativa', 'T08 NFR', 'tenant')),
    ('com', ('T09', 'COM', 'Comunidad y comunicaciones', 'T09 COM', 'tenant')),
    ('bia', ('T10', 'BIA', 'Reportes, BI y APIs', 'T10 BIA', 'tenant')),
    ('wfl', ('T11', 'WFL', 'Workflow, eventos y documentos', 'T11 WFL', 'tenant')),
    ('per', ('M01', 'PER', 'Personas, titulares, cuentas, inmuebles', 'M01 PER', 'suc')),
    ('cat', ('M02', 'CAT', 'Catálogo de servicios', 'M02 CAT', 'tenant')),
    ('med', ('M03', 'MED', 'Medición y consumos', 'M03 MED', 'zona')),
    ('tar', ('M04', 'TAR', 'Tarifas y motor de cálculo', 'M04 TAR', 'tenant')),
    ('fac', ('M05', 'FAC', 'Facturación', 'M05 FAC', 'tenant')),
    ('fis', ('M06', 'FIS', 'Fiscal e impuestos', 'M06 FIS', 'tenant')),
    ('cob', ('M07', 'COB', 'Cuenta corriente y cobranza', 'M07 COB', 'suc')),
    ('mor', ('M08', 'MOR', 'Mora y financiación', 'M08 MOR', 'suc')),
    ('crm', ('M09', 'CRM', 'Atención', 'M09 CRM', 'area')),
    ('tec', ('M10', 'TEC', 'Técnica, campo y redes', 'M10 TEC', 'cua')),
    ('ven', ('M11', 'VEN', 'Ventas y presupuestos', 'M11 VEN', 'suc')),
    ('cmp', ('M12', 'CMP', 'Compras y proveedores', 'M12 CMP', 'tenant')),
    ('stk', ('M13', 'STK', 'Stock y activos', 'M13 STK', 'dep')),
    ('tes', ('M14', 'TES', 'Tesorería y bancos', 'M14 TES', 'tenant')),
    ('con', ('M15', 'CON', 'Contabilidad', 'M15 CON', 'tenant')),
    ('sue', ('M16', 'SUE', 'Personal y sueldos', 'M16 SUE', 'tenant')),
    ('ins', ('M17', 'INS', 'Institucional', 'M17 INS', 'tenant')),
    ('soc', ('M18', 'SOC', 'Servicios sociales y flota', 'M18 SOC', 'tenant')),
    ('por', ('M19', 'POR', 'Landing, portal y app del socio', 'M19 POR', 'tenant')),
])

# ---------- matriz 4.3 ----------
i0 = next(i for i, l in enumerate(lines) if l.startswith('### 4.3'))
hdr = None
MAT = {}
for l in lines[i0:i0 + 40]:
    if l.startswith('| Módulo | T-ADM'):
        hdr = [c.strip() for c in l.strip('|').split('|')]
        continue
    if hdr and l.startswith('| ') and not l.startswith('|---'):
        c = [x.strip() for x in l.strip().strip('|').split('|')]
        if len(c) == len(hdr):
            MAT[c[0]] = dict(zip(hdr[1:], c[1:]))
    if hdr and l.startswith('**Comunidad'):
        break


def levels(cell):
    s = set(re.findall(r'(?<![A-Za-záéíóú])([VOACTPG])(?![a-záéíóú])', cell))
    if 'exp' in cell:
        s.add('X')
    return s


ROLE_ORDER = ['T-ADM', 'T-USR', 'T-GER', 'T-FAC', 'T-CAJ', 'T-CBR', 'T-TES', 'T-CON', 'T-CMP', 'T-DEP', 'T-TEC', 'T-LEC',
              'T-STE', 'T-SCM', 'T-ATE', 'T-SAT', 'T-RRHH', 'T-SEC', 'T-COM', 'T-SOC', 'T-CJO', 'T-SIN']

EN = {'read': 'ver', 'view': 'ver', 'list': 'ver', 'create': 'crear', 'update': 'editar', 'edit': 'editar',
      'delete': 'eliminar', 'write': 'registrar', 'manage': 'gestionar', 'execute': 'ejecutar', 'close': 'cerrar',
      'print': 'imprimir', 'import': 'importar', 'export': 'exportar', 'evaluate': 'evaluar', 'approve': 'aprobar',
      'send': 'enviar', 'assign': 'asignar', 'cancel': 'cancelar', 'run': 'ejecutar', 'publish': 'publicar',
      'configure': 'configurar', 'sign': 'firmar', 'upload': 'subir', 'download': 'descargar', 'bulkClose': 'cerrarMasivo',
      'bulkCreate': 'crearMasivo', 'reopen': 'reabrir', 'schedule': 'programar', 'validate': 'validar', 'review': 'revisar',
      'register': 'registrar', 'dispatch': 'despachar', 'reassign': 'reasignar', 'transfer': 'transferir', 'start': 'iniciar',
      'finish': 'finalizar', 'plan': 'planificar', 'admin': 'administrar', 'operate': 'operar', 'match': 'consultar',
      'track': 'seguir', 'approveClose': 'aprobarCierre', 'reject': 'rechazar', 'monitor': 'monitorear', 'process': 'procesar',
      'generate': 'generar', 'calculate': 'calcular', 'post': 'contabilizar', 'void': 'anular', 'issue': 'emitir',
      'capture': 'capturar', 'rate': 'tasar', 'provision': 'aprovisionar', 'suspend': 'suspender', 'activate': 'activar',
      'reconcile': 'conciliar', 'pay': 'pagar', 'invoice': 'facturar', 'audit': 'auditar', 'search': 'buscar',
      'analyze': 'analizar', 'simulate': 'simular', 'test': 'probar', 'sync': 'sincronizar', 'retry': 'reintentar'}
KEEP_EN = {'com.communications.emit'}   # canónica por CTR-COM-10

# sinónimos explícitos (nombre usado → canónica existente o propuesta)
SYN = {
    'per.personas.verSensibles': 'per.personas.datosSensibles.ver',
    'per.personas.fusionar': 'per.personas.unificar',
    'bia.ia.preguntar': 'bia.ia.consultar',
    'bia.indicadores.certificar': 'bia.cubos.certificar',
    'med.readings.write': 'med.lecturas.capturar',
    'fac.notasDebito.crear': 'fac.notasDebito.emitir',
    'com.outages.gestionar': 'com.outages.crear',
    'com.publicaciones.ver': 'com.posts.ver',
    'pwa.planObra.ver': 'por.planObra.ver',
    'pla.accesos.solicitar': 'pla.soporte.accesos.solicitar', 'pla.accesos.aprobar': 'pla.soporte.accesos.aprobar',
    'pla.accesos.revocar': 'pla.soporte.accesos.revocar', 'pla.accesos.ver': 'pla.soporte.accesos.ver',
    'pla.accesosSoporte.aprobar': 'pla.soporte.accesos.aprobar', 'pla.accesosSoporte.revocar': 'pla.soporte.accesos.revocar',
    'pla.accesosSoporte.ver': 'pla.soporte.accesos.ver',
    'tec.workOrder.read': 'tec.ordenes.ver', 'tec.workOrder.create': 'tec.ordenes.crear',
    'tec.workOrder.execute': 'tec.ordenes.ejecutar', 'tec.workOrder.close': 'tec.ordenes.cerrar',
    'tec.workOrder.assign': 'tec.ordenes.asignar', 'tec.feasibility.evaluate': 'tec.factibilidad.evaluar',
    'tec.network.edit': 'tec.redes.editar', 'tec.network.update': 'tec.redes.editar',
    'tec.provisioning.execute': 'tec.aprovisionamiento.ejecutar', 'tec.cdr.rate': 'tec.telefonia.tasar',
}
SCOPE_API = {'persons:read': 'per.personas.ver', 'accounts:read': 'per.cuentas.ver', 'contracts:read': 'cat.contratos.ver',
             'consumption:read': 'med.consumos.ver', 'billing:read': 'fac.comprobantes.ver', 'collections:read': 'cob.cuentaCorriente.ver',
             'arrears:read': 'mor.deudas.ver', 'field:read': 'tec.ordenes.ver', 'accounting:read': 'con.asientos.ver',
             'ledger:read': 'con.asientos.ver', 'institutional:read': 'ins.asociados.ver', 'payroll:read': 'sue.costos.ver',
             'metrics:read': 'bia.indicadores.ver', 'datasets:read': 'bia.datasets.ver', 'exports:write': 'bia.exportaciones.crear',
             'webhooks:manage': 'int.webhooks.gestionar', 'requests:write': 'crm.casos.crear', 'crm:read': 'crm.casos.ver'}


def norm_res(r):
    r = r.lower()
    for suf in ('es', 's'):
        if r.endswith(suf) and len(r) > 4:
            return r[:-len(suf)]
    return r


existing_norm = {}
for c in caps_t02:
    p = c.split('.')
    if len(p) >= 3:
        existing_norm[(p[0], '.'.join(norm_res(x) for x in p[1:-1]), p[-1])] = c


MAN = {
    'ext.cob.leer': ('cob.cuentaCorriente.ver', 'Prefijo `ext` no es módulo; la exposición externa se marca con X y el scope de T10, no con otro prefijo'),
    'ext.fac.leer': ('fac.comprobantes.ver', 'Prefijo `ext` no es módulo; la exposición externa se marca con X y el scope de T10'),
    'ext.fac.importar': ('fac.comprobantes.importar [VERIFICAR]', 'Prefijo `ext` no es módulo; la exposición externa se marca con X y el scope de T10'),
    'ext.per.cuentas.ver': ('per.cuentas.ver', 'Prefijo `ext` no es módulo; la exposición externa se marca con X y el scope de T10'),
    'ext.per.titulares.ver': ('per.titulares.ver', 'Prefijo `ext` no es módulo; la exposición externa se marca con X y el scope de T10'),
    'cat.read': ('cat.contratos.ver', 'Falta el recurso; API externa (marca X)'),
    'cmp.read': ('cmp.ordenes.ver', 'Falta el recurso; API externa (marca X) [VERIFICAR recurso]'),
    'med.read': ('med.consumos.ver', 'Falta el recurso; API externa (marca X)'),
    'tes.read': ('tes.posicion.ver', 'Falta el recurso; API externa (marca X) [VERIFICAR recurso]'),
    'ven.read': ('ven.presupuestos.ver', 'Falta el recurso; API externa (marca X) [VERIFICAR recurso]'),
    'sue.costoLaboral': ('sue.costoLaboral.ver', 'Falta la acción; API externa (marca X)'),
    'jobRuns.requestedBy': ('— (no es capability: es la condición "solo el solicitante"; alcance `self`)', 'Campo citado en la columna de capability'),
    'storedFiles.moduleCode': ('— (no es capability: el permiso se hereda de la capability del módulo dueño del archivo)', 'Campo citado en la columna de capability'),
    'meta.platformOnly': ('— (no es capability: metadato de pantalla solo de plataforma)', 'Metadato citado en la columna de capability'),
    'plt.uxd.diccionarioBase.ver': ('uxd.diccionarioBase.ver', 'Prefijo `plt` no es módulo; la capability es de T03 con roles de plataforma (alcance `global`)'),
    'plt.uxd.flags.configurar': ('uxd.flags.configurar', 'Prefijo `plt` no es módulo; capability de T03 con roles de plataforma (alcance `global`)'),
    'plt.uxd.marca.asistir': ('uxd.marca.asistir', 'Prefijo `plt` no es módulo; capability de T03 con roles de plataforma (alcance `global`)'),
    'plt.uxd.marca.ver': ('uxd.marca.ver', 'Prefijo `plt` no es módulo; capability de T03 con roles de plataforma (alcance `global`)'),
    'plt.uxd.tokens.ver': ('uxd.tokens.ver', 'Prefijo `plt` no es módulo; capability de T03 con roles de plataforma (alcance `global`)'),
    'platform.tar.funciones.administrar': ('tar.funciones.administrar', 'Prefijo `platform` no es módulo; capability de M04 con roles de plataforma (alcance `global`)'),
    'platform.tar.plantillas.administrar': ('tar.plantillas.administrar', 'Prefijo `platform` no es módulo; capability de M04 con roles de plataforma (alcance `global`)'),
    'plataforma.catalogos.gestionar': ('ins.catalogosBase.gestionar', 'Prefijo `plataforma` no es módulo; capability de M17 con roles de plataforma (alcance `global`)'),
    'public.cuadros.ver': ('— (pantalla pública sin login: no requiere capability)', 'Prefijo `public` no es módulo'),
    'pwa.factura.explicacion.ver': ('tar.explicacion.ver', 'Prefijo `pwa` no es módulo; capability de M04 con alcance `rel` en el portal'),
    'rolesPlantilla.editar': ('iam.rolesPlantilla.editar', 'Falta el prefijo de módulo'),
    'objetivos.ver': ('sue.objetivos.ver [VERIFICAR]', 'Falta el prefijo de módulo'),
    'sumarios.ver': ('sue.sumarios.ver [VERIFICAR]', 'Falta el prefijo de módulo'),
}
RES_EN = {'tec': {'workOrder': 'ordenes', 'feasibility': 'factibilidad', 'network': 'redes', 'provisioning': 'aprovisionamiento',
                  'schedule': 'agenda', 'installation': 'instalaciones', 'map': 'mapa', 'report': 'reportes',
                  'inspection': 'inspecciones', 'maintenance': 'mantenimiento', 'outage': 'cortes', 'work': 'obras'}}


def classify(c):
    """('ok', None) | ('syn', canónica, motivo) | ('nc', propuesta, motivo)"""
    if c in MAN:
        return 'nc', MAN[c][0], MAN[c][1]
    if c in SCOPE_API:
        return 'nc', SCOPE_API[c], 'Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X)'
    if c in SYN:
        tgt = SYN[c]
        return 'syn', tgt, 'Sinónimo de una capability existente' if tgt in caps_t02 else 'Sinónimo; se propone la canónica'
    p = c.split('.')
    if '*' in c or '<' in c:
        return 'nc', '— (explicitar las capabilities concretas por acción)', 'Comodín: no es una capability asignable'
    if p[0] not in MODS:
        alt = {'plt': 'pla', 'platform': 'pla', 'plataforma': 'pla', 'pwa': 'por', 'public': 'por', 'ext': 'bia',
               'objetivos': 'con', 'sumarios': 'sue', 'rolesPlantilla': 'iam', 'meta': 'iam', 'storedFiles': 'wfl',
               'jobRuns': 'wfl'}.get(p[0])
        prop = (alt + '.' + '.'.join(p[1:])) if alt and len(p) >= 3 else (alt + '.' + p[0] + '.' + '.'.join(p[1:]) if alt else '[VERIFICAR]')
        return 'nc', prop, 'Prefijo `%s` no es código de módulo (guía §62)' % p[0]
    if len(p) < 3:
        return 'nc', '%s.<recurso>.%s' % (p[0], EN.get(p[1], p[1])), 'Falta el recurso (`modulo.recurso.accion`)'
    act = p[-1]
    if act in EN and c not in KEEP_EN:
        rm = RES_EN.get(p[0], {})
        prop = '.'.join([p[0]] + [rm.get(x, x) for x in p[1:-1]] + [EN[act]])
        if prop in caps_t02:
            return 'syn', prop, 'Acción en inglés; equivale a una capability existente'
        return 'nc', prop, 'Acción en inglés; la guía §62 fija acciones en español'
    k = (p[0], '.'.join(norm_res(x) for x in p[1:-1]), act)
    if k in existing_norm and existing_norm[k] != c:
        return 'syn', existing_norm[k], 'Variante singular/plural de una capability existente'
    if not re.fullmatch(r'[a-z]{3}(\.[a-z][A-Za-z0-9]*)+', c):
        return 'nc', '[VERIFICAR]', 'No sigue `modulo.recurso.accion` en camelCase'
    return 'ok', None, None


VER = {'ver', 'consultar', 'listar', 'descargar', 'imprimir', 'buscar', 'resultados', 'seguir', 'monitorear', 'previsualizar', 'simular'}
APR = {'aprobar', 'anular', 'autorizar', 'revertir', 'rechazar', 'condonar', 'castigar', 'reabrir', 'liberar', 'firmar',
       'desbloquear', 'publicar', 'certificar', 'refinanciar', 'quitar', 'bonificar', 'excepcion', 'forzar', 'restaurar',
       'aprobarCierre', 'rehabilitar', 'dispensar', 'eximir'}
CFG = {'configurar', 'parametrizar', 'administrar'}
EXP = {'exportar'}


def aclass(act, res):
    if act in VER or act.startswith('ver'):
        return 'V'
    if act in EXP or act.startswith('exportar'):
        return 'X'
    if act in CFG or act.startswith('configurar'):
        return 'C'
    if act in APR or act.startswith('aprobar') or act.startswith('anular') or (act == 'cerrar' and re.search(r'period|ejercicio|cierre', res, re.I)):
        return 'A'
    return 'O'


MARK = {'V': '—', 'O': '—', 'A': 'S D', 'C': 'S', 'X': 'S'}


def contexts(u):
    cx = set()
    for a in u['api']:
        r = a['ruta'] or ''
        if '/api/v1/ext' in r or r.startswith('/v1/'):
            cx.add('ext')
        elif '/api/internal/' in r:
            cx.add('sys')
        elif '/api/platform/' in r or '/admin/platform' in r:
            cx.add('plat')
        elif '/api/public/' in r:
            cx.add('pub')
        elif '/api/admin/' in r or r.startswith('/admin'):
            cx.add('staff')
        elif re.search(r'/field/|my-route|my-stock|/team/', r):
            cx.add('staff')
        elif re.search(r'empleado', r) or (r.startswith('/api/sue/') and re.search(r'/me(/|$)', r)):
            cx.add('emp')
        elif re.search(r'/(me|my)(/|$|-|\?)|/my-|/portal/|^/api/por/|/offers|/inbox|/posts|/surveys|/events|/benefits|/preferences|/notices', r) or r.startswith('/app'):
            cx.add('portal')
        else:
            cx.add('staff')
    for p in u['pan']:
        r = p.get('ruta') or ''
        por = set(p.get('portal') or [])
        mp = {'admin': 'staff', 'campo': 'staff', 'socio': 'portal', 'empleado': 'emp', 'plataforma': 'plat', 'landing': 'pub'}
        if por:
            cx |= {mp.get(x, 'staff') for x in por}
        elif '/admin/plataforma' in r or '/admin/platform' in r:
            cx.add('plat')
        else:
            cx.add('staff')
    return cx or {'staff'}


def roles_for(mod, act, res, cx):
    out, scope = [], []
    k = aclass(act, res)
    row = MAT.get(MODS[mod][3], {})
    if 'staff' in cx:
        sel = []
        for r in ROLE_ORDER:
            lv = levels(row.get(r, '—'))
            if not lv:
                continue
            ok = {'V': lv & set('VOACTP'), 'O': lv & set('OT'), 'A': lv & set('AT'), 'C': lv & set('CT'),
                  'X': lv & set('TX')}[k]
            if k == 'O' and not ok and 'P' in lv:
                sel.append(r + ' (P)')
            elif ok:
                sel.append(r + (' (P)' if lv == {'P'} else ''))
        if not sel:
            sel = ['T-ADM']
        if k == 'X' and 'T-ADM' not in [s.split()[0] for s in sel]:
            sel.insert(0, 'T-ADM')
        out += sel
        scope.append(MODS[mod][4] if mod != 'pla' else 'tenant')
    if 'portal' in cx:
        out += ['C-SOC', 'C-REP']
        scope.append('self' if re.match(r'^(mi|mis|me|propio)', res) else 'rel')
    if 'emp' in cx:
        out += ['C-EMP']
        scope.append('self')
    if 'plat' in cx:
        out += ['P-SUP', 'P-ADM'] + (['P-SEC'] if k == 'V' else [])
        scope.append('global')
    if 'sys' in cx:
        out += ['S-SYS']
        scope.append('tenant')
    if 'ext' in cx:
        out += ['S-API']
        scope.append('tenant')
    if 'pub' in cx:
        out += ['público (sin login)']
        scope.append('público')
    seen = []
    for r in out:
        if r not in seen:
            seen.append(r)
    sc = []
    for s in scope:
        if s not in sc:
            sc.append(s)
    return ', '.join(seen), ' / '.join(sc)


def clean(s):
    s = re.sub(r'\s*Ruta anterior:.*$', '', s or '')
    s = re.sub(r'\s*\((antes|Reemplazado)[^)]*\)', '', s)
    s = re.sub(r'`', '', s)
    s = s.replace('|', '/').strip()
    s = re.sub(r'\s+', ' ', s)
    if len(s) > 130:
        s = s[:127].rsplit(' ', 1)[0] + '…'
    return s[:1].upper() + s[1:] if s else s


ACC = {'ver': 'Ver', 'crear': 'Crear', 'editar': 'Editar', 'anular': 'Anular', 'aprobar': 'Aprobar', 'exportar': 'Exportar',
       'configurar': 'Configurar', 'registrar': 'Registrar', 'gestionar': 'Gestionar', 'ejecutar': 'Ejecutar'}


def human(c):
    p = c.split('.')
    res = ' '.join(re.sub(r'([A-Z])', r' \1', x).lower() for x in p[1:-1])
    return '%s %s' % (ACC.get(p[-1], re.sub(r'([A-Z])', r' \1', p[-1]).capitalize()), res)


def desc_for(c, u):
    for a in u['api']:
        if a['desc'] and a['desc'] not in ('—', '-'):
            return clean(a['desc'])
    for p in u['pan']:
        if p.get('nombre'):
            return clean(p['nombre'])
    return clean(human(c))


def fuente(u):
    ids = []
    for a in u['api']:
        if a['id'] not in ids:
            ids.append(a['id'])
    for p in u['pan']:
        if p['id'] not in ids:
            ids.append(p['id'])
    s = ', '.join(ids[:3])
    if len(ids) > 3:
        s += ' (+%d)' % (len(ids) - 3)
    return s


ok = defaultdict(list)
nc = []
for c in sorted(falt):
    u = falt[c]
    if c.startswith('com.'):
        k = classify(c)
        if k[0] == 'ok':
            continue          # T09: tabla curada en §4.4 (sección T09 COM)
    k = classify(c)
    if k[0] == 'ok':
        p = c.split('.')
        cx = contexts(u)
        roles, scope = roles_for(p[0], p[-1], '.'.join(p[1:-1]), cx)
        mk = MARK[aclass(p[-1], '.'.join(p[1:-1]))]
        if 'ext' in cx:
            mk = (mk + ' X').replace('— X', 'X')
        if re.search(r'sensib|salud|bancari|CBU|clave|secreto|credencial', desc_for(c, u) + ' ' + c, re.I) and 'S' not in mk:
            mk = 'S' if mk == '—' else 'S ' + mk
        ok[p[0]].append((c, desc_for(c, u), mk, roles, scope, fuente(u)))
    else:
        tgt = k[1]
        if re.fullmatch(r'[a-z]{3}(\.[a-z][A-Za-z0-9]*){2,}', tgt) and tgt not in caps_t02 and tgt.split('.')[0] in MODS \
                and not tgt.startswith('com.'):
            p = tgt.split('.')
            prev = next((r for r in ok[p[0]] if r[0] == tgt), None)
            cx = contexts(u)
            if c in SCOPE_API or c.startswith('ext.') or c.endswith('.read') or c == 'sue.costoLaboral':
                cx = cx | {'ext'}
            roles, scope = roles_for(p[0], p[-1], '.'.join(p[1:-1]), cx)
            mk = MARK[aclass(p[-1], '.'.join(p[1:-1]))]
            if 'ext' in cx:
                mk = (mk + ' X').replace('— X', 'X')
            if prev and prev[1].startswith('Canónica propuesta para '):
                ok[p[0]].remove(prev)
                ds = prev[1].replace('Canónica propuesta para ', 'Canónica propuesta para %s, ' % c, 1)
                ok[p[0]].append((tgt, ds, prev[2], prev[3], prev[4], prev[5]))
            ok[p[0]].append((tgt, 'Canónica propuesta para %s. %s' % (c, desc_for(c, u)), mk, roles, scope, fuente(u)))
            ok[p[0]].sort()
        usado = sorted({a['anexo'] for a in u['api']} | {p['anexo'] for p in u['pan']})
        nc.append((c.split('.')[0].split(':')[0], c, k[1], k[2], ', '.join(usado), fuente(u)))

for m in list(ok):
    seen = OrderedDict()
    for r in ok[m]:
        if r[0] in seen:
            a = seen[r[0]]
            un = lambda x, y, s: s.join(dict.fromkeys(x.split(s) + y.split(s)))
            seen[r[0]] = (a[0], a[1], a[2], un(a[3], r[3], ', '), un(a[4], r[4], ' / '), a[5] + ', ' + r[5])
        else:
            seen[r[0]] = r
    ok[m] = sorted(seen.values())

# ---------- texto ----------
out = ['#### 4.4.2 Capabilities registradas por los anexos (mínimo obligatorio ampliado)', '',
       'Capabilities que los anexos usan en sus API (§11) y pantallas (§10, catálogo `17-catalogo-pantallas`) y que siguen la convención `modulo.recurso.accion`. Se registran en `capabilityCatalog` con el módulo dueño indicado en cada subtítulo. Criterios de asignación:',
       '',
       '- **Roles semilla**: se derivan de la matriz 4.3 según la acción: ver → roles con cualquier nivel en el módulo; operar (crear, editar, registrar, gestionar, ejecutar y propias del módulo) → niveles O/T y P (solo propios); aprobar, anular, autorizar, publicar, revertir → A/T; configurar → C/T; exportar → T y "V+exp". Las rutas del portal o la PWA agregan C-SOC y C-REP (alcance `rel`, o `self` si el recurso es propio); las del espacio del empleado, C-EMP; las internas, S-SYS; las de plataforma, P-SUP y P-ADM; las externas `/api/v1/ext`, S-API con marca X.',
       '- **Marcas**: aprobar/anular/autorizar/publicar → S D; configurar y exportar → S; datos sensibles en la descripción → S. El anexo dueño puede endurecer marcas y acotar roles; no puede renombrar.',
       '- **Fuente**: primeras filas API/PAN que la usan (relevamiento de `_trabajo/t02caps_a.py` sobre los anexos al 05-11-2026; regenerable).',
       '- Las capabilities de T09 COM se registran en la tabla de T09 de §4.4 (tabla revisada a mano con los roles de T09 §4).',
       '']
total = 0
for mod, rows in ok.items():
    pass
for mod in MODS:
    rows = ok.get(mod)
    if not rows:
        continue
    a, code, name, _, _ = MODS[mod]
    out += ['##### %s %s — %s (capabilities de los anexos)' % (a, code, name), '',
            '| Capability | Descripción | Marcas | Roles | Alcance | Fuente |', '|---|---|---|---|---|---|']
    for r in rows:
        out.append('| `%s` | %s | %s | %s | %s | %s |' % r)
        total += 1
    out.append('')
out += ['#### 4.4.3 Nombres fuera de convención o sinónimos (canónica propuesta)', '',
        'Nombres usados por los anexos que **no** se registran como capability: no siguen `modulo.recurso.accion` con acción en español, son comodines o duplican una capability existente. Cada anexo debe reemplazarlos por la canónica propuesta (T02 no edita los otros anexos). Hasta que se corrijan, el chequeo de permisos no los reconoce. Las propuestas marcadas [VERIFICAR] requieren decisión del anexo dueño.', '',
        '| Módulo | Nombre usado | Canónica propuesta | Motivo | Anexos que lo usan | Fuente |', '|---|---|---|---|---|---|']
def fmt(p):
    if p.startswith(('—', '[')) or '<' in p:
        return p
    a, _, b = p.partition(' ')
    return '`%s`' % a + (' ' + b if b else '')


for r in sorted(nc, key=lambda x: (x[0], x[1])):
    out.append('| %s | `%s` | %s | %s | %s | %s |' % (r[0], r[1], fmt(r[2]), r[3], r[4], r[5]))
out.append('')
json.dump(dict(registradas=total, por_modulo={m: len(v) for m, v in ok.items()}, fuera=len(nc),
               syn=sum(1 for r in nc if r[3].startswith('Sinónimo') or r[3].startswith('Variante')),
               comodines=sum(1 for r in nc if r[3].startswith('Comodín')),
               ingles=sum(1 for r in nc if r[3].startswith('Acción en inglés')),
               prefijo=sum(1 for r in nc if r[3].startswith('Prefijo')),
               scopes=sum(1 for r in nc if r[3].startswith('Scope'))),
          open(os.path.join(AQUI, 't02_gen_resumen.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
open(os.path.join(AQUI, 't02_gen_out.md'), 'w', encoding='utf-8', newline='\n').write('\n'.join(out))
print('registradas', total, 'fuera de convención/sinónimos', len(nc))
print({m: len(v) for m, v in ok.items()})
