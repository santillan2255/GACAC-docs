| # | `type` referenciado por consumidores | Anexos que lo consumen o mencionan | Candidato canónico emitido (mismo módulo) | Tratamiento |
|---|---|---|---|---|
| 1 | `iam.user.disabled` | T01 | `iam.idp.disabled` | Alias: suscribir al canónico |
| 2 | `cfg.package.published` | T01 | `cfg.configVersion.published` | Alias: suscribir al canónico |
| 3 | `tar.tariffVersion.published` | T01 | `tar.schedule.published` o `tar.rule.published` | Alias: suscribir al canónico |
| 4 | `fis.credential.verified` | T01 | `fis.credential.expiring` o `fis.credential.expired` | Alias: suscribir al canónico |
| 5 | `int.credential.revoked` | T01 | `int.credential.expiring` o `int.credential.rotated` | Alias: suscribir al canónico |
| 6 | `int.connector.healthChanged` | T01 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 7 | `int.webhook.verified` | T01 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 8 | `pla.license.changed` | T02, T10 | `pla.checklist.changed` | Alias: suscribir al canónico |
| 9 | `pla.module.activationChanged` | T02 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 10 | `com.message.statusChanged` | T02 | `com.communication.statusChanged` | Alias: suscribir al canónico |
| 11 | `cfg.config.published` | T02 | `cfg.configVersion.published` | Alias: suscribir al canónico |
| 12 | `fac.invoice.reissued` | T03 | `fac.invoice.issued` o `fac.invoice.dueDatesChanged` | Alias: suscribir al canónico |
| 13 | `pla.tenant.licenseChanged` | T03 | `pla.tenant.statusChanged` o `pla.tenant.reactivated` | Alias: suscribir al canónico |
| 14 | `pla.tenant.capabilityToggled` | T03 | `pla.tenant.statusChanged` o `pla.tenant.reactivated` | Alias: suscribir al canónico |
| 15 | `iam.role.updated` | T03 | `iam.role.changed` o `iam.role.unassigned` | Alias: suscribir al canónico |
| 16 | `iam.user.rolesChanged` | T03 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 17 | `iam.screenProfile.updated` | T03 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 18 | `cfg.branch.created` | T03 | `cfg.configVersion.created` | Alias: suscribir al canónico |
| 19 | `cfg.branch.updated` | T03 | `cfg.platformTable.updated` o `cfg.geoReference.updated` | Alias: suscribir al canónico |
| 20 | `cfg.organization.updated` | T03 | `cfg.platformTable.updated` o `cfg.geoReference.updated` | Alias: suscribir al canónico |
| 21 | `pla.tenant.moduleActivated` | T04 | `pla.tenant.statusChanged` o `pla.tenant.reactivated` | Alias: suscribir al canónico |
| 22 | `int.secret.updated` | T04 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 23 | `cat.serviceCopy.prepared` | T04 | `cat.serviceCopy.completed` | Alias: suscribir al canónico |
| 24 | `fac.batch.approved` | T06 | `fac.billingRun.approved` | Alias: suscribir al canónico |
| 25 | `cob.refund.approved` | T06, M14 | `cob.refund.executed` | Alias: suscribir al canónico |
| 26 | `tec.provisioning.requested` | T06 | `tec.survey.requested` o `tec.material.requested` | Alias: suscribir al canónico |
| 27 | `cob.payment.received` | T07 | `cob.retention.received` | Alias: suscribir al canónico |
| 28 | `fac.batch.simulated` | T07 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 29 | `iam.auth.loginFailed` | T08 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 30 | `iam.authz.crossTenantDenied` | T08 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 31 | `iam.support.accessGranted` | T08 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 32 | `ins.assembly.convened` | T09 | `ins.meeting.convened` | Alias: suscribir al canónico |
| 33 | `tec.installation.completed` | T09, M02, M04 | `tec.installation.activationConfirmed` | Alias: suscribir al canónico |
| 34 | `crm.claim.closed` | T09 | `crm.case.closed` o `crm.activityOccurrence.closed` | Alias: suscribir al canónico |
| 35 | `tec.outage.scheduled` | T09 | `tec.outage.notified` o `tec.outage.finished` | Alias: suscribir al canónico |
| 36 | `cob.prepaidSale.confirmed` | T09 | `cob.payment.confirmed` | Alias: suscribir al canónico |
| 37 | `ven.sale.registered` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 38 | `com.sanction.applied` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 39 | `com.survey.invited` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 40 | `iam.otp.requested` | T09 | `iam.authorization.requested` o `iam.supportAccess.requested` | Alias: suscribir al canónico |
| 41 | `iam.password.resetRequested` | T09 | `iam.password.changed` o `iam.password.resetCompleted` | Alias: suscribir al canónico |
| 42 | `iam.user.invited` | T09 | `iam.membership.invited` | Alias: suscribir al canónico |
| 43 | `per.contact.verificationRequested` | T09 | `per.contact.changed` | Alias: suscribir al canónico |
| 44 | `por.registration.completed` | T09 | `por.legacyImport.completed` | Alias: suscribir al canónico |
| 45 | `por.account.linked` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 46 | `por.authorization.granted` | T09 | `por.accountAccess.granted` | Alias: suscribir al canónico |
| 47 | `crm.request.received` | T09 | `crm.message.received` o `crm.cancellationRequest.received` | Alias: suscribir al canónico |
| 48 | `crm.request.statusChanged` | T09 | `crm.case.statusChanged` | Alias: suscribir al canónico |
| 49 | `crm.claim.registered` | T09 | `crm.deskEntry.registered` | Alias: suscribir al canónico |
| 50 | `crm.claim.updated` | T09 | `crm.incident.updated` | Alias: suscribir al canónico |
| 51 | `crm.claim.resolved` | T09 | `crm.case.resolved` | Alias: suscribir al canónico |
| 52 | `crm.claim.reopened` | T09 | `crm.case.reopened` | Alias: suscribir al canónico |
| 53 | `crm.appointment.confirmed` | T09 | `crm.incident.confirmed` | Alias: suscribir al canónico |
| 54 | `crm.appointment.called` | T09 | `crm.queueTicket.called` | Alias: suscribir al canónico |
| 55 | `crm.webRequest.registered` | T09 | `crm.deskEntry.registered` | Alias: suscribir al canónico |
| 56 | `tec.visit.scheduled` | T09, M19 | `tec.visit.failed` o `tec.visit.statusChanged` | Alias: suscribir al canónico |
| 57 | `tec.visit.rescheduled` | T09 | `tec.visit.failed` o `tec.visit.statusChanged` | Alias: suscribir al canónico |
| 58 | `cat.service.activated` | T09 | `cat.contract.activated` | Alias: suscribir al canónico |
| 59 | `tec.workOrder.confirmed` | T09, M04 | `tec.provisioning.confirmed` | Alias: suscribir al canónico |
| 60 | `tec.workOrder.responsibleNotified` | T09 | `tec.workOrder.created` o `tec.workOrder.statusChanged` | Alias: suscribir al canónico |
| 61 | `tec.outage.started` | T09 | `tec.outage.notified` o `tec.outage.finished` | Alias: suscribir al canónico |
| 62 | `tec.outage.restored` | T09 | `tec.outage.notified` o `tec.outage.finished` | Alias: suscribir al canónico |
| 63 | `med.meter.changed` | T09 | `med.meter.installed` o `med.meter.removed` | Alias: suscribir al canónico |
| 64 | `med.reading.estimated` | T09 | `med.reading.captured` o `med.reading.corrected` | Alias: suscribir al canónico |
| 65 | `med.prepaid.recharged` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 66 | `fac.invoice.voided` | T09, T10, M03, M04, M07, M11, M17, M18 | `fac.invoice.issued` o `fac.invoice.dueDatesChanged` | Alias: suscribir al canónico |
| 67 | `cob.paymentLink.requested` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 68 | `cob.payment.rejected` | T09, M19 | `cob.directDebit.rejected` | Alias: suscribir al canónico |
| 69 | `cob.directDebit.adhered` | T09, M19 | `cob.directDebit.rejected` | Alias: suscribir al canónico |
| 70 | `cob.refund.processed` | T09 | `cob.refund.executed` | Alias: suscribir al canónico |
| 71 | `mor.suspension.scheduled` | T09 | `mor.interruption.scheduled` | Alias: suscribir al canónico |
| 72 | `mor.service.suspended` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 73 | `mor.service.reconnected` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 74 | `mor.agreement.installmentDue` | T09 | `mor.agreement.completed` o `mor.agreement.activated` | Alias: suscribir al canónico |
| 75 | `per.service.terminated` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 76 | `pla.supportTicket.created` | T09 | `pla.sandbox.created` o `pla.tenant.created` | Alias: suscribir al canónico |
| 77 | `pla.notice.published` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 78 | `cmp.quote.requested` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 79 | `ins.member.admitted` | T09 | `ins.member.withoutServices` | Alias: suscribir al canónico |
| 80 | `com.mention.created` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 81 | `com.event.rsvpConfirmed` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 82 | `com.benefit.published` | T09 | `com.post.published` | Alias: suscribir al canónico |
| 83 | `com.post.reviewRequested` | T09 | `com.post.published` | Alias: suscribir al canónico |
| 84 | `com.survey.published` | T09 | `com.post.published` | Alias: suscribir al canónico |
| 85 | `com.survey.responseSubmitted` | T09, M09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 86 | `com.event.waitlistPromoted` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 87 | `com.outage.scheduled` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 88 | `com.outage.started` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 89 | `com.outage.rescheduled` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 90 | `com.outage.restored` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 91 | `com.newsletter.issued` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 92 | `iam.membership.changed` | T09, M19 | `iam.role.changed` o `iam.profile.changed` | Alias: suscribir al canónico |
| 93 | `iam.mfa.changed` | T09 | `iam.role.changed` o `iam.profile.changed` | Alias: suscribir al canónico |
| 94 | `iam.authorization.decided` | T09 | `iam.authorization.consumed` o `iam.authorization.requested` | Alias: suscribir al canónico |
| 95 | `com.platformNotice.published` | T09 | `com.post.published` | Alias: suscribir al canónico |
| 96 | `por.delegation.changed` | T09 | `por.delegation.accepted` o `por.delegation.invited` | Alias: suscribir al canónico |
| 97 | `por.formSubmission.received` | T09 | `por.publicSubmission.received` | Alias: suscribir al canónico |
| 98 | `por.formSubmission.decided` | T09 | `por.formSubmission.submitted` o `por.formSubmission.accepted` | Alias: suscribir al canónico |
| 99 | `crm.circular.issued` | T09 | `crm.queueTicket.issued` | Alias: suscribir al canónico |
| 100 | `com.post.decided` | T09 | `com.post.published` | Alias: suscribir al canónico |
| 101 | `com.event.changed` | T09 | `com.preference.changed` | Alias: suscribir al canónico |
| 102 | `com.benefit.issued` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 103 | `com.preference.unsubscribed` | T09 | `com.preference.changed` | Alias: suscribir al canónico |
| 104 | `tec.installation.activated` | T09 | `tec.installation.activationConfirmed` | Alias: suscribir al canónico |
| 105 | `ven.quote.closed` | T09 | `ven.posSession.closed` | Alias: suscribir al canónico |
| 106 | `fis.contingency.changed` | T09 | `fis.contingency.activated` o `fis.contingency.deactivated` | Alias: suscribir al canónico |
| 107 | `fis.filing.statusChanged` | T09 | `fis.filing.rejected` o `fis.filing.generated` | Alias: suscribir al canónico |
| 108 | `tar.schedule.approvalRequested` | T09 | `tar.schedule.activated` o `tar.schedule.approved` | Alias: suscribir al canónico |
| 109 | `cob.paymentLink.statusChanged` | T09 | `cob.paymentIntent.statusChanged` | Alias: suscribir al canónico |
| 110 | `cob.remittanceImport.failed` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 111 | `mor.promise.changed` | T09 | `mor.promise.broken` o `mor.promise.kept` | Alias: suscribir al canónico |
| 112 | `mor.agreement.changed` | T09 | `mor.agreement.completed` o `mor.agreement.activated` | Alias: suscribir al canónico |
| 113 | `cmp.supplyRequest.decided` | T09 | `cmp.portalSubmission.decided` o `cmp.matchException.decided` | Alias: suscribir al canónico |
| 114 | `cmp.portalSubmission.changed` | T09 | `cmp.portalSubmission.received` o `cmp.portalSubmission.decided` | Alias: suscribir al canónico |
| 115 | `sue.leave.changed` | T09 | `sue.leave.rejected` o `sue.leave.requested` | Alias: suscribir al canónico |
| 116 | `com.outage.criticalAffected` | T09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 117 | `com.consent.changed` | T09 | `com.preference.changed` | Alias: suscribir al canónico |
| 118 | `cob.ledgerEntry.posted` | T10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 119 | `con.journalEntry.posted` | T10, M06 | `con.inflationAdjustment.posted` o `con.entry.posted` | Alias: suscribir al canónico |
| 120 | `sue.payroll.closed` | T10, M06 | `sue.payrollRun.closed` | Alias: suscribir al canónico |
| 121 | `fac.billingBatch.closed` | T10 | `fac.billingCycle.closed` o `fac.billingRun.closed` | Alias: suscribir al canónico |
| 122 | `cob.cashbox.closed` | T10 | `cob.cashSession.closed` | Alias: suscribir al canónico |
| 123 | `mor.notificationBatch.generated` | T10 | `mor.batch.generated` | Alias: suscribir al canónico |
| 124 | `med.readingCycle.closed` | T10 | `med.readingBatch.closed` | Alias: suscribir al canónico |
| 125 | `iam.membership.deactivated` | T10 | `iam.membership.invited` o `iam.membership.activated` | Alias: suscribir al canónico |
| 126 | `iam.roleAssignment.revoked` | T10 | `iam.session.revoked` o `iam.apiClient.revoked` | Alias: suscribir al canónico |
| 127 | `iam.roleAssignment.changed` | T10 | `iam.role.changed` o `iam.profile.changed` | Alias: suscribir al canónico |
| 128 | `cfg.version.published` | T10 | `cfg.configVersion.published` | Alias: suscribir al canónico |
| 129 | `fis.authorization.granted` | T10 | `fis.authorization.detained` o `fis.authorization.uncertain` | Alias: suscribir al canónico |
| 130 | `cob.payment.reversed` | T10, M08, M17, M18 | `cob.allocation.reversed` | Alias: suscribir al canónico |
| 131 | `mor.reconnection.executed` | T10, M09 | `mor.interruption.executed` o `mor.prescription.executed` | Alias: suscribir al canónico |
| 132 | `crm.request.processed` | T10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 133 | `bia.webhook.disabled` | T10 | `bia.webhookSubscription.disabled` | Alias: suscribir al canónico |
| 134 | `bia.api.legacyRefsExposed` | T10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 135 | `bia.sem.billed` | T10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 136 | `bia.sem.collected` | T10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 137 | `bia.sem.credited` | T10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 138 | `bia.sem.connected` | T10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 139 | `bia.sem.committed` | T10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 140 | `cat.category.changed` | M01, M03 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 141 | `cat.serviceContract.activated` | M01, M17 | `cat.contract.activated` | Alias: suscribir al canónico |
| 142 | `cat.serviceContract.categoryChanged` | M01 | `cat.contract.categoryChanged` | Alias: suscribir al canónico |
| 143 | `tec.location.proposed` | M01 | `tec.charge.proposed` | Alias: suscribir al canónico |
| 144 | `ins.membership.changed` | M01 | `ins.membership.reinstated` o `ins.membership.exitRequested` | Alias: suscribir al canónico |
| 145 | `iam.user.registered` | M01, M19 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 146 | `iam.user.deleted` | M01 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 147 | `crm.request.admitted` | M02 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 148 | `tec.feasibility.resolved` | M02 | `tec.syncConflict.resolved` | Alias: suscribir al canónico |
| 149 | `mor.suspension.ordered` | M02, M10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 150 | `mor.reconnection.ordered` | M02, M03, M10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 151 | `mor.prepaidConversion.ordered` | M02 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 152 | `per.holder.deactivated` | M02 | `per.holder.created` o `per.holder.reopened` | Alias: suscribir al canónico |
| 153 | `stk.unit.returned` | M02, M15 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 154 | `stk.unit.replaced` | M02, M15 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 155 | `fac.cycle.closed` | M02 | `fac.billingCycle.closed` o `fac.billingRun.closed` | Alias: suscribir al canónico |
| 156 | `pla.capability.revoked` | M02 | `pla.supportGrant.revoked` | Alias: suscribir al canónico |
| 157 | `pla.license.expired` | M02 | `pla.supportGrant.expired` | Alias: suscribir al canónico |
| 158 | `per.serviceContract.activated` | M03, M18 | `per.holder.activated` | Alias: suscribir al canónico |
| 159 | `stk.serialItem.statusChanged` | M03 | `stk.rma.statusChanged` | Alias: suscribir al canónico |
| 160 | `mor.disconnection.ordered` | M03 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 161 | `med.meter.alreadyInstalled` | M03 | `med.meter.installed` o `med.meter.removed` | Alias: suscribir al canónico |
| 162 | `tec.cdr.imported` | M04 | `tec.mobileUsage.imported` | Alias: suscribir al canónico |
| 163 | `fac.batch.discarded` | M04 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 164 | `cat.plan.changed` | M04 | `cat.plan.discontinued` o `cat.plan.published` | Alias: suscribir al canónico |
| 165 | `fis.taxConfig.published` | M04 | `fis.normativeVersion.published` | Alias: suscribir al canónico |
| 166 | `cfg.parameter.published` | M04 | `cfg.configVersion.published` | Alias: suscribir al canónico |
| 167 | `cfg.fxRate.published` | M04 | `cfg.configVersion.published` | Alias: suscribir al canónico |
| 168 | `cfg.inflationIndex.published` | M04 | `cfg.configVersion.published` | Alias: suscribir al canónico |
| 169 | `tar.version.published` | M04, M05 | `tar.schedule.published` o `tar.rule.published` | Alias: suscribir al canónico |
| 170 | `tar.call.rated` | M04, M10 | `tar.calls.rated` | Alias: suscribir al canónico |
| 171 | `fis.invoice.observed` | M05 | `fis.invoice.authorized` | Alias: suscribir al canónico |
| 172 | `fis.invoice.rejected` | M05 | `fis.filing.rejected` o `fis.authorization.rejected` | Alias: suscribir al canónico |
| 173 | `med.consumption.revoked` | M05 | `med.consumption.voided` o `med.consumption.blocked` | Alias: suscribir al canónico |
| 174 | `cat.contract.updated` | M05 | `cat.contract.reactivationRequested` o `cat.contract.requested` | Alias: suscribir al canónico |
| 175 | `com.communication.delivered` | M05, M09 | `com.communication.statusChanged` o `com.communication.failed` | Alias: suscribir al canónico |
| 176 | `mor.interestCharge.requested` | M05 | `mor.interruption.requested` | Alias: suscribir al canónico |
| 177 | `cob.allocation.applied` | M06, M17 | `cob.chargeback.applied` | Alias: suscribir al canónico |
| 178 | `cmp.paymentOrder.prepared` | M06 | `cmp.paymentOrder.paid` o `cmp.paymentOrder.cancelled` | Alias: suscribir al canónico |
| 179 | `tes.movement.confirmed` | M06 | `tes.payrollPayment.confirmed` | Alias: suscribir al canónico |
| 180 | `per.person.fiscalDataChanged` | M06 | `per.person.merged` o `per.person.deceased` | Alias: suscribir al canónico |
| 181 | `pla.tenant.restored` | M06 | `pla.tenant.statusChanged` o `pla.tenant.reactivated` | Alias: suscribir al canónico |
| 182 | `tes.bankMovement.matched` | M07 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 183 | `fac.batch.issued` | M07, M17 | `fac.invoice.issued` o `fac.creditNote.issued` | Alias: suscribir al canónico |
| 184 | `cob.treasuryHandover.received` | M07 | `cob.retention.received` | Alias: suscribir al canónico |
| 185 | `mor.charge.created` | M07 | `mor.deferredInterest.created` o `mor.notice.created` | Alias: suscribir al canónico |
| 186 | `tes.bankMovement.unmatched` | M07 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 187 | `fac.fiscal.authorized` | M07 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 188 | `fac.fiscal.failed` | M07 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 189 | `tes.treasuryHandover.received` | M07 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 190 | `int.sftp.fileReceived` | M07 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 191 | `com.message.delivered` | M08 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 192 | `tec.workOrder.completed` | M08, M09, M11 | `tec.workOrder.created` o `tec.workOrder.statusChanged` | Alias: suscribir al canónico |
| 193 | `int.provisioning.succeeded` | M08 | `int.operation.succeeded` | Alias: suscribir al canónico |
| 194 | `tec.workOrder.failed` | M08, M11 | `tec.provisioning.failed` o `tec.visit.failed` | Alias: suscribir al canónico |
| 195 | `int.provisioning.failed` | M08 | `int.message.failed` o `int.operation.failed` | Alias: suscribir al canónico |
| 196 | `cob.chargeback.registered` | M08 | `cob.obligation.registered` | Alias: suscribir al canónico |
| 197 | `cob.payment.informed` | M08 | `cob.payment.confirmed` | Alias: suscribir al canónico |
| 198 | `crm.request.created` | M08 | `crm.case.created` | Alias: suscribir al canónico |
| 199 | `com.message.accepted` | M08 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 200 | `cat.contract.created` | M09 | `cat.contract.reactivationRequested` o `cat.contract.requested` | Alias: suscribir al canónico |
| 201 | `tec.feasibility.completed` | M09 | `tec.feasibility.verdictIssued` o `tec.feasibility.requested` | Alias: suscribir al canónico |
| 202 | `cat.command.rejected` | M09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 203 | `per.account.ownerTransferred` | M09 | `per.account.closed` o `per.account.principalChanged` | Alias: suscribir al canónico |
| 204 | `tec.network.outageDetected` | M09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 205 | `fac.adjustment.issued` | M09 | `fac.invoice.issued` o `fac.creditNote.issued` | Alias: suscribir al canónico |
| 206 | `mor.suspension.executed` | M09 | `mor.interruption.executed` o `mor.prescription.executed` | Alias: suscribir al canónico |
| 207 | `int.localAgent.statusChanged` | M09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 208 | `crm.priority.defaultUnclassified` | M09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 209 | `crm.notify.onCreated` | M09 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 210 | `crm.queue.called` | M09 | `crm.queueTicket.called` | Alias: suscribir al canónico |
| 211 | `crm.case.workOrderRequested` | M10 | `crm.case.derived` o `crm.case.closed` | Alias: suscribir al canónico |
| 212 | `crm.case.feasibilityRequested` | M10 | `crm.case.derived` o `crm.case.closed` | Alias: suscribir al canónico |
| 213 | `mor.suspension.revoked` | M10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 214 | `tec.feasibility.expired` | M10 | `tec.feasibility.verdictIssued` o `tec.feasibility.requested` | Alias: suscribir al canónico |
| 215 | `tec.feasibility.alreadyUsed` | M10 | `tec.feasibility.verdictIssued` o `tec.feasibility.requested` | Alias: suscribir al canónico |
| 216 | `tec.workOrder.locked` | M10 | `tec.workOrder.created` o `tec.workOrder.statusChanged` | Alias: suscribir al canónico |
| 217 | `tec.booking.expired` | M10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 218 | `tec.material.exceedsAuthorized` | M10 | `tec.material.returned` o `tec.material.used` | Alias: suscribir al canónico |
| 219 | `con.contract.created` | M10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 220 | `con.contract.planChanged` | M10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 221 | `con.contract.terminated` | M10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 222 | `fac.estimate.accepted` | M10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 223 | `med.anomaly.detected` | M10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 224 | `iam.user.deactivated` | M10 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 225 | `ven.salesOrder.invoiced` | M11 | `ven.operationCharge.invoiced` | Alias: suscribir al canónico |
| 226 | `crm.request.approved` | M11 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 227 | `mor.reconnection.requested` | M11 | `mor.interruption.requested` | Alias: suscribir al canónico |
| 228 | `cob.payment.allocated` | M11, M19 | `cob.payment.confirmed` | Alias: suscribir al canónico |
| 229 | `stk.reservation.failed` | M11 | `stk.reservation.released` o `stk.reservation.expired` | Alias: suscribir al canónico |
| 230 | `stk.movement.confirmed` | M11, M12 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 231 | `cat.concept.versionPublished` | M11 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 232 | `stk.movement.rejected` | M12 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 233 | `stk.reorderPoint.reached` | M12 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 234 | `tec.workOrder.materialsRequested` | M12 | `tec.workOrder.created` o `tec.workOrder.statusChanged` | Alias: suscribir al canónico |
| 235 | `cmp.invoice.priceVarianceDetected` | M13, M15 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 236 | `tec.workOrder.scheduled` | M13 | `tec.workOrder.created` o `tec.workOrder.statusChanged` | Alias: suscribir al canónico |
| 237 | `cat.serviceContract.terminated` | M13, M17 | `cat.contract.terminated` | Alias: suscribir al canónico |
| 238 | `cfg.index.published` | M13 | `cfg.configVersion.published` | Alias: suscribir al canónico |
| 239 | `stk.consumption.recorded` | M13 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 240 | `sue.payrollPayment.requested` | M14 | `sue.leave.requested` | Alias: suscribir al canónico |
| 241 | `cob.cashSession.reopened` | M14 | `cob.obligation.reopened` | Alias: suscribir al canónico |
| 242 | `cob.payment.voided` | M14 | `cob.receipt.voided` | Alias: suscribir al canónico |
| 243 | `cob.gatewaySettlement.expected` | M14 | `cob.settlement.expected` | Alias: suscribir al canónico |
| 244 | `cob.unidentified.resolved` | M14 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 245 | `fis.obligation.dueRegistered` | M14 | `fis.obligation.created` | Alias: suscribir al canónico |
| 246 | `fis.withholdingComputation.updated` | M14 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 247 | `con.journalEntry.created` | M14 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 248 | `cmp.supplierInvoice.posted` | M15 | `cmp.supplierInvoice.registered` o `cmp.supplierInvoice.released` | Alias: suscribir al canónico |
| 249 | `cmp.creditNote.posted` | M15 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 250 | `stk.revaluation.posted` | M15 | `stk.adjustment.posted` o `stk.depreciation.posted` | Alias: suscribir al canónico |
| 251 | `stk.fixedAsset.capitalized` | M15 | `stk.fixedAsset.valueChanged` o `stk.fixedAsset.disposed` | Alias: suscribir al canónico |
| 252 | `stk.fixedAsset.improved` | M15 | `stk.fixedAsset.valueChanged` o `stk.fixedAsset.disposed` | Alias: suscribir al canónico |
| 253 | `stk.fixedAsset.inflationAdjusted` | M15 | `stk.fixedAsset.valueChanged` o `stk.fixedAsset.disposed` | Alias: suscribir al canónico |
| 254 | `stk.productionOrder.started` | M15 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 255 | `tec.work.completed` | M15 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 256 | `tes.paymentRequest.settled` | M16 | `tes.paymentRequest.create` | Alias: suscribir al canónico |
| 257 | `tec.crewTimesheet.approved` | M16 | `tec.levy.approved` | Alias: suscribir al canónico |
| 258 | `soc.vehicleUsage.closed` | M16 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 259 | `soc.vehicleUsage.voided` | M16 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 260 | `med.readingRoute.completed` | M16 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 261 | `mor.cutOrder.executed` | M16 | `mor.interruption.executed` o `mor.prescription.executed` | Alias: suscribir al canónico |
| 262 | `tes.paymentRequest.accepted` | M16 | `tes.cashRemittance.accepted` | Alias: suscribir al canónico |
| 263 | `con.entry.failed` | M16, M17 | `con.export.failed` o `con.event.failed` | Alias: suscribir al canónico |
| 264 | `iam.user.linked` | M16 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 265 | `cfg.officialTable.published` | M16 | `cfg.configVersion.published` | Alias: suscribir al canónico |
| 266 | `fac.invoice.adjusted` | M17 | `fac.invoice.issued` o `fac.invoice.dueDatesChanged` | Alias: suscribir al canónico |
| 267 | `mor.agreement.voided` | M17 | `mor.agreement.completed` o `mor.agreement.activated` | Alias: suscribir al canónico |
| 268 | `ins.capital.closed` | M17 | `ins.meeting.closed` | Alias: suscribir al canónico |
| 269 | `ins.refund.annualLimitReached` | M17 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 270 | `ins.meeting.reserved` | M17 | `ins.meeting.closed` o `ins.meeting.convened` | Alias: suscribir al canónico |
| 271 | `ins.vote.closed` | M17 | `ins.meeting.closed` | Alias: suscribir al canónico |
| 272 | `ven.salesDocument.issued` | M17, M18 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 273 | `ven.salesDocument.voided` | M17 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 274 | `tes.paymentOrder.voided` | M17 | `tes.cashRemittance.voided` o `tes.paymentExecution.voided` | Alias: suscribir al canónico |
| 275 | `per.relationship.changed` | M18 | `per.ownership.changed` o `per.address.changed` | Alias: suscribir al canónico |
| 276 | `tec.workOrder.assigned` | M18 | `tec.workOrder.created` o `tec.workOrder.statusChanged` | Alias: suscribir al canónico |
| 277 | `cmp.purchaseInvoice.posted` | M18 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 278 | `soc.act.unauthorized` | M18 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 279 | `soc.housing.cashRegisterClosed` | M18 | `soc.housing.priceUpdated` o `soc.housing.allocated` | Alias: suscribir al canónico |
| 280 | `soc.driver.licenseExpired` | M18 | `soc.driver.timeReported` | Alias: suscribir al canónico |
| 281 | `per.serviceContract.disconnected` | M18 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 282 | `stk.movement.posted` | M18 | `stk.adjustment.posted` o `stk.depreciation.posted` | Alias: suscribir al canónico |
| 283 | `per.contract.activated` | M19 | `per.holder.activated` | Alias: suscribir al canónico |
| 284 | `per.contract.suspended` | M19 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 285 | `per.contract.reactivated` | M19 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 286 | `per.contract.terminated` | M19 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 287 | `per.account.ownerChanged` | M19 | `per.account.closed` o `per.account.principalChanged` | Alias: suscribir al canónico |
| 288 | `tec.visit.completed` | M19 | `tec.visit.failed` o `tec.visit.statusChanged` | Alias: suscribir al canónico |
| 289 | `per.relation.validated` | M19 | `per.document.validated` | Alias: suscribir al canónico |
| 290 | `cat.offer.changed` | M19 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 291 | `med.selfReading.validated` | M19 | `med.selfReading.accepted` o `med.selfReading.rejected` | Alias: suscribir al canónico |
| 292 | `med.prepaid.credited` | M19 | — | Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira |
| 293 | `sue.payslip.published` | M19 | `sue.payrollConfig.published` o `sue.salaryScale.published` | Alias: suscribir al canónico |
