import sys, re, glob, os
sys.stdout.reconfigure(encoding='utf-8')
A = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
# uso: python res_m0711_find.py M07 campo1 campo2 ...  (busca en §7 y muestra línea + heading actual)
mod = sys.argv[1]
f = glob.glob(os.path.join(A, mod + '-*.md'))[0]
lines = open(f, encoding='utf-8-sig').read().split('\n')
sec = None
ini = fin = None
for i, l in enumerate(lines):
    if l.startswith('## 7.'):
        ini = i
    elif ini is not None and l.startswith('## ') and fin is None and i > ini:
        fin = i
        break
for name in sys.argv[2:]:
    print('=====', name)
    head = ''
    for i in range(ini, fin):
        l = lines[i]
        if re.match(r'^#{3,5} ', l) or re.match(r'^\*\*`', l):
            head = l[:90]
        if re.search(r'`' + re.escape(name) + r'(`|\b)', l) or re.search(r'\b' + re.escape(name) + r'\b', l):
            print('  %d [%s] %s' % (i + 1, head, l[:260]))
