import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from g_cierre_lib import Doc

# ---------------- T04 ----------------
d = Doc('T04-CFG-configuracion-parametros-maestros.md')
d.rep("| `economicIndexValues` | `seriesCode`, `date` o `period`",
      "| `economicIndexValues` | `seriesId` (antes `seriesCode`; nombre de T05 COL-CFG-22), `date` o `period`")
d.rep("| `{tenantId, seriesCode, date, recordedAt}` |", "| `{tenantId, seriesId, date, recordedAt}` |")
d.rep("`platformTableReleases`: `tableCode` o `seriesCode`,", "`platformTableReleases`: `tableCode` o `seriesId` (antes `seriesCode`),")
d.rep("`platformTableAdoptions`: `tenantId`, `tableCode`/`seriesCode`,", "`platformTableAdoptions`: `tenantId`, `tableCode`/`seriesId` (antes `seriesCode`),")
d.rep("`economicIndexValues.seriesCode` → `economicIndexSeries.code` (T04; clave natural compartida con `platformTableReleases` y `platformTableAdoptions`; T05 COL-CFG-22 la nombra `seriesId`, diferencia informada a T05)",
      "`economicIndexValues.seriesId` → `economicIndexSeries` (T04; el mismo campo usan `platformTableReleases` y `platformTableAdoptions` para las series; nombre de T05 COL-CFG-22, que prevalece; antes `seriesCode` → `economicIndexSeries.code` como clave natural)")
d.rep("| Ingesta o carga | `seriesCode`, `date`, `value` |", "| Ingesta o carga | `seriesId` (antes `seriesCode`), `date`, `value` |")
d.rep("| EVT-CFG-16 | `cfg.customField.defined` / `.deprecated` | Publicación | `entity`, `key` | Módulo dueño de la entidad, T10 |",
      "| EVT-CFG-16 | `cfg.customField.defined` / `.deprecated` | Publicación | `entity`, `key` | Dueño de la entidad extendida según §7.11: M01 (`person`, `account`, `property`), M02 (`serviceContract`, `category`, `product` comercial), M09 (`ticket`), M10 (`workOrder`), M12 (`supplier`), M13 (`product` de stock, `fixedAsset`), M16 (`employee`); T10; T11 (formularios) (antes \"Módulo dueño de la entidad, T10\") |")
d.rep("si `historized`, `customFieldHistory: [{ key, value, validFrom, validTo, recordedAt, by }]`.\n\n`formCustomizations`",
      "si `historized`, `customFieldHistory: [{ key, value, validFrom, validTo, recordedAt, by }]`.\n\n"
      "Entidades con campos extra (valores del enum `entity`) y anexo dueño de cada una; el dueño consume EVT-CFG-16:\n\n"
      "| `entity` | Anexo dueño |\n|---|---|\n"
      "| `person`, `account`, `property` | M01 |\n"
      "| `serviceContract`, `category`, `product` (producto comercial) | M02 |\n"
      "| `ticket` | M09 |\n"
      "| `workOrder` | M10 |\n"
      "| `supplier` | M12 |\n"
      "| `product` (artículo de stock), `fixedAsset` | M13 |\n"
      "| `employee` | M16 |\n\n"
      "`formCustomizations`")
d.rep("| `pla.cfg.tablasPlataforma.*` | Releases de tablas de plataforma. |",
      "| `pla.cfg.tablasPlataforma.editar` (GET y POST de releases), `pla.cfg.tablasPlataforma.publicar` (`/:id/publish`) (antes `pla.cfg.tablasPlataforma.*`, comodín; T02 §4.4.3) | Releases de tablas de plataforma. |")
d.renames += 1
d.save()

# ---------------- T06 ----------------
d = Doc('T06-INT-integraciones.md')
d.rep("`businessRef`, `status` (§8.12),", "`businessRef`, `status` (`ok`, `error`, `blocked`; §8.12; PA-INT-26),")
d.rep("cada llamada se escribe con su `status` final (`succeeded`, `failed`, `blockedByPolicy` [VERIFICAR]) y no cambia;",
      "cada llamada se escribe con su `status` final (`ok`, `error`, `blocked`: bloqueada por política o porque la IA está apagada en el tenant; PA-INT-26, Asumida DEC-072; antes `succeeded`, `failed`, `blockedByPolicy` [VERIFICAR]) y no cambia;")
d.rep("| PA-INT-25 | Asumida (recomendada) | A. |\n",
      "| PA-INT-25 | Asumida (recomendada) | A. |\n| PA-INT-26 | Asumida (DEC-072) | A: `aiUsageLogs.status` toma `ok`, `error` o `blocked`. |\n")
d.rep("- **Bloquea:** FI-INT-92.\n\n## 22. Trazabilidad de fuentes",
      "- **Bloquea:** FI-INT-92.\n\n"
      "### PA-INT-26 — Estados de `aiUsageLogs`\n\n"
      "- **Pregunta:** ¿Qué valores toma `aiUsageLogs.status`?\n"
      "- **Contexto:** §7.16 y §8.12 declaraban `succeeded`, `failed` y `blockedByPolicy` [VERIFICAR]; el registro es inmutable y solo cambia `outcome`.\n"
      "- **Opciones:**\n"
      "  - A) `ok`, `error` y `blocked` (bloqueada por política o porque la IA está apagada en el tenant) **(Recomendada)**.\n"
      "  - B) Sin estado: solo un código de resultado.\n"
      "- **Impacto si no se responde:** se asume A.\n"
      "- **Bloquea:** RF-INT-086; FI-INT-90.\n"
      "- **Estado:** Asumida (DEC-072): opción A.\n\n"
      "## 22. Trazabilidad de fuentes")
d.save()

# ---------------- T07 ----------------
d = Doc('T07-MIG-migracion-procoop.md')
d.rep("| `acceptanceActId` | ObjectId | No | Documento T11 del acta. |",
      "| `acceptanceActId` | ObjectId | No | Acta en `documents` de T11 con tipo documental `acta` (PA-MIG-20; antes \"Documento T11 del acta\"). |")
d.rep("`migrationProjects.acceptanceActId` → documento del acta en T11 [VERIFICAR colección]",
      "`migrationProjects.acceptanceActId` → `documents` (T11) con `documentTypeCode` = `acta` (PA-MIG-20, Asumida DEC-072; antes \"documento del acta en T11 [VERIFICAR colección]\")")
d.rep("- **Bloquea:** RN-MIG-038, M18, M16.\n\n## 22. Trazabilidad de fuentes",
      "- **Bloquea:** RN-MIG-038, M18, M16.\n\n"
      "### PA-MIG-20 — Dónde se guarda el acta de aceptación de la migración\n"
      "- **Pregunta:** ¿El acta de aceptación firmada (RF-MIG-087, PAN-MIG-23) es un documento de T11 o una colección propia de T07?\n"
      "- **Contexto:** `migrationProjects.acceptanceActId` apuntaba a un documento de T11 sin colección definida.\n"
      "- **Opciones:**\n"
      "  - A) `documents` de T11 con tipo documental `acta`: firma, versiones y retención las da T11 **(Recomendada)**.\n"
      "  - B) Colección propia de T07.\n"
      "- **Impacto si no se responde:** se asume A.\n"
      "- **Bloquea:** RF-MIG-087; PAN-MIG-23; API-MIG-03 (transición a `live`).\n"
      "- **Estado:** Asumida (DEC-072): opción A.\n\n"
      "## 22. Trazabilidad de fuentes")
d.save()

# ---------------- T08 ----------------
d = Doc('T08-NFR-no-funcionales-seguridad.md')
d.rep("porque los ciclos y vencimientos de los tenants no coinciden; el factor de simultaneidad implícito (entre 35 % y 85 % de la suma, según la fila) se recalibra con la piloto [VERIFICAR].",
      "porque los ciclos y vencimientos de los tenants no coinciden: el pico de plataforma es 0,6 × la suma de los picos por tenant en todas las filas de simultaneidad (PA-NFR-22, Asumida DEC-072), y una prueba de carga antes de O4 lo confirma o lo recalibra; antes \"el factor de simultaneidad implícito (entre 35 % y 85 % de la suma, según la fila) se recalibra con la piloto [VERIFICAR]\".")
d.rep("| Usuarios administrativos concurrentes | 30 | 150 | 2.500 | 7.500 |",
      "| Usuarios administrativos concurrentes | 30 | 150 | 2.088 (0,6 × 3.480; antes 2.500) | 6.264 (0,6 × 10.440; antes 7.500) |")
d.rep("| Socios activos en el día pico de vencimiento | 5.000 | 30.000 | 400.000 | 1.200.000 |",
      "| Socios activos en el día pico de vencimiento | 5.000 | 30.000 | 360.000 (0,6 × 600.000; antes 400.000) | 1.080.000 (0,6 × 1.800.000; antes 1.200.000) |")
d.rep("| Técnicos/lecturistas con app de campo simultáneos | 10 | 60 | 1.500 | 4.500 |",
      "| Técnicos/lecturistas con app de campo simultáneos | 10 | 60 | 720 (0,6 × 1.200; antes 1.500) | 2.160 (0,6 × 3.600; antes 4.500) |")
d.rep("| Mensajes salientes (correo, push, SMS, WhatsApp) por día pico | 30.000 | 200.000 | 3.000.000 | 9.000.000 |",
      "| Mensajes salientes (correo, push, SMS, WhatsApp) por día pico | 30.000 | 200.000 | 2.208.000 (0,6 × 3.680.000; antes 3.000.000) | 6.624.000 (0,6 × 11.040.000; antes 9.000.000) |")
d.rep("| 300 req/s sostenidas, 1.000 pico | 900 sostenidas, 3.000 pico |",
      "| 348 req/s sostenidas, 2.088 pico (0,6 × 580 y 0,6 × 3.480; antes 300 y 1.000) | 1.044 sostenidas, 6.264 pico (0,6 × 1.740 y 0,6 × 10.440; antes 900 y 3.000) |")
d.rep("| Núcleo | O0 | Adoptado (DEC-087; PA-NFR-06 asumida por DEC-072) |",
      "| Núcleo | O0 | Adoptado (DEC-087; PA-NFR-06 asumida por DEC-072; PA-NFR-23 asumida por DEC-072) |")
d.rep("**`retentionPolicies`** — conservación (RF-NFR-009): `code` (= PRM de 10.3), `category`,",
      "**`retentionPolicies`** — conservación (RF-NFR-009): `code` (= PRM de 10.3), `category`, `retentionClass` (clase de retención que declara cada colección en su esquema, T05 §7.1.13 y COL-NFR-06: `legal10y`, `fiscal10y`, `labor10y`, `health`, `operational`, `technical`, `audit`, `legacy`),")
d.rep("`retentionRuns.policyId` → `retentionPolicies` (T08);",
      "`retentionRuns.policyId` → `retentionPolicies` (T08); `documentTypes.retentionPolicyCode` (T11) → `retentionPolicies.code` (T08): el tipo documental usa `retentionPolicyCode` y no `retentionClass`, que es la clase de la colección (T05 COL-WFL-33);")
d.rep("| Oficial de seguridad de plataforma | `PLATFORM` | `nfr.incidentes.*`,",
      "| Oficial de seguridad de plataforma | `PLATFORM` | `nfr.incidentes.ver`, `nfr.incidentes.gestionar`, `nfr.incidentes.editar` (antes `nfr.incidentes.*`, comodín; T02 §4.4.3),")
d.rep("| `/api/platform/nfr/incidents[/:id]` | `nfr.incidentes.*` |",
      "| `/api/platform/nfr/incidents[/:id]` | `nfr.incidentes.ver` (GET), `nfr.incidentes.gestionar` (POST, PATCH) (antes `nfr.incidentes.*`, comodín; T02 §4.4.3) |")
d.renames += 2
d.rep("- **Bloquea:** RNF-NFR-203; PRM-NFR-060; O4.\n\n## 22. Trazabilidad de fuentes",
      "- **Bloquea:** RNF-NFR-203; PRM-NFR-060; O4.\n\n"
      "### PA-NFR-22 — Factor de simultaneidad del pico de plataforma\n"
      "- **Pregunta:** ¿Qué factor se aplica a la suma de los picos por tenant para obtener el pico simultáneo de la plataforma (§7.1)?\n"
      "- **Contexto:** Los ciclos y vencimientos de los tenants no coinciden; el perfil usaba factores implícitos distintos por fila (entre 35 % y 85 %), sin una regla.\n"
      "- **Opciones:**\n"
      "  - A) 0,6 en todas las filas de simultaneidad, con prueba de carga antes de O4 que lo confirma o lo recalibra **(Recomendada)**.\n"
      "  - B) 1,0 (todos los tenants en su pico a la vez): sobredimensiona la infraestructura.\n"
      "- **Impacto si no se responde:** se asume A.\n"
      "- **Bloquea:** §7.1; RNF-NFR-010, 016, 024, 145.\n"
      "- **Estado:** Asumida (DEC-072): opción A, aplicada en §7.1.\n\n"
      "### PA-NFR-23 — Copias anuales de 10 años\n"
      "- **Pregunta:** ¿La conservación legal de 10 años necesita copias de seguridad anuales?\n"
      "- **Contexto:** RNF-NFR-038 preveía copias anuales de 10 años; DEC-087 deja en línea los datos económicos y pasa a archivo en frío el detalle de más de 36 meses.\n"
      "- **Opciones:**\n"
      "  - A) Sin copias anuales: los datos quedan en línea los 10 años y el detalle va al archivo en frío según DEC-087; los backups sirven para recuperar **(Recomendada)**.\n"
      "  - B) Además, una copia anual inmutable de 10 años: más costo de almacenamiento.\n"
      "- **Impacto si no se responde:** se asume A.\n"
      "- **Bloquea:** RNF-NFR-038, RNF-NFR-259.\n"
      "- **Estado:** Asumida (DEC-072): opción A; RNF-NFR-038 ya la aplica.\n\n"
      "## 22. Trazabilidad de fuentes")
d.save()

# ---------------- T10 ----------------
d = Doc('T10-BIA-reportes-bi-apis.md')
d.rep("El contador de TEN-001 ejecuta REP-CON-004 sobre el plan operativo PC-OPER-01 (Ingresos por servicios ARS 38.000) y sobre el alternativo PC-ALT-01 en la simulación SIM-ERP-001 (Ingresos Agua ARS 13.000 e Ingresos Internet ARS 25.000; total ARS 38.000). El reporte de la simulación lleva marca \"SIMULACIÓN\", columna `scenarioId` y no se mezcla con el oficial (RF-BIA-015, RN-BIA-020); los totales coinciden.",
      "El caso es de M15 (dueño de CU-ERP-01, M15 §16); T10 cubre solo la salida del reporte. El contador de TEN-001 ejecuta REP-CON-004 sobre el plan operativo PC-OPER-01 (Ingresos por servicios ARS 38.000) y sobre el alternativo PC-ALT-01 (Ingresos Agua ARS 13.000 e Ingresos Internet ARS 25.000; total ARS 38.000): los totales de los dos planes coinciden. La simulación SIM-ERP-001 de M15 aplica tarifa +10 % y da Agua ARS 14.300, Internet ARS 27.500 y total ARS 41.800, mientras los libros oficiales siguen en ARS 38.000 (prevalece M15; antes T10 asignaba a SIM-ERP-001 el total ARS 38.000). El reporte de la simulación lleva marca \"SIMULACIÓN\", columna `scenarioId` y no se mezcla con el oficial (RF-BIA-015, RN-BIA-020).")
d.rep("| Plan contable CU-ERP-01 | PC-OPER-01 y PC-ALT-01; simulación SIM-ERP-001 (agua ARS 13.000, Internet ARS 25.000) |",
      "| Plan contable CU-ERP-01 | PC-OPER-01 y PC-ALT-01 (agua ARS 13.000, Internet ARS 25.000; total ARS 38.000); simulación SIM-ERP-001 de M15 con tarifa +10 % (agua ARS 14.300, Internet ARS 27.500; total ARS 41.800; antes agua 13.000 e Internet 25.000 asignados a la simulación) |")

# Scopes de la API externa: se mantienen y se mapean a la capability (T02 §4.4.3)
d.rep("| Scope | Recursos | Notas |\n|---|---|---|\n",
      "| Scope | Recursos | Notas | Capability mapeada (T02 §4.4.3) |\n|---|---|---|---|\n")
scopes = [
    ('persons:read', '`per.personas.ver`'), ('accounts:read', '`per.cuentas.ver`'),
    ('contracts:read', '`cat.contratos.ver`'), ('consumption:read', '`med.consumos.ver`'),
    ('billing:read', '`fac.comprobantes.ver`'), ('collections:read', '`cob.cuentaCorriente.ver`'),
    ('ledger:read', '`con.asientos.ver` según T02; el recurso es la cuenta corriente, por lo que corresponde `cob.cuentaCorriente.ver` [VERIFICAR con T02]'),
    ('arrears:read', '`mor.deudas.ver`'), ('crm:read', '`crm.casos.ver`'), ('field:read', '`tec.ordenes.ver`'),
    ('erp.catalog:read', '— (T02 no lo lista)'), ('erp.finance:read', '— (T02 no lo lista)'),
    ('accounting:read', '`con.asientos.ver`'), ('institutional:read', '`ins.asociados.ver`'),
    ('payroll:read', '`sue.costos.ver`'), ('metrics:read', '`bia.indicadores.ver`'),
    ('datasets:read', '`bia.datasets.ver`'), ('exports:write', '`bia.exportaciones.crear`'),
    ('webhooks:manage', '`int.webhooks.gestionar`'), ('pii:read', '— (modificador de campos, no capability)'),
    ('requests:write', '`crm.casos.crear`'),
]
import re
for sc, cap in scopes:
    pat = re.compile(r'^(\| `' + re.escape(sc) + r'` \|[^\n]*\|)$', re.M)
    m = pat.findall(d.t)
    if len(m) != 1:
        raise SystemExit('scope ' + sc + ' ' + str(len(m)))
    d.t = pat.sub(lambda mm: mm.group(1) + ' ' + cap + ' |', d.t)
    d.changes += 1
for o, n in [('bia.ia.preguntar', 'bia.ia.consultar'), ('bia.indicadores.certificar', 'bia.cubos.certificar')]:
    print('  ', o, d.rename(o, n))
d.save()

# ---------------- T12 ----------------
for f in ['T12-SRV-fichas-verticales-servicios-parte1.md', 'T12-SRV-fichas-verticales-servicios-parte2.md']:
    d = Doc(f)
    for o, n in [('tec.cdr.import', 'tec.cdr.importar'), ('tec.work.manage', 'tec.obras.gestionar')]:
        d.rename(o, n)
    d.save()
