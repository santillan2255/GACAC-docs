"""Edición que conserva BOM y finales de línea (LF o CRLF)."""
import os, glob, sys, io

ROOT = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')


class Doc:
    def __init__(self, pat):
        p = glob.glob(os.path.join(ROOT, 'anexos', pat))
        assert len(p) == 1, (pat, p)
        self.path = p[0]
        raw = open(self.path, 'rb').read()
        self.bom = raw.startswith(b'\xef\xbb\xbf')
        t = raw.decode('utf-8-sig')
        self.crlf = '\r\n' in t
        if self.crlf:
            assert t.count('\r\n') == t.count('\n'), 'EOL mixto'
            t = t.replace('\r\n', '\n')
        self.t = t
        self.cnt = {}

    def _k(self, k):
        self.cnt[k] = self.cnt.get(k, 0) + 1

    def rep(self, old, new, k='otros', count=1):
        c = self.t.count(old)
        assert c == count, 'esperaba %d y hay %d: %r' % (count, c, old[:200])
        self.t = self.t.replace(old, new)
        self._k(k)

    def line(self, starts):
        ls = [l for l in self.t.split('\n') if l.startswith(starts)]
        assert len(ls) == 1, (starts, len(ls))
        return ls[0]

    def cell(self, rowstart, col, fn, k='otros'):
        old = self.line(rowstart)
        cells = old.split(' | ')
        cells[col] = fn(cells[col])
        new = ' | '.join(cells)
        assert new != old, rowstart
        self.rep(old + '\n', new + '\n', k)

    def after_line(self, starts, new_lines, k='otros'):
        ls = self.t.split('\n')
        idx = [i for i, l in enumerate(ls) if l.startswith(starts)]
        assert len(idx) == 1, (starts, idx)
        ls[idx[0] + 1:idx[0] + 1] = new_lines
        self.t = '\n'.join(ls)
        self._k(k)

    def before_line(self, starts, new_lines, k='otros'):
        ls = self.t.split('\n')
        idx = [i for i, l in enumerate(ls) if l.startswith(starts)]
        assert len(idx) == 1, (starts, idx)
        ls[idx[0]:idx[0]] = new_lines
        self.t = '\n'.join(ls)
        self._k(k)

    def save(self):
        t = self.t.replace('\n', '\r\n') if self.crlf else self.t
        open(self.path, 'wb').write((b'\xef\xbb\xbf' if self.bom else b'') + t.encode('utf-8'))
        print(os.path.basename(self.path), self.cnt)
