﻿import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from res_lib_m12m19 import Doc

d = Doc('M13-STK-stock-activos-fabricacion.md')
PA = 'PA-STK-11'

# Cat 6
d.rep('se publica `stk.item.below-minimum`.', 'se publica `stk.item.belowMinimum` (EVT-STK-12; antes `stk.item.below-minimum`, ' + PA + ').', cat=6)

# Cat 4: itemId -> inventoryItemId en stockMovements y stockBalances; documentId -> stockDocumentId
d.rep('| `documentId`, `lineId` | ObjectId, string | O | Documento y renglón. |',
      '| `stockDocumentId` (antes `documentId`), `lineId` | ObjectId, string | O | Documento y renglón (nombre de T05; ' + PA + '). |', cat=4)
d.rep('| `itemId`, `warehouseId` | ObjectId | O | |',
      '| `inventoryItemId` (antes `itemId`), `warehouseId` | ObjectId | O | Nombre de T05 (' + PA + '). |', cat=4)
d.rep('Índices: `{tenantId, itemId, warehouseId, effectiveDate}`; `{tenantId, serialUnitId, effectiveDate}`; `{tenantId, documentId}`;',
      'Índices: `{tenantId, inventoryItemId, warehouseId, effectiveDate}`; `{tenantId, serialUnitId, effectiveDate}`; `{tenantId, stockDocumentId}` (antes con `itemId` y `documentId`);', cat=4)
d.rep('### 7.12 `stockBalances` — saldos materializados\n\n`itemId`, `warehouseId` (O)',
      '### 7.12 `stockBalances` — saldos materializados\n\n`inventoryItemId` (antes `itemId`; nombre de T05, ' + PA + '), `warehouseId` (O)', cat=4)
d.rep('Índice único `{tenantId, itemId, warehouseId, locationId, lotId, contractId, stockState}`. Se actualiza con `$inc` dentro de la transacción del movimiento, con `version` (RN-STK-025).',
      'Índice único `{tenantId, inventoryItemId, warehouseId, locationId, lotId, contractId, stockState}` (antes con `itemId`). Se actualiza con `$inc` dentro de la transacción del movimiento, con `version` (RN-STK-025).', cat=4)
d.rep('| `lineId` | [VERIFICAR] destino no deducible (identificador externo o interno) |\n| `itemId` | `inventoryItems` (M13); antes implícita por el nombre |',
      '| `stockDocumentId` (antes `documentId`) | `stockDocuments` (M13) |\n'
      '| `lineId` | — (renglón embebido `lines[].lineId` del documento de `stockDocuments` (M13), no es colección; antes `[VERIFICAR]`) |\n'
      '| `inventoryItemId` (antes `itemId`) | `inventoryItems` (M13); antes implícita por el nombre |', cat=4)
d.rep('| `destination` | [VERIFICAR] destino no deducible (identificador externo o interno) |\n| `projectId` | [VERIFICAR] destino no deducible (identificador externo o interno) |',
      '| `destination` | — (objeto embebido de dimensión analítica; no es referencia; antes `[VERIFICAR]`) |\n'
      '| `projectId` | `works` (M10) (obra; antes `[VERIFICAR]`; ' + PA + ') |', cat=2)
# serialUnits
d.rep('| `itemId` | ObjectId | O | `COD_PRO`. |\n| `serialNumber` | string | O | `NID_PTH`. |',
      '| `inventoryItemId` (antes `itemId`) | ObjectId | O | `COD_PRO`; nombre de T05 (' + PA + '). |\n| `serialNumber` | string | O | `NID_PTH`. |', cat=4)
d.rep('| `currentWarehouseId`, `currentLocationId`, `currentServiceContractId` | ObjectId | C | Posición vigente. |',
      '| `currentWarehouseId`, `currentLocationId`, `currentContractId` (antes `currentServiceContractId`) | ObjectId | C | Posición vigente; nombre de T05 (' + PA + '). |', cat=4)
d.rep('| `itemId` | `inventoryItems` (M13); antes implícita por el nombre |\n| `secondaryIds` | [VERIFICAR] destino no deducible (identificador externo o interno) |',
      '| `inventoryItemId` (antes `itemId`) | `inventoryItems` (M13); antes implícita por el nombre |\n'
      '| `secondaryIds` | — (identificadores del fabricante o de la red: MAC, GPON SN, IMEI, número de medidor; no es referencia; antes `[VERIFICAR]`) |\n'
      '| `currentContractId` (antes `currentServiceContractId`) | `serviceContracts` (M02) |', cat=2)
# inventoryItems, stockDocuments
d.rep('| `catalogProductId` | [VERIFICAR] destino no deducible (identificador externo o interno) |',
      '| `catalogProductId` | `serviceProducts` (M02) (producto comercial; T05 COL-CAT-05 guarda el vínculo inverso `inventoryItemId`; antes `[VERIFICAR]`) |', cat=2)
d.rep('| `clientMutationId` | [VERIFICAR] destino no deducible (identificador externo o interno) |',
      '| `clientMutationId` | — (identificador de la mutación offline generado por el cliente; no es referencia; antes `[VERIFICAR]`) |', cat=2)
# lotTypes (renglones de lots en la tabla)
d.rep('| `purchaseReceiptId` | ObjectId | [VERIFICAR] | — | [VERIFICAR] destino no deducible (identificador externo o interno) |\n| `status` | enum | [VERIFICAR] | `available`, `blocked`, `expired`, `depleted` | — |',
      '| `purchaseReceiptId` | ObjectId | [VERIFICAR] | Renglón de `lots`. | `supplierReceipts` (M12) (antes `[VERIFICAR]`) |\n'
      '| `lots.status` (antes `status` en esta tabla) | enum | — | Reemplazado por `lots.status` (§7.37.15, §8.12): la lista original del §7.15 mezcla `lotTypes` y `lots`; desde `blockExpired` los renglones son de `lots` y `lotTypes` no tiene estado (' + PA + '). | — |', cat=1)
# stockReservations, revaluations, reorderSuggestions
d.rep('| `sourceRef` | string | [VERIFICAR] | Declarado en T05; no figuraba en la lista del anexo. | — |',
      '| `sourceRef` | string | [VERIFICAR] | Declarado en T05; no figuraba en la lista del anexo. | — (clave polimórfica del documento origen; la colección la indica `target.type`; no es referencia directa) |', cat=2)
d.rep('| `projectId` | ObjectId | [VERIFICAR] | obra P3041 | [VERIFICAR] destino no deducible (identificador externo o interno) |',
      '| `projectId` | ObjectId | [VERIFICAR] | obra P3041 | `works` (M10) (antes `[VERIFICAR]`; ' + PA + ') |', cat=2)
d.rep('| `requisitionId` | ObjectId | [VERIFICAR] | M12 | [VERIFICAR] destino no deducible (identificador externo o interno) |',
      '| `requisitionId` | ObjectId | [VERIFICAR] | M12 | `supplyRequests` (M12) (antes `[VERIFICAR]`) |', cat=2)
d.rep('| `isImprovement` | [VERIFICAR] destino no deducible (identificador externo o interno) |',
      '| `isImprovement` | — (booleano, no es referencia; antes `[VERIFICAR]`) |\n'
      '| `costCenterId` | `costCenters` (M15) (clave de T05; centro principal; el reparto va en `costCenterAllocation[].costCenterId`; ' + PA + ') |', cat=2)
d.rep('| `costCenterAllocation` | [{costCenterId, percent}] | — | `BIENES_USO_CTSEC` (`COD_SEC`, `POR_ASIGNACION`). |',
      '| `costCenterAllocation` | [{costCenterId, percent}] | — | `BIENES_USO_CTSEC` (`COD_SEC`, `POR_ASIGNACION`). |\n'
      '| `costCenterId` | ObjectId | — | Centro de costo principal (clave de T05; ' + PA + '). |', cat=4)
# depreciationRuns / fixedAssetDepreciations
d.rep('| `reversalOfRunId` | ObjectId | [VERIFICAR] | . `fixedAssetDepreciations`: `runId` | [VERIFICAR] destino no deducible (identificador externo o interno) |',
      '| `reversalOfRunId` | ObjectId | [VERIFICAR] | Corrida revertida. | `depreciationRuns` (M13) (antes `[VERIFICAR]`) |', cat=2)
d.rep('| `journalRef` | string | [VERIFICAR] | devuelto por M15, reemplaza `COD_ASI` | — |',
      '| `journalRef` | string | [VERIFICAR] | devuelto por M15, reemplaza `COD_ASI` | `journalEntries` (M15) (identificador del asiento informado por EVT-CON-01) |', count=2, cat=2)
d.rep('| `runId` | ObjectId | [VERIFICAR] | — | [VERIFICAR] destino no deducible (identificador externo o interno) |',
      '| `runId` | ObjectId | [VERIFICAR] | Reemplazado por `depreciationRunId` (nombre de T05). | `depreciationRuns` (M13) (antes `[VERIFICAR]`) |', cat=2)
# receptionStatuses / serviceReceptions
d.rep('| `documentRef` | string | [VERIFICAR] | `COD_COM/SUC_COM/NUM_COM` | — |',
      '| `documentRef` | string | [VERIFICAR] | `COD_COM/SUC_COM/NUM_COM` | — (número del comprobante de origen como texto; no es referencia) |', count=2, cat=2)
d.rep('| `items` | array | [VERIFICAR] | [{lineId, itemId (`COD_PRO`), quantity (`CAN_PRO`), price (`PRE_VSI`), customerSerial, currentStatusId, statusHistory [{statusId, at, userId}] (`ITRE_EST`)}] | — |\n| `status` | [VERIFICAR] | [VERIFICAR] | — | — |\n\n#### 7.37.31',
      '| `items` | array | [VERIFICAR] | [{lineId, itemId (`COD_PRO`), quantity (`CAN_PRO`), price (`PRE_VSI`), customerSerial, currentStatusId, statusHistory [{statusId, at, userId}] (`ITRE_EST`)}] | — |\n'
      '| `serviceReceptions.status` (antes `status` en esta tabla) | — | — | Reemplazado por `serviceReceptions.status` (§7.37.31, §8.14): la lista original del §7.29 mezcla ambas colecciones; desde `date` los renglones son de `serviceReceptions` y `receptionStatuses` es un catálogo sin estado (' + PA + '). | — |\n\n#### 7.37.31', cat=1)
d.rep('| `items` | array | [VERIFICAR] | [{lineId, itemId (`COD_PRO`), quantity (`CAN_PRO`), price (`PRE_VSI`), customerSerial, currentStatusId, statusHistory [{statusId, at, userId}] (`ITRE_EST`)}] | — |\n| `status` | [VERIFICAR] | [VERIFICAR] | — | — |\n| `accountId`',
      '| `items` | array | [VERIFICAR] | [{lineId, itemId (`COD_PRO`), quantity (`CAN_PRO`), price (`PRE_VSI`), customerSerial, currentStatusId, statusHistory [{statusId, at, userId}] (`ITRE_EST`)}] | — |\n'
      '| `status` | enum | Sí | `open`, `closed`, `cancelled` (§8.14; antes sin valores, ' + PA + '). El avance de cada renglón lo da `items[].currentStatusId` (`receptionStatuses`). | — |\n| `accountId`', cat=1)
d.rep('| `requisitionIds` | ObjectId[] | [VERIFICAR] | — | [VERIFICAR] destino no deducible (identificador externo o interno) |',
      '| `requisitionIds` | ObjectId[] | [VERIFICAR] | Solicitudes generadas en M12 (§8.13). | `supplyRequests` (M12) (antes `[VERIFICAR]`) |', cat=2)
# manufacturingOrders.bomStructureVersionId
d.rep('| `isGenericDamagedOrder` | bool | — | P3040. |',
      '| `isGenericDamagedOrder` | bool | — | P3040. |\n'
      '| `bomStructureVersionId` | ObjectId | C | Versión de estructura vigente al generar la orden (clave de T05; cada renglón puede fijar la suya en `products[].bomVersionId`; ' + PA + '). |', cat=4)
# serialUnitEvents: valores de fromStatus / toStatus
d.rep('| `fromStatus` | [VERIFICAR] | [VERIFICAR] | — | — |\n| `toStatus` | [VERIFICAR] | [VERIFICAR] | — | — |',
      '| `fromStatus` | enum | [VERIFICAR] | Valores de `serialUnits.status` (§8.2); registra la transición, no tiene máquina propia (antes sin valores, ' + PA + '). | — |\n'
      '| `toStatus` | enum | [VERIFICAR] | Valores de `serialUnits.status` (§8.2). | — |', cat=1)

# PRM-STK-058: parámetro, no servicio interno
d.rep('| PRM-STK-058 | `stk.services.noCommercialStock` | bool | S | `false` | Servicio sin stock comercial (RF-STK-132). | — |',
      '| PRM-STK-058 | `stk.services.noCommercialStock` | bool | S | `false` | Servicio sin stock comercial (RF-STK-132). Es un parámetro por servicio, no un servicio interno: lo consultan M02 (catálogo) y M11 al vender (' + PA + '). | — |', cat=5)

# Cat 1: estado inicial detectable
for sec, st in [('### 8.3 `stockReservations.status`', 'active'), ('### 8.5 `crewSettlements.status`', 'draft'),
                ('### 8.6 `physicalCounts.status`', 'planned'), ('### 8.7 `fixedAssets.status`', 'draft'),
                ('### 8.8 `depreciationRuns.status`', 'simulated'), ('### 8.10 `productionReports.status`', 'pending'),
                ('### 8.11 `rmaCases` (estados configurables, catálogo por defecto)', 'received')]:
    d.rep(sec + '\n\nEstado inicial: `%s`.' % st, sec + '\n\nEstado inicial: `%s` (alta → `%s`; %s).' % (st, st, PA), cat=1)

states_tbl = ('| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |\n|---|---|---|---|---|\n'
              '| (alta) | `available` | Ingreso por compra, vale de entrada, producción o saldo inicial | RN-STK-003 | — |\n'
              '| `available` | `inTransit` | Transferencia con tránsito o entrega emitida (§8.1) | — | — |\n'
              '| `inTransit` | `available` | Recepción en el depósito destino | — | — |\n'
              '| `inTransit` | `custody` | Aceptación por la cuadrilla o el técnico | — | — |\n'
              '| `available` | `custody` | Entrega a cuadrilla sin tránsito | — | — |\n'
              '| `custody` | `available` | Devolución de cuadrilla | — | — |\n'
              '| `custody` | `applied` | Aplicación en OT | RN-STK-018 | — |\n'
              '| `applied` | `quarantine` | Retiro pendiente de revisión | — | — |\n'
              '| `quarantine` | `available` | Revisión apta | — | — |\n'
              '| `quarantine`, `available` | `repair` | Envío a reparación interna | — | — |\n'
              '| `repair` | `available` | Reparación terminada | — | — |\n'
              '| `available`, `repair`, `quarantine` | `supplier` | Envío a proveedor (RMA) | — | — |\n'
              '| `supplier` | `available` | Retorno del proveedor | — | — |\n'
              '| `available` | `consigned` | Entrega en consignación | — | — |\n'
              '| `consigned` | `available` | Devolución de consignación | — | — |\n'
              '| `available`, `quarantine`, `repair`, `supplier` | `scrap` | Baja técnica aprobada | — | — |\n')

d.rep('| `mrpRuns` | `calculated` | `discarded` | Descarte por el usuario o nueva corrida del mismo rango | — | — |\n\n## 9. Procesos y flujos',
      '| `mrpRuns` | `calculated` | `discarded` | Descarte por el usuario o nueva corrida del mismo rango | — | — |\n\n'
      '### 8.14 Estado de stock, revaluaciones y recepciones de servicio técnico (corrección 05-11-2026)\n\n'
      'Corrección del 05-11-2026 (' + PA + '): el §7 enumeraba valores sin transiciones para `stockState`, `revaluations.status` y `serviceReceptions.status` (este último sin valores). `stockState` es una dimensión del saldo: cada paso es un par de movimientos (`out` del estado de origen e `in` al de destino) en la misma transacción; el movimiento es inmutable y su `stockState` no cambia después del alta.\n\n'
      '#### 8.14.1 Estado de stock del saldo (`stockBalances.stockState`)\n\n'
      'Estado inicial: `available` (alta → `available`).\n\n' + states_tbl + '\n'
      '#### 8.14.2 Estado de stock del movimiento (`stockMovements.stockState`)\n\n'
      'Mismas transiciones que §8.14.1, registradas como pares de movimientos. Estado inicial: `available` (alta → `available`).\n\n' + states_tbl + '\n'
      '#### 8.14.3 Revaluación (`revaluations.status`)\n\n'
      'Estado inicial: `draft`.\n\n'
      '| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |\n|---|---|---|---|---|\n'
      '| (alta) | `draft` | Cálculo de la revaluación (índice, costo o manual) | — | — |\n'
      '| `draft` | `approved` | Aprobación del responsable (P3042) | — | — |\n'
      '| `approved` | `posted` | Contabilización: genera el documento `revaluation` y los movimientos `kind = value` | Período abierto | — |\n'
      '| `draft`, `approved` | `cancelled` | Descarte | — | — |\n\n'
      '#### 8.14.4 Recepción de servicio técnico (`serviceReceptions.status`)\n\n'
      'Estado inicial: `open`. El avance de cada equipo recibido lo da `items[].currentStatusId` con el catálogo `receptionStatuses`, que no tiene estado propio.\n\n'
      '| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |\n|---|---|---|---|---|\n'
      '| (alta) | `open` | Registro de la recepción | — | — |\n'
      '| `open` | `closed` | Todos los renglones en un estado con `isFinal` | — | — |\n'
      '| `open` | `cancelled` | Anulación de la recepción | — | — |\n\n'
      '## 9. Procesos y flujos', cat=1)

d.insert_before('## 22. Trazabilidad de fuentes', '''### PA-STK-11 — Residuales del 05-11-2026 (estados, referencias, nombres de campo y evento bajo mínimo)
- **Pregunta:** ¿Cómo se cierran los residuales de M13 que detectaron los entregables regenerados?
- **Contexto:** el índice de estados marcó máquinas sin estado inicial (§8.3, §8.5 a §8.8, §8.10, §8.11), `stockState`, `lotTypes` y `revaluations` con valores sin transiciones, y `serialUnitEvents`, `receptionStatuses` y `serviceReceptions` sin valores; las tablas del §7.37 dejaban referencias sin destino; T05 nombra `inventoryItemId`, `stockDocumentId`, `currentContractId`, `costCenterId` y `bomStructureVersionId`; RF-STK-029 publicaba `stk.item.below-minimum` con guion.
- **Opciones:**
  - A) Estado inicial explícito; §8.14 con `stockState` como flujo entre estados por pares de movimientos, `revaluations` y `serviceReceptions` (`open`, `closed`, `cancelled`); los renglones de `lots` y `serviceReceptions` mezclados en las tablas de `lotTypes` y `receptionStatuses` quedan marcados como reemplazados; nombres de T05 con "antes"; `projectId` → `works` (M10) por ser la obra de P3041; `requisitionId` y `requisitionIds` → `supplyRequests` (M12); `purchaseReceiptId` → `supplierReceipts` (M12); `catalogProductId` → `serviceProducts` (M02); evento `stk.item.belowMinimum` (EVT-STK-12) **(Recomendada)**.
  - B) Mantener el texto y resolver en los entregables.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** §7.11 a §7.13, §7.24, §7.33, §7.37, §8.
- **Estado:** Asumida la recomendada (DEC-072). T05 debe resolver el `[VERIFICAR]` de `projectId` (§7.2 lo apuntaba a `crmProjects` con duda) hacia `works` (M10) para M13, y registrar `serviceReceptions.status` y `revaluations.status` con estos valores.

''', cat=0)
d.save()
