import sys
sys.stdout.reconfigure(encoding='utf-8')
def edit(P, pairs):
    raw = open(P, 'rb').read(); assert not raw.startswith(b'\xef\xbb\xbf') and b'\r\n' not in raw
    t = raw.decode('utf-8')
    for a, b in pairs:
        assert t.count(a) == 1, a[:60]
        t = t.replace(a, b)
    open(P, 'wb').write(t.encode('utf-8'))

a = "ya están corregidos en sus anexos y quedan como alias."
edit('anexos/T02-IAM-identidad-roles-auditoria.md', [(a, a +
    " (4) Barrido final (cuarta ronda, 05-11-2026) de las capabilities `modulo.recurso.accion` usadas por M01–M19 y T01–T12: "
    "las que usa el anexo dueño y faltaban se registran en 4.4.2 (incluidas las concretas de `stk.fabricacion.ordenes.*`, "
    "`sue.rrhh.*.editar`, `sue.rrhh.objetivos.*`, `sue.rrhh.sumarios.*`, `sue.portal.datos.editar` y `tec.telefonia.cdr.*`); "
    "los nombres que el anexo ya reemplazó (\"antes `x`\") pasan a alias en 4.4.1; los comodines (`cmp.cotizaciones.*`, "
    "`stk.fabricacion.*.*`, `sue.rrhh.*.*`, `tec.telefonia.*.*`) se explicitan en esta tabla. Los nombres que solo aparecen en "
    "el mapa de navegación de T03 sin capability del dueño no se registran: T03 debe usar la capability del anexo dueño.")])

b = "Equivalencias PWA ProCoop: `Inicio_ProCoop`"
edit('anexos/T09-COM-comunidad-comunicaciones.md', [(b,
    "Destino \"Comunidad\" de la tabbar del socio (M19 PAN-POR-105, `/app/comunidad`, RF-POR-180): agrega en pestañas PAN-COM-40 (Muro), "
    "PAN-COM-43 (Encuestas) y PAN-COM-44 (Novedades) y muestra solo las pestañas cuya capability tiene el usuario: `com.wall.ver` "
    "para Muro y Novedades y `com.surveys.responder` para Encuestas (claves canónicas de T09). `com.muro.ver` y "
    "`com.encuestas.responder` son alias de esas claves en T02 §4.4.1 (CTR-COM-09); `com.wall.ver` no tiene alias inverso. "
    "PAN-COM-51 (`/app/comunidad/reglas`) cuelga de ese destino.\n\n" + b)])
print('OK')
