#### 12.B.1 Jobs BullMQ declarados por los módulos (con ID de origen)

Columnas: **Tipo** de disparo `P` programado (cron por tenant, zona horaria del tenant), `E` por evento/condición, `D` a demanda (usuario o comando); **Cola** según RN-WFL-061 (si el anexo de origen declara una cola, prevalece la declarada).

**Módulo T01** (22 jobs; fuente: anexo T01 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-PLA-01 | `pla:outbox-relay` | Continuo + sondeo `PRM-PLA-029` | P | `events` | Entrega de eventos (§7.6) |
| JOB-PLA-02 | `pla:evaluar-checklist` | Por evento y diario 03:00 | P+E | `events` | Evalúa checklists (§9.2) |
| JOB-PLA-03 | `pla:vencimientos-contratos-licencias` | Diario 02:00 | P | `maintenance` | Expira licencias/contratos, alertas PLA-ALR-09 |
| JOB-PLA-04 | `pla:expirar-accesos-soporte` | Cada minuto | P | `maintenance` | Vence grants y revoca tokens |
| JOB-PLA-05 | `pla:medir-uso` | Diario 01:00 | P | `maintenance` | Snapshots de uso |
| JOB-PLA-06 | `pla:evaluar-cupos` | Tras JOB-PLA-05 | E | `maintenance` | Alertas y flags de cupo |
| JOB-PLA-07 | `pla:evaluar-alertas` | Cada minuto | P | `maintenance` | Reglas de métricas, latidos y vencimientos |
| JOB-PLA-08 | `pla:recolectar-salud` | Cada `PRM-PLA-043` s | P | `maintenance` | `healthSnapshots`, uptime sintético por tenant |
| JOB-PLA-09 | `pla:backup-logico-tenant` | Diario (escalonado) | P | `maintenance` | Backup lógico por tenant |
| JOB-PLA-10 | `pla:verificar-backups` | Diario | P | `maintenance` | Checksums, PITR disponible |
| JOB-PLA-11 | `pla:restaurar-tenant` | A demanda | D | `maintenance` | §9.7 pasos 2–4 |
| JOB-PLA-12 | `pla:conciliar-post-restauracion` | Tras JOB-PLA-11 | E | `integration` | §9.7 paso 5 |
| JOB-PLA-13 | `pla:ensayo-restauracion` | Cada `PRM-PLA-014` días | P | `maintenance` | Ensayo con evidencia |
| JOB-PLA-14 | `pla:cerrar-y-purgar-tenant` | Diario (evalúa fechas) | P | `maintenance` | Cerrado y purga con certificado |
| JOB-PLA-15 | `pla:crear-sandbox` | A demanda | D | `maintenance` | Crea gemelo en `sandbox` |
| JOB-PLA-16 | `pla:propuesta-ia-alta` | A demanda | D | `interactive` | Propuesta de marca y diccionario |
| JOB-PLA-17 | `pla:limpiar-borradores-y-temporales` | Diario | P | `maintenance` | Borradores vencidos, exportaciones vencidas, idempotencia expirada (además del TTL), archivos huérfanos no confirmados |
| JOB-PLA-18 | `pla:sincronizar-config-sandbox` | A demanda | D | `maintenance` | Transferencia de paquetes T04 |
| JOB-PLA-19 | `pla:copia-anonimizada` | A demanda (aprobada) | E+D | `maintenance` | Copia anonimizada a sandbox |
| JOB-PLA-20 | `pla:exportar-tenant` | A demanda / salida | D | `export` | Exportación completa |
| JOB-PLA-21 | `pla:escanear-archivo` | Por subida | E | `interactive` | Antivirus y tipo real |
| JOB-PLA-22 | `pla:sla-soporte` | Cada 5 min | P | `maintenance` | Vencimientos de SLA y escalamiento; cierre automático de casos resueltos |

**Módulo T02** (12 jobs; fuente: anexo T02 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-IAM-01 | `iam:expirar-autorizaciones` | 5 min | E | `batch` | Vence solicitudes pendientes y aprobadas no consumidas |
| JOB-IAM-02 | `iam:expirar-accesos-soporte` | 1 min | E | `batch` | Vence grants, revoca sesiones de soporte |
| JOB-IAM-03 | `iam:purgar-transitorios` | Horario | P | `maintenance` | Respaldo de TTL: tokens, OTP, transacciones, presencias |
| JOB-IAM-04 | `iam:sellar-auditoria` | Diario 00:15 (zona del tenant) | P | `batch` | Cierra partición, calcula hash final, guarda ancla WORM |
| JOB-IAM-05 | `iam:verificar-integridad` | Diario + bajo demanda | P+D | `batch` | Recalcula cadenas; emite EVT-IAM-16 si falla |
| JOB-IAM-06 | `iam:recertificacion` | Según `PRM-IAM-061` | E | `batch` | Crea revisiones y suspende vencidas |
| JOB-IAM-07 | `iam:suspender-inactivos` | Diario | P | `notifications` | RF-IAM-076 con aviso previo `PRM-IAM-064` días |
| JOB-IAM-08 | `iam:detectar-anomalias` | 5 min | E | `export` | Ráfagas, reutilización, geografía, exportaciones masivas |
| JOB-IAM-09 | `iam:enviar-invitaciones` | Bajo demanda | D | `notifications` | Importación masiva |
| JOB-IAM-10 | `iam:expirar-asignaciones` | Horario | P | `notifications` | `validTo` de asignaciones, excepciones SoD y credenciales API (aviso previo) |
| JOB-IAM-11 | `iam:verificar-contrasenas-comprometidas` | Semanal | P | `integration` | Marca `passwordCompromised` contra lista actualizada (k-anonimato, sin enviar hashes completos) |
| JOB-IAM-12 | `iam:sincronizar-catalogos` | Al desplegar | E | `integration` | `capabilityCatalog` y `screenCatalog` desde código; versión de plantillas |

**Módulo T03** (7 jobs; fuente: anexo T03 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-UXD-01 | `uxd:procesar-recurso` | Subida de recurso | E | `batch` | Valida formato, sanea SVG, genera variantes (íconos 48–512, maskable, apple-touch, favicon, splash), calcula `sha256`, p… |
| JOB-UXD-02 | `uxd:compilar-marca` | `uxd.branding.published/reverted` | E | `integration` | Genera CSS de variables por tenant, manifests por app, invalida CDN |
| JOB-UXD-03 | `uxd:compilar-diccionario` | `uxd.dictionary.published/reverted`, `uxd.catalog.updated` | E | `batch` | Fusiona base + tenant + canal, resuelve referencias a términos, valida, genera paquetes por app/canal con hash |
| JOB-UXD-04 | `uxd:sembrar-tenant` | `pla.tenant.created` | E | `batch` | Crea `tenantBrandings` release 1 y release 0 del diccionario; opcional plantilla |
| JOB-UXD-05 | `uxd:sincronizar-catalogo` | Despliegue | E | `integration` | Sincroniza `packages/dictionary/base` con `dictionaryKeys`, aplica `renamedTo` a entradas de tenants, emite EVT-UXD-08 |
| JOB-UXD-06 | `uxd:resumen-claves-faltantes` | Diario 03:00 (zona plataforma) | P | `notifications` | Agrega `dictionaryMissingKeys` y alerta si una clave falta en > 1 tenant |
| JOB-UXD-07 | `uxd:auditar-contraste` | Semanal y al cambiar tokens base | P | `batch` | Recalcula `contrastReport` de todos los tenants y avisa a los que no cumplen |

**Módulo T04** (14 jobs; fuente: anexo T04 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-CFG-05 | `cfg:ingesta-georef` | Mensual (configurable) + manual | P+D | `batch` | Descarga por provincia de unidades territoriales y calles; diff contra vigente; release en borrador para curador |
| JOB-CFG-06 | `cfg:ingesta-feriados` | Anual (noviembre/diciembre) + manual ante decreto | P+D | `batch` | Carga calendario nacional del año siguiente desde fuente oficial o carga asistida; release |
| JOB-CFG-07 | `cfg:ingesta-indices` | Diaria 18:00 (cotizaciones/tasas); mensual (IPC) | P | `batch` | Consulta integración (T06), inserta valores `provisional`/`definitive`; detecta revisiones |
| JOB-CFG-08 | `cfg:ingesta-padron:<registro>` | Según fuente (mensual/quincenal) | P | `batch` | Descarga o recibe archivo; valida; carga por lotes con vigencia; cierra entradas anteriores |
| JOB-CFG-01 | `cfg:sincronizar-registro` | En cada despliegue | P | `integration` | §9.1. |
| JOB-CFG-02 | `cfg:publicar-version-programada` | Cada minuto | P | `batch` | Revalida y publica versiones `scheduled` vencidas. |
| JOB-CFG-03 | `cfg:importar-maestro` | Bajo demanda | D | `batch` | Validación y carga por lotes (§9.6). |
| JOB-CFG-04 | `cfg:unificar-maestro` | Bajo demanda | D | `batch` | Redirección de referencias (§9.7). |
| JOB-CFG-09 | `cfg:geocodificar-pendientes` | Cada 15 min | P | `integration` | Reintenta `pending` con backoff y respeta cuota. |
| JOB-CFG-10 | `cfg:migrar-variables` | Bajo demanda (T07) | D | `batch` | §9.11. |
| JOB-CFG-11 | `cfg:aplicar-semilla` | Bajo demanda | D | `batch` | §9.13. |
| JOB-CFG-12 | `cfg:activar-vigencias` | Cada minuto | P | `batch` | §9.14. |
| JOB-CFG-13 | `cfg:verificar-integridad` | Diario 03:00 (zona del tenant) | P | `batch` | §9.15. |
| JOB-CFG-14 | `cfg:purgar-geocache` | Diario | P | `maintenance` | Elimina `geocodeRequests` vencidos según política de PA-CFG-03. |

**Módulo T06** (28 jobs; fuente: anexo T06 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-INT-01 | `int:ejecutar-operacion` | Por operación | E | `batch` | §9.1 |
| JOB-INT-02 | `int:resolver-incierto` | Por operación incierta, con backoff | E | `batch` | §9.2 |
| JOB-INT-03 | `int:procesar-webhook` | Por webhook | E | `integration` | §9.3 |
| JOB-INT-04 | `int:generar-archivo` | A pedido del módulo dueño | D | `batch` | §9.4 saliente |
| JOB-INT-05 | `int:procesar-archivo-entrante` | Carga/buzón | E | `batch` | §9.4 entrante |
| JOB-INT-06 | `int:conciliar` | Diario por conexión (configurable) | P | `batch` | §9.5 |
| JOB-INT-07 | `int:recuperar-pendientes` | Cada PRM-INT-025 min + barridos | P | `batch` | §9.6 |
| JOB-INT-08 | `int:health-check` | Cada PRM-INT-013 min | P | `batch` | §9.7 |
| JOB-INT-09 | `int:alertar-vencimientos` | Diario | P | `batch` | §9.8 |
| JOB-INT-10 | `int:rotar-credencial` | Manual/programado | P+D | `batch` | §9.9 |
| JOB-INT-11 | `int:refrescar-tokens` | Antes de vencer | E | `batch` | §9.10 |
| JOB-INT-12 | `int:cerrar-contingencia` | Al recuperar conexión | E | `batch` | §9.11 |
| JOB-INT-13 | `int:entregar-mensaje` | Por lote T09 | E | `batch` | §9.13 |
| JOB-INT-14 | `int:despachar-comando-agente` | Por comando | D | `batch` | §9.14 |
| JOB-INT-15 | `int:purgar-bitacora` | Diario | P | `maintenance` | §9.15 |
| JOB-INT-16 | `int:leer-buzon-sftp` | Cron por conexión | P | `batch` | §9.16 |
| JOB-INT-17 | `int:entregar-sftp` | Por archivo | E | `batch` | §9.16 |
| JOB-INT-18 | `int:sincronizar-parametros-arca` | Semanal y a demanda | P+D | `integration` | §9.17 |
| JOB-INT-19 | `int:polling-cobranzas` | Cron por conexión de pasarela/red con API (ej. Pagos360 `report/collection`, SIR… | P | `integration` | Respaldo del webhook (FI-INT-37, 43) |
| JOB-INT-20 | `int:sincronizar-estados-debito` | Diario | P | `integration` | Estados de adhesiones (Pagos360 `pending_to_sign`, `signed`, `canceled`) |
| JOB-INT-21 | `int:importar-movimientos-bancarios` | Diario por cuenta | P | `integration` | Interbanking movimientos de días anteriores |
| JOB-INT-22 | `int:leer-telemedicion` | Cron por sistema MDM | P | `integration` | Lecturas remotas |
| JOB-INT-23 | `int:importar-cdr` | Cron/buzón por central | P | `integration` | CDR de centrales |
| JOB-INT-24 | `int:importar-posiciones-gps` | Cada N min | P | `integration` | Posiciones AVL |
| JOB-INT-25 | `int:revalidar-padron` | Mensual (opcional por tenant) | P | `batch` | Revalidación masiva de condición fiscal (FI-INT-06/07) |
| JOB-INT-26 | `int:importar-padron-provincial` | Mensual/al publicarse | P+E | `batch` | Padrones IIBB (FI-INT-18, 21, 22) |
| JOB-INT-27 | `int:vencer-intenciones` | Horario | P | `maintenance` | Vence/limpia intenciones impagas (RN-INT-033) |
| JOB-INT-28 | `int:consumo-mensual` | Mensual | P | `batch` | Cierre de consumo por tenant (RF-INT-013) |

**Módulo T07** (16 jobs; fuente: anexo T07 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-MIG-01 | `mig:extraer-snapshot` | A demanda / programado (delta diario en paralelo) | P+D | `ai` | Extracción por tabla, reanudable |
| JOB-MIG-02 | `mig:perfilar` | Tras snapshot | E | `batch` | Perfilado |
| JOB-MIG-03 | `mig:transformar` | Por corrida | E | `batch` | Aplicación de reglas |
| JOB-MIG-04 | `mig:validar` | Por corrida | E | `batch` | Validaciones |
| JOB-MIG-05 | `mig:cargar-dominio` | Por corrida (hijos por tabla/lote) | E | `batch` | Carga vía servicio del módulo |
| JOB-MIG-06 | `mig:conciliar` | Tras carga | E | `batch` | Cálculo de checks |
| JOB-MIG-07 | `mig:reprocesar` | A demanda | D | `batch` | Reproceso de selección |
| JOB-MIG-08 | `mig:paralelo-simular` | Por ciclo | E | `batch` | Invoca `fac:emitir-lote` en modo `simulation` |
| JOB-MIG-09 | `mig:paralelo-comparar` | Tras simular e importar | E | `batch` | Comparación factura por factura |
| JOB-MIG-10 | `mig:sync-convivencia` | Según `coexistenceSyncs.schedule` | E | `export` | Deltas y exportaciones de convivencia |
| JOB-MIG-11 | `mig:exportar-asientos-procoop` | Diario en convivencia E2 | P | `export` | Archivo importable en ProCoop |
| JOB-MIG-12 | `mig:anonimizar` | A demanda | D | `maintenance` | Snapshot anonimizado + verificación de fuga |
| JOB-MIG-13 | `mig:archivar-historico` | O11, tras corte | E | `maintenance` | Carga de `legacyRecords` |
| JOB-MIG-14 | `mig:vencer-alias` | Diario | P | `batch` | Desactiva alias vencidos (PRM-MIG-030) |
| JOB-MIG-15 | `mig:purgar-staging` | Diario | P | `maintenance` | TTL y purga de ensayos |
| JOB-MIG-16 | `mig:migrar-adjuntos` | Por corrida | E | `batch` | Copia de archivos con hash |

**Módulo T08** (24 jobs; fuente: anexo T08 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-NFR-01 | `nfr:informe-acceso` | Por solicitud verificada | D | `batch` | Genera informe PDF + JSON del titular |
| JOB-NFR-02 | `nfr:localizar-titular` | Por solicitud verificada | D | `batch` | Busca apariciones del titular en colecciones `x-pii` |
| JOB-NFR-03 | `nfr:ejecutar-solicitud` | Por aprobación | E | `batch` | Emite EVT-NFR-06 por módulo, espera confirmaciones, registra `erasureLedger` |
| JOB-NFR-04 | `nfr:aplicar-conservacion` | Diario 03:00 hora del tenant | P | `batch` | Calcula candidatos por política, omite bloqueos, ejecuta lo aprobado |
| JOB-NFR-05 | `nfr:verificar-cadena-auditoria` | Diario 04:00 UTC | P | `batch` | Verifica encadenamiento de hash y anclaje WORM (RNF-NFR-113) |
| JOB-NFR-06 | `nfr:verificar-invariantes` | Diario 05:00 hora del tenant y bajo demanda | P+D | `batch` | Controles de RNF-NFR-229 |
| JOB-NFR-07 | `nfr:simulacro-restauracion` | Mensual (plataforma), trimestral (tenant) | P | `maintenance` | Restaura en ambiente aislado y ejecuta verificaciones |
| JOB-NFR-08 | `nfr:recifrar` | Tras rotación de DEK o compromiso | E | `batch` | Re-cifra campos con la clave nueva |
| JOB-NFR-09 | `nfr:vencimientos-credenciales` | Diario 08:00 hora del tenant | P | `batch` | Certificados y credenciales por vencer (RNF-NFR-071) |
| JOB-NFR-10 | `nfr:escanear-patrones` | Semanal | P | `batch` | Escanea muestras de logs, auditoría y telemetría buscando secretos y PII (RNF-NFR-118, 121, 139) |
| JOB-NFR-11 | `nfr:limpiar-exportaciones` | Cada hora | P | `maintenance` | Elimina archivos de exportación vencidos (PRM-NFR-054) |
| JOB-NFR-12 | `nfr:antivirus-analizar` | Por archivo subido (cola `critical`) | E | `batch` | Analiza, mueve o retiene (RNF-NFR-079) |
| JOB-NFR-13 | `nfr:actualizar-firmas-av` | Cada 6 h | P | `integration` | Actualiza firmas del antivirus |
| JOB-NFR-14 | `nfr:destruir-tenant` | Por EVT `pla.tenant.closed` + plazo | E | `batch` | Destrucción de datos del tenant y constancia (RNF-NFR-108) |
| JOB-NFR-15 | `nfr:reaplicar-supresiones` | Tras cada restauración | P+E | `batch` | Reaplica `erasureLedger` (RNF-NFR-045) |
| JOB-NFR-16 | `nfr:agregar-csp` | Cada 5 min | P | `export` | Agrega reportes CSP |
| JOB-NFR-17 | `nfr:informe-sla` | Mensual, día 1 | P | `batch` | Disponibilidad, latencias e incidentes por tenant |
| JOB-NFR-18 | `nfr:inventario-backups` | Cada hora | P | `maintenance` | Verifica existencia y estado de backups (RNF-NFR-038) |
| JOB-NFR-19 | `nfr:conciliar-tras-restauracion` | Tras restauración selectiva | E | `maintenance` | Consulta ARCA, pasarelas, entes y mensajería y reconcilia (RNF-NFR-044) |
| JOB-NFR-20 | `nfr:evaluar-slo` | Cada 60 s | P | `batch` | Calcula SLI y burn rate y dispara `alertEvents` (RNF-NFR-131, 132) |
| JOB-NFR-21 | `nfr:medir-consumo` | Cada hora y cierre mensual | P | `export` | Consolida `tenantUsageSnapshots` y evalúa cuotas y topes (RNF-NFR-250, 251); emite EVT-NFR-14 |
| JOB-NFR-22 | `nfr:informe-accesos-sensibles` | Mensual | P | `batch` | Informe al responsable de datos del tenant con las lecturas de datos de salud, bancarios y de identidad (RNF-NFR-101, 11… |
| JOB-NFR-23 | `nfr:anonimizar-dataset-bi` | Al publicar un cubo certificado y diario | P+E | `maintenance` | Seudonimiza y suprime celdas menores que PRM-NFR-094 (RNF-NFR-106) |
| JOB-NFR-24 | `nfr:escaneo-configuracion` | Semanal | P | `batch` | TLS, encabezados, buckets públicos, nombres de objetos con PII, contenedores como root y deriva de IaC (RNF-NFR-052, 058… |

**Módulo T09** (33 jobs; fuente: anexo T09 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-COM-01 | `com:publicar-programadas` | cada minuto | P | `batch` | Publica `scheduled` vencidas. |
| JOB-COM-02 | `com:expirar-publicaciones` | cada 15 min | P | `batch` | Archiva vencidas, libera fijados. |
| JOB-COM-03 | `com:notificar-publicacion` | por evento | E | `notifications` | Avisos de nueva publicación por lotes. |
| JOB-COM-04 | `com:analizar-contenido` | por evento | E | `ai` | Análisis IA asíncrono de comentarios e imágenes. |
| JOB-COM-05 | `com:cerrar-comentarios` | diario | P | `batch` | Cierra hilos por antigüedad. |
| JOB-COM-06 | `com:expirar-sanciones` | cada hora | P | `batch` | Vence sanciones. |
| JOB-COM-07 | `com:purgar-evidencia` | diario | P | `maintenance` | Aplica retención de evidencias y vistas. |
| JOB-COM-08 | `com:generar-boletines` | cada 15 min | P | `batch` | Evalúa reglas de boletín. |
| JOB-COM-09 | `com:enviar-boletin` | por aprobación | E | `notifications` | Envío del boletín. |
| JOB-COM-10 | `com:recordatorios-encuestas` | cada hora | P | `notifications` | Recordatorios según configuración. |
| JOB-COM-11 | `com:cerrar-encuestas` | cada 15 min | P | `batch` | Cierra vencidas; reabre periódicas. |
| JOB-COM-12 | `com:inteligencia-encuestas` | cada 24 h o +15 respuestas | P | `ai` | Recalcula capa B (IA cacheada). |
| JOB-COM-13 | `com:informe-encuesta` | según `reportSchedule` | E | `batch` | Envía informe programado. |
| JOB-COM-14 | `com:recordatorios-eventos` | cada 5 min | P | `notifications` | Recordatorios de eventos. |
| JOB-COM-15 | `com:finalizar-eventos` | cada hora | P | `batch` | Pasa eventos a `finished`; no-show. |
| JOB-COM-16 | `com:expirar-beneficios` | diario | P | `batch` | Vence beneficios y códigos. |
| JOB-COM-17 | `com:evaluar-audiencia` | a pedido | D | `batch` | Conteos de audiencias grandes. |
| JOB-COM-18 | `com:generar-comunicaciones` | por evento | E | `batch` | Consumidor de eventos transaccionales → `communications`. |
| JOB-COM-19 | `com:despachar` | continuo (cola por canal) | P | `maintenance` | Envío a conectores con throttling. |
| JOB-COM-20 | `com:reintentar` | cada minuto | P | `batch` | Reencola `failed` soft con `nextAttemptAt`. |
| JOB-COM-21 | `com:expirar-comunicaciones` | cada 15 min | P | `maintenance` | `ttl` vencido → `expired` + alternativa. |
| JOB-COM-22 | `com:verificar-hitos` | cada 15 min | P | `batch` | Emite `milestoneReached`/`failed` por plazo. |
| JOB-COM-23 | `com:generar-constancia` | a pedido / regulatory | D | `batch` | PDF con hash al expediente. |
| JOB-COM-24 | `com:ejecutar-campana` | programado | P | `notifications` | Ejecuta campañas. |
| JOB-COM-25 | `com:metricas-campana` | cada 5 min | P | `notifications` | Agrega métricas. |
| JOB-COM-26 | `com:sincronizar-plantillas-whatsapp` | cada hora | P | `integration` | Estado de aprobación de plantillas del proveedor. |
| JOB-COM-27 | `com:limpiar-push` | diario | P | `maintenance` | Revoca suscripciones con 410/404 o > N fallas. |
| JOB-COM-28 | `com:purgar-bandeja` | diario | P | `maintenance` | Vence `appNotifications`. |
| JOB-COM-29 | `com:consumo-mensajeria` | diario | P | `batch` | Agrega `messagingUsage`, alertas de cupo. |
| JOB-COM-30 | `com:saludos-automaticos` | diario 08:00 tenant | P | `batch` | Cumpleaños/aniversarios. |
| JOB-COM-31 | `com:retencion-comunicaciones` | mensual | P | `maintenance` | Archiva/anonimiza según política (reemplaza V2 3097/3098). |
| JOB-COM-32 | `com:avisos-interrupcion` | cada 5 min | P | `notifications` | Transiciones programadas de avisos de interrupción. |
| JOB-COM-33 | `com:vencimientos-proximos` | diario 09:00 tenant | P | `batch` | Genera tipos 44, 45, 59 consultando M07/M08. |

**Módulo T10** (22 jobs; fuente: anexo T10 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-BIA-01 | `bia:ejecutar-reporte` | Por demanda | D | `export` | Ejecuta provider en lotes |
| JOB-BIA-02 | `bia:generar-exportacion` | Por demanda | D | `export` | Genera archivo |
| JOB-BIA-03 | `bia:programador` | Cada minuto | P | `batch` | Dispara programaciones |
| JOB-BIA-04 | `bia:entregar-reporte` | Por demanda | D | `export` | Envía emails |
| JOB-BIA-05 | `bia:purgar-exportaciones` | Diario 03:00 | P | `maintenance` | Borra vencidos y resultados temporales |
| JOB-BIA-06 | `bia:snapshot-indicadores` | Diario 02:00 (tz tenant) | P | `export` | Snapshots diarios |
| JOB-BIA-07 | `bia:cierre-mensual-indicadores` | Mensual día hábil `PRM-BIA-028` | P | `export` | Congela mes |
| JOB-BIA-08 | `bia:evaluar-alertas` | 15 min y post-snapshot | E | `batch` | Alertas |
| JOB-BIA-09 | `bia:proyectar-<dominio>` | Continuo | P | `batch` | Proyección analítica |
| JOB-BIA-10 | `bia:snapshot-saldos` | Diario 01:30 | P | `export` | Saldos y aging |
| JOB-BIA-11 | `bia:reconciliar-bi` | Diario 05:00 | P | `batch` | Interno vs BI |
| JOB-BIA-12 | `bia:reconstruir-proyeccion` | Manual | P+D | `batch` | Rebuild |
| JOB-BIA-13 | `bia:analisis-ia-auto` | Cada `PRM-BIA-034` h por sala con cambios | P | `ai` | Análisis automático |
| JOB-BIA-14 | `bia:despachar-eventos-publicos` | Continuo | P | `integration` | Crea entregas webhook |
| JOB-BIA-15 | `bia:entregar-webhook` | Por entrega | E | `integration` | POST firmado |
| JOB-BIA-16 | `bia:expirar-credenciales` | Horario | P | `batch` | Expira y avisa 15/7/1 días antes |
| JOB-BIA-17 | `bia:agregar-uso-api` | Horario y diario | P | `batch` | `apiUsageDaily` |
| JOB-BIA-18 | `bia:benchmark-agregar` | Mensual día 10 | P | `export` | Agregados anónimos |
| JOB-BIA-19 | `bia:publicar-datos-abiertos` | Según publicación | E | `batch` | Genera versión |
| JOB-BIA-20 | `bia:exportacion-masiva` | Por demanda | D | `export` | `extBulkExports` |
| JOB-BIA-21 | `bia:exportacion-salida` | Por demanda (T01) | D | `export` | Portabilidad |
| JOB-BIA-22 | `bia:verificar-frescura` | Cada 5 min | P | `export` | Frescura de datasets → alerta |

**Módulo M01** (12 jobs; fuente: anexo M01 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-PER-01 | `per:verificar-cuit-arca` | Alta/cambio de CUIT/CUIL; manual | P+E+D | `integration` | Consulta el padrón de ARCA, guarda constancia y resultado (`arcaVerified`, `arcaMismatch`, `arcaNotFound`); publica `per`… |
| JOB-PER-02 | `per:geocodificar-domicilios` | Alta/cambio de domicilio; lote nocturno de pendientes | P+E | `integration` | Normaliza y busca candidato con el proveedor configurado; respeta cuotas. |
| JOB-PER-03 | `per:detectar-duplicados` | Diario 02:00 (hora del tenant); al importar | P | `batch` | Calcula pares candidatos sobre personas cambiadas; crea o actualiza `duplicateCases`. |
| JOB-PER-04 | `per:vencimientos` | Diario 01:00 | P | `batch` | Vence documentación, relaciones y bloqueos; ejecuta acciones de vencimiento; avisa por vencer (PRM-PER-098). |
| JOB-PER-05 | `per:mayoria-edad-adherentes` | Diario | P | `notifications` | Lista adherentes que cumplen la edad (PRM-PER-067) y envía el aviso por T09 (PRM-PER-066). |
| JOB-PER-06 | `per:adherentes-condicion` | Manual o programado por el administrador | P+D | `batch` | Evalúa condición de adherentes contra categoría (RN-PER-083) y da de baja o cambia categoría en lote con simulación prev… |
| JOB-PER-07 | `per:ejecutar-transferencia` | Transferencia aprobada | E | `batch` | Ejecuta los pasos con comandos a M02/M05/M07/M17; compensa si falla. |
| JOB-PER-08 | `per:fusionar-personas` | Fusión aprobada | E | `batch` | Reasigna referencias propias, publica evento y espera confirmaciones; habilita reversión. |
| JOB-PER-09 | `per:importar` | Importación confirmada (ExcelImportWizard) | E | `integration` | Importa personas, titulares, cuentas, inmuebles, adherentes, marcas de facturación (RN-PER-051) con validación por fila. |
| JOB-PER-10 | `per:revalidar-padron-arca` | Mensual (PRM-PER-014) | P | `integration` | Revalida identificaciones fiscales y lista diferencias de condición IVA sin cambiarlas (RF-PER-029). |
| JOB-PER-11 | `per:anonimizar` | Solicitud de supresión resuelta; plazo de conservación cumplido | D | `maintenance` | Anonimiza campos no obligatorios de personas archivadas conservando lo fiscal exigido. |
| JOB-PER-12 | `per:exportar-padron` | Pedido de exportación | D | `export` | Genera el padrón con columnas y filtros elegidos (RF-PER-148) y lo deja en T11 con vencimiento. |

**Módulo M02** (12 jobs; fuente: anexo M02 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-CAT-01 | `cat:altas-automaticas` | Evento | E | `batch` | Evalúa `autoServiceRules`. |
| JOB-CAT-02 | `cat:tramite-masivo` | Aprobación | E | `batch` | Ejecuta `bulkContractOperations` por lotes. |
| JOB-CAT-03 | `cat:copiar-servicio` | Comando | D | `batch` | Copia configuración entre tenants. |
| JOB-CAT-04 | `cat:publicar-version-programada` | Diario 00:05 zona del tenant | P | `batch` | Publica versiones `scheduled` cuyo `effectiveFrom` llegó. |
| JOB-CAT-05 | `cat:vencimiento-provisorios` | Diario | P | `notifications` | Notifica y propone baja/conversión de provisorios vencidos. |
| JOB-CAT-06 | `cat:vencimiento-no-facturar` | Diario | P | `integration` | Quita la marca "No facturar" vencida y avisa. |
| JOB-CAT-07 | `cat:mayoria-edad-adherentes` | Diario (V2 3186) | P | `notifications` | Lista adherentes que cumplen 21 años; envía correo/notificación. |
| JOB-CAT-08 | `cat:fin-suspension-voluntaria` | Diario | P | `batch` | Solicita reactivación al vencer la suspensión voluntaria. |
| JOB-CAT-09 | `cat:devoluciones-vencidas` | Diario | P | `integration` | Marca equipos con devolución vencida y crea tareas de retiro (TEC). |
| JOB-CAT-10 | `cat:fin-promociones` | Al cierre de ciclo (evento de FAC) | E | `integration` | Marca promociones finalizadas y notifica al socio (RF-CAT-052). |
| JOB-CAT-11 | `cat:carencias` | Diario | P | `notifications` | Activa coberturas al cumplirse la carencia y notifica. |
| JOB-CAT-12 | `cat:fin-cuotas-obra` | Evento de FAC (última cuota) | E | `batch` | Cierra contratos OBR completados. |

**Módulo M03** (22 jobs; fuente: anexo M03 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-MED-01 | `med:generar-lotes` | Diario (según cronograma) y a pedido | P+D | `batch` | 9.2. |
| JOB-MED-02 | `med:asignar-automatica` | A pedido | D | `batch` | Divide tareas entre lecturistas por secuencia/zona. |
| JOB-MED-03 | `med:confirmar-lote` | A pedido / al completar recepción | E+D | `batch` | 9.4. |
| JOB-MED-04 | `med:importar-lecturas` | A pedido | D | `batch` | 9.6. |
| JOB-MED-05 | `med:estimar` | A pedido / al cerrar lote | E+D | `batch` | 9.10. |
| JOB-MED-06 | `med:dividir-consumos` | A pedido / al confirmar lote | E+D | `batch` | 9.12. |
| JOB-MED-07 | `med:distribuir-consumos` | Al aprobar padre / a pedido | E+D | `notifications` | 9.12. |
| JOB-MED-08 | `med:regularizar-estimados` | Al validar lectura real posterior a estimado; diario | P+E | `batch` | 9.11. |
| JOB-MED-09 | `med:detectar-transgresiones` | Al aprobar demanda; mensual | P+E+D | `batch` | 9.13. |
| JOB-MED-10 | `med:toma-estado` | Según cronograma / a pedido | P+D | `batch` | 9.7. |
| JOB-MED-11 | `med:importar-ami` | Configurable por sistema (horario/diario) | P | `integration` | 9.7. |
| JOB-MED-12 | `med:ejecutar-operaciones-remotas` | Continuo (cola) | P | `integration` | 9.8. |
| JOB-MED-13 | `med:solicitar-credito-prepago` | Continuo (cola) | P | `batch` | 9.9. |
| JOB-MED-14 | `med:conciliar-prepago` | Diario (hora PRM-MED-135) | P | `batch` | 9.9. |
| JOB-MED-15 | `med:balance-inyeccion` | Al aprobar consumos GD | E | `batch` | 9.14. |
| JOB-MED-16 | `med:abrir-ventanas-autolectura` | Diario | P | `batch` | 9.15. |
| JOB-MED-17 | `med:detectar-sin-lectura` | Al cerrar ventana del cronograma | P+E | `batch` | Informa medidores sin leer (RN-MED-083) y crea excepciones. |
| JOB-MED-18 | `med:detectar-consumo-no-registrado` | Mensual tras aprobación | P | `batch` | Patrones de RF-MED-126. |
| JOB-MED-19 | `med:verificar-salud-conectores` | Cada 15 min | P | `integration` | Salud de `meteringSystems`. |
| JOB-MED-20 | `med:depurar-logs-conector` | Diario | P | `maintenance` | Aplica retención PRM-MED-133. |
| JOB-MED-21 | `med:archivar-fotos` | Mensual | P | `maintenance` | Aplica PA-MED-09 (archivo frío). |
| JOB-MED-22 | `med:importar-curvas` | Diario (Extensión) | P | `batch` | Curvas de carga (PA-MED-03). |

**Módulo M04** (13 jobs; fuente: anexo M04 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-TAR-01 | `tar:activar-versiones` | Diario 00:05 zona del tenant y al publicar | P+E | `batch` | Activa versiones `scheduled` con `validFrom` ≤ hoy y cierra las anteriores. |
| JOB-TAR-02 | `tar:simular-masivo` | A pedido | D | `batch` | Simulación masiva comparativa por bloques (PRM-TAR-020). |
| JOB-TAR-03 | `tar:calcular-lote` | A pedido de M05 | D | `batch` | Cálculo de un lote de cuentas por bloques. |
| JOB-TAR-04 | `tar:importar-padron` | A pedido | D | `batch` | Validación y cruce de padrones. |
| JOB-TAR-05 | `tar:recategorizar` | A pedido | D | `batch` | Recategorización masiva por padrón/edad/gas (preview y aplicación vía M02). |
| JOB-TAR-06 | `tar:diferencias-retroactivas` | Al publicar con vigencia pasada o a pedido | E+D | `batch` | Diferencias contra comprobantes emitidos. |
| JOB-TAR-07 | `tar:migrar-cuadros` | Migración (T07) | E | `batch` | Reconstrucción de versiones desde `CUADROS` + `HIS_*` + tablas vivas. |
| JOB-TAR-08 | `tar:traducir-formulas` | Migración y a pedido | D | `batch` | Traducción DevExpress → GFL con casos de prueba. |
| JOB-TAR-09 | `tar:tasar-llamadas` | Al recibir `tec.cdr.imported`; cada hora si PRM-TAR-083 | P+E | `batch` | Tasación de llamadas pendientes. |
| JOB-TAR-10 | `tar:retasar` | A pedido | D | `batch` | Retasación por rango conservando IDs. |
| JOB-TAR-11 | `tar:aviso-fin-promociones` | Diario | P | `notifications` | Avisos de último ciclo / fin de promoción. |
| JOB-TAR-12 | `tar:purgar-simulaciones` | Semanal | P | `maintenance` | Purga simulaciones y cálculos descartados vencidos (PRM-TAR-151). |
| JOB-TAR-13 | `tar:exportar-padron` | A pedido | D | `export` | Exportación de beneficiarios al organismo. |

**Módulo M05** (18 jobs; fuente: anexo M05 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-FAC-01 | `fac:preparar-lote` | API preparar | E | `batch` | Valida, resuelve y congela universo. |
| JOB-FAC-02 | `fac:prefacturar-lote` | API prefacturar o nueva versión de universo | E | `batch` | Calcula candidatos y excepciones. |
| JOB-FAC-03 | `fac:emitir-lote` | API emitir/reanudar | E | `batch` | Emite por bloques. |
| JOB-FAC-04 | `fac:generar-pdf` | `fis.invoice.authorized` o emisión sin autorización | E | `batch` | PDF y QR. |
| JOB-FAC-05 | `fac:generar-codigos` | Emisión | E | `batch` | Códigos de pago. |
| JOB-FAC-06 | `fac:distribuir-lote` | API distribuir o automático al autorizar | E | `notifications` | Distribución. |
| JOB-FAC-07 | `fac:reprocesar-excepciones` | API o al resolver excepciones | E | `batch` | Crea/actualiza lote `reprocess`. |
| JOB-FAC-08 | `fac:conciliar-inciertos` | Cada 15 min | P | `batch` | Pide a M06 consulta del último comprobante y concilia. |
| JOB-FAC-09 | `fac:anular-masivo` | Solicitud aprobada | E+D | `batch` | Anulación/NC/ND. |
| JOB-FAC-10 | `fac:recategorizar` | Operación aprobada | E | `batch` | Simulación y confirmación. |
| JOB-FAC-11 | `fac:retroactivos` | Operación aprobada | E | `batch` | Genera ítems facturables retroactivos. |
| JOB-FAC-12 | `fac:modificacion-masiva` | Operación aprobada | E | `batch` | Aplica cambios no fiscales. |
| JOB-FAC-13 | `fac:importar-terceros` | Importación confirmada | E | `batch` | Crea ítems o comprobantes. |
| JOB-FAC-14 | `fac:generar-talones` | API | E | `batch` | Talones/cupones. |
| JOB-FAC-15 | `fac:cerrar-ciclo` | Acta aprobada | E | `batch` | Cierre, PDF del acta, traslados, propagación. |
| JOB-FAC-16 | `fac:alerta-pendientes-autorizacion` | Diario | P | `notifications` | Alerta de pendientes antiguos (REL §1). |
| JOB-FAC-17 | `fac:programar-ciclos` | Diario 02:00 hora del tenant | P | `batch` | Crea lotes `draft`. |
| JOB-FAC-18 | `fac:aplicar-resultado-fiscal` | Eventos `fis.*` | E | `batch` | Actualiza estado fiscal y casos. |

**Módulo M06** (20 jobs; fuente: anexo M06 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-FIS-01 | `fis:autorizar-cola` | Por evento y cada 1 min | P+E | `integration` | Autorización CAE por par serializado (§9.2) |
| JOB-FIS-02 | `fis:renovar-ticket` | A demanda y preventivo cada 30 min | P+D | `integration` | WSAA con lock distribuido |
| JOB-FIS-03 | `fis:probar-conector` | A demanda y cada 15 min (health) | P+D | `integration` | `FEDummy`, TA y puntos |
| JOB-FIS-04 | `fis:conciliar-incierto` | Inmediato tras timeout y cada 5 min | P | `batch` | `FECompConsultar` de inciertos |
| JOB-FIS-05 | `fis:conciliar-arca` | Diario 02:00 (zona del tenant) y tras restauración | P | `integration` | Inconsistencias CAE/importe |
| JOB-FIS-06 | `fis:solicitar-caea` | N días antes de cada quincena | P | `integration` | `FECAEAConsultar`/`Solicitar` |
| JOB-FIS-07 | `fis:informar-caea` | Diario y al cierre de quincena | P | `integration` | `FECAEARegInformativo` y sin movimiento |
| JOB-FIS-08 | `fis:importar-padron` | A demanda / mensual | P+D | `batch` | Padrones IIBB y offline |
| JOB-FIS-09 | `fis:sincronizar-puntos-venta` | Diario | P | `integration` | `FEParamGetPtosVenta` por tenant |
| JOB-FIS-10 | `fis:generar-libro-iva` | A demanda | D | `export` | Libro IVA ventas/compras |
| JOB-FIS-11 | `fis:generar-lid` | A demanda / mensual | P+D | `export` | Archivos Libro IVA Digital |
| JOB-FIS-12 | `fis:conciliar-mis-comprobantes` | A demanda | D | `integration` | Cruce con ARCA |
| JOB-FIS-13 | `fis:generar-regimen` | A demanda / según calendario | D | `batch` | Regímenes informativos |
| JOB-FIS-14 | `fis:calendario-fiscal` | Diario | P | `batch` | Borradores y alertas de vencimientos |
| JOB-FIS-15 | `fis:rendicion-terceros` | Según convenio | E | `batch` | Cálculo de rendiciones |
| JOB-FIS-16 | `fis:generar-informe-regulatorio` | A demanda / según calendario | D | `batch` | Reguladores |
| JOB-FIS-17 | `fis:sincronizar-parametros-arca` | Semanal (plataforma) | P | `integration` | Tablas `FEParamGet*` |
| JOB-FIS-18 | `fis:alertas-credenciales` | Diario | P | `integration` | Certificados, CAI, CESP, CAEA, padrones |
| JOB-FIS-19 | `fis:revalidar-condicion` | Mensual | P | `batch` | Revalidación de padrón |
| JOB-FIS-20 | `fis:pasarela-importar` | Por carga / API | E | `integration` | Modo pasarela |

**Módulo M07** (22 jobs; fuente: anexo M07 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-COB-01 | `cob:exportar-deuda-ente` | Programado por ente / manual; Según `collectionAgencies.transport.schedule` | P+D | `export` | — |
| JOB-COB-02 | `cob:importar-rendicion` | SFTP T06 (archivo nuevo) / manual; Cada 30 min en ventana configurada | P+D | `batch` | — |
| JOB-COB-03 | `cob:sondear-rendicion-api` | Programado (SIRO API, Pagos360); Diario + a demanda por fecha | P+D | `batch` | — |
| JOB-COB-04 | `cob:procesar-webhook` | Webhook recibido; En línea | E | `integration` | — |
| JOB-COB-05 | `cob:resolver-inciertos` | Intención `uncertain` / polling; Backoff 1-5-15-60 min, luego 6 h hasta 72 h | E | `batch` | — |
| JOB-COB-06 | `cob:conciliar-pasarelas-diario` | Programado; Diario 06:00 tenant | P | `integration` | — |
| JOB-COB-07 | `cob:presentar-debitos` | Día de corte; Diario (evalúa cortes) | P | `batch` | — |
| JOB-COB-08 | `cob:importar-rechazos-debito` | Archivo / API; Diario | P | `batch` | — |
| JOB-COB-09 | `cob:sincronizar-adhesiones` | Programado; Diario | P | `integration` | — |
| JOB-COB-10 | `cob:cancelacion-automatica-creditos` | Programado / manual; Diario tras facturación | P+D | `batch` | — |
| JOB-COB-11 | `cob:emitir-resumenes` | `fac.batch.issued` / cierre de ciclo; Por ciclo | E | `batch` | — |
| JOB-COB-12 | `cob:vencer-intenciones` | Programado; Cada hora | P | `batch` | — |
| JOB-COB-13 | `cob:recordatorio-cierre-caja` | Programado; Fin de jornada configurable | P | `notifications` | — |
| JOB-COB-14 | `cob:verificar-integridad-auxiliar` | Programado / manual; Diario 03:00 tenant | P+D | `batch` | — |
| JOB-COB-15 | `cob:reparar-pendientes` | Operaciones `pendingFiscal`, outbox atascado; Cada 10 min | P | `batch` | — |
| JOB-COB-16 | `cob:qr-masivo-facturas` | `fac.batch.issued`; Por lote | E | `batch` | — |
| JOB-COB-17 | `cob:liquidar-comisiones-cobradores` | Programado / manual; Mensual | P+D | `batch` | — |
| JOB-COB-18 | `cob:procesar-novedades-adhesion` | Archivo de novedades / morosidad; A demanda | D | `batch` | — |
| JOB-COB-19 | `cob:importar-contracargos` | API / archivo del proveedor; Diario | P | `batch` | — |
| JOB-COB-20 | `cob:conciliacion-cobranzas` | Programado; Diario | P | `batch` | — |
| JOB-COB-21 | `cob:escalar-no-identificados` | Programado; Diario | P | `batch` | — |
| JOB-COB-22 | `cob:actualizar-deuda-publicada` | `cob.obligation.settled`, `fac.invoice.voided`; En línea / lote diario | P+E | `batch` | — |

**Módulo M08** (18 jobs; fuente: anexo M08 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-MOR-05 | `mor:vencer-promesas` | Diario | P | `integration` | Marca promesas vencidas como `kept` (si se pagó lo prometido) o `broken`; libera la notificación para procesar. |
| JOB-MOR-06 | `mor:alertas-protecciones` | Diario | P | `notifications` | Alertas de protecciones y excepciones por vencer o vencidas; las vencidas dejan de bloquear. |
| JOB-MOR-12 | `mor:recalcular-cuotas-fiscal` | A demanda / mensual | P+D | `batch` | Detecta cuotas con situación fiscal distinta (RN-MOR-122) y propone el recálculo. |
| JOB-MOR-13 | `mor:deuda-a-prescribir` | Mensual | P | `batch` | Prepara la corrida de prescripción en `draft` y alertas de próximas a prescribir. |
| JOB-MOR-14 | `mor:exportacion-regulatoria` | Según regulador | E | `integration` | Genera el archivo de condición de mora (ERSeP). |
| JOB-MOR-15 | `mor:ajuste-indices` | Mensual | P | `notifications` | Verifica disponibilidad de índices para cuotas con ajuste del mes; alerta faltantes. |
| JOB-MOR-16 | `mor:actualizar-depositos` | Mensual | P | `batch` | Propone actualización de depósitos en garantía indexados. |
| JOB-MOR-17 | `mor:segmentar-deuda` | Diario | P | `batch` | Recalcula segmentos de los expedientes de seguimiento (BASE §14). |
| JOB-MOR-01 | `mor:intereses-facturar` (`:preview`, `:generate`) | A demanda | D | `batch` | §9.3 |
| JOB-MOR-02 | `mor:evaluar-mora` | Diario (hora del tenant, default 03:00) | P | `batch` | §9.4 |
| JOB-MOR-03 | `mor:generar-candidatos` | A demanda o programado por política | P+D | `batch` | §9.5 |
| JOB-MOR-04 | `mor:procesar-instancia` | A demanda o programado (`autoAdvance`) | P+D | `batch` | §9.6 |
| JOB-MOR-07 | `mor:evaluar-reconexion` | Por evento | E | `batch` | §9.8 |
| JOB-MOR-08 | `mor:fin-suspension-voluntaria` | Diario | P | `batch` | §9.9 |
| JOB-MOR-09 | `mor:vencer-anticipos` | Diario | P | `batch` | §9.10 |
| JOB-MOR-10 | `mor:emitir-cuotas` | Diario | P | `batch` | §9.10 |
| JOB-MOR-11 | `mor:control-convenios` | Diario | P | `batch` | §9.10 |
| JOB-MOR-18 | `mor:ejecutar-ventana` | Cada 15 min | P | `batch` | Libera casos `scheduled` cuya ventana de ejecución se abrió y los envía a M10/T06. |

**Módulo M09** (18 jobs; fuente: anexo M09 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-CRM-01 | `crm:sla-monitor` | Cada minuto | P | `batch` | Alertas, vencimientos y escalamientos SLA |
| JOB-CRM-02 | `crm:ai-classify` | Cola (por evento) | E | `ai` | Sugerencias de IA para casos nuevos y mensajes entrantes |
| JOB-CRM-03 | `crm:auto-close-resolved` | Diario 02:00 | P | `batch` | Cierre automático de resueltos sin respuesta tras plazo |
| JOB-CRM-04 | `crm:stale-cases` | Diario 07:00 | P | `notifications` | Indicadores "sin intervención" 7 y 8+ días; aviso a responsables |
| JOB-CRM-05 | `crm:incident-detect` | Cada 5 minutos | P | `batch` | Detección de concentraciones de reclamos |
| JOB-CRM-06 | `crm:cancellation-receipts` | Cada 15 minutos | P | `batch` | Control de constancias de baja (≤ 24 h) y reintento por canal alternativo |
| JOB-CRM-07 | `crm:procedure-expiry` | Diario 03:00 | P | `batch` | Vencimiento de trámites y acciones |
| JOB-CRM-08 | `crm:queue-day-close` | Diario al cierre de sucursal | P | `batch` | Cierre de turnos y boxes del día |
| JOB-CRM-09 | `crm:activity-generate` | Diario 01:00 | P | `batch` | Generación de ocurrencias y citas |
| JOB-CRM-10 | `crm:activity-reminders` | Diario 08:00 (una vez por día) | P | `notifications` | Estados, recordatorios, escalamiento |
| JOB-CRM-11 | `crm:circular-generate` | A demanda | D | `batch` | Generación de corridas |
| JOB-CRM-12 | `crm:email-ingest` | Cada minuto o por webhook | P | `batch` | Ingesta de email |
| JOB-CRM-13 | `crm:bot-step` | Cola (por mensaje) | E | `batch` | Procesamiento del bot |
| JOB-CRM-14 | `crm:conversation-expire` | Cada 5 minutos | P | `batch` | Expiración de ventanas y sesiones |
| JOB-CRM-15 | `crm:appointment-reminders` | Cada 15 minutos | P | `notifications` | Recordatorios y ausencias de reservas |
| JOB-CRM-16 | `crm:command-retry` | Cada minuto | P | `batch` | Reintentos de comandos fallidos |
| JOB-CRM-17 | `crm:metrics-snapshot` | Cada hora | P | `export` | Proyecciones para T10 (cubos de atención) |
| JOB-CRM-18 | `crm:whatsapp-templates-sync` | Diario | P | `integration` | Sincroniza estado de plantillas aprobadas |

**Módulo M10** (16 jobs; fuente: anexo M10 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-TEC-01 | `tec:liberar-reservas` | cada minuto | P | `batch` | Expira reservas `held` vencidas y devuelve capacidad. |
| JOB-TEC-02 | `tec:generar-ot-masivas` | a demanda | D | `batch` | Generación masiva por filtros. |
| JOB-TEC-03 | `tec:cerrar-ot-masivas` | a demanda | D | `batch` | Cierre/confirmación masiva. |
| JOB-TEC-04 | `tec:reparar-efectos` | cada 5 min | P | `batch` | Reintenta `pendingSteps` de OT en `closing`; tras N fallos, bandeja operativa. |
| JOB-TEC-05 | `tec:generar-mantenimiento` | diario 02:00 TZ tenant | P | `batch` | Planes preventivos. |
| JOB-TEC-06 | `tec:aprovisionar` | continuo (cola BullMQ) | P | `integration` | Ejecuta comandos de aprovisionamiento. |
| JOB-TEC-07 | `tec:monitorear-equipos` | cada 5 min | P | `batch` | Estado de equipos de red; caída → propuesta de incidente de zona. |
| JOB-TEC-08 | `tec:recordatorios-visitas` | cada 15 min | P | `notifications` | Recordatorios previos a la visita. |
| JOB-TEC-09 | `tec:importar-cdr` | a demanda / programado para fuentes online | P+D | `integration` | Parseo, deduplicación y atribución de CDR. |
| JOB-TEC-10 | `tec:geocodificar-pendientes` | cada hora | P | `integration` | Enriquecer puntos pendientes respetando cuotas. |
| JOB-TEC-11 | `tec:conciliar-aprovisionamiento` | diario + tras restauración | P | `integration` | Concilia estado local vs sistemas externos. |
| JOB-TEC-12 | `tec:escalar-conflictos` | cada hora | P | `batch` | Escala conflictos vencidos. |
| JOB-TEC-13 | `tec:exportar-gis` | a demanda / programado | P+D | `export` | Ejecuta plantillas de exportación GIS/regulatorias. |
| JOB-TEC-14 | `tec:vencer-factibilidades` | diario | P | `integration` | Marca `expired`. |
| JOB-TEC-15 | `tec:impacto-interrupcion` | a demanda | D | `batch` | Cálculo de impacto para planes grandes. |
| JOB-TEC-16 | `tec:alertas-ot-vencidas` | cada 30 min | P | `notifications` | Alertas de OT por vencer/vencidas. |

**Módulo M11** (7 jobs; fuente: anexo M11 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-VEN-01 | `ven:vencer-presupuestos` | Diario 00:30 (zona del tenant) | P | `batch` | Pasa a `expired` y libera reservas |
| JOB-VEN-02 | `ven:recordar-presupuestos` | Diario | P | `notifications` | Avisa presupuestos por vencer (N días) |
| JOB-VEN-03 | `ven:preparar-cuotas-corrida` | A demanda de M05 | D | `batch` | Selecciona cuotas a facturar (RN-VEN-030) y las bloquea para la corrida |
| JOB-VEN-04 | `ven:modificacion-masiva-cuotas` | A demanda | D | `batch` | Ejecuta la modificación con vista previa confirmada |
| JOB-VEN-05 | `ven:actualizacion-masiva-precios` | A demanda | D | `batch` | Aplica la actualización confirmada |
| JOB-VEN-06 | `ven:importar-ventas-terceros` | A demanda (desde M05) | D | `batch` | Crea ventas y cuotas de importaciones |
| JOB-VEN-07 | `ven:sincronizar-campo` | Al sincronizar | P+E | `integration` | Procesa presupuestos/ventas de pwa-campo con `clientMutationId` |

**Módulo M12** (8 jobs; fuente: anexo M12 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-CMP-01 | `cmp:vencer-cotizaciones` | Diario 01:00 | P | `integration` | Marca `expired` las cotizaciones vencidas |
| JOB-CMP-02 | `cmp:conciliar-tres-vias` | Al registrar factura o recepción; nocturno de repaso | P+E | `batch` | Recalcula conciliación y excepciones |
| JOB-CMP-03 | `cmp:alertas-vencimientos` | Diario | P | `notifications` | Facturas por vencer, documentos de proveedor vencidos, OC atrasadas |
| JOB-CMP-04 | `cmp:borradores-mis-comprobantes` | Tras JOB-FIS-12 | E | `batch` | Crea borradores desde comprobantes no registrados |
| JOB-CMP-05 | `cmp:lectura-ia` | A demanda | D | `ai` | Extracción por IA |
| JOB-CMP-06 | `cmp:desempeno-proveedores` | Semanal | P | `export` | Recalcula indicadores de desempeño |
| JOB-CMP-07 | `cmp:expandir-previsiones` | Diario | P | `batch` | Publica previsiones a M14 para el horizonte configurado |
| JOB-CMP-08 | `cmp:aprobacion-masiva` | A demanda | D | `batch` | Ejecuta aprobaciones masivas validando por documento |

**Módulo M13** (12 jobs; fuente: anexo M13 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-STK-01 | `stk:verificar-saldos` | Diario (madrugada) y antes de cierre | P | `export` | Recalcula saldos desde el libro por lote de artículos y reporta diferencias (no corrige sin aprobación). |
| JOB-STK-02 | `stk:vencer-reservas` | Cada hora | P | `notifications` | Expira reservas (RN-STK-024) y notifica. |
| JOB-STK-03 | `stk:sugerir-reposicion` | Diario | P | `batch` | Sugerencias por mínimo (9.8). |
| JOB-STK-04 | `stk:rendicion-cuadrillas` | Semanal configurable | P | `batch` | Abre rendiciones periódicas por cuadrilla (PRM-STK-030). |
| JOB-STK-05 | `stk:devoluciones-vencidas` | Diario | P | `notifications` | Asignaciones `pendingReturn` vencidas → avisos y propuestas de cargo. |
| JOB-STK-06 | `stk:preparar-cierre` | Mensual / a demanda | P+D | `batch` | Checklist de cierre de stock. |
| JOB-STK-07 | `stk:amortizar-bienes` | Mensual (o anual) | P | `batch` | Corrida de amortización (9.10). |
| JOB-STK-08 | `stk:mrp` | A demanda / diario | P+D | `integration` | Aprovisionamiento de fabricación. |
| JOB-STK-09 | `stk:vencimientos` | Diario | P | `batch` | Lotes por vencer, ensayos por vencer, garantías por vencer. |
| JOB-STK-10 | `stk:procesar-sync-campo` | Continuo (cola) | P | `batch` | Procesa lotes de `/field/sync` grandes de forma asíncrona con resultado por ítem. |
| JOB-STK-11 | `stk:importar` | A demanda | D | `batch` | Importaciones Excel grandes (artículos, series, saldos). |
| JOB-STK-12 | `stk:migrar-procoop` | A demanda (O11) | D | `batch` | Carga y conciliación de migración (sección 19). |

**Módulo M14** (14 jobs; fuente: anexo M14 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-TES-01 | `tes:recalcular-saldos` | Nocturno | P | `notifications` | Recalcula saldos desde movimientos y alerta diferencias con el materializado (AGR-011). |
| JOB-TES-02 | `tes:importar-extracto` | A demanda | D | `integration` | Parseo, validación y alta de líneas. |
| JOB-TES-03 | `tes:conciliar-automatico` | Tras importación/sincronización y a demanda | P+E+D | `batch` | Reglas de conciliación. |
| JOB-TES-04 | `tes:sincronizar-interbanking` | Diario (PRM-TES-058) | P | `integration` | Cuentas, saldos y movimientos. |
| JOB-TES-05 | `tes:generar-archivo-pago` | A demanda | D | `batch` | Archivo por formato. |
| JOB-TES-06 | `tes:procesar-respuesta-banco` | A demanda / al recibir | E+D | `batch` | Aplica respuestas y rechazos por línea. |
| JOB-TES-07 | `tes:abrir-caja-pagos` | Diario 00:05 (si PRM-TES-040) | P | `batch` | Apertura automática. |
| JOB-TES-08 | `tes:verificar-cajas-abiertas` | Diario 07:00 | P | `batch` | Alertas de cajas y rendiciones pendientes. |
| JOB-TES-09 | `tes:actualizar-cotizaciones` | Diario (hora configurable) | P | `batch` | Cotizaciones. |
| JOB-TES-10 | `tes:proyectar-flujo` | Nocturno y a demanda | P+D | `export` | Proyección base y snapshot. |
| JOB-TES-11 | `tes:alertas-vencimientos` | Diario | P | `notifications` | Valores por vencer, vencidos, eCheq por aceptar, cheques propios a debitar, depósitos no acreditados. |
| JOB-TES-12 | `tes:importar-liquidaciones-tarjeta` | A demanda (Extensión) | D | `batch` | Liquidaciones de procesadores. |
| JOB-TES-13 | `tes:reconciliar-externos` | A demanda (recuperación, ESC-04) | D | `integration` | Compara transmisiones y extractos con registros locales. |
| JOB-TES-14 | `tes:reintentar-eventos` | Cada 5 min | P | `batch` | Reprocesa eventos consumidos fallidos; envía a bandeja tras N intentos. |

**Módulo M15** (21 jobs; fuente: anexo M15 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-CON-10 | `con:proyectar-planes` | Evento `con.entry.posted` / reconstrucción | E | `batch` | Proyecta asientos oficiales a planes alternativos y regulatorios por `accountMappings`; marca sin equivalencia. |
| JOB-CON-11 | `con:reconstruir-saldos` | A demanda / nocturno | P+D | `batch` | Recalcula `ledgerBalances` desde `journalLines` y compara (RN-CON-092). |
| JOB-CON-12 | `con:exportar-externo` | Programado / a demanda | P+D | `integration` | Exporta asientos a sistema contable externo (layout, idempotente por rango y versión; marca `exported`). |
| JOB-CON-13 | `con:importar-asientos` | Carga de archivo | E | `batch` | Valida (cuentas, balance, período, duplicados por `externalId`), vista previa y contabiliza o deja borradores (`ExcelImp`… |
| JOB-CON-14 | `con:presupuesto-ejecucion` | Nocturno / eventos | P+E | `batch` | Recalcula ejecución (presupuestado, comprometido, devengado, pagado) y alertas de exceso. |
| JOB-CON-15 | `con:generar-estados` | A demanda | D | `export` | Genera estados contables con plantilla, comparativo y anexos; congela snapshot y hash al emitir. |
| JOB-CON-16 | `con:renumerar-asientos` | A demanda | D | `batch` | Renumera asientos de un ejercicio por fecha en períodos no transcriptos (`frmRenumerar`). |
| JOB-CON-17 | `con:anular-masivo` | A demanda | D | `batch` | Anulación/contraasiento masivo de lo seleccionado, con validación por asiento y eventos de reversión a módulos dueños (``… |
| JOB-CON-18 | `con:transcribir-rubricado` | A demanda | D | `ai` | Genera PDF de hojas rubricadas con folios correlativos y registra transcripción. |
| JOB-CON-19 | `con:salud-configuracion` | Diario y al publicar config | P+E | `batch` | Detecta roles sin cuenta, cuentas no imputables usadas, reglas solapadas, conceptos/productos/bancos/proveedores sin cue… |
| JOB-CON-20 | `con:asientos-recurrentes` | Diario | P | `batch` | Genera asientos de plantillas recurrentes y reversiones automáticas de provisiones. |
| JOB-CON-21 | `con:provisiones-cierre` | Cierre mensual | P | `batch` | Provisiones de SAC/vacaciones (con datos SUE), incobrables (con antigüedad de MOR/COB) e ingresos no facturados (con con… |
| JOB-CON-22 | `con:diferencia-cambio` | Cierre mensual | P | `batch` | Revalúa saldos en moneda extranjera con cotización de TES. |
| JOB-CON-01 | `con:contabilizar-evento` | Por evento | E | `events` | — |
| JOB-CON-02 | `con:cierre-diario` | Diario 02:00 (por defecto) o a demanda | P+D | `batch` | — |
| JOB-CON-03 | `con:reprocesar-pendientes` | Al publicar configuración / a demanda | E+D | `batch` | — |
| JOB-CON-05 | `con:cierre-ejercicio` | A demanda | D | `batch` | — |
| JOB-CON-06 | `con:ajuste-inflacion` | A demanda (anual o mensual) | P+D | `batch` | — |
| JOB-CON-07 | `con:distribuir-costos` | Mensual / a demanda | P+D | `batch` | — |
| JOB-CON-08 | `con:conciliar` | Diario (deudores, bancos) y mensual (resto) | P | `batch` | — |
| JOB-CON-09 | `con:simular-escenario` | A demanda | D | `batch` | — |

**Módulo M16** (23 jobs; fuente: anexo M16 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-SUE-01 | `sue:calcular-liquidacion` | A pedido | D | `batch` | Cálculo por lotes de 50 empleados, reanudable (§9.6). |
| JOB-SUE-02 | `sue:simular-configuracion` | A pedido | D | `batch` | Simulación de una versión en borrador sobre el último período (AGR-009). |
| JOB-SUE-03 | `sue:emitir-recibos-pdf` | Al aprobar | E | `batch` | PDF por recibo, hash, almacenamiento privado. |
| JOB-SUE-04 | `sue:firmar-recibos-empleador` | Al emitir | E | `integration` | Envía lote al proveedor de firma (FIC 15) o firma interna. |
| JOB-SUE-05 | `sue:notificar-recibos` | Al firmar el empleador | E | `notifications` | Notificaciones T09. |
| JOB-SUE-06 | `sue:consultar-estado-firma` | Cada 15 min mientras haya lotes abiertos | P | `integration` | Estado de firma con el proveedor. |
| JOB-SUE-07 | `sue:proponer-novedades-operativas` | Por evento y a pedido | E+D | `batch` | Novedades desde OT, cuadrillas, flota y tareas extra. |
| JOB-SUE-08 | `sue:importar-siradig` | A pedido | D | `batch` | Procesa XML de F.572. |
| JOB-SUE-09 | `sue:liquidacion-anual-ganancias` | Anual (cierre del período fiscal) y por egreso | P | `batch` | Determinación anual y formulario. |
| JOB-SUE-10 | `sue:generar-lsd` | A pedido | D | `export` | Archivo del Libro de Sueldos Digital. |
| JOB-SUE-11 | `sue:generar-sicoss` | A pedido | D | `batch` | Archivo SICOSS y controles. |
| JOB-SUE-12 | `sue:recalcular-saldos-vacaciones` | Diario 02:00 y por evento de licencia | P+E | `batch` | Saldos de vacaciones. |
| JOB-SUE-13 | `sue:generar-sicore-sueldos` | A pedido | D | `batch` | Archivo SICORE de sueldos. |
| JOB-SUE-14 | `sue:generar-archivos-sindicales` | A pedido | D | `batch` | Archivos por sindicato. |
| JOB-SUE-15 | `sue:alertas-legajo` | Diario 06:00 | P | `notifications` | Cambio de categoría, fin de prueba y de contrato, documentos, certificados art. 80, vencimientos de presentaciones, plaz… |
| JOB-SUE-16 | `sue:importar-liquidacion-externa` | A pedido | D | `batch` | Validación CU-28. |
| JOB-SUE-17 | `sue:procesar-fichadas` | Diario 03:00 y a pedido | P+D | `batch` | Fichadas contra turno. |
| JOB-SUE-18 | `sue:aplicar-aumento` | A pedido | D | `batch` | Previsualización y generación de escala. |
| JOB-SUE-19 | `sue:recordatorios-firma` | Diario 09:00 | P | `integration` | Recibos pendientes de firma (PRM-SUE-024/049). |
| JOB-SUE-20 | `sue:proyeccion-costo` | Mensual y a pedido | P+D | `batch` | Proyección presupuestaria (AGR-028). |
| JOB-SUE-21 | `sue:purgar-simulaciones` | Semanal | P | `maintenance` | Elimina simulaciones vencidas (PRM-SUE-050); no toca liquidaciones reales. |
| JOB-SUE-22 | `sue:importar-novedades-excel` | A pedido | D | `batch` | ExcelImportWizard de novedades y anticipos. |
| JOB-SUE-23 | `sue:paralelo-comparar` | A pedido | D | `batch` | Comparativo ProCoop / GoodApps. |

**Módulo M17** (12 jobs; fuente: anexo M17 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-INS-01 | `ins:registrar-capital-lote` | `fac.batch.issued` | E | `batch` | — |
| JOB-INS-02 | `ins:revisar-capital` | Manual / nocturno | P+D | `batch` | — |
| JOB-INS-03 | `ins:generar-padron` | API-INS-046 | E | `batch` | — |
| JOB-INS-04 | `ins:emitir-libro-asociados` | API-INS-011 | E | `export` | — |
| JOB-INS-05 | `ins:exportar-inaes` | API-INS-057 | E | `export` | — |
| JOB-INS-06 | `ins:calcular-distribucion-excedentes` | API-INS-033 | E | `batch` | — |
| JOB-INS-07 | `ins:ejecutar-distribucion` | API-INS-034 | E | `batch` | — |
| JOB-INS-08 | `ins:emitir-credenciales-masivas` | API-INS-059 | E | `batch` | — |
| JOB-INS-09 | `ins:alertas-institucionales` | Cron diario 06:00 (America/Argentina/Cordoba) | P | `notifications` | — |
| JOB-INS-10 | `ins:liquidar-honorarios` | Cron mensual / API-INS-055 | P | `batch` | — |
| JOB-INS-11 | `ins:procesar-cola-rescates` | `con.fiscalYear.closed` / manual | P+E+D | `batch` | — |
| JOB-INS-12 | `ins:conciliar-capital-contable` | Cron diario / manual | P+D | `batch` | — |

**Módulo M18** (11 jobs; fuente: anexo M18 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-SOC-01 | `soc:mayoria-edad` | Cron diario 05:00 (America/Argentina/Cordoba) | P | `batch` | — |
| JOB-SOC-02 | `soc:revision-condiciones` | Manual / mensual | P+D | `batch` | — |
| JOB-SOC-03 | `soc:vencimiento-subsidios` | Cron diario | P | `batch` | — |
| JOB-SOC-04 | `soc:vencer-reservas` | Cron horario | P | `batch` | — |
| JOB-SOC-05 | `soc:actualizar-precios-vivienda` | API-SOC-034 tras aprobación | E | `batch` | — |
| JOB-SOC-06 | `soc:vencimientos-flota` | Cron diario | P | `batch` | — |
| JOB-SOC-07 | `soc:mantenimiento-preventivo` | Cron diario | P | `batch` | — |
| JOB-SOC-08 | `soc:ingestar-gps` | Cada PRM-SOC-051 minutos / webhook | P | `integration` | — |
| JOB-SOC-09 | `soc:resumir-recorridos` | Cron nocturno | P | `batch` | — |
| JOB-SOC-10 | `soc:vencimiento-prestamos` | Cron diario | P | `batch` | — |
| JOB-SOC-11 | `soc:costo-convenios` | Cron mensual | P | `batch` | — |

**Módulo M19** (12 jobs; fuente: anexo M19 §9/§12)

| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |
|---|---|---|---|---|---|
| JOB-POR-01 | `por:vencer-borradores` | Diario 03:00 | P | `maintenance` | Avisa 3 días antes y purga borradores vencidos y sus adjuntos |
| JOB-POR-02 | `por:vencer-accesos` | Cada hora | P | `batch` | Pasa a `vencido` accesos e invitaciones vencidos; emite eventos |
| JOB-POR-03 | `por:identificar-bajas-publicas` | Al recibir + cada 15 min | P+E | `batch` | Intenta identificar contratos y crear casos M09 |
| JOB-POR-04 | `por:controlar-plazos-baja-publica` | Cada 15 min | P | `notifications` | Alerta código sin entregar a 20 h, constancia a 60 h; reintenta envío por canal alternativo |
| JOB-POR-05 | `por:importar-usuarios-cooponline` | A demanda | D | `batch` | Valida e importa volcado |
| JOB-POR-06 | `por:invitar-usuarios-migrados` | A demanda, en tandas de 500/hora | D | `notifications` | Envía invitaciones |
| JOB-POR-07 | `por:publicar-landing-programada` | Cada minuto | P | `batch` | Publica versiones `programada` vencidas |
| JOB-POR-08 | `por:purgar-intentos-vinculacion` | TTL Mongo | E | `maintenance` | — |
| JOB-POR-09 | `por:metricas-portal` | Diario 04:00 | P | `export` | Calcula indicadores del §15 para T10 |
| JOB-POR-10 | `por:vencer-banners` | Cada hora | P | `batch` | Pasa banners a `vencido` |
| JOB-POR-11 | `por:heartbeat-totems` | Cada minuto | P | `integration` | Marca `fueraDeServicio` sin heartbeat 5 min y alerta |
| JOB-POR-12 | `por:recordar-acciones-pendientes` | Diario 10:00 | P | `integration` | Recordatorios de trámites observados, conformidades sin firmar y recibos sin firmar |

