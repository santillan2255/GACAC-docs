﻿import re,glob
for pat,rx in [('T01-*',r'[Ss]ucursal|branch|legalEntit|EMPRESAS|brandingRef|tenantParameters|configPackages|masterTables|pointsOfSale|PA-PLA-14|tenantProfile|featureFlags|supportAccessGrants|retentionPolicies|legalHolds|DFA §3[0-4]'),('T02-*',r'branches|pointsOfSale|EMPRESAS|PA-PER-01|vincula|DFA §3[0-4]'),('M14-*',r'RN-09 §14|bankAccountId|fileId|branches'),('T08-*',r'DFA §3[0-4]'),('T04-*',r'DFA §3[0-4]|branchId|EMPRESAS')]:
    f=glob.glob('anexos/'+pat)[0]
    for i,l in enumerate(open(f,encoding='utf-8').read().split('\n'),1):
        for m in re.finditer(rx,l):
            print(pat[:3],i,'|',l[max(0,m.start()-120):m.end()+120].replace('\n',' ')); break
