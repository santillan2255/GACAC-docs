﻿# Criterio 4: cada ID con código de módulo (RF-XXX-nnn, RN-, RNF-, PRM-, API-, EVT-, JOB-, PA-, CTR-, PAN-, ESC-)
# citado en la especificación debe estar definido en el anexo dueño de ese código. Solo lectura.
import re, collections, pathlib

BASE = pathlib.Path(__file__).resolve().parent.parent
OUT = BASE / '_trabajo' / 'revision-ids-colgantes.txt'
CODES = {'M01':'PER','M02':'CAT','M03':'MED','M04':'TAR','M05':'FAC','M06':'FIS','M07':'COB','M08':'MOR',
         'M09':'CRM','M10':'TEC','M11':'VEN','M12':'CMP','M13':'STK','M14':'TES','M15':'CON','M16':'SUE',
         'M17':'INS','M18':'SOC','M19':'POR','T01':'PLA','T02':'IAM','T03':'UXD','T04':'CFG','T04b':'CFG',
         'T05':'DAT','T06':'INT','T07':'MIG','T08':'NFR','T09':'COM','T10':'BIA','T11':'WFL','T12':'SRV'}
PREF = r'(?:RNF|RF|RN|PRM|API|EVT|JOB|PA|CTR|PAN|ESC)'
CIT = re.compile(r'(?<![A-Za-z0-9-])(' + PREF + r')-([A-Z]{3})(-P\d)?-(\d+)(?![\d.])')
DEF = re.compile(r'^(?:\|\s*[*`]*|#{2,6}\s+\**)(' + PREF + r')-([A-Z]{3})(-P\d)?-(\d+)[*`]*(?:\s|\||$|—|:)')

def annex(rel):
    m = re.match(r'anexos/(T04b|[MT]\d\d)-', rel)
    return m.group(1) if m else None

texts = {}
for p in sorted(BASE.rglob('*.md')):
    rel = p.relative_to(BASE).as_posix()
    if rel.startswith('_trabajo/') or rel.startswith('04-'):
        continue
    texts[rel] = p.read_text(encoding='utf-8-sig').splitlines()

defined = collections.defaultdict(set)   # code -> set of ids defined in owner annex
for rel, lines in texts.items():
    a = annex(rel)
    if not a:
        continue
    for line in lines:
        m = DEF.match(line)
        if m and CODES.get(a) == m.group(2):
            defined[m.group(2)].add(f'{m.group(1)}-{m.group(2)}{m.group(3) or ""}-{int(m.group(4))}')
    # PRM-XXX también se define en T04b (columna de ID) y en tablas de parámetros con ID en primera celda
    if a == 'T04b':
        for line in lines:
            for m in CIT.finditer(line):
                if m.group(1) == 'PRM':
                    defined[m.group(2)].add(f'PRM-{m.group(2)}{m.group(3) or ""}-{int(m.group(4))}')

missing = collections.defaultdict(list)
for rel, lines in texts.items():
    for i, line in enumerate(lines, 1):
        for m in CIT.finditer(line):
            code = m.group(2)
            if code not in CODES.values() or code == 'SRV':
                continue
            idn = f'{m.group(1)}-{code}{m.group(3) or ""}-{int(m.group(4))}'
            if idn not in defined[code]:
                missing[idn].append(f'{rel}:{i}')

with OUT.open('w', encoding='utf-8', newline='\n') as f:
    f.write(f'IDs citados sin definición en su anexo dueño: {len(missing)}\n')
    for k in sorted(missing):
        v = missing[k]
        f.write(f'{k} ({len(v)}): {"; ".join(v[:6])}{" …" if len(v) > 6 else ""}\n')
print(len(missing))
