﻿P='anexos/T02-IAM-identidad-roles-auditoria.md'
raw=open(P,'rb').read(); assert not raw.startswith(b'\xef\xbb\xbf') and b'\r\n' not in raw
t=raw.decode('utf-8')
assert '`fis.reportes.exportar`' not in t
a='| `fis.rendiciones.generar` | Rendiciones | — | T-FAC, T-CON | tenant | API-FIS-71, PAN-FIS-34 |\n'
assert t.count(a)==1
t=t.replace(a,a+'| `fis.reportes.exportar` | Exportar reportes fiscales; única para todos los reportes, además de la `fis.<recurso>.ver` del dominio de cada reporte (PA-FIS-19, Asumida DEC-072; antes `fis.*.exportar` en M06) | S X | T-CON, T-GER, T-SIN (Auditor) | tenant | API-FIS-80, M06 §4 |\n')
b='| fis | `fis.*.ver` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M06 | API-FIS-80, PAN-FIS-40 |'
assert t.count(b)==1
t=t.replace(b,'| fis | `fis.*.ver` | — (comodín de visibilidad que se mantiene por AL-08 de T03; la exportación de API-FIS-80 usa `fis.reportes.exportar`, PA-FIS-19) | Comodín: no es una capability asignable | M06 | API-FIS-80, PAN-FIS-40 |')
open(P,'wb').write(t.encode('utf-8')); print('OK')
