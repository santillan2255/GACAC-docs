﻿from repl import *
apply('T01', [
 ('`iam.user.mfaEnabled`, `iam.user.disabled`, `uxd.branding.published`, `cfg.package.published`, `tar.tariffVersion.published`, `fis.credential.verified`, `int.credential.revoked`, `int.connector.healthChanged`, `int.webhook.verified`,',
  '`iam.mfa.enrolled` (EVT-IAM-08), `iam.membership.suspended` / `.revoked` (EVT-IAM-03), `uxd.branding.published` (EVT-UXD-01), `cfg.configVersion.published` (EVT-CFG-05), `tar.schedule.published` (EVT-TAR-004), `fis.credential.verified`, `int.credential.expiring` / `.rotated` (EVT-INT-05), `int.circuit.opened` / `.closed` (EVT-INT-04), `int.connection.activated` (EVT-INT-01),', 2),
 ('`int.edgeAgent.heartbeatLost`,', '`int.agent.offline` (EVT-INT-22),'),
])
apply('T02', [
 ('| `pla.license.changed` / `pla.module.activationChanged` | T01 |', '| `pla.license.updated` (EVT-PLA-08) / `pla.capability.activated` / `.deactivated` (EVT-PLA-06/07) | T01 |'),
 ('| `cfg.config.published` (claves `iam.*`) | T04 |', '| `cfg.configVersion.published` (EVT-CFG-05; claves `iam.*`) | T04 |'),
])
apply('T03', [
 ('| `pla.tenant.licenseChanged` / `pla.tenant.capabilityToggled` | T01 |', '| `pla.license.updated` (EVT-PLA-08) / `pla.capability.activated` / `.deactivated` (EVT-PLA-06/07) | T01 |'),
 ('| `iam.role.updated`, `iam.user.rolesChanged`, `iam.screenProfile.updated` | T02 |', '| `iam.role.changed` / `iam.profile.changed` (EVT-IAM-05), `iam.role.assigned` / `.unassigned` (EVT-IAM-04) | T02 |'),
 ('| `cfg.branch.created` / `cfg.branch.updated` | T04 |', '| `pla.branch.created` / `.updated` (EVT-PLA-21) | T01 |'),
 ('| `cfg.organization.updated` | T04 |', '| `pla.tenantProfile.updated` (EVT-PLA-22) | T01 |'),
])
apply('T04', [
 ('| `pla.tenant.moduleActivated` / `.moduleDeactivated` | T01 |', '| `pla.capability.activated` / `.deactivated` (EVT-PLA-06/07) | T01 |'),
 ('| `int.secret.updated` / `.expiring` | T06 |', '| `int.credential.rotated` / `.expiring` (EVT-INT-05) | T06 |'),
 ('| `cat.serviceCopy.prepared` | M02 |', '| `cat.serviceCopy.prepared` (EVT-CAT-26) | M02 |'),
 ('| `mig.legacyDump.ready` | T07 |', '| `mig.snapshot.ready` (EVT-MIG-01) | T07 |'),
])
apply('T06', [
 ('`fac.batch.approved` y `fac.invoice.issued` (M05 → CAE/CAEA)', '`fac.billingRun.approved` (EVT-FAC-03) y `fac.invoice.issued` (EVT-FAC-07) (M05 → CAE/CAEA)'),
 ('`cob.refund.approved` (M07)', '`cob.refund.approved` (EVT-COB-27) (M07)'),
 ('`mor.cut-order.approved` / `mor.reconnection-order.approved` (M08 → comando remoto)', '`mor.interruption.approved` (EVT-MOR-12; corte o reconexión) (M08 → comando remoto)'),
 ('`tec.provisioning.requested` (M10)', '`tec.provisioning.requested` (EVT-TEC-33) (M10)'),
 ('`crm.queue-ticket.called` (M09 → turnero)', '`crm.queueTicket.called` (EVT-CRM-20) (M09 → turnero)'),
])
apply('T07', [
 ('| `cob.payment.received` con clave no resuelta |', '| `cob.payment.confirmed` (EVT-COB-04) con clave no resuelta |'),
 ('| `fac.batch.simulated` |', '| `fac.billingRun.prebilled` (EVT-FAC-02) |'),
])
apply('T08', [
 ('**Eventos consumidos:** `iam.auth.loginFailed`, `iam.authz.crossTenantDenied`, `iam.role.assigned`, `iam.support.accessGranted` (T02, alertas de seguridad);', '**Eventos consumidos:** `iam.login.failed` (EVT-IAM-07), `iam.securityAlert.raised` (EVT-IAM-14; incluye accesos entre tenants denegados), `iam.role.assigned` (EVT-IAM-04), `iam.supportAccess.granted` (EVT-IAM-11) (T02, alertas de seguridad);'),
])
