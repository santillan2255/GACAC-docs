"""Recuento de RF y RNF por ola y por prompt del plan de olas (03-plan-de-olas-y-prompts.md).

Solo lectura. Lee las tablas de RF y RNF de los anexos y la linea IMPLEMENTAR de cada prompt.
Reglas:
- Un ID cuenta en el prompt cuya linea IMPLEMENTAR lo cita (texto entre parentesis o corchetes es aclaracion).
- Las citas precedidas por "extension" / "extensión" / "parte Ox de" dentro de IMPLEMENTAR no cuentan
  (la linea EXTENSIONES tampoco cuenta).
Salida: JSON en _trabajo/plan_recuento.json y resumen por consola.
"""
import os, re, sys, json, glob, collections

sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo')
from lib_espec import leer_rf, expandir_ids, ANEXO_COD, archivos_anexo, celdas, limpiar_md, quitar_acentos  # noqa

ESPEC = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
PLAN = os.path.join(ESPEC, '03-plan-de-olas-y-prompts.md')
OLAS = ['O%d' % i for i in range(12)]


def olas_celda(o):
    o = re.sub(r'\(?antes O\d+[^);]*\)?', '', o or '')
    return ['O' + x for x in re.findall(r'\bO(\d{1,2})\b', o)]


def ola_inicio(o):
    os_ = olas_celda(o)
    return min(os_, key=lambda x: int(x[1:])) if os_ else ''


def leer_rnf():
    out = {}
    for f in glob.glob(os.path.join(ESPEC, 'anexos', '*.md')):
        L = open(f, encoding='utf-8-sig').read().split('\n')
        cab = None
        for i, l in enumerate(L):
            if l.startswith('|') and i + 1 < len(L) and re.match(r'^\|\s*-{3}', L[i + 1]):
                cab = [quitar_acentos(c).lower() for c in celdas(l)]
                continue
            m = re.match(r'^\|\s*\**(RNF-[A-Z]+-\d{3})\**\s*\|', l)
            if m and m.group(1) not in out:
                c = celdas(l)
                ola = ''
                if cab and 'ola' in cab:
                    k = cab.index('ola')
                    ola = limpiar_md(c[k]) if k < len(c) else ''
                out[m.group(1)] = {'ola': ola, 'archivo': os.path.basename(f), 'linea': i + 1}
    return out


def leer_prompts():
    L = open(PLAN, encoding='utf-8-sig').read().split('\n')
    prompts, act = [], None
    for i, l in enumerate(L):
        m = re.match(r'^#### (PRO-(O\d+)-(\d+)) — (.*)$', l)
        if m:
            act = {'id': m.group(1), 'ola': m.group(2), 'titulo': m.group(4), 'texto': ''}
            prompts.append(act)
            continue
        if act is not None:
            if re.match(r'^#{2,4} ', l):
                act = None
                continue
            act['texto'] += l + '\n'
    tabla = {}
    for l in L:
        m = re.match(r'^\| (PRO-O\d+-\d+) \| [^|]+ \| (\d+)', l)
        if m:
            tabla[m.group(1)] = int(m.group(2))
    for p in prompts:
        m = re.search(r'^IMPLEMENTAR:(.*)$', p['texto'], re.M)
        imp = m.group(1) if m else ''
        limpio = imp
        for _ in range(3):
            limpio = re.sub(r'\([^()]*\)', '', limpio)
        limpio = re.sub(r'\[[^\]]*\]', '', limpio)
        # citas de extension: "extensión [O5] de RF-..." hasta el siguiente ';'
        ext_txt = ' '.join(re.findall(r'(?:extensi[oó]n|parte O\d+ de)[^;]*', limpio, re.I))
        nuevo_txt = re.sub(r'(?:extensi[oó]n|parte O\d+ de)[^;]*', '', limpio, flags=re.I)
        p['rf'] = expandir_ids(nuevo_txt, 'RF')
        p['rnf'] = expandir_ids(nuevo_txt, 'RNF')
        me = re.search(r'^EXTENSIONES[^:]*:(.*)$', p['texto'], re.M)
        p['ext'] = expandir_ids(ext_txt + ' ' + (me.group(1) if me else ''), 'RF')
        p['tabla'] = tabla.get(p['id'])
        del p['texto']
    return prompts


def main():
    rf = {}
    for a, c in ANEXO_COD:
        for r in leer_rf(a):
            r['anexo'] = a + ' ' + c
            rf[r['id']] = r
    rnf = leer_rnf()
    prompts = leer_prompts()
    asign = collections.defaultdict(list)
    asign_rnf = collections.defaultdict(list)
    for p in prompts:
        for r in p['rf']:
            asign[r].append(p['id'])
        for r in p['rnf']:
            asign_rnf[r].append(p['id'])
    pola = {p['id']: p['ola'] for p in prompts}
    res = {'prompts': [], 'ola': {}, 'matriz': {}, 'rnf_matriz': {}}
    for p in prompts:
        n = len([r for r in p['rf'] if r in rf])
        res['prompts'].append({'id': p['id'], 'ola': p['ola'], 'tabla': p['tabla'], 'rf': n,
                               'rnf': len([r for r in p['rnf'] if r in rnf]),
                               'inexistentes': [r for r in p['rf'] + p['rnf'] if r not in rf and r not in rnf],
                               'ext': p['ext']})
    for o in OLAS:
        ps = [x for x in res['prompts'] if x['ola'] == o]
        res['ola'][o] = {'prompts': len(ps), 'rf': sum(x['rf'] for x in ps), 'rnf': sum(x['rnf'] for x in ps)}
    mat = collections.defaultdict(collections.Counter)
    for r, ps in asign.items():
        if r in rf:
            mat[rf[r]['anexo']][pola[ps[0]]] += 1
    res['matriz'] = {k: dict(v) for k, v in mat.items()}
    res['rf_anexo'] = dict(collections.Counter(x['anexo'] for x in rf.values()))
    rm = collections.defaultdict(collections.Counter)
    for r, ps in asign_rnf.items():
        if r in rnf:
            rm[rnf[r]['archivo'][:3]][pola[ps[0]]] += 1
    res['rnf_matriz'] = {k: dict(v) for k, v in rm.items()}
    res['rnf_anexo'] = dict(collections.Counter(x['archivo'][:3] for x in rnf.values()))
    res['faltan_rf'] = sorted(r for r in rf if r not in asign)
    res['faltan_rnf'] = sorted(r for r in rnf if r not in asign_rnf)
    res['dup_rf'] = {r: ps for r, ps in asign.items() if len(set(ps)) > 1}
    res['dup_rnf'] = {r: ps for r, ps in asign_rnf.items() if len(set(ps)) > 1}
    sin_ola, distinta = [], []
    for r, x in sorted(rf.items()):
        os_ = olas_celda(x['ola'])
        if not os_:
            sin_ola.append((r, x['ola'], asign.get(r)))
        elif r in asign:
            po = pola[asign[r][0]]
            if po != os_[0]:
                distinta.append((r, x['ola'], asign[r][0]))
    res['sin_ola'] = sin_ola
    res['distinta'] = distinta
    res['rnf_sin_ola'] = [(r, x['ola'], asign_rnf.get(r)) for r, x in sorted(rnf.items()) if not olas_celda(x['ola'])]
    res['rnf_distinta'] = [(r, x['ola'], asign_rnf[r][0]) for r, x in sorted(rnf.items())
                           if olas_celda(x['ola']) and r in asign_rnf and pola[asign_rnf[r][0]] != olas_celda(x['ola'])[0]]
    res['multi'] = [(r, x['ola'], asign.get(r)) for r, x in sorted(rf.items()) if len(set(olas_celda(x['ola']))) > 1]
    res['inicio_distinto'] = [(r, x['ola'], asign[r][0]) for r, x in sorted(rf.items())
                              if ola_inicio(x['ola']) and r in asign and pola[asign[r][0]] != ola_inicio(x['ola'])]
    print('inicio_distinto (regla 0.1: ola mas temprana de la celda)', res['inicio_distinto'])
    json.dump(res, open(os.path.join(ESPEC, '_trabajo', 'plan_recuento.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('RF anexos', len(rf), 'asignados', len(asign), 'RNF', len(rnf), 'asignados', len(asign_rnf))
    for o in OLAS:
        print(o, res['ola'][o])
    print('total', sum(v['rf'] for v in res['ola'].values()), sum(v['rnf'] for v in res['ola'].values()))
    print('dif tabla', [(x['id'], x['tabla'], x['rf']) for x in res['prompts'] if x['tabla'] is not None and x['tabla'] != x['rf'] and not x['id'].endswith(('-21',)) and x['rf']])
    print('inexistentes', [(x['id'], x['inexistentes']) for x in res['prompts'] if x['inexistentes']])
    print('faltan', res['faltan_rf'], res['faltan_rnf'])
    print('dup', res['dup_rf'], res['dup_rnf'])
    print('sin_ola', res['sin_ola'])
    print('distinta', res['distinta'])
    print('rnf_sin_ola', res['rnf_sin_ola'])
    print('rnf_distinta', res['rnf_distinta'])
    print('multi', len(res['multi']))


if __name__ == '__main__':
    main()
