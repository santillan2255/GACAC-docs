"""Correcciones del 05-11-2026 a la maestra: solo §9.2 (tabbar del socio) y párrafo de totales de §15."""
import os

ESPEC = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
F = os.path.join(ESPEC, '00-ESPECIFICACION-MAESTRA.md')
raw = open(F, 'rb').read()
bom = raw.startswith(b'\xef\xbb\xbf')
T = raw.decode('utf-8-sig')


def rep(old, new):
    global T
    assert T.count(old) == 1, old[:100]
    T = T.replace(old, new)


rep('### 9.2 PWA socio (tabbar)\r\n\r\n'
    '1. **Inicio**: saldo, próximo vencimiento, alertas y novedades.\r\n'
    '2. **Cuentas y servicios**.\r\n'
    '3. **Pagar** (FAB).\r\n'
    '4. **Gestiones**: reclamos, solicitudes y turnos.\r\n'
    '5. **Comunidad**.\r\n'
    '6. **Perfil**.\r\n\r\n'
    'El detalle está en M19 y T03.\r\n',
    '### 9.2 PWA socio (tabbar)\r\n\r\n'
    'Tabbar de cinco posiciones con botón flotante (FAB) central, según T03 §10.1.4, RF-UXD-066 y CTR-UXD-12 (mapa del sitio `SM-PWS-001`, `002`, `017` y `026` de T03 §10.8):\r\n\r\n'
    '1. **Inicio** (`/inicio`): saldo, próximo vencimiento, alertas y novedades.\r\n'
    '2. **Cuentas y servicios** (`/servicios`).\r\n'
    '3. **FAB "+"** central: por defecto **Pagar** en Inicio y Facturas; su acción cambia por pantalla (`useCreateAction`): "Nueva gestión" en Gestiones, "Contratar" en Servicios, "Vincular cuenta" en Cuentas.\r\n'
    '4. **Gestiones** (`/gestiones`): reclamos, solicitudes y turnos.\r\n'
    '5. **Comunidad** (`/comunidad`).\r\n\r\n'
    '**Perfil** no ocupa una posición de la tabbar: se abre desde el avatar de la topbar. El tenant puede reemplazar Comunidad (slot 4 de T03) por configuración (RF-UXD-177), sin otorgar permisos.\r\n\r\n'
    '*Reemplazado (corrección 05-11-2026):* la lista anterior enumeraba seis destinos (Inicio, Cuentas y servicios, Pagar como FAB, Gestiones, Comunidad y Perfil) para cinco posiciones; se alinea a T03, dueño del mapa del sitio (§9). La tabbar que lista M19 §10 ("Inicio · Servicios · (+) · Facturas · Perfil") no coincide con T03 y la debe alinear el dueño de M19.\r\n\r\n'
    'El detalle está en M19 y T03.\r\n')

rep('Reparto de RF por ola: O0 305, O1 458, O2 613, O3 319, O4 424, O5 468, O6 244, O7 274, O8 462, O9 163, O10 383, O11 90.',
    'Reparto de RF por ola: O0 305, O1 458, O2 613, O3 319, O4 424, O5 469, O6 244, O7 274, O8 462, O9 163, O10 383, O11 89.')
rep('*Reemplazado (versión 1.0 del plan): 4.120 RF, con O0 299, O1 457, O2 607, O3 315, O4 419, O5 463, O6 241, O7 256, O8 454, O9 161, O10 360, O11 88.*',
    '*Reemplazado (versión 1.0 del plan): 4.120 RF, con O0 299, O1 457, O2 607, O3 315, O4 419, O5 463, O6 241, O7 256, O8 454, O9 161, O10 360, O11 88.* '
    '*Reemplazado (corrección 05-11-2026 del plan, §21.5): O5 468 y O11 90; RF-CON-160 empieza en O5 (saldos de apertura) y su migración completa queda como extensión en O11. El total (4.203 RF y 292 RNF) y los prompts por ola no cambian.*')

open(F, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + T.encode('utf-8'))
print('ok')
