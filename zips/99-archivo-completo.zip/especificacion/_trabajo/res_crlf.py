import sys

BASE = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\\'


def editar(nombre, reps):
    path = BASE + nombre
    raw = open(path, 'rb').read()
    bom = raw.startswith(b'\xef\xbb\xbf')
    t = raw[3:].decode('utf-8') if bom else raw.decode('utf-8')
    crlf = '\r\n' in t
    t = t.replace('\r\n', '\n')
    for a, b in reps:
        assert t.count(a) == 1, (nombre, t.count(a), a[:80])
        t = t.replace(a, b)
    if crlf:
        t = t.replace('\n', '\r\n')
    out = t.encode('utf-8')
    open(path, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + out)
    print(nombre, 'BOM' if bom else 'sin BOM', 'CRLF' if crlf else 'LF', len(reps))


if __name__ == '__main__':
    editar('03-plan-de-olas-y-prompts.md', [(
        'siteMapGroups declarativo con estructura de clusters del maestro §9 (vacío de ítems de dominio; cada ola agrega los suyos, RF-UXD-171).',
        'siteMapGroups declarativo con estructura de clusters del maestro §9 (vacío de ítems de dominio; cada ola agrega los suyos, RF-UXD-171); pantallas PAN-UXD-15 (asistente IA de la PWA, RF-UXD-064, oculta por el flag `pwa.asistente` hasta O11), PAN-UXD-16 (directorio del empleado, RF-UXD-063, `iam.directorio.ver`; datos de M16 desde O2) y PAN-UXD-17 (alertas activas del admin, RF-UXD-055) (agregado en el cierre de residuales del 05-11-2026; antes no figuraban en ningún prompt).')])
    editar('00-ESPECIFICACION-MAESTRA.md', [(
        'La tabbar que lista M19 §10 ("Inicio · Servicios · (+) · Facturas · Perfil") no coincide con T03 y la debe alinear el dueño de M19.',
        'La tabbar que lista M19 §10 ("Inicio · Servicios · (+) · Facturas · Perfil") no coincidía con T03; *resuelto (cierre de residuales 05-11-2026):* M19 la alineó con RF-POR-180 (Inicio · Cuentas y servicios · (+) · Gestiones · Comunidad, con PAN-POR-105 `/app/comunidad`; PA-POR-20). Antes: "no coincide con T03 y la debe alinear el dueño de M19". El rótulo corto de la posición 2 es "Cuentas" (RN-UXD-006, máximo 12 caracteres; T03 §10.1.4).')])
