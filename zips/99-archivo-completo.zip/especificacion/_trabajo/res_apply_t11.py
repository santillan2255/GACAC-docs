import sys, io, glob, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
from res_evt_ren import REN
F = glob.glob(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T11-*")[0]
raw = open(F, "rb").read()
assert raw.startswith(b"\xef\xbb\xbf")
t = raw[3:].decode("utf-8")
assert "\r\n" not in t
cnt = {}

def rep(old, new, k, n=1):
    global t
    c = t.count(old)
    assert c == n, (k, old[:100], c)
    t = t.replace(old, new)
    cnt[k] = cnt.get(k, 0) + 1

PA = "PA-WFL-23, Asumida DEC-072"

# ===================== Cat. 6: catálogo §12.3 =====================
CAT = [
("| EVT-INS-08 | `ins.capital.movement.recorded` |", "| EVT-INS-08 | `ins.capitalMovement.recorded` (antes `ins.capital.movement.recorded`) |"),
("| EVT-INS-09 | `ins.capital.movement.reversed` |", "| EVT-INS-09 | `ins.capitalMovement.reversed` (antes `ins.capital.movement.reversed`) |"),
("| EVT-INS-10 | `ins.capital.transfer.executed` |", "| EVT-INS-10 | `ins.capitalTransfer.executed` (antes `ins.capital.transfer.executed`) |"),
("| EVT-INS-11 | `ins.capital.refund.approved` |", "| EVT-INS-11 | `ins.capitalRefund.approved` (antes `ins.capital.refund.approved`) |"),
("| EVT-INS-12 | `ins.capital.refund.paid` |", "| EVT-INS-12 | `ins.capitalRefund.paid` (antes `ins.capital.refund.paid`) |"),
("| EVT-INS-13 | `ins.surplus.distribution.approved` / `.executed` |", "| EVT-INS-13 | `ins.surplusDistribution.approved` / `.executed` (antes `ins.surplus.distribution.approved` / `.executed`) |"),
("| EVT-INS-21 | `ins.inaes.report.submitted` |", "| EVT-INS-21 | `ins.inaesReport.submitted` (antes `ins.inaes.report.submitted`) |"),
("| EVT-INT-01 | `int.connection.activated` / `.suspended` / `.mode-changed` [`modeChanged`] |",
 "| EVT-INT-01 | `int.connection.activated` / `.suspended` / `.modeChanged` (antes `.mode-changed` [`modeChanged`]) |"),
("/ `.uncertain` / `.manually-resolved` [`manuallyResolved`] / `.cancelled` |",
 "/ `.uncertain` / `.manuallyResolved` (antes `.manually-resolved` [`manuallyResolved`]) / `.cancelled` |"),
("| EVT-INT-06 | `int.arca.cae-obtained` [`caeObtained`] / `cae-rejected` / `caea-obtained` / `caea-informed` / `params-synced` |",
 "| EVT-INT-06 | `int.arca.caeObtained` / `.caeRejected` / `.caeaObtained` / `.caeaInformed` / `.paramsSynced` (antes `int.arca.cae-obtained` [`caeObtained`] / `cae-rejected` / `caea-obtained` / `caea-informed` / `params-synced`) |"),
("| EVT-INT-07 | `int.padron.persona-retrieved` [`personaRetrieved`] |",
 "| EVT-INT-07 | `int.padron.personaRetrieved` (antes `int.padron.persona-retrieved` [`personaRetrieved`]) |"),
("| EVT-INT-08 | `int.payment-intent.created` [`paymentIntent.created`] / `int.payment.confirmed` /",
 "| EVT-INT-08 | `int.paymentIntent.created` (antes `int.payment-intent.created` [`paymentIntent.created`]) / `int.payment.confirmed` /"),
("| EVT-INT-09 | `int.debt-publication.acknowledged` / `.rejected` [`debtPublication.*`] |",
 "| EVT-INT-09 | `int.debtPublication.acknowledged` / `.rejected` (antes `int.debt-publication.acknowledged` / `.rejected` [`debtPublication.*`]) |"),
("| EVT-INT-10 | `int.remittance.line-received` / `.file-applied` |",
 "| EVT-INT-10 | `int.remittance.lineReceived` / `.fileApplied` (antes `int.remittance.line-received` / `.file-applied`) |"),
("| EVT-INT-11 | `int.direct-debit.adhesion-updated` / `.result-received` |",
 "| EVT-INT-11 | `int.directDebit.adhesionUpdated` / `.resultReceived` (antes `int.direct-debit.adhesion-updated` / `.result-received`) |"),
("| EVT-INT-12 | `int.bank.movements-received` / `.balances-received` |",
 "| EVT-INT-12 | `int.bank.movementsReceived` / `.balancesReceived` (antes `int.bank.movements-received` / `.balances-received`) |"),
("| EVT-INT-13 | `int.message.sent` / `.delivered` / `.read` / `.bounced` / `.failed` / `.inbound-received` |",
 "| EVT-INT-13 | `int.message.sent` / `.delivered` / `.read` / `.bounced` / `.failed` / `.inboundReceived` (antes `.inbound-received`) |"),
("| EVT-INT-14 | `int.meter.reading-received` / `.command-result` / `int.prepaid.credit-issued` |",
 "| EVT-INT-14 | `int.meter.readingReceived` / `.commandResult` / `int.prepaid.creditIssued` (antes `int.meter.reading-received` / `.command-result` / `int.prepaid.credit-issued`) |"),
("| EVT-INT-15 | `int.network.provisioning-result` |", "| EVT-INT-15 | `int.network.provisioningResult` (antes `int.network.provisioning-result`) |"),
("| EVT-INT-16 | `int.cdr.batch-received` |", "| EVT-INT-16 | `int.cdr.batchReceived` (antes `int.cdr.batch-received`) |"),
("| EVT-INT-17 | `int.fleet.positions-received` |", "| EVT-INT-17 | `int.fleet.positionsReceived` (antes `int.fleet.positions-received`) |"),
("| EVT-INT-20 | `int.reconciliation.closed` / `.differences-found` |", "| EVT-INT-20 | `int.reconciliation.closed` / `.differencesFound` (antes `.differences-found`) |"),
("| EVT-INT-22 | `int.agent.online` / `.offline` / `.command-result` |", "| EVT-INT-22 | `int.agent.online` / `.offline` / `.commandResult` (antes `.command-result`) |"),
("| EVT-INT-23 | `int.ai.completion-ready` |", "| EVT-INT-23 | `int.ai.completionReady` (antes `int.ai.completion-ready`) |"),
]
for o, nw in CAT:
    rep(o, nw, "cat6-catalogo")

# otras menciones en T11
rep("| `int.provisioning.succeeded` / `.failed` | M07, M08, M09, T04 | `int.network.provisioning-result` (EVT-INT-15) | Alias |",
    "| `int.provisioning.succeeded` / `.failed` | M07, M08, M09, T04 | `int.network.provisioningResult` (EVT-INT-15; antes `int.network.provisioning-result`) | Alias |", "cat6-menciones")
rep("| `int.operation.succeeded` / `.failed` / `.uncertain` / `.manually-resolved` | T06 |",
    "| `int.operation.succeeded` / `.failed` / `.uncertain` / `.manuallyResolved` (antes `.manually-resolved`) | T06 |", "cat6-menciones")
rep("Canónico en camelCase; los nombres de T06 quedan como alias durante O0–O2. | Guía §5 |",
    "Canónico en camelCase; los nombres de T06 quedan como alias durante O0–O2. Aplicado el 5-11-2026 en §12.3 (EVT-INT-01, 03, 06 a 17, 20, 22 y 23; también EVT-INS-08 a 13 y 21, que tenían cuatro segmentos) con alias en §12.4 (PA-WFL-23). | Guía §5 |", "cat6-menciones")

# alias nuevos en §12.4
from collections import OrderedDict
USERS = {
 "ins.capital.movement.recorded": "M15, M17 (productor), M19, T12",
 "ins.capital.movement.reversed": "M15, M17 (productor), T12",
 "ins.capital.transfer.executed": "M15, M17 (productor), T12",
 "ins.capital.refund.approved": "M15, M17 (productor), T12",
 "ins.capital.refund.paid": "M15, M17 (productor), T09, T12",
 "ins.surplus.distribution.approved": "M15, M17 (productor)",
 "ins.surplus.distribution.executed": "M15, M17 (productor)",
 "ins.inaes.report.submitted": "M17 (productor)",
 "int.arca.params-synced": "M06, T06 (productor)",
 "int.message.inbound-received": "T06 (productor), T09",
 "int.network.provisioning-result": "M08, T06 (productor), T12",
 "int.cdr.batch-received": "M10, T06 (productor), T12",
 "int.fleet.positions-received": "M18, T06 (productor)",
 "int.ai.completion-ready": "T06 (productor), T09",
}
rows = []
for evt, old, new in REN:
    u = USERS.get(old, "T06 (productor)")
    rows.append("| `%s` | %s | `%s` (%s) | Alias (5-11-2026, %s): renombrado por la convención `<mod>.<agregado>.<hecho>` (INC-06-11; guiones a camelCase, cuatro segmentos a tres). El productor y los consumidores deben adoptar el nombre nuevo |" % (old, u, new, evt, PA))
anchor = "| `com.message.failed` / `.bounced` (sin canal restante) | M05, M08, M09, T02 | `com.communication.allChannelsFailed` (EVT-COM-29) | Alias |"
rep(anchor, anchor + "\n" + "\n".join(rows), "cat6-alias-nuevos")
cnt["cat6-alias-filas"] = len(rows)

# ===================== 24 alias con un solo canónico =====================
RET = [  # (línea exacta col0, canónico elegido)
 ("`fac.invoice.adjusted` (ajuste en contra)", "fac.invoice.adjusted", "fac.creditNote.issued"),
 ("`fac.adjustment.issued` (", None, None),
]
def retire_row(prefix, name, chosen):
    """prefix: comienzo exacto de la fila (incluye '| ' y la celda 0)."""
    global t
    lines = t.split("\n")
    idx = [i for i, l in enumerate(lines) if l.startswith("| " + prefix + " |")]
    assert len(idx) == 1, (prefix, len(idx))
    i = idx[0]
    c = lines[i].split(" | ")
    parts = lines[i].split("|")
    assert len(parts) == 6, (prefix, len(parts))
    col0 = parts[1].strip().replace("`", "")
    obs = parts[4].strip()
    parts[1] = " %s: retirado como alias " % col0
    parts[4] = " Retirado como alias el 5-11-2026 (%s): un alias resuelve a un solo canónico y `%s` queda en `%s`; para este caso el consumidor se suscribe directamente al canónico de esta fila. Antes \"%s\" " % (PA, name, chosen, obs.replace("`", ""))
    lines[i] = "|".join(parts)
    t = "\n".join(lines)
    cnt["alias-retirados"] = cnt.get("alias-retirados", 0) + 1

R = [
 ("`fac.invoice.adjusted` (ajuste en contra)", "fac.invoice.adjusted", "fac.creditNote.issued"),
]
def rows_of(name):
    return [l for l in t.split("\n") if l.startswith("| `" + name + "`")]

CHOICE = OrderedDict([
 ("fac.invoice.adjusted", "fac.creditNote.issued"),
 ("fac.adjustment.issued", "fac.creditNote.issued"),
 ("med.anomaly.detected", "med.point.suspicionRaised"),
 ("cat.contract.updated", "cat.contract.planChanged"),
 ("cat.offer.changed", "cat.tenantService.published"),
 ("tec.workOrder.failed", "tec.visit.failed"),
 ("tec.network.outageDetected", "tec.networkDevice.down"),
 ("col.legalStatus.changed", "mor.collectionCase.opened"),
 ("cli.holder.taxDataChanged", "per.person.updated"),
 ("per.relation.ended", "per.relationship.revoked"),
 ("per.person.fiscalDataChanged", "per.person.updated"),
 ("stk.movement.confirmed", "stk.goods.received"),
 ("stk.serialItem.statusChanged", "stk.equipment.applied"),
 ("ins.membership.changed", "ins.membership.approved"),
 ("pla.module.activationChanged", "pla.capability.activated"),
 ("int.connector.health", "int.circuit.*"),
 ("int.localAgent.statusChanged", "int.agent.online"),
])
ali_ini = t.index("| Nombre usado por el consumidor | Consumidor(es) | Canónico | Observación |")
ali_fin = t.index("Alias de campos de payload (5/11/2026).")
for name, chosen in CHOICE.items():
    lines = t.split("\n")
    base = t[:ali_ini].count("\n")
    fin = t[:ali_fin].count("\n")
    cand = [i for i in range(base, fin) if lines[i].startswith("| `" + name + "`")]
    assert len(cand) >= 2, (name, len(cand))
    keep = [i for i in cand if ("`" + chosen + "`") in lines[i].split("|")[3]]
    assert len(keep) == 1, (name, chosen, len(keep))
    for i in cand:
        if i == keep[0]:
            continue
        parts = lines[i].split("|")
        assert len(parts) == 6, (name, len(parts))
        col0 = parts[1].strip().replace("`", "")
        obs = parts[4].strip()
        parts[1] = " %s, retirado como alias " % col0
        parts[4] = " Retirado como alias el 5-11-2026 (%s): un alias resuelve a un solo canónico y %s queda en `%s`; para este caso el consumidor se suscribe directamente al canónico de esta fila. Antes \"%s\" " % (PA, name, chosen, obs.replace("`", ""))
        lines[i] = "|".join(parts)
        cnt["alias-retirados"] = cnt.get("alias-retirados", 0) + 1
    # anotar la fila conservada
    parts = lines[keep[0]].split("|")
    parts[4] = parts[4].rstrip() + " (5-11-2026, %s: único canónico del alias) " % PA
    lines[keep[0]] = "|".join(parts)
    t = "\n".join(lines)
    cnt["alias-unico"] = cnt.get("alias-unico", 0) + 1

CNC = [
 ("| CNC-WFL-001 | `iam.user.disabled` | T01 | `iam.idp.disabled` | Conciliado: `iam.membership.suspended` / `.revoked` (EVT-IAM-03) |",
  "| CNC-WFL-001 | `iam.user.disabled` | T01 | `iam.idp.disabled` | Conciliado: `iam.membership.suspended` (EVT-IAM-03). Un solo canónico desde el 5-11-2026 (%s); la revocación se consume directamente; antes \"Conciliado: iam.membership.suspended / .revoked (EVT-IAM-03)\" |" % PA),
 ("| CNC-WFL-004 | `int.credential.revoked` | T01 | `int.credential.expiring` o `int.credential.rotated` | Conciliado: `int.credential.expiring` / `.rotated` (EVT-INT-05) |",
  "| CNC-WFL-004 | `int.credential.revoked` | T01 | `int.credential.expiring` o `int.credential.rotated` | Conciliado: `int.credential.rotated` (EVT-INT-05). Un solo canónico desde el 5-11-2026 (%s); antes \"Conciliado: int.credential.expiring / .rotated (EVT-INT-05)\" |" % PA),
 ("| CNC-WFL-005 | `int.connector.healthChanged` | T01 | — | Conciliado: `int.circuit.opened` / `.closed` (EVT-INT-04) |",
  "| CNC-WFL-005 | `int.connector.healthChanged` | T01 | — | Conciliado: `int.circuit.opened` (EVT-INT-04). Un solo canónico desde el 5-11-2026 (%s); el cierre del circuito se consume directamente; antes \"Conciliado: int.circuit.opened / .closed (EVT-INT-04)\" |" % PA),
 ("| CNC-WFL-009 | `pla.tenant.capabilityToggled` | T03 | `pla.tenant.statusChanged` o `pla.tenant.reactivated` | Conciliado: `pla.capability.activated` (EVT-PLA-06), `pla.capability.deactivated` (EVT-PLA-07) |",
  "| CNC-WFL-009 | `pla.tenant.capabilityToggled` | T03 | `pla.tenant.statusChanged` o `pla.tenant.reactivated` | Conciliado: `pla.capability.activated` (EVT-PLA-06). Un solo canónico desde el 5-11-2026 (%s); la desactivación (EVT-PLA-07) se consume directamente; antes \"Conciliado: pla.capability.activated (EVT-PLA-06), pla.capability.deactivated (EVT-PLA-07)\" |" % PA),
 ("| CNC-WFL-049 | `tec.outage.restored` | T09 | `tec.outage.notified` o `tec.outage.finished` | Conciliado: `tec.outage.notified` (EVT-TEC-23), `com.outage.restored` (EVT-COM-25) |",
  "| CNC-WFL-049 | `tec.outage.restored` | T09 | `tec.outage.notified` o `tec.outage.finished` | Conciliado: `tec.outage.finished` (EVT-TEC-23). Un solo canónico desde el 5-11-2026 (%s): el restablecimiento del corte es el fin del corte de M10; antes \"Conciliado: tec.outage.notified (EVT-TEC-23), com.outage.restored (EVT-COM-25)\" |" % PA),
 ("| CNC-WFL-083 | `cob.ledgerEntry.posted` | T10 | — | Conciliado: `cob.obligation.registered` (EVT-COB-01), `cob.payment.confirmed` (EVT-COB-04), `cob.receipt.voided` (EVT-COB-05), `cob.allocation.reversed` (EVT-COB-06) |",
  "| CNC-WFL-083 | `cob.ledgerEntry.posted` | T10 | — | Conciliado: `cob.obligation.registered` (EVT-COB-01). Un solo canónico desde el 5-11-2026 (%s); T10 se suscribe directamente a EVT-COB-04, EVT-COB-05 y EVT-COB-06; antes \"Conciliado: cob.obligation.registered (EVT-COB-01), cob.payment.confirmed (EVT-COB-04), cob.receipt.voided (EVT-COB-05), cob.allocation.reversed (EVT-COB-06)\" |" % PA),
 ("| CNC-WFL-089 | `iam.roleAssignment.changed` | T10 | `iam.role.changed` o `iam.profile.changed` | Conciliado: `iam.role.assigned` (EVT-IAM-04), `iam.role.changed` (EVT-IAM-05) |",
  "| CNC-WFL-089 | `iam.roleAssignment.changed` | T10 | `iam.role.changed` o `iam.profile.changed` | Conciliado: `iam.role.assigned` (EVT-IAM-04). Un solo canónico desde el 5-11-2026 (%s); T10 se suscribe directamente a EVT-IAM-05; antes \"Conciliado: iam.role.assigned (EVT-IAM-04), iam.role.changed (EVT-IAM-05)\" |" % PA),
]
for o, nw in CNC:
    rep(o, nw, "alias-unico-cnc")

rep("Desde el 5-11-2026 cada fila tiene un solo canónico: las filas que agrupaban varios se separaron (el texto entre paréntesis indica qué caso del alias corresponde a cada canónico).",
    "Desde el 5-11-2026 cada fila tiene un solo canónico: las filas que agrupaban varios se separaron (el texto entre paréntesis indica qué caso del alias corresponde a cada canónico). En el cierre de residuales del mismo día (%s) cada alias quedó con un solo canónico: de cada grupo se conserva una fila y las demás figuran como \"retirado como alias\" (el consumidor se suscribe directamente a ese canónico); al final de la tabla se agregan los alias de los eventos renombrados por la convención de nombres (INC-06-11)." % PA, "alias-unico-intro")

# ===================== §12.10 totales =====================
rep("| Filas de conciliación en §12.4 | 168, una por canónico (5-11-2026;",
    "| Filas de conciliación en §12.4 | 203, una por canónico (5-11-2026, residuales: se agregan 35 alias de eventos renombrados por INC-06-11 y 25 filas quedan como \"retirado como alias\" para que cada alias tenga un solo canónico; antes 168. 5-11-2026;", "totales")

# ===================== §12.2 payload propio =====================
rep("| EVT-WFL-040 | `wfl.sequence.thresholdReached` / `.adjusted` | `sequenceId`, `code`,",
    "| EVT-WFL-040 | `wfl.sequence.thresholdReached` / `.adjusted` | `numberingSequenceId` (antes `sequenceId`), `code`,", "cat4")

open(F, "wb").write(b"\xef\xbb\xbf" + t.encode("utf-8"))
print(cnt)
