import sys, io, glob, re, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
F = glob.glob(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T11-*")[0]
t = open(F, "rb").read().decode("utf-8-sig")
ini = t.index("### 12.4 Conciliación")
fin = t.index("Alias de campos de payload")
rows = [l for l in t[ini:fin].split("\n") if l.startswith("| ") and not l.startswith("| Nombre usado") ]
print("filas", len(rows))
ret = [r for r in rows if "retirado como alias" in r.split(" | ")[0]]
print("retiradas", len(ret))
alias = collections.defaultdict(list)
for r in rows:
    c0 = r.split(" | ")[0]
    if "retirado como alias" in c0:
        continue
    for a in re.findall(r"`([a-z]+\.[A-Za-z\-]+(?:\.[A-Za-z\-\*]+)*)`", c0):
        alias[a].append(r.split(" | ")[2][:60])
for a, v in alias.items():
    if len(v) > 1:
        print("DUP", a, v)
