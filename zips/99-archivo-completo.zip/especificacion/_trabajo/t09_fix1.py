# -*- coding: utf-8 -*-
"""Correcciones T09 (parte 1): específicas, capabilities (cat. 1, 8, 9), RF (cat. 6), CU (cat. 10)."""
import re, sys
sys.stdout.reconfigure(encoding='utf-8')
P = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T09-COM-comunidad-comunicaciones.md'
raw = open(P, 'rb').read()
assert not raw.startswith(b'\xef\xbb\xbf') and b'\r\n' not in raw
txt = raw.decode('utf-8')
L = txt.split('\n')


def rep(old, new, cnt=1):
    global L
    t = '\n'.join(L)
    n = t.count(old)
    assert n == cnt, (n, old[:120])
    t = t.replace(old, new)
    L = t.split('\n')


def row_idx(rid):
    idx = [i for i, l in enumerate(L) if l.startswith('| ' + rid + ' |')]
    assert len(idx) == 1, (rid, idx)
    return idx[0]


def cells(line):
    return [x.strip() for x in line.strip()[1:-1].split(' | ')]


def set_cell(rid, col, new, expect=None):
    i = row_idx(rid)
    c = cells(L[i])
    if expect is not None:
        assert c[col] == expect, (rid, c[col])
    c[col] = new
    L[i] = '| ' + ' | '.join(c) + ' |'


# ---------- (b) específicas ----------
rep('sin alternativa → `com.communication.failed` al módulo emisor (que decide, ej. M08 crea tarea “canal alternativo”).',
    'sin alternativa → `com.communication.allChannelsFailed` (EVT-COM-29) al módulo emisor (que decide, ej. M08 crea tarea “canal alternativo”). Antes decía `com.communication.failed`, que es el estado de **un** intento/canal (EVT-COM-27) y no el agotamiento de alternativas.')
rep('y COM devuelve `com.communication.milestoneReached` o `com.communication.failed`. | AGR-024 |',
    'y COM devuelve `com.communication.milestoneReached` (EVT-COM-28) o, si se agotaron los canales, `com.communication.allChannelsFailed` (EVT-COM-29; antes `com.communication.failed`). | AGR-024 |')
rep('3. El resto se enruta a M09 (`crm.message.received`), incluida la carga rápida de reclamos por SMS (V2 2812).',
    '3. El resto se enruta a M09 (`crm.message.received`), incluida la carga rápida de reclamos por SMS, que es funcionalidad de M09 sin parámetro V2 asignado [VERIFICAR en RN-07]. Antes se atribuía a V2 2812; según CTR-COM-21, V2 2812 es el remitente SMS (PRM-COM-P1-003, PRM-COM-025).')
rep('(incluida la carga rápida de reclamos por SMS de ProCoop, V2 2812) se enrutan a M09.',
    '(incluida la carga rápida de reclamos por SMS de ProCoop, sin parámetro V2 asignado [VERIFICAR en RN-07]; antes atribuida a V2 2812, que es el remitente SMS según CTR-COM-21) se enrutan a M09.')
set_cell('RF-COM-156', 2, 'Pedido T09; RN-07 (carga rápida de reclamos por SMS) [VERIFICAR parámetro]; antes “RN-09 2812 (`cargaRapidaReclamosSMS`)”, corregido por CTR-COM-21 (2812 = remitente SMS)')
set_cell('RF-COM-205', 5, 'Adoptado (antes “Reemplazado por RF-COM-205”, autorreferente; CTR-COM-24)')

# ---------- cat. 1: §4 ----------
rep('| Gestor de eventos y beneficios | `com.events.*`, `com.benefits.*`, `com.benefits.validarCanje` | Grant |',
    '| Gestor de eventos y beneficios | `com.events.ver`, `com.events.gestionar`, `com.benefits.ver`, `com.benefits.gestionar`, `com.benefits.validarCanje` (antes `com.events.*`, `com.benefits.*`) | Grant |')
rep('| Sistema (módulos emisores) | Cuenta técnica por módulo con `com.communications.emitir` | Tenant del evento |',
    '| Sistema (módulos emisores y T06) | Cuenta técnica (rol S-SYS) con `com.communications.emit` (antes `com.communications.emitir`; canónica según API-COM-75 y CTR-COM-10), `com.communications.consultar`, `com.audiences.match`, `com.invoiceMessages.resolver`, `com.preferences.consultar`; T06: `com.providerEvents.registrar`, `com.inboundMessages.registrar` | Tenant del evento |')
rep('| Socio / titular / adherente (PWA) | `com.wall.ver`, `com.reactions.crear`, `com.comments.crear` (si habilitado y sin sanción), `com.reports.crear`, `com.surveys.responder`, `com.events.inscribirse`, `com.benefits.canjear`, `com.inbox.ver`, `com.preferences.editar` | Propios; contenido según audiencia |',
    '| Socio / titular / adherente (PWA) | `com.wall.ver`, `com.reactions.crear`, `com.comments.crear` (si habilitado y sin sanción), `com.reports.crear`, `com.sanctions.apelar`, `com.surveys.responder`, `com.events.ver`, `com.events.inscribirse`, `com.benefits.ver`, `com.benefits.canjear`, `com.inbox.ver`, `com.preferences.editar` | Propios; contenido según audiencia |')
rep('| Plataforma (GoodApps) | `pla.notices.publicar`, `pla.messaging.consumo.ver` |',
    '| Administrador del tenant (avisos de plataforma) | `com.platformNotices.ver` | Su tenant |\n| Plataforma (GoodApps) | `pla.notices.publicar`, `pla.messaging.consumo.ver` |')

# ---------- cat. 1/9: API ----------
api = {
    'API-COM-12': ('propio', '`com.comments.crear` (solo el autor; antes “propio”)'),
    'API-COM-15': ('sesión', '`com.wall.ver` (antes “sesión”)'),
    'API-COM-16': ('sesión', '`com.sanctions.apelar` (solo sanciones propias; antes “sesión”)'),
    'API-COM-19': ('según acción', '`com.posts.crear` (submit, duplicate) / `com.posts.aprobar` (approve, reject) / `com.posts.publicar` (schedule, publish, republish) / `com.posts.archivar` (archive) / `com.posts.fijar` (pin, unpin) (antes “según acción”)'),
    'API-COM-42': ('`com.newsletters.*`', '`com.newsletters.ver` (GET, pdf, preview-html) / `com.newsletters.configurar` (POST generación manual) / `com.newsletters.aprobar` (PATCH, suggest, approve, reject, cancel) / `com.newsletters.enviar` (send) (antes `com.newsletters.*`)'),
    'API-COM-47': ('`com.surveys.*`', '`com.surveys.ver` (GET) / `com.surveys.crear` (POST, PATCH, DELETE de borrador) (antes `com.surveys.*`)'),
    'API-COM-48': ('según acción', '`com.surveys.publicar` (publish, pause, reopen) / `com.surveys.cerrar` (close, archive) / `com.surveys.crear` (duplicate, restore-version, save-as-template) / `com.surveys.anonimizar` (anonymize-responses) (antes “según acción”)'),
    'API-COM-57': ('`com.events.*`', '`com.events.ver` (GET) / `com.events.gestionar` (alta, edición, publish, cancel, registrations, check-in) (antes `com.events.*`)'),
    'API-COM-60': ('`com.benefits.*`', '`com.benefits.ver` (GET) / `com.benefits.gestionar` (alta, edición, baja) (antes `com.benefits.*`)'),
    'API-COM-71': ('cuenta técnica', '`com.audiences.match` (cuenta técnica; antes “cuenta técnica”)'),
    'API-COM-76': ('cuenta técnica', '`com.communications.consultar` (cuenta técnica; antes “cuenta técnica”)'),
    'API-COM-77': ('cuenta técnica', '`com.communications.consultar` (cuenta técnica; antes “cuenta técnica”)'),
    'API-COM-78': ('cuenta técnica (M05)', '`com.invoiceMessages.resolver` (cuenta técnica M05; antes “cuenta técnica (M05)”)'),
    'API-COM-79': ('cuenta técnica', '`com.preferences.consultar` (cuenta técnica; antes “cuenta técnica”)'),
    'API-COM-85': ('`com.templates.*`', '`com.templates.ver` (GET) / `com.templates.crear` (POST) / `com.templates.editar` (PATCH, DELETE de borrador, versiones) (antes `com.templates.*`)'),
    'API-COM-88': ('`com.campaigns.*`', '`com.campaigns.ver` (GET) / `com.campaigns.crear` (POST, PATCH, DELETE de borrador) (antes `com.campaigns.*`)'),
    'API-COM-89': ('según acción', '`com.campaigns.crear` (submit, test) / `com.campaigns.aprobar` (approve, reject) / `com.campaigns.programar` (schedule, send-now, pause, resume) / `com.campaigns.cancelar` (cancel) (antes “según acción”)'),
    'API-COM-91': ('`com.invoiceMessages.*`', '`com.invoiceMessages.ver` (GET, simulate) / `com.invoiceMessages.crear` (POST, PATCH) / `com.invoiceMessages.aprobar` (approve, cancel) (antes `com.invoiceMessages.*`)'),
    'API-COM-98': ('`com.outages.*`', '`com.outages.ver` (GET, affected-preview) / `com.outages.crear` (POST, PATCH, update) / `com.outages.publicar` (publish, reschedule, restore, cancel) (antes `com.outages.*`)'),
    'API-COM-104': ('sesión', '`com.inbox.ver` (antes “sesión”)'),
    'API-COM-107': ('T06 (cuenta técnica)', '`com.providerEvents.registrar` (cuenta técnica T06; antes “T06 (cuenta técnica)”)'),
    'API-COM-108': ('T06', '`com.inboundMessages.registrar` (cuenta técnica T06; antes “T06”)'),
    'API-COM-111': ('sesión (admin del tenant)', '`com.platformNotices.ver` (administrador del tenant; antes “sesión (admin del tenant)”)'),
}
for rid, (old, new) in api.items():
    set_cell(rid, 3, new, expect=old)

# Otras celdas con sufijo relativo (`/ editar`) se explicitan
for rid, col in [('API-COM-17', 3), ('API-COM-27', 3), ('API-COM-32', 3), ('API-COM-50', 3), ('API-COM-81', 3),
                 ('API-COM-86', 3), ('API-COM-96', 3)]:
    i = row_idx(rid)
    c = cells(L[i])
    m = re.match(r'^`(com\.[A-Za-z]+)\.([A-Za-z]+)` / `([A-Za-z]+)`$', c[col])
    if m:
        c[col] = '`%s.%s` / `%s.%s`' % (m.group(1), m.group(2), m.group(1), m.group(3))
        L[i] = '| ' + ' | '.join(c) + ' |'
    else:
        print('sin cambio', rid, c[col])

# ---------- cat. 8: PAN ----------
for i, l in enumerate(L):
    if l.startswith('| PAN-COM-'):
        c = cells(l)
        col = 2 if int(c[0][8:]) < 40 else 3
        m = re.match(r'^`(com\.[A-Za-z]+)\.([A-Za-z]+)` / `([A-Za-z]+)`$', c[col])
        if m:
            c[col] = '`%s.%s` / `%s.%s`' % (m.group(1), m.group(2), m.group(1), m.group(3))
            L[i] = '| ' + ' | '.join(c) + ' |'
set_cell('PAN-COM-32', 2, '`com.inbox.ver` (antes “sesión”)', expect='sesión')

# ---------- §11.6 ----------
rep('`com.outages.publicar`, `com.wall.verInterno` (muro de empleados).',
    '`com.outages.publicar`, `com.wall.verInterno` (muro de empleados), `com.events.gestionar` (alta, edición, publicación, cancelación, inscripciones y check-in de eventos), `com.benefits.gestionar` (comercios y beneficios), `com.sanctions.apelar` (apelar una sanción propia), `com.platformNotices.ver` (avisos de plataforma recibidos por el tenant), `com.communications.emit` (comando de envío, cuenta técnica), `com.communications.consultar` (estado y constancia por objeto, cuenta técnica), `com.audiences.match` (pertenencia a audiencia, cuenta técnica), `com.invoiceMessages.resolver` (mensajes impresos aplicables, cuenta técnica M05), `com.preferences.consultar` (preferencias efectivas, cuenta técnica), `com.providerEvents.registrar` y `com.inboundMessages.registrar` (ingreso desde T06, cuenta técnica). Los comodines usados antes (`com.newsletters.*`, `com.surveys.*`, `com.events.*`, `com.benefits.*`, `com.templates.*`, `com.campaigns.*`, `com.invoiceMessages.*`, `com.outages.*`) y las reglas “sesión”, “propio”, “según acción” y “cuenta técnica” quedan reemplazados por estas capabilities explícitas en §10 y §11; T02 §4.4 las registra.')

# ---------- cat. 6: criterios de aceptación ----------
crit = {
    '070': 'La encuesta guarda y muestra en la vista previa todos los campos del constructor; sin `title` no se puede guardar.',
    '072': 'Cada opción se aplica igual en cliente y servidor: una respuesta que viola una validación (mín/máx, largo, archivo) se rechaza con el mensaje propio; la precarga toma el dato del perfil.',
    '075': 'Con `one_by_one` se muestra el progreso; con `allowBack=false` no se puede volver; con `allowEditAfterSubmit=false` la respuesta enviada no se edita; con `anonymous=true` se aplica RN-COM-049.',
    '078': 'Con `maxCount=2`, una invitación sin respuesta recibe 2 recordatorios y una respondida ninguno; el informe programado llega solo a `recipientUserIds`.',
    '080': 'Restaurar una versión crea una versión nueva sin perder las anteriores; la encuesta generada con IA queda en borrador hasta que una persona la confirma; la comparación de oleadas muestra ambas series por pregunta.',
    '085': 'Cada respuesta disparada por evento guarda `context` (visita, orden, reclamo, servicio) y la invitación registra cada paso `created → delivered → opened → responded` o `expired`.',
    '087': 'Una respuesta que cumple la regla de insatisfacción crea un caso en M09 con referencia a la respuesta; la respuesta sigue sin cambios en los resultados.',
    '094': 'Al enviarse una respuesta, T06 entrega un POST firmado al conector configurado; una falla del webhook no rechaza la respuesta y se reintenta según T06.',
    '106': 'Un beneficio publicado o canjeado no genera comprobante, asiento ni cambio de tarifa; ningún registro de `BENSOC` migra a `benefits`.',
    '110': 'Cada modo resuelve destinatarios según su definición: `all` toda la audiencia del canal, `none` nadie, `import` solo las filas cruzadas de la lista, `segment` la evaluación del segmento.',
    '116': 'Un segmento `private` solo lo ve y usa su dueño; uno `shared` lo usa otro usuario con `com.audiences.usar`; con evaluación `snapshot` el conteo no cambia hasta recalcular.',
    '117': 'Publicar o enviar crea un `audienceSnapshots` con `definitionHash`, conteos y miembros; un cambio posterior de la audiencia no altera el snapshot tomado.',
    '120': 'Un aviso por ramal o nodo obtiene de M10 los contratos afectados y solo esos titulares integran la audiencia (ESC-COM-34).',
    '133': 'La vista previa con datos ficticios muestra el render final; el envío de prueba llega solo a la dirección del usuario que lo pide y no cuenta en métricas.',
    '137': 'Una suscripción que recibe 404/410 del servicio push pasa a `expired` y no se usa más; un push entregado abre el enlace profundo configurado.',
    '138': 'Dos inserciones con la misma `dedupeKey` dejan un único aviso; leer o descartar registra `readAt` o `dismissedAt`.',
    '144': 'Con `perSecond=10` un lote de 1.000 mensajes tarda al menos 100 s; nadie supera el tope de PRM-COM-029; `security` y `service_outage` no cuentan para el tope.',
    '147': 'Con agrupación por cuenta, una cuenta con 3 comprobantes recibe un solo mensaje con los 3; con `ninguna`, recibe 3.',
    '150': 'Desde la vista previa de una factura o recibo, el envío rápido crea una comunicación del tipo correspondiente con el PDF por referencia y queda en el historial de la cuenta.',
    '151': 'En un envío masivo de email con CCO configurada (PRM-COM-053), la casilla de auditoría recibe copia y ningún destinatario ve direcciones de otros.',
    '153': 'Una comunicación generada antes de cambiar una etiqueta del diccionario conserva el texto original en su constancia; las nuevas usan la etiqueta nueva.',
    '161': 'Un `tec.outage.notified` crea un aviso en `draft` con área y ventana de M10 (o lo publica si PRM-COM-063 = true); al restablecer, los afectados reciben el aviso de restablecimiento.',
    '162': 'Publicar un corte programado con menos anticipación que PRM-COM-060 exige confirmación con motivo y registra quién lo confirmó.',
    '163': 'Los electrodependientes afectados reciben el aviso estándar; la lista de críticos llega solo al módulo dueño por EVT-COM-26 y no aparece en muro, campañas ni BI general (ESC-COM-35).',
    '171': 'La API rechaza desactivar `security`/`regulatory` y el último canal de una finalidad `transactional`; sin opt-in no se envía `marketing` por SMS, WhatsApp ni email (ESC-COM-32).',
    '173': 'Todo email `community`/`marketing` lleva `List-Unsubscribe` y `List-Unsubscribe-Post`; el enlace registra el opt-out sin login y lo confirma en pantalla (ESC-COM-14 vía CU-COM-14).',
    '176': 'El código de verificación sale como comunicación `security` sin opt-out ni horario de no molestar; COM no guarda el código en claro y la validación la hace M01/T02.',
    '181': 'Ningún módulo fuera de COM llama a un conector de mensajería: todo envío se origina en un evento del catálogo o en el comando `com.communications.emit` / servicio `com.notify` (§11.7).',
    '184': 'Con la operación configurada “al confirmar”, crear la OT no envía aviso y confirmarla envía uno; con “nunca” no se envía ninguno.',
    '190': 'Una campaña sin finalidad, audiencia, canal o programación no puede pasar a `scheduled`; la prueba llega solo a `testRecipients`.',
    '192': 'El segmento “inactivos 30 días” incluye solo usuarios sin ingreso a la app en los últimos 30 días al momento de evaluarlo.',
    '194': 'El copy generado con IA queda en borrador hasta que una persona lo confirma; con A/B al 20 %, el resto recibe la variante ganadora tras `decideAfterMinutes`.',
    '197': 'Los destinatarios sin contacto para el canal no generan comunicación y figuran en el reporte de excluidos con su motivo.',
    '200': 'Las pestañas filtran por estado; “marcar todo leído” deja el contador en 0 y el badge se actualiza en todas las pantallas abiertas.',
    '201': 'Un aviso a un empleado aparece en la campana del AdminShell y en su bandeja PWA; leerlo en un lugar lo marca leído en el otro.',
    '203': 'Un aviso sin acción pendiente sale de la bandeja al vencer su vigencia (PRM-COM-050) y JOB-COM-18 lo purga; uno con acción pendiente sigue visible.',
    '204': 'Un aviso de plataforma dirigido a un plan aparece solo a administradores de tenants de ese plan, con la permanencia elegida, y registra lecturas por tenant.',
    '205': 'Asignar una tarea o cambiar un vencimiento genera aviso in-app al responsable; no existe función de correo interno libre entre usuarios.',
}
for n, cr in crit.items():
    set_cell('RF-COM-' + n, 6, cr, expect='—')
left = [l.split(' | ')[0] for l in L if l.startswith('| RF-COM-') and cells(l)[-1] == '—']
print('RF sin criterio restantes:', left)

# ---------- cat. 10: CU ----------
rep('| CU-26 (BASE §26) | Comunicar al asociado por el canal adecuado',
    '| CU-26 (BASE §26; dueño T09, T11 cita) | Comunicar al asociado por el canal adecuado')
i = row_idx('CU-INS-01 (BASE §73)')
c = cells(L[i])
c[0] = 'CU-INS-01 (BASE §73; dueño M10, T09 cita)'
c[1] = 'Instalación integral: aporte de T09 (encuesta de satisfacción). La definición completa del caso está en M10 «CU-INS-01 (BASE §73, parte técnica)»; aquí solo se describe el tramo de COM'
L[i] = '| ' + ' | '.join(c) + ' |'

out = '\n'.join(L)
open(P, 'wb').write(out.encode('utf-8'))
print('ok', len(L))
