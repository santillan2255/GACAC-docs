import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from res_lib_m12m19 import Doc

d = Doc('M12-CMP-compras-proveedores.md')
PA = 'PA-CMP-16'


def _idx(after, field):
    ls = d.t.split('\n')
    st = [i for i, l in enumerate(ls) if after in l]
    assert st, ('ancla', after)
    for j in range(st[0], len(ls)):
        if ls[j].startswith('| `%s` |' % field):
            return ls, j
    raise AssertionError(('fila', after, field))


def add_after(after, field, rows, cat=4):
    ls, j = _idx(after, field)
    ls[j + 1:j + 1] = rows
    d.t = '\n'.join(ls)
    d.n += 1
    d.cats[cat] = d.cats.get(cat, 0) + len(rows)


def set_row(after, field, desc=None, ref=None, tipo=None, cat=2):
    ls, j = _idx(after, field)
    cells = ls[j].split(' | ')
    if tipo is not None:
        cells[1] = tipo
    if desc is not None:
        cells[-2] = desc
    if ref is not None:
        cells[-1] = ref + ' |'
    ls[j] = ' | '.join(cells)
    d.t = '\n'.join(ls)
    d.n += 1
    d.cats[cat] = d.cats.get(cat, 0) + 1


S = '#### 7.13.'
# suppliers
set_row(S + '1 `suppliers`', 'taxId', ref='— (CUIT; identificador fiscal, no es referencia; T05 lo declara clave única)')
set_row(S + '1 `suppliers`', 'productTypeIds', ref='`supplierCategories` (M12) con `kind = productService` (rubros de productos y servicios, `PROVEED_TIPPROD`; antes `[VERIFICAR]`; ' + PA + ')')
set_row(S + '1 `suppliers`', 'isEmployee', ref='— (booleano; el empleado es `employeeId` → `employees` (M16))')
set_row(S + '1 `suppliers`', 'accountingAccountId', ref='`ledgerAccounts` (M15) (antes `[VERIFICAR]`); M15 §7.38 y §7.39 guardan la cuenta del proveedor en `entityAccountAssignments` con `entityType = supplier`: el campo queda como alias de migración de P3068 (' + PA + ')')
add_after(S + '1 `suppliers`', 'accountingAccountId',
          ['| `personId` | `persons` (M01) (opcional; clave de T05; proveedor que también es persona registrada; ' + PA + ') |'])
# catálogos
set_row(S + '6 `supplierCorrespondence`', 'templateId', ref='`messageTemplates` (T09) (antes `[VERIFICAR]`)')
set_row(S + '7 `purchaseForecasts`', 'productId', desc='T05 nombra el campo `inventoryItemId` (§7.2); `productId` queda como alias (' + PA + ').',
        ref='`inventoryItems` (M13) (antes `[VERIFICAR]`)')
set_row(S + '8 `supplyRequests`', 'recipientId', ref='`purchaseLookups` (M12) con `kind = recipient` (`COD_DES`; antes `[VERIFICAR]`)')
set_row(S + '9 `quoteRequests`', 'groupId', ref='— (identificador que agrupa las solicitudes enviadas juntas a varios proveedores; no es referencia; antes `[VERIFICAR]`)')
set_row(S + '10 `sourcingEvents`', 'invitationTemplateId', ref='`documentTemplates` (T11) (antes `[VERIFICAR]`)')
set_row(S + '11 `purchaseOrders`', 'blanketOrderId', ref='`purchaseOrders` (M12) (OC marco, `kind = blanket`; antes `[VERIFICAR]`)')
add_after(S + '11 `purchaseOrders`', 'blanketOrderId',
          ['| `legalEntityId` | `legalEntities` (T04) (entidad jurídica compradora, DEC-064; clave de T05; ' + PA + ') |'])
set_row(S + '12 `supplierReceipts`', 'receiverId', ref='`memberships` (T02) (usuario que recibe; antes `[VERIFICAR]`)')
add_after(S + '13 `supplierInvoices`', 'signalRightsSettlementId',
          ['| `legalEntityId` | `legalEntities` (T04) (entidad jurídica receptora del comprobante, DEC-064; clave de T05; ' + PA + ') |'])
# vínculos
poly = 'Polimórfica según `%s`: `supplyRequests`, `quoteRequests`, `purchaseOrders`, `supplierReceipts` o `supplierInvoices` (M12) (antes `[VERIFICAR]`)'
set_row(S + '14 `purchaseDocumentLinks`', 'originId', ref=poly % 'originType')
set_row(S + '14 `purchaseDocumentLinks`', 'targetId', ref=poly % 'targetType')
emb = '— (renglón embebido `items[].itemId` del documento indicado por `%s`; no es colección; antes `[VERIFICAR]`)'
set_row(S + '14 `purchaseDocumentLinks`', 'originItemId', ref=emb % 'originType')
set_row(S + '14 `purchaseDocumentLinks`', 'targetItemId', ref=emb % 'targetType')
# excepciones
set_row(S + '15 `matchExceptions`', 'invoiceId', ref='`supplierInvoices` (M12) (antes `invoices` (M05), que es la factura de venta; ' + PA + ')')
set_row(S + '15 `matchExceptions`', 'invoiceItemId', ref='— (renglón embebido `items[].itemId` de `supplierInvoices` (M12); antes `[VERIFICAR]`)')
set_row(S + '15 `matchExceptions`', 'receiptId', ref='`supplierReceipts` (M12) (antes `receipts` (M07), que es el recibo de cobranza; ' + PA + ')')
set_row(S + '17 `supplierPortalSubmissions`', 'taxId', tipo='string', ref='— (CUIT informado por el proveedor; no es referencia; antes tipo ObjectId y `[VERIFICAR]`)')
set_row(S + '18 `aiInvoiceExtractions`', 'invoiceId', ref='`supplierInvoices` (M12) (antes `invoices` (M05); ' + PA + ')')
set_row(S + '20 `supplyBalances`', 'invoiceIds', ref='`supplierInvoices` (M12) (facturas mayoristas de compra; antes `invoices` (M05); ' + PA + ')')
set_row(S + '21 `signalRightsContracts`', 'packageIds', ref='`servicePlans` (M02) (paquetes de señales del servicio de TV; antes `[VERIFICAR]`; ' + PA + ')')
set_row(S + '21 `signalRightsContracts`', 'status', tipo='enum', desc='Valores: `draft`, `active`, `ended` (§8.8; antes sin valores, ' + PA + ').', cat=1)
set_row(S + '22 `signalRightsSettlements`', 'contractId', ref='`signalRightsContracts` (M12) (contrato de señales, T05 COL-CMP-23; antes `serviceContracts` (M02); ' + PA + ')')
set_row(S + '22 `signalRightsSettlements`', 'reportRef', ref='— (clave del informe de abonados activos que emite M02; no es referencia)')
set_row(S + '22 `signalRightsSettlements`', 'invoiceId', ref='`supplierInvoices` (M12) (factura de la programadora; antes `invoices` (M05); ' + PA + ')')
add_after('### 7.10 `paymentOrders`', 'supplierId`, `beneficiaryName',
          ['| `legalEntityId` | ObjectId | Sí | Entidad jurídica pagadora, la de las facturas aplicadas (DEC-064; clave de T05; ' + PA + ') |'])

# Cat 1: estados
d.rep('## 9. Procesos y flujos\n', '''### 8.8 Estados iniciales y máquinas sin transiciones (corrección 05-11-2026)

Corrección del 05-11-2026 (%s): §8.2, §8.4 y §8.7 están en texto corrido y el §7.11 enumera valores sin transiciones para `supplierAdvances`, `supplyBalances` y `signalRightsSettlements`; `signalRightsContracts.status` no tenía valores y el `cancelled` del evento de selección no tenía origen. Esta tabla lo explicita sin cambiar el texto anterior. Estado inicial: ver las filas `(alta)`.

| Colección | Desde | Hacia | Disparador | Guarda | Evento |
|---|---|---|---|---|---|
| `quoteRequests` | (alta) | `draft` | Carga de la solicitud de cotización | — | — |
| `sourcingEvents` | (alta) | `draft` | Alta del evento de selección | — | — |
| `sourcingEvents` | `draft`, `published`, `closed`, `opened` | `cancelled` | Anulación del evento antes de adjudicar | Motivo obligatorio | — |
| `supplierReceipts` | (alta) | `draft` | Carga de la recepción | — | — |
| `matchExceptions.decision` | (alta) | `pending` | Conciliación con diferencia | — | — |
| `supplierAdvances` | (alta) | `open` | OP de anticipo aprobada | — | — |
| `supplierAdvances` | `open` | `partiallyApplied` | Aplicación parcial a una factura | — | — |
| `supplierAdvances` | `open`, `partiallyApplied` | `applied` | Aplicación del saldo total | — | — |
| `supplierAdvances` | `open` | `voided` | Anulación de la OP que lo originó (§8.6) | Sin aplicaciones | — |
| `supplyBalances` | (alta) | `draft` | Cálculo del balance de compra y pérdidas del período | — | — |
| `supplyBalances` | `draft` | `approved` | Aprobación (`approvedBy`) | — | — |
| `signalRightsContracts` | (alta) | `draft` | Carga del contrato con la programadora | — | — |
| `signalRightsContracts` | `draft` | `active` | Aprobación del contrato | — | — |
| `signalRightsContracts` | `active` | `ended` | Fin de vigencia (`validTo`) o rescisión | — | — |
| `signalRightsSettlements` | (alta) | `draft` | Liquidación mensual por abonados activos | — | — |
| `signalRightsSettlements` | `draft` | `approved` | Aprobación (`approvedBy`) | — | EVT-CMP-17 |
| `signalRightsSettlements` | `approved` | `invoiced` | Registro de la factura de la programadora (`invoiceId`) | — | — |
| `signalRightsSettlements` | `draft`, `approved` | `voided` | Anulación; un ajuste posterior usa `adjustsSettlementId` | — | — |

## 9. Procesos y flujos
''' % PA, cat=1)

d.insert_before('## 22. Trazabilidad', '''### PA-CMP-16 — Residuales del 05-11-2026 (estados, referencias y nombres de campo)
- **Pregunta:** ¿Cómo se cierran los residuales de M12 que detectaron los entregables regenerados?
- **Opciones:** A) (Recomendada) §8.8 con estados iniciales y transiciones de `supplierAdvances`, `supplyBalances`, `signalRightsContracts` (`draft`, `active`, `ended`) y `signalRightsSettlements`; destinos o "no es referencia" en cada campo del §7.13; facturas y recepciones de compra apuntan a `supplierInvoices` y `supplierReceipts` (antes `invoices` de M05 y `receipts` de M07); `legalEntityId` y `personId` de T05. B) Mantener el texto y resolver en los entregables.
- **Contexto:** el índice de estados marcó máquinas sin estado inicial, valores sin transiciones y el `cancelled` del evento de selección sin origen; el modelo entidad-relación dejó referencias sin destino y algunas apuntaban a colecciones de venta o cobranza.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** §7.10, §7.13, §8.
- **Estado:** Asumida la recomendada (DEC-072). `packageIds` → `servicePlans` (M02) debe confirmarlo M02; T05 COL-CMP-23 todavía dice que M12 nombra `declarationFileId`, pero este anexo ya usa `declarationStoredFileId`.

''', cat=0)
d.save()
