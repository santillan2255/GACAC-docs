﻿import re
L=open('anexos/T02-IAM-identidad-roles-auditoria.md',encoding='utf-8').read().split('\n')
defs={}
for i,l in enumerate(L[220:2268],start=221):
    m=re.match(r'\| `([^`]+)` \|',l)
    if m and not (794<=i<820): defs[m.group(1)]=i
for p in ['tec.ordenes','tec.materiales','tec.conflictos','sue.novedades','sue.liquidaciones','per.documentacion','tec.guardias','tec.calidadAgua','tec.cuadrillas','tec.despacho','tec.dispositivos','tec.estimaciones','tec.formulariosCampo','tec.equiposRed','tec.servicioTecnico','tec.contribucionesObra','tec.telefonia','uxd.','por.conformidades','por.totem','iam.directorio','tec.agenda','tec.campo','tec.ot.','tec.instalaciones','tec.inspecciones']:
    print(p, sorted((k,v) for k,v in defs.items() if k.startswith(p)))
