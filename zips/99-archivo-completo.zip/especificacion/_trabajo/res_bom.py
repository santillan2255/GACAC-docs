import subprocess, glob, os
os.chdir('..')
pats = ['T01-*', 'T02-*', 'T03-*', 'T04*', 'T06-*', 'T07-*', 'T08-*', 'T10-*', 'T12-*']
files = [f.replace('\\', '/') for p in pats for f in glob.glob('anexos/' + p + '.md')] + ['00-ESPECIFICACION-MAESTRA.md', '03-plan-de-olas-y-prompts.md']
for f in files:
    head = subprocess.run(['git', 'show', 'HEAD:docs/especificacion/' + f], capture_output=True).stdout
    cur = open(f, 'rb').read()
    hb, cb = head.startswith(b'\xef\xbb\xbf'), cur.startswith(b'\xef\xbb\xbf')
    hc, cc = b'\r\n' in head, b'\r\n' in cur
    flag = '' if (hb, hc) == (cb, cc) else '  <-- DIFIERE'
    print(f.ljust(70), 'HEAD bom=%s crlf=%s | ahora bom=%s crlf=%s%s' % (hb, hc, cb, cc, flag))
