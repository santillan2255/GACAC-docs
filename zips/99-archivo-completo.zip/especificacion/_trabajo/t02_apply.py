# -*- coding: utf-8 -*-
"""Aplica a T02: tabla T09 COM curada, alias en 4.4.1 y §4.4.2/§4.4.3 generadas por t02_gen.py."""
import os, re, sys
sys.stdout.reconfigure(encoding='utf-8')
AQUI = os.path.dirname(os.path.abspath(__file__))
T02 = os.path.normpath(os.path.join(AQUI, '..', 'anexos', 'T02-IAM-identidad-roles-auditoria.md'))
t = open(T02, 'rb').read().decode('utf-8')
L = t.split('\n')
if '#### 4.4.2' in t:
    a0 = next(n for n, l in enumerate(L) if l.startswith('#### 4.4.2'))
    c0 = next(n for n, l in enumerate(L) if l.startswith('### 4.5'))
    del L[a0:c0]
    t = '\n'.join(L)
if '--quitar' in sys.argv:
    open(T02, 'wb').write(t.encode('utf-8'))
    sys.exit(0)
HECHO = 'Tabla alineada a T09' in t

COM = [
    ('com.wall.ver', 'Ver muro según audiencia', '—', 'Todos staff y comunidad', 'audiencia'),
    ('com.wall.verInterno', 'Ver muro interno de empleados', '—', 'Todos staff, C-EMP', 'audiencia'),
    ('com.reactions.crear', 'Reaccionar a publicaciones (antes com.muro.reaccionar)', '—', 'C-SOC, C-REP, C-ADH, C-EMP, staff', 'audiencia'),
    ('com.comments.crear', 'Comentar y editar o borrar comentarios propios si el tenant y la publicación lo habilitan, DEC-008 (antes com.muro.comentar)', '—', 'C-SOC, C-REP, C-ADH, C-EMP, staff', 'audiencia / prop'),
    ('com.reports.crear', 'Denunciar un comentario', '—', 'C-SOC, C-REP, C-ADH, C-EMP, staff', 'audiencia'),
    ('com.sanctions.apelar', 'Ver y apelar sanciones propias', '—', 'C-SOC, C-REP, C-ADH, C-EMP, staff', 'self'),
    ('com.inbox.ver', 'Bandeja de avisos propia y suscripciones push', '—', 'Todos staff y comunidad', 'self'),
    ('com.preferences.editar', 'Editar preferencias de comunicación propias, o del socio en atención', '—', 'C-SOC, C-REP, C-ADH, C-EMP; T-ATE, T-SAT', 'self / suc'),
    ('com.posts.ver', 'Ver publicaciones en administración', '—', 'T-COM, T-ADM, T-GER, T-CJO, T-SIN', 'audiencia ⊆ alcance'),
    ('com.posts.crear', 'Redactar, duplicar y enviar a aprobación (antes com.publicaciones.crear)', '—', 'T-COM, T-ADM, empleados autorizados (T-STE, T-ATE, T-SAT, T-RRHH, T-SEC por asignación)', 'audiencia ⊆ alcance'),
    ('com.posts.editar', 'Editar publicación', '—', 'Ídem com.posts.crear', 'prop / audiencia ⊆ alcance'),
    ('com.posts.programar', 'Programar publicación', '—', 'T-COM, T-ADM', 'audiencia ⊆ alcance'),
    ('com.posts.aprobar', 'Aprobar o rechazar publicación (aprobador distinto del autor)', 'D', 'T-COM, T-ADM, T-GER', 'audiencia ⊆ alcance'),
    ('com.posts.publicar', 'Publicar o republicar (antes com.publicaciones.publicar)', 'D', 'T-COM, T-ADM, T-GER', 'audiencia ⊆ alcance'),
    ('com.posts.publicarLanding', 'Publicar en la landing pública con control de datos personales', 'S D', 'T-COM, T-ADM', 'tenant'),
    ('com.posts.archivar', 'Archivar publicación', '—', 'T-COM, T-ADM', 'audiencia ⊆ alcance'),
    ('com.posts.fijar', 'Fijar o desfijar publicación', '—', 'T-COM, T-ADM', 'audiencia ⊆ alcance'),
    ('com.posts.configurar', 'Categorías, plantillas de publicación, reacciones y saludos automáticos', 'S', 'T-COM, T-ADM', 'tenant'),
    ('com.posts.publicarEquipo', 'Aviso del supervisor a su equipo desde la PWA', '—', 'Supervisores por asignación (T-STE, T-SAT, T-RRHH)', 'equipo (cua / area)'),
    ('com.media.subir', 'Subir medios de publicaciones', '—', 'T-COM, T-ADM, autores autorizados', 'tenant'),
    ('com.moderation.ver', 'Ver cola de moderación', '—', 'T-COM, T-SAT', 'tenant'),
    ('com.moderation.decidir', 'Decidir casos de moderación y denuncias (antes com.comentarios.moderar)', '—', 'T-COM, T-SAT', 'tenant'),
    ('com.moderation.configurar', 'Políticas, reglas de moderación y reglas de comunidad', 'S', 'T-COM, T-ADM', 'tenant'),
    ('com.moderation.verEvidencia', 'Ver contenido oculto o borrado conservado como evidencia', 'S', 'T-COM (responsable), T-ADM', 'tenant'),
    ('com.comments.ocultar', 'Ocultar comentario', '—', 'T-COM, T-SAT', 'tenant'),
    ('com.comments.responder', 'Respuesta institucional a un comentario', '—', 'T-COM, T-SAT', 'tenant'),
    ('com.comments.eliminarEvidencia', 'Eliminar evidencia con aprobación de workflow', 'S D', 'T-COM (responsable), T-ADM', 'tenant'),
    ('com.reports.resolver', 'Resolver denuncias', '—', 'T-COM, T-SAT', 'tenant'),
    ('com.sanctions.aplicar', 'Aplicar sanción (el moderador solo leves)', 'D', 'T-COM; T-SAT (leves)', 'tenant'),
    ('com.sanctions.revocar', 'Revocar sanción y decidir apelaciones', 'D', 'T-COM (responsable), T-ADM', 'tenant'),
    ('com.audit.ver', 'Auditoría de moderación y comunicaciones', '—', 'T-COM, T-ADM, T-SIN', 'tenant'),
    ('com.newsletters.ver', 'Ver boletines', '—', 'T-COM, T-ADM, T-GER', 'tenant'),
    ('com.newsletters.configurar', 'Reglas de boletín y generación manual', 'S', 'T-COM, T-ADM', 'tenant'),
    ('com.newsletters.aprobar', 'Revisar, aprobar o cancelar boletín', 'D', 'T-COM, T-ADM', 'tenant'),
    ('com.newsletters.enviar', 'Enviar boletín (antes com.novedades.enviar)', '—', 'T-COM, T-ADM', 'audiencia ⊆ alcance'),
    ('com.surveys.ver', 'Ver encuestas', '—', 'T-COM, T-SAT, T-RRHH, T-SEC, T-GER, T-ADM, T-SIN', 'audiencia ⊆ alcance'),
    ('com.surveys.crear', 'Crear, editar y duplicar encuestas y plantillas (antes com.encuestas.editar)', '—', 'T-COM, T-SAT, T-RRHH, T-SEC', 'audiencia ⊆ alcance'),
    ('com.surveys.publicar', 'Publicar, pausar o reabrir encuestas (antes com.encuestas.publicar)', 'D', 'T-COM, T-ADM', 'audiencia ⊆ alcance'),
    ('com.surveys.cerrar', 'Cerrar o archivar encuesta', '—', 'T-COM, T-ADM, autor', 'prop / tenant'),
    ('com.surveys.resultados', 'Ver resultados (antes com.encuestas.resultados.ver)', '—', 'T-COM, T-GER, T-ADM, autor', 'prop / tenant'),
    ('com.surveys.exportar', 'Exportar resultados', 'S', 'T-COM, T-GER, T-ADM', 'tenant'),
    ('com.surveys.verRespondentes', 'Ver identidad de respondentes en encuestas no anónimas', 'S', 'T-COM, T-ADM', 'tenant'),
    ('com.surveys.anonimizar', 'Anonimizar respuestas', 'S D', 'T-COM, T-ADM', 'tenant'),
    ('com.surveys.rapidaEquipo', 'Encuesta rápida del supervisor a su equipo', '—', 'Supervisores por asignación', 'equipo (cua / area)'),
    ('com.surveys.responder', 'Responder', '—', 'C-*, staff', 'audiencia'),
    ('com.events.ver', 'Ver eventos y agenda', '—', 'Todos staff y comunidad', 'audiencia'),
    ('com.events.gestionar', 'Alta, edición, publicación, cancelación, inscripciones y asistencia de eventos', '—', 'T-COM, T-SEC, T-RRHH', 'audiencia ⊆ alcance'),
    ('com.events.inscribirse', 'Inscribirse o cancelar la inscripción propia', '—', 'C-SOC, C-REP, C-ADH, C-EMP, staff', 'self'),
    ('com.benefits.ver', 'Ver beneficios elegibles', '—', 'C-SOC, C-REP, C-ADH; T-COM, T-ADM', 'audiencia'),
    ('com.benefits.gestionar', 'Comercios adheridos y beneficios', '—', 'T-COM, T-ADM', 'tenant'),
    ('com.benefits.canjear', 'Obtener el código de canje de un beneficio', '—', 'C-SOC, C-REP, C-ADH', 'self'),
    ('com.benefits.validarCanje', 'Validar un canje en el comercio', '—', 'T-COM; validadores del comercio por asignación', 'tenant'),
    ('com.audiences.usar', 'Armar audiencias, segmentos, importaciones y vista previa', '—', 'T-COM, T-ATE, T-SAT, T-RRHH, T-SEC', 'audiencia ⊆ alcance'),
    ('com.audiences.exportar', 'Exportar miembros de una audiencia', 'S', 'T-COM, T-ADM', 'tenant'),
    ('com.audiences.consultar', 'Pertenencia de un usuario a una audiencia (cuenta técnica)', '—', 'S-SYS', 'tenant'),
    ('com.campaigns.ver', 'Ver campañas', '—', 'T-COM, T-ADM, T-GER', 'tenant'),
    ('com.campaigns.crear', 'Crear, editar, probar y enviar a aprobación una campaña', '—', 'T-COM, T-ATE', 'audiencia ⊆ alcance'),
    ('com.campaigns.programar', 'Programar, enviar ahora, pausar y reanudar envíos masivos (antes com.campanas.enviar)', 'S D', 'T-COM, T-ADM', 'audiencia ⊆ alcance'),
    ('com.campaigns.aprobar', 'Aprobar o rechazar campaña (aprobador distinto del creador)', 'S D', 'T-ADM, T-GER', 'tenant'),
    ('com.campaigns.cancelar', 'Cancelar campaña', 'S', 'T-COM, T-ADM, T-GER', 'tenant'),
    ('com.templates.ver', 'Ver plantillas de mensajes', '—', 'T-COM, T-ADM, T-ATE', 'tenant'),
    ('com.templates.crear', 'Crear plantillas de mensajes', '—', 'T-COM, T-ADM', 'tenant'),
    ('com.templates.editar', 'Editar plantillas y versiones (antes com.plantillas.editar)', '—', 'T-COM, T-ADM', 'tenant'),
    ('com.templates.publicar', 'Publicar una versión de plantilla', 'D', 'T-COM, T-ADM', 'tenant'),
    ('com.catalog.configurar', 'Catálogo de tipos de comunicación, variables y reglas internas', 'S', 'T-ADM, T-COM', 'tenant'),
    ('com.channels.configurar', 'Canales, remitentes y presupuesto de mensajería', 'S', 'T-ADM', 'tenant'),
    ('com.suppression.gestionar', 'Lista de supresión', 'S', 'T-ADM, T-COM', 'tenant'),
    ('com.consents.ver', 'Ver consentimientos de comunicación', 'S', 'T-ADM, T-COM, T-SIN', 'tenant'),
    ('com.consents.exportar', 'Exportar consentimientos', 'S', 'T-ADM', 'tenant'),
    ('com.communications.ver', 'Historial de comunicaciones por persona y cuenta (antes com.comunicaciones.historial.ver)', '—', 'T-ATE, T-SAT, T-COM, T-FAC, T-ADM, T-SIN', 'suc'),
    ('com.communications.verContacto', 'Ver datos de contacto sin enmascarar', 'S', 'T-SAT, T-ADM', 'suc'),
    ('com.communications.reenviar', 'Reenviar una comunicación', '—', 'T-ATE, T-SAT, T-COM', 'suc'),
    ('com.communications.enviarManual', 'Envío manual desde la ficha', '—', 'T-ATE, T-SAT, T-COM, T-FAC', 'suc'),
    ('com.communications.exportarConstancia', 'Exportar constancia de comunicación', 'S', 'T-COM, T-SAT, T-ADM, T-SIN', 'tenant'),
    ('com.communications.emit', 'Comando de envío del servicio interno com.notify para los módulos emisores (CTR-COM-10)', '—', 'S-SYS', 'tenant'),
    ('com.communications.consultar', 'Estado y constancia de las comunicaciones de un objeto de negocio', '—', 'S-SYS', 'tenant'),
    ('com.invoiceMessages.ver', 'Ver y simular mensajes en factura', '—', 'T-COM, T-FAC, T-ADM', 'tenant'),
    ('com.invoiceMessages.crear', 'Crear mensajes en factura', '—', 'T-COM, T-FAC', 'tenant'),
    ('com.invoiceMessages.aprobar', 'Aprobar o cancelar mensajes en factura', 'D', 'T-ADM, T-GER', 'tenant'),
    ('com.invoiceMessages.resolver', 'Resolver los mensajes aplicables a un comprobante (M05)', '—', 'S-SYS', 'tenant'),
    ('com.preferences.consultar', 'Preferencias efectivas de una persona', '—', 'S-SYS', 'tenant'),
    ('com.outages.ver', 'Ver avisos de interrupción', '—', 'T-COM, T-STE, T-ATE, T-SAT, T-ADM', 'zona / srv'),
    ('com.outages.crear', 'Crear y actualizar avisos de interrupción', '—', 'T-COM, T-STE', 'zona / srv'),
    ('com.outages.publicar', 'Publicar, reprogramar, restablecer o cancelar avisos de interrupción', 'D', 'T-COM, T-STE, T-ADM', 'zona / srv'),
    ('com.platformNotices.ver', 'Avisos de plataforma recibidos por el tenant', '—', 'T-ADM, T-USR', 'tenant'),
    ('com.providerEvents.registrar', 'Ingreso de eventos de estado de proveedores (desde T06)', '—', 'S-SYS', 'tenant'),
    ('com.inboundMessages.registrar', 'Ingreso de mensajes entrantes (desde T06)', '—', 'S-SYS', 'tenant'),
]
ALIAS = [
    ('com.muro.reaccionar', 'com.reactions.crear'), ('com.muro.comentar', 'com.comments.crear'),
    ('com.publicaciones.crear', 'com.posts.crear'), ('com.publicaciones.publicar', 'com.posts.publicar'),
    ('com.comentarios.moderar', 'com.moderation.decidir'), ('com.novedades.enviar', 'com.newsletters.enviar'),
    ('com.campanas.enviar', 'com.campaigns.programar'), ('com.encuestas.editar', 'com.surveys.crear'),
    ('com.encuestas.publicar', 'com.surveys.publicar'), ('com.encuestas.resultados.ver', 'com.surveys.resultados'),
    ('com.plantillas.editar', 'com.templates.editar'), ('com.comunicaciones.historial.ver', 'com.communications.ver'),
]
PLA_EXTRA = [
    ('pla.notices.publicar', 'Publicar avisos de plataforma a los tenants (los recibe T09, com.platformNotices.ver)', '—', 'P-SUP, P-ADM', 'global', 'T09 §4'),
    ('pla.messaging.consumo.ver', 'Consumo de mensajería por tenant', '—', 'P-SUP, P-COM, P-OPS', 'global', 'T09 §4'),
]

# 1) tabla T09 COM
if not HECHO:
    i = L.index('#### T09 COM — Comunidad y comunicaciones')
    j = i + 1
    while not L[j].startswith('| Capability'):
        j += 1
    k = j + 2
    while L[k].startswith('| `'):
        k += 1
    nuevo = ['| Capability | Descripción | Marcas | Roles | Alcance |', '|---|---|---|---|---|'] + \
            ['| `%s` | %s | %s | %s | %s |' % r for r in COM]
    L[j:k] = nuevo
    L.insert(j, '')
    L.insert(j, 'Tabla alineada a T09 §4 y §11.6: los recursos de T09 son en inglés (CTR-COM-09) y `emit` se conserva (CTR-COM-10). Los nombres anteriores en español de esta tabla quedan como alias en 4.4.1.')

    # 2) alias
    a = next(n for n, l in enumerate(L) if l.startswith('#### 4.4.1'))
    b = a
    while not L[b].startswith('| Nombre anterior'):
        b += 1
    b += 2
    while L[b].startswith('| `'):
        b += 1
    L[b:b] = ['| `%s` | `%s` | Total | §4.4 T09 (versión anterior de esta tabla) | CTR-COM-09 |' % x for x in ALIAS]

# 3) §4.4.2 / §4.4.3
gen = open(os.path.join(AQUI, 't02_gen_out.md'), encoding='utf-8').read().rstrip('\n').split('\n')
caps_gen = {re.match(r'\| `([^`]+)`', l).group(1) for l in gen if l.startswith('| `')}
extra = [r for r in PLA_EXTRA if r[0] not in caps_gen and ('`%s`' % r[0]) not in t]
if extra:
    h = next(n for n, l in enumerate(gen) if l.startswith('##### T01 PLA'))
    e = h + 4
    while gen[e].startswith('| `'):
        e += 1
    gen[e:e] = ['| `%s` | %s | %s | %s | %s | %s |' % r for r in extra]
c = next(n for n, l in enumerate(L) if l.startswith('### 4.5'))
L[c:c] = gen + ['']
open(T02, 'wb').write('\n'.join(L).encode('utf-8'))
print('ok', len(COM), len(ALIAS), len(extra))
