# Corrección de inconsistencias detectadas por los entregables (05-11-2026)

Origen: al ampliar los entregables de `docs/entregables-analisis-diseno/` a cobertura completa, los scripts detectaron inconsistencias en la especificación. Registro consolidado: `docs/entregables-analisis-diseno/_trabajo/inconsistencias-especificacion.md`. Detalle por elemento en las secciones de inconsistencias de cada entregable:

- ER: `03-modelo-entidad-relacion.md` §29 y sección de observaciones de cada `03-er/*.md`; datos en `_trabajo/er-verificacion.json`.
- Procesos: `04-procesos-bpmn.md` §18 y `04a` §6.
- Pantallas: `17-catalogo-pantallas/17-catalogo-pantallas.md` (inconsistencias) y el final de cada parte `17-NN-*.md`; `05a` final.
- Estados y secuencias: `06a-indice-cobertura-secuencias-estados.md` §7 (INC-06-01..10, tablas 7.1 y 7.2).
- API y eventos: `18-openapi/_inconsistencias.md`, `18-contratos-api.md`, `19-catalogo-eventos.md`.
- Casos de prueba: `20-casos-prueba.md` §7.
- Casos de uso, navegación, estimación y costos: `21-casos-de-uso.md` §6, `22-mapa-navegacion.md`, `23-estimacion-esfuerzo.md`, `24-modelo-costos-operacion.md`.

Los scripts de `docs/entregables-analisis-diseno/_trabajo/` se pueden ejecutar (solo lectura sobre la especificación) para obtener las listas filtradas por anexo.

## Categorías a corregir en TUS archivos

1. **Capabilities**: filas API, PAN o RF que ponen un rol o texto libre donde va una capability → reemplazar por una capability `modulo.recurso.accion` (convención T02), conservando el rol como nota. Listar en el informe las capabilities nuevas que elijas (el agente de T02 las incorpora al catálogo).
2. **Colecciones sin tabla de campos en el §7** (y las 8 sin ficha o sin campos): agregar la tabla de campos (nombre, tipo, obligatorio, descripción, referencia) tomando T05 y los usos en RF/RN/API/EVT del mismo anexo. No inventar semántica: si un campo no se puede deducir, `[VERIFICAR]`.
3. **Referencias sin destino** (campos `*Id` sin colección destino) y **relaciones inferidas**: declarar el destino (colección y anexo dueño) en la tabla de campos.
4. **Nombres distintos de T05** (733 campos): T05 prevalece en nombres. Alinear el anexo al nombre de T05 dejando nota "antes `x`". Si creés que T05 está mal, no lo cambies: informalo.
5. **Estados**: campo de estado sin valores → declarar los valores; máquina sin transiciones → agregar tabla de transiciones (desde, hacia, disparador, guarda RN, evento EVT); sin estado inicial → declararlo; máquina del §8 que no coincide con el §7 → alinear (prevalece la que use RF/RN; nota del cambio).
6. **RF sin criterio de aceptación** (150): redactar el criterio verificable a partir del enunciado y las RN citadas.
7. **Eventos**: cuando un anexo declara consumir un EVT pero T11 no lo lista como consumidor (tabla 7.2 de `06a`), dejarlo explícito en el §12 del anexo; el agente de T11 lo agrega del lado de T11. Payloads en texto libre en §12 → nombres de campo.
8. **Pantallas (PAN)**: PAN sin capability ni regla de acceso → declararla; PAN sin ruta ni forma de apertura → declararla; capability o ruta distinta de T03 → alinear según la regla AL-01 de T03 (prevalece el anexo; T03 se ajusta).
9. **API**: operaciones duplicadas (mismo método y ruta) → unificar o marcar una como reemplazada; mismo path con distinto nombre de parámetro → unificar; formato de tabla API distinto del de la guía `_GUIA-REDACCION-ANEXOS.md` → normalizar columnas (`API-ID`, método, ruta, capability, descripción) sin perder datos; filas API que son servicios internos → moverlas a la sección de servicios internos dejando la fila marcada "Reemplazado por servicio interno `x`". Rutas: seguir la convención de la maestra; si la maestra no la fija, no las cambies e informalo.
10. **Casos de uso y escenarios**: CU definidos en más de un anexo con resultados distintos → el anexo dueño del objetivo conserva la definición y los demás la citan.
11. **Específicas** asignadas a tu grupo (ver el pedido de tu tarea).

## Reglas

- **Solo tus archivos.** No edites `01`, `02`, `03-plan`, `04-matriz`, `05` ni la maestra salvo que tu tarea lo diga. Si una corrección requiere una decisión nueva, no la tomes: propone la PA (pregunta, opciones, recomendada) en el informe.
- No borrar contenido: corregir o marcar "Reemplazado por …" indicando por qué.
- IDs nuevos siguiendo la numeración de cada anexo y la guía. No crear RF nuevos salvo imprescindible (informar con ola).
- Respetar BOM y saltos de línea de cada archivo (leer primero, luego escribir; en PowerShell 5 usar `[IO.File]` con la codificación detectada).
- Datos solo ficticios; sin secretos ni código de ProCoop.
- Verificación final por archivo: IDs definidos una vez, encabezados únicos, sin `<!-- SIGUE -->`, sin mojibake, tablas con columnas consistentes.
- **Informe (en español)**: conteo por categoría (encontradas / corregidas / no corregibles y por qué), capabilities nuevas elegidas, consumidores de eventos a agregar en T11, PA propuestas, archivos modificados.
