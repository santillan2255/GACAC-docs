import glob, re, collections
ROOT = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
cur = open(glob.glob(ROOT + r'\anexos\T03-*.md')[0], encoding='utf-8').read().split('\n')
old = open(ROOT + r'\_trabajo\backup-cierre-T-20261105\T03-antes-r3.md', encoding='utf-8').read().split('\n')


def occ(L):
    seen = collections.Counter(); m = {}
    for i, l in enumerate(L):
        g = re.match(r'^\| ([A-Z]+-[A-Z]+-\d+|[^|]+?) \|', l)
        if g:
            k = g.group(1); seen[k] += 1; m[(k, seen[k])] = i
    return m


mo = occ(old)
out = open(ROOT + r'\_trabajo\sync2_t03_cmp.txt', 'w', encoding='utf-8')
seen = collections.Counter()
for i, l in enumerate(cur):
    g = re.match(r'^\| ([A-Z]+-[A-Z]+-\d+|[^|]+?) \|', l)
    k = None
    if g:
        k = g.group(1); seen[k] += 1
    if 'cita en 10.9.13' in l:
        j = mo.get((k, seen[k])) if k else None
        out.write('ACT %d: %s\n' % (i + 1, l))
        out.write('R3  %s: %s\n\n' % (j + 1 if j is not None else '-', old[j] if j is not None else '(sin par)'))
