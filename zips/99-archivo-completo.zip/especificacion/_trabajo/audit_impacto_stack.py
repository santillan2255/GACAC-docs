#!/usr/bin/env python3
"""Auditoría de residuos de stack pre-GoodApps en documentación canónica."""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import date
from pathlib import Path

ESPEC = Path(__file__).resolve().parents[1]
REPO = ESPEC.parents[1]

CANONICAL_DIRS = [
    ESPEC / "anexos",
]
CANONICAL_FILES = [
    ESPEC / "00-ESPECIFICACION-MAESTRA.md",
    ESPEC / "01-registro-decisiones.md",
    ESPEC / "03-plan-de-olas-y-prompts.md",
    ESPEC / "06-impacto-adaptacion-stack-goodapps.md",
    ESPEC / "_GUIA-REDACCION-ANEXOS.md",
    ESPEC / "07-modelo-relacional-azure-sql.md",
    ESPEC / "07-catalogo-tablas-sql.md",
    REPO / "docs" / "presentacion-stakeholders",
]

PATTERNS = {
    "mongo_normative": re.compile(
        r"\b(MongoDB|Mongoose|ObjectId|Decimal128|replica set|BullMQ)\b", re.I
    ),
    "node_vue": re.compile(r"\b(Node\.js|Express\b|Vue 3|Pinia)\b", re.I),
    "dec001_row": re.compile(r"DEC-001.*Node", re.I),
    "banner_missing": re.compile(r"Norma de implementación \(DEC-111", re.I),
    "azure_sql_ok": re.compile(r"Azure SQL", re.I),
}

BANNER_MARKER = "Norma de implementación (DEC-111"


def iter_md_files() -> list[Path]:
    files: list[Path] = []
    for d in CANONICAL_DIRS:
        if d.is_dir():
            files.extend(sorted(d.glob("*.md")))
    for item in CANONICAL_FILES:
        if item.is_dir():
            for p in sorted(item.glob("*.md")):
                if "OLD" not in p.parts:
                    files.append(p)
        elif item.is_file() and item.exists():
            files.append(item)
    # dedupe
    seen: set[Path] = set()
    out: list[Path] = []
    for f in files:
        rp = f.resolve()
        if rp not in seen and "OLD" not in f.parts and "_trabajo" not in f.parts:
            seen.add(rp)
            out.append(f)
    return sorted(out)


def main() -> None:
    hits: dict[str, list[tuple[str, int, str]]] = defaultdict(list)
    banner_ok: list[str] = []
    banner_miss: list[str] = []
    azure_ok: list[str] = []

    for path in iter_md_files():
        rel = path.relative_to(REPO).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()

        if BANNER_MARKER in text:
            banner_ok.append(rel)
        elif path.parent.name == "anexos" and path.name[0] in "MT":
            banner_miss.append(rel)

        if PATTERNS["azure_sql_ok"].search(text):
            azure_ok.append(rel)

        for i, line in enumerate(lines, 1):
            for key, pat in PATTERNS.items():
                if key in ("banner_missing", "azure_sql_ok"):
                    continue
                if pat.search(line):
                    hits[key].append((rel, i, line.strip()[:120]))

    out = ESPEC / "13-auditoria-impacto-stack.md"
    today = date.today().strftime("%d-%m-%Y")
    parts = [
        f"# 13 — Auditoría de aplicación del impacto stack (CoopApps / GoodApps)",
        "",
        f"Generado automáticamente el **{today}** por `_trabajo/audit_impacto_stack.py`.",
        "Ámbito: anexos canónicos, maestro, guía, `06`, `07-*`, presentación (sin `OLD/` ni backups).",
        "",
        "## Resumen",
        "",
        f"| Métrica | Valor |",
        f"|---|---|",
        f"| Archivos revisados | {len(iter_md_files())} |",
        f"| Anexos con banner DEC-111 | {len(banner_ok)} |",
        f"| Anexos M/T sin banner | {len(banner_miss)} |",
        f"| Archivos que mencionan Azure SQL | {len(azure_ok)} |",
        f"| Líneas con tokens Mongo (revisar) | {len(hits.get('mongo_normative', []))} |",
        f"| Líneas Node/Vue (revisar) | {len(hits.get('node_vue', []))} |",
        "",
        "### Interpretación",
        "",
        "- **C-05 (19-11):** anexos M/T con nota **Barrido C-05** tras `## 7.` + banner; tokens Mongo en tablas §7 = lógico hasta barrido fino.",
        "- Residuos **no esperados** en presentación export (DIR-13) sin nota de reemplazo; entregables: **C-10 cerrado** (`00-C10-CIERRE-STACK.md`).",
        "",
        "## Anexos sin banner normativo",
        "",
    ]
    if banner_miss:
        parts.extend(f"- `{p}`" for p in banner_miss)
    else:
        parts.append("_Ninguno._")

    for key, title in [
        ("dec001_row", "DEC-001 como stack vigente (sin reemplazo explícito)"),
        ("node_vue", "Menciones Node / Vue / Express"),
        ("mongo_normative", "Menciones Mongo / Mongoose / tipos documento"),
    ]:
        parts.extend(["", f"## {title}", ""])
        group = hits.get(key, [])
        if not group:
            parts.append("_Sin hallazgos._")
            continue
        by_file: dict[str, list[tuple[int, str]]] = defaultdict(list)
        for rel, ln, snip in group:
            by_file[rel].append((ln, snip))
        for rel in sorted(by_file):
            parts.append(f"### `{rel}`")
            for ln, snip in by_file[rel][:25]:
                parts.append(f"- L{ln}: `{snip}`")
            if len(by_file[rel]) > 25:
                parts.append(f"- _… y {len(by_file[rel]) - 25} líneas más._")
            parts.append("")

    out.write_text("\n".join(parts).rstrip() + "\n", encoding="utf-8")
    print(f"Wrote {out} ({len(parts)} lines)")


if __name__ == "__main__":
    main()