﻿from conc_lib import *
L=read(T11).split('\n')
for n in list(range(2337,2346))+list(range(2466,2472))+list(range(3163,3192)):
    print(n,L[n-1][:300])
for n,l in enumerate(L,1):
    if 'JOB-INT-23' in l or 'JOB-SUE-04' in l or 'JOB-SUE-06' in l or 'JOB-SUE-19' in l or l.startswith('| CTR-WFL-12') or 'SIG-SUE-EMPLEADOR' in l or 'SIG-ACTA' in l: print(n,l[:300])
