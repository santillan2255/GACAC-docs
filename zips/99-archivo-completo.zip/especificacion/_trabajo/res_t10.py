from res_lib import Doc

d = Doc(r'anexos\T10-BIA-*.md')

# --- Cat. 5: scopes erp registrados en T02 §4.4.3 ---
d.rep('| `erp.catalog:read` | productos, stock por depósito, proveedores (datos públicos) | | — (T02 no lo lista) |',
      '| `erp.catalog:read` | productos, stock por depósito, proveedores (datos públicos) | | `stk.articulos.ver` (API-BIA-107 además `cmp.proveedores.ver`; T02 §4.4.3; antes "— (T02 no lo lista)") |')
d.rep('| `erp.finance:read` | tesorería y bancos agregados, compras | Requiere aprobación reforzada. | — (T02 no lo lista) |',
      '| `erp.finance:read` | tesorería y bancos agregados, compras | Requiere aprobación reforzada. | `tes.posicion.ver` (API-BIA-109 además `cmp.ordenes.ver`; T02 §4.4.3; antes "— (T02 no lo lista)") |')

# --- Cat. 2 y 4: referencias ---
d.rep('`scenarioId` (null en reales)', '`scenarioId` (null en reales; → `simulationScenarios` de M15)')
d.rep('`templateOriginId` (galería)', '`templateOriginId` (galería; → `customReports`)')
d.rep('`catalogQuestionId`, `semanticQuery`',
      '`catalogQuestionCode` (antes `catalogQuestionId`; código del catálogo de preguntas de la sala, configuración y no colección), `semanticQuery`')
d.rep('`indicatorSnapshots.scenarioId` → escenario de simulación del módulo dueño del indicador [VERIFICAR]',
      '`indicatorSnapshots.scenarioId` → `simulationScenarios` (M15; antes "escenario de simulación del módulo dueño del indicador [VERIFICAR]")')
d.rep('`aiQuestions.catalogQuestionId` → catálogo de preguntas de la sala (T10) [VERIFICAR colección]',
      '`aiQuestions.catalogQuestionCode` (antes `catalogQuestionId`) → código del catálogo de preguntas de la sala (configuración del anexo, no colección; antes "[VERIFICAR colección]")')
d.rep('`kpiAlertRules.indicatorCode` y `kpiAlerts.ruleId` → `indicatorDefinitions` y `kpiAlertRules` (T10)',
      '`kpiAlertRules.indicatorCode` y `kpiAlerts.ruleId` → `indicatorDefinitions` y `kpiAlertRules` (T10; T05 nombra la referencia de la regla `indicatorId` → `indicatorDefinitions`, ver §7.26)')

# --- Cat. 5: capabilities ---
for a, cap in {
    'API-BIA-06': '`bia.reportes.ver` (además `requiredCapabilities[]` del reporte de la corrida; antes "`requiredCapabilities[]` del reporte de la corrida")',
    'API-BIA-07': '`bia.reportes.ver` (además `detailCapability` del indicador o reporte, del módulo dueño del detalle; antes "`detailCapability` del indicador o reporte")',
    'API-BIA-10': '`bia.reportes.ver` (además `requiredCapabilities[]` del reporte de la corrida; antes "`requiredCapabilities[]` del reporte de la corrida")',
    'API-BIA-12': '`bia.exportaciones.crear` (además `<mod>.<recurso>.exportar` de la grilla; antes "`<mod>.<recurso>.exportar`")',
    'API-BIA-64': '`public: true` (antes "público")',
    'API-BIA-65': '`public: true` (antes "público")',
}.items():
    d.cell('| %s |' % a, 3, cap)
for a in ['API-BIA-70', 'API-BIA-71', 'API-BIA-72', 'API-BIA-73', 'API-BIA-74', 'API-BIA-129']:
    d.cell('| %s |' % a, 3, '`bia.apis.consumir` (cualquier scope; antes "(cualquiera)")')

# --- Cat. 1: tabla normalizada de las máquinas en texto ---
T = []
def r(c, a, b, disp, g='—', e='—'):
    T.append('| `%s` | %s | `%s` | %s | %s | %s |' % (c, a if a == '—' else ', '.join('`%s`' % x for x in a.split(',')), b, disp, g, e))

r('reportExports', '—', 'queued', 'Solicitud de exportación')
r('reportExports', 'queued', 'generating', 'Worker toma la exportación')
r('reportExports', 'generating', 'ready', 'Archivo generado', '—', '`bia.export.ready`')
r('reportExports', 'generating', 'failed', 'Error')
r('reportExports', 'queued,generating', 'cancelled', 'Cancelación')
r('reportExports', 'ready', 'expired', 'Pasa `expiresAt`')
r('indicatorDefinitions', '—', 'draft', 'Alta o versión nueva')
r('indicatorDefinitions', 'draft', 'certified', 'Certificación por `bia.cubos.certificar`', 'Pruebas de reconciliación OK')
r('indicatorDefinitions', 'certified', 'deprecated', 'Se publica una versión nueva')
r('apiCredentials', '—', 'active', 'Emisión de la credencial')
r('apiCredentials', 'active', 'rotating', 'Se emite el reemplazo (ambas válidas `PRM-BIA-042` horas)')
r('apiCredentials', 'rotating', 'revoked', 'Fin de la gracia')
r('apiCredentials', 'active', 'expired', 'Job de vencimiento')
r('apiCredentials', 'active', 'revoked', 'Revocación manual o por compromiso')
r('extWebhookSubscriptions', '—', 'active', 'Alta de la suscripción')
r('extWebhookSubscriptions', 'active', 'paused', 'Pausa por cliente o admin')
r('extWebhookSubscriptions', 'paused', 'active', 'Reanudación')
r('extWebhookSubscriptions', 'active', 'disabled', 'Fallas continuas ≥ `PRM-BIA-048` horas')
r('extWebhookSubscriptions', 'disabled', 'active', 'Reactivación manual tras prueba OK')
r('extWebhookDeliveries', '—', 'pending', 'Evento público emitido para la suscripción')
r('extWebhookDeliveries', 'pending', 'delivered', 'Respuesta 2xx')
r('extWebhookDeliveries', 'pending,retrying', 'failed', 'Intento sin 2xx o timeout `PRM-BIA-052` s')
r('extWebhookDeliveries', 'failed', 'retrying', 'Quedan intentos (`nextAttemptAt`)')
r('extWebhookDeliveries', 'retrying', 'delivered', 'Respuesta 2xx')
r('extWebhookDeliveries', 'failed', 'dead', 'Agotó los reintentos')
r('extWebhookDeliveries', 'dead', 'pending', 'Reenvío manual (API-BIA-50)')
r('kpiAlerts', '—', 'open', 'Se cumple la condición de la regla')
r('kpiAlerts', 'open', 'acknowledged', 'Reconocimiento del responsable')
r('kpiAlerts', 'open,acknowledged', 'resolved', 'Manual o automático (la condición deja de cumplirse `forPeriods` veces)')
r('kpiAlerts', 'open,acknowledged', 'muted', 'Silencio con vencimiento')
r('kpiAlerts', 'resolved,muted', 'open', 'Vuelve a cumplirse fuera de la ventana de deduplicación')
r('openDataPublications', '—', 'draft', 'Alta o refresco (versión nueva)')
r('openDataPublications', 'draft', 'approved', 'Aprobación por `bia.datosAbiertos.publicar`', 'Control de celdas mínimas')
r('openDataPublications', 'approved', 'published', 'Publicación')
r('openDataPublications', 'published', 'withdrawn', 'Retiro')
for b, t in [('answered', 'Respuesta con citas'), ('refused', 'Pregunta fuera de alcance o con datos personales'), ('failed', 'Error del proveedor o de la consulta')]:
    r('aiQuestions', '—', b, t)

bloque = ['### 8.12 Tabla normalizada de las máquinas de §8.3, §8.5 y §8.7 a §8.10', '',
          'Corrección del cierre de residuales (05-11-2026; PA-BIA-17): una fila por transición de las máquinas descritas en texto, con el estado de alta explícito (`—`). Prevalece el texto de cada subsección si hay diferencia. `aiQuestions` nace en su estado final. `apiClients` y `apiCredentials` son de T02 (§8.11 de T02), que prevalece. `apiUsageLogs.status` y `apiUsageDaily.status` son códigos HTTP (`200` a `599`) y no tienen máquina.', '',
          '| Colección | Desde | Hacia | Disparador | Guarda (RN) | Evento |', '|---|---|---|---|---|---|'] + T + ['']
d.before_line('Referencias de §7 sin destino explícito: `reportSchedules.lastRunId`', bloque)
d.rep('`apiUsageLogs.status` es el código HTTP de la llamada, no un estado de ciclo de vida.',
      '`apiUsageLogs.status` y `apiUsageDaily.status` son el código HTTP (`200` a `599`), no un estado de ciclo de vida (antes solo `apiUsageLogs`).')
d.rep('`scopeUsed`, `status`, `problemType`', '`scopeUsed`, `status` (código HTTP, `200` a `599`; no es estado), `problemType`')

pa = '''### PA-BIA-17 — Cierre de residuales del anexo (estados, referencias, tablas de campos y API)

- **Pregunta:** ¿cómo se cierran los residuales del anexo detectados por los entregables de análisis?
- **Contexto:** 7 máquinas de §8 estaban en texto sin estado de alta en tabla; 4 referencias no tenían destino (`scenarioId`, `templateOriginId`, `catalogQuestionId`, `indicatorId`); 59 colecciones no tenían tabla de campos; 14 filas de §11 citaban reglas en lugar de una capability; los scopes `erp.catalog:read` y `erp.finance:read` figuraban sin capability en T02; `apiUsageDaily` usaba `day` en lugar del nombre canónico `date`.
- **Opciones:**
  - A) Agregar §8.12 con una fila por transición y estado inicial; declarar destinos (`scenarioId` → `simulationScenarios` de M15, `templateOriginId` → `customReports`) y renombrar `catalogQuestionCode` (antes `catalogQuestionId`, código de configuración); renombrar `date` (antes `day`); agregar §7.26 con tablas derivadas del texto y de T05 (obligatoriedad por regla: clave única, `status`, `code`, `name` y referencias de T05 = Sí); usar `bia.reportes.ver`, `bia.exportaciones.crear`, `bia.apis.consumir` y `public: true` (con la condición o la capability adicional entre paréntesis); citar el mapeo de los scopes `erp` de T02 §4.4.3. **(Recomendada)**.
  - B) Dejar las máquinas solo en texto y las celdas como reglas.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** diagramas de estados, contratos, ER y matriz de capabilities de T10.
- **Estado:** Asumida (DEC-072): opción A.
'''
d.before_line('## 22. Trazabilidad de fuentes', pa.split('\n'))
print('T10 cambios', d.save(), 'filas', len(T))
