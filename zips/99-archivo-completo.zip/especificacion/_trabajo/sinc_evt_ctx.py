import sys, io, glob, os, re
sys.path.insert(0, os.path.dirname(__file__))
from res_evt_ren import REN
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos"
EXTRA = [
    ("EVT-STK-12", "stk.item.below-minimum", "stk.item.belowMinimum"),
    ("-", "fis.regime-file.requested", "fis.regimeFile.requested"),
    ("-", "cob.payment-intent.requested", "cob.paymentIntent.requested"),
    ("-", "cob.debt-publication.requested", "cob.debtPublication.requested"),
    ("-", "cob.direct-debit.batch-requested", "cob.directDebit.batchRequested"),
    ("-", "med.reading-route.published", "med.readingRoute.published"),
    ("-", "com.message.dispatch-requested", "com.message.dispatchRequested"),
    ("-", "per.person.fiscal-lookup-requested", "per.person.fiscalLookupRequested"),
    ("-", "tes.bank-sync.requested", "tes.bankSync.requested"),
    ("-", "tes.payment-file.requested", "tes.paymentFile.requested"),
    ("-", "sue.payroll-files.requested", "sue.payrollFiles.requested"),
    ("EVT-MOR-12", "mor.cut-order.approved", "mor.interruption.approved"),
]
MAP = REN + EXTRA
MINE = ["M%02d-*" % i for i in range(1, 20)] + ["T01-*", "T04-*", "T06-*", "T07-*", "T08-*", "T09-*", "T10-*", "T12-*"]
if __name__ == "__main__":
    files = []
    for p in MINE:
        files += sorted(glob.glob(os.path.join(ROOT, p + ".md")))
    W = int(sys.argv[1]) if len(sys.argv) > 1 else 110
    for f in files:
        t = open(f, encoding="utf-8-sig").read().replace("\r\n", "\n")
        for evt, old, new in MAP:
            for m in re.finditer(re.escape(old) + r"(?![\w-])", t):
                a = max(0, m.start() - W); b = m.end() + 40
                ln = t.count("\n", 0, m.start()) + 1
                print("%s:%d %s ::: %s" % (os.path.basename(f)[:3], ln, old, t[a:b].replace("\n", " / ")))
