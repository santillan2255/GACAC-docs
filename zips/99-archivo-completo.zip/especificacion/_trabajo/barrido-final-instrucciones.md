# Fase 3: barrido final

Mismas reglas de `_trabajo/huecos-reglas-comunes.md`. Solo editás tus archivos de siempre.

1. **Pendientes**: aplicá cada ítem de `_trabajo/pendientes-barrido-final.md` cuyo anexo destino sea uno de los tuyos. Antes de aplicar, verificá si ya está hecho (otro agente pudo haberlo resuelto) y no lo dupliques.
2. **Huecos parciales**: en `05-registro-huecos.md` (solo lectura) buscá las filas con Estado `Corregido en anexo (parcial)`; si lo pendiente cae en tus archivos, resolvelo (si es un valor legal sin fuente relevada, dejalo explícito como parámetro con default propuesto y `requiere validación legal`, que es la resolución final) e informá el ID.
3. **Renombres globales (T05 CTR-DAT-30 y otros)**: en tus archivos reemplazá `tenantServiceId` → `serviceId`; `propertyId` usado como inmueble → `premiseId`; `holderPersonId` → `holderId`; `serviceContractId` → `contractId` (salvo donde T05 lo mantenga explícitamente); subdocumentos `legacyRef`/`legacyCode`/`migration` → `legacy`; derivados de `fileId` (`imageFileId`, `evidenceFileIds`, `declarationFileId`, etc.) → `storedFileId`/`…StoredFileIds` según T05. Capability `pwa.planObra.ver` → `por.planObra.ver`. Revisá cada reemplazo en contexto (no toques citas a nombres de ProCoop ni notas de alias que expliquen el nombre viejo).
4. **Verificación**: IDs definidos una sola vez, encabezados únicos, sin `<!-- SIGUE -->`, UTF-8 sin caracteres dañados, BOM y saltos de línea originales.
5. **Informe**: por ítem (archivo, IDs, resumen); lista de RF nuevos creados en las fases 1–3 en tus archivos con su ola (para el plan de olas); eventos/jobs nuevos o con payload cambiado para T11; lo que quede sin resolver y por qué.
