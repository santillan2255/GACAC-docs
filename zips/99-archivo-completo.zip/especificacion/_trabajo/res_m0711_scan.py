import sys, os, re, json
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo')
sys.stdout.reconfigure(encoding='utf-8')
import contratos_lib as L

cols = L.leer_colecciones_t05()
for an in ['M07', 'M08', 'M09', 'M10', 'M11']:
    c7 = L.leer_campos_seccion7(an)
    propias = [(n, c) for n, c in cols.items() if c['dueno'] == an and not c['est'].startswith('A')]
    sin = [(c['id'], n) for n, c in propias if n not in c7]
    print(an, 'propias', len(propias), 'con tabla', len([1 for n, c in propias if n in c7]), 'sin', len(sin))
    for x in sin:
        print('   ', x)
