# -*- coding: utf-8 -*-
"""C-05: inserta nota normativa tras el encabezado ## 7. de cada anexo M/T (si falta)."""
from __future__ import annotations

import re
from pathlib import Path

ESPEC = Path(__file__).resolve().parents[1]
ANEXOS = ESPEC / "anexos"

MAP: dict[str, tuple[str, str]] = {
    "M01": ("per", "2.1"),
    "M02": ("cat", "2.4"),
    "M03": ("med", "2.6"),
    "M04": ("tar", "2.8"),
    "M05": ("fac", "2.7"),
    "M06": ("fis", "2.9"),
    "M07": ("cob", "2.10"),
    "M08": ("mor", "2.11"),
    "M09": ("crm", "2.12"),
    "M10": ("tec", "2.13"),
    "M11": ("ven", "2.15"),
    "M12": ("cmp", "2.16"),
    "M13": ("stk", "2.17"),
    "M14": ("tes", "2.14"),
    "M15": ("con", "2.18"),
    "M16": ("sue", "2.19"),
    "M17": ("ins", "2.20"),
    "M18": ("soc", "2.21"),
    "M19": ("por", "2.22"),
    "T01": ("pla", "2.0"),
    "T02": ("iam", "2.2"),
    "T03": ("uxd", "2.5"),
    "T04": ("cfg", "2.3"),
    "T05": ("", "2.x"),
    "T06": ("int", "2.24"),
    "T07": ("mig", "2.27"),
    "T08": ("nfr", "2.26"),
    "T09": ("com", "2.23"),
    "T10": ("bia", "2.28"),
    "T11": ("wfl", "2.25"),
}

MARKER = "Barrido C-05 (DEC-111)"
H2_7 = re.compile(r"^## 7\.[^\n]*$", re.M)


def file_prefix(name: str) -> str | None:
    if name.startswith("T04b"):
        return "T04"
    m = re.match(r"^(M\d+|T\d+)", name)
    return m.group(1) if m else None


def note_block(schema: str, sec: str) -> str:
    if schema:
        ddl = (
            f"esquema **`{schema}.*`**, `07-modelo-relacional-azure-sql.md` (seccion {sec}), "
            f"DDL `07-ddl/sql/{schema}/`"
        )
    else:
        ddl = (
            f"catalogo en `07-modelo-relacional-azure-sql.md` (seccion {sec}) "
            f"y `07-catalogo-tablas-sql.md`"
        )
    return (
        f"\n> **{MARKER}.** Las tablas y tipos que citan MongoDB, Mongoose, `ObjectId`, "
        f"BullMQ o Redis en este capitulo describen la **entidad logica** del anexo. "
        f"La implementacion vigente (DEC-111, DEC-117) es **Azure SQL** + **EF Core**: "
        f"{ddl}. Ante divergencia, prevalece `07-*` y el banner DEC-111 del anexo.\n"
    )


def insert_note(content: str, block: str) -> str | None:
    if MARKER in content:
        return None
    m = H2_7.search(content)
    if not m:
        return None
    pos = m.end()
    return content[:pos] + block + content[pos:]


def main() -> None:
    changed = 0
    skipped = 0
    for path in sorted(ANEXOS.glob("*.md")):
        if "backup" in path.name.lower():
            continue
        pre = file_prefix(path.name)
        if not pre or pre not in MAP:
            skipped += 1
            continue
        schema, sec = MAP[pre]
        block = note_block(schema, sec)
        text = path.read_text(encoding="utf-8")
        new = insert_note(text, block)
        if new is None:
            continue
        path.write_text(new, encoding="utf-8", newline="\n")
        changed += 1
        print(f"Updated {path.name}")
    print(f"Done. {changed} updated, {skipped} skipped.")


if __name__ == "__main__":
    main()