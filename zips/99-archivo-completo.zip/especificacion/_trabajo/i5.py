﻿import json,re,collections
c=collections.Counter()
for l in open('repl-log.jsonl',encoding='utf-8'):
    d=json.loads(l); c[(d['file'][-40:],d['tag'])]+=1
    if 'JOB-' in d['new'] and ('Ver JOB' in d['new'] or 'Retirado' in d['new'] or 'Reemplazado' in d['new'] or 'reacci' in d['new']):
        print(d['file'][-40:][:12], d['tag'], d['new'][:170].replace('\n',' '))
for k,v in sorted(c.items()): print(k,v)
