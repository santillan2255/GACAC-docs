"""Mapeo tipos lógicos anexo → SQL Server (Azure SQL)."""
from __future__ import annotations

import re

ARRAY_OBJ = re.compile(r"\b(array|object|subdocumento)\b", re.I)
OBJECTID = re.compile(r"\bObjectId\b", re.I)
DECIMAL128 = re.compile(r"\bDecimal128\b", re.I)
ENUM_T = re.compile(r"\benum\b", re.I)
BOOL_T = re.compile(r"\bbool(ean)?\b", re.I)
INT_T = re.compile(r"\bint(eger)?\b", re.I)
DATE_ONLY = re.compile(r"\bdate\b", re.I)
DATETIME = re.compile(r"\bDate\b|\bdatetime\b|\bdateTime\b", re.I)
STRING = re.compile(r"\bstring\b", re.I)


def camel_to_pascal(name: str) -> str:
    if not name:
        return name
    if name == "tenantId":
        return "TenantId"
    if "." in name:
        parts = name.split(".")
        return "".join(
            (p[0].upper() + p[1:]) if p else "" for p in parts
        )
    return name[0].upper() + name[1:]


def mongo_field_to_sql(field: str, type_cell: str) -> tuple[str, str, bool] | None:
    """Returns (column_name, sql_type, nullable). None = skip field (_id as doc id)."""
    field = field.replace("[]", "").strip()
    if field in ("_id",):
        return None
    if field == "tenantId":
        return ("TenantId", "UNIQUEIDENTIFIER", False)

    t = type_cell.strip()
    col = camel_to_pascal(field)

    if ARRAY_OBJ.search(t) or "array de" in t.lower() or t.strip().startswith("array"):
        return (f"{col}Json", "NVARCHAR(MAX)", True)
    if OBJECTID.search(t):
        if field.endswith("Id") or field.endswith("Ids"):
            return (col if col.endswith("Id") else f"{col}Id", "UNIQUEIDENTIFIER", True)
        return (f"{col}Id", "UNIQUEIDENTIFIER", True)
    if DECIMAL128.search(t):
        return (col, "DECIMAL(18,4)", True)
    if ENUM_T.search(t) or t.startswith("enum "):
        return (col, "VARCHAR(64)", True)
    if BOOL_T.search(t):
        return (col, "BIT", True)
    if INT_T.search(t):
        return (col, "INT", True)
    if field.endswith(("At", "On")) or col.endswith(("At", "On")):
        return (col, "DATETIME2(7)", True)
    if DATETIME.search(t):
        return (col, "DATETIME2(7)", True)
    if DATE_ONLY.search(t):
        return (col, "DATE", True)
    if STRING.search(t) or "texto" in t.lower() or "String" in t:
        if "max" in t.lower() or len(t) > 80:
            return (col, "NVARCHAR(MAX)", True)
        return (col, "NVARCHAR(512)", True)
    if "object" in t.lower() or "{" in t:
        return (f"{col}Json", "NVARCHAR(MAX)", True)
    return (col, "NVARCHAR(MAX)", True)