import sys, io, glob, re, os
sys.stdout = open(sys.argv[2], "w", encoding="utf-8")
A = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos"
PAS = sys.argv[1].split(",")
for f in sorted(glob.glob(os.path.join(A, "*.md"))):
    t = open(f, "rb").read().decode("utf-8-sig")
    for pa in PAS:
        m = re.search(r"^#{3,4} " + re.escape(pa) + r"\b.*?(?=^#{2,4} |\Z)", t, re.M | re.S)
        if m:
            print("=" * 20, os.path.basename(f), pa)
            print(m.group(0).strip())
