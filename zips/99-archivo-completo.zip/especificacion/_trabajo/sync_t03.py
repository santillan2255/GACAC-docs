from sync_lib import Doc

d = Doc('T03-*.md')

# Mapa: SM-LND-008 tiene como principal a POR-19, que en M19 declara `/recuperar` y `/restablecer/:token`
old = [l for l in d.t.split('\n') if l.startswith('| SM-LND-008 | ') and 'sin pantalla propia' in l]
assert len(old) == 1
old = old[0]
cells = old.split(' | ')
cells[1] = ('POR-19 (M19 declara en PAN-POR-19 las rutas `/ingresar`, `/recuperar` y `/restablecer/:token`: '
            'misma app y recurso; PA-UXD-19; antes "' + cells[1] + '")')
d.rep(old + '\n', ' | '.join(cells) + '\n', 'mapa')

d.cell('| Ítem SM-LND-008 | PAN-POR-19 |', 2,
       lambda c: 'Reemplazado: es la principal del ítem en 10.9.7 (PA-UXD-19; antes "otra app o recurso (AL-10)")',
       'mapa')

# Rótulo corto de la tabbar en la contraposición del maestro
d.cell('| CTR-UXD-12 |', 3,
       lambda c: c + '; rótulo corto "Cuentas" para el destino "Cuentas y servicios" (RN-UXD-006, PA-UXD-18 y PA-UXD-19; SM-PWS-002 y `dict:nav.pws.servicios`)',
       'rotulo')

pa = '''### PA-UXD-19 - Sincronización posterior a la ronda de residuales (mapa del portal y rótulo corto)

- **Pregunta:** ¿cómo queda la correspondencia de PAN-POR-19, 52, 55 y 91 con los ítems del mapa y el rótulo corto "Cuentas" de la tabbar del socio después de la ronda de residuales de M19 (PA-POR-22)?
- **Contexto:** `_trabajo/residuales-sincronizacion.md` (sección M12-M19) y el catálogo de pantallas de M19 (`17-19-M19-POR.md`), que marcaba PAN-POR-19 como principal de SM-LND-008, PAN-POR-52 de SM-LND-014, PAN-POR-55 de SM-PWS-027 y PAN-POR-91 de SM-LND-011 con app o ruta distinta. Verificado contra M19 §10: PAN-POR-19 declara `/ingresar`, `/recuperar` y `/restablecer/:token` (landing); PAN-POR-52 `/app/turnos`; PAN-POR-55 `/app/muro(/:id)`; PAN-POR-91 `/admin/portal/recepcion-publica` (admin).
- **Opciones:**
  - A) PAN-POR-19 principal de SM-LND-007 y de SM-LND-008 (misma app y recurso); PAN-POR-52 principal de SM-PWS-022 y cita de otra app en SM-LND-014; PAN-POR-55 principal de SM-PWS-027 con la ruta del anexo; PAN-POR-91 principal de SM-ADM-209 y cita de otra app en SM-LND-011; rótulo corto "Cuentas" también en CTR-UXD-12. **(Recomendada)**.
  - B) Dejar SM-LND-008 sin pantalla propia y citar PAN-POR-19 como pantalla relacionada.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** mapa de navegación (10.9.4, 10.9.7, 10.9.13) y catálogo de pantallas de M19.
- **Estado:** **Asumida (DEC-072)**, opción A. Aplicada el 5-11-2026: 10.9.7 (SM-LND-008 con POR-19), 10.9.13 (fila de SM-LND-008 y PAN-POR-19 marcada como reemplazada) y CTR-UXD-12. Ya estaban alineados SM-PWS-002 (rótulo "Cuentas"), SM-PWS-022 (POR-52), SM-PWS-027 (POR-55, `/app/muro(/:id)`), SM-ADM-209 (POR-91), SM-LND-011 (POR-13; POR-91 en 10.9.13) y SM-LND-014 (POR-19 con destino; POR-52 en 10.9.13). Ya no bloquea.
'''
d.rep('- **Bloquea:** mapa de navegación, catálogo de pantallas y contratos OpenAPI de T03.\n- **Estado:** Asumida (DEC-072): opción A.\n\n## 22.',
      '- **Bloquea:** mapa de navegación, catálogo de pantallas y contratos OpenAPI de T03.\n- **Estado:** Asumida (DEC-072): opción A.\n\n' + pa + '\n## 22.', 'PA')
d.save()
