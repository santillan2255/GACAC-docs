﻿import glob,re
def g(pat, rx):
    f=glob.glob('anexos/'+pat)[0]; s=open(f,encoding='utf-8').read()
    return [l[:170] for l in s.split('\n') if re.search(rx,l)]
print('M18 SOC-08:', g('M18-*','JOB-SOC-08'))
print('M08 COB-24:', g('M08-*','EVT-COB-24|cob\\.payment\\.informed'))
print('M19 COB-24:', g('M19-*','EVT-COB-24|cob\\.payment\\.informed'))
print('M19 SUE firma:', g('M19-*','sue\\.payslip\\.(published|issued)|EVT-SUE-14'))
print('M17 firma acta:', g('M17-*','firma digital|SIG-ACTA|DEC-078')[:4])
