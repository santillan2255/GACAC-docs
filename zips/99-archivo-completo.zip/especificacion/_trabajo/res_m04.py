from res_m0106_lib import Doc

d = Doc('M04')

TAB = '''
### 8.8 Estados iniciales completados (residuales del 05-11-2026)

Ronda de residuales del 05-11-2026 (PA-TAR-21, DEC-072): estado de alta explícito de las máquinas de §8.3 y §8.6, que lo daban por implícito. Las cadenas de §8.3 y §8.6 no cambian.

| Entidad | Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |
|---|---|---|---|---|---|
| `subsidyEnrollments` | — | `active` | Confirmación de padrón (§8.2), alta manual o pedido del socio (`source`) | Fecha efectiva; la retroactiva exige `tar.excepciones.aprobar` | `tar.enrollment.changed` |
| `subsidyEnrollments` | `suspended` | `ended` | Baja del padrón, vencimiento o baja del contrato durante la suspensión | — | `tar.enrollment.changed` |
| `calculationRuns` | — | `queued` | Pedido de cálculo (lote de M05, individual, simulación, retroactivo o re-tasación) | — | — |
'''
d.insert_before('\n## 9. ', TAB, '1')

# --- Categoría 2: referencias ---
d.rep("| `sourceScheduleId` | ObjectId | No | Versión de la que se copió. Referencia: `tariffSchedules` (M04). |",
      "| `sourceScheduleId` | ObjectId | No | Versión de la que se copió. Referencia: → `tariffSchedules` (M04). |", '2')
d.rep("`rightId` (derecho de M18, para `right_acquisition`), `levyEventId` (id del evento EVT-TEC-25 que lo creó)",
      "`rightId` (derecho de M18, para `right_acquisition`; → `burialRights` (M18, COL-SOC-22), PA-DAT-04), `levyEventId` (id del evento EVT-TEC-25 que lo creó; no es referencia a una colección: es el `eventId` del sobre del evento, usado para idempotencia)", '2')

# --- Categoría 3: tabla de `calculations` sin ancla ---
d.rep("\n`calculations` (una por cuenta/comprobante propuesto):\n",
      "\n**`calculations`** (una por cuenta/comprobante propuesto):\n", '3')
d.anchor_field_tables('3')

# --- Categoría 4: nombre canónico del servicio de M06 (M06 §9.6/§11.1) ---
c = d.t.count('`fis.calculateTaxes`')
d.t = d.t.replace('`fis.calculateTaxes`', '`fis.service.calculateTaxes` (antes `fis.calculateTaxes`)')
d.count('4', c)

# --- Categoría 5: API pública sin capability (convención RF-IAM-061) ---
d.rep("| — (pública sin login si el tenant publica, sin capability; antes `public.cuadros.ver`) |",
      "| `public: true` (sin capability, RF-IAM-061; solo si el tenant publica; antes «— (pública sin login…)» y antes `public.cuadros.ver`) |", '5')

PA = '''
### PA-TAR-21 — Residuales de estados, referencias y nombres (ronda del 05-11-2026)
- **Pregunta:** ¿Se confirman los estados de alta de `subsidyEnrollments` y `calculationRuns`, los destinos de `rightId` y `levyEventId`, el nombre del servicio fiscal y la marca pública de API-TAR-061?
- **Contexto:** al regenerar los entregables, 06a §7 marcó 2 máquinas de M04 sin estado inicial; 03-er marcó 12 colecciones sin tabla asociada y referencias sin destino; M06 §11.1 nombra el servicio `fis.service.calculateTaxes`; API-TAR-061 tenía la celda de capability vacía.
- **Opciones:**
  - A) **(Recomendada)** Declarar en §8.8 `subsidyEnrollments` inicial `active` (más `suspended → ended`) y `calculationRuns` inicial `queued`; `rightId` → `burialRights` (M18); `levyEventId` es el `eventId` del sobre, no una colección; usar `fis.service.calculateTaxes`; API-TAR-061 con `public: true` (RF-IAM-061).
  - B) Crear un estado `pending` para inscripciones de padrón no confirmadas.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** 06 (estados), 03 (ER), 05 (contratos de API).
- **Estado:** Asumida (DEC-072): opción A. Aplicado en §6 (RN-TAR-167), §7.16, §7.19, §8.8, §9 (P15) y §11.
'''
d.insert_before('\n## 22. ', PA, 'PA')
d.save()
