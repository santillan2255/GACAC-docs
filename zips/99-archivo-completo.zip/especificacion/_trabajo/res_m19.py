﻿import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from res_lib_m12m19 import Doc

d = Doc('M19-POR-portal-socio-landing.md')

# Cat 6: consumo de EVT-INS-08 con el nombre nuevo
d.rep('| `ins.capital.movement.recorded` (EVT-INS-08) | M17 | Invalida la caché de capital social en "Mi asociación" (PAN-POR-102). Consumo declarado en T11 §12 |',
      '| `ins.capitalMovement.recorded` (EVT-INS-08; antes `ins.capital.movement.recorded`, alias en T11 §12.4, PA-INS-13 de M17) | M17 | Invalida la caché de capital social en "Mi asociación" (PAN-POR-102). Consumo declarado en T11 §12 |', cat=6)

# PAN-POR-105: nombre de la pantalla
d.rep('| PAN-POR-105 | pwa-socio | `/app/comunidad` | `por.portal.ver`; cada pestaña exige además la capability de T09 (`com.wall.ver` muro y novedades, `com.surveys.responder` encuestas) | Destino "Comunidad" de la tabbar',
      '| PAN-POR-105 | pwa-socio | `/app/comunidad` | `por.portal.ver`; cada pestaña exige además la capability de T09 (`com.wall.ver` muro y novedades, `com.surveys.responder` encuestas) | **Comunidad**: destino "Comunidad" de la tabbar', cat=8)

# Cat 8: rótulo corto de la tabbar
d.rep('- **Tabbar por espacio**: socio = Inicio · Cuentas y servicios · (+) · Gestiones · Comunidad, con Perfil desde el avatar de la topbar y FAB = Pagar por defecto (',
      '- **Tabbar por espacio**: socio = Inicio · Cuentas y servicios · (+) · Gestiones · Comunidad, con Perfil desde el avatar de la topbar y FAB = Pagar por defecto; en la tabbar el destino "Cuentas y servicios" usa el rótulo corto **"Cuentas"** (RN-UXD-006, máximo 12 caracteres; el título de la pantalla sigue siendo "Cuentas y servicios"; PA-POR-22) (', cat=8)
d.rep('la tabbar del socio es Inicio · Cuentas y servicios · (+) · Gestiones · Comunidad, con Perfil desde el avatar',
      'la tabbar del socio es Inicio · Cuentas y servicios (rótulo corto "Cuentas", RN-UXD-006) · (+) · Gestiones · Comunidad, con Perfil desde el avatar', cat=8)

# Cat 2: referencias
d.rep('| `revokedAt` / `revokedBy` / `revokeReason` | Date / ObjectId / String | No |  | `memberships` (T02) (solo `revokedBy`) |',
      '| `revokedAt` | Date | No | Antes en una fila conjunta con `revokedBy` y `revokeReason` (PA-POR-22) | — |\n'
      '| `revokedBy` | ObjectId | No | Usuario que revocó | `memberships` (T02) |\n'
      '| `revokeReason` | String | No | Motivo de la revocación | — (texto, no es referencia) |', cat=2)
d.rep('| `cashboxId` | ObjectId | Sí | Caja M07 asociada | `cashRegisters` (M07) [VERIFICAR] (T05 podría nombrar el campo `cashRegisterId`) |',
      '| `cashboxId` | ObjectId | Sí | Caja M07 asociada | `cashRegisters` (M07); antes `[VERIFICAR]` (T05 podría nombrar el campo `cashRegisterId`); T05 no declara otro nombre y se conserva `cashboxId` (PA-POR-22) |', cat=2)
d.rep('| `clientMutationId` | String | No | Para sincronización offline | — |',
      '| `clientMutationId` | String | No | Para sincronización offline | — (identificador de la mutación offline generado por el cliente, no es referencia) |', cat=2)

# Cat 1: estado inicial explícito
d.rep('### 8.4. `portalForms.status`\n\n`borrador` →', '### 8.4. `portalForms.status`\n\nEstado inicial: `borrador` (alta → `borrador`; PA-POR-22).\n\n`borrador` →', cat=1)
d.rep('### 8.8. `kioskDevices.status`\n\n`activo` ↔', '### 8.8. `kioskDevices.status`\n\nEstado inicial: `activo` (alta → `activo`, al registrar el dispositivo; PA-POR-22).\n\n`activo` ↔', cat=1)

d.insert_before('## 22. Trazabilidad de fuentes', '''### PA-POR-22 - Residuales del 05-11-2026 (estados, referencias, rótulo corto y nombre de PAN-POR-105)
- **Pregunta:** ¿Cómo se cierran los residuales de M19 que detectaron los entregables regenerados?
- **Contexto:** el índice de estados marcó `portalForms` y `kioskDevices` sin estado inicial; el modelo entidad-relación, `revokeReason`, `accessId` y `cashboxId` sin destino; el catálogo de pantallas, la fila de PAN-POR-105 sin nombre; RN-UXD-006 limita a 12 caracteres el rótulo de la tabbar y "Cuentas y servicios" tiene 19; M17 renombró EVT-INS-08.
- **Opciones:**
  - A) Estado inicial `borrador` en `portalForms` y `activo` en `kioskDevices`; separar la fila de revocación para que solo `revokedBy` apunte a `memberships`; confirmar `cashboxId` → `cashRegisters` (M07) sin renombrar; nombrar PAN-POR-105 "Comunidad"; rótulo corto "Cuentas" en la tabbar con el título completo en la pantalla; consumir `ins.capitalMovement.recorded` **(Recomendada)**.
  - B) Mantener el texto y resolver en los entregables.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** §7.3, §7.14, §8.4, §8.8, §10.1, §10.3, §12.2.
- **Estado:** Asumida la recomendada (DEC-072). T03 debe usar el rótulo corto "Cuentas" en SM-PWS-002 y en la clave de diccionario de la tabbar.

''', cat=0)
d.save()
