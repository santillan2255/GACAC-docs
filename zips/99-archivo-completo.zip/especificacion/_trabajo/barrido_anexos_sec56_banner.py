# -*- coding: utf-8 -*-
"""Banner §5–§6: comportamiento vigente; stack → 03-norma (sin reescribir RF)."""
from __future__ import annotations

import re
from pathlib import Path

ANEXOS = Path(__file__).resolve().parents[1] / "anexos"

BANNER = (
    "> **Barrido transversal (19-11-2026, DEC-111).** Los RF/RN de **§5–§6** definen comportamiento "
    "aceptado. Citas a MongoDB, Mongoose, BullMQ, Vue o npm son **mecanismos históricos Connectia** "
    "o columnas de contraste; en build GoodApps prevalecen `03-norma-ejecucion-goodapps.md` §3–§4, "
    "`07-ddl` y §7 de este anexo. No reinterpretar alcance sin nueva DEC.\n\n"
)

MARKER = "Barrido transversal (19-11-2026"

H2_5 = re.compile(r"^## 5\.\s", re.M)
H2_6 = re.compile(r"^## 6\.\s", re.M)
H2_NEXT = re.compile(r"^## [67]\d*\.|^## [89]\.|^## 1[0-9]\.", re.M)


def insert_after_h2(content: str, h2_pat: re.Pattern[str]) -> str:
    if MARKER in content:
        return content
    m = h2_pat.search(content)
    if not m:
        return content
    line_end = content.find("\n", m.start())
    if line_end < 0:
        return content
    return content[: line_end + 1] + "\n" + BANNER + content[line_end + 1 :]


def main() -> None:
    n = 0
    for path in sorted(ANEXOS.glob("*.md")):
        if "backup" in path.name.lower():
            continue
        raw = path.read_text(encoding="utf-8")
        new = insert_after_h2(raw, H2_5)
        new = insert_after_h2(new, H2_6)
        if new != raw:
            path.write_text(new, encoding="utf-8", newline="\n")
            n += 1
            print(path.name)
    print(f"Done. {n} files.")


if __name__ == "__main__":
    main()