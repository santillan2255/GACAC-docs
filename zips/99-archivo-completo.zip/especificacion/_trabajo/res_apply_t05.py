import sys, io, glob, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
F = glob.glob(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T05-*")[0]
raw = open(F, "rb").read()
assert not raw.startswith(b"\xef\xbb\xbf")
txt = raw.decode("utf-8")
assert "\r\n" in txt and "\n" not in txt.replace("\r\n", "")
NL = "\r\n"
lines = txt.split(NL)

cnt = {}
def bump(k, n=1):
    cnt[k] = cnt.get(k, 0) + n

def rep(old, new, k, n=1):
    global lines
    t = NL.join(lines)
    c = t.count(old)
    assert c == n, (old[:90], c)
    t = t.replace(old, new)
    lines = t.split(NL)
    bump(k)

def row_index(colid):
    idx = [i for i, l in enumerate(lines) if l.startswith("| " + colid + " |")]
    assert len(idx) == 1, colid
    return idx[0]

COLS = {"claves": 5, "unicos": 6, "est": 11, "proposito": 4}
def set_cells(colid, k, expect=None, **cells):
    i = row_index(colid)
    parts = lines[i].split("|")
    assert len(parts) == 13, (colid, len(parts))
    for key, val in cells.items():
        j = COLS[key]
        old = parts[j].strip()
        if expect and key in expect:
            assert old == expect[key], (colid, key, old)
        parts[j] = " " + val + " "
    lines[i] = "|".join(parts)
    bump(k)

def al(mod, antes):
    return "(5-11-2026, residuales: alineado a %s §7; antes %s)" % (mod, antes)

# ---------- R -> C ----------
for cid in ["COL-BIA-30", "COL-FIS-09", "COL-MOR-27", "COL-MOR-34", "COL-TEC-04", "COL-INS-01"]:
    set_cells(cid, "R->C", expect={"est": "R"}, est="C (antes `R`)")
rep("M17 debe declarar la colección con ese nombre y la fila pasa de `R` a `C` cuando lo haga |",
    "M17 debe declarar la colección con ese nombre y la fila pasa de `R` a `C` cuando lo haga (5-11-2026: M17 ya la declara como `associateMemberships`; pasa a `C`) |", "R->C-nota")
rep("- **Est.**: `C` canónica (crear); `R` crear con el nombre indicado en lugar del declarado;",
    "- **Est.**: `C` canónica (crear); `R` crear con el nombre indicado en lugar del declarado (5-11-2026: no queda ninguna `R`; las 6 que había pasaron a `C (antes R)` porque sus anexos dueños ya declaran el nombre nuevo);", "R->C-leyenda")
# tabla de control 7.7.10
for pref, old, new in [("T10 | BIA | 69 | 69 | 67 | 2 | 1 | 0", None, "T10 | BIA | 69 | 69 | 67 | 2 | 0 (antes 1) | 0"),
                       ("M06 | FIS | 47 | 47 | 47 | 0 | 1 | 0", None, "M06 | FIS | 47 | 47 | 47 | 0 | 0 (antes 1) | 0"),
                       ("M08 | MOR | 39 | 39 | 39 | 0 | 2 | 0", None, "M08 | MOR | 39 | 39 | 39 | 0 | 0 (antes 2) | 0"),
                       ("M10 | TEC | 76 | 76 | 75 | 1 | 1 | 0", None, "M10 | TEC | 76 | 76 | 75 | 1 | 0 (antes 1) | 0"),
                       ("M17 | INS | 36 | 36 | 35 | 1 | 1 | 0", None, "M17 | INS | 36 | 36 | 35 | 1 | 0 (antes 1) | 0")]:
    rep("| " + pref + " |", "| " + new + " |", "R->C-control")
rep("| **Total** | — | **1.108** | **1.108** | **1.057** | **51** | **6** | **0** |",
    "| **Total** | — | **1.108** | **1.108** | **1.057** | **51** | **0** (antes 6) | **0** |", "R->C-control")
rep("Cifras anteriores: 1.107 filas, 1.107 declaradas, 1.056 a crear.",
    "Cifras anteriores: 1.107 filas, 1.107 declaradas, 1.056 a crear." + NL + NL +
    "Actualización por los residuales del 5-11-2026: las 6 filas `R` (COL-BIA-30, COL-FIS-09, COL-MOR-27, COL-MOR-34, COL-TEC-04 y COL-INS-01) pasan a `C` porque sus anexos dueños ya declaran la colección con el nombre del catálogo (misma regla que fijaba COL-INS-01). No cambian las filas (1.108), las declaradas (1.108), las colecciones a crear (1.057) ni las absorbidas (51); las renombradas pasan de 6 a 0.", "R->C-control")
rep("- Las 6 renombradas: `reportRunResults`", "- Las 6 que eran renombradas (hoy `C`, 5-11-2026): `reportRunResults`", "R->C-control")

# ---------- apiUsageDaily ----------
set_cells("COL-BIA-23", "apiUsageDaily", expect={"unicos": "`{apiClientId, date}`"},
          unicos="`{apiClientId, day}` " + al("T10", "`{apiClientId, date}`"))

# ---------- vatRates / taxDefinitions: cuentas por entidad ----------
set_cells("COL-FIS-16", "cuentas-fiscales",
          claves="Cuentas contables en `entityAccountAssignments` (COL-CON-38, `entityType = vatRate`, `usage` `sales`, `purchases`, `salesPerception`; PA-DAT-04, Asumida DEC-072; M06 no guarda `ledgerAccountId`). Antes \"`accounts{sales, purchases, salesPerception}` → `ledgerAccounts` (antes `ledgerAccountIds`) [VERIFICAR con COL-CON-38: las cuentas por entidad van a `entityAccountAssignments`]\"")
set_cells("COL-FIS-18", "cuentas-fiscales",
          claves="Cuentas contables en `entityAccountAssignments` (COL-CON-38, `entityType = taxDefinition`; PA-DAT-04, Asumida DEC-072; M06 no guarda `ledgerAccountId`). Antes \"`accountMap` → `ledgerAccounts` (antes `ledgerAccountIds`) [VERIFICAR con COL-CON-38]\"")

# ---------- destinos puntuales en filas ----------
rep("`rightId` (M18) | `{contractId, workCode}`", "`rightId` → `burialRights` (COL-SOC-22, M18; cuotas de adquisición de derecho, `right_acquisition`; PA-DAT-04) | `{contractId, workCode}`", "cat2-destino")
rep("| `associateMembershipId`, `paymentOrderRef` | `number` |", "| `associateMembershipId`, `paymentOrderRef` → `paymentOrders` (COL-CMP-15, M12; PA-DAT-04) | `number` |", "cat2-destino")

# ---------- §7.2.1 [VERIFICAR] ----------
P = "PA-DAT-04, Asumida DEC-072"
rep("| `templateId` | M12 `supplierCorrespondence`, T02 `auditMessages` | `messageTemplates` [VERIFICAR] | T09 |",
    "| `templateId` | M12 `supplierCorrespondence`, T02 `auditMessages` | `messageTemplates` (COL-COM-36; %s; antes \"`messageTemplates` [VERIFICAR]\") | T09 |" % P, "7.2.1")
rep("| `templateId` | M08 `suspensionRestrictionRules` | Código de plantilla de plataforma: no es referencia [VERIFICAR] | M08 |",
    "| `templateId` | M08 `suspensionRestrictionRules` | `code` de la fila de plataforma de la misma colección (alcance `T+P`): clave natural, no ObjectId (%s; antes \"Código de plantilla de plataforma: no es referencia [VERIFICAR]\") | M08 |" % P, "7.2.1")
rep("| `templateId` | M10 `connectionEstimates`, M17 `memberCredentials` | `documentTemplates` [VERIFICAR] | T11 |",
    "| `templateId` | M10 `connectionEstimates`, M17 `memberCredentials` | `documentTemplates` (COL-WFL-41; %s; antes \"`documentTemplates` [VERIFICAR]\") | T11 |" % P, "7.2.1")
rep("| `deviceId` | M10 `syncMutations`, M03 `readingTasks` | `fieldDevices` (M03 [VERIFICAR]) | M10 |",
    "| `deviceId` | M10 `syncMutations`, M03 `readingTasks` | `fieldDevices` (COL-TEC-28): M03 usa los mismos dispositivos de campo de M10 (%s; antes \"`fieldDevices` (M03 [VERIFICAR])\") | M10 |" % P, "7.2.1")
rep("| `deviceId` | M16 `timePunches`, T06 `localAgentCommands` | Dispositivo de `localAgents` (M16 [VERIFICAR]) | T06 |",
    "| `deviceId` | M16 `timePunches`, T06 `localAgentCommands` | `deviceId` del dispositivo embebido en `localAgents.devices[]` (COL-INT-16): identificador del subdocumento, no ObjectId de colección; M16 lo usa para el reloj de fichada (%s; antes \"Dispositivo de `localAgents` (M16 [VERIFICAR])\") | T06 |" % P, "7.2.1")
rep("| `targetAccountId` | M08 `agreements` | `accounts` (cuenta de servicios) [VERIFICAR] | M01 |",
    "| `targetAccountId` | M08 `agreements` | `accounts` (COL-PER-05, cuenta de servicios destino del convenio; %s; antes \"`accounts` (cuenta de servicios) [VERIFICAR]\") | M01 |" % P, "7.2.1")
rep("| `importBatchId` | T02 `legacyAuditRecords`, M08 `interestIndexValues`, M11 `salesOrders` | `migrationBatches` [VERIFICAR para M08 y M11: puede ser un lote de importación propio] | T07 |",
    "| `importBatchId` | T02 `legacyAuditRecords`, M11 `salesOrders` | `migrationBatches` (%s; antes la fila incluía M08 `interestIndexValues` y decía \"`migrationBatches` [VERIFICAR para M08 y M11: puede ser un lote de importación propio]\") | T07 |" % P + NL +
    "| `importBatchId` | M08 `interestIndexValues` | `masterImportJobs` (COL-CFG-36): importación de índices desde planilla, no migración (%s) | T04 |" % P, "7.2.1")
rep("| `projectId` | M11 `salesQuotes`, M13 `stockMovements`, `revaluations` | `crmProjects` [VERIFICAR: M13 puede referirse a obras de M18] | M09 |",
    "| `projectId` | M11 `salesQuotes` | `crmProjects` (%s; antes la fila incluía M13 y decía \"`crmProjects` [VERIFICAR: M13 puede referirse a obras de M18]\") | M09 |" % P + NL +
    "| `projectId` | M13 `stockMovements`, `revaluations` | `works` (COL-TEC-46): obra a la que se imputa el material; las obras de vivienda de M18 también se registran en `works` (%s) | M10 |" % P, "7.2.1")
rep("| `taxRateIds` | M04 `tariffCategoryRates`, `tariffRows`, `productPrices` | `vatRates` o `taxDefinitions` según el tributo (confirmado por PA-TAR-20, Asumida DEC-072) | M06 |",
    "| `taxRateIds` | M04 `tariffCategoryRates`, `tariffRows`, `productPrices` | `vatRates` (COL-FIS-16), solo alícuotas de IVA; los demás tributos y percepciones del renglón van en `taxIds` → `taxDefinitions` (%s; antes \"`vatRates` o `taxDefinitions` según el tributo (confirmado por PA-TAR-20, Asumida DEC-072)\"). M04 debe separar los dos campos | M06 |" % P, "7.2.1")
rep("| `lineId` | T10 `bi_fact_invoiceLine` | `billableItems` [VERIFICAR] | M05 |",
    "| `lineId` | T10 `bi_fact_invoiceLine` | Renglón embebido `invoices.lines[].lineId` (COL-FAC-13): la fila analítica es un renglón de factura, no un ítem facturable (%s; antes \"`billableItems` [VERIFICAR]\") | M05 |" % P, "7.2.1")
rep("| `memberId` | M05 `billingRunItems`, M09 `crmProcedureRecords` | `associateMemberships` [VERIFICAR]; canónico `associateMembershipId` (PA 9 del cierre) | M17 |",
    "| `memberId` | M05 `billingRunItems`, M09 `crmProcedureRecords` | `associateMemberships` (COL-INS-01); canónico `associateMembershipId` (PA 9 del cierre); M05 y M09 deben renombrar (%s; antes \"`associateMemberships` [VERIFICAR]\") | M17 |" % P, "7.2.1")
rep("| `paymentId` | T10 `bi_fact_payment`, `bi_fact_allocation` | `cashOperations` o `receipts` [VERIFICAR] | M07 |",
    "| `paymentId` | T10 `bi_fact_payment`, `bi_fact_allocation` | `receipts` (COL-COB-12): el hecho analítico es el cobro con recibo; canónico `receiptId` (%s; antes \"`cashOperations` o `receipts` [VERIFICAR]\") | M07 |" % P, "7.2.1")
rep("| `unitId` | M01 `servicePoints` | Unidad embebida en `premises` [VERIFICAR] | M01 |",
    "| `unitId` | M01 `servicePoints` | Subdocumento `premises.units` (COL-PER-08; M01 §7 lo declara así): identificador de la unidad dentro del inmueble, no ObjectId de colección (%s; antes \"Unidad embebida en `premises` [VERIFICAR]\") | M01 |" % P, "7.2.1")
# filas nuevas 7.2.1
anchor = "| `unitId` | M18 `cemeteryActs` | `burialUnits` | M18 |"
rep(anchor, anchor + NL +
    "| `rightId` | M04 `worksInstallmentPlans` (`planKind = right_acquisition`) | `burialRights` (COL-SOC-22) (%s; agregado el 5-11-2026) | M18 |" % P + NL +
    "| `paymentOrderRef` | M17 `capitalRefunds` | `paymentOrders` (COL-CMP-15): orden de pago del reembolso (%s; agregado el 5-11-2026) | M12 |" % P, "7.2.1-nueva")

open("_tmp_t05_state.txt", "w", encoding="utf-8").write(repr(cnt))
OUT = NL.join(lines)
open(F, "wb").write(OUT.encode("utf-8"))
print(cnt)
