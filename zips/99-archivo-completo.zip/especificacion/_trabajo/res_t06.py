import re
from res_lib import Doc

d = Doc(r'anexos\T06-INT-*.md')


def camel(s):
    p = s.split('-')
    return p[0] + ''.join(x[:1].upper() + x[1:] for x in p[1:])


# --- Cat. 6: tipos de evento con guiones -> camelCase ---
TOK = re.compile(r'\bint\.([a-z][A-Za-z0-9-]*)\.([a-z][A-Za-z0-9-]*)\b')
renombres = {}
for m in TOK.finditer(d.t):
    old = m.group(0)
    if '-' in old:
        renombres[old] = 'int.%s.%s' % (camel(m.group(1)), camel(m.group(2)))
# capabilities ya corregidas con "antes": no son eventos
for k in [k for k in renombres if k.startswith(('int.operaciones.', 'int.bitacora.'))]:
    del renombres[k]

ls = d.t.split('\n')
alias_por_evt = {}
for i, l in enumerate(ls):
    if not any(o in l for o in renombres):
        continue
    if l.startswith('| EVT-INT-'):
        cells = l.split(' | ')
        olds = [o for o in renombres if '`%s`' % o in cells[1]]
        for o in olds:
            cells[1] = cells[1].replace('`%s`' % o, '`%s`' % renombres[o])
        cells[2] = cells[2] + ' (alias: ' + ', '.join('`%s` antes `%s`' % (renombres[o], o) for o in olds) + ')'
        alias_por_evt[cells[0].strip('| ')] = olds
        ls[i] = ' | '.join(cells)
    else:
        # referencias fuera del catálogo: nombre nuevo (el alias está en §12)
        for o, n in renombres.items():
            ls[i] = re.sub(re.escape(o) + r'(?![A-Za-z0-9-])', n, ls[i])
d.t = '\n'.join(ls)
d.n += len(renombres)
print('eventos renombrados', len(renombres))
for o, n in sorted(renombres.items()):
    print('  ', o, '->', n)

# --- Cat. 2 y 4: referencias ---
d.rep('| `fallbackConnectionIds` | ObjectId[] | No | Cadena de respaldo (RF-INT-010). |',
      '| `fallbackConnectionIds` | ObjectId[] | No | Cadena de respaldo (RF-INT-010); → `integrationConnections`. |')
c = d.t.count('`externalTransactionId`')
d.t = d.t.replace('`integrationFileExchanges.externalTransactionId` →', '`integrationFileExchanges.externalTransactionNumber` (antes `externalTransactionId`) →')
d.t = re.sub(r'`externalTransactionId`(?! →)(?!\) →)', '`externalTransactionNumber` (antes `externalTransactionId`; número de transacción del ente, no referencia)', d.t, count=1)
d.n += 1
d.rep('`affectedOperations` (conteo), `closingReconciliationId`, `status` (§8.9).',
      '`affectedOperations` (conteo), `closingReconciliationId` (→ `integrationReconciliations`), `status` (§8.9).')

# --- Cat. 5: celdas de capability ---
for a, cap in {
    'API-INT-30': '`public: true` (requiere firma del proveedor; antes "Firma del proveedor")',
    'API-INT-31': '`public: true` (requiere token de verificación; antes "Token de verificación")',
    'API-INT-47': '`int.agentes.ejecutar` (identidad de dispositivo del agente, S-AGT; antes "Identidad de dispositivo")',
    'API-INT-48': '`public: true` (requiere código de emparejamiento de un uso; antes "Código de emparejamiento")',
}.items():
    d.cell('| %s |' % a, 3, cap)

# --- Cat. 1: estados iniciales y transiciones en tabla ---
filas = [
    ('integrationSecrets.status', '—', 'pending', 'Carga del secreto en la bóveda'),
    ('integrationSecrets.status', 'pending', 'active', 'Prueba de conexión correcta'),
    ('integrationSecrets.status', 'active', 'rotated', 'Nueva versión activa (gracia PRM-INT-009)'),
    ('integrationSecrets.status', 'rotated', 'revoked', 'Fin de la gracia de rotación'),
    ('integrationSecrets.status', 'active', 'expired', 'Pasa `expiresAt`'),
    ('integrationSecrets.status', 'active', 'revoked', 'Incidente (la conexión pasa a `blocked_credential` si no hay otra versión activa)'),
    ('integrationCertificates.status', '—', 'csr_generated', 'Generación del CSR'),
    ('integrationCertificates.status', 'csr_generated', 'pending_upload', 'Descarga del CSR'),
    ('integrationCertificates.status', 'pending_upload', 'active', 'Certificado subido y validado'),
    ('integrationCertificates.status', 'active', 'expiring', 'Faltan 30 días o menos para el vencimiento'),
    ('integrationCertificates.status', 'expiring', 'expired', 'Vencimiento'),
    ('integrationCertificates.status', 'active', 'superseded', 'Otro certificado activado'),
    ('integrationCertificates.status', 'expiring', 'superseded', 'Otro certificado activado'),
    ('integrationCertificates.status', 'csr_generated', 'revoked', 'Revocación'),
    ('integrationCertificates.status', 'pending_upload', 'revoked', 'Revocación'),
    ('integrationCertificates.status', 'active', 'revoked', 'Revocación'),
    ('integrationCertificates.status', 'expiring', 'revoked', 'Revocación'),
    ('webhookInbox.status', '—', 'received', 'Llega el webhook (API-INT-30)'),
    ('webhookInbox.status', 'received', 'rejected', 'Firma o IP inválida'),
    ('webhookInbox.status', 'received', 'verified', 'Firma válida'),
    ('webhookInbox.status', 'received', 'duplicate', '`dedupKey` ya existente'),
    ('webhookInbox.status', 'verified', 'processing', 'El worker toma el webhook'),
    ('webhookInbox.status', 'processing', 'processed', 'Procesamiento correcto'),
    ('webhookInbox.status', 'processing', 'failed', 'Error de procesamiento'),
    ('webhookInbox.status', 'failed', 'processing', 'Reintento'),
    ('integrationFileExchanges.status', '—', 'generated', 'Generación del archivo saliente'),
    ('integrationFileExchanges.status', '—', 'received', 'Recepción del archivo entrante (manual, SFTP o API)'),
    ('integrationFileExchanges.status', 'generated', 'approved', 'Aprobación (si la ficha la exige)'),
    ('integrationFileExchanges.status', 'generated', 'delivered', 'Entrega sin aprobación'),
    ('integrationFileExchanges.status', 'approved', 'delivered', 'Descarga registrada o SFTP correcto'),
    ('integrationFileExchanges.status', 'delivered', 'acknowledged', 'Acuse del ente'),
    ('integrationFileExchanges.status', 'delivered', 'rejected_by_provider', 'Rechazo del ente'),
    ('integrationFileExchanges.status', 'generated', 'superseded', 'Regeneración'),
    ('integrationFileExchanges.status', 'received', 'parsed', 'Parseo por layout'),
    ('integrationFileExchanges.status', 'received', 'duplicate', 'Hash ya recibido'),
    ('integrationFileExchanges.status', 'parsed', 'validated', 'Validación por línea'),
    ('integrationFileExchanges.status', 'validated', 'applied', 'Confirmación: todas las líneas aplicadas'),
    ('integrationFileExchanges.status', 'validated', 'partially_applied', 'Confirmación con líneas rechazadas'),
    ('integrationFileExchanges.status', 'validated', 'failed', 'Error al aplicar'),
    ('integrationReconciliations.status', '—', 'open', 'Apertura de la conciliación del período'),
    ('integrationReconciliations.status', 'open', 'in_review', 'Hay diferencias'),
    ('integrationReconciliations.status', 'in_review', 'open', 'Recalcular'),
    ('integrationReconciliations.status', 'open', 'closed', 'Cierre sin diferencias (`int.conciliaciones.aprobar`)'),
    ('integrationReconciliations.status', 'in_review', 'closed', 'Cierre sin diferencias abiertas (`int.conciliaciones.aprobar`)'),
    ('integrationReconciliations.status', 'in_review', 'closed_with_differences', 'Cierre con diferencias explicadas (`int.conciliaciones.aprobar`)'),
    ('integrationContingencies.status', '—', 'declared', 'Declaración de la contingencia'),
    ('integrationContingencies.status', 'declared', 'active', 'Aprobación (si la ficha la exige)'),
    ('integrationContingencies.status', 'declared', 'cancelled', 'Cancelación'),
    ('integrationContingencies.status', 'active', 'closing', 'Conexión recuperada; conciliación en curso'),
    ('integrationContingencies.status', 'closing', 'closed', 'Conciliación de cierre aprobada'),
    ('localAgents.status', '—', 'pairing', 'Alta del agente con código de emparejamiento (API-INT-48)'),
    ('localAgents.status', 'pairing', 'online', 'Emparejamiento correcto y primer latido'),
    ('localAgents.status', 'online', 'offline', 'Sin latido por PRM-INT-050'),
    ('localAgents.status', 'offline', 'online', 'Vuelve el latido'),
    ('localAgents.status', 'online', 'outdated', 'Versión menor a la mínima'),
    ('localAgents.status', 'outdated', 'online', 'Actualización del agente'),
    ('localAgents.status', 'online', 'revoked', 'Baja del agente'),
    ('localAgents.status', 'offline', 'revoked', 'Baja del agente'),
]
bloque = ['### 8.13 Tabla normalizada de las máquinas de §8.2, §8.3 y §8.6 a §8.10', '',
          'Corrección del cierre de residuales (05-11-2026; PA-INT-27): una fila por transición de las máquinas descritas en texto, con el estado de alta explícito (`—`). Prevalece el texto de cada subsección si hay diferencia.', '',
          '| Colección | Desde | Hacia | Disparador | Guarda (RN) | Evento |', '|---|---|---|---|---|---|']
for c_, a, b, t in filas:
    bloque.append('| `%s` | %s | `%s` | %s | — | — |' % (c_, a if a == '—' else '`%s`' % a, b, t))
bloque.append('')
d.before_line('Referencias de §7 sin destino explícito: `integrationConnections.fallbackConnectionIds[]`', bloque)

# --- PA-INT-27 ---
pa = '''### PA-INT-27 — Cierre de residuales del anexo (tipos de evento, estados, referencias y API)

- **Pregunta:** ¿cómo se cierran los residuales del anexo detectados por los entregables de análisis?
- **Contexto:** %d tipos de evento usaban guiones fuera de la convención `<mod>.<agregado>.<hecho>` en camelCase; 7 máquinas descritas en texto no declaraban el estado de alta; 3 referencias no tenían destino en la definición del campo; 10 colecciones del §7 no tenían tabla de campos; 4 filas de §11 citaban reglas de acceso en lugar de una capability.
- **Opciones:**
  - A) Renombrar los tipos a camelCase y conservar el nombre anterior como alias en la descripción del evento de §12 (T11 los registra en su §12.4); agregar §8.13 con una fila por transición; declarar destinos (`externalTransactionNumber`, antes `externalTransactionId`, porque es un número del ente y no una referencia); agregar las tablas de campos de §7.18 (derivadas del texto y de T05, obligatoriedad por regla); usar `public: true` (con la condición) y `int.agentes.ejecutar` en §11. **(Recomendada)**.
  - B) Mantener los nombres con guiones y registrarlos como excepción.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** catálogo de eventos (T11 §12.4), diagramas de estados y contratos de T06.
- **Estado:** Asumida (DEC-072): opción A.
''' % len(renombres)
d.before_line('## 22. Trazabilidad de fuentes', pa.split('\n'))
print('T06 cambios', d.save())
