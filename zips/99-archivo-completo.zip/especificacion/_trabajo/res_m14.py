﻿import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from res_lib_m12m19 import Doc

d = Doc('M14-TES-tesoreria-bancos.md')
PA = 'PA-TES-19'

# Cat 7: CU-13 (dueño M07) -> CU-TES-17
d.rep('### CU-13 (BASE, parte tesorería) — Conciliación de cobro por pasarela',
      '### CU-TES-17 (antes CU-13; BASE §13, parte tesorería) — Conciliación de cobro por pasarela', cat=7)
d.rep('RF-TES-043, RF-TES-134; §16 CU-13 |', 'RF-TES-043, RF-TES-134; §16 CU-TES-17 (antes CU-13) |', cat=7)

# Cat 5: capability de API-TES-87
d.rep('| token BI con alcance `tes.read` |', '| `tes.posicion.ver` (token BI; antes alcance `tes.read`, que no es capability de T02; ' + PA + ') |', cat=5)

# Cat 2 y 4: referencias y nombres
d.rep("| `accountingRef` | `{ accountKey, pendingDebitAccountKey }` | No | Claves de regla contable para M15 (`COD_CTA`, `CTA_PENDEB`). | — |",
      "| `accountingRef` | `{ accountKey, pendingDebitAccountKey }` | No | Claves de regla contable para M15 (`COD_CTA`, `CTA_PENDEB`). | — (claves de rol contable embebidas; la cuenta la resuelve M15 en `entityAccountAssignments`; no es referencia) |", cat=2)
d.rep('| `unidentifiedCaseId` | ObjectId (M07) | No | RF-TES-040. | M07, colección [VERIFICAR] |',
      '| `unidentifiedCaseId` | ObjectId (M07) | No | RF-TES-040. | `unidentifiedReceipts` (M07) (antes "M07, colección [VERIFICAR]"; ' + PA + ') |', cat=2)
d.rep('| `reportRef` | ObjectId | [VERIFICAR] | — | `storedFiles` (T01) [VERIFICAR] |',
      '| `reportRef` | ObjectId | [VERIFICAR] | Reporte de conciliación cerrado (PDF versionado). | `storedFiles` (T01) (antes con `[VERIFICAR]`) |', cat=2)
d.rep('| `customerId` | String | [VERIFICAR] | No secreto. Identificador de cliente de Interbanking (dato externo, no es referencia). | — |',
      '| `customerId` | String | [VERIFICAR] | No secreto. Identificador de cliente de Interbanking (dato externo, no es referencia). | — (dato externo, no es referencia) |', cat=2)
d.rep('| `originAccountId` | ObjectId | Sí | RN-TES-059. | `treasuryAccounts` (M14) |\n| `executionDate` | date | Sí | — | — |',
      '| `originTreasuryAccountId` (antes `originAccountId`) | ObjectId | Sí | RN-TES-059; nombre canónico de T05 COL-TES-21 (' + PA + '). | `treasuryAccounts` (M14) |\n| `executionDate` | date | Sí | — | — |', cat=4)
d.rep('| `fileRef` | `{ storageKey, sha256, generatedAt }` | Sí | — | — |',
      '| `storedFileId` (antes `fileRef` `{ storageKey, sha256, generatedAt }`) | ObjectId | Sí | Archivo generado; el hash y la fecha quedan en `storedFiles` (nombre de T05; ' + PA + '). | `storedFiles` (T01) |', cat=4)
d.rep('| `echeqId` | string | Cond. | Para eCheq. | — |',
      '| `echeqId` | string | Cond. | Para eCheq. | — (identificador del eCheq en el banco, externo; no es referencia) |', cat=2)
d.rep('| `externalRef` | String | [VERIFICAR] | Operación eCheq del banco. | — |',
      '| `externalRef` | String | [VERIFICAR] | Operación eCheq del banco. | — (identificador externo del banco; no es referencia) |', cat=2)
d.rep('| `echeqId` | String | [VERIFICAR] | Identificador del eCheq en el banco (externo). | — |',
      '| `echeqId` | String | [VERIFICAR] | Identificador del eCheq en el banco (externo). | — (externo; no es referencia) |', cat=2)
d.rep('| `sourceRef` | `{ module (cmp, fis, cob, sue), docId, docNumber }` | Sí | OP (`ID_PPAGO`), obligación fiscal, reintegro. | — |',
      '| `sourceRef` | `{ module (cmp, fis, cob, sue), docId, docNumber }` | Sí | OP (`ID_PPAGO`), obligación fiscal, reintegro. | Polimórfica según `module`: `paymentOrders` (M12), obligación de M06, reintegro de M07 o `payrollRuns` (M16) |', cat=2)
d.rep('| `sourceRef` | String | [VERIFICAR] | Referencia de la publicación de origen. | — |',
      '| `sourceRef` | String | [VERIFICAR] | Referencia de la publicación de origen. | — (texto de la fuente de la cotización, p. ej. BCRA; no es referencia) |', cat=2)
d.rep('| `sourceRef` | Object | [VERIFICAR] | `{ module (cmp, tes, manual), docId }`. | — |',
      '| `sourceRef` | Object | [VERIFICAR] | `{ module (cmp, tes, manual), docId }`. | Polimórfica según `module`: `purchaseOrders` (M12) o documento de M14; `manual` sin referencia |', cat=2)
d.rep('| `companyRef` | ObjectId | [VERIFICAR] | — | `legalEntities` (T04) [VERIFICAR] |',
      '| `legalEntityId` (antes `companyRef`) | ObjectId | [VERIFICAR] | Empleador del lote (DEC-064; nombre canónico de T05 §7.2; ' + PA + '). | `legalEntities` (T04) |', cat=4)
d.rep('| `employeeId` | ObjectId (M16) | No | `COD_EMP`. | `employees` (M16) |\n| `validFrom`, `validTo` | date | Sí/No | Vigencia. | — |',
      '| `employeeId` | ObjectId (M16) | No | `COD_EMP`. | `employees` (M16) |\n'
      '| `personId` | ObjectId | Sí | Persona firmante; clave de unicidad `{treasuryAccountId, personId, validFrom}` de T05 (' + PA + '). | `persons` (M01) |\n'
      '| `legalEntityId` | ObjectId | Sí | Entidad jurídica de la cuenta (copia de `treasuryAccounts.legalEntityId`, DEC-064; ' + PA + '). | `legalEntities` (T04) |\n'
      '| `validFrom`, `validTo` | date | Sí/No | Vigencia. | — |', cat=4)
d.rep('Índice `{tenantId, institutionId, branchId, accountNumber}` único. Origen: `CTASUCE`',
      'Índice `{tenantId, institutionId, bankBranchId, accountNumber}` único (antes `branchId`, CTR-DAT-80). Origen: `CTASUCE`', cat=4)
d.rep('| `branchId` | ObjectId | Sí | — | `branches` (T04) |\n| `conceptId` | ObjectId | No | — | `billableConcepts` (M02) |',
      '| `branchId` | ObjectId | Sí | — | `branches` (T04) |\n'
      '| `legalEntityId` | ObjectId | Sí | Entidad jurídica de la operación, la de sus cuentas (DEC-064; clave de T05; ' + PA + '). | `legalEntities` (T04) |\n'
      '| `conceptId` | ObjectId | No | — | `billableConcepts` (M02) |', cat=4)
d.rep('| `kind` | Enum | [VERIFICAR] | `presentation`, `out`. | — |\n| `date` | Date | [VERIFICAR] | — | — |\n| `receivedWithholdingIds`',
      '| `number` | String | Sí | Número de la presentación, único por tenant (T05; ' + PA + '). | — |\n'
      '| `kind` | Enum | [VERIFICAR] | `presentation`, `out`. | — |\n| `date` | Date | [VERIFICAR] | — | — |\n| `receivedWithholdingIds`', cat=4)

# Cat 1: estados
inits = [
    ('### 8.1 Operación de tesorería (`treasuryOperations.status`)', 'draft'),
    ('### 8.2 Movimiento — conciliación (`treasuryMovements.reconciliation.status`)', 'unreconciled'),
    ('### 8.6 Cupón (`cardVouchers.state`)', 'collected'),
    ('### 8.7 Retención recibida (`receivedWithholdings.state`)', 'received'),
    ('### 8.10 Archivo de pago (`paymentFiles.status`)', 'generated'),
    ('### 8.11 Caja de pagos (`paymentCashSessions.status`)', 'open'),
    ('### 8.12 Cierre de caja de tesorería (`treasuryCashClosings.status`)', 'open'),
    ('### 8.13 Depósito (`bankDeposits.status`)', 'registered'),
    ('### 8.14 Compromiso (`fundCommitments.status`)', 'active'),
]
for h, st in inits:
    d.rep(h + '\n\n', h + '\n\nEstado inicial: `%s` (alta → `%s`; %s).\n\n' % (st, st, PA), cat=1)
d.rep('| (carga del archivo) | `previewed` |', '| (alta: carga del archivo) | `previewed` |', cat=1)
d.rep('| `fromState` | Enum | [VERIFICAR] | Estado de §8.4 o §8.5 según `checkKind`. | — |',
      '| `fromState` | Enum | [VERIFICAR] | Estado de §8.4 o §8.5 según `checkKind`; vacío en el evento de alta del cheque. `checkEvents` registra transiciones y no tiene máquina propia (§8.16.11; ' + PA + '). | — |', cat=1)

d.insert_before('## 9. ', '''#### 8.16.11 Corrida de sincronización Interbanking (`interbankingSyncRuns.status`)

Estado inicial: `running` (corrección del 05-11-2026, %s).

| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |
|---|---|---|---|---|
| (alta) | `running` | Inicio de la sincronización (programada o manual) | — | — |
| `running` | `completed` | Todas las páginas procesadas | — | — |
| `running` | `partial` | Alguna página con error; la corrida es reanudable | — | — |
| `partial` | `running` | Reanudación desde la última página procesada | — | — |
| `running` | `failed` | Error de conexión o de credenciales | — | — |

#### 8.16.12 Evento de cheque (`checkEvents.fromState`, `checkEvents.toState`)

`checkEvents` es la bitácora inmutable de las transiciones de §8.4 (`thirdPartyChecks.state`) y §8.5 (`ownChecks.state`): cada documento registra un paso `fromState` → `toState` de esas máquinas. Estado inicial: el alta del cheque se registra con `fromState` vacío (alta → `received`, `pendingAcceptance` o `available`, según la máquina). No tiene transiciones propias.

''' % PA, cat=1)

d.insert_before('## 22. Trazabilidad', '''### PA-TES-19 - Residuales del 05-11-2026 (estados, referencias, nombres de campo, CU duplicado y capability de API)
- **Pregunta:** ¿Cómo se cierran los residuales de M14 que detectaron los entregables regenerados?
- **Contexto:** el índice de estados marcó máquinas sin estado inicial y `interbankingSyncRuns` y `checkEvents` con valores sin transiciones; el modelo entidad-relación dejó referencias sin destino; T05 nombra `originTreasuryAccountId`, `storedFileId`, `personId`, `legalEntityId` y `number` donde este §7 no los tenía o los llamaba distinto; el §16 usaba CU-13, que es de M07; API-TES-87 exigía el alcance `tes.read`, que no es capability de T02.
- **Opciones:**
  - A) Estado inicial explícito; tablas de §8.16.11 y §8.16.12; destinos y "no es referencia" en cada campo; nombres de T05 con "antes"; el caso de uso pasa a CU-TES-17 (antes CU-13); API-TES-87 exige `tes.posicion.ver` **(Recomendada)**.
  - B) Mantener el texto y resolver en los entregables.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** §7.4, §7.8, §7.9, §7.15, §7.16, §7.22, §7.32, §7.42, §8, §15 (API-TES-87), §16.
- **Estado:** Asumida la recomendada (DEC-072). T05 debe expresar la unicidad de `bankStatementImports` sobre el hash de `storedFiles` (hoy `fileRef.hash`) y la de `payrollPaymentBatches` sobre `payrollRunId` (hoy `payrollRunRef`).

''', cat=0)
d.save()
