import glob, re, os
from collections import Counter
base = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
codes = ['M11', 'M14', 'M16', 'T01', 'T02', 'T04', 'T08']
files = []
for c in codes:
    files += glob.glob(os.path.join(base, c + '-*.md'))
files += glob.glob(os.path.join(base, 'T04b*.md'))
idpat = re.compile(r'^\|\s*\**((?:[A-Z]{2,4}-)?[A-Z]{2,5}-[A-Z0-9]{2,5}-\d{2,4}|[A-Z]{2,5}-\d{2,4})\**\s*\|')
for f in sorted(set(files)):
    raw = open(f, 'rb').read()
    s = raw.decode('utf-8')
    probs = []
    if b'\r' in raw:
        probs.append('CR')
    if '<!-- SIGUE' in s:
        probs.append('SIGUE')
    if '\ufffd' in s:
        probs.append('U+FFFD')
    lines = s.split('\n')
    heads = Counter(l.strip() for l in lines if l.startswith('#'))
    dh = [h for h, n in heads.items() if n > 1]
    if dh:
        probs.append('headings dup: %s' % dh[:5])
    ids = Counter()
    for l in lines:
        m = idpat.match(l)
        if m:
            ids[m.group(1)] += 1
    for l in lines:
        m = re.match(r'^#{2,4}\s+((?:[A-Z]{2,4}-)+\d{2,4})\b', l)
        if m:
            ids[m.group(1)] += 1
    di = [i for i, n in ids.items() if n > 1]
    if di:
        probs.append('ids dup: %s' % sorted(di)[:15])
    # filas de tabla CTR con columnas distintas a la anterior
    print(os.path.basename(f)[:40], len(ids), probs or 'OK')
