#### 4.4.2 Capabilities registradas por los anexos (mínimo obligatorio ampliado)

Capabilities que los anexos usan en sus API (§11) y pantallas (§10, catálogo `17-catalogo-pantallas`) y que siguen la convención `modulo.recurso.accion`. Se registran en `capabilityCatalog` con el módulo dueño indicado en cada subtítulo. Criterios de asignación:

- **Roles semilla**: se derivan de la matriz 4.3 según la acción: ver → roles con cualquier nivel en el módulo; operar (crear, editar, registrar, gestionar, ejecutar y propias del módulo) → niveles O/T y P (solo propios); aprobar, anular, autorizar, publicar, revertir → A/T; configurar → C/T; exportar → T y "V+exp". Las rutas del portal o la PWA agregan C-SOC y C-REP (alcance `rel`, o `self` si el recurso es propio); las del espacio del empleado, C-EMP; las internas, S-SYS; las de plataforma, P-SUP y P-ADM; las externas `/api/v1/ext`, S-API con marca X.
- **Marcas**: aprobar/anular/autorizar/publicar → S D; configurar y exportar → S; datos sensibles en la descripción → S. El anexo dueño puede endurecer marcas y acotar roles; no puede renombrar.
- **Fuente**: primeras filas API/PAN que la usan (relevamiento de `_trabajo/t02caps_a.py` sobre los anexos al 05-11-2026; regenerable).
- Las capabilities de T09 COM se registran en la tabla de T09 de §4.4 (tabla revisada a mano con los roles de T09 §4).

##### T01 PLA — Plataforma (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `pla.alertas.configurar` | Reglas de plataforma | S | P-SUP, P-ADM | global | API-PLA-34 |
| `pla.alertas.reconocer` | Ciclo de alerta | — | P-SUP, P-ADM | global | API-PLA-33 |
| `pla.alertas.ver` | Alertas | — | P-SUP, P-ADM, P-SEC | global | API-PLA-32, PAN-PLA-12 |
| `pla.altaAsistida.usar` | Crear borrador | — | P-SUP, P-ADM | global | API-PLA-12, API-PLA-13, API-PLA-14 (+1) |
| `pla.backups.ejecutar` | Backup lógico a demanda | — | P-SUP, P-ADM | global | API-PLA-42 |
| `pla.bia.api.monitorear` | Uso de API por tenant (agregado) | — | P-SUP, P-ADM, P-SEC | global | API-BIA-59, API-BIA-60, PAN-BIA-23 |
| `pla.bia.benchmark.administrar` | Segmentos y mínimos | S | P-SUP, P-ADM | global | API-BIA-63, PAN-BIA-23 |
| `pla.bia.catalogo.administrar` | Reconstrucción por tenant (JOB-BIA-12) | S | P-SUP, P-ADM | global | API-BIA-61, API-BIA-62, PAN-BIA-23 |
| `pla.bia.tablero.ver` | Indicadores globales GOB-001 (consumido por PAN-PLA-01) | — | P-SUP, P-ADM, P-SEC | global | API-BIA-58 |
| `pla.catalogo.editar` | Catálogo de módulos | — | P-SUP, P-ADM | global | API-PLA-16 |
| `pla.catalogo.ver` | Catálogo de módulos | — | P-SUP, P-ADM, P-SEC | global | API-PLA-16, PAN-PLA-05 |
| `pla.cfg.defaults.editar` | Registro de definiciones y defaults de plataforma | — | P-SUP, P-ADM | global | PAN-CFG-25 |
| `pla.cfg.equivalencias.editar` | Equivalencias V2. | — | P-SUP, P-ADM | global | API-CFG-52, PAN-CFG-27 |
| `pla.cfg.registro.ver` | Registro de definiciones y defaults de plataforma | — | P-SUP, P-ADM, P-SEC | global | PAN-CFG-25 |
| `pla.cfg.semillas.administrar` | Aplicar/retirar semilla. | S | P-SUP, P-ADM | global | API-CFG-50, PAN-CFG-24 |
| `pla.cfg.tablasPlataforma.editar` | Tablas de plataforma y releases | — | P-SUP, P-ADM | global | PAN-CFG-26 |
| `pla.checklists.ver` | Checklists del tenant | — | P-SUP, P-ADM, P-SEC | global | API-PLA-06 |
| `pla.checklists.verificar` | Reevaluar ahora | — | P-SUP, P-ADM, P-SEC | global | API-PLA-07, API-PLA-08 |
| `pla.colas.pausar` | Pausa de cola | — | P-SUP, P-ADM | global | API-PLA-38 |
| `pla.contratos.aprobar` | Enviar, aprobar, rechazar, terminar | S D | P-SUP, P-ADM | global | API-PLA-20 |
| `pla.contratos.crear` | Lista / alta | — | P-SUP, P-ADM | global | API-PLA-18 |
| `pla.contratos.editar` | Edición de borrador o nueva versión | — | P-SUP, P-ADM | global | API-PLA-19 |
| `pla.contratos.ver` | Lista / alta | — | P-SUP, P-ADM, P-SEC | global | API-PLA-18, PAN-PLA-07 |
| `pla.deadLetters.reprocesar` | Bandeja técnica | — | P-SUP, P-ADM | global | API-PLA-40 |
| `pla.estado.ver` | Estado del tenant (banda, suspensión, mantenimiento) | — | T-ADM, T-USR, T-GER, T-SIN | tenant | API-PLA-61 |
| `pla.exportacion.solicitar` | Exportación completa | — | T-ADM | tenant | API-PLA-59, PAN-PLA-23 |
| `pla.facturacionSaas.exportar` | Prefactura exportable | S | P-SUP, P-ADM | global | API-PLA-22 |
| `pla.flags.editar` | Flags | — | P-SUP, P-ADM | global | API-PLA-49 |
| `pla.habilitacion.ver` | Estado y checklists propios | — | T-ADM, T-USR, T-GER, T-SIN | tenant | API-PLA-53, PAN-PLA-16 |
| `pla.habilitacion.verificar` | Verificar ítem manual propio | — | T-ADM, T-USR, T-GER, T-SIN | tenant | API-PLA-54 |
| `pla.incidentes.editar` | Incidentes | — | P-SUP, P-ADM | global | API-PLA-30 |
| `pla.incidentes.ver` | Incidentes | — | P-SUP, P-ADM, P-SEC | global | API-PLA-30, PAN-PLA-13 |
| `pla.jobs.cancelar` | Reintento/cancelación | — | P-SUP, P-ADM | global | API-PLA-37 |
| `pla.jobs.reintentar` | Reintento/cancelación | — | P-SUP, P-ADM | global | API-PLA-37 |
| `pla.jobs.ver` | Métricas de colas por tenant | — | P-SUP, P-ADM, P-SEC | global | API-PLA-35, API-PLA-36, API-PLA-39 (+1) |
| `pla.messaging.consumo.ver` | Consumo por tenant (sin contenido). | — | P-SUP, P-ADM, P-SEC | global | API-COM-110, PAN-COM-34 |
| `pla.miSuscripcion.ver` | Mi suscripción (proyección sin datos internos) | — | T-ADM, T-USR, T-GER, T-SIN | tenant | API-PLA-52, PAN-PLA-15 |
| `pla.notices.publicar` | Avisos de plataforma. | S D | P-SUP, P-ADM | global | API-COM-109, PAN-COM-33 |
| `pla.novedadesPlataforma.ver` | Lo nuevo y avisos | — | T-ADM, T-USR, T-GER, T-SIN | tenant | API-PLA-60, PAN-PLA-19 |
| `pla.planes.editar` | Planes | — | P-SUP, P-ADM | global | API-PLA-17 |
| `pla.planes.ver` | Planes | — | P-SUP, P-ADM, P-SEC | global | API-PLA-17, PAN-PLA-06 |
| `pla.releases.publicar` | Releases | S D | P-SUP, P-ADM | global | API-PLA-48 |
| `pla.releases.ver` | Releases | — | P-SUP, P-ADM, P-SEC | global | API-PLA-48, PAN-PLA-20 |
| `pla.restauraciones.aprobar` | Ciclo de restauración | S D | P-SUP, P-ADM | global | API-PLA-44 |
| `pla.restauraciones.ejecutar` | Ciclo de restauración | — | P-SUP, P-ADM | global | API-PLA-44 |
| `pla.restauraciones.solicitar` | Lista / solicitud | — | P-SUP, P-ADM | global | API-PLA-43, PAN-PLA-11 |
| `pla.sandbox.crear` | Crear sandbox | — | T-ADM, P-SUP, P-ADM | tenant / global | API-PLA-46, API-PLA-47, PAN-PLA-14 |
| `pla.sandbox.ver` | Ambientes | — | T-ADM, T-USR, T-GER, T-SIN, P-SUP, P-ADM, P-SEC | tenant / global | PAN-PLA-14 |
| `pla.soporte.accesos.ver` | Canónica propuesta para pla.accesosSoporte.ver, pla.accesos.ver. Accesos temporales | — | P-SUP, P-ADM, P-SEC, T-ADM, T-USR, T-GER, T-SIN | global / tenant | PAN-PLA-08, API-PLA-57, PAN-PLA-18 |
| `pla.soporte.crear` | Casos propios | — | T-ADM | tenant | API-PLA-55, API-PLA-56 |
| `pla.soporte.editar` | Asignar, prioridad, estado, incidente | — | P-SUP, P-ADM | global | API-PLA-24, API-PLA-25 |
| `pla.soporte.ver` | Bandeja global | — | T-ADM, T-USR, T-GER, T-SIN, P-SUP, P-ADM, P-SEC | tenant / global | API-PLA-23, API-PLA-55, PAN-PLA-17 (+1) |
| `pla.tablasSueldos.editar` | Tablas oficiales (servicio de T04) | — | P-SUP, P-ADM | global | API-SUE-87, PAN-SUE-47 |
| `pla.uso.ver` | Uso por tenant y dimensión | — | P-SUP, P-ADM, P-SEC | global | API-PLA-21, PAN-PLA-22 |

##### T02 IAM — Identidad, roles y auditoría (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `iam.rolesPlantilla.editar` | Canónica propuesta para rolesPlantilla.editar. Usuarios y roles de plataforma | — | P-SUP, P-ADM | global | PAN-IAM-26 |

##### T03 UXD — Experiencia, marca y diccionario (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `uxd.diccionario.exportar` | Exportar | S | T-ADM | tenant | API-UXD-22 |
| `uxd.diccionario.importar` | Importación con ExcelImportWizard | — | T-COM | tenant | API-UXD-23 |
| `uxd.diccionario.revertir` | Revertir a release k | S D | T-ADM | tenant | API-UXD-19 |
| `uxd.diccionarioBase.ver` | Canónica propuesta para plt.uxd.diccionarioBase.ver. Faltantes de todos los tenants (sin datos personales) | — | P-SUP, P-ADM, P-SEC | global | API-UXD-34, PAN-UXD-09 |
| `uxd.flags.configurar` | Canónica propuesta para plt.uxd.flags.configurar. Flags globales | S | P-SUP, P-ADM, T-ADM | global / tenant | API-UXD-35, PAN-UXD-11, API-UXD-28, PAN-UXD-07 |
| `uxd.marca.asistir` | Canónica propuesta para plt.uxd.marca.asistir. Propuesta de marca en el alta asistida (queda en borrador del tenant) | — | P-SUP, P-ADM | global | API-UXD-37 |
| `uxd.marca.editar` | Crear/actualizar borrador (control version) | — | T-COM | tenant | API-UXD-06, API-UXD-07, API-UXD-11 (+1) |
| `uxd.marca.publicar` | Publicar borrador (Idempotency-Key) | S D | T-ADM | tenant | API-UXD-08, API-UXD-09 |
| `uxd.navegacion.configurar` | Navegación PWA por rol | S | T-ADM | tenant | API-UXD-29, PAN-UXD-05 |
| `uxd.tokens.ver` | Canónica propuesta para plt.uxd.tokens.ver. Catálogo vivo de componentes y tokens | — | P-SUP, P-ADM, P-SEC | global | PAN-UXD-10 |
| `uxd.vistas.compartir` | Vistas guardadas de DataTable | — | T-COM | tenant | API-UXD-31 |

##### T04 CFG — Configuración, parámetros y maestros (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `cfg.adopciones.configurar` | Adopciones y propósitos. | S | T-ADM | tenant | API-CFG-41, PAN-CFG-17 |
| `cfg.calendarios.editar` | Calendarios y feriados. | — | T-ADM | tenant | API-CFG-37 |
| `cfg.calendarios.ver` | Calendarios y feriados. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CFG-37 |
| `cfg.calles.crear` | Alta de calle local. | — | T-ADM | tenant | API-CFG-31, PAN-CFG-12 |
| `cfg.camposExtra.configurar` | Definiciones de campos extra. | S | T-ADM | tenant | API-CFG-44, PAN-CFG-21 |
| `cfg.enumeraciones.configurar` | Enumeraciones. | S | T-ADM | tenant | API-CFG-43, PAN-CFG-20 |
| `cfg.fiscal.ver` | Consulta de padrón. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CFG-42, PAN-CFG-10 |
| `cfg.formularios.configurar` | Personalizaciones. | S | T-ADM | tenant | API-CFG-46, PAN-CFG-22 |
| `cfg.geo.aprobarCalle` | Propuesta y decisión. | S D | P-SUP, P-ADM | global | API-CFG-32 |
| `cfg.geo.confirmarPunto` | Confirmar/corregir punto de una entidad (llama al dueño). | — | T-ADM, C-SOC, C-REP | tenant / rel | API-CFG-35, API-CFG-36, PAN-CFG-14 (+2) |
| `cfg.geo.proponerCalle` | Propuesta y decisión. | — | T-ADM, P-SUP, P-ADM | tenant / global | API-CFG-32, PAN-CFG-12 |
| `cfg.geo.ver` | Unidades territoriales | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN, C-SOC, C-REP | tenant / rel | PAN-CFG-11, PAN-CFG-12, PAN-CFG-14 |
| `cfg.historia.ver` | Valores a at/knownAt; exportable. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CFG-20, PAN-CFG-06 |
| `cfg.indices.editar` | Series y valores. | — | T-ADM | tenant | API-CFG-39 |
| `cfg.indices.ver` | Series y valores. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CFG-39 |
| `cfg.maestros.anular` | Editar / inactivar. | S D | T-ADM, T-GER | tenant | API-CFG-23 |
| `cfg.maestros.crear` | Listar (paginado, at) / crear registro. | — | T-ADM | tenant | API-CFG-22 |
| `cfg.maestros.exportar` | Exportación XLSX/CSV. | S | T-ADM | tenant | API-CFG-27 |
| `cfg.maestros.importar` | Importación de maestros y padrones. | — | T-ADM | tenant | API-CFG-26, PAN-CFG-09 |
| `cfg.maestros.unificar` | Unificar (job). | — | T-ADM | tenant | API-CFG-25 |
| `cfg.padrones.importar` | Padrones fiscales disponibles y su estado | — | T-ADM | tenant | PAN-CFG-10 |
| `cfg.secuencias.configurar` | Definición de secuencias y contadores (§14.7). Reemplazado por la API de numberingSequences de T11 (CTR-DAT-16). | S | T-ADM | tenant | API-CFG-54 |
| `cfg.semillas.aplicar` | Paquetes semilla y su aplicación | — | P-SUP, P-ADM | global | PAN-CFG-24 |
| `cfg.tecnica.ver` | Estado de secretos requeridos. | S | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CFG-49, PAN-CFG-28 |
| `cfg.versiones.aprobar` | Aprobar/rechazar con comentario. | S D | T-ADM, T-GER | tenant | API-CFG-14 |
| `cfg.versiones.cancelar` | Cancelar con motivo. | — | T-ADM | tenant | API-CFG-17 |
| `cfg.versiones.crear` | Listar / crear borrador (origen manual, import, copy, seed, migration, platform). | — | T-ADM | tenant | API-CFG-07, API-CFG-08, API-CFG-09 (+1) |
| `cfg.versiones.enviarRevision` | Enviar a revisión (T11). | — | T-ADM | tenant | API-CFG-13 |
| `cfg.versiones.programar` | Programar publicación. | — | T-ADM | tenant | API-CFG-15 |
| `cfg.versiones.publicar` | Publicar ahora (atómico). | S D | T-ADM, T-GER | tenant | API-CFG-16 |
| `cfg.versiones.simular` | Simulación por contributors (job si es larga). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CFG-12 |
| `cfg.versiones.validar` | Validación y dependencias. | — | T-ADM | tenant | API-CFG-11 |
| `cfg.versiones.ver` | Listar / crear borrador (origen manual, import, copy, seed, migration, platform). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CFG-07, API-CFG-08, API-CFG-10 (+2) |
| `cfg.vistas.compartir` | Vistas guardadas. | — | T-ADM | tenant | API-CFG-47, PAN-CFG-23 |
| `cfg.vistas.crear` | Vistas guardadas. | — | T-ADM | tenant | API-CFG-47, PAN-CFG-23 |

##### T06 INT — Integraciones (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `int.agentes.gestionar` | Emparejar/revocar agente local | — | T-FAC, T-TES, T-CON, T-STE, T-SCM | tenant | API-INT-46, PAN-INT-17 |
| `int.alertas.gestionar` | Alertas | — | T-FAC, T-TES, T-CON, T-STE, T-SCM | tenant | API-INT-41 |
| `int.alertas.ver` | Alertas | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-STE, T-SCM, T-SIN, P-SUP, P-ADM, P-SEC | tenant / global | PAN-INT-15 |
| `int.archivos.aprobar` | Aprobar y entregar saliente | S D | T-ADM | tenant | API-INT-35 |
| `int.archivos.importar` | Carga entrante en 3 pasos | — | T-FAC, T-TES, T-CON, T-STE, T-SCM | tenant | API-INT-37 |
| `int.archivos.ver` | Intercambios de archivos | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-STE, T-SCM, T-SIN, P-SUP, P-ADM, P-SEC | tenant / global | API-INT-34, API-INT-36, API-INT-38 (+2) |
| `int.bitacora.ver` | Bitácora (metadatos) | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-STE, T-SCM, T-SIN | tenant | API-INT-28, PAN-INT-10 |
| `int.bitacora.verPayload` | Cuerpos saneados (auditado) | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-STE, T-SCM, T-SIN | tenant | API-INT-29 |
| `int.certificados.gestionar` | Generar par de claves y CSR | S | T-FAC, T-TES, T-CON, T-STE, T-SCM | tenant | API-INT-17, API-INT-18, API-INT-19 (+3) |
| `int.conciliaciones.aprobar` | Resolver diferencia / cerrar | S D | T-ADM | tenant | API-INT-40 |
| `int.conciliaciones.ver` | Conciliaciones | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-STE, T-SCM, T-SIN | tenant | API-INT-39, PAN-INT-14 |
| `int.conexiones.configurar` | Editar configuración (versión optimista) | S | T-ADM | tenant | API-INT-07, API-INT-09, API-INT-10 (+1) |
| `int.conexiones.crear` | Crear conexión (borrador) | — | T-FAC, T-TES, T-CON, T-STE, T-SCM | tenant | API-INT-05, API-INT-12 |
| `int.conexiones.probar` | Probar conexión | — | T-FAC, T-TES, T-CON, T-STE, T-SCM | tenant | API-INT-08 |
| `int.conexiones.ver` | Proveedores disponibles para la licencia del tenant | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-STE, T-SCM, T-SIN | tenant | API-INT-03, API-INT-04, API-INT-06 (+2) |
| `int.contingencias.declarar` | Declarar/cerrar contingencia | — | T-FAC, T-TES, T-CON, T-STE, T-SCM | tenant | API-INT-42, PAN-INT-16 |
| `int.modo.cambiar` | Solicitar cambio de modo | — | T-FAC, T-TES, T-CON, T-STE, T-SCM | tenant | API-INT-11 |
| `int.monitoreo.ver` | Tableros | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-STE, T-SCM, T-SIN, P-SUP, P-ADM, P-SEC | tenant / global | API-INT-43, API-INT-44, API-INT-49 (+4) |
| `int.operaciones.reintentar` | Reintentar | — | T-FAC, T-TES, T-CON, T-STE, T-SCM | tenant | API-INT-23, API-INT-24, API-INT-27 (+1) |
| `int.operaciones.resolverManual` | Registrar resultado externo con evidencia | — | T-FAC, T-TES, T-CON, T-STE, T-SCM | tenant | API-INT-25, API-INT-26 |
| `int.operaciones.ver` | Listar/detallar operaciones | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-STE, T-SCM, T-SIN | tenant | API-INT-22, API-INT-45, PAN-INT-08 (+1) |
| `int.proveedores.configurar` | Alta/edición de proveedor | S | T-ADM, P-SUP, P-ADM | tenant / global | API-INT-02, API-INT-38, PAN-INT-01 (+1) |
| `int.proveedores.ver` | Listar catálogo | — | P-SUP, P-ADM, P-SEC | global | API-INT-01 |
| `int.webhooks.configurar` | Bandeja y reproceso | S | T-ADM | tenant | API-INT-32, API-INT-33, PAN-INT-11 |
| `int.webhooks.gestionar` | Canónica propuesta para webhooks:manage. Listar/crear suscripciones propias (secreto devuelto una vez) | X | T-FAC, T-TES, T-CON, T-STE, T-SCM, S-API | tenant | API-BIA-124, API-BIA-125, API-BIA-126 (+2) |

##### T07 MIG — Migración (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `mig.actaAceptacion.firmar` | Cambiar estado (§8.1) | S D | T-ADM, P-SUP, P-ADM | tenant / global | API-MIG-03, PAN-MIG-23 |
| `mig.anonimizacion.ejecutar` | Perfiles y ejecución | — | P-SUP, P-ADM | global | API-MIG-37, PAN-MIG-22 |
| `mig.archivo.ver` | Histórico por vínculo (?accountId=&table=&from=&to=) | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-SIN | tenant | API-MIG-35, PAN-MIG-20 |
| `mig.bypass.aprobar` | Cambiar estado (§8.1) | S D | T-ADM, P-SUP, P-ADM | tenant / global | API-MIG-03, API-MIG-27 |
| `mig.calidad.sanear` | Candidatos y decisiones de fusión | — | T-ADM | tenant | API-MIG-19, PAN-MIG-11, PAN-MIG-12 |
| `mig.conciliacion.aprobar` | Flujo de aprobación | S D | T-ADM | tenant | API-MIG-21 |
| `mig.conciliacion.ver` | Conciliaciones | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-SIN | tenant | API-MIG-20, PAN-MIG-13 |
| `mig.corridas.cancelar` | Control de corrida | — | P-SUP, P-ADM | global | API-MIG-12 |
| `mig.corridas.ejecutar` | Lanzar corrida | — | T-ADM, P-SUP, P-ADM | tenant / global | API-MIG-11, API-MIG-12, API-MIG-17 (+1) |
| `mig.corte.aprobar` | Cambiar estado (§8.1) | S D | T-ADM, P-SUP, P-ADM | tenant / global | API-MIG-03, API-MIG-30 |
| `mig.corte.ejecutar` | Decisión go y pasos | — | T-ADM | tenant | API-MIG-30 |
| `mig.corte.planificar` | Runbook | — | T-ADM | tenant | API-MIG-29, PAN-MIG-17 |
| `mig.paralelo.aprobar` | Cambiar estado (§8.1) | S D | T-ADM, P-SUP, P-ADM | tenant / global | API-MIG-03, API-MIG-25 |
| `mig.paralelo.ejecutar` | Crear corrida paralela (simular + importar + comparar) | — | T-ADM | tenant | API-MIG-22 |
| `mig.paralelo.justificar` | Clasificar y justificar | — | T-ADM | tenant | API-MIG-24, PAN-MIG-15 |
| `mig.perfilado.ver` | Perfilado de calidad | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-SIN | tenant | PAN-MIG-06 |
| `mig.proyectos.configurar` | Detalle / actualizar estrategia | S | P-SUP, P-ADM | global | API-MIG-02, API-MIG-03, API-MIG-04 (+1) |
| `mig.proyectos.crear` | Listar / crear proyectos | — | P-SUP, P-ADM | global | API-MIG-01 |
| `mig.proyectos.ver` | Listar / crear proyectos | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-SIN, P-SUP, P-ADM, P-SEC | tenant / global | API-MIG-01, API-MIG-02, API-MIG-04 (+8) |
| `mig.rechazos.editar` | Asignar, excluir, aceptar | — | T-ADM | tenant | API-MIG-15, API-MIG-16 |
| `mig.rechazos.exportar` | Exportar XLSX/CSV | S | T-ADM | tenant | API-MIG-18 |
| `mig.rechazos.ver` | Rechazos/advertencias paginados { items, total, page, size } | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-SIN | tenant | API-MIG-14, PAN-MIG-10 |
| `mig.reglas.editar` | Conjuntos de mapeo | — | P-SUP, P-ADM | global | API-MIG-07, API-MIG-09, PAN-MIG-07 |
| `mig.reglas.publicar` | Publicar (inmutable) | S D | P-SUP, P-ADM | global | API-MIG-08 |
| `mig.rollback.ejecutar` | Ejecutar plan de retorno | — | T-ADM | tenant | API-MIG-31, API-MIG-32, PAN-MIG-18 |
| `mig.snapshots.crear` | Extraer snapshot full/delta/final | — | P-SUP, P-ADM | global | API-MIG-05, PAN-MIG-05 |
| `mig.valores.editar` | Mapas de valores del tenant | — | T-ADM | tenant | API-MIG-10, PAN-MIG-08 |

##### T08 NFR — Privacidad y seguridad operativa (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `nfr.alertas.configurar` | Reglas de alerta y SLO | S | P-SUP, P-ADM | global | API-NFR-39, PAN-NFR-15 |
| `nfr.alertas.reconocer` | Gestión de alertas | — | P-SUP, P-ADM | global | API-NFR-40 |
| `nfr.anonimizacion.aprobar` | Aprobar ejecución | S D | T-ADM | tenant | API-NFR-16 |
| `nfr.avisos.editar` | Avisos y borradores | — | T-ADM, T-USR | tenant | API-NFR-05 |
| `nfr.avisos.publicar` | Publicar versión | S D | T-ADM | tenant | API-NFR-06 |
| `nfr.avisos.ver` | Avisos y borradores | — | T-ADM, T-USR, T-GER, T-SIN | tenant | API-NFR-05, PAN-NFR-03 |
| `nfr.bloqueosLegales.anular` | Transiciones | S D | T-ADM | tenant | API-NFR-18 |
| `nfr.bloqueosLegales.aprobar` | Transiciones | S D | T-ADM | tenant | API-NFR-18 |
| `nfr.bloqueosLegales.crear` | Proponer bloqueo | — | T-ADM, T-USR | tenant | API-NFR-17 |
| `nfr.claves.rotar` | Rotación | S | P-SUP, P-ADM | global | API-NFR-38 |
| `nfr.claves.ver` | Metadatos de claves | S | P-SUP, P-ADM, P-SEC | global | API-NFR-37, PAN-NFR-14 |
| `nfr.consentimientos.exportar` | Exportación auditada | S | T-ADM | tenant | API-NFR-08 |
| `nfr.conservacion.configurar` | Políticas de conservación | S | T-ADM | tenant | API-NFR-14, API-NFR-15 |
| `nfr.conservacion.ver` | Políticas de conservación | — | T-ADM, T-USR, T-GER, T-SIN | tenant | API-NFR-14, PAN-NFR-06 |
| `nfr.cspReportes.ver` | Reportes CSP agregados | — | P-SUP, P-ADM, P-SEC | global | API-NFR-42 |
| `nfr.evidencias.aprobar` | Evidencias y aprobación de promoción | S D | P-SUP, P-ADM | global | API-NFR-41 |
| `nfr.evidencias.ver` | Evidencias y aprobación de promoción | — | P-SUP, P-ADM, P-SEC | global | API-NFR-41, PAN-NFR-16 |
| `nfr.incidentes.editar` | Notificar tenants afectados | — | P-SUP, P-ADM | global | API-NFR-35 |
| `nfr.incidentes.ver` | Incidentes que afectan al tenant | — | T-ADM, T-USR, T-GER, T-SIN, P-SUP, P-ADM, P-SEC | tenant / global | API-NFR-20, PAN-NFR-08, PAN-NFR-12 |
| `nfr.inventarioDatos.ver` | Inventario de datos | — | T-ADM, T-USR, T-GER, T-SIN | tenant | API-NFR-04, PAN-NFR-02 |
| `nfr.restauracion.ejecutar` | Simulacros y restauraciones | — | P-SUP, P-ADM | global | API-NFR-36, PAN-NFR-13 |
| `nfr.restauracion.solicitar` | Solicitar restauración selectiva | — | T-ADM, T-USR | tenant | API-NFR-21 |
| `nfr.salud.ver` | Tablero de salud del tenant | S | T-ADM, T-USR, T-GER, T-SIN | tenant | API-NFR-19, API-NFR-22, PAN-NFR-07 |
| `nfr.saludPlataforma.ver` | Tablero global | S | P-SUP, P-ADM, P-SEC | global | API-NFR-33, PAN-NFR-11 |
| `nfr.solicitudesDerechos.aprobar` | Aprobar decisiones | S D | T-ADM | tenant | API-NFR-11, API-NFR-12 |
| `nfr.solicitudesDerechos.crear` | Bandeja y alta | — | T-ADM, T-USR | tenant | API-NFR-09 |
| `nfr.solicitudesDerechos.editar` | Verificar, analizar, decidir | — | T-ADM, T-USR | tenant | API-NFR-10 |
| `nfr.solicitudesDerechos.ver` | Bandeja y alta | — | T-ADM, T-USR, T-GER, T-SIN | tenant | API-NFR-09, API-NFR-13, PAN-NFR-05 |
| `nfr.subencargados.editar` | Registro de subencargados | — | P-SUP, P-ADM | global | API-NFR-43, PAN-NFR-17 |
| `nfr.tratamientos.editar` | Alta/edición con version | — | T-ADM, T-USR | tenant | API-NFR-02 |
| `nfr.tratamientos.exportar` | Exportación asíncrona | S | T-ADM | tenant | API-NFR-03 |
| `nfr.tratamientos.ver` | Listar registro de tratamientos | — | T-ADM, T-USR, T-GER, T-SIN | tenant | API-NFR-01, API-NFR-23, PAN-NFR-01 |

##### T10 BIA — Reportes, BI y APIs (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `bia.alertas.configurar` | Reglas; POST /:id/simulate | S | T-ADM | tenant | API-BIA-33, PAN-BIA-14 |
| `bia.alertas.gestionar` | Bandeja | — | T-CAJ (P), T-CBR (P) | tenant | API-BIA-34, API-BIA-35, PAN-BIA-14 |
| `bia.api.clientes.aprobar` | Transiciones §8.6 | S D | T-ADM | tenant | API-BIA-45, PAN-BIA-15 |
| `bia.api.clientes.crear` | Perfil de datos del cliente (finalidad, scopes, restricciones, límites) | — | T-CAJ (P), T-CBR (P) | tenant | API-BIA-44, PAN-BIA-15 |
| `bia.api.clientes.ver` | Perfil de datos del cliente (finalidad, scopes, restricciones, límites) | — | T-ADM, T-GER, T-FAC, T-CAJ (P), T-CBR (P), T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | tenant | API-BIA-44, PAN-BIA-15 |
| `bia.api.credenciales.rotar` | Emite/rota/revoca delegando en T02 (API-IAM-47); secreto en la respuesta una sola vez | S | T-CAJ (P), T-CBR (P) | tenant | API-BIA-46, PAN-BIA-15 |
| `bia.api.uso.ver` | Uso agregado y errores | — | T-ADM, T-GER, T-FAC, T-CAJ (P), T-CBR (P), T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | tenant | API-BIA-47, PAN-BIA-16 |
| `bia.api.webhooks.configurar` | Suscripciones (alta en nombre de un cliente) | S | T-ADM | tenant | API-BIA-48, API-BIA-49, API-BIA-50 (+1) |
| `bia.auditoria.ver` | Auditoría de accesos a reportes | — | T-ADM, T-GER, T-FAC, T-CAJ (P), T-CBR (P), T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | tenant | API-BIA-51, PAN-BIA-19 |
| `bia.benchmark.configurar` | Adhesión y segmento | S | T-ADM | tenant | API-BIA-54, PAN-BIA-20 |
| `bia.benchmark.ver` | Percentiles del tenant | — | T-ADM, T-GER, T-FAC, T-CAJ (P), T-CBR (P), T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | tenant | API-BIA-55, PAN-BIA-20 |
| `bia.bi.ver` | Zona A de la sala | — | T-ADM, T-GER, T-FAC, T-CAJ (P), T-CBR (P), T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | tenant | API-BIA-37, API-BIA-38, API-BIA-39 (+1) |
| `bia.cat.contratos.ver` | Canónica propuesta para ext.cat.contratos.ver. Contratos para APIs de terceros/BI (sin datos sensibles ni secretos). | X | S-API | tenant | API-CAT-54 |
| `bia.datasets.configurar` | Datasets semánticos y exposición | S | T-ADM | tenant | API-BIA-36, PAN-BIA-18 |
| `bia.datasets.ver` | Canónica propuesta para datasets:read. Datasets expuestos a API con diccionario | X | T-ADM, T-GER, T-FAC, T-CAJ (P), T-CBR (P), T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN, S-API | tenant | API-BIA-119, API-BIA-120, API-BIA-36, PAN-BIA-18 |
| `bia.datosAbiertos.publicar` | Publicaciones | S D | T-ADM | tenant | API-BIA-52, API-BIA-53 |
| `bia.disenador.publicar` | Ciclo §8.1 | S D | T-ADM | tenant | API-BIA-26, PAN-BIA-09 |
| `bia.disenador.usar` | Reportes personalizados (O11) | — | T-CAJ (P), T-CBR (P) | tenant | API-BIA-25, API-BIA-26, PAN-BIA-09 |
| `bia.exportaciones.administrar` | Estado, progreso, metadatos, totales | S | T-ADM | tenant | API-BIA-05, API-BIA-08, API-BIA-09 (+5) |
| `bia.exportaciones.crear` | Canónica propuesta para exports:write. Crea exportación masiva { resource/datasetCode, filters, format: ndjson/csv/parquet, asOf } → 202 | X | T-CAJ (P), T-CBR (P), S-API | tenant | API-BIA-121, API-BIA-122, API-BIA-123 |
| `bia.exportaciones.ver` | Mis exportaciones | — | T-ADM, T-GER, T-FAC, T-CAJ (P), T-CBR (P), T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | tenant | API-BIA-13, API-BIA-14, API-BIA-15 (+1) |
| `bia.fac.codigos.ver` | Canónica propuesta para ext.fac.codigos.ver. Decodificación para recaudadores (devuelve documento, importe vigente y vencimiento). | X | S-API | tenant | API-FAC-157 |
| `bia.fac.comprobantes.ver` | Canónica propuesta para ext.fac.comprobantes.ver. Lectura para integradores (sin datos personales salvo los fiscales necesarios). | X | S-API | tenant | API-FAC-155 |
| `bia.fac.importaciones.crear` | Canónica propuesta para ext.fac.importaciones.crear. Carga de ítems de terceros por API (formato canónico). | X | S-API | tenant | API-FAC-156 |
| `bia.indicadores.ver` | Canónica propuesta para metrics:read. Catálogo de indicadores certificados con definición | X | T-ADM, T-GER, T-FAC, T-CAJ (P), T-CBR (P), T-TES, T-CON, T-CMP, T-DEP, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN, S-API | tenant | API-BIA-117, API-BIA-118, API-BIA-27, PAN-BIA-13 |
| `bia.med.consumos.ver` | Canónica propuesta para ext.med.consumos.ver. Consumos aprobados para BI del tenant (T10). | X | S-API | tenant | API-MED-75 |
| `bia.med.lecturas.crear` | Canónica propuesta para ext.med.lecturas.crear. Ingreso de lecturas desde MDM/AMI del tenant (push). | X | S-API | tenant | API-MED-76 |
| `bia.presets.compartir` | Presets | — | T-CAJ (P), T-CBR (P) | tenant | API-BIA-16, PAN-BIA-06 |
| `bia.reportes.configurar` | Ocultar, renombrar, plantilla y preset por defecto | S | T-ADM | tenant | API-BIA-21, API-BIA-22, API-BIA-23 (+3) |
| `bia.reportes.ejecutar` | Ejecuta; 200 con primera página (sync) o 202 con runId (async) | — | T-CAJ (P), T-CBR (P) | tenant | API-BIA-03, API-BIA-08, API-BIA-09 (+1) |
| `bia.reportes.programar` | Programaciones | — | T-CAJ (P), T-CBR (P) | tenant | API-BIA-18, API-BIA-19, API-BIA-20 (+2) |
| `bia.tableros.disenar` | Tableros; GET con valores ya calculados | — | T-CAJ (P), T-CBR (P) | tenant | API-BIA-31, PAN-BIA-11 |

##### T11 WFL — Workflow, eventos y documentos (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `wfl.agenda.ver` | Agenda por rango y capas | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-CJO, T-SIN, C-EMP | tenant / self | API-WFL-13, API-WFL-14, API-WFL-15 (+2) |
| `wfl.aprobaciones.decidir` | Detalle | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-41, API-WFL-42, API-WFL-43 (+1) |
| `wfl.aprobaciones.delegar` | Delegaciones | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-45, PAN-WFL-11 |
| `wfl.bandeja.supervisar` | Carga por persona y área | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-07, PAN-WFL-02 |
| `wfl.documentos.anular` | Anular con motivo | S D | T-GER, T-CJO | tenant | API-WFL-55 |
| `wfl.documentos.compartir` | Crear y revocar enlaces | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-57 |
| `wfl.documentos.descargar` | URL firmada de descarga (registra acceso) | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-CJO, T-SIN | tenant | API-WFL-54, API-WFL-63 |
| `wfl.documentos.retener` | Aplicar y liberar hold | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-58, API-WFL-59 |
| `wfl.eventos.reprocesar` | Acciones de la bandeja operativa | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, P-SUP, P-ADM | tenant / global | API-WFL-89, API-WFL-90 |
| `wfl.expedientes.exportar` | Exportar (job) | S | T-ADM | tenant | API-WFL-61 |
| `wfl.expedientes.gestionar` | Expedientes formales (abrir, cerrar, foliar, archivar) | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-62, PAN-WFL-15 |
| `wfl.firmas.solicitar` | Solicitar firma | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-75 |
| `wfl.flujos.publicar` | Publicar con vigencia (aprobación si PRM-WFL-030) | S D | T-GER, T-CJO | tenant | API-WFL-23, API-WFL-24, API-WFL-39 |
| `wfl.flujos.ver` | Catálogo de máquinas | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-CJO, T-SIN | tenant | API-WFL-17, API-WFL-18, API-WFL-26 (+4) |
| `wfl.formularios.configurar` | Formularios y publicación | S | T-ADM | tenant | API-WFL-25, PAN-WFL-07 |
| `wfl.instancias.administrar` | Ciclo de la instancia | S | T-ADM | tenant | API-WFL-31 |
| `wfl.instancias.iniciar` | Iniciar instancia desde admin | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-27 |
| `wfl.jobs.programar` | Programaciones y reprogramación | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-81 |
| `wfl.numeracion.configurar` | Secuencias | S | T-ADM | tenant | API-WFL-71, API-WFL-72, API-WFL-73 (+1) |
| `wfl.operaciones.reintentar` | Reintentar paso fallido | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-48, API-WFL-49, API-WFL-50 |
| `wfl.operaciones.ver` | Operaciones | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-CJO, T-SIN | tenant | API-WFL-47, PAN-WFL-13 |
| `wfl.plantillas.editar` | Guardar borrador | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-67 |
| `wfl.plantillas.publicar` | Publicar (aprobación si requiresApproval) | S D | T-GER, T-CJO | tenant | API-WFL-69 |
| `wfl.plantillas.ver` | Plantillas y versiones | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-CJO, T-SIN | tenant | API-WFL-66, API-WFL-68, API-WFL-70 (+1) |
| `wfl.tareas.crear` | Crear tarea ad hoc o recurrente | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC | tenant | API-WFL-08 |

##### M01 PER — Personas, titulares, cuentas, inmuebles (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `per.adherentes.baja` | Reemplazado por API-SOC-003 (HUECO-TRV-01; no se expone). Texto original: Baja con motivo. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-39, API-PER-40 |
| `per.adherentes.editar` | Reemplazado por API-SOC-001, API-SOC-002 y API-SOC-005 (HUECO-TRV-01; no se expone). Texto original: Lista, alta y modificación. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-38 |
| `per.adherentes.ver` | Reemplazado por API-SOC-001, API-SOC-002 y API-SOC-005 (HUECO-TRV-01; no se expone). Texto original: Lista, alta y modificación. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-38, PAN-PER-10 |
| `per.bloqueos.aplicar` | Lista y aplicación. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-42 |
| `per.bloqueos.levantar` | Levanta con motivo. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-43 |
| `per.bloqueos.ver` | Bloqueos activos que afectan un destino y efecto (incluye herencia titular → cuenta → contrato). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-41, API-PER-42 |
| `per.configuracion.configurar` | Parámetros del módulo (sección 14). | S | T-ADM | suc | API-PER-65, API-PER-67, PAN-PER-22 |
| `per.documentacion.configurar` | Tipos de requisito documental y acciones. | S | T-ADM | suc | API-PER-66 |
| `per.documentacion.editar` | Requisitos exigibles, presentaciones y validación. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-46 |
| `per.documentacion.ver` | Requisitos exigibles, presentaciones y validación. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-46, PAN-PER-13 |
| `per.domicilios.confirmarUbicacion` | Confirma, corrige, marca aproximado o para revisión con motivo. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-29 |
| `per.domicilios.editar` | Crea domicilio normalizado. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-27, API-PER-28, API-PER-30 |
| `per.domicilios.proponerUbicacion` | Confirma, corrige, marca aproximado o para revisión con motivo. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-29 |
| `per.duplicados.resolver` | Dismissed o confirmedSame con motivo. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-55, API-PER-56 |
| `per.duplicados.ver` | Bandeja de casos. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-54, PAN-PER-18 |
| `per.historial.ver` | Revisiones; parámetros asOfValid, asOfRecorded. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-53, PAN-PER-19 |
| `per.identificaciones.verificar` | Verificación ARCA (asíncrona, devuelve 202 con estado) o manual con evidencia. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-07 |
| `per.importaciones.crear` | Valida y encola importación (JOB-PER-09). | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-63, PAN-PER-24 |
| `per.inmuebles.crear` | Lista y alta de inmuebles. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-31 |
| `per.inmuebles.ver` | Lista y alta de inmuebles. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-31, API-PER-32, PAN-PER-07 |
| `per.me.autorizados.gestionar` | Otorga, lista y revoca autorizaciones que el titular concede. | — | C-SOC, C-REP | self | API-PER-71, PAN-PER-27 |
| `per.me.editarContactos` | Alta y cambio de contactos (fuente portal), con verificación; acepta clientMutationId. | — | C-SOC, C-REP | self | API-PER-69, API-PER-73 |
| `per.me.ver` | Personas vinculadas, titularidades y cuentas visibles con relación aplicable. | — | C-SOC, C-REP | self | API-PER-68, API-PER-72, PAN-PER-25 |
| `per.me.vincular` | Solicita y verifica vínculo con una persona (intentos limitados). | — | C-SOC, C-REP | self | API-PER-70, API-PER-76, PAN-PER-26 |
| `per.notas.crear` | Lista por destino y alta. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-44 |
| `per.notas.editar` | Nueva versión o borrado lógico con motivo (no aplica a notas de sistema). | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-45 |
| `per.notas.eliminar` | Nueva versión o borrado lógico con motivo (no aplica a notas de sistema). | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-45 |
| `per.notas.ver` | Lista por destino y alta. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-44 |
| `per.operacionesEspeciales.ejecutar` | Renumeración y correcciones especiales con aprobación. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-64, PAN-PER-21 |
| `per.padron.exportar` | Encola exportación (JOB-PER-12). | S | T-ADM | suc | API-PER-58 |
| `per.padron.ver` | Vista previa paginada con columnas y filtros. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-59, PAN-PER-20 |
| `per.personas.anonimizar` | Anonimiza (encola JOB-PER-11). | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-61 |
| `per.personas.registrarFallecimiento` | Registra fallecimiento y efectos. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-09, API-PER-10, PAN-PER-16 |
| `per.privacidad.gestionar` | Solicitudes de derechos. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-60, PAN-PER-23 |
| `per.puntosPrestacion.editar` | Lista, alta o reutilización, modificación. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-33 |
| `per.puntosPrestacion.ver` | Lista, alta o reutilización, modificación. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-33, PAN-PER-08, PAN-PER-28 |
| `per.relaciones.crear` | Lista y alta de relaciones. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-36 |
| `per.relaciones.revocar` | Verifica o revoca. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-37 |
| `per.relaciones.ver` | ¿Puede la persona X hacer la acción A sobre el destino D? Devuelve relación habilitante. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-35, API-PER-36, PAN-PER-09 |
| `per.relaciones.verificar` | Verifica o revoca. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-37 |
| `per.titulares.baja` | Lista impedimentos y advertencias para la baja. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-17, API-PER-18 |
| `per.titulares.crear` | Alta de titular (con primera cuenta opcional en el mismo cuerpo). | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-14 |
| `per.titulares.editar` | Modificación del titular. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-16 |
| `per.titulares.reactivar` | Reactivación con motivo. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-19 |
| `per.titulares.renumerar` | Renumeración y correcciones especiales con aprobación. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-64 |
| `per.titulares.ver` | Canónica propuesta para ext.per.titulares.ver. Consulta para integraciones autorizadas (por ejemplo, organismos con convenio) con campos mínimos y auditoría. | X | S-API, T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant / suc | API-PER-75, API-PER-13, API-PER-15, PAN-PER-01 (+1) |
| `per.transferencias.aprobar` | Aprueba o rechaza. | S D | T-ADM, T-SAT | suc | API-PER-49 |
| `per.transferencias.crear` | Simula y devuelve efectos y advertencias. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-47, API-PER-48, PAN-PER-14 |
| `per.transferencias.ejecutar` | Encola la ejecución; 202. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-50 |
| `per.transferencias.revertir` | Crea la transferencia inversa. | S D | T-ADM, T-SAT | suc | API-PER-51 |
| `per.transferencias.ver` | Lista y detalle con pasos y constancia. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-52, PAN-PER-15 |
| `per.vinculosUsuario.editar` | Gestión de vínculos usuario–persona desde backoffice. | — | T-ADM, T-FAC, T-CBR (P), T-TEC (P), T-LEC (P), T-ATE | suc | API-PER-62 |
| `per.vinculosUsuario.ver` | Gestión de vínculos usuario–persona desde backoffice. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-CMP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | suc | API-PER-62 |

##### M02 CAT — Catálogo de servicios (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `cat.adherentes.editar` | Reemplazado por API-SOC-001 a API-SOC-005 (M18, HUECO-TRV-01). Texto original: Adherentes y beneficiarios. | — | T-ADM | tenant | API-CAT-40 |
| `cat.adherentes.ver` | Reemplazado por API-SOC-001 a API-SOC-005 (M18, HUECO-TRV-01). Texto original: Adherentes y beneficiarios. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-STE, T-SCM, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-CAT-40, PAN-CAT-20 |
| `cat.capacidades.crear` | Crear capacidad. | — | P-SUP, P-ADM | global | API-CAT-02 |
| `cat.capacidades.editar` | Editar ficha/esquema (nueva versión de esquema). | — | P-SUP, P-ADM | global | API-CAT-03 |
| `cat.capacidades.ver` | Listar capacidades. | — | P-SUP, P-ADM, P-SEC | global | API-CAT-01, PAN-CAT-01 |
| `cat.categorias.editar` | Categorías y grupos. | — | T-ADM | tenant | API-CAT-24 |
| `cat.categorias.ver` | Categorías y grupos. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-STE, T-SCM, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-CAT-24, PAN-CAT-08 |
| `cat.clases.editar` | Clases de servicio. | — | T-ADM | tenant | API-CAT-25 |
| `cat.clases.ver` | Clases de servicio. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-STE, T-SCM, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-CAT-25, PAN-CAT-09 |
| `cat.comodatos.asignar` | Equipos del contrato; asignar. | — | T-ADM | tenant | API-CAT-37 |
| `cat.comodatos.devolver` | Registrar devolución/pérdida/reemplazo. | — | T-ADM | tenant | API-CAT-38 |
| `cat.comodatos.ver` | Equipos del contrato; asignar. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-STE, T-SCM, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-CAT-37, API-CAT-39, PAN-CAT-19 |
| `cat.conceptos.editar` | Conceptos facturables. | — | T-ADM | tenant | API-CAT-19, API-CAT-28, PAN-CAT-12 |
| `cat.conceptos.ver` | Conceptos facturables. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-STE, T-SCM, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-CAT-19 |
| `cat.contratos.activar` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | — | T-ADM | tenant | API-CAT-35 |
| `cat.contratos.anular` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | S D | T-GER | tenant | API-CAT-35 |
| `cat.contratos.baja` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | — | T-ADM | tenant | API-CAT-35 |
| `cat.contratos.cambiarCategoria` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | — | T-ADM | tenant | API-CAT-35 |
| `cat.contratos.cambiarPlan` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | — | T-ADM | tenant | API-CAT-35 |
| `cat.contratos.crear` | Crear contrato (requested); devuelve todos los errores/advertencias. | — | T-ADM | tenant | API-CAT-33, PAN-CAT-15 |
| `cat.contratos.editar` | Editar atributos no de estado (observaciones, referencias, atributos de dominio). | — | T-ADM | tenant | API-CAT-34, API-CAT-41, API-CAT-42 (+2) |
| `cat.contratos.marcar` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | — | T-ADM | tenant | API-CAT-35 |
| `cat.contratos.reactivar` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | — | T-ADM | tenant | API-CAT-35 |
| `cat.contratos.solicitarBaja` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | — | T-ADM | tenant | API-CAT-35 |
| `cat.contratos.suspender` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | — | T-ADM | tenant | API-CAT-35 |
| `cat.contratos.transferir` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | — | T-ADM | tenant | API-CAT-35 |
| `cat.contratos.trasladar` | Ejecutar transición/cambio (approve, requestFeasibility, activate, suspend, requestReactivation, reactivate,… | — | T-ADM | tenant | API-CAT-35 |
| `cat.contratos.ver` | Buscar contratos (paginado). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-STE, T-SCM, T-ATE, T-SAT, T-SOC, T-SIN, S-API | tenant | API-CAT-31, API-CAT-32, API-CAT-36 (+3), API-CAT-54, API-BIA-82, API-BIA-83, API-BIA-84 (+3) |
| `cat.copias.autorizarOrigen` | Autorización del tenant origen. | — | T-ADM | tenant | API-CAT-47 |
| `cat.copias.ejecutar` | Solicitar copia entre tenants. | — | T-ADM, P-SUP, P-ADM | tenant / global | API-CAT-46, API-CAT-48, PAN-CAT-18 |
| `cat.estados.configurar` | Estados operativos. | S | T-ADM | tenant | API-CAT-27, PAN-CAT-10 |
| `cat.habilitacion.ver` | Matriz tenants × capacidades. | — | P-SUP, P-ADM, P-SEC | global | API-CAT-04, PAN-CAT-02 |
| `cat.masivos.ejecutar` | Crear trámite masivo. | — | T-ADM | tenant | API-CAT-44, API-CAT-45, PAN-CAT-17 |
| `cat.misServicios.ver` | Contratos propios/representados (componente embebido en PAN-POR-29/30; HUE-SRV-04). | — | C-SOC, C-REP | self | API-CAT-50, PAN-CAT-22 |
| `cat.oferta.ver` | Oferta para la PWA (la consume el componente embebido en PAN-POR-31; HUE-SRV-04). | — | C-SOC, C-REP | rel | API-CAT-49, PAN-CAT-21 |
| `cat.paquetes.editar` | Paquetes. | — | T-ADM | tenant | API-CAT-23 |
| `cat.paquetes.ver` | Paquetes. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-STE, T-SCM, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-CAT-23, PAN-CAT-27 |
| `cat.planes.discontinuar` | Discontinuar plan. | — | T-ADM | tenant | API-CAT-22 |
| `cat.planes.editar` | Planes. | — | T-ADM | tenant | API-CAT-20, API-CAT-21 |
| `cat.planes.ver` | Planes. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-STE, T-SCM, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-CAT-20, PAN-CAT-07 |
| `cat.plantillas.editar` | Plantillas de servicio de plataforma (Adoptado DEC-026, PA-CAT-08). | — | P-SUP, P-ADM | global | API-CAT-55 |
| `cat.plantillas.ver` | Plantillas de servicio de plataforma (Adoptado DEC-026, PA-CAT-08). | — | P-SUP, P-ADM, P-SEC | global | API-CAT-55 |
| `cat.productos.ver` | Productos y subservicios. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-STE, T-SCM, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-CAT-18, PAN-CAT-06 |
| `cat.propiedades.editar` | Propiedades. | — | T-ADM | tenant | API-CAT-26 |
| `cat.propiedades.ver` | Propiedades. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-STE, T-SCM, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-CAT-26 |
| `cat.reglasAuto.configurar` | Reglas automáticas. | S | T-ADM | tenant | API-CAT-29, API-CAT-30, PAN-CAT-11 |
| `cat.servicios.configurar` | Crear servicio (desde cero o plantilla). | S | T-ADM | tenant | API-CAT-09, API-CAT-53, PAN-CAT-04 (+1) |
| `cat.servicios.retirar` | Abrir/cerrar oferta, retirar con alcance. | — | T-ADM | tenant | API-CAT-17 |
| `cat.versiones.aprobar` | Aprobar/rechazar. | S D | T-GER | tenant | API-CAT-15, API-CAT-43, PAN-CAT-05 |
| `cat.versiones.crear` | Crear versión borrador. | — | T-ADM | tenant | API-CAT-10, API-CAT-11, API-CAT-12 (+3) |

##### M03 MED — Medición y consumos (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `med.ajustes.crear` | Proponer regularización/ajuste; POST /:id/approve, /reject. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-49, PAN-MED-15 |
| `med.autolectura.crear` | Estado de ventana de autolectura. | — | T-CAJ, T-TEC, T-LEC (P), T-STE, C-SOC, C-REP | zona / rel | API-MED-71, API-MED-72, PAN-MED-32 |
| `med.campo.leer` | Lotes asignados al lecturista. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-29, API-MED-30, API-MED-33 (+3) |
| `med.campo.sincronizar` | Lote de mutaciones offline (clientMutationId por ítem); resultado por ítem. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-31, API-MED-32, PAN-MED-30 |
| `med.catalogos.configurar` | Alta/edición de ítem de catálogo. | S | T-ADM | zona | API-MED-02 |
| `med.catalogos.ver` | Lista un catálogo (brands, meter-types, reading-observations, reading-results, reading-conditions, meter-observations). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-01, PAN-MED-01 |
| `med.conflictos.resolver` | Conflictos offline. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-69, PAN-MED-34 |
| `med.consumos.aprobar` | Aprobación individual/masiva. | S D | T-SCM | zona | API-MED-42, API-MED-45, API-MED-74 (+1) |
| `med.consumos.bloquear` | Bloquear/desbloquear. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-43 |
| `med.consumos.distribuir` | ABM; POST /:id/run, /runs/:runId/revert. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-63, PAN-MED-17 |
| `med.consumos.dividir` | División/agrupación (dryRun/confirmar). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-62, PAN-MED-16 |
| `med.consumos.ver` | Canónica propuesta para med.read, consumption:read. Medidores: número, tipo, estado, punto, telemedido | X | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN, S-API | zona / tenant | API-BIA-88, API-BIA-89, API-BIA-90, API-MED-75, API-MED-41, API-MED-61, PAN-MED-12 |
| `med.cronograma.editar` | Cronogramas; POST /:id/publish. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-18 |
| `med.cronograma.ver` | Cronogramas; POST /:id/publish. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-18, PAN-MED-06 |
| `med.demanda.editar` | Demanda contratada; transgresiones; POST /transgressions/:id/reset. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-65 |
| `med.demanda.ver` | Demanda contratada; transgresiones; POST /transgressions/:id/reset. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-65, PAN-MED-19 |
| `med.ensayos.crear` | Registrar ensayo. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-08 |
| `med.excepciones.resolver` | Resolver una o varias (acción + justificación). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-47 |
| `med.excepciones.ver` | Bandeja de excepciones. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-46, PAN-MED-11 |
| `med.gas.configurar` | Factores de gas; POST /:id/approve. Reemplazado por API-TAR-030 (HUE-GAS-03): M03 consume la API de M04 en lectura. | S | T-ADM | zona | API-MED-66, PAN-MED-20 |
| `med.gd.editar` | Contratos GD; transiciones /approve, /connect, /suspend, /terminate. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-59 |
| `med.gd.ver` | Contratos GD; transiciones /approve, /connect, /suspend, /terminate. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-59, PAN-MED-26 |
| `med.informes.exportar` | Informes (sección 15); ?format=pdf/xlsx/csv. | S | T-ADM | zona | API-MED-68 |
| `med.informes.ver` | Informes (sección 15); ?format=pdf/xlsx/csv. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-68, API-MED-77, PAN-MED-22 (+1) |
| `med.instalaciones.anular` | Anular instalación/retiro. | S D | T-SCM | zona | API-MED-15 |
| `med.instalaciones.crear` | Instalar / retirar / cambiar (operación atómica). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-14, PAN-MED-04 |
| `med.jobs.ejecutar` | Contrato de datos de consumo aprobado por servicio y período (ver 13.3). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-60 |
| `med.lecturas.anular` | Anular. | S D | T-SCM | zona | API-MED-36 |
| `med.lecturas.crear` | Lectura manual (uno o varios canales). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-34, API-MED-44, PAN-MED-09 |
| `med.lecturas.importar` | Subir archivo + perfil → preview. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-38, API-MED-39, PAN-MED-10 |
| `med.lotes.asignar` | Asignar/reasignar tareas. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-21 |
| `med.lotes.cancelar` | Cancelar. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-27 |
| `med.lotes.cerrar` | Cerrar con decisión de pendientes. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-25 |
| `med.lotes.confirmar` | Confirmar (encola JOB-MED-03). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-24 |
| `med.lotes.crear` | Generar lote(s) (encola JOB-MED-01). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-19 |
| `med.lotes.exportar` | Exportar a archivo (perfil). | S | T-ADM | zona | API-MED-22 |
| `med.lotes.reabrir` | Reabrir. | S D | T-SCM | zona | API-MED-26 |
| `med.lotes.ver` | Listado/detalle con contadores. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-20, API-MED-23, API-MED-28 (+2) |
| `med.medicionPropia.editar` | Puntos y lecturas propias; GET /losses. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-67 |
| `med.medicionPropia.ver` | Puntos y lecturas propias; GET /losses. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-67, API-MED-78, PAN-MED-21 |
| `med.medidores.crear` | Alta de medidor. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-05, API-MED-07 |
| `med.miPrepago.ver` | Validar preventa y unidades estimadas. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN, C-SOC, C-REP | zona / self | API-MED-55, API-MED-73, PAN-MED-33 |
| `med.misConsumos.ver` | Mis consumos (solo servicios autorizados). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN, C-SOC, C-REP | zona / self | API-MED-70, PAN-MED-31 |
| `med.perfilesImportacion.configurar` | Perfiles de importación; POST /:id/test. | S | T-ADM | zona | API-MED-40 |
| `med.precintos.crear` | Registrar precinto (colocar/retirar/violado). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-09 |
| `med.prepago.reintentar` | Reintentar recarga fallida o pedir devolución a M07. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-57 |
| `med.prepago.ver` | Validar preventa y unidades estimadas. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-55, API-MED-56, API-MED-58 (+1) |
| `med.puntos.editar` | Alta/edición de punto (ZSR, acceso, testigo). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-12, API-MED-13 |
| `med.puntos.ver` | Listado de puntos. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-10, API-MED-11, PAN-MED-03 |
| `med.rutas.ver` | ABM de rutas; GET /:id/preview. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-16, PAN-MED-05 |
| `med.telemedicion.comandoCorte` | Encolar operación remota (exige originOrderId para corte/reconexión). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-50 |
| `med.telemedicion.comandoReconexion` | Encolar operación remota (exige originOrderId para corte/reconexión). | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-50 |
| `med.telemedicion.configurar` | Sistemas y mapeos; POST /:id/test-connection. | S | T-ADM | zona | API-MED-54, PAN-MED-23 |
| `med.telemedicion.reintentar` | Reintentar/cancelar. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-52 |
| `med.telemedicion.tomarEstado` | Toma de estado puntual o por lote. | — | T-CAJ, T-TEC, T-LEC (P), T-STE | zona | API-MED-53 |
| `med.telemedicion.ver` | Consulta con log saneado. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-51, PAN-MED-24 |
| `med.testigos.ver` | Testigos y consumos. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TEC, T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | zona | API-MED-64, PAN-MED-18 |

##### M04 TAR — Tarifas y motor de cálculo (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `tar.calculo.ejecutar` | Cargos precargados. | — | T-FAC | tenant | API-TAR-055, PAN-TAR-28 |
| `tar.calculo.explicar` | Cálculo con traza. | — | T-FAC | tenant | API-TAR-047, API-TAR-048, API-TAR-059 (+2) |
| `tar.config.configurar` | Parámetros PRM-TAR. | S | T-ADM | tenant | API-TAR-057, PAN-TAR-27 |
| `tar.cuadros.aprobar` | Firma de aprobación. | S D | T-GER | tenant | API-TAR-010, API-TAR-058, PAN-TAR-21 |
| `tar.cuadros.aprobarFinal` | Firma de aprobación. | S D | T-GER | tenant | API-TAR-010 |
| `tar.cuadros.crear` | Crear versión en borrador. | — | T-FAC | tenant | API-TAR-002, API-TAR-005 |
| `tar.cuadros.enviar` | Enviar a aprobación. | — | T-FAC | tenant | API-TAR-008, API-TAR-009 |
| `tar.cuadros.exportar` | Exportar Excel/PDF. | S | T-ADM | tenant | API-TAR-017 |
| `tar.cuadros.rechazar` | Rechazo con motivo. | S D | T-GER | tenant | API-TAR-011 |
| `tar.eventos.ver` | Cargos por evento y bonificaciones. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-TAR-032, PAN-TAR-18 |
| `tar.excepciones.aprobar` | Cancelar asignación. | S D | T-GER | tenant | API-TAR-042 |
| `tar.explicacion.ver` | Canónica propuesta para pwa.factura.explicacion.ver. Explicación para el socio (solo cuentas propias). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN, C-SOC, C-REP | tenant / rel | API-TAR-060, PAN-TAR-23 |
| `tar.formulas.editar` | Compilar y validar fórmula GFL (AST, dependencias, errores). | — | T-FAC | tenant | API-TAR-027, PAN-TAR-07 |
| `tar.formulas.probar` | Evaluar regla con contratos reales sin persistir. | — | T-FAC | tenant | API-TAR-028 |
| `tar.funciones.administrar` | Canónica propuesta para platform.tar.funciones.administrar. Catálogo global de funciones y plantillas ficticias. | S | P-SUP, P-ADM | global | API-TAR-065 |
| `tar.funciones.ver` | Catálogo de funciones y variables. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-TAR-029, PAN-TAR-08 |
| `tar.grupos.editar` | Grupos de beneficio y miembros. | — | T-FAC | tenant | API-TAR-033 |
| `tar.grupos.ver` | Grupos de beneficio y miembros. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-TAR-033, PAN-TAR-11 |
| `tar.inscripciones.editar` | Inscripciones por suministro. | — | T-FAC | tenant | API-TAR-037 |
| `tar.normas.adjuntar` | Vincular documento normativo (PDF). | — | T-FAC | tenant | API-TAR-018, API-TAR-019 |
| `tar.padrones.confirmar` | Confirmar padrón validado. | — | T-FAC | tenant | API-TAR-036 |
| `tar.padrones.exportar` | Exportación al organismo (asíncrono). | S | T-ADM | tenant | API-TAR-039, PAN-TAR-13 |
| `tar.padrones.importar` | Subir padrón (asíncrono). | — | T-FAC | tenant | API-TAR-035 |
| `tar.padrones.recategorizar` | Recategorización masiva (preview/aplicar). | — | T-FAC | tenant | API-TAR-038 |
| `tar.plantillas.administrar` | Canónica propuesta para platform.tar.plantillas.administrar. Catálogo global de funciones y plantillas ficticias. | S | P-SUP, P-ADM | global | API-TAR-065 |
| `tar.precios.actualizarMasivo` | Generar borrador con actualización masiva (vista previa con dryRun). | — | T-FAC | tenant | API-TAR-015, PAN-TAR-04 |
| `tar.precios.importar` | Importar planilla (asíncrono). | — | T-FAC | tenant | API-TAR-016, PAN-TAR-05 |
| `tar.promociones.asignar` | Asignar a contrato. | — | T-FAC | tenant | API-TAR-041 |
| `tar.promociones.crear` | Promociones. | — | T-FAC | tenant | API-TAR-040 |
| `tar.promociones.ver` | Promociones. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-TAR-040, PAN-TAR-14 |
| `tar.redondeo.configurar` | Políticas de redondeo. | S | T-ADM | tenant | API-TAR-054, PAN-TAR-25 |
| `tar.reglas.aprobar` | Ciclo de aprobación de regla. | S D | T-GER | tenant | API-TAR-026 |
| `tar.reglas.crear` | Crear regla. | — | T-FAC | tenant | API-TAR-022, API-TAR-024 |
| `tar.reglas.editar` | Editar borrador de regla. | — | T-FAC | tenant | API-TAR-023, API-TAR-025, API-TAR-026 (+1) |
| `tar.reglas.ver` | Listar reglas. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-TAR-021, PAN-TAR-06 |
| `tar.retroactivo.aprobar` | Aprobar (firma) o rechazar; al completar firmas pide ajustes a M05. | S D | T-GER | tenant | API-TAR-050 |
| `tar.retroactivo.calcular` | Calcular diferencias retroactivas (asíncrono). | — | T-FAC | tenant | API-TAR-049, PAN-TAR-22 |
| `tar.simulador.ejecutar` | Simulación individual (síncrona) o masiva (asíncrona, devuelve runId). | — | T-FAC | tenant | API-TAR-043, API-TAR-044, API-TAR-046 (+1) |
| `tar.simulador.masivo` | Simulación individual (síncrona) o masiva (asíncrona, devuelve runId). | — | T-FAC | tenant | API-TAR-043, API-TAR-045, PAN-TAR-16 |
| `tar.subsidios.configurar` | Regímenes de subsidio. | S | T-ADM | tenant | API-TAR-034 |
| `tar.subsidios.ver` | Regímenes de subsidio. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-TAR-034, API-TAR-037, PAN-TAR-12 |
| `tar.telefonia.configurar` | Configuración de tasación. | S | T-ADM | tenant | API-TAR-051 |
| `tar.telefonia.retasar` | Retasación por rango (asíncrona). | — | T-FAC | tenant | API-TAR-053 |
| `tar.telefonia.tasar` | Tasar llamada hipotética o pendientes. | — | T-FAC | tenant | API-TAR-052, PAN-TAR-20 |
| `tar.telefonia.ver` | Configuración de tasación. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-TAR-051, PAN-TAR-19 |

##### M05 FAC — Facturación (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `fac.anulaciones.aprobar` | Aprobar o rechazar; ejecuta JOB-FAC-09. | S D | T-GER, T-FAC | tenant | API-FAC-083 |
| `fac.bloqueos.bloquear` | Bloquear comprobantes o cuenta. | — | T-FAC, T-CAJ | tenant | API-FAC-087, API-FAC-100, API-FAC-101 (+3) |
| `fac.bloqueos.desbloquear` | Desbloquear. | S D | T-GER, T-FAC | tenant | API-FAC-088 |
| `fac.bloqueosCausas.configurar` | Causas de bloqueo. Reemplazado por holdReasons de M08 (CTR-DAT-36). | S | T-ADM, T-FAC | tenant | API-FAC-023, PAN-FAC-17 |
| `fac.cargos.anular` | Anular cargo no facturado. | S D | T-GER, T-FAC | tenant | API-FAC-106 |
| `fac.cargos.crear` | Ítems facturables manuales. | — | T-FAC, T-CAJ | tenant | API-FAC-105, PAN-FAC-21 |
| `fac.cargos.editar` | Ítems facturables manuales. | — | T-FAC, T-CAJ | tenant | API-FAC-105 |
| `fac.ciclos.crear` | Crear ciclo (borrador). | — | T-FAC, T-CAJ | tenant | API-FAC-002 |
| `fac.ciclos.editar` | Editar borrador o vigencia. | — | T-FAC, T-CAJ | tenant | API-FAC-003, API-FAC-004, API-FAC-011 (+1) |
| `fac.ciclos.ver` | Listar ciclos. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-FAC-001, API-FAC-005, PAN-FAC-02 |
| `fac.cierre.aprobar` | Aprobar (JOB-FAC-15). | S D | T-GER, T-FAC | tenant | API-FAC-135 |
| `fac.cierre.proponer` | Proponer acta (calcula cuadre). | — | T-FAC, T-CAJ | tenant | API-FAC-132, API-FAC-134, PAN-FAC-35 |
| `fac.cierre.reabrir` | Reabrir con motivo. | S D | T-GER, T-FAC | tenant | API-FAC-136 |
| `fac.codigoBarras.configurar` | Formatos de código de barras. | S | T-ADM, T-FAC | tenant | API-FAC-029, API-FAC-030, API-FAC-031 (+2) |
| `fac.comprobantes.crear` | Crear borrador de factura manual. | — | T-FAC, T-CAJ | tenant | API-FAC-073, API-FAC-074, API-FAC-075 (+4) |
| `fac.comprobantes.refacturar` | Iniciar refacturación puntual. | — | T-FAC, T-CAJ | tenant | API-FAC-079, PAN-FAC-13 |
| `fac.comprobantes.reimprimir` | Duplicado con motivo y cargo opcional. | — | T-FAC, T-CAJ | tenant | API-FAC-092 |
| `fac.comprobantes.replicar` | Crear borrador replicado. | — | T-FAC, T-CAJ | tenant | API-FAC-078, PAN-FAC-12 |
| `fac.cvlp.crear` | Proceso CVLP (O10). | — | T-FAC, T-CAJ | tenant | API-FAC-110 |
| `fac.cvlp.finalizar` | Proceso CVLP (O10). | — | T-FAC, T-CAJ | tenant | API-FAC-110 |
| `fac.cvlp.ver` | CVLP | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | PAN-FAC-37 |
| `fac.diseno.configurar` | Diseños de comprobante: reglas de selección en M05; el diseño y sus versiones se guardan en T11… | S | T-ADM, T-FAC | tenant | API-FAC-025, API-FAC-026, API-FAC-027 (+3) |
| `fac.distribucion.ejecutar` | Crear corrida de distribución (lote o selección). | — | T-FAC, T-CAJ | tenant | API-FAC-120, API-FAC-123, API-FAC-125 (+2) |
| `fac.distribucion.exportar` | PDF/archivo de imprenta ordenado (URL firmada). | S | T-ADM, T-FAC | tenant | API-FAC-124 |
| `fac.distribucion.ver` | Seguimiento con conteos. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-FAC-121, API-FAC-122, PAN-FAC-31 |
| `fac.excepciones.asignar` | Asignar responsable. | — | T-FAC, T-CAJ | tenant | API-FAC-065, API-FAC-068 |
| `fac.excepciones.excluir` | Excluir con causa. | — | T-FAC, T-CAJ | tenant | API-FAC-050, API-FAC-067 |
| `fac.excepciones.resolver` | Marcar resuelta (verifica que el dato esté corregido en el módulo dueño). | — | T-FAC, T-CAJ | tenant | API-FAC-066 |
| `fac.excepciones.ver` | Bandeja (filtra por alcance del usuario). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-FAC-063, API-FAC-064, PAN-FAC-08 |
| `fac.excepcionesMotivos.configurar` | Motivos de excepción. | S | T-ADM, T-FAC | tenant | API-FAC-024, PAN-FAC-42 |
| `fac.facturacion.ejecutar` | Reemplazado por billableItems de M05 (CTR-DAT-38): M11 crea los cargos con fac.service.upsertBillableItem y M05 proyecta las… | — | T-FAC, T-CAJ | tenant | API-VEN-006, API-VEN-007 |
| `fac.grupos.crear` | Grupos de facturación. | — | T-FAC, T-CAJ | tenant | API-FAC-018 |
| `fac.grupos.desarmar` | Disolver desde un período. | — | T-FAC, T-CAJ | tenant | API-FAC-020 |
| `fac.grupos.editar` | Grupos de facturación. | — | T-FAC, T-CAJ | tenant | API-FAC-018 |
| `fac.grupos.validarFiscal` | Aprobar o rechazar validación fiscal. | — | T-FAC, T-CAJ | tenant | API-FAC-019 |
| `fac.grupos.ver` | Grupos de facturación. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-FAC-018, PAN-FAC-25 |
| `fac.importaciones.crear` | Subir archivo con formato. | — | T-FAC, T-CAJ | tenant | API-FAC-107, API-FAC-108, API-FAC-109 (+1) |
| `fac.lotes.cancelar` | Cancelar (solo sin emitidos). | — | T-FAC, T-CAJ | tenant | API-FAC-058 |
| `fac.lotes.crear` | Crear lote draft (ciclo, adHoc, simulation). | — | T-FAC, T-CAJ | tenant | API-FAC-041, API-FAC-043, API-FAC-059 (+1) |
| `fac.lotes.exportar` | Exportar casos y resultados. | S | T-ADM, T-FAC | tenant | API-FAC-061 |
| `fac.lotes.pausar` | Pausar al terminar el bloque. | — | T-FAC, T-CAJ | tenant | API-FAC-056 |
| `fac.lotes.prefacturar` | Prefacturar (todo o casos afectados) (202). | — | T-FAC, T-CAJ | tenant | API-FAC-047 |
| `fac.lotes.preparar` | Preparar y congelar v1 (202). | — | T-FAC, T-CAJ | tenant | API-FAC-044, API-FAC-045 |
| `fac.lotes.reanudar` | Reanudar desde el último bloque confirmado. | — | T-FAC, T-CAJ | tenant | API-FAC-057 |
| `fac.lotes.ver` | Listar lotes. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-FAC-040, API-FAC-042, API-FAC-046 (+9) |
| `fac.modalidad.configurar` | Política de modalidad. | S | T-ADM, T-FAC | tenant | API-FAC-017, PAN-FAC-26 |
| `fac.modificacionMasiva.aprobar` | Aprobar y aplicar (202). | S D | T-GER, T-FAC | tenant | API-FAC-103 |
| `fac.modificacionMasiva.crear` | Crear operación. | — | T-FAC, T-CAJ | tenant | API-FAC-100, API-FAC-101, API-FAC-102 (+2) |
| `fac.notasCredito.aprobar` | Aprobar o rechazar; ejecuta JOB-FAC-09. | S D | T-GER, T-FAC | tenant | API-FAC-083 |
| `fac.numeracion.configurar` | Numeradores (alta, bloqueo; el último número solo cambia con override auditado); cada numerador pertenece a una entidad… | S | T-ADM, T-FAC | tenant | API-FAC-016 |
| `fac.overrides.aprobar` | Registrar override de validación con motivo. | S D | T-GER, T-FAC | tenant | API-FAC-062 |
| `fac.parametros.configurar` | Parámetros del módulo (vía T04). | S | T-ADM, T-FAC | tenant | API-FAC-035, PAN-FAC-41 |
| `fac.plantillas.editar` | ABM de plantillas de corrida. | — | T-FAC, T-CAJ | tenant | API-FAC-009, API-FAC-010 |
| `fac.plantillas.ver` | ABM de plantillas de corrida. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-FAC-009, PAN-FAC-04 |
| `fac.preferencias.editar` | Preferencias de entrega del titular. | — | T-FAC, T-CAJ | tenant | API-FAC-139, PAN-FAC-40 |
| `fac.puntosVenta.configurar` | Puntos de venta. Reemplazado por la API de puntos de venta de M06 (CTR-DAT-17); queda solo GET de lectura con ?legalEntityId=. | S | T-ADM, T-FAC | tenant | API-FAC-015, PAN-FAC-24 |
| `fac.recategorizacion.confirmar` | Aprobar y aplicar (202). | — | T-FAC, T-CAJ | tenant | API-FAC-103 |
| `fac.recategorizacion.simular` | Crear operación. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-FAC-100, API-FAC-101, API-FAC-102 (+2) |
| `fac.relaciones.editar` | Consultar y registrar relaciones manuales. | — | T-FAC, T-CAJ | tenant | API-FAC-086, PAN-FAC-15 |
| `fac.reparto.configurar` | Rutas de reparto. | S | T-ADM, T-FAC | tenant | API-FAC-033, API-FAC-034, PAN-FAC-33 |
| `fac.reparto.registrarEntrega` | Sincronizar entregas offline (lote de mutaciones con clientMutationId). | — | T-FAC, T-CAJ, C-EMP | tenant / self | API-FAC-126, API-FAC-127, PAN-FAC-46 |
| `fac.reportes.ver` | Reportes de §15 (exportar con fac.reportes.exportar). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-FAC-138, PAN-FAC-36 |
| `fac.retroactivos.aprobar` | Aprobar y aplicar (202). | S D | T-GER, T-FAC | tenant | API-FAC-103 |
| `fac.retroactivos.crear` | Crear operación. | — | T-FAC, T-CAJ | tenant | API-FAC-100, API-FAC-101, API-FAC-102 (+2) |
| `fac.talones.eliminar` | Anular no pagado. | — | T-FAC, T-CAJ | tenant | API-FAC-130 |
| `fac.talones.generar` | Generar talón sumado o de cuotas. | — | T-FAC, T-CAJ | tenant | API-FAC-128, API-FAC-129, PAN-FAC-32 |
| `fac.tiposComprobante.configurar` | Tipos de comprobante. | S | T-ADM, T-FAC | tenant | API-FAC-012, API-FAC-013, PAN-FAC-23 |
| `fac.tramas.configurar` | Tramas de vencimiento y recargo. | S | T-ADM, T-FAC | tenant | API-FAC-021, API-FAC-022, PAN-FAC-27 |
| `fac.universos.crear` | ABM de universos. | — | T-FAC, T-CAJ | tenant | API-FAC-006 |
| `fac.universos.editar` | ABM de universos. | — | T-FAC, T-CAJ | tenant | API-FAC-006, API-FAC-008 |
| `fac.universos.ver` | ABM de universos. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-SCM, T-ATE, T-SAT, T-SIN | tenant | API-FAC-006, API-FAC-007, PAN-FAC-03 |

##### M06 FIS — Fiscal e impuestos (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `fis.admPublica.editar` | Selección de administración pública (DELETE quita ítems, no borra comprobantes) | — | T-FAC, T-CON | tenant | API-FIS-76 |
| `fis.admPublica.ver` | Selección de administración pública (DELETE quita ítems, no borra comprobantes) | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-76, PAN-FIS-37 |
| `fis.arca.configurar` | Genera clave y CSR en bóveda | S | T-ADM, T-CON | tenant | API-FIS-11, API-FIS-12, API-FIS-13 (+3) |
| `fis.arcaParametros.sincronizar` | Sincroniza tablas ARCA | — | P-SUP, P-ADM | global | API-FIS-04, PAN-FIS-02 |
| `fis.autorizaciones.enviar` | Encola selección (ids o filtros) | — | T-FAC, T-CON | tenant | API-FIS-22, API-FIS-24 |
| `fis.autorizaciones.previsualizar` | Vista previa del request | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-25, PAN-FIS-11 |
| `fis.autorizaciones.reintentar` | Reintenta (consulta previa si incierto) | — | T-FAC, T-CON | tenant | API-FIS-23 |
| `fis.autorizaciones.ver` | Lista paginada con filtros | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-20, API-FIS-21, PAN-FIS-09 |
| `fis.bandeja.derivar` | Deriva a corrección (responsable) | — | T-FAC, T-CON | tenant | API-FIS-26 |
| `fis.bandeja.ver` | Bandeja de excepciones fiscales | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | PAN-FIS-10 |
| `fis.caea.informar` | Informa comprobantes CAEA | — | T-FAC, T-CON | tenant | API-FIS-33, API-FIS-34 |
| `fis.caea.solicitar` | Lista / solicita o consulta CAEA | — | T-FAC, T-CON | tenant | API-FIS-32, API-FIS-35, PAN-FIS-14 |
| `fis.certificadosRetencion.ver` | Certificado (URL firmada) | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-56 |
| `fis.cesp.configurar` | CESP | S | T-ADM, T-CON | tenant | API-FIS-36, PAN-FIS-15 |
| `fis.conciliacion.aprobar` | Ejecuta conciliación de inconsistencias | S D | T-GER, T-CON | tenant | API-FIS-30, API-FIS-31, PAN-FIS-13 |
| `fis.conector.ver` | Estado observable | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-16, PAN-FIS-39 |
| `fis.exclusiones.editar` | Alícuotas determinadas y exclusiones | — | T-FAC, T-CON | tenant | API-FIS-48 |
| `fis.impuestos.configurar` | CVP | S | T-ADM, T-CON | tenant | API-FIS-37, API-FIS-38, API-FIS-39 (+9) |
| `fis.impuestos.ver` | Calcula impuestos de un documento | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-42, API-FIS-43 |
| `fis.libroIva.cerrar` | Cierra/reabre | — | T-FAC, T-CON | tenant | API-FIS-60 |
| `fis.libroIva.generar` | Genera libro (job) | — | T-FAC, T-CON | tenant | API-FIS-59, API-FIS-61, PAN-FIS-30 |
| `fis.libroIva.reabrir` | Cierra/reabre | S D | T-GER, T-CON | tenant | API-FIS-60 |
| `fis.libroIva.ver` | Resultado de conciliación | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-62, PAN-FIS-29 |
| `fis.obligaciones.ver` | Obligaciones y calendario | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-58, PAN-FIS-28 |
| `fis.padrones.aprobar` | Activa padrón | S D | T-GER, T-CON | tenant | API-FIS-46 |
| `fis.padrones.importar` | Lista / importa padrón | — | T-FAC, T-CON | tenant | API-FIS-45, API-FIS-50, PAN-FIS-21 |
| `fis.pasarela.consultar` | Estado y CAE | X | S-API | tenant | API-FIS-78 |
| `fis.pasarela.enviar` | Envía comprobante externo | X | T-FAC, T-CON, S-API | tenant | API-FIS-77, API-FIS-79, PAN-FIS-38 |
| `fis.perfil.editar` | Perfil fiscal (nueva versión en PUT) | — | T-FAC, T-CON | tenant | API-FIS-08, API-FIS-09, PAN-FIS-05 |
| `fis.perfil.ver` | Perfil fiscal (nueva versión en PUT) | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-08, PAN-FIS-04 |
| `fis.puntosVenta.configurar` | Puntos de venta y modalidades | S | T-ADM, T-CON | tenant | API-FIS-17, API-FIS-18, API-FIS-19 (+2) |
| `fis.regimenes.generar` | Lista / genera declaración | — | T-FAC, T-CON | tenant | API-FIS-63, PAN-FIS-31 |
| `fis.regimenes.presentar` | Aprueba | — | T-FAC, T-CON | tenant | API-FIS-65, API-FIS-66, API-FIS-67 |
| `fis.regimenes.rectificar` | Crea rectificativa | — | T-FAC, T-CON | tenant | API-FIS-68 |
| `fis.regimenes.validar` | Valida archivos | — | T-FAC, T-CON | tenant | API-FIS-64, API-FIS-69, PAN-FIS-32 |
| `fis.reguladores.configurar` | Mapas de conceptos | S | T-ADM, T-CON | tenant | API-FIS-75, PAN-FIS-36 |
| `fis.reguladores.generar` | Informes regulatorios | — | T-FAC, T-CON | tenant | API-FIS-73 |
| `fis.reguladores.presentar` | Presentación y acuse | — | T-FAC, T-CON | tenant | API-FIS-74 |
| `fis.reguladores.ver` | Informes a reguladores | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | PAN-FIS-35 |
| `fis.rendiciones.aprobar` | Aprueba y solicita OP a M14 | S D | T-GER, T-CON | tenant | API-FIS-72 |
| `fis.rendiciones.generar` | Rendiciones | — | T-FAC, T-CON | tenant | API-FIS-71, PAN-FIS-34 |
| `fis.retenciones.calcular` | Calcula retenciones de una OP | — | T-FAC, T-CON | tenant | API-FIS-52 |
| `fis.retenciones.configurar` | Condiciones de agente | S | T-ADM, T-CON | tenant | API-FIS-10, API-FIS-51, API-FIS-57 (+4) |
| `fis.retenciones.ver` | Retenciones practicadas | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-55, PAN-FIS-26 |
| `fis.service.calculateTaxes` | Calcula impuestos de un documento | — | T-FAC, T-CON | tenant | API-FIS-42 |
| `fis.service.calculateWithholdings` | Calcula retenciones de una OP | — | T-FAC, T-CON | tenant | API-FIS-52 |
| `fis.tablasNormativas.adoptar` | Versiones pendientes y adoptadas | — | T-FAC, T-CON | tenant | API-FIS-05, API-FIS-06, API-FIS-07 (+1) |
| `fis.tablasNormativas.crear` | Crea versión borrador con fuente | — | P-SUP, P-ADM | global | API-FIS-02 |
| `fis.tablasNormativas.publicar` | Publica versión | S D | P-SUP, P-ADM | global | API-FIS-03 |
| `fis.tablasNormativas.ver` | Lista tablas y versiones | — | P-SUP, P-ADM, P-SEC | global | API-FIS-01, PAN-FIS-01 |
| `fis.terceros.configurar` | Convenios | S | T-ADM, T-CON | tenant | API-FIS-70, PAN-FIS-33 |
| `fis.ultimoComprobante.consultar` | FECompUltimoAutorizado | — | T-ADM, T-GER, T-FAC, T-TES, T-CON, T-CMP, T-RRHH, T-SIN | tenant | API-FIS-28, API-FIS-29, PAN-FIS-12 |

##### M07 COB — Cuenta corriente y cobranza (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `cob.ajustes.aprobar` | Ajuste de redondeo o causa catalogada (no fiscal). | S D | T-GER, T-TES, T-SAT | suc | API-COB-19 |
| `cob.autoOffset.ejecutar` | Simular o ejecutar cancelación automática. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-14, PAN-COB-05 |
| `cob.bloqueos.gestionar` | Bloqueo/desbloqueo individual o masivo. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-22, PAN-COB-31 |
| `cob.caja.anular` | Anular (supervisor si corresponde). | S D | T-GER, T-TES, T-SAT | suc | API-COB-36, PAN-COB-11 |
| `cob.caja.anularOtroUsuario` | Anulación de cobranza | S D | T-GER, T-TES, T-SAT | suc | PAN-COB-11 |
| `cob.caja.aprobarDiferencia` | Aprobar diferencia. | S D | T-GER, T-TES, T-SAT | suc | API-COB-31, PAN-COB-12 |
| `cob.caja.cobrar` | Sesión abierta del usuario. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-28, API-COB-33, API-COB-34 (+3) |
| `cob.caja.egresar` | Ingreso/egreso manual, donación, pago a proveedor. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-35 |
| `cob.caja.reabrir` | Reabrir. | S D | T-GER, T-TES, T-SAT | suc | API-COB-32, PAN-COB-12 |
| `cob.caja.ver` | Cheques recibidos. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-ATE, T-SAT, T-SIN | suc | API-COB-43, PAN-COB-33 |
| `cob.cajas.configurar` | ABM de cajas y QR estático. | S | T-ADM, T-TES | suc | API-COB-26, PAN-COB-08 |
| `cob.cobradores.gestionar` | Cobradores. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-73, API-COB-74, PAN-COB-28 |
| `cob.cobradores.rendir` | Rendición del cobrador. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-85, PAN-COB-29 |
| `cob.cobranzaCampo.cobrar` | Sincronizar cola offline (clientMutationId por ítem). | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-84, PAN-COB-29 |
| `cob.cobranzaCampo.ver` | Listas asignadas (descarga offline). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-ATE, T-SAT, T-SIN | suc | API-COB-83, PAN-COB-29 |
| `cob.conciliacion.cerrar` | Cerrar con acta. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-72, PAN-COB-27 |
| `cob.conciliacion.conciliar` | Emparejar ítems. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-71, PAN-COB-27 |
| `cob.conciliacion.ver` | Tablero por día y canal. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-ATE, T-SAT, T-SIN | suc | API-COB-70, PAN-COB-27 |
| `cob.contracargos.gestionar` | Contracargos y disputa. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-69, PAN-COB-26 |
| `cob.creditos.aplicar` | Aplicar saldo a obligaciones. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-12, PAN-COB-03 |
| `cob.creditos.aprobar` | Cambiar aplicación automática / próxima factura. | S D | T-GER, T-TES, T-SAT | suc | API-COB-13, PAN-COB-03 |
| `cob.creditos.crear` | Listar y crear anticipos o saldos a favor. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-11, PAN-COB-03 |
| `cob.cuentas.importar` | Importar obligaciones externas (vista previa y confirmación). | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-23, PAN-COB-32 |
| `cob.cuentas.ver` | Buscar cuentas corrientes (titular, documento, cuenta, código, identificador de pago). | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-ATE, T-SAT, T-SIN | suc | API-COB-01, API-COB-02, API-COB-03 (+3) |
| `cob.debitos.adherir` | Adhesiones (alta, suspensión, cancelación, exclusiones). | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-55, PAN-COB-21 |
| `cob.debitos.importar` | Novedades y morosidad. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-54, API-COB-57, PAN-COB-20 (+1) |
| `cob.debitos.presentar` | Generar/presentar lote. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-56, PAN-COB-22 |
| `cob.debitos.ver` | Adhesiones a débito automático | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-ATE, T-SAT, T-SIN | suc | PAN-COB-21 |
| `cob.descuentos.configurar` | Configuración de medios, tarjetas y descuentos. | S | T-ADM, T-TES | suc | API-COB-42, PAN-COB-16 |
| `cob.devoluciones.aprobar` | Aprobar/rechazar (segregación). | S D | T-GER, T-TES, T-SAT | suc | API-COB-67, PAN-COB-26 |
| `cob.devoluciones.ejecutar` | Ejecutar. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-68, PAN-COB-26 |
| `cob.devoluciones.solicitar` | Expedientes. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-66, PAN-COB-26 |
| `cob.entes.configurar` | ABM de entes. | S | T-ADM, T-TES | suc | API-COB-46, PAN-COB-17 |
| `cob.entes.confirmar` | Confirmar líneas seleccionadas. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-53, PAN-COB-19 |
| `cob.entes.exportar` | Vista previa de exportación. | S | T-ADM, T-TES | suc | API-COB-48, API-COB-49, API-COB-50 (+1) |
| `cob.entes.importar` | Subir rendición o consultar API por fecha. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-51, API-COB-52, PAN-COB-19 |
| `cob.excepciones.resolver` | Bandeja de excepciones. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-75, PAN-COB-34 |
| `cob.imputaciones.aprobar` | Aprobar o rechazar. | S D | T-GER, T-TES, T-SAT | suc | API-COB-10, PAN-COB-02 |
| `cob.imputaciones.crear` | Simulación del motor (dryRun). | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-06, API-COB-07, PAN-COB-02 (+1) |
| `cob.imputaciones.reasignar` | Reverso con motivo. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-08, API-COB-09, PAN-COB-02 |
| `cob.integridad.ver` | Resultados de JOB-COB-14; POST lanza verificación. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-ATE, T-SAT, T-SIN | suc | API-COB-25 |
| `cob.intenciones.cancelar` | Cancelar. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-63, PAN-COB-24 |
| `cob.intenciones.crear` | Crear intención o link (reutiliza dentro de la ventana). | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-61, API-COB-65, PAN-COB-24 |
| `cob.intenciones.reprocesar` | Reconsultar al proveedor y reprocesar. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-62, PAN-COB-24 |
| `cob.intenciones.ver` | Listar intenciones. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-ATE, T-SAT, T-SIN | suc | API-COB-60, PAN-COB-24 |
| `cob.layouts.configurar` | Layouts versionados; POST /{id}/test prueba con archivo. | S | T-ADM, T-TES | suc | API-COB-47, PAN-COB-17 |
| `cob.links.crear` | Crear intención o link (reutiliza dentro de la ventana). | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-61, API-COB-64, PAN-COB-25 |
| `cob.medios.configurar` | Configuración de medios, tarjetas y descuentos. | S | T-ADM, T-TES | suc | API-COB-42, PAN-COB-15 |
| `cob.miCuenta.adherirDebito` | Adhesión del socio. | — | C-SOC, C-REP, público (sin login) | self / público | API-COB-81, PAN-COB-35 |
| `cob.miCuenta.informarTransferencia` | Informar transferencia con comprobante. | — | C-SOC, C-REP, público (sin login) | self / público | API-COB-82, PAN-COB-35 |
| `cob.miCuenta.pagar` | Iniciar pago. | — | C-SOC, C-REP, público (sin login) | self / público | API-COB-79, API-COB-80, PAN-COB-35 |
| `cob.miCuenta.ver` | Cuentas autorizadas y saldos. | — | C-SOC, C-REP, público (sin login) | self / público | API-COB-77, API-COB-78, PAN-COB-35 |
| `cob.noIdentificados.aplicar` | Aplicar (genera recibo). | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-17, API-COB-18, PAN-COB-04 |
| `cob.noIdentificados.identificar` | Identificar titular y obligaciones con evidencia. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-16, PAN-COB-04 |
| `cob.noIdentificados.ver` | Bandeja. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-ATE, T-SAT, T-SIN | suc | API-COB-15, PAN-COB-04 |
| `cob.politicas.configurar` | Políticas versionadas (borrador, publicar). | S | T-ADM, T-TES | suc | API-COB-24, PAN-COB-07 |
| `cob.qr.cobrar` | Cargar importe en el QR del puesto y esperar confirmación. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-37 |
| `cob.recibos.enviar` | Enviar por el motor de comunicaciones de T09 (com.communications.emit; antes "canal M10"). | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-40, PAN-COB-14 |
| `cob.recibos.reimprimir` | Recibos | — | T-CAJ, T-CBR (P), T-TES | suc | PAN-COB-14 |
| `cob.recibos.ver` | Listar recibos. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-ATE, T-SAT, T-SIN | suc | API-COB-38, API-COB-39, PAN-COB-14 |
| `cob.rendiciones.ingestar` | Ingesta de rendición por API de un ente o agregador. | X | S-API | tenant | API-COB-90, API-COB-91 |
| `cob.rendiciones.recibir` | Rendiciones; POST /{id}/receive y /{id}/reject. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-41, PAN-COB-13 |
| `cob.reportes.exportar` | Reportes de cobranza | S | T-ADM, T-TES | suc | PAN-COB-36 |
| `cob.reportes.ver` | Reporte; ?format=xlsx/csv/pdf exige cob.reportes.exportar. | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-ATE, T-SAT, T-SIN | suc | API-COB-76, PAN-COB-36 |
| `cob.resumenes.emitir` | Listar y emitir resúmenes. | — | T-CAJ, T-CBR (P), T-TES | suc | API-COB-20, API-COB-21, PAN-COB-06 |
| `cob.terceros.configurar` | Terceros. | S | T-ADM, T-TES | suc | API-COB-44, PAN-COB-30 |
| `cob.webhooks.recibir` | Webhook de pasarela: registra, deduplica y responde 200. | X | S-API | tenant | API-COB-89 |

##### M08 MOR — Mora y financiación (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `mor.bloqueos.crear` | Listar / aplicar bloqueos (individual o masivo) | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-23 |
| `mor.bloqueos.liberar` | Liberar bloqueo (opcional con interés) | S D | T-GER, T-TES, T-SAT | suc | API-MOR-24 |
| `mor.candidatos.generar` | Previsualizar candidatos con exclusiones | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-32, API-MOR-33, PAN-MOR-13 |
| `mor.cargosInterrupcion.configurar` | ABM de reglas de cargos | S | T-ADM | suc | API-MOR-59, PAN-MOR-28 |
| `mor.causas.configurar` | ABM de causas de bloqueo | S | T-ADM | suc | API-MOR-25, API-MOR-52, PAN-MOR-26 |
| `mor.convenios.aceptar` | Solicitar, aceptar (OTP) y firmar convenio | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-89 |
| `mor.convenios.anular` | Anular (valida RN-MOR-121) | S D | T-GER, T-TES, T-SAT | suc | API-MOR-70 |
| `mor.convenios.cancelarAnticipado` | Cotizar y confirmar cancelación anticipada | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-68, API-MOR-91 |
| `mor.convenios.declararCaducidad` | Declarar caducidad / rehabilitar | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-69 |
| `mor.convenios.editar` | Cambiar garante | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-71, API-MOR-72 |
| `mor.convenios.enviarFirma` | Enviar enlace de firma (OTP) | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-66 |
| `mor.convenios.firmar` | Solicitar, aceptar (OTP) y firmar convenio | S D | T-GER, T-TES, T-SAT | suc | API-MOR-89 |
| `mor.convenios.imprimir` | PDF convenio, talonario o liquidación | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-73 |
| `mor.convenios.registrarFirma` | Registrar firma presencial | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-67 |
| `mor.convenios.solicitar` | Solicitar, aceptar (OTP) y firmar convenio | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-89 |
| `mor.convenios.ver` | Listar / ficha | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-64, API-MOR-90, PAN-MOR-31 |
| `mor.cotizacion.ver` | Cotizar recargo de documentos a una fecha | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-13, API-MOR-14, PAN-MOR-07 |
| `mor.descuentosProntoPago.configurar` | ABM de descuentos por pronto pago | S | T-ADM | suc | API-MOR-12, PAN-MOR-06 |
| `mor.deuda.ver` | Expedientes de seguimiento y contactos | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-85, PAN-MOR-01, PAN-MOR-18 (+1) |
| `mor.deudas.ver` | Canónica propuesta para arrears:read. Notificaciones e instancias de mora por cuenta | X | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN, S-API | suc / tenant | API-BIA-98, API-BIA-99, API-BIA-100 |
| `mor.dispensaRecargo.aprobar` | Aprobar/rechazar dispensa | S D | T-GER, T-TES, T-SAT | suc | API-MOR-16 |
| `mor.dispensaRecargo.solicitar` | Solicitar dispensa del recargo | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-15 |
| `mor.entidadesFinancieras.configurar` | ABM de entidades financieras | S | T-ADM | suc | API-MOR-61, PAN-MOR-32 |
| `mor.estudios.configurar` | ABM de estudios | S | T-ADM | suc | API-MOR-76 |
| `mor.evaluaciones.ejecutar` | Evaluar una cuenta o universo a una fecha | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-28 |
| `mor.evaluaciones.ver` | Consultar evaluaciones | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-29 |
| `mor.excepciones.aprobar` | Autorizar / desautorizar | S D | T-GER, T-TES, T-SAT | suc | API-MOR-47 |
| `mor.excepciones.editar` | ABM de excepciones | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-46 |
| `mor.excepciones.ver` | ABM de excepciones | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-46, PAN-MOR-23 |
| `mor.ext.condicionMora.ver` | Condición de mora por cuenta (exportación regulatoria) | X | S-API | tenant | API-MOR-98 |
| `mor.ext.expedientes.registrar` | Registrar avance/costo | X | S-API | tenant | API-MOR-97 |
| `mor.ext.expedientes.ver` | Expedientes asignados | X | S-API | tenant | API-MOR-96 |
| `mor.garantias.editar` | ABM y acciones de garantías | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-74, API-MOR-75 |
| `mor.garantias.ver` | ABM y acciones de garantías | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-74, PAN-MOR-33 |
| `mor.gastosJudiciales.registrar` | Movimientos del expediente | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-78 |
| `mor.gestionExterna.editar` | Expedientes externos/judiciales | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-77, API-MOR-78 |
| `mor.gestionExterna.ver` | Expedientes externos/judiciales | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-77, PAN-MOR-34 |
| `mor.gestionExterna.verAsignados` | Portal de estudios | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | PAN-MOR-42 |
| `mor.incobrables.aprobar` | Aprobar / rechazar / revertir | S D | T-GER, T-TES, T-SAT | suc | API-MOR-80 |
| `mor.incobrables.proponer` | Proponer incobrables | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-79 |
| `mor.incobrables.ver` | Incobrables | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | PAN-MOR-35 |
| `mor.indices.importar` | Importar valores (preview y confirmación) | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-09 |
| `mor.indices.ver` | Listar / crear tablas de índices | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-08 |
| `mor.informes.exportar` | Exportar informe (asíncrono) | S | T-ADM | suc | API-MOR-84 |
| `mor.informes.ver` | Ejecutar informe con filtros y fecha de corte | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-83 |
| `mor.interesesFacturar.aprobar` | Aprobar corrida | S D | T-GER, T-TES, T-SAT | suc | API-MOR-20 |
| `mor.interesesFacturar.cancelar` | Cancelar corrida | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-22 |
| `mor.interesesFacturar.ejecutar` | Generar cargos (job) | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-21 |
| `mor.interesesFacturar.simular` | Tildar/destildar documentos o tramos | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-19 |
| `mor.interesesFacturar.ver` | Listar / crear corrida (draft + preview) | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-17, API-MOR-18 |
| `mor.interrupciones.aprobar` | Aprobar / rechazar | S D | T-GER, T-TES, T-SAT | suc | API-MOR-56, API-MOR-57 |
| `mor.interrupciones.solicitar` | Opciones de suspensión/reactivación habilitadas y costos | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE, C-SOC, C-REP | suc / rel | API-MOR-93, API-MOR-94, API-MOR-95 (+1) |
| `mor.interrupciones.ver` | Listar / ficha | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-55, PAN-MOR-27 |
| `mor.lotes.anular` | Anular lote | S D | T-GER, T-TES, T-SAT | suc | API-MOR-34 |
| `mor.miDeuda.ver` | Deuda vencida del socio con cotización a hoy | — | C-SOC, C-REP | self | API-MOR-86, PAN-MOR-39 |
| `mor.misAvisos.ver` | Avisos del socio con constancias | — | C-SOC, C-REP | self | API-MOR-87 |
| `mor.modelosAviso.configurar` | ABM de modelos de aviso (versionados) | S | T-ADM | suc | API-MOR-31, PAN-MOR-12 |
| `mor.notificaciones.calificar` | Calificar | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-39, PAN-MOR-17 |
| `mor.notificaciones.cerrar` | Cerrar notificaciones (lote, bloqueo opcional) | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-41 |
| `mor.notificaciones.darBaja` | Dar de baja con causa (lote) | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-40 |
| `mor.notificaciones.exportar` | Exportar circulares / archivo para envío masivo | S | T-ADM | suc | API-MOR-43 |
| `mor.notificaciones.imprimir` | Generar PDF agrupado por titular u individual | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-42 |
| `mor.notificaciones.marcarEntrega` | Marcar/desmarcar entrega con evidencia (lote de ids) | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-37, PAN-MOR-16 |
| `mor.notificaciones.procesar` | Crear lote (generar candidatos o procesar instancia) | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-33, API-MOR-44, PAN-MOR-15 |
| `mor.notificaciones.promesa` | Registrar promesa de pago | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-38 |
| `mor.notificaciones.ver` | Buscar notificaciones (filtros de RF-MOR-083) | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-35, API-MOR-36, PAN-MOR-14 (+1) |
| `mor.operacionesEspeciales.ejecutar` | Resolver o eliminar (lógico) notificación sin efectos | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-45, PAN-MOR-22 |
| `mor.planesPago.configurar` | ABM de planes | S | T-ADM | suc | API-MOR-60, PAN-MOR-29 |
| `mor.plataforma.restricciones.configurar` | Catálogo normativo base por jurisdicción | S | P-SUP, P-ADM | global | API-MOR-51 |
| `mor.politicasInteres.configurar` | Crear borrador / nueva versión | S | T-ADM | suc | API-MOR-02, API-MOR-03, API-MOR-04 |
| `mor.politicasInteres.ver` | Listar políticas de interés | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-01, PAN-MOR-02 |
| `mor.politicasMora.configurar` | ABM de políticas de mora | S | T-ADM | suc | API-MOR-26, API-MOR-27 |
| `mor.politicasMora.ver` | ABM de políticas de mora | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-26 |
| `mor.prescripcion.configurar` | Reglas de prescripción | S | T-ADM | suc | API-MOR-81 |
| `mor.prescripcion.proponer` | Corridas de prescripción | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-82 |
| `mor.promesa.registrar` | Promesa de pago del socio | — | C-SOC, C-REP | rel | API-MOR-92 |
| `mor.protecciones.aprobar` | Verificar protección | S D | T-GER, T-TES, T-SAT | suc | API-MOR-49 |
| `mor.protecciones.editar` | ABM de protecciones normativas | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-48 |
| `mor.protecciones.ver` | ABM de protecciones normativas | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-48 |
| `mor.restricciones.configurar` | ABM de matriz (las normative solo con capability normativa) | S | T-ADM | suc | API-MOR-50 |
| `mor.restricciones.configurarNormativas` | ABM de matriz (las normative solo con capability normativa) | S | T-ADM | suc | API-MOR-50 |
| `mor.restricciones.ver` | ABM de matriz (las normative solo con capability normativa) | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-50 |
| `mor.simulador.usar` | Simular convenio | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE, C-SOC, C-REP | suc / rel | API-MOR-62, API-MOR-88, PAN-MOR-30 (+1) |
| `mor.tasas.editar` | Reemplazar tramos (valida superposición) | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-06, API-MOR-07 |
| `mor.tasas.ver` | Listar / crear tablas de tasas | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-05 |
| `mor.tramasRecargo.configurar` | ABM de esquemas de recargo entre vencimientos | S | T-ADM | suc | API-MOR-10, API-MOR-11, PAN-MOR-05 |
| `mor.tratamiento.ejecutar` | Crear caso(s) de interrupción (evalúa) | — | T-CAJ, T-CBR (P), T-TEC (P), T-STE, T-ATE | suc | API-MOR-54, API-MOR-58, PAN-MOR-20 |
| `mor.tratamiento.ver` | Servicios elegibles de notificaciones vencidas | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR (P), T-TES, T-CON, T-TEC (P), T-STE, T-ATE, T-SAT, T-SIN | suc | API-MOR-53, PAN-MOR-19 |

##### M09 CRM — Atención (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `crm.actividades.cerrar` | Cierre, aprobación, anulación | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-54 |
| `crm.actividades.configurar` | Actividades y catálogos | S | T-ADM | area | API-CRM-52, PAN-CRM-30 |
| `crm.actividades.ver` | Seguimiento | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN, C-EMP | area / self | API-CRM-53, API-CRM-55, API-CRM-56 (+3) |
| `crm.canales.configurar` | Probar conexión, sincronizar plantillas WhatsApp | S | T-ADM | area | API-CRM-40, PAN-CRM-16 |
| `crm.casos.anular` | Ejecutar transición ({ to, reason, data }) | S D | T-SAT | area | API-CRM-05, API-CRM-21 |
| `crm.casos.editar` | Editar campos no estructurales (asunto, etiquetas, campos adicionales, contactos) | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-04, API-CRM-05, API-CRM-12 (+1) |
| `crm.casos.exportar` | Exportar XLSX/CSV/PDF | S | T-ADM | area | API-CRM-23 |
| `crm.casos.fusionar` | Fusionar en caso principal | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-17 |
| `crm.casos.reclasificar` | Clasificar/reclasificar (acepta o corrige sugerencia IA) | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-09 |
| `crm.casos.resolver` | Ejecutar transición ({ to, reason, data }) | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-05, API-CRM-18 |
| `crm.casos.responder` | Mensaje visible o nota interna (con adjuntos) | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-10 |
| `crm.casos.tomar` | Tomar, pausar, soltar, retomar | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-08 |
| `crm.circulares.aprobar` | Corridas de circulares | S D | T-SAT | area | API-CRM-58 |
| `crm.circulares.configurar` | Modelos de circular | S | T-ADM | area | API-CRM-57 |
| `crm.circulares.generar` | Corridas de circulares | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-58 |
| `crm.circulares.ver` | Circulares | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | area | PAN-CRM-32 |
| `crm.comandos.solicitar` | Solicitar comando a módulo dueño | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-13, API-CRM-15 |
| `crm.config.areas.configurar` | Catálogos y configuración | S | T-ADM | area | API-CRM-39, PAN-CRM-13 |
| `crm.config.canales.configurar` | Catálogos y configuración | S | T-ADM | area | API-CRM-39 |
| `crm.config.estados.configurar` | Catálogos y configuración | S | T-ADM | area | API-CRM-39, PAN-CRM-12 |
| `crm.config.reglas.configurar` | Catálogos y configuración | S | T-ADM | area | API-CRM-39, PAN-CRM-15 |
| `crm.config.sla.configurar` | Catálogos y configuración | S | T-ADM | area | API-CRM-39, PAN-CRM-14 |
| `crm.config.tipos.configurar` | Catálogos y configuración | S | T-ADM | area | API-CRM-39, PAN-CRM-11 |
| `crm.config.tramites.configurar` | Catálogos y configuración | S | T-ADM | area | API-CRM-39 |
| `crm.conversaciones.atender` | Bandeja omnicanal | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-33, API-CRM-34, API-CRM-35 (+1) |
| `crm.horas.facturar` | Solicitar a M05 la facturación de horas | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-44 |
| `crm.horas.registrar` | Proyectos, tiempo, bolsas | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-43 |
| `crm.horas.ver` | Proyectos, tiempo, bolsas | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | area | API-CRM-43, PAN-CRM-22 |
| `crm.ia.auditar` | Auditoría de IA | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-38, PAN-CRM-19 |
| `crm.ia.configurar` | IA supervisada | S | T-ADM | area | PAN-CRM-18 |
| `crm.ia.usar` | Pedir sugerencia (resumen, borrador, extracción) | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-36, API-CRM-37 |
| `crm.incidentes.crear` | ABM de incidentes | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-28 |
| `crm.incidentes.editar` | ABM de incidentes | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-28, API-CRM-30, API-CRM-31 |
| `crm.incidentes.ver` | ABM de incidentes | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | area | API-CRM-28, PAN-CRM-07, PAN-CRM-08 |
| `crm.incidentes.vincular` | Vincular casos al incidente | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-29 |
| `crm.interacciones.crear` | Registrar interacción (llamada, visita) | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-26 |
| `crm.ivr.consultar` | Consulta y alta de reclamo desde IVR | X | S-API | tenant | API-CRM-79 |
| `crm.mesaEntradas.crear` | Mesa de entradas | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-32 |
| `crm.mesaEntradas.pasar` | Mesa de entradas | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-32 |
| `crm.mesaEntradas.registrarSalida` | Mesa de entradas | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-32 |
| `crm.mesaEntradas.ver` | Mesa de entradas | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | area | API-CRM-32, PAN-CRM-09 |
| `crm.misCasos.cancelar` | Desistir, confirmar o rechazar resolución, reabrir | — | C-SOC, C-REP | self | API-CRM-65 |
| `crm.misCasos.crear` | Nueva gestión (reclamo, consulta, solicitud) | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC, C-SOC, C-REP | area / self | API-CRM-62, API-CRM-66, API-CRM-67 (+1) |
| `crm.misCasos.responder` | Responder/adjuntar | — | C-SOC, C-REP | self | API-CRM-64 |
| `crm.misCasos.ver` | Mis gestiones | — | C-SOC, C-REP | self | API-CRM-61, API-CRM-63, API-CRM-68 |
| `crm.reportes.ver` | Estadísticas del turnero | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | area | API-CRM-49, API-CRM-59, PAN-CRM-28 (+1) |
| `crm.respuestasRapidas.configurar` | Respuestas rápidas | S | T-ADM | area | PAN-CRM-20 |
| `crm.tramites.configurar` | Trámites con vencimiento | S | T-ADM | area | PAN-CRM-21 |
| `crm.turnero.box.abrir` | Abrir/cerrar box | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC | area | API-CRM-46 |
| `crm.turnero.emitir` | Emitir turno | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC, C-EMP, público (sin login) | area / self / público | API-CRM-45, API-CRM-77, PAN-CRM-23 |
| `crm.turnero.llamar` | Llamar siguiente (atómico) | — | T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-RRHH, T-SEC, T-COM, T-SOC, C-EMP | area / self | API-CRM-47, API-CRM-48, PAN-CRM-24 |
| `crm.turnero.pantalla.ver` | Pantalla pública de turnos | — | público (sin login) | público | API-CRM-76 |
| `crm.turnero.ver` | Eventos en tiempo real de turnos | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CBR, T-TES, T-CON, T-CMP, T-DEP, T-TEC (P), T-LEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-RRHH, T-SEC, T-COM, T-SOC, T-SIN | area | API-CRM-51 |
| `crm.turnos.reservar` | Fila virtual y reservas | — | C-SOC, C-REP | rel | API-CRM-70 |
| `crm.webhooks.recibir` | Entrantes de WhatsApp, SMS, email, redes, CTI/IVR | X | S-API | tenant | API-CRM-78 |

##### M10 TEC — Técnica, campo y redes (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `tec.agenda.configurar` | Canónica propuesta para tec.schedule.configure. Configuración de agenda. | S | T-ADM | cua | API-TEC-20, PAN-TEC-12 |
| `tec.agenda.ver` | Canónica propuesta para tec.schedule.read. Disponibilidad por zona/tipo/fecha. También en portal (API-TEC-40). | X | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN, S-API | cua / tenant | API-TEC-17 |
| `tec.aprovisionamiento.configurar` | Canónica propuesta para tec.provisioning.configure. Sistemas de aprovisionamiento. | S | T-ADM | cua | API-TEC-33, PAN-TEC-36 |
| `tec.aprovisionamiento.operar` | Canónica propuesta para tec.provisioning.operate. Consola. | — | T-TEC (P), T-ATE | cua | API-TEC-34, PAN-TEC-38 |
| `tec.campo.ejecutar` | Lote de mutaciones. Resultado por ítem (applied/duplicate/conflict/rejected/deferred). | — | T-TEC (P), T-ATE | cua | API-TEC-43, API-TEC-51 |
| `tec.campo.evidencia` | URL firmada para foto/firma. Tamaño máx. PRM-TEC-144. | — | T-TEC (P), T-ATE | cua | API-TEC-44 |
| `tec.campo.ver` | Paquete del día. ETag; delta desde since. | — | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | cua | API-TEC-42, API-TEC-46 |
| `tec.cdr.importar` | Canónica propuesta para tec.cdr.import. CDR y móvil. Subida por URL firmada. | — | T-TEC (P), T-ATE | cua | API-TEC-39, PAN-TEC-45 |
| `tec.config.gestionar` | Canónica propuesta para tec.config.manage. Recursos. | — | T-TEC (P), T-ATE | cua | API-TEC-21, API-TEC-22, API-TEC-52 (+10) |
| `tec.cortes.gestionar` | Canónica propuesta para tec.outage.manage. Mantenimiento e interrupciones. | — | T-TEC (P), T-ATE | cua | API-TEC-26, PAN-TEC-28 |
| `tec.crew.gestionar` | Canónica propuesta para tec.crew.manage. Recursos. | — | T-TEC (P), T-ATE | cua | API-TEC-21, PAN-TEC-13, PAN-TEC-14 |
| `tec.device.gestionar` | Canónica propuesta para tec.device.manage. Dispositivos. Revocación borra caché local al próximo contacto. | — | T-TEC (P), T-ATE | cua | API-TEC-46 |
| `tec.dispatch.gestionar` | Canónica propuesta para tec.dispatch.manage. Transiciones operativas. | — | T-TEC (P), T-ATE | cua | API-TEC-09, PAN-TEC-10 |
| `tec.estimate.gestionar` | Canónica propuesta para tec.estimate.manage. Estimación y envío a M11. | — | T-TEC (P), T-ATE | cua | API-TEC-06, PAN-TEC-03 |
| `tec.ext.aprovisionamiento.callback` | Callback de sistemas externos. Verifica firma y replay. | X | S-API | tenant | API-TEC-50 |
| `tec.ext.ordenes.crear` | Alta externa de OT (contratistas, sistemas). Idempotente. | X | S-API | tenant | API-TEC-49 |
| `tec.ext.workOrder` | Alta externa de OT (contratistas, sistemas). Idempotente. | X | S-API | tenant | API-TEC-49 |
| `tec.factibilidad.cancelar` | Canónica propuesta para tec.feasibility.cancel. Anular / reabrir. Reapertura según PRM-TEC-064. | — | T-TEC (P), T-ATE | cua | API-TEC-04 |
| `tec.factibilidad.crear` | Canónica propuesta para tec.feasibility.create. Listar / crear factibilidad. Filtros estado, servicio, zona, vigencia. | — | T-TEC (P), T-ATE | cua | API-TEC-01 |
| `tec.factibilidad.editar` | Canónica propuesta para tec.feasibility.update. Ficha / editar. Cambios versionados. | — | T-TEC (P), T-ATE | cua | API-TEC-02 |
| `tec.factibilidad.reabrir` | Canónica propuesta para tec.feasibility.reopen. Anular / reabrir. Reapertura según PRM-TEC-064. | S D | T-STE | cua | API-TEC-04 |
| `tec.factibilidad.ver` | Canónica propuesta para tec.feasibility.read. Listar / crear factibilidad. Filtros estado, servicio, zona, vigencia. | X | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN, S-API | cua / tenant | API-TEC-01, API-TEC-02, PAN-TEC-01 |
| `tec.fieldForm.gestionar` | Canónica propuesta para tec.fieldForm.manage. Formularios de campo. Versionado inmutable al publicar. | — | T-TEC (P), T-ATE | cua | API-TEC-25, PAN-TEC-26 |
| `tec.geo.revisar` | Canónica propuesta para tec.geo.review. Geolocalización. Proveedor abstraído (PRM-TEC-149). | — | T-TEC (P), T-ATE | cua | API-TEC-47, PAN-TEC-48 |
| `tec.inspecciones.aprobar` | Canónica propuesta para tec.inspection.approve. Inspecciones. Separación de funciones (RN). | S D | T-STE | cua | API-TEC-37 |
| `tec.inspecciones.gestionar` | Canónica propuesta para tec.inspection.manage. Inspecciones. Separación de funciones (RN). | — | T-TEC (P), T-ATE | cua | API-TEC-37, PAN-TEC-41, PAN-TEC-54 |
| `tec.instalaciones.revisar` | Canónica propuesta para tec.installation.review. Instalaciones. | — | T-TEC (P), T-ATE | cua | API-TEC-23 |
| `tec.instalaciones.ver` | Canónica propuesta para tec.installation.read. Instalaciones. | X | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN, S-API | cua / tenant | API-TEC-23, PAN-TEC-25 |
| `tec.levy.gestionar` | Canónica propuesta para tec.levy.manage. Obras y contribución. | — | T-TEC (P), T-ATE | cua | API-TEC-36, PAN-TEC-40 |
| `tec.mantenimiento.gestionar` | Canónica propuesta para tec.maintenance.manage. Mantenimiento e interrupciones. | — | T-TEC (P), T-ATE | cua | API-TEC-26, PAN-TEC-27 |
| `tec.mapa.ver` | Canónica propuesta para tec.map.read. Mapa operativo | X | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN, S-API | cua / tenant | PAN-TEC-29, PAN-TEC-56 |
| `tec.material.authorize` | Materiales. Delegan reserva/vale a M13. | — | T-TEC (P), T-ATE | cua | API-TEC-14, PAN-TEC-09 |
| `tec.material.request` | Materiales. Delegan reserva/vale a M13. | — | T-TEC (P), T-ATE | cua | API-TEC-14 |
| `tec.mobile.importar` | Canónica propuesta para tec.mobile.import. CDR y móvil. Subida por URL firmada. | — | T-TEC (P), T-ATE | cua | API-TEC-39, PAN-TEC-46 |
| `tec.networkDevice.gestionar` | Canónica propuesta para tec.networkDevice.manage. Equipos de red. Credencial solo como credentialRef. | — | T-TEC (P), T-ATE | cua | API-TEC-32, PAN-TEC-35 |
| `tec.ordenes.cancelar` | Canónica propuesta para tec.workOrder.cancel. Anular / reabrir / restablecer. Compensación. | — | T-TEC (P), T-ATE | cua | API-TEC-12 |
| `tec.ordenes.cerrarMasivo` | Canónica propuesta para tec.workOrder.bulkClose. Masivos. Job con resultado por ítem. | — | T-TEC (P), T-ATE | cua | API-TEC-15, PAN-TEC-08 |
| `tec.ordenes.crearMasivo` | Canónica propuesta para tec.workOrder.bulkCreate. Masivos. Job con resultado por ítem. | — | T-TEC (P), T-ATE | cua | API-TEC-15, PAN-TEC-07 |
| `tec.ordenes.editar` | Canónica propuesta para tec.workOrder.update. Ficha / editar. Bloqueada si dispatch.locked (423). | — | T-TEC (P), T-ATE | cua | API-TEC-08, API-TEC-13, PAN-TEC-51 |
| `tec.ordenes.imprimir` | Canónica propuesta para tec.workOrder.print. Comprobante PDF. Marca despacho (RN-TEC-011). | — | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | cua | API-TEC-16 |
| `tec.ordenes.reabrir` | Canónica propuesta para tec.workOrder.reopen. Anular / reabrir / restablecer. Compensación. | S D | T-STE | cua | API-TEC-12 |
| `tec.phone.lines` | Líneas | — | T-TEC (P), T-ATE | cua | PAN-TEC-44 |
| `tec.phone.plant` | Red telefónica física | — | T-TEC (P), T-ATE | cua | PAN-TEC-42 |
| `tec.redes.configurar` | Canónica propuesta para tec.network.configure. Estructura de red. | S | T-ADM | cua | API-TEC-28, PAN-TEC-30 |
| `tec.redes.exportar` | Canónica propuesta para tec.network.export. Exportación GIS. | S | T-ADM | cua | API-TEC-31, PAN-TEC-34 |
| `tec.redes.gestionar` | Canónica propuesta para tec.network.manage. Red instalada. GeoJSON; bbox con índice 2dsphere. | — | T-TEC (P), T-ATE | cua | API-TEC-29, API-TEC-30, PAN-TEC-31 (+1) |
| `tec.redes.ver` | Canónica propuesta para tec.network.read. Análisis de impacto. Async (JOB-TEC-15) si supera umbral. | X | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN, S-API | cua / tenant | API-TEC-27, API-TEC-29 |
| `tec.reportes.ver` | Canónica propuesta para tec.report.read. Informes. Exportación CSV/XLSX/PDF. | X | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN, S-API | cua / tenant | API-TEC-48, PAN-TEC-47 |
| `tec.serviceTechnical.editar` | Canónica propuesta para tec.serviceTechnical.update. Datos técnicos del servicio. Cambios generan comando. | — | T-TEC (P), T-ATE | cua | API-TEC-35 |
| `tec.serviceTechnical.ver` | Canónica propuesta para tec.serviceTechnical.read. Datos técnicos del servicio. Cambios generan comando. | X | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN, S-API | cua / tenant | API-TEC-35 |
| `tec.syncConflict.resolve` | Conflictos. Resolución con motivo. | — | T-TEC (P), T-ATE | cua | API-TEC-24, PAN-TEC-24 |
| `tec.telefonia.configurar` | Telefonía. | S | T-ADM | cua | API-TEC-38 |
| `tec.telefonia.lineas.editar` | Telefonía. | — | T-TEC (P), T-ATE | cua | API-TEC-38 |
| `tec.telefonia.lineas.ver` | Telefonía. | — | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | cua | API-TEC-38 |
| `tec.telefonia.llamadas.ver` | Llamadas atribuidas por contrato y período (RF-TEC-237). Solo lectura; destino enmascarado salvo tec.telefonia.lineas.*;… | — | S-SYS | tenant | API-TEC-55 |
| `tec.telefonia.numeracion.editar` | Telefonía. | — | T-TEC (P), T-ATE | cua | API-TEC-38 |
| `tec.telefonia.numeracion.ver` | Telefonía. | — | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | cua | API-TEC-38 |
| `tec.telefonia.redFisica.editar` | Telefonía. | — | T-TEC (P), T-ATE | cua | API-TEC-38 |
| `tec.telefonia.redFisica.ver` | Telefonía. | — | T-ADM, T-GER, T-FAC, T-DEP, T-TEC (P), T-STE, T-SCM, T-ATE, T-SAT, T-SIN | cua | API-TEC-38 |

##### M11 VEN — Ventas y presupuestos (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `ven.cargos.anular` | Anular cargo no facturado | S D | T-GER, T-SAT | suc | API-VEN-004 |
| `ven.cargos.crear` | Alta manual de cargo | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-002 |
| `ven.cargos.editar` | Bonificar (inicia T11 si corresponde) | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-003, API-VEN-005 |
| `ven.cargos.ver` | Listar cargos (filtros, paginado) | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-DEP, T-STE, T-ATE, T-SAT, T-SIN | suc | API-VEN-001, API-VEN-008, PAN-VEN-01 |
| `ven.condiciones.configurar` | ABM condiciones | S | T-ADM | suc | API-VEN-028, PAN-VEN-04 |
| `ven.config.configurar` | Parámetros del módulo | S | T-ADM | suc | API-VEN-091, PAN-VEN-24 |
| `ven.cuotas.cancelarAnticipado` | Cancelación anticipada | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-056 |
| `ven.cuotas.editar` | Editar cuota sin facturar | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-054 |
| `ven.cuotas.modificarMasivo` | Modificación masiva (preview/confirm) | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-055, PAN-VEN-15 |
| `ven.cuotas.ver` | Listar cuotas | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-DEP, T-STE, T-ATE, T-SAT, T-SIN | suc | API-VEN-053, PAN-VEN-14 |
| `ven.descuentos.configurar` | Reglas de recargo/descuento | S | T-ADM | suc | API-VEN-063, PAN-VEN-18 |
| `ven.entregas.registrar` | Registrar entrega | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-047, PAN-VEN-12 |
| `ven.entregas.ver` | Vendido no entregado | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-DEP, T-STE, T-ATE, T-SAT, T-SIN | suc | API-VEN-048 |
| `ven.misCuotas.ver` | Cargos y cuotas del socio | — | C-SOC, C-REP | self | API-VEN-035, PAN-VEN-06 |
| `ven.misPresupuestos.aceptar` | Aceptar/rechazar como socio | — | C-SOC, C-REP, público (sin login) | self / público | API-VEN-034, PAN-VEN-05 |
| `ven.misPresupuestos.ver` | Presupuestos del socio | — | C-SOC, C-REP | self | API-VEN-033, PAN-VEN-06 |
| `ven.planes.configurar` | ABM planes | S | T-ADM | suc | API-VEN-052, PAN-VEN-19 |
| `ven.pos.abrir` | Abrir sesión | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-071, PAN-VEN-11 |
| `ven.pos.cerrar` | Cerrar con arqueo | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-072 |
| `ven.pos.configurar` | Terminales | S | T-ADM | suc | API-VEN-070 |
| `ven.pos.operar` | Venta POS (crea, cobra, emite) | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-073, PAN-VEN-10 |
| `ven.precios.actualizarMasivo` | Actualización masiva (preview/confirm) | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-062 |
| `ven.precios.ver` | Listas de precios | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-DEP, T-STE, T-ATE, T-SAT, T-SIN | suc | API-VEN-061, PAN-VEN-17 |
| `ven.presupuestos.anular` | Anular | S D | T-GER, T-SAT | suc | API-VEN-020 |
| `ven.presupuestos.cambiarEstado` | Cambio manual de estado con motivo | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-021 |
| `ven.presupuestos.editar` | Editar borrador (o crear nueva versión) | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-013, API-VEN-017, API-VEN-018 (+4) |
| `ven.presupuestos.enviar` | Enviar/reenviar por canales | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-014 |
| `ven.presupuestos.ver` | Canónica propuesta para ven.read. Consulta para integraciones externas | X | S-API, T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-DEP, T-STE, T-ATE, T-SAT, T-SIN | tenant / suc | API-VEN-092, API-VEN-010, API-VEN-012, API-VEN-026 (+4) |
| `ven.rendiciones.ver` | Rendiciones | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-DEP, T-STE, T-ATE, T-SAT, T-SIN | suc | API-VEN-080, PAN-VEN-20 |
| `ven.riesgo.override` | Autorizar riesgo excedido | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-044 |
| `ven.vendedores.ver` | ABM vendedores | — | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-DEP, T-STE, T-ATE, T-SAT, T-SIN | suc | API-VEN-060, PAN-VEN-16 |
| `ven.ventas.anular` | Anular | S D | T-GER, T-SAT | suc | API-VEN-045, API-VEN-046, PAN-VEN-22 |
| `ven.ventas.aprobar` | Aprobar devolución | S D | T-GER, T-SAT | suc | API-VEN-050 |
| `ven.ventas.crear` | Facturar total/parcial por ítems | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-019, API-VEN-041, API-VEN-043 (+1) |
| `ven.ventas.devolver` | Crear devolución | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-049, PAN-VEN-13 |
| `ven.ventas.editar` | Editar borrador | — | T-FAC, T-CAJ, T-ATE | suc | API-VEN-042, PAN-VEN-09 |
| `ven.ventas.exportar` | Ejecutar reporte (sección 15) | S | T-ADM | suc | API-VEN-090, PAN-VEN-23 |
| `ven.ventas.ver` | Listar ventas | X | T-ADM, T-GER, T-FAC, T-CAJ, T-TES, T-CON, T-DEP, T-STE, T-ATE, T-SAT, T-SIN, S-API | suc / tenant | API-VEN-040, API-VEN-051, API-VEN-064 (+2) |

##### M12 CMP — Compras y proveedores (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `cmp.anticipos.crear` | Anticipo a proveedor | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-067 |
| `cmp.catalogos.configurar` | Conceptos, rubros, destinatarios, unidades, combustibles, modalidades | S | T-ADM, T-CMP | tenant | API-CMP-013, PAN-CMP-03 |
| `cmp.comprobantes.anular` | Anular | S D | T-GER, T-CMP | tenant | API-CMP-065 |
| `cmp.comprobantes.editar` | Editar borrador | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-062 |
| `cmp.comprobantes.registrar` | Crear borrador o registrar | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-061, API-CMP-063, API-CMP-066 (+3) |
| `cmp.comprobantes.ver` | Cuenta corriente a fecha de corte | X | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN, S-API | tenant | API-CMP-011, API-CMP-014, API-CMP-060 (+8) |
| `cmp.conciliacion.aprobarExcepcion` | Decidir excepción | S D | T-GER, T-CMP | tenant | API-CMP-071 |
| `cmp.conciliacion.ver` | Excepciones | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CMP-070, PAN-CMP-13 |
| `cmp.concursos.adjudicar` | Concursos y licitaciones | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-035, API-CMP-036 |
| `cmp.concursos.editar` | Concursos y licitaciones | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-035 |
| `cmp.concursos.ver` | Concursos y licitaciones | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CMP-035 |
| `cmp.config.configurar` | Parámetros | S | T-ADM, T-CMP | tenant | API-CMP-101, PAN-CMP-21 |
| `cmp.cotizaciones.crear` | Generar cotizaciones desde SA | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-030 |
| `cmp.cotizaciones.editar` | Cargar precios | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-031, API-CMP-032 |
| `cmp.cotizaciones.evaluar` | Adjudicar ítems | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-034 |
| `cmp.cotizaciones.ver` | Cuadro comparativo | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CMP-033, PAN-CMP-06 |
| `cmp.ia.usar` | Subir PDF para lectura IA | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-092, API-CMP-093, PAN-CMP-17 |
| `cmp.misComprobantes.importar` | Bandejas de recibidos | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-090, PAN-CMP-17 |
| `cmp.ordenes.cerrar` | Cerrar / cancelar | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-045 |
| `cmp.ordenes.editar` | Editar / nueva revisión | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-042, PAN-CMP-09 |
| `cmp.ordenes.enviar` | Enviar al proveedor | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-044 |
| `cmp.ordenes.ver` | Canónica propuesta para cmp.read. Consulta para integraciones/BI | X | S-API, T-ADM, T-GER, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CMP-120, API-CMP-040, API-CMP-046, API-CMP-120 (+1) |
| `cmp.ordenesPago.anular` | Cancelar OP | S D | T-GER, T-CMP | tenant | API-CMP-086 |
| `cmp.ordenesPago.aprobar` | Aprobación | S D | T-GER, T-CMP | tenant | API-CMP-085 |
| `cmp.ordenesPago.crear` | Crear OP en borrador | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-081, API-CMP-085, PAN-CMP-15 |
| `cmp.ordenesPago.editar` | Editar borrador | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-082, API-CMP-083 |
| `cmp.ordenesPago.ver` | Listar OP | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CMP-080, API-CMP-087, PAN-CMP-14 |
| `cmp.pago.habilitar` | Habilitación manual de pago | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-064 |
| `cmp.politicas.configurar` | Políticas de aprobación y tolerancias | S | T-ADM, T-CMP | tenant | PAN-CMP-20 |
| `cmp.portal.cotizar` | Consultas del portal | — | público (sin login) | público | API-CMP-110, API-CMP-111 |
| `cmp.portal.revisar` | Bandejas de recibidos | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-090, API-CMP-091, PAN-CMP-17 |
| `cmp.portal.subirComprobante` | Consultas del portal | — | público (sin login) | público | API-CMP-110, API-CMP-112 |
| `cmp.portal.verOrdenes` | Consultas del portal | — | público (sin login) | público | API-CMP-110, API-CMP-113 |
| `cmp.portal.verPagos` | Consultas del portal | — | público (sin login) | público | API-CMP-110 |
| `cmp.proveedores.aprobarCbu` | Aprobar CBU | S D | T-GER, T-CMP | tenant | API-CMP-007 |
| `cmp.proveedores.crear` | Crear proveedor | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-002 |
| `cmp.recepciones.anular` | Anular recepción | S D | T-GER, T-CMP | tenant | API-CMP-051 |
| `cmp.recepciones.ver` | Recepciones sin factura | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CMP-052 |
| `cmp.reportes.exportar` | Reportes de la sección 15 | S | T-ADM, T-CMP | tenant | API-CMP-100 |
| `cmp.retenciones.ajustar` | Ajuste manual con motivo | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-084 |
| `cmp.solicitudes.aprobar` | Aprobar/rechazar | S D | T-GER, T-CMP | tenant | API-CMP-024, API-CMP-025 |
| `cmp.solicitudes.editar` | Editar borrador | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-022 |
| `cmp.solicitudes.procesar` | Transiciones | — | T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC | tenant | API-CMP-026 |
| `cmp.solicitudes.ver` | Listar SA | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-DEP, T-TEC, T-LEC, T-STE, T-ATE, T-SAT, T-RRHH, T-SEC, T-SOC, T-SIN | tenant | API-CMP-020, API-CMP-027, PAN-CMP-04 |

##### M13 STK — Stock y activos (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `stk.ajustes.crear` | Ajuste (queda pendiente si supera umbral). | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-47 |
| `stk.amortizaciones.ejecutar` | Simular o contabilizar corrida. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-58, PAN-STK-27 |
| `stk.amortizaciones.revertir` | Revertir. | S D | T-DEP | dep | API-STK-59 |
| `stk.aplicaciones.registrar` | Lote de mutaciones de campo (consumeMaterials, applyEquipment, retrieveEquipment, visitFailed, returnRequest, countLine),… | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-35 |
| `stk.articulos.crear` | Alta de artículo. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-02, API-STK-05, API-STK-06 |
| `stk.articulos.editar` | Edición con version. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-04, API-STK-09, API-STK-13 |
| `stk.asignaciones.editar` | Proponer cargo por no devolución. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-42, API-STK-43, API-STK-44 |
| `stk.asignaciones.ver` | Equipos en domicilios. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-40, PAN-STK-17 |
| `stk.auditoria.ver` | Auditoría del módulo. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-72 |
| `stk.bajas.aprobar` | Baja técnica. | S D | T-DEP | dep | API-STK-27 |
| `stk.bienesUso.baja` | Baja con recupero. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-55, API-STK-56 |
| `stk.bienesUso.editar` | Bienes de uso (incluye confirmar borrador). | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-53, API-STK-54 |
| `stk.bienesUso.ver` | Bienes de uso (incluye confirmar borrador). | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-53, API-STK-57, API-STK-60 (+2) |
| `stk.cierres.crear` | Cierre de stock. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-52, PAN-STK-24 |
| `stk.cierres.reabrir` | Cierre de stock. | S D | T-DEP | dep | API-STK-52 |
| `stk.config.configurar` | Maestros. | S | T-ADM, T-DEP | dep | API-STK-08, PAN-STK-04, PAN-STK-36 |
| `stk.consumos.registrar` | Lote de mutaciones de campo (consumeMaterials, applyEquipment, retrieveEquipment, visitFailed, returnRequest, countLine),… | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-35, API-STK-36, PAN-STK-38 |
| `stk.consumos.validar` | Conflictos y sustituciones. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-38, PAN-STK-16 |
| `stk.costos.editar` | Actualización masiva de costos (preview/confirm). | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-07, PAN-STK-03 |
| `stk.custodia.ver` | Custodia del técnico (proxy a M13). | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-TEC-45 |
| `stk.custodias.ver` | Tablero de custodias | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | PAN-STK-14 |
| `stk.depositos.editar` | Depósitos. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-10, API-STK-11, API-STK-12 (+1) |
| `stk.depositos.ver` | Depósitos. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-10, PAN-STK-05 |
| `stk.devoluciones.crear` | Devolución en mostrador. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-41, PAN-STK-18 |
| `stk.entregas.aceptar` | Aceptar entrega con firma. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-34 |
| `stk.entregas.crear` | Entrega a cuadrilla/técnico. | — | T-CMP, T-DEP, T-TEC (P), T-STE, C-EMP | dep / self | API-STK-32, PAN-STK-41 |
| `stk.etiquetas.imprimir` | Etiquetas por artículo/serie/lote/ubicación. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-69 |
| `stk.ext.saldos.ver` | Saldos para terceros/BI. | X | S-API | tenant | API-STK-71 |
| `stk.ext.vales.crear` | Vales desde sistemas externos (reemplaza Procoop INTEGRA). | X | S-API | tenant | API-STK-70 |
| `stk.fabricacion.aprovisionamiento.ejecutar` | MRP y requisiciones. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-67, PAN-STK-34 |
| `stk.fabricacion.estructuras.editar` | Estructuras. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-63, API-STK-64 |
| `stk.fabricacion.estructuras.ver` | Estructuras. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-63, API-STK-64, PAN-STK-31 |
| `stk.fabricacion.ordenes.editar` | Órdenes. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-65 |
| `stk.fabricacion.ordenes.ver` | Órdenes. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-65, PAN-STK-32 |
| `stk.fabricacion.partes.crear` | Partes de producción. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-66 |
| `stk.fabricacion.partes.finalizar` | Partes de producción. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-66 |
| `stk.fabricacion.partes.lanzar` | Partes de producción. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-66 |
| `stk.fabricacion.partes.ver` | Partes de producción. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-66, PAN-STK-33 |
| `stk.informes.exportar` | Informes y exportación (format=xlsx/csv/pdf). | S | T-ADM, T-DEP | dep | API-STK-68 |
| `stk.informes.ver` | Informes y exportación (format=xlsx/csv/pdf). | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-68, PAN-STK-35 |
| `stk.inventarios.cerrar` | Inventarios físicos. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-46 |
| `stk.inventarios.contar` | Inventarios físicos. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-46, PAN-STK-39 |
| `stk.inventarios.ver` | Inventarios físicos. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-46, PAN-STK-20 |
| `stk.lotes.editar` | Lotes. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-28 |
| `stk.lotes.ver` | Lotes. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-28 |
| `stk.miStock.ver` | Mi stock (para caché offline, con asOf). | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-33, PAN-STK-37 |
| `stk.misEquipos.ver` | Equipos del socio (solo sus contratos). | — | C-SOC, C-REP | self | API-STK-45, PAN-STK-40 |
| `stk.movimientos.anular` | Anulación con contramovimiento. | S D | T-DEP | dep | API-STK-20 |
| `stk.movimientos.crear` | Crear documento (borrador o contabilizar). | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-17, API-STK-18, PAN-STK-10 |
| `stk.movimientos.ver` | Kárdex/movimientos. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-15, API-STK-16, API-STK-21 (+3) |
| `stk.recepciones.crear` | Recepción técnica. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-62 |
| `stk.recepciones.editar` | Recepción técnica. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-62 |
| `stk.recepciones.entregar` | Recepción técnica. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-62 |
| `stk.recepciones.ver` | Recepción técnica. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-62, PAN-STK-30 |
| `stk.rendiciones.aprobar` | Rendiciones: crear, contar, ajustar, cerrar. | S D | T-DEP | dep | API-STK-39 |
| `stk.rendiciones.editar` | Rendiciones: crear, contar, ajustar, cerrar. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-39 |
| `stk.rendiciones.ver` | Rendiciones: crear, contar, ajustar, cerrar. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-39, PAN-STK-15 |
| `stk.reservas.crear` | Crear reserva (servicio interno usado por M10/M11/M18). | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-29 |
| `stk.reservas.liberar` | Liberar con motivo. | S D | T-DEP | dep | API-STK-30 |
| `stk.reservas.ver` | Consultar por destino. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-31, PAN-STK-13 |
| `stk.retiros.registrar` | Lote de mutaciones de campo (consumeMaterials, applyEquipment, retrieveEquipment, visitFailed, returnRequest, countLine),… | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-35 |
| `stk.revaluaciones.aprobar` | Revaluaciones. | S D | T-DEP | dep | API-STK-51 |
| `stk.revaluaciones.crear` | Revaluaciones. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-51, PAN-STK-23 |
| `stk.revaluaciones.ver` | Revaluaciones. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-51 |
| `stk.rma.cerrar` | RMA. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-61 |
| `stk.rma.crear` | RMA. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-61 |
| `stk.rma.editar` | RMA. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-61, PAN-STK-29 |
| `stk.rma.ver` | RMA. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-61, PAN-STK-28 |
| `stk.saldos.ver` | Disponibilidad por dimensiones (incluye comprometido). | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-14, PAN-STK-07 |
| `stk.series.crear` | Validar series a ingresar (RN-STK-020/021). | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-24 |
| `stk.series.editar` | Registrar inspección/ensayo. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-25, API-STK-26, PAN-STK-19 |
| `stk.series.ver` | Búsqueda por cualquier identificador. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-22, API-STK-23, PAN-STK-11 (+1) |
| `stk.sugerencias.convertir` | Convertir en requisición M12. | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-49 |
| `stk.sugerencias.ver` | Sugerencias. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-48, PAN-STK-21 |
| `stk.transferencias.recibir` | Recepción en destino (parcial con diferencias). | — | T-CMP, T-DEP, T-TEC (P), T-STE | dep | API-STK-19 |
| `stk.valorizacion.ver` | Valorización a fecha por método. | — | T-ADM, T-GER, T-CON, T-CMP, T-DEP, T-TEC (P), T-STE, T-ATE, T-SIN | dep | API-STK-50, PAN-STK-22 |

##### M14 TES — Tesorería y bancos (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `tes.archivosPago.enviar` | Registrar envío / importar respuesta / anular | — | T-TES | tenant | API-TES-42 |
| `tes.archivosPago.generar` | Generar archivo desde selección | — | T-TES | tenant | API-TES-40, API-TES-41, PAN-TES-13 |
| `tes.cajasPago.abrir` | Caja de pagos | — | T-TES | tenant | API-TES-61, PAN-TES-25 |
| `tes.categorias.configurar` | Maestros | S | T-ADM, T-TES | tenant | API-TES-09, PAN-TES-05 |
| `tes.chequeras.anular` | Transiciones de cheque propio | S D | T-GER, T-TES | tenant | API-TES-50 |
| `tes.chequeras.crear` | Chequeras | — | T-TES | tenant | API-TES-49 |
| `tes.chequeras.imprimir` | Imprimir rango (PDF) y marcar | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-51, PAN-TES-20 |
| `tes.chequeras.ver` | Chequeras y cheques propios | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | PAN-TES-18 |
| `tes.cierreCaja.cerrar` | Cierre / reapertura de caja de tesorería | S D | T-GER, T-TES | tenant | API-TES-70, PAN-TES-29 |
| `tes.compromisos.liberar` | Compromisos | S D | T-GER, T-TES | tenant | API-TES-78 |
| `tes.compromisos.ver` | Compromisos | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-78 |
| `tes.conciliacion.cerrar` | Cerrar / reabrir | — | T-TES | tenant | API-TES-31 |
| `tes.conciliacion.conciliar` | Abrir conciliación | — | T-TES | tenant | API-TES-23, API-TES-25, API-TES-26 (+4) |
| `tes.conciliacion.desconciliar` | Desconciliar grupo (motivo en cuerpo; borrado lógico) | — | T-TES | tenant | API-TES-28 |
| `tes.conciliacion.reabrir` | Cerrar / reabrir | S D | T-GER, T-TES | tenant | API-TES-31 |
| `tes.conciliacion.ver` | Líneas por cuenta/estado | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-22, API-TES-24, API-TES-32 |
| `tes.configuracion.configurar` | Parámetros (versionados T04) | S | T-ADM, T-TES | tenant | API-TES-82, PAN-TES-31, PAN-TES-39 |
| `tes.cotizaciones.crear` | Cotizaciones | — | T-TES | tenant | API-TES-72 |
| `tes.cuentas.configurar` | Bloquear / cerrar | S | T-ADM, T-TES | tenant | API-TES-05, API-TES-07, API-TES-08 (+1) |
| `tes.cuentas.crear` | Crear cuenta (genera apertura) | — | T-TES | tenant | API-TES-02 |
| `tes.cuentas.editar` | Editar (control optimista version) | — | T-TES | tenant | API-TES-04 |
| `tes.cuentas.ver` | Listar cuentas financieras | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-01, API-TES-03, API-TES-06 (+1) |
| `tes.cupones.editar` | Corregir datos | — | T-TES | tenant | API-TES-55 |
| `tes.cupones.liquidar` | Liquidar / anular | — | T-TES | tenant | API-TES-57, PAN-TES-23 |
| `tes.cupones.presentar` | Presentar / anular | — | T-TES | tenant | API-TES-56 |
| `tes.cupones.rechazar` | Rechazo de cupón | S D | T-GER, T-TES | tenant | API-TES-58 |
| `tes.cupones.ver` | Cupones | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-54, PAN-TES-22 |
| `tes.depositos.crear` | Depósito / anular | — | T-TES | tenant | API-TES-48, PAN-TES-17 |
| `tes.echeq.gestionar` | Importar estados eCheq | — | T-TES | tenant | API-TES-52 |
| `tes.echeq.ver` | Bandeja eCheq | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | PAN-TES-19 |
| `tes.extractos.importar` | Perfiles de importación | — | T-TES | tenant | API-TES-19, API-TES-20, API-TES-21 (+1) |
| `tes.flujo.simular` | Escenarios | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-76, PAN-TES-34 |
| `tes.flujo.ver` | Proyección | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-74, API-TES-75, PAN-TES-32 |
| `tes.haberes.ejecutar` | Lotes de haberes (detalle con tes.haberes.verDetalle) | — | T-TES | tenant | API-TES-79, API-TES-80, PAN-TES-35 |
| `tes.informes.ver` | Ejecutar informe (formato por Accept) | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-81, PAN-TES-36 |
| `tes.interbanking.configurar` | Configurar conexión (secreto solo de escritura → bóveda) | S | T-ADM, T-TES | tenant | API-TES-34, API-TES-35, API-TES-39 (+1) |
| `tes.interbanking.sincronizar` | Cuentas IB | — | T-TES | tenant | API-TES-36, API-TES-37, API-TES-38 (+1) |
| `tes.monedas.configurar` | Monedas del tenant | S | T-ADM, T-TES | tenant | API-TES-71, PAN-TES-30 |
| `tes.movimientos.anular` | Anular con motivo | S D | T-GER, T-TES | tenant | API-TES-14 |
| `tes.movimientos.aprobar` | Aprobar/rechazar | S D | T-GER, T-TES | tenant | API-TES-15 |
| `tes.movimientos.crear` | Registrar operación (asistente) | — | T-TES | tenant | API-TES-12 |
| `tes.movimientos.editar` | Cambiar fecha valor/observación | — | T-TES | tenant | API-TES-17 |
| `tes.movimientos.ver` | Buscar movimientos | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-11, API-TES-13, API-TES-16 (+6) |
| `tes.pagos.anular` | Anular | S D | T-GER, T-TES | tenant | API-TES-66 |
| `tes.pagos.entregar` | Entregar | — | T-TES | tenant | API-TES-65 |
| `tes.pagos.firmar` | Firmar (lista de ids; 2FA reciente) | S D | T-GER, T-TES, C-EMP | tenant / self | API-TES-64, API-TES-85, PAN-TES-27 (+1) |
| `tes.pagos.ver` | Bandeja | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-62, PAN-TES-26 |
| `tes.periodos.cerrar` | Cierre de períodos | S D | T-GER, T-TES | tenant | API-TES-83, PAN-TES-42 |
| `tes.previsiones.crear` | Previsiones | — | T-TES | tenant | API-TES-77, PAN-TES-33 |
| `tes.reglasConciliacion.configurar` | Reglas y prueba | S | T-ADM, T-TES | tenant | API-TES-33, PAN-TES-10 |
| `tes.rendiciones.recibir` | Rendiciones | — | T-TES | tenant | API-TES-68, PAN-TES-28 |
| `tes.retencionesRecibidas.crear` | Retenciones recibidas | — | T-TES | tenant | API-TES-59 |
| `tes.retencionesRecibidas.presentar` | Presentar / salida / anular | — | T-TES | tenant | API-TES-60 |
| `tes.retencionesRecibidas.ver` | Cartera de retenciones recibidas | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | PAN-TES-24 |
| `tes.tarjetas.configurar` | Tarjetas y recargos | S | T-ADM, T-TES | tenant | API-TES-53, PAN-TES-21 |
| `tes.valores.crear` | Alta de valor | — | T-TES | tenant | API-TES-44, PAN-TES-15 |
| `tes.valores.editar` | Libradores | — | T-TES | tenant | API-TES-10, API-TES-45, PAN-TES-16 |
| `tes.valores.ver` | Cartera | — | T-ADM, T-GER, T-TES, T-CON, T-CMP, T-SIN | tenant | API-TES-43, API-TES-47, PAN-TES-14 |

##### M15 CON — Contabilidad (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `con.asientos.anular` | Anular (período abierto, no transcripto) | S D | T-GER, T-CON | tenant | API-CON-44, API-CON-45 |
| `con.asientos.anularMasivo` | Anulación masiva (dryRun) → JOB-CON-17 | S D | T-GER, T-CON | tenant | API-CON-48, PAN-CON-18 |
| `con.asientos.aprobar` | Aprobar o rechazar | S D | T-GER, T-CON | tenant | API-CON-43, PAN-CON-13 |
| `con.asientos.contabilizar` | Contabilizar | — | T-CON | tenant | API-CON-42, PAN-CON-13 |
| `con.asientos.crear` | Crear asiento manual (borrador) | — | T-CON | tenant | API-CON-38, API-CON-41, API-CON-50 (+3) |
| `con.asientos.editar` | Editar borrador | — | T-CON | tenant | API-CON-39, API-CON-40, API-CON-46 (+1) |
| `con.asientos.importar` | Importar archivo (validar / confirmar) | — | T-CON | tenant | API-CON-47, PAN-CON-15 |
| `con.asientos.renumerar` | Renumeración → JOB-CON-16 | — | T-CON | tenant | API-CON-49, PAN-CON-19 |
| `con.asientos.verVinculado` | Asiento(s) vinculado(s) a un documento | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-85 |
| `con.centros.configurar` | Centros y grupos | S | T-ADM, T-CON | tenant | API-CON-62, API-CON-63, PAN-CON-24 (+1) |
| `con.centros.ver` | Centros y grupos | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-62, PAN-CON-24 |
| `con.compromisos.autorizarExceso` | Autorizar exceso / liberar | — | T-CON | tenant | API-CON-78, PAN-CON-35 |
| `con.compromisos.liberar` | Autorizar exceso / liberar | S D | T-GER, T-CON | tenant | API-CON-78 |
| `con.compromisos.ver` | Ejecución presupuestaria y compromisos | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | PAN-CON-35 |
| `con.conciliaciones.ejecutar` | Ejecutar y consultar conciliaciones → JOB-CON-08 | — | T-CON | tenant | API-CON-66, API-CON-67, PAN-CON-28 |
| `con.conciliaciones.ver` | Ejecutar y consultar conciliaciones → JOB-CON-08 | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-66, PAN-CON-28 |
| `con.config.configurar` | Guardar borrador | S | T-ADM, T-CON | tenant | API-CON-02, API-CON-03, PAN-CON-02 |
| `con.config.ver` | Configuración vigente y versiones | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-01, API-CON-84, PAN-CON-02 (+1) |
| `con.cuentas.crear` | Alta de cuenta | — | T-CON | tenant | API-CON-11 |
| `con.cuentas.editar` | Editar / inactivar cuenta | — | T-CON | tenant | API-CON-12, API-CON-15, API-CON-83 (+3) |
| `con.cuentas.renumerar` | Cambiar código visible | — | T-CON | tenant | API-CON-13, PAN-CON-06 |
| `con.cuentas.unificar` | Unificar cuentas (vista previa con dryRun) | — | T-CON | tenant | API-CON-14, PAN-CON-06 |
| `con.cuentas.ver` | Árbol o lista de cuentas con filtros | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-10, API-CON-15, PAN-CON-04 |
| `con.distribuciones.editar` | Modelos de distribución | — | T-CON | tenant | API-CON-64 |
| `con.distribuciones.ejecutar` | Corrida de distribución → JOB-CON-07 | — | T-CON | tenant | API-CON-65, PAN-CON-26 |
| `con.distribuciones.ver` | Modelos de distribución | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-64, PAN-CON-26 |
| `con.ejercicios.crear` | Ejercicios | — | T-CON | tenant | API-CON-25, API-CON-26 |
| `con.ejercicios.reabrir` | Solicitar/ejecutar reapertura (doble aprobación) | S D | T-GER, T-CON | tenant | API-CON-29, PAN-CON-31 |
| `con.ejercicios.ver` | Ejercicios | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-25, API-CON-30, PAN-CON-10 |
| `con.estados.aprobar` | Estados contables → JOB-CON-15 | S D | T-GER, T-CON | tenant | API-CON-80, PAN-CON-36 |
| `con.estados.emitir` | Estados contables → JOB-CON-15 | — | T-CON | tenant | API-CON-80, PAN-CON-36 |
| `con.estados.generar` | Plantillas de estados | — | T-CON | tenant | API-CON-79, API-CON-80, PAN-CON-36 |
| `con.eventos.ignorar` | Ignorar con motivo | — | T-CON | tenant | API-CON-55, PAN-CON-16 |
| `con.eventos.reprocesar` | Reprocesar seleccionados o por causa | — | T-CON | tenant | API-CON-54, PAN-CON-16 |
| `con.eventos.ver` | Bandeja de eventos | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-52, API-CON-53, PAN-CON-16 |
| `con.ext.asientos` | Asientos contabilizados por rango (solo lectura, paginado) | X | S-API | tenant | API-CON-89 |
| `con.ext.saldos` | Sumas y saldos por período (solo lectura, para estudio contable o BI) | X | S-API | tenant | API-CON-88 |
| `con.externo.configurar` | Mapeo sistema externo | S | T-ADM, T-CON | tenant | API-CON-81 |
| `con.externo.ejecutar` | Exportar / importar → JOB-CON-12 / JOB-CON-13 | — | T-CON | tenant | API-CON-82, PAN-CON-37 |
| `con.externo.ver` | Mapeo sistema externo | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-81, PAN-CON-37 |
| `con.inflacion.editar` | Series e índices (importación) | — | T-CON | tenant | API-CON-68, PAN-CON-29 |
| `con.inflacion.ejecutar` | Ajuste por inflación → JOB-CON-06 | — | T-CON | tenant | API-CON-69, PAN-CON-30 |
| `con.inflacion.ver` | Series e índices (importación) | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-68, PAN-CON-29 |
| `con.libros.transcribir` | Libros y transcripción → JOB-CON-18 | — | T-CON | tenant | API-CON-61, PAN-CON-23 |
| `con.libros.ver` | Libros rubricados | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | PAN-CON-23 |
| `con.lotes.confirmar` | Confirmar | — | T-CON | tenant | API-CON-58, PAN-CON-17 |
| `con.lotes.ejecutar` | Crear lote (vista previa) → JOB-CON-02 | — | T-CON | tenant | API-CON-56, API-CON-59, PAN-CON-17 |
| `con.lotes.ver` | Lotes y resultado | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-57, PAN-CON-17 |
| `con.periodos.bloquear` | Bloquear/desbloquear módulo hasta fecha | — | T-CON | tenant | API-CON-32, PAN-CON-11 |
| `con.periodos.ver` | Matriz de períodos y bloqueos | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-31, PAN-CON-11 |
| `con.planes.aprobar` | Aprobar | S D | T-GER, T-CON | tenant | API-CON-07 |
| `con.planes.crear` | Crear plan (vacío, copia o plantilla) | — | T-CON | tenant | API-CON-05 |
| `con.planes.editar` | Editar plan en borrador | — | T-CON | tenant | API-CON-06, API-CON-09, API-CON-70 (+1) |
| `con.planes.promover` | Promover a operativo para un ejercicio | — | T-CON | tenant | API-CON-08 |
| `con.planes.ver` | Listar planes | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-04, PAN-CON-03 |
| `con.presupuestos.aprobar` | Ciclo de aprobación | S D | T-GER, T-CON | tenant | API-CON-75, PAN-CON-34 |
| `con.presupuestos.editar` | Presupuestos | — | T-CON | tenant | API-CON-74, API-CON-75, PAN-CON-34 |
| `con.presupuestos.ver` | Presupuestos | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-74, API-CON-76, PAN-CON-34 (+1) |
| `con.reglas.ver` | Roles de cuenta con estado | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-16, API-CON-18, API-CON-21 (+4) |
| `con.reportes.ver` | Informes (§15) con parámetros; format=json/pdf/xlsx/csv (exportar exige con.reportes.exportar) | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-60, PAN-CON-20, PAN-CON-21 (+3) |
| `con.simulaciones.crear` | Escenarios | — | T-CON | tenant | API-CON-71, PAN-CON-33 |
| `con.simulaciones.ejecutar` | Ejecutar simulación → JOB-CON-09 | — | T-CON | tenant | API-CON-72, PAN-CON-33 |
| `con.simulaciones.ver` | Escenarios | — | T-ADM, T-GER, T-TES, T-CON, T-SIN | tenant | API-CON-71, API-CON-73, PAN-CON-33 |

##### M16 SUE — Personal y sueldos (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `sue.aumentos.aplicar` | Aplicar aumentos | — | T-RRHH | tenant | API-SUE-38, PAN-SUE-16 |
| `sue.causasLicencia.configurar` | Tipos | S | T-ADM, T-RRHH | tenant | API-SUE-39 |
| `sue.certificados.emitir` | Certificados y constancias | — | T-RRHH | tenant | API-SUE-69, PAN-SUE-33 |
| `sue.conceptos.simular` | Probar fórmula sobre un empleado | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | API-SUE-33, API-SUE-37 |
| `sue.configuracion.publicar` | Ciclo de versión | S D | T-GER, T-RRHH | tenant | API-SUE-37, PAN-SUE-15 |
| `sue.costoLaboral.ver` | Canónica propuesta para sue.costoLaboral. Costo laboral agregado por centro de costo (sin datos personales) | X | S-API | tenant | API-SUE-86 |
| `sue.cuentasPago.editar` | Cuentas de acreditación | — | T-RRHH | tenant | API-SUE-10 |
| `sue.datosSensibles.ver` | Planes de descuento | S | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | API-SUE-17 |
| `sue.documentos.autorizar` | Autorizar/rechazar documento | S D | T-GER, T-RRHH | tenant | API-SUE-12 |
| `sue.egresos.crear` | Egresos | — | T-RRHH | tenant | API-SUE-58, PAN-SUE-28 |
| `sue.equipo.ver` | Encargado | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN, C-EMP | tenant / self | API-SUE-83, PAN-SUE-44 |
| `sue.escalas.aprobar` | Escalas | S D | T-GER, T-RRHH | tenant | API-SUE-24 |
| `sue.estructura.configurar` | Listar empresas. Reemplazado por API-CFG-55 de T04 (GET /api/admin/cfg/legal-entities, filtro con employer; CTR-DAT-06). | S | T-ADM, T-RRHH | tenant | API-SUE-01, API-SUE-02, API-SUE-21 (+14) |
| `sue.familiares.editar` | Familiares | — | T-RRHH | tenant | API-SUE-09 |
| `sue.ganancias.calcular` | Liquidación anual | — | T-RRHH | tenant | API-SUE-61 |
| `sue.ganancias.importarF572` | Importar SIRADIG | — | T-RRHH | tenant | API-SUE-60 |
| `sue.ganancias.ver` | Calculadora | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | API-SUE-59, API-SUE-62, PAN-SUE-29 |
| `sue.importacionExterna.importar` | CU-28 | — | T-RRHH | tenant | API-SUE-75, API-SUE-76 |
| `sue.importacionExterna.ver` | Liquidación externa | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | PAN-SUE-39 |
| `sue.legajos.crear` | Alta (con búsqueda/creación de persona) | — | T-RRHH | tenant | API-SUE-05, API-SUE-19, PAN-SUE-04 |
| `sue.licencias.autorizar` | Decisiones | S D | T-GER, T-RRHH | tenant | API-SUE-46, API-SUE-83 |
| `sue.licencias.solicitar` | Licencias | — | C-EMP | self | API-POR-98, PAN-POR-73 |
| `sue.licencias.ver` | Licencias (admin) | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | API-SUE-45, API-SUE-47, PAN-SUE-22 |
| `sue.liquidaciones.simular` | Simulación | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | API-SUE-54, PAN-SUE-26 |
| `sue.liquidaciones.ver` | Controles, comparativo, vista previa de asiento | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | API-SUE-53, API-SUE-77, PAN-SUE-24 (+2) |
| `sue.novedades.aprobar` | Acciones masivas | S D | T-GER, T-RRHH | tenant | API-SUE-41 |
| `sue.novedades.crear` | Fichadas | — | T-RRHH | tenant | API-SUE-43, API-SUE-44, PAN-SUE-21 |
| `sue.novedades.importar` | Importar (Excel, OT, flota, fichadas, anticipos) | — | T-RRHH | tenant | API-SUE-42, PAN-SUE-19 |
| `sue.novedades.ver` | Novedades del período | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | PAN-SUE-18, PAN-SUE-20 |
| `sue.pagos.solicitar` | Pago de haberes y obligaciones | — | T-RRHH | tenant | API-SUE-66 |
| `sue.pagos.ver` | Seguimiento | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | API-SUE-67, PAN-SUE-31 |
| `sue.portal.certificados.ver` | Constancias | — | C-EMP | self | API-SUE-82, PAN-SUE-45 |
| `sue.portal.datos.ver` | Mis datos y documentos | — | C-EMP | self | PAN-SUE-43 |
| `sue.portal.documentos.subir` | Datos y documentos | — | C-EMP | self | API-SUE-81 |
| `sue.portal.evaluaciones.autoevaluar` | Evaluaciones propias | — | C-EMP | self | API-SUE-84, PAN-SUE-46 |
| `sue.portal.licencias.solicitar` | Licencias propias | — | C-EMP | self | API-SUE-80, PAN-SUE-42 |
| `sue.portal.recibos.ver` | Mis recibos | — | C-EMP | self | API-SUE-78, API-SUE-79, PAN-SUE-41 (+1) |
| `sue.presentaciones.aprobar` | Aprobar, cargar acuse, rectificar | S D | T-GER, T-RRHH | tenant | API-SUE-64 |
| `sue.presentaciones.generar` | Generar LSD, SICOSS, SICORE, F.1357/F.1359, sindicatos, ART | — | T-RRHH | tenant | API-SUE-63, PAN-SUE-30 |
| `sue.presentaciones.ver` | Descargar archivo (URL firmada) | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | API-SUE-65 |
| `sue.recibos.emitir` | Reenviar, rectificar | — | T-RRHH | tenant | API-SUE-56, API-SUE-57 |
| `sue.recibos.firmar` | Firmar conformidad/disconformidad (OTP) | S D | C-EMP | self | API-POR-95, PAN-POR-71 |
| `sue.recibos.ver` | Recibos | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN, C-EMP | tenant / self | API-SUE-55, API-POR-94, API-POR-96 (+3) |
| `sue.reglasContables.configurar` | Reglas contables | S | T-ADM, T-RRHH | tenant | API-SUE-68, PAN-SUE-32 |
| `sue.remuneraciones.ver` | Recibos | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | API-SUE-55 |
| `sue.reportes.ver` | Tablas oficiales adoptadas | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | API-SUE-28, API-SUE-74, PAN-SUE-01 (+2) |
| `sue.rrhh.accidentes.ver` | Accidentes y ART | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | PAN-SUE-36 |
| `sue.rrhh.evaluaciones.ver` | Evaluaciones y objetivos | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | PAN-SUE-34 |
| `sue.rrhh.juicios.ver` | Juicios laborales | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | PAN-SUE-37 |
| `sue.rrhh.sanciones.ver` | Sanciones y sumarios | — | T-ADM, T-GER, T-TES, T-CON, T-RRHH, T-SIN | tenant | PAN-SUE-35 |
| `sue.tiposLiquidacion.configurar` | Tipos de liquidación | S | T-ADM, T-RRHH | tenant | API-SUE-35, PAN-SUE-14 |
| `sue.tiposNovedad.configurar` | Tipos | S | T-ADM, T-RRHH | tenant | API-SUE-39, PAN-SUE-17 |
| `sue.vacaciones.solicitar` | Saldo y solicitudes | — | C-EMP | self | API-POR-97, PAN-POR-72 |
| `sue.variables.configurar` | Variables (+ /:id/rename) | S | T-ADM, T-RRHH | tenant | API-SUE-30, PAN-SUE-12 |

##### M17 INS — Institucional (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `ins.actas.firmar` | Firmar | S D | T-SEC, T-CJO | tenant | API-INS-044 |
| `ins.asistencia.registrar` | Participantes y asistencia | — | T-SEC, C-EMP | tenant / self | API-INS-040, API-INS-041, PAN-INS-20 |
| `ins.asociados.aprobar` | Cambio de estado (toStatus, motivo, acta, fecha efectiva) | S D | T-SEC, T-CJO | tenant | API-INS-006, API-INS-009, API-INS-010 (+1) |
| `ins.asociados.crear` | Crear solicitud de ingreso | — | T-SEC | tenant | API-INS-002 |
| `ins.asociados.egresar` | Cambio de estado (toStatus, motivo, acta, fecha efectiva) | — | T-SEC | tenant | API-INS-006, PAN-INS-04 |
| `ins.asociados.renumerar` | Solicitar renumeración | — | T-SEC | tenant | API-INS-007 |
| `ins.capital.ajustar` | Movimiento manual (queda pending hasta aprobación) | — | T-SEC | tenant | API-INS-017, API-INS-018, API-INS-029 (+1) |
| `ins.capital.importar` | Importación (simular/confirmar) | — | T-SEC | tenant | API-INS-020, PAN-INS-13 |
| `ins.capital.ver` | Movimientos con filtros | — | T-ADM, T-GER, T-CAJ, T-CON, T-ATE, T-SEC, T-CJO, T-SIN | tenant | API-INS-016, API-INS-019, API-INS-030 (+3) |
| `ins.catalogosBase.gestionar` | Canónica propuesta para plataforma.catalogos.gestionar. Catálogo base de categorías INAES | — | P-SUP, P-ADM | global | API-INS-070 |
| `ins.cierres.crear` | Cierres y reapertura | — | T-SEC | tenant | API-INS-028, PAN-INS-12 |
| `ins.config.configurar` | Rubros de capital | S | T-ADM, T-SEC | tenant | API-INS-013, API-INS-014, API-INS-015 (+6) |
| `ins.credenciales.emitir` | Credenciales masivas (job) | S | T-SEC | tenant | API-INS-059, PAN-INS-27 |
| `ins.excedentes.calcular` | Distribuciones | — | T-SEC | tenant | API-INS-032, API-INS-033, PAN-INS-14 |
| `ins.excedentes.ejecutar` | Ejecutar (job) | — | T-SEC | tenant | API-INS-034 |
| `ins.honorarios.aprobar` | Aprobar, anular | S D | T-SEC, T-CJO | tenant | API-INS-056 |
| `ins.honorarios.gestionar` | Definiciones de honorarios | — | T-SEC | tenant | API-INS-054, API-INS-055, PAN-INS-25 |
| `ins.inaes.exportar` | Generar, validar, registrar presentación y acuse | S | T-ADM, T-SEC | tenant | API-INS-057, PAN-INS-26 |
| `ins.libro.emitir` | Generar Libro de Registro de Asociados (job) | — | T-SEC | tenant | API-INS-011, API-INS-012, PAN-INS-05 |
| `ins.listas.gestionar` | Listas | — | T-SEC | tenant | API-INS-052, PAN-INS-22 |
| `ins.mi.solicitar` | Solicitud de ingreso, egreso, poder o reclamo de padrón | — | C-SOC, C-REP | self | API-INS-066, API-POR-127, PAN-INS-32 |
| `ins.mi.ver` | Mi asociación (PWA) | — | C-SOC, C-REP | self | API-INS-063, API-INS-064, API-INS-065 (+5) |
| `ins.organos.gestionar` | Órganos y cargos | — | T-SEC | tenant | API-INS-035, API-INS-036, PAN-INS-15 |
| `ins.padrones.aprobar` | Publicar, aprobar final | S D | T-SEC, T-CJO | tenant | API-INS-048, API-INS-049 |
| `ins.padrones.generar` | Generar padrón (job) | — | T-SEC | tenant | API-INS-046, API-INS-050, PAN-INS-19 |
| `ins.padrones.ver` | Entradas con motivo | — | T-ADM, T-GER, T-CAJ, T-CON, T-ATE, T-SEC, T-CJO, T-SIN | tenant | API-INS-047 |
| `ins.poderes.validar` | Poderes | — | T-SEC | tenant | API-INS-051 |
| `ins.reportes.ver` | Reportes de §15 (?format=json/csv/xlsx/pdf) | — | T-ADM, T-GER, T-CAJ, T-CON, T-ATE, T-SEC, T-CJO, T-SIN | tenant | API-INS-062 |
| `ins.rescates.aprobar` | Aprobar, programar, rechazar, cancelar | S D | T-SEC, T-CJO | tenant | API-INS-027 |
| `ins.rescates.gestionar` | Rescates | — | T-SEC | tenant | API-INS-025, API-INS-026, PAN-INS-11 |
| `ins.reservas.gestionar` | Reservas | — | T-SEC | tenant | API-INS-021, API-INS-022, PAN-INS-09 |
| `ins.reuniones.gestionar` | Reuniones y asambleas | — | T-SEC | tenant | API-INS-037, API-INS-038, API-INS-039 (+2) |
| `ins.reuniones.ver` | Resoluciones y seguimiento | — | T-ADM, T-GER, T-CAJ, T-CON, T-ATE, T-SEC, T-CJO, T-SIN | tenant | API-INS-045, PAN-INS-16, PAN-INS-17 (+1) |
| `ins.status.ver` | Canónica propuesta para ins.status.read. Verificación externa de condición de asociado (sin datos personales) | X | S-API | tenant | API-INS-069 |
| `ins.transferencias.crear` | Transferencias | — | T-SEC | tenant | API-INS-023, API-INS-024, PAN-INS-10 |
| `ins.votaciones.gestionar` | Votaciones y recuentos | — | T-SEC | tenant | API-INS-053, PAN-INS-21 |

##### M18 SOC — Servicios sociales y flota (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `soc.actos.programar` | Actos | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-023, PAN-SOC-11 |
| `soc.actos.registrar` | Programar, realizar, cancelar | — | T-TEC, T-STE, T-SOC, C-EMP | tenant / self | API-SOC-024, PAN-SOC-35 |
| `soc.adherentes.gestionar` | Alta de adherente | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-002, API-SOC-003, API-SOC-004 (+2) |
| `soc.adherentes.ver` | Adherentes del contrato (?asOf=, ?includeEnded=) | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CON, T-TEC, T-STE, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-SOC-001, API-SOC-006, API-SOC-007 (+3) |
| `soc.autorizaciones.gestionar` | Autorizaciones de internación y prácticas | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-028, PAN-SOC-16 |
| `soc.beneficiarios.gestionar` | Beneficiarios | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-005 |
| `soc.campanas.gestionar` | Campañas y turnos | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-027 |
| `soc.cementerio.configurar` | Establecimientos y reglamentos | S | T-ADM, T-SOC | tenant | API-SOC-018, API-SOC-019, PAN-SOC-12 |
| `soc.cementerio.ver` | Unidades (importación masiva) | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CON, T-TEC, T-STE, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-SOC-019, API-SOC-025, PAN-SOC-09 |
| `soc.certificados.aprobar` | Aprobar, liquidar, cancelar | S D | T-SOC | tenant | API-SOC-041 |
| `soc.combustible.gestionar` | Combustibles | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-046, API-SOC-047, PAN-SOC-24 |
| `soc.config.configurar` | Características de viaje | S | T-ADM, T-SOC | tenant | API-SOC-031, API-SOC-054, PAN-SOC-29 |
| `soc.convenios.gestionar` | Convenios | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-010 |
| `soc.derechos.aprobarCesion` | Formalizar, ceder, suceder, extinguir | S D | T-SOC | tenant | API-SOC-022 |
| `soc.derechos.aprobarExtincion` | Formalizar, ceder, suceder, extinguir | S D | T-SOC | tenant | API-SOC-022 |
| `soc.derechos.gestionar` | Reservar (control de concurrencia por version) | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-020, API-SOC-021, API-SOC-022 (+1) |
| `soc.dispenser.registrar` | Registrar retiro con validación de límites | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-053, PAN-SOC-28 |
| `soc.flota.ver` | Vehículos aptos y libres en un rango (para M10 y traslados) | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CON, T-TEC, T-STE, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-SOC-044, PAN-SOC-22 |
| `soc.gps.registrar` | Canónica propuesta para soc.gps.write. Ingesta de posiciones por lote (adaptador) | X | S-API | tenant | API-SOC-051 |
| `soc.materiales.gestionar` | Asignar, reservar, liberar, reasignar | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-038, API-SOC-039 |
| `soc.mi.solicitar` | Solicitud de alta/baja de integrante, prestación o acto | — | C-SOC, C-REP | self | API-SOC-057, API-POR-126, PAN-SOC-31 (+1) |
| `soc.mi.ver` | Mi grupo y coberturas | — | C-SOC, C-REP | self | API-SOC-056, API-SOC-058, API-SOC-059 (+7) |
| `soc.mi.viajes.ver` | Viajes del chofer y registros offline | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CON, T-TEC, T-STE, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-SOC-060, PAN-SOC-34 |
| `soc.obra.gestionar` | Progreso (DELETE solo si no está certificado) | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-037, API-SOC-040, PAN-SOC-20 |
| `soc.ortopedia.gestionar` | Elementos y préstamos | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-052, PAN-SOC-27 |
| `soc.planes.configurar` | Planes | S | T-ADM, T-SOC | tenant | API-SOC-008, PAN-SOC-03 |
| `soc.precios.actualizar` | Precios y actualización masiva (job) | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-034 |
| `soc.prestadores.gestionar` | Prestadores | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-009, PAN-SOC-04 |
| `soc.profesionales.gestionar` | Profesionales y especialidades | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-011 |
| `soc.rendiciones.aprobar` | Enviar, aprobar, rechazar | S D | T-SOC | tenant | API-SOC-049 |
| `soc.rendiciones.gestionar` | Rendiciones | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-048, PAN-SOC-25 |
| `soc.reportes.ver` | Reportes de §15 | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CON, T-TEC, T-STE, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-SOC-055, PAN-SOC-15, PAN-SOC-21 |
| `soc.sangre.gestionar` | Solicitudes de banco de sangre | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-026 |
| `soc.sangre.ver` | Banco de sangre | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CON, T-TEC, T-STE, T-ATE, T-SAT, T-SOC, T-SIN | tenant | PAN-SOC-13 |
| `soc.solicitudes.crear` | Solicitudes | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-012 |
| `soc.solicitudes.resolver` | Aprobar, rechazar, derivar, registrar respuesta, cerrar | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-014 |
| `soc.solicitudes.ver` | Verificar cobertura a la fecha del evento | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CON, T-TEC, T-STE, T-ATE, T-SAT, T-SOC, T-SIN | tenant | API-SOC-013, PAN-SOC-05, PAN-SOC-06 |
| `soc.subsidios.aprobar` | Aprobar, rechazar, pagar | S D | T-SOC | tenant | API-SOC-017 |
| `soc.subsidios.crear` | Subsidios | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-016, PAN-SOC-08 |
| `soc.traslados.gestionar` | Viajes y tramos | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-029, API-SOC-030 |
| `soc.traslados.ver` | Agenda y registro de traslados | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CON, T-TEC, T-STE, T-ATE, T-SAT, T-SOC, T-SIN | tenant | PAN-SOC-14 |
| `soc.viajes.registrarKm` | Viajes del chofer y registros offline | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-060 |
| `soc.vivienda.adjudicar` | Adjudicar, iniciar obra, entregar, transferir, rescindir, cambiar plan | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-036 |
| `soc.vivienda.configurar` | Planes, tipologías, etapas, actividades, materiales | S | T-ADM, T-SOC | tenant | API-SOC-032, API-SOC-033, PAN-SOC-17 |
| `soc.vivienda.rescindir` | Adjudicar, iniciar obra, entregar, transferir, rescindir, cambiar plan | — | T-TEC, T-STE, T-SOC | tenant | API-SOC-036 |
| `soc.vivienda.ver` | Viviendas inscriptas | — | T-ADM, T-GER, T-FAC, T-CAJ, T-CON, T-TEC, T-STE, T-ATE, T-SAT, T-SOC, T-SIN | tenant | PAN-SOC-18, PAN-SOC-19 |

##### M19 POR — Landing, portal y app del socio (capabilities de los anexos)

| Capability | Descripción | Marcas | Roles | Alcance | Fuente |
|---|---|---|---|---|---|
| `por.accesos.ver` | Accesos de una cuenta | — | T-ADM, T-GER, T-ATE, T-SAT, T-COM, T-SIN | tenant | API-POR-114, PAN-POR-90 |
| `por.adherentes.gestionar` | Adherentes del servicio | — | C-SOC, C-REP | rel | PAN-POR-67 |
| `por.autolectura.crear` | Ventana vigente y último valor | — | C-SOC, C-REP | rel | API-POR-77, API-POR-78, API-POR-79 (+1) |
| `por.banners.configurar` | Banners | S | T-ADM | tenant | API-POR-117, PAN-POR-93 |
| `por.borradores.gestionar` | Borradores | — | C-SOC, C-REP | rel | API-POR-45, PAN-POR-63 |
| `por.comprobantes.ver` | Comprobantes de las cuentas autorizadas del usuario (solo autorizados y publicados). | — | C-SOC, C-REP | rel | API-FAC-150, API-FAC-151, PAN-FAC-43 (+1) |
| `por.consentimientos.editar` | Preferencias y consentimientos | — | C-SOC, C-REP | rel | API-NFR-26 |
| `por.constancias.descargar` | Listar constancias / solicitar libre deuda | — | C-SOC, C-REP | rel | API-POR-73, PAN-POR-64 |
| `por.consumos.ver` | Llamadas atribuidas por contrato y período (RF-TEC-237). Solo lectura; destino enmascarado salvo tec.telefonia.lineas.*;… | — | C-SOC, C-REP, S-SYS | rel / tenant | API-TEC-55, API-POR-75, API-POR-76 (+3) |
| `por.ddjj.presentar` | Plantilla de DDJJ del servicio del contrato (PRM-CAT-110) leída de API-CAT-41: campos, unidad de potencia y obligatoriedad… | — | C-SOC, C-REP | rel | API-POR-125, PAN-POR-66 |
| `por.debito.gestionar` | Consultar, adherir (sesión tokenizada de M07), dar de baja | — | C-SOC, C-REP | rel | API-POR-70, PAN-POR-44 |
| `por.facturaDigital.gestionar` | Adhesión a factura digital (M05) | — | C-SOC, C-REP | rel | API-POR-71, PAN-POR-45 |
| `por.facturas.consultar` | Canónica propuesta para public.facturas.consultar. Consulta sin login con cuenta + dato de validación (si PRM-FAC-145). Respuesta mínima: vencimientos, total, enlace PDF de un… | — | público (sin login) | público | API-FAC-154 |
| `por.facturas.descargar` | URL firmada del PDF | — | C-SOC, C-REP | rel | API-POR-62, API-POR-69 |
| `por.facturas.ver` | CAE, vencimiento, QR y leyendas del propio comprobante | — | T-ADM, T-GER, T-ATE, T-SAT, T-COM, T-SIN, C-SOC, C-REP | tenant / rel | API-FIS-81, API-POR-60, API-POR-61 (+8) |
| `por.formularios.configurar` | CRUD de formularios | S | T-ADM | tenant | API-POR-108, PAN-POR-88 |
| `por.formularios.publicar` | Publicar versión | S D | T-SAT | tenant | API-POR-109 |
| `por.formularios.ver` | Presentaciones | — | T-ADM, T-GER, T-ATE, T-SAT, T-COM, T-SIN | tenant | API-POR-110, API-POR-111, PAN-POR-87 (+1) |
| `por.gestiones.crear` | Mis gestiones (incluye históricas migradas) | — | C-SOC, C-REP | rel | API-POR-82, API-POR-83, PAN-POR-33 (+2) |
| `por.landing.editar` | Borrador de landing | — | T-ATE, T-COM | tenant | API-POR-106, PAN-POR-85 |
| `por.landing.publicar` | Revisión, aprobación, programación, publicación, reversión | S D | T-SAT | tenant | API-POR-107, API-POR-121, PAN-POR-86 |
| `por.metricas.ver` | Métricas | — | T-ADM, T-GER, T-ATE, T-SAT, T-COM, T-SIN | tenant | API-POR-118, PAN-POR-94 |
| `por.migracion.ejecutar` | Migración CoopOnline | — | T-ATE, T-COM | tenant | API-POR-116, PAN-POR-92 |
| `por.misDatos.solicitar` | Solicitud de derechos del titular | — | C-SOC, C-REP | self | API-NFR-25 |
| `por.misDatos.ver` | Datos del titular autenticado | — | C-SOC, C-REP, C-EMP | self | API-NFR-24, PAN-NFR-09 |
| `por.ofertas.ver` | Canónica propuesta para public.ofertas.ver. Oferta pública de la landing (componente embebido en PAN-POR-02/03; HUE-SRV-04). | — | público (sin login) | público | API-CAT-51 |
| `por.pagos.crear` | Recalcular deuda/recargos/percepciones para una selección | — | C-SOC, C-REP | rel | API-POR-64, API-POR-65, API-POR-66 (+3) |
| `por.parametros.configurar` | Parámetros del portal con vigencia (T04) | S | T-ADM | tenant | API-POR-105, PAN-POR-84 |
| `por.perfil.editar` | Perfil; PATCH de contacto inicia verificación (T02) | — | C-SOC, C-REP | rel | API-POR-27, PAN-POR-59 |
| `por.prepaga.comprar` | Cotizar recarga | — | C-SOC, C-REP | rel | API-POR-80, API-POR-81, PAN-POR-49 |
| `por.recepcionPublica.ver` | Recepción pública: identificar, derivar, reenviar | — | T-ADM, T-GER, T-ATE, T-SAT, T-COM, T-SIN | tenant | API-POR-115, PAN-POR-91 |
| `por.representaciones.gestionar` | Representaciones otorgadas y recibidas | — | C-SOC, C-REP | rel | API-POR-35, API-POR-36, PAN-POR-57 (+1) |
| `por.servicios.contratar` | Oferta para contratar con condiciones del usuario (aviso de deuda, PRM-POR-071) | — | C-SOC, C-REP | rel | API-POR-43, PAN-POR-31 |
| `por.servicios.solicitarBaja` | Baja, suspensión o reactivación del servicio | — | C-SOC, C-REP | rel | PAN-POR-37 |
| `por.servicios.suspender` | Baja, suspensión o reactivación del servicio | — | C-SOC, C-REP | rel | PAN-POR-37 |
| `por.servicios.ver` | Plan de cuotas de obra del contrato, delegado en API-TAR-066 (M04): cuota n/N, cuotas facturadas, saldo, unidades, próxima… | — | C-SOC, C-REP | rel | API-POR-123, PAN-POR-28, PAN-POR-29 (+1) |
| `por.totems.configurar` | Tótems | S | T-ADM | tenant | API-POR-120, PAN-POR-96 |
| `por.turnos.gestionar` | Turnos de atención (M09 turnero), tiempo estimado | — | C-SOC, C-REP | rel | API-POR-89, PAN-POR-52 |
| `por.vinculaciones.aprobar` | Bandeja de vinculaciones; aprobar/rechazar | S D | T-SAT | tenant | API-POR-112, API-POR-113 |
| `por.vinculaciones.ver` | Vinculaciones pendientes | — | T-ADM, T-GER, T-ATE, T-SAT, T-COM, T-SIN | tenant | PAN-POR-89 |
| `por.visitas.cancelar` | Seguimiento. Solo datos propios. | — | C-SOC, C-REP | rel | API-TEC-41 |
| `por.visitas.gestionar` | Franjas disponibles (M10) | — | C-SOC, C-REP | rel | API-POR-54, API-POR-55, API-POR-56 (+5) |
| `por.visitas.reprogramar` | Seguimiento. Solo datos propios. | — | C-SOC, C-REP | rel | API-TEC-41 |
| `por.visitas.reservar` | Reserva del socio. Rate limit. | — | C-SOC, C-REP | rel | API-TEC-40 |
| `por.visitas.ver` | Seguimiento. Solo datos propios. | — | C-SOC, C-REP | rel | API-TEC-41 |
| `por.vistaSocio.ver` | Abrir vista de socio solo lectura (motivo) | — | T-ADM, T-GER, T-ATE, T-SAT, T-COM, T-SIN | tenant | API-POR-119, PAN-POR-95 |

#### 4.4.3 Nombres fuera de convención o sinónimos (canónica propuesta)

Nombres usados por los anexos que **no** se registran como capability: no siguen `modulo.recurso.accion` con acción en español, son comodines o duplican una capability existente. Cada anexo debe reemplazarlos por la canónica propuesta (T02 no edita los otros anexos). Hasta que se corrijan, el chequeo de permisos no los reconoce. Las propuestas marcadas [VERIFICAR] requieren decisión del anexo dueño.

| Módulo | Nombre usado | Canónica propuesta | Motivo | Anexos que lo usan | Fuente |
|---|---|---|---|---|---|
| accounting | `accounting:read` | `con.asientos.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-110, API-BIA-111, API-BIA-112 |
| accounts | `accounts:read` | `per.cuentas.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-77, API-BIA-78, API-BIA-81 |
| arrears | `arrears:read` | `mor.deudas.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-98, API-BIA-99, API-BIA-100 |
| bia | `bia.ia.preguntar` | `bia.ia.consultar` | Sinónimo de una capability existente | T10 | API-BIA-40, API-BIA-41, API-BIA-42 (+1) |
| bia | `bia.indicadores.certificar` | `bia.cubos.certificar` | Sinónimo de una capability existente | T10 | API-BIA-29, API-BIA-30, PAN-BIA-13 |
| billing | `billing:read` | `fac.comprobantes.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-91, API-BIA-92, API-BIA-93 |
| cat | `cat.adherentes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M02 | API-CAT-40 |
| cat | `cat.categorias.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M02 | API-CAT-24 |
| cat | `cat.clases.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M02 | API-CAT-25 |
| cat | `cat.conceptos.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M02 | API-CAT-19 |
| cat | `cat.paquetes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M02 | API-CAT-23 |
| cat | `cat.planes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M02 | API-CAT-20 |
| cat | `cat.plantillas.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M02 | API-CAT-55 |
| cat | `cat.productos.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M02 | API-CAT-18 |
| cat | `cat.propiedades.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M02 | API-CAT-26 |
| cat | `cat.read` | `cat.contratos.ver` | Falta el recurso; API externa (marca X) | M02 | API-CAT-54 |
| cmp | `cmp.*.exportar` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M12 | API-CMP-100 |
| cmp | `cmp.concursos.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M12 | API-CMP-035, PAN-CMP-07 |
| cmp | `cmp.portal.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M12 | API-CMP-110, PAN-CMP-23 |
| cmp | `cmp.read` | `cmp.ordenes.ver` | Falta el recurso; API externa (marca X) [VERIFICAR recurso] | M12 | API-CMP-120 |
| cob | `cob.caja.abrir` | `cob.cajas.abrir` | Variante singular/plural de una capability existente | M07 | API-COB-27, PAN-COB-09 |
| cob | `cob.caja.cerrar` | `cob.cajas.cerrar` | Variante singular/plural de una capability existente | M07 | API-COB-29, API-COB-30, API-COB-41 (+2) |
| collections | `collections:read` | `cob.cuentaCorriente.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-94, API-BIA-95, API-BIA-96 |
| consumption | `consumption:read` | `med.consumos.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-88, API-BIA-89, API-BIA-90 |
| contracts | `contracts:read` | `cat.contratos.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-82, API-BIA-83, API-BIA-84 (+3) |
| crm | `crm.config.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M09 | API-CRM-39 |
| crm | `crm.horas.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M09 | API-CRM-43 |
| crm | `crm.incidentes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M09 | API-CRM-28 |
| crm | `crm.mesaEntradas.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M09 | API-CRM-32 |
| crm | `crm:read` | `crm.casos.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-101, API-BIA-102 |
| dataSourceCatalog | `dataSourceCatalog.scopeAware` | [VERIFICAR] | Prefijo `dataSourceCatalog` no es código de módulo (guía §62) | T11 | API-WFL-26 |
| datasets | `datasets:read` | `bia.datasets.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-119, API-BIA-120 |
| exports | `exports:write` | `bia.exportaciones.crear` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-121, API-BIA-122, API-BIA-123 |
| ext | `ext.cat.contratos.ver` | `bia.cat.contratos.ver` | Prefijo `ext` no es código de módulo (guía §62) | M02 | API-CAT-54 |
| ext | `ext.cob.leer` | `cob.cuentaCorriente.ver` | Prefijo `ext` no es módulo; la exposición externa se marca con X y el scope de T10, no con otro prefijo | M05 | API-FAC-157 |
| ext | `ext.fac.codigos.ver` | `bia.fac.codigos.ver` | Prefijo `ext` no es código de módulo (guía §62) | M05 | API-FAC-157 |
| ext | `ext.fac.comprobantes.ver` | `bia.fac.comprobantes.ver` | Prefijo `ext` no es código de módulo (guía §62) | M05 | API-FAC-155 |
| ext | `ext.fac.importaciones.crear` | `bia.fac.importaciones.crear` | Prefijo `ext` no es código de módulo (guía §62) | M05 | API-FAC-156 |
| ext | `ext.fac.importar` | `fac.comprobantes.importar` [VERIFICAR] | Prefijo `ext` no es módulo; la exposición externa se marca con X y el scope de T10 | M05 | API-FAC-156 |
| ext | `ext.fac.leer` | `fac.comprobantes.ver` | Prefijo `ext` no es módulo; la exposición externa se marca con X y el scope de T10 | M05 | API-FAC-155 |
| ext | `ext.med.consumos.ver` | `bia.med.consumos.ver` | Prefijo `ext` no es código de módulo (guía §62) | M03 | API-MED-75 |
| ext | `ext.med.lecturas.crear` | `bia.med.lecturas.crear` | Prefijo `ext` no es código de módulo (guía §62) | M03 | API-MED-76 |
| ext | `ext.per.cuentas.ver` | `per.cuentas.ver` | Prefijo `ext` no es módulo; la exposición externa se marca con X y el scope de T10 | M01 | API-PER-74 |
| ext | `ext.per.titulares.ver` | `per.titulares.ver` | Prefijo `ext` no es módulo; la exposición externa se marca con X y el scope de T10 | M01 | API-PER-75 |
| fac | `fac.notasDebito.crear` | `fac.notasDebito.emitir` | Sinónimo de una capability existente | M05 | API-FAC-085 |
| fac | `fac.plantillas.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M05 | API-FAC-009 |
| field | `field:read` | `tec.ordenes.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-103, API-BIA-104 |
| fis | `fis.*.ver` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M06 | API-FIS-80, PAN-FIS-40 |
| iam | `iam.apiClientes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | T02 | API-IAM-47 |
| iam | `iam.plataforma.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | T02 | API-IAM-66 |
| iam | `iam.portal.usuarios.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | T02 | API-IAM-63 |
| ins | `ins.status.read` | `ins.status.ver` | Acción en inglés; la guía §62 fija acciones en español | M17 | API-INS-069 |
| institutional | `institutional:read` | `ins.asociados.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-113, API-BIA-114, API-BIA-115 |
| jobRuns | `jobRuns.requestedBy` | — (no es capability: es la condición "solo el solicitante"; alcance `self`) | Campo citado en la columna de capability | T01 | API-PLA-67 |
| ledger | `ledger:read` | `con.asientos.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-79, API-BIA-80, API-BIA-97 |
| med | `med.cronograma.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M03 | API-MED-18 |
| med | `med.demanda.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M03 | API-MED-65 |
| med | `med.gd.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M03 | API-MED-59 |
| med | `med.medicionPropia.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M03 | API-MED-67 |
| med | `med.read` | `med.consumos.ver` | Falta el recurso; API externa (marca X) | M03 | API-MED-75 |
| med | `med.readings.write` | `med.lecturas.capturar` | Sinónimo de una capability existente | M03 | API-MED-76 |
| med | `med.rutas.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M03 | API-MED-16 |
| meta | `meta.platformOnly` | — (no es capability: metadato de pantalla solo de plataforma) | Metadato citado en la columna de capability | T10 | PAN-BIA-23 |
| metrics | `metrics:read` | `bia.indicadores.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-117, API-BIA-118 |
| mor | `mor.*.exportar` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | API-MOR-84 |
| mor | `mor.*.ver` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | API-MOR-83, PAN-MOR-37 |
| mor | `mor.bloqueos.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | PAN-MOR-09 |
| mor | `mor.convenios.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | PAN-MOR-40 |
| mor | `mor.excepciones.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | API-MOR-46, PAN-MOR-23 |
| mor | `mor.garantias.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | API-MOR-74, PAN-MOR-33 |
| mor | `mor.gestionExterna.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | API-MOR-77, PAN-MOR-34 |
| mor | `mor.incobrables.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | PAN-MOR-35 |
| mor | `mor.indices.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | PAN-MOR-04 |
| mor | `mor.interesesFacturar.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | PAN-MOR-08 |
| mor | `mor.politicasMora.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | API-MOR-26, PAN-MOR-10 |
| mor | `mor.prescripcion.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | PAN-MOR-36 |
| mor | `mor.protecciones.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | API-MOR-48, PAN-MOR-24 |
| mor | `mor.restricciones.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | API-MOR-50, PAN-MOR-25 |
| mor | `mor.tasas.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | PAN-MOR-03 |
| mor | `mor.tratamiento.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M08 | PAN-MOR-19 |
| nfr | `nfr.incidentes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | T08 | API-NFR-34 |
| objetivos | `objetivos.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M16 | API-SUE-70 |
| payroll | `payroll:read` | `sue.costos.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-116 |
| per | `per.adherentes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M01 | API-PER-38 |
| per | `per.documentacion.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M01 | API-PER-46 |
| per | `per.personas.fusionar` | `per.personas.unificar` | Sinónimo de una capability existente | M01 | API-PER-57, PAN-PER-18 |
| per | `per.personas.verSensibles` | `per.personas.datosSensibles.ver` | Sinónimo de una capability existente | M01 | API-PER-11 |
| per | `per.puntosPrestacion.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M01 | API-PER-33 |
| per | `per.vinculosUsuario.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M01 | API-PER-62 |
| persons | `persons:read` | `per.personas.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-75, API-BIA-76 |
| pla | `pla.accesos.aprobar` | `pla.soporte.accesos.aprobar` | Sinónimo de una capability existente | T01 | API-PLA-27 |
| pla | `pla.accesos.revocar` | `pla.soporte.accesos.revocar` | Sinónimo de una capability existente | T01 | API-PLA-29 |
| pla | `pla.accesos.solicitar` | `pla.soporte.accesos.solicitar` | Sinónimo de una capability existente | T01 | API-PLA-26, API-PLA-28 |
| pla | `pla.accesos.ver` | `pla.soporte.accesos.ver` | Sinónimo; se propone la canónica | T01 | PAN-PLA-08 |
| pla | `pla.accesosSoporte.aprobar` | `pla.soporte.accesos.aprobar` | Sinónimo de una capability existente | T01 | API-PLA-58 |
| pla | `pla.accesosSoporte.revocar` | `pla.soporte.accesos.revocar` | Sinónimo de una capability existente | T01 | API-PLA-58 |
| pla | `pla.accesosSoporte.ver` | `pla.soporte.accesos.ver` | Sinónimo; se propone la canónica | T01 | API-PLA-57, PAN-PLA-18 |
| pla | `pla.cfg.tablasPlataforma.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | T04 | API-CFG-51 |
| pla | `pla.soporte.accesos.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | T02 | PAN-IAM-27 |
| plataforma | `plataforma.catalogos.gestionar` | `ins.catalogosBase.gestionar` | Prefijo `plataforma` no es módulo; capability de M17 con roles de plataforma (alcance `global`) | M17 | API-INS-070 |
| platform | `platform.tar.funciones.administrar` | `tar.funciones.administrar` | Prefijo `platform` no es módulo; capability de M04 con roles de plataforma (alcance `global`) | M04 | API-TAR-065 |
| platform | `platform.tar.plantillas.administrar` | `tar.plantillas.administrar` | Prefijo `platform` no es módulo; capability de M04 con roles de plataforma (alcance `global`) | M04 | API-TAR-065 |
| plt | `plt.uxd.diccionarioBase.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | T03 | API-UXD-33 |
| plt | `plt.uxd.diccionarioBase.ver` | `uxd.diccionarioBase.ver` | Prefijo `plt` no es módulo; la capability es de T03 con roles de plataforma (alcance `global`) | T03 | API-UXD-34, PAN-UXD-09 |
| plt | `plt.uxd.flags.configurar` | `uxd.flags.configurar` | Prefijo `plt` no es módulo; capability de T03 con roles de plataforma (alcance `global`) | T03 | API-UXD-35, PAN-UXD-11 |
| plt | `plt.uxd.marca.asistir` | `uxd.marca.asistir` | Prefijo `plt` no es módulo; capability de T03 con roles de plataforma (alcance `global`) | T03 | API-UXD-37 |
| plt | `plt.uxd.marca.ver` | `uxd.marca.ver` | Prefijo `plt` no es módulo; capability de T03 con roles de plataforma (alcance `global`) | T03 | API-UXD-36 |
| plt | `plt.uxd.tokens.ver` | `uxd.tokens.ver` | Prefijo `plt` no es módulo; capability de T03 con roles de plataforma (alcance `global`) | T03 | PAN-UXD-10 |
| public | `public.cuadros.ver` | — (pantalla pública sin login: no requiere capability) | Prefijo `public` no es módulo | M04 | API-TAR-061, PAN-TAR-24 |
| public | `public.facturas.consultar` | `por.facturas.consultar` | Prefijo `public` no es código de módulo (guía §62) | M05 | API-FAC-154 |
| public | `public.ofertas.ver` | `por.ofertas.ver` | Prefijo `public` no es código de módulo (guía §62) | M02 | API-CAT-51 |
| pwa | `pwa.factura.explicacion.ver` | `tar.explicacion.ver` | Prefijo `pwa` no es módulo; capability de M04 con alcance `rel` en el portal | M04 | API-TAR-060, PAN-TAR-23 |
| pwa | `pwa.planObra.ver` | `por.planObra.ver` | Sinónimo de una capability existente | M04, M19 | API-TAR-066, API-POR-123 |
| requests | `requests:write` | `crm.casos.crear` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-130, API-BIA-131, API-BIA-132 (+1) |
| rolesPlantilla | `rolesPlantilla.editar` | `iam.rolesPlantilla.editar` | Falta el prefijo de módulo | T02 | PAN-IAM-26 |
| soc | `soc.gps.write` | `soc.gps.registrar` | Acción en inglés; la guía §62 fija acciones en español | M18 | API-SOC-051 |
| stk | `stk.bienesUso.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-53 |
| stk | `stk.depositos.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-10 |
| stk | `stk.fabricacion.estructuras.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-63, API-STK-64 |
| stk | `stk.fabricacion.ordenes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-65 |
| stk | `stk.fabricacion.partes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-66 |
| stk | `stk.inventarios.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-46 |
| stk | `stk.lotes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-28 |
| stk | `stk.recepciones.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-62 |
| stk | `stk.rendiciones.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-39 |
| stk | `stk.revaluaciones.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-51 |
| stk | `stk.rma.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M13 | API-STK-61 |
| storedFiles | `storedFiles.moduleCode` | — (no es capability: el permiso se hereda de la capability del módulo dueño del archivo) | Campo citado en la columna de capability | T01 | API-PLA-62 |
| sue | `sue.costoLaboral` | `sue.costoLaboral.ver` | Falta la acción; API externa (marca X) | M16 | API-SUE-86 |
| sue | `sue.legajo.ver` | `sue.legajos.ver` | Variante singular/plural de una capability existente | M19 | API-POR-99, PAN-POR-74 |
| sue | `sue.portal.datos.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M16 | API-SUE-81 |
| sue | `sue.rrhh.accidentes.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M16 | API-SUE-72 |
| sue | `sue.rrhh.evaluaciones.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M16 | API-SUE-70 |
| sue | `sue.rrhh.juicios.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M16 | API-SUE-73 |
| sue | `sue.rrhh.sanciones.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M16 | API-SUE-71 |
| sumarios | `sumarios.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M16 | API-SUE-71 |
| tec | `tec.cdr.import` | `tec.cdr.importar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-39, PAN-TEC-45 |
| tec | `tec.config.manage` | `tec.config.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-21, API-TEC-22, API-TEC-52 (+10) |
| tec | `tec.crew.manage` | `tec.crew.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-21, PAN-TEC-13, PAN-TEC-14 |
| tec | `tec.device.manage` | `tec.device.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-46 |
| tec | `tec.dispatch.manage` | `tec.dispatch.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-09, PAN-TEC-10 |
| tec | `tec.estimate.manage` | `tec.estimate.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-06, PAN-TEC-03 |
| tec | `tec.feasibility.cancel` | `tec.factibilidad.cancelar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-04 |
| tec | `tec.feasibility.create` | `tec.factibilidad.crear` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-01 |
| tec | `tec.feasibility.evaluate` | `tec.factibilidad.evaluar` | Sinónimo de una capability existente | M10 | API-TEC-03, API-TEC-05, PAN-TEC-02 |
| tec | `tec.feasibility.read` | `tec.factibilidad.ver` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-01, API-TEC-02, PAN-TEC-01 |
| tec | `tec.feasibility.reopen` | `tec.factibilidad.reabrir` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-04 |
| tec | `tec.feasibility.update` | `tec.factibilidad.editar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-02 |
| tec | `tec.fieldForm.manage` | `tec.fieldForm.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-25, PAN-TEC-26 |
| tec | `tec.geo.review` | `tec.geo.revisar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-47, PAN-TEC-48 |
| tec | `tec.inspection.approve` | `tec.inspecciones.aprobar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-37 |
| tec | `tec.inspection.manage` | `tec.inspecciones.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-37, PAN-TEC-41, PAN-TEC-54 |
| tec | `tec.installation.read` | `tec.instalaciones.ver` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-23, PAN-TEC-25 |
| tec | `tec.installation.review` | `tec.instalaciones.revisar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-23 |
| tec | `tec.levy.manage` | `tec.levy.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-36, PAN-TEC-40 |
| tec | `tec.maintenance.manage` | `tec.mantenimiento.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-26, PAN-TEC-27 |
| tec | `tec.map.read` | `tec.mapa.ver` | Acción en inglés; la guía §62 fija acciones en español | M10 | PAN-TEC-29, PAN-TEC-56 |
| tec | `tec.mobile.import` | `tec.mobile.importar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-39, PAN-TEC-46 |
| tec | `tec.network.configure` | `tec.redes.configurar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-28, PAN-TEC-30 |
| tec | `tec.network.export` | `tec.redes.exportar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-31, PAN-TEC-34 |
| tec | `tec.network.manage` | `tec.redes.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-29, API-TEC-30, PAN-TEC-31 (+1) |
| tec | `tec.network.read` | `tec.redes.ver` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-27, API-TEC-29 |
| tec | `tec.networkDevice.manage` | `tec.networkDevice.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-32, PAN-TEC-35 |
| tec | `tec.outage.manage` | `tec.cortes.gestionar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-26, PAN-TEC-28 |
| tec | `tec.phone.*` | — (explicitar las capabilities concretas por acción) | Comodín: no es una capability asignable | M10 | API-TEC-38 |
| tec | `tec.provisioning.configure` | `tec.aprovisionamiento.configurar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-33, PAN-TEC-36 |
| tec | `tec.provisioning.operate` | `tec.aprovisionamiento.operar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-34, PAN-TEC-38 |
| tec | `tec.report.read` | `tec.reportes.ver` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-48, PAN-TEC-47 |
| tec | `tec.schedule.configure` | `tec.agenda.configurar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-20, PAN-TEC-12 |
| tec | `tec.schedule.manage` | `tec.agenda.gestionar` | Acción en inglés; equivale a una capability existente | M10 | API-TEC-18, API-TEC-19, PAN-TEC-11 |
| tec | `tec.schedule.read` | `tec.agenda.ver` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-17 |
| tec | `tec.serviceTechnical.read` | `tec.serviceTechnical.ver` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-35 |
| tec | `tec.serviceTechnical.update` | `tec.serviceTechnical.editar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-35 |
| tec | `tec.work.manage` | `tec.obras.gestionar` | Acción en inglés; equivale a una capability existente | M10 | API-TEC-36, PAN-TEC-39 |
| tec | `tec.workOrder.bulkClose` | `tec.ordenes.cerrarMasivo` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-15, PAN-TEC-08 |
| tec | `tec.workOrder.bulkCreate` | `tec.ordenes.crearMasivo` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-15, PAN-TEC-07 |
| tec | `tec.workOrder.cancel` | `tec.ordenes.cancelar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-12 |
| tec | `tec.workOrder.close` | `tec.ordenes.cerrar` | Sinónimo de una capability existente | M10 | API-TEC-11 |
| tec | `tec.workOrder.create` | `tec.ordenes.crear` | Sinónimo de una capability existente | M10 | API-TEC-07, PAN-TEC-06, PAN-TEC-55 |
| tec | `tec.workOrder.execute` | `tec.ordenes.ejecutar` | Sinónimo de una capability existente | M10 | API-TEC-10 |
| tec | `tec.workOrder.print` | `tec.ordenes.imprimir` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-16 |
| tec | `tec.workOrder.read` | `tec.ordenes.ver` | Sinónimo de una capability existente | M10 | API-TEC-07, API-TEC-08, PAN-TEC-04 |
| tec | `tec.workOrder.reopen` | `tec.ordenes.reabrir` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-12 |
| tec | `tec.workOrder.update` | `tec.ordenes.editar` | Acción en inglés; la guía §62 fija acciones en español | M10 | API-TEC-08, API-TEC-13, PAN-TEC-51 |
| tes | `tes.read` | `tes.posicion.ver` | Falta el recurso; API externa (marca X) [VERIFICAR recurso] | M14 | API-TES-87 |
| ven | `ven.read` | `ven.presupuestos.ver` | Falta el recurso; API externa (marca X) [VERIFICAR recurso] | M11 | API-VEN-092 |
| webhooks | `webhooks:manage` | `int.webhooks.gestionar` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X) | T10 | API-BIA-124, API-BIA-125, API-BIA-126 (+2) |
