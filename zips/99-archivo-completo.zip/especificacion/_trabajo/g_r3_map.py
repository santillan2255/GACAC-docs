import re, os, json, sys
sys.stdout.reconfigure(encoding='utf-8')
B = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
an = json.load(open(os.path.join(B, '_trabajo', 'g_r3_analisis.json'), encoding='utf-8'))
t02 = json.load(open(os.path.join(B, '_trabajo', 'g_r3_t02.json'), encoding='utf-8'))
reg = set(t02['reg'])
L = open(os.path.join(B, 'anexos', 'T03-UXD-experiencia-marca-diccionario.md'), encoding='utf-8').read().split('\n')
CAPRE = re.compile(r'(?<!antes )`([a-z]{3}\.[A-Za-z0-9.]+)`')
sm109 = {}
for i, l in enumerate(L, 1):
    m = re.match(r'\| (SM-[A-Z]{3}-\d+) \|', l)
    if m and i > 2000:
        c = l.split('|')
        caps = [k for k in CAPRE.findall(c[4] if len(c) > 5 else '') if k in reg]
        sm109.setdefault(m.group(1), []).append((i, caps, c[2].strip()[:60]))
res = {}
for cap, d in an.items():
    props = []
    for o in d['occ']:
        sm = o[1] if o[1].startswith('SM-') else None
        props.append((o[0], sm, sm109.get(sm) if sm else None))
    res[cap] = props
    print(cap)
    for p in props:
        print('   ', p)
