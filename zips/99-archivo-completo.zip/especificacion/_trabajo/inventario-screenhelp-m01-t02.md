# Inventario ScreenHelp — M01 + T02 (fase 3b)

| Campo | Valor |
|---|---|
| Fecha | 19-11-2026 |
| Origen | Generado desde anexos M01 §pantallas, T02 §10 |
| Uso | Export GoodApps; completar columnas CU, ayuda base, IA |
| Norma | RF-UXD-049; `06` §6.1–6.2; DIR-12, DIR-13 |

Estado por fila: `Pendiente` → borrador ScreenHelp → revisado export.

## M01 PER

| screenId | ScreenHelp | CU | FAQ distinta | IA uso | Notas |
|---|---|---|---|---|---|
| PAN-PER-01 | Revisado export (T03b) | CU-03; CU-TIT-01 | No | No | Núcleo export |
| PAN-PER-02 | Revisado export (T03b) | CU-PER-01..05; CU-04 | No | No | Núcleo export |
| PAN-PER-03 | Revisado export (T03b) | CU-03; CU-PER-06; CU-PER-13 | No | No | Núcleo export |
| PAN-PER-04 | Revisado export (T03b) | CU-03; CU-REG-01 (M19) | No | No | Núcleo export |
| PAN-PER-05 | Revisado export (T03b) | CU-04; CU-TIT-01 | No | No | Núcleo export |
| PAN-PER-06 | Revisado export (T03b) | CU-GEO-01 | No | No | Núcleo export |
| PAN-PER-07 | Revisado export (T03b) | CU-PER-10 | No | No | Núcleo export |
| PAN-PER-08 | Revisado export (T03b) | CU-04 | No | No |  |
| PAN-PER-09 | Revisado export (T03b) | CU-PER-04; CU-PER-05 | No | No |  |
| PAN-PER-10 | Revisado export (T03b) | CU-04 | No | No |  |
| PAN-PER-11 | Revisado export (T03b) | CU-04 | No | No |  |
| PAN-PER-12 | Revisado export (T03b) | CU-PER-07 | No | No |  |
| PAN-PER-13 | Revisado export (T03b) | CU-PER-11; CU-TIT-01 | No | No |  |
| PAN-PER-14 | Revisado export (T03b) | CU-PER-11; CU-TIT-01 | No | No | Núcleo export |
| PAN-PER-15 | Revisado export (T03b) | CU-PER-11 | No | No | Núcleo export |
| PAN-PER-16 | Revisado export (T03b) | CU-PER-03 | No | No | Núcleo export |
| PAN-PER-17 | Revisado export (T03b) | CU-PER-12 | No | No | Núcleo export |
| PAN-PER-18 | Revisado export (T03b) | CU-PER-06 | No | No | Núcleo export |
| PAN-PER-19 | Revisado export (T03b) | CU-GOB-01 | No | No |  |
| PAN-PER-20 | Revisado export (T03b) | CU-04 | No | No |  |
| PAN-PER-21 | Revisado export (T03b) | CU-PER-11 | No | No |  |
| PAN-PER-22 | Revisado export (T03b) | CU-04 | No | No |  |
| PAN-PER-23 | Revisado export (T03b) | CU-PER-13 | No | No | Núcleo export |
| PAN-PER-24 | Revisado export (T03b) | CU-03 | No | No |  |
| PAN-PER-25 | Revisado export (T03b) | CU-REG-01 (M19) | No | No |  |
| PAN-PER-26 | Revisado export (T03b) | CU-REG-01 (M19) | No | No |  |
| PAN-PER-27 | Revisado export (T03b) | CU-PER-05 | No | No |  |
| PAN-PER-28 | Revisado export (T03b) | CU-GEO-01 | No | No |  |

## T02 IAM

| screenId | ScreenHelp | CU | FAQ distinta | IA uso | Notas |
|---|---|---|---|---|---|
| PAN-IAM-01 | Revisado export (T03b) | CU-IAM-11; CU-29 | No | No | Núcleo export; ayuda formato T03 |
| PAN-IAM-02 | Revisado export (T03b) | CU-REG-01 (M19) | No | No | Núcleo export; ayuda formato T03 |
| PAN-IAM-03 | Revisado export (T03b) | CU-IAM-11 | No | No | Núcleo export |
| PAN-IAM-04 | Revisado export (T03b) | CU-IAM-01; CU-IAM-02 | No | No | Núcleo export |
| PAN-IAM-05 | Revisado export (T03b) | CU-IAM-11 | No | No |  |
| PAN-IAM-06 | Revisado export (T03b) | CU-29 | No | No |  |
| PAN-IAM-07 | Revisado export (T03b) | CU-IAM-11 | No | No |  |
| PAN-IAM-08 | Revisado export (T03b) | CU-IAM-11 | No | No |  |
| PAN-IAM-09 | Revisado export (T03b) | CU-29; CU-GOB-01 | No | No | Núcleo export |
| PAN-IAM-10 | Revisado export (T03b) | CU-GOB-01; CU-IAM-02 | No | No | Núcleo export |
| PAN-IAM-11 | Revisado export (T03b) | CU-ACC-01 | No | No | Núcleo export |
| PAN-IAM-12 | Revisado export (T03b) | CU-ACC-01; CU-IAM-09 | No | No | Núcleo export |
| PAN-IAM-13 | Revisado export (T03b) | CU-ACC-01 | No | No |  |
| PAN-IAM-14 | Revisado export (T03b) | CU-ACC-01 | No | No | Núcleo export |
| PAN-IAM-15 | Revisado export (T03b) | CU-IAM-04 | No | No | Núcleo export |
| PAN-IAM-16 | Revisado export (T03b) | CU-IAM-04 | No | No |  |
| PAN-IAM-17 | Revisado export (T03b) | CU-GOB-01 | No | No | Núcleo export |
| PAN-IAM-18 | Revisado export (T03b) | CU-GOB-01 | No | No |  |
| PAN-IAM-19 | Revisado export (T03b) | CU-GOB-01 | No | No |  |
| PAN-IAM-20 | Revisado export (T03b) | CU-GOB-01 | No | No |  |
| PAN-IAM-21 | Revisado export (T03b) | CU-GOB-01 | No | No |  |
| PAN-IAM-22 | Revisado export (T03b) | CU-IAM-11 | No | No |  |
| PAN-IAM-23 | Revisado export (T03b) | CU-IAM-11 | No | No |  |
| PAN-IAM-24 | Revisado export (T03b) | CU-ACC-01 | No | No |  |
| PAN-IAM-25 | Revisado export (T03b) | CU-29 | No | No |  |
| PAN-IAM-26 | Revisado export (T03b) | CU-IAM-05 | No | No |  |
| PAN-IAM-27 | Revisado export (T03b) | CU-IAM-05 | No | No | Núcleo export |
| PAN-IAM-28 | Revisado export (T03b) | CU-IAM-05 | No | No |  |
| PAN-IAM-29 | Revisado export (T03b) | CU-GOB-01 | No | No |  |
| PAN-IAM-30 | Revisado export (T03b) | CU-IAM-02 | No | No |  |
| PAN-IAM-31 | Revisado export (T03b) | CU-29 | No | No |  |
| PAN-IAM-32 | Revisado export (T03b) | CU-REG-01 (M19) | No | No |  |

**Totales:** M01 = 28 pantallas; T02 = 32 pantallas.

**Cobertura T03b:** 60/60 pantallas con borrador; artículos en anexo: 60.
