# Ronda 4 de cierre en T02: registra capabilities usadas por los anexos y faltantes, alias y filas de 4.4.3.
import re, json, sys
sys.stdout.reconfigure(encoding='utf-8')
sys.path.insert(0, '_trabajo')
import importlib.util
spec = importlib.util.spec_from_file_location('cl', '_trabajo/t02r4_class.py')
P = 'anexos/T02-IAM-identidad-roles-auditoria.md'
raw = open(P, 'rb').read(); assert not raw.startswith(b'\xef\xbb\xbf') and b'\r\n' not in raw
import io, contextlib
_out = sys.stdout
sys.stdout = open(__import__('os').devnull, 'w', encoding='utf-8')
cl = importlib.util.module_from_spec(spec); spec.loader.exec_module(cl)
sys.stdout = _out
occ, defs, alias_set, MODS = cl.occ, cl.defs, cl.alias, cl.MODS
res = json.load(open('_trabajo/t02r4_class.json', encoding='utf-8'))
reg = [c for c, _ in res['reg']]

# --- tratamiento especial ---------------------------------------------------
ALIAS = {  # nombre anterior -> (canónica, usado antes por, fuente)
    'per.adherentes.crear': ('soc.adherentes.gestionar', 'M01 (PAN-PER-10, §4)', 'HUECO-TRV-01'),
    'com.communications.emitir': ('com.communications.emit', 'T09 §4 (cuenta técnica S-SYS)', 'API-COM-75'),
    'tec.factibilidades.ver': ('tec.factibilidad.ver', 'M10 §4, T03 SM-ADM-102', 'PA-TEC-21'),
    'tec.factibilidades.crear': ('tec.factibilidad.crear', 'M10 §4', 'PA-TEC-21'),
    'tec.factibilidades.editar': ('tec.factibilidad.editar', 'M10 §4', 'PA-TEC-21'),
    'tec.factibilidades.aprobar': ('tec.factibilidad.evaluar', 'M10 §4', 'PA-TEC-21'),
    'tec.factibilidades.anular': ('tec.factibilidad.cancelar', 'M10 §4', 'PA-TEC-21'),
}
NC = {  # nombre usado -> (canónica propuesta, motivo, registrar_canonica)
    'cob.cajas.ver': ('cob.caja.ver', 'Duplica una capability existente (M07 registra `cob.caja.*` en singular)', False),
    'cob.caja.donacion': ('cob.caja.egresar', 'Recurso como acción; la donación ya es un egreso manual de `cob.caja.egresar`', False),
    'cob.saldo.consultar': ('cob.cuentaCorriente.ver', 'Duplica una capability existente (lectura delegada del bot, M09 §4)', False),
    'fac.comprobante.segundaVia': ('fac.comprobantes.reimprimir', 'Recurso en singular y acción sustantivada; duplica una capability existente', False),
    'fac.notasCredito.crear': ('fac.notasCredito.emitir', 'Sinónimo de una capability existente', False),
    'crm.encuesta.responder': ('crm.encuestas.responder', 'Recurso en singular (convención: plural)', True),
    'per.api.cuentas.ver': ('per.cuentas.ver', 'Prefijo de canal (`api`) en el recurso; el canal externo se declara con la marca X', False),
    'per.api.titulares.ver': ('per.titulares.ver', 'Prefijo de canal (`api`) en el recurso; el canal externo se declara con la marca X', False),
    'tec.campo.enCamino': ('tec.campo.marcarEnCamino', 'Acción sustantivada (no es verbo)', True),
    'tec.campo.conformidad': ('tec.campo.registrarConformidad', 'Acción sustantivada (no es verbo)', True),
    'tec.campo.materiales': ('tec.campo.registrarMateriales', 'Acción sustantivada (no es verbo)', True),
    'tec.campo.crearOt': ('tec.campo.crearOrden', 'Abreviatura `Ot`; M10 usa `tec.ordenes.*` como vocabulario canónico', True),
    'tec.perfilTecnico.secretos': ('tec.perfilTecnico.verSecretos', 'Acción sustantivada (no es verbo)', True),
    'mor.bloqueos.masivos': ('mor.bloqueos.aplicarMasivo', 'Acción sustantivada (no es verbo)', True),
    'soc.vivienda.cobranza': ('soc.vivienda.gestionarCobranza', 'Acción sustantivada (no es verbo)', True),
    'cat.contratos.transicionSistema': ('cat.contratos.transicionar', 'Acción sustantivada; el actor (sistema) no forma parte del nombre', True),
    'sue.portal.datos.proponerCambio': ('sue.portal.datos.editar', 'Sinónimo: API-SUE-81 usa `sue.portal.datos.editar` para la propuesta de cambio', False),
}
COMODIN = {  # comodín -> (explicitación, anexos, fuente)
    'cmp.cotizaciones.*': ('`cmp.cotizaciones.ver`, `.crear`, `.editar`, `.evaluar` (registradas en 4.4.2)', 'M12', 'M12 §4 (Comprador), API-CMP-030 a API-CMP-034'),
    'sue.rrhh.objetivos.*': ('`sue.rrhh.objetivos.ver`, `.editar` (registradas en 4.4.2)', 'M16', 'API-SUE-70'),
    'sue.rrhh.sumarios.*': ('`sue.rrhh.sumarios.ver`, `.editar` (registradas en 4.4.2)', 'M16', 'API-SUE-71'),
    'tec.telefonia.lineas.*': ('`tec.telefonia.lineas.ver`, `.editar`', 'M10', 'M10 §4, API-TEC-38'),
    'tec.telefonia.numeracion.*': ('`tec.telefonia.numeracion.ver`, `.editar`, `.configurar`', 'M10', 'M10 §4, API-TEC-38, PAN-TEC-43'),
    'tec.telefonia.redFisica.*': ('`tec.telefonia.redFisica.ver`, `.editar`', 'M10', 'M10 §4, API-TEC-38'),
}
UPD443 = {  # filas existentes de 4.4.3: comodín -> explicitación
    'stk.fabricacion.estructuras.*': '`stk.fabricacion.estructuras.ver`, `.editar` (M13 §4 ya lo explicitó)',
    'stk.fabricacion.ordenes.*': '`stk.fabricacion.ordenes.ver`, `.editar`, `.crear`, `.lanzar`, `.finalizar`, `.cancelar`, `.anular` (registradas en 4.4.2; M13 §4)',
    'stk.fabricacion.partes.*': '`stk.fabricacion.partes.ver`, `.crear`, `.lanzar`, `.finalizar` (M13 §4 ya lo explicitó)',
    'sue.portal.datos.*': '`sue.portal.datos.ver`, `.editar` (registrada en 4.4.2), `sue.portal.documentos.subir` (M16 API-SUE-81)',
    'sue.rrhh.accidentes.*': '`sue.rrhh.accidentes.ver`, `.editar` (registrada en 4.4.2; M16 API-SUE-72)',
    'sue.rrhh.evaluaciones.*': '`sue.rrhh.evaluaciones.ver`, `.editar`, `.evaluar` (registradas en 4.4.2; M16 API-SUE-70 y §4)',
    'sue.rrhh.juicios.*': '`sue.rrhh.juicios.ver`, `.editar` (registrada en 4.4.2; M16 API-SUE-73)',
    'sue.rrhh.sanciones.*': '`sue.rrhh.sanciones.ver`, `.editar` (registrada en 4.4.2; M16 API-SUE-71)',
    'tec.phone.*': '`tec.telefonia.lineas.ver`, `.editar`; `tec.telefonia.numeracion.ver`, `.editar`, `.configurar`; `tec.telefonia.redFisica.ver`, `.editar`',
}
ERRORES = {'pla.soporte.accesoDatos'}  # T01 la nombra para decir que no existe

DESC = {
    'stk.fabricacion.ordenes.crear': ('Crear orden de fabricación (productos, componentes y plazos)', None),
    'stk.fabricacion.ordenes.lanzar': ('Lanzar orden de fabricación: reserva y retiro de componentes', None),
    'stk.fabricacion.ordenes.finalizar': ('Finalizar orden de fabricación e ingresar el producto terminado', None),
    'stk.fabricacion.ordenes.cancelar': ('Cancelar orden de fabricación no iniciada', None),
    'stk.fabricacion.ordenes.anular': ('Anular orden de fabricación con reversión de movimientos', None),
    'sue.rrhh.accidentes.editar': ('Denunciar accidentes de trabajo, vincular licencia, registrar reintegro y alta (ART)', 'S'),
    'sue.rrhh.evaluaciones.editar': ('Plantillas, ciclos y evaluaciones de desempeño (crear ciclo, cerrar, calibrar)', 'S'),
    'sue.rrhh.evaluaciones.evaluar': ('Evaluar a los operarios a cargo (primera instancia, `supervisionLinks`)', None),
    'sue.rrhh.juicios.editar': ('Registrar juicios laborales, actualizar provisión y vincular expediente de M08', 'S'),
    'sue.rrhh.objetivos.ver': ('Ver objetivos de desempeño', None),
    'sue.rrhh.objetivos.editar': ('Crear y editar objetivos de desempeño (RRHH; encargado sobre operarios a cargo)', None),
    'sue.rrhh.sanciones.editar': ('Registrar y notificar sanciones disciplinarias', 'S'),
    'sue.rrhh.sumarios.ver': ('Ver sumarios administrativos', 'S'),
    'sue.rrhh.sumarios.editar': ('Abrir, instruir y resolver sumarios administrativos', 'S'),
    'sue.portal.datos.editar': ('Proponer cambio de mis datos personales desde la PWA del empleado (queda pendiente de aprobación de RRHH)', None),
    'sue.portal.recibos.firmar': ('Firmar (conformar) mis recibos de sueldo', None),
    'tec.telefonia.cdr.importar': ('Importar lotes de CDR de la central telefónica', None),
    'tec.telefonia.cdr.asignar': ('Asignar CDR sin línea identificada a una línea o contrato', None),
    'tec.telefonia.cdr.revertir': ('Revertir la importación o asignación de un lote de CDR', 'S D'),
    'tec.ext.cdr.importar': ('Importación de CDR por integración (token de T06)', None),
}
ROLES = {
    'sue.rrhh.evaluaciones.evaluar': 'T-RRHH; encargado (supervisor) sobre operarios a cargo',
    'sue.rrhh.objetivos.editar': 'T-RRHH; encargado (supervisor) sobre operarios a cargo',
    'sue.rrhh.juicios.editar': 'T-RRHH (incluye asesor legal)',
    'sue.rrhh.sumarios.ver': 'T-ADM, T-GER, T-RRHH (incluye asesor legal), T-SIN',
    'sue.portal.datos.editar': 'C-EMP', 'sue.portal.recibos.firmar': 'C-EMP',
    'tec.ext.cdr.importar': 'S-SYS',
    'wfl.documentos.verSensibles': 'T-ADM, T-GER, T-SIN (y los roles con permiso sensible del tipo documental)',
    'soc.datosSensibles.ver': 'T-SOC (operador de salud / traslados), T-GER',
    'per.privacidad.ver': 'T-ADM, T-SIN',
    'tec.perfilTecnico.verSecretos': 'T-STE (operador NOC)',
    'tec.telefonia.cdr.importar': 'T-STE, T-TEC (P)', 'tec.telefonia.cdr.asignar': 'T-STE, T-TEC (P)', 'tec.telefonia.cdr.revertir': 'T-STE',
}
DESC.update({
    'tec.aprovisionamiento.marcarManual': ('Marcar como resuelta manualmente una operación de aprovisionamiento', None),
    'tec.campo.cerrarCuadrilla': ('Cerrar las tareas de campo de la cuadrilla (líder de cuadrilla)', None),
    'tec.perfilTecnico.verSecretos': ('Ver secretos del perfil técnico de red, con auditoría', 'S'),
    'bia.ia.configurar': ('Habilitar IA, preguntas de catálogo y límites (T10 §4)', 'S'),
    'wfl.aprobaciones.administrar': ('Reasignar o cancelar aprobaciones ajenas y crear delegaciones por otros (T11 §4)', 'S'),
    'wfl.documentos.verSensibles': ('Ver documentos de sensibilidad `restricted` o `health`; acceso siempre auditado (T11 §4, RN-WFL-073)', 'S'),
    'mor.interrupciones.aprobarSensible': ('Aprobar interrupciones en casos sensibles; rol «Supervisor de mora» de M08 §4', None),
})
ACT = {'ver': 'Ver', 'crear': 'Crear', 'editar': 'Editar', 'aprobar': 'Aprobar', 'anular': 'Anular', 'exportar': 'Exportar',
       'configurar': 'Configurar', 'rechazar': 'Rechazar', 'revertir': 'Revertir', 'reabrir': 'Reabrir', 'cerrar': 'Cerrar',
       'registrar': 'Registrar', 'solicitar': 'Solicitar', 'ejecutar': 'Ejecutar', 'publicar': 'Publicar', 'procesar': 'Procesar',
       'generar': 'Generar', 'descargar': 'Descargar', 'derivar': 'Derivar', 'finalizar': 'Finalizar', 'usar': 'Usar',
       'responder': 'Responder', 'adjuntar': 'Adjuntar', 'devolver': 'Devolver', 'consultar': 'Consultar', 'calcular': 'Calcular',
       'emitir': 'Emitir', 'pagar': 'Pagar', 'retirar': 'Retirar', 'observar': 'Observar', 'aceptar': 'Aceptar', 'depositar': 'Depositar',
       'revocar': 'Revocar', 'promover': 'Promover', 'validar': 'Validar', 'confirmar': 'Confirmar', 'reintentar': 'Reintentar',
       'proponer': 'Proponer', 'resetear': 'Resetear', 'cambiar': 'Cambiar', 'excepcionar': 'Excepcionar', 'refinanciar': 'Refinanciar',
       'rehabilitar': 'Rehabilitar', 'diagnosticar': 'Diagnosticar', 'descartar': 'Descartar', 'reservar': 'Reservar',
       'reprogramar': 'Reprogramar', 'cancelar': 'Cancelar', 'forzar': 'Forzar', 'leerOrigen': 'Leer el tenant de origen de',
       'enviarAprobacion': 'Enviar a aprobación', 'verDetalle': 'Ver detalle de', 'verSensibles': 'Ver datos sensibles de',
       'administrar': 'Administrar', 'cobrarParcial': 'Cobro parcial en', 'cambiarRecargo': 'Cambiar recargo en',
       'desmarcarNota': 'Desmarcar nota en', 'cobrarBloqueado': 'Cobrar documento bloqueado en', 'forzarAdvertencia': 'Forzar advertencia en',
       'procesarRespuesta': 'Procesar respuesta de', 'configurarFiscal': 'Configurar datos fiscales de', 'cerrarCuadrilla': 'Cerrar (líder de cuadrilla)',
       'marcarManual': 'Marcar como resuelto manualmente', 'aprobarRecupero': 'Aprobar recupero de', 'aprobarSensible': 'Aprobar (caso sensible)',
       'registrarAvance': 'Registrar avance de', 'marcarEnCamino': 'Marcar "en camino" en', 'registrarConformidad': 'Registrar conformidad del cliente en',
       'registrarMateriales': 'Registrar materiales usados en', 'crearOrden': 'Crear OT desde', 'verSecretos': 'Ver secretos (auditado) de',
       'aplicarMasivo': 'Aplicar en forma masiva', 'gestionarCobranza': 'Gestionar cobranza de', 'transicionar': 'Transición automática de estado de',
       'evaluar': 'Evaluar', 'importar': 'Importar', 'asignar': 'Asignar', 'firmar': 'Firmar', 'masivos': 'Masivos'}
ACC = {'auditoria': 'auditoría', 'facturacion': 'facturación', 'saas': 'SaaS', 'restauracion': 'restauración', 'regimenes': 'regímenes',
       'perdidas': 'pérdidas', 'depositos': 'depósitos', 'valorizacion': 'valorización', 'importacion': 'importación',
       'migracion': 'migración', 'recepcion': 'recepción', 'publica': 'pública', 'medicion': 'medición', 'retencion': 'retención',
       'parametros': 'parámetros', 'categorias': 'categorías', 'garantias': 'garantías', 'indices': 'índices', 'gestion': 'gestión',
       'prescripcion': 'prescripción', 'rapida': 'rápida', 'rapidas': 'rápidas', 'tecnico': 'técnico', 'padron': 'padrón',
       'sla': 'SLA', 'gis': 'GIS', 'gd': 'generación distribuida', 'ia': 'IA', 'metricas': 'métricas', 'arca': 'ARCA',
       'prestacion': 'prestación', 'geo': 'maestros geográficos', 'refacturacion': 'refacturación', 'historia': 'historial'}
PHR = {'bienes uso': 'bienes de uso', 'archivos pago': 'archivos de pago', 'cajas pago': 'cajas de pago', 'cierre caja': 'cierre de caja',
       'certificados retención': 'certificados de retención', 'solicitudes derechos': 'solicitudes de derechos',
       'reglas auto': 'reglas automáticas', 'conexiones red': 'conexiones de red', 'equipos red': 'equipos de red',
       'tablas sueldos': 'tablas de sueldos', 'puntos prestación': 'puntos de prestación', 'cuentas': 'cuentas'}
def words(s):
    segs = s.split('.')
    out = []
    for sg in reversed(segs):
        w = ' '.join(ACC.get(x, x) for x in re.sub(r'([a-z])([A-Z])', r'\1 \2', sg).lower().split())
        for a, b in PHR.items(): w = re.sub(r'\b' + a + r'\b', b, w)
        out.append(w)
    return ' de '.join(out)
def fuente(o):
    ids = []
    for x in o:
        if x[1] in ('API', 'PAN', 'SM') and x[2] not in ids: ids.append(x[2])
    if not ids:
        return ', '.join(sorted({x[0] + ' §4' for x in o}))
    return ', '.join(ids[:3]) + (f' (+{len(ids) - 3})' if len(ids) > 3 else '')
def hint_roles(rolname):
    r = rolname.lower()
    if 'empleado (pwa)' in r: return ['C-EMP'], 'self'
    if 'socio' in r and ('pwa' in r or 'portal' in r or 'landing' in r): return ['C-SOC', 'C-REP (según relación)'], 'rel'
    if 'bot' in r: return ['S-BOT'], None
    if 'cliente de api' in r: return ['S-API'], None
    if 'agente local' in r: return ['S-AGT'], None
    if re.search(r'worker|proceso del sistema|cuenta de servicio|proceso de integración|sistema \(', r): return ['S-SYS'], None
    if 'administrador de cooperativa' in r: return ['T-ADM'], 'tenant'
    if 'soporte de plataforma' in r: return ['P-SOP2 (acceso temporal)'], 'tenant'
    if 'seguridad / auditor de plataforma' in r: return ['P-SUP', 'P-SEC'], 'global'
    if 'finanzas de plataforma' in r or 'aprobador comercial / dirección' in r: return ['P-SUP', 'P-COM'], 'global'
    if 'plataforma' in r: return ['P-SUP', 'P-ADM'], 'global'
    return None, None
def row_for(c, src=None, canon_of=None):
    o = occ[src or c]
    mod, act = c.split('.')[0], c.rsplit('.', 1)[1]
    res_ = '.'.join(c.split('.')[1:-1])
    s4 = [x for x in o if x[1] == 'S4']
    rolname = s4[0][2] if s4 and not s4[0][2].startswith('`') else ''
    roles, k = cl.roles_for(mod, act, [])
    if res_ == 'auditoria' and act == 'ver': roles = 'T-ADM, T-SIN'
    scope = MODS[mod][1]
    hr, hs = hint_roles(rolname)
    if hr: roles = ', '.join(hr); scope = hs or scope
    elif mod == 'pla': roles = 'P-SUP, P-ADM'; scope = 'global'
    roles = ROLES.get(c, roles)
    if c in ROLES and ROLES[c].startswith('C-'): scope = 'self'
    mark = cl.MARK[k]
    if 'S-API' in roles: mark = 'X' if mark == '—' else mark + ' X'
    if re.search(r'[Ss]ensible|[Ss]ecretos|auditoria', c) and 'S' not in mark: mark = 'S' if mark == '—' else 'S ' + mark
    if c in DESC:
        d, m = DESC[c]; mark = m or mark
    else:
        api = next((x for x in o if x[1] in ('API', 'PAN') and x[3] and not re.match(r'^(Sí|—|-|O\d+)', x[3])), None)
        base = f"{ACT.get(act, act[0].upper() + words(act)[1:])} {words(res_)}".strip()
        d = base + (f" ({api[3].rstrip('.')})" if api and len(api[3]) < 90 else '')
        if rolname: d += f"; rol «{rolname}» de {MODS[mod][0] if s4[0][0] == MODS[mod][0] else s4[0][0]} §4"
    if canon_of: d = f'Canónica propuesta para {canon_of}. ' + d
    d = d.replace('|', '\\|')
    return f"| `{c}` | {d} | {mark} | {roles} | {scope} | {fuente(o)} |", MODS[mod][0]

skip = set(ALIAS) | set(NC) | ERRORES
new_rows = {}
for c in reg:
    if c in skip or c in defs: continue
    r, an = row_for(c); new_rows[c] = (r, an)
for old, (canon, _, doit) in NC.items():
    if doit:
        assert canon not in defs, canon
        r, an = row_for(canon, src=old, canon_of=old); new_rows[canon] = (r, an)
for c in ['sue.rrhh.objetivos.ver', 'sue.rrhh.objetivos.editar', 'sue.rrhh.sumarios.editar', 'sue.portal.datos.editar']:
    assert c in new_rows, c
for c, (canon, _, _) in ALIAS.items(): assert canon in defs, canon
for c, (canon, _, doit) in NC.items(): assert doit or canon in defs or canon in new_rows, canon

t = raw.decode('utf-8')
L = t.split('\n')
def sec_range(an):
    i = next(k for k, l in enumerate(L) if l.startswith('##### ' + an + ' '))
    j = i + 1
    while not (L[j].startswith('| Capability |')): j += 1
    j += 2; s = j
    while L[j].startswith('| `'): j += 1
    return s, j
by_an = {}
for c, (r, an) in new_rows.items(): by_an.setdefault(an, []).append((c, r))
for an, rows in by_an.items():
    s, e = sec_range(an)
    block = L[s:e] + [r for _, r in rows]
    names = [re.match(r'\| `([^`]+)`', x).group(1) for x in block]
    assert len(names) == len(set(names)), an
    block = [x for _, x in sorted(zip(names, block))]
    L[s:e] = block
# alias 4.4.1 (al final de la tabla)
i = L.index('#### 4.4.2 Capabilities registradas por los anexos (mínimo obligatorio ampliado)')
j = i - 1
while not L[j].startswith('| `'): j -= 1
L[j + 1:j + 1] = [f"| `{o}` | `{c}` | Total | {u} | {f} |" for o, (c, u, f) in ALIAS.items()]
# 4.4.3
k3 = L.index('#### 4.4.3 Nombres fuera de convención o sinónimos (canónica propuesta)')
for wc, exp in UPD443.items():
    idx = [n for n in range(k3, len(L)) if re.match(r'\| [^|]+ \| `' + re.escape(wc) + r'` \|', L[n])]
    assert len(idx) == 1, wc
    cells = L[idx[0]].split(' | ')
    assert cells[2].startswith('—') or cells[2].startswith('- ('), (wc, cells[2])
    cells[2] = f'— (explicitar: {exp})'
    L[idx[0]] = ' | '.join(cells)
s = k3
while not L[s].startswith('| Módulo | Nombre usado'): s += 1
s += 2; e = s
while e < len(L) and L[e].startswith('| '): e += 1
add = []
for old, (canon, mot, _) in NC.items():
    o = occ[old]; ans = ', '.join(sorted({x[0] for x in o}))
    add.append(f"| {old.split('.')[0]} | `{old}` | `{canon}` | {mot} | {ans} | {fuente(o)} |")
for wc, (exp, ans, f) in COMODIN.items():
    add.append(f"| {wc.split('.')[0]} | `{wc}` | — (explicitar: {exp}) | Comodín: no es una capability asignable | {ans} | {f} |")
block = L[s:e] + add
keys = [tuple(x.split(' | ')[0:2]) for x in block]
names = [re.search(r'`([^`]+)`', x.split(' | ')[1]).group(1) for x in block]
assert len(names) == len(set(names)), [n for n in names if names.count(n) > 1]
block = [x for _, x in sorted(zip([(x.split(' | ')[0], n) for x, n in zip(block, names)], block))]
L[s:e] = block
out = '\n'.join(L)
open(P, 'wb').write(out.encode('utf-8'))
json.dump(sorted(new_rows), open('_trabajo/t02r4_nuevas.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('nuevas', len(new_rows), 'alias', len(ALIAS), 'nc', len(NC), 'comodines', len(COMODIN), 'upd443', len(UPD443))
for an, rows in sorted(by_an.items()): print(an, len(rows))
