import re, glob, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
files = sorted(glob.glob('anexos/M1[0-9]-*.md'))
PIPE = re.compile(r'(?<!\\)\|')
for f in files:
    raw = open(f, 'rb').read()
    txt = raw.decode('utf-8')
    lines = txt.replace('\r\n', '\n').split('\n')
    i = 0
    while i < len(lines):
        if lines[i].startswith('|') and i + 1 < len(lines) and re.match(r'^\|[\s:|-]+\|\s*$', lines[i + 1]):
            n = len(PIPE.findall(lines[i]))
            j = i + 2
            while j < len(lines) and lines[j].startswith('|'):
                m = len(PIPE.findall(lines[j]))
                if m != n:
                    print(f[7:10], j + 1, 'cols', m, 'vs', n, lines[j][:100])
                j += 1
            i = j
        else:
            i += 1
    # IDs defined (first cell of table rows / headings)
    ids = collections.Counter()
    for l in lines:
        m = re.match(r'^\| ((?:RF|PAN|API|EVT|PA|RN|JOB|PRM|CU|ESC|SIM|CTR|COL)-[A-Z0-9]+(?:-[A-Z0-9]+)*) \|', l)
        if m:
            ids[m.group(1)] += 1
        m = re.match(r'^#{2,4} ((?:PA|CU)-[A-Z0-9]+(?:-[A-Z0-9]+)*)\b', l)
        if m:
            ids['H:' + m.group(1)] += 1
    d = [k for k, v in ids.items() if v > 1]
    if d:
        print(f[7:10], 'IDs duplicados:', d[:30])
    moj = [k for k in ['Ã', 'Â', '\ufffd', 'â€'] if k in txt]
    if moj:
        print(f[7:10], 'posible mojibake', moj)
    if '<!-- SIGUE -->' in txt:
        print(f[7:10], 'SIGUE')
    crlf = txt.count('\r\n'); lf = txt.count('\n')
    print(f[7:10], 'bom', raw[:3] == b'\xef\xbb\xbf', 'crlf', crlf, 'lf', lf)
