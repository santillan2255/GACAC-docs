# Clasifica las capabilities faltantes del barrido (t02r4_scan.py) y arma filas candidatas para T02 §4.4.2.
import re, glob, json, collections, sys
sys.stdout.reconfigure(encoding='utf-8')
MODS = {'pla': ('T01', 'global'), 'iam': ('T02', 'tenant'), 'uxd': ('T03', 'tenant'), 'cfg': ('T04', 'tenant'), 'int': ('T06', 'tenant'),
        'mig': ('T07', 'tenant'), 'nfr': ('T08', 'tenant'), 'com': ('T09', 'tenant'), 'bia': ('T10', 'tenant'), 'wfl': ('T11', 'tenant'),
        'per': ('M01', 'suc'), 'cat': ('M02', 'tenant'), 'med': ('M03', 'zona'), 'tar': ('M04', 'tenant'), 'fac': ('M05', 'tenant'),
        'fis': ('M06', 'tenant'), 'cob': ('M07', 'suc'), 'mor': ('M08', 'suc'), 'crm': ('M09', 'area'), 'tec': ('M10', 'cua'),
        'ven': ('M11', 'suc'), 'cmp': ('M12', 'tenant'), 'stk': ('M13', 'dep'), 'tes': ('M14', 'tenant'), 'con': ('M15', 'tenant'),
        'sue': ('M16', 'tenant'), 'ins': ('M17', 'tenant'), 'soc': ('M18', 'tenant'), 'por': ('M19', 'tenant')}
T2 = open('anexos/T02-IAM-identidad-roles-auditoria.md', encoding='utf-8').read().split('\n')
i441 = T2.index('#### 4.4.1 Alias de capabilities (nombre anterior → canónico)')
i442 = T2.index('#### 4.4.2 Capabilities registradas por los anexos (mínimo obligatorio ampliado)')
i443 = T2.index('#### 4.4.3 Nombres fuera de convención o sinónimos (canónica propuesta)')
i44 = next(i for i, l in enumerate(T2) if l.startswith('### 4.4 '))
i45 = next(i for i, l in enumerate(T2) if l.startswith('### 4.5 '))
defs, alias, non = {}, set(), set()
for i in range(i44, i45):
    l = T2[i]
    if i441 <= i < i442:
        m = re.match(r'\| `([^`]+)` \|', l)
        if m: alias.add(m.group(1))
    elif i >= i443:
        m = re.match(r'\| [^|]+ \| `([^`]+)`', l)
        if m: non.add(m.group(1))
    else:
        m = re.match(r'\| `([^`]+)` \| ([^|]*)\| ([^|]*)\| ([^|]*)\|', l)
        if m: defs[m.group(1)] = (m.group(2).strip(), m.group(3).strip(), m.group(4).strip())

# matriz 4.3
i0 = next(i for i, l in enumerate(T2) if l.startswith('### 4.3'))
hdr, MAT = None, {}
for l in T2[i0:i0 + 45]:
    if l.startswith('| Módulo | T-ADM'):
        hdr = [c.strip() for c in l.strip('|').split('|')]; continue
    if hdr and l.startswith('| ') and not l.startswith('|---'):
        c = [x.strip() for x in l.strip().strip('|').split('|')]
        if len(c) == len(hdr):
            MAT[c[0].split()[0]] = dict(zip(hdr[1:], c[1:]))
ROLE_ORDER = [h for h in (hdr or [])[1:] if h.startswith('T-')]
def levels(cell):
    s = set(re.findall(r'(?<![A-Za-záéíóú])([VOACTPG])(?![a-záéíóú])', cell))
    if 'exp' in cell: s.add('X')
    return s
VER = {'ver', 'consultar', 'listar', 'descargar', 'imprimir', 'buscar', 'previsualizar', 'simular', 'observar', 'diagnosticar'}
APR = {'aprobar', 'anular', 'autorizar', 'revertir', 'rechazar', 'condonar', 'reabrir', 'liberar', 'publicar', 'certificar',
       'refinanciar', 'rehabilitar', 'excepcionar', 'forzar', 'retirar', 'aprobarSensible', 'aprobarRecupero', 'aceptar', 'cerrar'}
def aclass(act):
    if act in VER or act.startswith('ver'): return 'V'
    if act.startswith('exportar'): return 'X'
    if act in ('configurar', 'administrar') or act.startswith('configurar'): return 'C'
    if act in APR or act.startswith('aprobar') or act.startswith('anular'): return 'A'
    return 'O'
MARK = {'V': '—', 'O': '—', 'A': 'S D', 'C': 'S', 'X': 'S'}
def roles_for(mod, act, extra):
    k = aclass(act)
    row = MAT.get(MODS[mod][0], {})
    sel = []
    for r in ROLE_ORDER:
        lv = levels(row.get(r, '—'))
        if not lv: continue
        ok = {'V': lv & set('VOACTP'), 'O': lv & set('OT'), 'A': lv & set('AT'), 'C': lv & set('CT'), 'X': lv & set('TX')}[k]
        if k == 'O' and not ok and 'P' in lv: sel.append(r + ' (P)')
        elif ok: sel.append(r + (' (P)' if lv == {'P'} else ''))
    if not sel: sel = ['T-ADM']
    if k == 'X' and 'T-ADM' not in [s.split()[0] for s in sel]: sel.insert(0, 'T-ADM')
    return ', '.join(sel + extra), k

tok = re.compile(r'`([a-z]{3}(?:\.[A-Za-z0-9]+){2,3}(?:\.\*)?(?:\.\{[A-Za-z0-9,]+\})?(?:/[A-Za-z0-9]+)*)`')
def expand(s):
    m = re.match(r'^(.*)\.\{([^}]+)\}$', s)
    if m: return [m.group(1) + '.' + a for a in m.group(2).split(',')]
    if '/' in s:
        head, *rest = s.split('/'); base = head.rsplit('.', 1)[0]
        return [head] + [base + '.' + r for r in rest]
    return [s]
occ = collections.defaultdict(list)   # cap -> [(anexo, kind, id, desc, route, rol)]
for f in sorted(glob.glob('anexos/*.md')):
    an = f.replace('\\', '/').split('/')[-1].split('-')[0]
    if an == 'T02': continue
    L = open(f, encoding='utf-8').read().split('\n')
    sec = ''
    for l in L:
        if l.startswith('## '): sec = l[3:6]
        kind = 'API' if l.startswith('| API-') else 'PAN' if l.startswith('| PAN-') else 'SM' if l.startswith('| SM-') else ('S4' if sec.startswith('4.') and l.startswith('|') else None)
        if not kind: continue
        cells = [c.strip() for c in re.split(r'(?<!\\)\|', l)[1:-1]]
        for m in tok.finditer(l):
            for c in expand(m.group(1)):
                if c.split('.')[0] not in MODS: continue
                ci = next((j for j, x in enumerate(cells) if m.group(1) in x), None)
                desc = ''
                if kind in ('API', 'PAN') and ci is not None and ci + 1 < len(cells):
                    desc = cells[ci + 1]
                route = next((x for x in cells if x.startswith('`/')), '')
                occ[c].append((an, kind, cells[0], desc, route, cells[0] if kind == 'S4' else ''))

FP_EXACT = {'com.recurso.accion', 'mor.recurso.accion', 'tec.booking.noCapacity', 'tec.feature.disabled', 'tec.workOrder.duplicate',
            'wfl.instances.migrate', 'wfl.sequence.adjust'}
res = collections.defaultdict(list)
for c, oc in sorted(occ.items()):
    if c in defs or c in alias: continue
    ans = sorted({o[0] for o in oc})
    if c in non: res['nc'].append((c, ans)); continue
    if c in FP_EXACT or ans == ['T12'] or '.service.' in c: res['fp'].append((c, ans)); continue
    if c.endswith('.*'): res['comodin'].append((c, ans)); continue
    if ans == ['T03']: res['t03'].append((c, ans)); continue
    res['reg'].append((c, ans))
json.dump({k: v for k, v in res.items()}, open('_trabajo/t02r4_class.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
for k, v in res.items():
    print('==', k, len(v))
    if k != 't03':
        for c, a in v:
            o = occ[c]
            first = next((x for x in o if x[1] in ('API', 'PAN')), o[0])
            print('  ', c, ','.join(a), '|', first[2], '|', first[3][:70])
json.dump({c: occ[c] for c, _ in res['reg']}, open('_trabajo/t02r4_occ.json', 'w', encoding='utf-8'), ensure_ascii=False)
