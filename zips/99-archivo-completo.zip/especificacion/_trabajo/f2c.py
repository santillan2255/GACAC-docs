﻿import re,glob,collections
for f in sorted(glob.glob('anexos/*.md')):
    b=f[7:]
    if not re.match(r'(M11|M14|M16|T01|T02|T04|T08)',b): continue
    s=open(f,encoding='utf-8').read(); L=s.split('\n')
    mx=collections.defaultdict(int)
    for m in re.finditer(r'\b(RF|RN|PRM|PAN|API|EVT|JOB|ESC|CTR|PA|COL|CU|CA|RNF|FI|TPL)-([A-Z]{3})(?:-P\d)?-(\d+)\b',s):
        k=m.group(1)+'-'+m.group(2); mx[k]=max(mx[k],int(m.group(3)))
    print('=====',b,len(L))
    print({k:v for k,v in sorted(mx.items()) if k.split('-')[1] in b[:3] or b.startswith('T04')})
    for i,l in enumerate(L,1):
        if re.match(r'#{2,3} ',l): print(i,l[:90])
