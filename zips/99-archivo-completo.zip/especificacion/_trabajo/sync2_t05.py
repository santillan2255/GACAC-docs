from sync_lib import Doc

S = '5-11-2026, pendientes de la sincronización'


def add_pa_line(d, pa, text):
    t = d.t.split('\n')
    s = [i for i, l in enumerate(t) if l.startswith('### ' + pa)]
    assert len(s) == 1
    j = s[0] + 1
    while j < len(t) and not (t[j].startswith('### ') or t[j].startswith('## ')):
        j += 1
    while t[j - 1].strip() == '':
        j -= 1
    t[j:j] = ['  - ' + text]
    d.t = '\n'.join(t)
    d._k('PA')


d = Doc('T05-*.md')


def keys(rowstart, new, why, col=4, k='catalogo'):
    d.cell(rowstart, col, lambda old: '%s (%s: %s; antes "%s")' % (new, S, why, old.strip()), k)


for r in ('| COL-TAR-03 |', '| COL-TAR-04 |', '| COL-TAR-06 |'):
    d.cell(r, 4, lambda old: '%s, `taxRateIds` (→ `vatRates`, solo IVA), `taxIds` (→ `taxDefinitions`) (%s: M04 §7 separa los dos campos, PA-TAR-21; antes sin ellos)' % (old, S), 'catalogo')
keys('| COL-CON-38 |', '`entityType` + `entityId` (polimórfica: `vatRate` → `vatRates`, `taxDefinition` → `taxDefinitions` (antes `tax`), y las demás entidades de M15 §7), `ledgerAccountId`',
     'M15 §7 admite `vatRate` y `taxDefinition`')
keys('| COL-SOC-48 |', '`vatRateId` (→ `vatRates`, ObjectId obligatorio)',
     'M18 §7 cambia `vatRate` (Enum) por `vatRateId` (PA-SOC-19); el [VERIFICAR] de obligatoriedad de M18 se resuelve como obligatorio: todo combustible liquida IVA con una alícuota')
keys('| COL-SUE-06 |', '`{employeeId, cbuHmac}`', 'sin cambio de clave: M16 §7 declara `cbuHmac` y el índice `{tenantId, employeeId, cbuHmac}` (antes con `cbu`, PA-SUE-18)', col=5, k='unicos')

d.before_line('| Autorreferencias: `parentRunId`',
              ['| `vatRateId` | M18 `fuelTypes` | `vatRates` (COL-FIS-16), ObjectId obligatorio (antes Enum `vatRate` en M18; resuelve el [VERIFICAR] de obligatoriedad de M18) (%s; Asumida DEC-072, PA-DAT-05) | M06 |' % S],
              'destinos')

add_pa_line(d, 'PA-DAT-05', '%s: COL-TAR-03, COL-TAR-04 y COL-TAR-06 suman `taxRateIds` → `vatRates` y `taxIds` → `taxDefinitions` (M04 PA-TAR-21); COL-CON-38 declara `entityType` + `entityId` polimórfica con `vatRate` y `taxDefinition` (antes `tax`; M15); COL-SOC-48 `vatRateId` → `vatRates` como ObjectId obligatorio, que resuelve el [VERIFICAR] de M18 (fila nueva en §7.2.1); COL-SUE-06 conserva `{employeeId, cbuHmac}`, que M16 ya adopta como `{tenantId, employeeId, cbuHmac}`. Totales sin cambio. M18 debe quitar el [VERIFICAR] de `fuelTypes.vatRateId`.' % S)
d.save()

d = Doc('T03-*.md')
add_pa_line(d, 'PA-UXD-19', '%s: se restauran los IDs de pantalla de 38 filas del mapa (10.9.4 a 10.9.12; SM-ADM-004 a SM-PLT-024) que una ronda posterior a la r3 había reemplazado por "otra pantalla (cita en 10.9.13)" o "pantalla relacionada (cita en 10.9.13)", incluso dentro de los "antes" (por ejemplo SM-PWS-027 "antes COM-31", SM-LND-007 "IAM-02, IAM-03, IAM-04"); el texto se toma del respaldo `_trabajo/backup-cierre-T-20261105/T03-antes-r3.md`. Donde esa ronda dejó la principal en "— (sin pantalla propia en esta app …)" (SM-PWS-028, SM-PWC-019, SM-LND-025) se conserva la decisión y se nombra la pantalla relacionada (COM-40, FAC-46, COM-50). Las 5 tablas irregulares (RN-UXD-003, `variants`, `variables[]`, `lastContext`, `ui.accion.crear`) tenían `|` sin escapar dentro de código; se escapan como `\\|` sin cambiar el texto mostrado. El generador del mapa debe leer las referencias a otra app desde 10.9.13 y no contar los IDs citados en "antes".' % S)
d.save()
