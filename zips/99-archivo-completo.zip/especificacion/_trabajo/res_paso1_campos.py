"""Paso 1: rótulo 'Campos de `x`:' reconocible como encabezado de colección cuando el encabezado vigente es de otra colección."""
import re, glob, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from res_lib import Doc, ANX

tot = {}
for p in sorted(glob.glob(os.path.join(ANX, 'M1[2-9]-*.md'))):
    d = Doc(os.path.basename(p))
    L = d.t.split('\n')
    a = next(i for i, l in enumerate(L) if re.match(r'^## 7\.', l))
    b = next(i for i in range(a + 1, len(L)) if re.match(r'^## \d', L[i]))
    cur = []
    k = 0
    for i in range(a, b):
        l = L[i]
        mh = re.match(r'^(#{3,5})\s+(.*)$', l)
        mb = re.match(r'^\*\*`([A-Za-z0-9_]+)`\*\*', l.strip())
        mc = re.match(r'^Campos de `([A-Za-z0-9_]+)`(.*)$', l)
        if mh:
            ns = [n for n in re.findall(r'`([^`]+)`', mh.group(2)) if re.fullmatch(r'[a-zA-Z][A-Za-z0-9_]*', n)]
            if ns:
                cur = ns
        elif mb:
            cur = [mb.group(1)]
        elif mc and (not cur or cur[0] != mc.group(1)):
            L[i] = '**`%s`** — campos%s' % (mc.group(1), mc.group(2))
            cur = [mc.group(1)]
            k += 1
    if k:
        d.t = '\n'.join(L)
        d.n = k
        d.save()
    tot[d.name] = k
print(tot)
