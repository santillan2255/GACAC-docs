﻿from conc_lib import *
cat = json.load(open('cat.json',encoding='utf-8'))
L = read(T11).split('\n')
s = next(i for i,l in enumerate(L) if l.startswith('### 12.4 '))
e = next(i for i,l in enumerate(L) if l.startswith('### 12.5 '))
names = {}
for i in range(s, e):
    l = L[i]
    if not l.startswith('|') or l.startswith('|---'): continue
    c = [x.strip() for x in l.strip().strip('|').split('|')]
    if c[0].startswith('CNC'):
        for n in expand(c[1]): names.setdefault(n, []).append(c[0])
    elif c[0] != 'Nombre usado por el consumidor' and c[0] != 'ID':
        for n in expand(c[0]): names.setdefault(n, []).append('R%d' % (i+1))
print(len(names))
occ = {}
for f in files():
    code = os.path.basename(f).split('-')[0]
    for ln, l in enumerate(read(f).split('\n'), 1):
        if code == 'T11' and s <= ln-1 < e: continue
        for n in set(expand(l)):
            if n in names: occ.setdefault(n, []).append('%s:%d' % (code, ln))
with open('occ.txt','w',encoding='utf-8') as o:
    for n in names:
        o.write('%s [%s] canon=%s -> %s\n' % (n, ','.join(names[n]), n in cat, ' '.join(occ.get(n, []))))
json.dump({'names': names, 'occ': occ}, open('occ.json','w',encoding='utf-8'), indent=0)
