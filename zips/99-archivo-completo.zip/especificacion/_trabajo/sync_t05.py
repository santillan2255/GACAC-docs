from sync_lib import Doc

d = Doc('T05-*.md')
S = '5-11-2026, sincronización'


def keys(rowstart, new, why, col=4, k='catalogo'):
    """Reemplaza la celda conservando el texto anterior como "antes"."""
    def fn(old):
        return '%s (%s: %s; antes "%s")' % (new, S, why, old.strip())
    d.cell(rowstart, col, fn, k)


def uniq(rowstart, new, why):
    keys(rowstart, new, why, col=5, k='unicos')


# ---------------- Catálogo: M07
keys('| COL-COB-11 |', '`cashSessionId`, `receiptIds[]`', 'alineado a M07 §7.37 y a los payloads de EVT-COB-12, 14 y 25')
keys('| COL-COB-13 |', '`cashOperationId`, `thirdPartyCheckId`, `settlementId` (→ `agencySettlements`), `gatewayTransactionId`, `directDebitBatchId`',
     'alineado a M07 §7.37: `transactionId` y `batchId` pasan a `gatewayTransactionId` y `directDebitBatchId`')
keys('| COL-COB-34 |', '`items.obligationId`, `gatewayConnectorId`', 'M07 §7.37 adopta el nombre de T05')
uniq('| COL-COB-34 |', '`intentNo`; `{gatewayConnectorId, externalId}` d.', 'M07 §7.37')

# ---------------- Catálogo: M08
keys('| COL-MOR-02 |', '`serviceId`, `voucherTypeId`, `rates[].categoryIds`',
     'M08 §7.2 y §7.38: `policyId` no existe, la relación es `interestPolicies.lateInterest.rateTableId`')
uniq('| COL-MOR-02 |', '`code`', 'M08 §7.2: la vigencia es por tramo `rates[].from`, sin superposición por RN-MOR-010')
keys('| COL-MOR-13 |', '`scope.serviceId`, `scope.categoryIds`', 'alineado a M08 §7.38')
keys('| COL-MOR-17 |', '`accountId`, `delinquencyBatchId`, `stageId`', 'alineado a M08 §7.38')
keys('| COL-MOR-19 |', '`scope.accountId`, `scope.contractId`', 'alineado a M08 §7.38')
keys('| COL-MOR-20 |', '`scope.contractId`, `personSensitiveDataId`', 'alineado a M08 §7.38, que declara `personSensitiveDataId`')
keys('| COL-MOR-24 |', '`contractId`, `origin.noticeId`, `execution.workOrderId`, `execution.remoteActionIds` (→ `provisioningCommands` de M10, que ejecuta T06)',
     'alineado a M08 §7.38')
keys('| COL-MOR-26 |', '—', 'M08 §7.38: `financialInstitutionId` es de COL-MOR-27 `financingInstitutionPlans`, no de `paymentPlans`')

# ---------------- Catálogo: M09
keys('| COL-CRM-10 |', '`scope.caseSubtypeIds[]`', 'alineado a M09 §7.45')
keys('| COL-CRM-11 |', '`target.areaId`', 'alineado a M09 §7.45')
keys('| COL-CRM-12 |', '`crmCaseId`, `dependsOnCommandId` (autorreferencia)', 'M09 §7.45 no declara `operationId`')
keys('| COL-CRM-16 |', '—', 'M09 §7.45 no declara `documentRequirementTypeIds[]`: los requisitos van en `crmCaseTypes.requirementsTemplate`')
keys('| COL-CRM-19 |', '`crmCaseId`, `userId`', 'M09 §7.45: el proyecto se toma de `crmCases.projectId`')
keys('| COL-CRM-26 |', '`targetType` + `targetId` (polimórfica: `crmCases`, `crmConversations`, `crmMessages`, `storedFiles`), `aiUsageLogId`',
     'M09 §7.45: el caso es `targetType = case` + `targetId`')

# ---------------- Catálogo: M10
keys('| COL-TEC-12 |', '`contractId`, `crmCaseId`, `assignment.crewId`', 'alineado a M10 §7.23')
keys('| COL-TEC-20 |', '`resourceType` + `resourceId` (`crews` o `fieldResources`)',
     'M10 §7.23: `calendarId` no existe, las excepciones van en `exceptions[]`')
keys('| COL-TEC-21 |', '`slotKey`, `targetRef.workOrderId`', 'alineado a M10 §7.23')
keys('| COL-TEC-22 |', '`workOrderId`, `assignedCrewId`, `assignedResourceIds[]`', 'alineado a M10 §7.23')
keys('| COL-TEC-28 |', '`userId`', 'alineado a M10 §7.23')
keys('| COL-TEC-42 |', '`connectorId`, `credentialRef`', 'alineado a M10 §7.23 (→ `integrationConnections`)')

# ---------------- Catálogo: M03, M12, M14, M17
keys('| COL-MED-17 |', '`readerId` (→ `memberships`)', 'M03 PA-MED-15: el lecturista es usuario de la app de campo')
keys('| COL-CMP-22 |', '`supplierId`, `packageIds[]` (→ `servicePlans`, M02)', 'M12 §7.13.21, PA-CMP-16')
d.rep('`declarationStoredFileId` (en M12 `declarationFileId`, §7.2)',
      '`declarationStoredFileId` (%s: M12 §7.13.22 ya usa este nombre; antes "(en M12 `declarationFileId`, §7.2)")' % S, 'catalogo')
uniq('| COL-TES-13 |', '`storedFileId` p. (el duplicado se controla por el `sha256` de `storedFiles`, T01, antes del alta)', 'M14 PA-TES-19')
keys('| COL-TES-42 |', '`payrollRunId`, `originTreasuryAccountId`', 'M14 §7 adopta los nombres de T05')
uniq('| COL-TES-42 |', '`payrollRunId`', 'M14 PA-TES-19')
keys('| COL-INS-01 |', '`personId`, `electoralDistrictId`, `inaesCategoryId`, `reentryOfAssociateMembershipId` (autorreferencia)', 'M17 §7.1, PA-INS-13')

# ---------------- Catálogo: T02, T07, T10
keys('| COL-IAM-08 |', '`membershipId`, `screenProfileId`', 'T02 §7 adopta el nombre canónico de T05')
uniq('| COL-IAM-13 |', '`refreshFamilyId`', 'T02 §7 adopta el nombre canónico de T05')
keys('| COL-MIG-01 |', '`acceptanceActId` (→ `documents`, T11)', 'T07 §7, PA-MIG-20')
keys('| COL-MIG-11 |', '`batchId`, `ruleId` (→ `migrationMappingRules`)', 'T07 §7.26 (Asumida DEC-072, PA-DAT-05): la referencia conserva `ruleId`; `ruleCode` es la clave natural de la regla')
keys('| COL-MIG-13 |', '`projectId`, `goodappsBatchId` (→ `billingRuns`, M05)', 'T07 §7')
keys('| COL-BIA-12 |', '`indicatorId` (→ `indicatorDefinitions`), `indicatorCode` (código desnormalizado), `scenarioId` (→ `simulationScenarios`, M15)',
     'T10 §7.26 declara `indicatorId` obligatorio y `scenarioId` (PA-DAT-05)')
keys('| COL-BIA-15 |', '`indicatorId` (→ `indicatorDefinitions`), `indicatorCode` (código desnormalizado)',
     'T10 §7.26 declara `indicatorId` obligatorio (PA-DAT-05)')
keys('| COL-BIA-16 |', '`kpiAlertRuleId` (→ `kpiAlertRules`)', 'T10 §7.26 adopta el nombre canónico de T05; el texto del §7.13 dice `ruleId` (PA-DAT-05)')
uniq('| COL-BIA-23 |', '`{apiClientId, date, route, status}`', 'T10 §7.20 es dueño y usa `date` (PA-DAT-05)')

# ---------------- §7.2.1: notas en filas existentes
def note(rowstart, col, txt, k='destinos'):
    d.cell(rowstart, col, lambda c: '%s (%s: %s)' % (c, S, txt), k)

note('| `taxId` | M05, M08, M12, T09 |', 1, 'incluye M08 `debtCollectionAgencies.taxId`, que deja de ser ObjectId')
note('| `connectionId`, `connectorId`, `providerConnectionId` |', 1, 'incluye M10 `provisioningSystems.connectorId`')
note('| `reasonId` | M01 `blocks`, M08 `documentHolds` |', 2, 'M08 ya usa `holdReasonId`')
note('| `sourceAccountId`, `originAccountId` |', 2, 'M14 ya usa `originTreasuryAccountId` en `payrollPaymentBatches`')
note('| `taxRateIds` |', 2, 'M04 ya separa `taxRateIds` y `taxIds`, PA-TAR-21')
note('| `taxIds` | M07 `collectionReportSchemes`, M08 `interestPolicies` |', 1,
     'agrega M04 `tariffCategoryRates`, `tariffRows` y `productPrices`, y M08 `interestPolicies.base.excludedTaxIds`')
note('| `memberId` |', 2, 'M05 `billingRunItems` e `invoices.customer` y M09 ya usan `associateMembershipId`')
note('| `pendingChargeId` |', 2, 'M08 ya usa `billableItemId`')
note('| `paymentOrderRef` |', 1, 'agrega M17 `surplusAllocations` e `institutionalFeeSettlements`')

# ---------------- §7.2.1: filas nuevas
P = '(%s; Asumida DEC-072, PA-DAT-05)' % S
rows = [
    # no es referencia
    '| `closeGroupId`, `externalQrId`, `externalPaymentId` | M07 `cashSessions`, `staticQrCodes`, `gatewayTransactions` | No es referencia: correlación del cierre múltiple (UUID) e identificadores del proveedor (string) %s | M07 |' % P,
    '| `planSnapshot`, `noticeModelVersion`, `policyVersion`, `rates[].rateId`, `adminFee.*` | M08 `agreements`, `delinquencyNotices`, `interestCalculations`, `interestRateTables`, `interestPolicies` | No es referencia: copia del plan, números de versión, identificador del tramo y datos del cargo administrativo %s | M08 |' % P,
    '| `externalThreadId`, `targetType` | M09 `crmConversations`, `crmAiSuggestions` | No es referencia: identificador externo del hilo y discriminador de `targetId` %s | M09 |' % P,
    '| `prospect`, `cancelReason`, `entityType`, `casPackageIds`, `deviceId` | M10 `feasibilityRequests`, `fieldEvidence`, `provisioningProfiles`, `fieldDevices` | No es referencia: datos del interesado, motivo, discriminador de `entityId`, códigos del CAS externo y UUID del dispositivo (clave de COL-TEC-28; M10 lo apuntaba a `networkDevices` por error) %s | M10 |' % P,
    '| `sourceType`, `originType`, `quoteVersion`, `installmentType`, `discountAmount`, `discountReason` | M11 `operationCharges`, `salesInstallments`, `salesQuoteAcceptances` | No es referencia: discriminadores de `sourceId` y `originId` (polimórficas), número de versión, código `TIPO_FAC` y datos del descuento %s | M11 |' % P,
    '| `vendorTransactionId` | M03 `prepaidTopUps` | No es referencia: identificador del proveedor de prepago %s | M03 |' % P,
    '| `levyEventId` | M04 `worksInstallmentPlans` | No es referencia: `eventId` del sobre del evento que origina el gravamen (M04 PA-TAR-21) %s | M04 |' % P,
    '| `arcaVatId` | M06 `vatRates` | No es referencia: código ARCA de la alícuota (entero; antes ObjectId) %s | M06 |' % P,
    '| `promptTemplateCode` | T02 `auditAi` | No es referencia: plantilla de prompt versionada en código (antes `promptTemplateId`) %s | T02 |' % P,
    '| `catalogQuestionCode` | T10 `aiQuestions` | No es referencia: código del catálogo de preguntas de la sala (antes `catalogQuestionId`) %s | T10 |' % P,
    '| `externalTransactionNumber` | T06 `integrationFileExchanges` | No es referencia: número de transacción del ente (antes `externalTransactionId`) %s | T06 |' % P,
    '| `ruleCode` | T07 `migrationMappingRules` | No es referencia: clave natural de la regla (antes `ruleId` en esa colección) %s | T07 |' % P,
    '| `jobId` | M02 `bulkContractOperations`, M04 `calculationRuns`, M05 `massOperations` | Identificador del job BullMQ registrado en `jobRuns.jobId` (COL-PLA-27): string, no ObjectId %s | T01 |' % P,
    '| `documentRef`, `receiptRef` | M17 `capitalReserves`, `capitalRefunds` | No es referencia: número del comprobante o del recibo; `documentRef.typeId` → `voucherTypes` (M05) %s | M17 |' % P,
    # destinos
    '| `deviceIds` | M07 `collectors` | `fieldDevices` (COL-TEC-28) %s | M10 |' % P,
    '| `surchargeProductId`, `productIds`, `requiresProductIds`, `excludesProductIds`, `catalogProductId` | M07 `cardPlans`, `collectionReportSchemes`; M02 `serviceProducts` (autorreferencia); M13 `inventoryItems` | `serviceProducts` (COL-CAT-05) %s | M02 |' % P,
    '| `billingTypeId` | M07 `thirdPartyBillers` | `voucherTypes`; canónico `voucherTypeId` %s | M05 |' % P,
    '| `premiseAddressId` | M11 `salesQuotes` | `addresses` (COL-PER-06) %s | M01 |' % P,
    '| `creditNoteRequestId` | M11 `salesReturns` | `invoiceAnnulmentRequests` (COL-FAC-17) %s | M05 |' % P,
    '| `freightSettlementId` | M11 `salesDeliveries` | `tripSettlements` (COL-SOC-50) %s | M18 |' % P,
    '| `discountApprovalId`, `chargeProposalId` | M11 `operationCharges`; M02 `contractEquipmentAssignments` (M13 §7.17) | `approvalRequests` (COL-WFL-24) %s | T11 |' % P,
    '| `declaredAffidavitRef`, `documents`, `acceptanceActId` | M02 `serviceContracts`; M03 `meters`, `distributedGenerationContracts`; T07 `migrationProjects` | `documents` (expediente T11) %s | T11 |' % P,
    '| `feasibilityRef` | M02 `serviceContracts` | `feasibilityRequests` (COL-TEC-01) %s | M10 |' % P,
    '| `defaultReaderIds`, `readerId`, `assigneeId` | M03 `readingRoutes`, `readerWorkSessions`; M05 `billingExceptions` | `memberships` (COL-IAM-04) %s | T02 |' % P,
    '| `ownerRole` | M05 `billingExceptions` | `roles` (T02) por clave del rol, no ObjectId %s | T02 |' % P,
    '| `photoIds` | M03 `meterReadings` | `storedFiles` %s | T01 |' % P,
    '| `reading.routeIds` | M03 `meteringPoints` | `readingRoutes` (COL-MED-13) %s | M03 |' % P,
    '| `serviceBlockId`, `affectedServiceBlockIds` | M05 `billedPeriods`, `invoiceRelations` | Subdocumento `invoices.serviceBlocks` (COL-FAC-13): identificador del bloque dentro de la factura, no ObjectId de colección %s | M05 |' % P,
    '| `paymentOrderId`, `supplierId`, `withholdingTypeId`, `filingId`, `obligationId` | M06 `withholdingsApplied` (`filingId` también en `fiscalDeadlines`) | `paymentOrders` (M12), `suppliers` (M12), `withholdingTypes`, `regimeFilings` y `taxObligations` (M06); en esta colección `obligationId` es la obligación fiscal, no `obligations` de M07 %s | M06 |' % P,
    '| `perceptionTaxId` | M06 `vatRateMatrix` | `taxDefinitions` (COL-FIS-18) %s | M06 |' % P,
    '| `entityId` | M15 `entityAccountAssignments` | Polimórfica según `entityType`, que admite `vatRate` y `taxDefinition` (antes `tax`) %s | M15 |' % P,
    '| `goodappsBatchId` | T07 `parallelRuns` | `billingRuns` (M05) %s | M05 |' % P,
    '| `ruleId` | T07 `migrationIssues` | `migrationMappingRules` (COL-MIG-04) %s | T07 |' % P,
    '| `scenarioId` | T10 `indicatorSnapshots` | `simulationScenarios` (COL-CON-22) %s | M15 |' % P,
    '| `indicatorId` | T10 `indicatorSnapshots`, `kpiAlertRules` | `indicatorDefinitions` (COL-BIA-11); `indicatorCode` se conserva como código desnormalizado %s | T10 |' % P,
    '| `reentryOfAssociateMembershipId` | M17 `associateMemberships` | `associateMemberships` (autorreferencia; antes `reentryOfMembershipId`) %s | M17 |' % P,
    '| `productGroupIds` | M17 `capitalItems` | `accountRubrics` (COL-CON-03) %s | M15 |' % P,
    '| `creditRef` | M17 `surplusAllocations` | `creditBalances` (COL-COB-06) %s | M07 |' % P,
    '| `withholdingRef` | M17 `institutionalFeeSettlements` | `withholdingsApplied` (COL-FIS-28) %s | M06 |' % P,
    '| `savedFilterSetId` | M17 `rosters` | `dataTableViews` (COL-UXD-10) %s | T03 |' % P,
    '| `requisitionId`, `requisitionIds` | M13 `reorderSuggestions`, `mrpRuns` | `supplyRequests` (COL-CMP-07) %s | M12 |' % P,
    '| `purchaseReceiptId` | M13 `lots` | `supplierReceipts` (COL-CMP-11) %s | M12 |' % P,
    '| `invoiceId`, `receiptId` | M12 `matchExceptions`, `aiInvoiceExtractions`, `signalRightsSettlements` | `supplierInvoices` (COL-CMP-12) y `supplierReceipts` (COL-CMP-11), no `invoices` de M05 ni `receipts` de M07 %s | M12 |' % P,
    '| `packageIds`, `lines.packageId` | M12 `signalRightsContracts`, `signalRightsSettlements` | `servicePlans` (M02) %s | M02 |' % P,
]
d.before_line('| Autorreferencias: `parentRunId`', rows, 'destinos_nuevos')

# ---------------- §8.1 estados
st = [
    '| `collectors`, `gatewayConnectors` | COL-COB-18, COL-COB-32 | M07 | `active`, `suspended`, `inactive` | `active` | M07 §8.19 (PA-COB-21) |',
    '| `interestIndexTables` | COL-MOR-03 | M08 | `active`, `inactive` | `active` | M08 §8.15 (PA-MOR-22) |',
    '| `debtCollectionAgencies` | COL-MOR-34 | M08 | `active`, `suspended`, `inactive` | `active` | M08 §8.15 (PA-MOR-22) |',
    '| `regulatoryReportRuns` | COL-FIS-41 | M06 | `draft`, `generated`, `validated`, `validationFailed`, `approved`, `submitted`, `accepted`, `rejected`, `rectified` | `draft` | M06 §8.7 (PA-FIS-22) |',
    '| `revaluations` | COL-STK-23 | M13 | `draft`, `approved`, `posted`, `cancelled` | `draft` | M13 §8.14.3 (PA-STK-11) |',
    '| `serviceReceptions` | COL-STK-33 | M13 | `open`, `closed`, `cancelled` (el avance de cada equipo va en `items[].currentStatusId` → `receptionStatuses`) | `open` | M13 §8.14.4 (PA-STK-11) |',
    '| `signalRightsContracts` | COL-CMP-22 | M12 | `draft`, `active`, `ended` | `draft` | M12 §8.8 (PA-CMP-16) |',
    '| `matchExceptions` | COL-CMP-14 | M12 | `decision`: `pending`, `accepted`, `claimCreditNote`, `rejected` (el estado es `decision`, no `status`) | `pending` | M12 §8.7 (PA-CMP-16) |',
    '| `shifts` | COL-SUE-10 | M16 | `active`, `inactive` | `active` | M16 §8.12.11 (PA-SUE-18) |',
    '| `extraTasks` | COL-SUE-34 | M16 | `draft`, `confirmed`, `voided` | `draft` | M16 §8.12.12 (PA-SUE-18) |',
]
d.after_line('| `collectionAccountingGroups` | COL-COB-47 |', st, 'estados')

# ---------------- PA-DAT-04: notas sobre lo que cambió
d.rep('  - `apiUsageDaily` único `{apiClientId, day}` (antes `date`, alineado a T10); ',
      '  - `apiUsageDaily` único `{apiClientId, day}` (antes `date`, alineado a T10; %s: reemplazado por `{apiClientId, date, route, status}`, ver PA-DAT-05); ' % S, 'PA')
d.rep('`fuelTypes.vatRateId` y `housingContributions.invoiceId`.',
      '`fuelTypes.vatRateId` y `housingContributions.invoiceId`. (%s: M13, M14, M16, M17 y M18 `fuelTypes.vatRateId` ya adoptaron estos nombres; ver PA-DAT-05.)' % S, 'PA')

pa = [
    '',
    '### PA-DAT-05 — Sincronización del catálogo con las rondas de residuales de los anexos dueños',
    '',
    '- **Pregunta:** ¿cómo se reflejan en el catálogo, en §7.2.1 y en §8.1 los nombres, destinos, unicidades y estados que los anexos dueños fijaron en la ronda de residuales del 5-11-2026 (`_trabajo/residuales-sincronizacion.md`), y qué nombre rige cuando T05 y el dueño difieren?',
    '- **Contexto:** M07 a M11 (PA-COB-21, PA-MOR-22, PA-CRM-20, PA-TEC-23, PA-VEN-12), M12 a M17 (PA-CMP-16, PA-STK-11, PA-TES-19, PA-SUE-18, PA-INS-13), M02 a M06 (PA-CAT-23, PA-MED-15, PA-TAR-21, PA-FAC-23, PA-FIS-22) y T02, T06, T07, T10 corrigieron sus §7 y §8 y piden a T05 reflejarlo. En la ronda anterior T05 había alineado algunas filas a nombres que los dueños después cambiaron (`connectorId` de COL-COB-34, `ruleId` de COL-BIA-16, `day` de COL-BIA-23, `profileId` de COL-IAM-08, `familyId` de COL-IAM-13). T10 §7.26 declara `indicatorId` obligatorio en `indicatorSnapshots` y `kpiAlertRules`, y el texto del §7.11 y del §7.13 solo `indicatorCode`; T07 declara `migrationIssues.ruleId` → `migrationMappingRules` y `ruleCode` como clave natural de la regla.',
    '- **Opciones:**',
    '  - A) Prevalece el anexo dueño: el catálogo toma los nombres del §7 del dueño (incluidas las tablas de campos que adoptan el canónico de T05), los destinos y valores nuevos se registran en §7.2.1 y §8.1, y donde el dueño declara dos nombres se toma la tabla de campos: `indicatorId` como referencia más `indicatorCode` como código desnormalizado, `kpiAlertRuleId`, `migrationIssues.ruleId` como referencia y `ruleCode` como clave natural, `apiUsageDaily.date` **(Recomendada)**.',
    '  - B) Conservar los nombres de la ronda anterior de T05 y pedir a cada dueño que vuelva a cambiar — reabre filas que el dueño ya cerró.',
    '- **Impacto si no se responde:** se asume A.',
    '- **Bloquea:** COL-COB-11, 13 y 34; COL-MOR-02, 13, 17, 19, 20, 24 y 26; COL-CRM-10, 11, 12, 16, 19 y 26; COL-TEC-12, 20, 21, 22, 28 y 42; COL-MED-17; COL-CMP-22 y 23; COL-TES-13 y 42; COL-INS-01; COL-IAM-08 y 13; COL-MIG-01, 11 y 13; COL-BIA-12, 15, 16 y 23; §7.2.1; §8.1.',
    '- **Estado:** **Asumida (DEC-072)**, opción A. Aplicada el 5-11-2026:',
    '  - Catálogo: 40 celdas con nota "%s: …; antes …" en las filas de la lista anterior (claves y referencias o únicos). No cambian Alc., Clas., Ola ni Est.' % S,
    '  - §7.2.1: 9 filas existentes con nota y 44 filas nuevas (14 de "no es referencia" y 30 de destinos), entre ellas `obligationId` de `withholdingsApplied` → `taxObligations` e `invoiceId`/`receiptId` de M12 → `supplierInvoices`/`supplierReceipts`, que son excepciones de contexto a §7.2.',
    '  - §8.1: 10 filas nuevas (`collectors` y `gatewayConnectors`, `interestIndexTables`, `debtCollectionAgencies`, `regulatoryReportRuns`, `revaluations`, `serviceReceptions`, `signalRightsContracts`, `matchExceptions.decision`, `shifts`, `extraTasks`).',
    '  - Los totales no cambian: 1.108 filas y 1.057 colecciones a crear (no hay colecciones nuevas ni absorbidas).',
    '  - Quedan para los dueños: M13 §7.37.15 todavía apunta `lots.purchaseReceiptId` a `receipts` (M07) mientras §7.37.14 dice `supplierReceipts`; T10 §7.11 y §7.13 nombran solo `indicatorCode` y `ruleId` en el texto; M12 PA-CMP-16 pide que M02 confirme `packageIds` → `servicePlans`.',
]
d.after_line('  - Las 6 filas `R` pasan a `C (antes R)`.', pa, 'PA')

d.after_line('| `_trabajo/residuales-instrucciones.md` (cierre de residuales, 5-11-2026) |',
             ['| `_trabajo/residuales-sincronizacion.md` (sincronización de residuales, 5-11-2026) | PA-DAT-05; §7.2.1; §8.1; filas del catálogo listadas en PA-DAT-05 |'], 'trazabilidad')

d.save()
