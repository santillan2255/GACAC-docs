from sync_lib import Doc

d = Doc('T02-*.md')

# 1. fac.bloqueosCausas.configurar reemplazada por mor.causas.configurar
d.cell('| `fac.bloqueosCausas.configurar` | Causas de bloqueo.', 1,
       lambda c: 'Reemplazada por `mor.causas.configurar` (API-MOR-25 sobre `holdReasons` de M08; M05 PA-FAC-23 reemplaza API-FAC-023 por API-MOR-25; alias en 4.4.1; PA-IAM-19). Antes "' + c + '"',
       'reemplazada')
d.cell('| `mor.causas.configurar` | ABM de causas de bloqueo |', 5,
       lambda c: c + ', API-FAC-023 y PAN-FAC-17 de M05 (por el alias `fac.bloqueosCausas.configurar`, PA-IAM-19)',
       'reemplazada')
last = [l for l in d.t.split('\n') if l.startswith('| `cob.cajas.ver` | `cob.caja.ver` | Total |')]
assert len(last) == 1
d.after_line(last[0], [
    '| `fac.bloqueosCausas.configurar` | `mor.causas.configurar` | Total | M05 (§4, PAN-FAC-17, API-FAC-023) | M05 PA-FAC-23: API-FAC-023 reemplazada por API-MOR-25 (`holdReasons` de M08, CTR-DAT-36); alias agregado el 5-11-2026 (PA-IAM-19, Asumida DEC-072) |'
], 'reemplazada')

# 2. fis.service.*: son servicios internos de M06 §11.1, no capabilities asignables
d.cell('| `fis.service.calculateTaxes` | Calcula impuestos de un documento |', 1,
       lambda c: 'Servicio interno `fis.service.calculateTaxes` de M06 §11.1 (antes `fis.taxEngine.calculate`; consumidores M04, M05 y M11), no capability asignable: se conserva la fila para no reutilizar el nombre; API-FIS-42 (simulación) exige `fis.impuestos.ver` (M06 PA-FIS-22; PA-IAM-19). Antes "' + c + '"',
       'servicios')
d.cell('| `fis.service.calculateWithholdings` | Calcula retenciones de una OP |', 1,
       lambda c: 'Servicio interno `fis.service.calculateWithholdings` de M06 §11.1 (antes `fis.withholding.calculate`; consumidores M12 y M14), no capability asignable: se conserva la fila para no reutilizar el nombre; API-FIS-52 exige `fis.retenciones.calcular`. Los otros servicios de M06 §11.1 (`fis.service.resolveDocumentClass`, `fis.service.checkRegistryCoverage`, antes `fis.registries.validateCoverage`, `fis.service.confirmWithholdings`, `fis.service.cancelWithholdings`) no se registran como capabilities (M06 PA-FIS-22; PA-IAM-19). Antes "' + c + '"',
       'servicios')

# 3. tec.workOrder.create ya no es comando en M10
d.cell('| `tec.workOrder.create` | `tec.ordenes.crear` | Total |', 4,
       lambda c: c + '. Desde el 5-11-2026 `tec.workOrder.create` ya no es el comando de M09 a M10: el comando es `tec.workOrder.request` (EVT-CRM-13; M10 PA-TEC-23); el alias de capability se conserva (PA-IAM-19)',
       'alias')
d.cell('| tec | `tec.workOrder.create` | `tec.ordenes.crear` |', 3,
       lambda c: c + '. Ya no es comando: M10 usa `tec.workOrder.request` (PA-TEC-23); se conserva solo como alias de capability (4.4.1, PA-IAM-19)',
       'alias')

pa = '''### PA-IAM-19 - Sincronización posterior a la ronda de residuales (capabilities reemplazadas, servicios internos y comando de OT)

- **Pregunta:** ¿qué ajustes del catálogo de capabilities piden los anexos de módulo después de la ronda de residuales (`_trabajo/residuales-sincronizacion.md`)?
- **Contexto:** M05 PA-FAC-23 reemplazó API-FAC-023 por API-MOR-25 y pidió marcar `fac.bloqueosCausas.configurar` como reemplazada por `mor.causas.configurar`; M06 PA-FIS-22 renombró los servicios internos de §11.1 (`fis.service.calculateTaxes`, antes `fis.taxEngine.calculate`; `fis.service.checkRegistryCoverage`, antes `fis.registries.validateCoverage`; `fis.service.calculateWithholdings`, antes `fis.withholding.calculate`; `fis.service.resolveDocumentClass`), dos de los cuales figuraban en 4.4.2 como capabilities; M10 PA-TEC-23 cambió el comando de OT a `tec.workOrder.request`. Barrido de uso activo (`_trabajo/t02r4_scan.py`, filas PAN, API y SM y §4 de todos los anexos): ninguna capability nueva sin registrar respecto del barrido anterior; las capabilities citadas por las PA de residuales (`pla.archivos.*`, `pla.misProcesos.ver`, `pla.salud.sondear`, `iam.sesion.autenticada`, `iam.ia.decisiones.registrar`, `mig.clavesHeredadas.resolver`, `mig.miHistorial.ver`, `int.agentes.ejecutar`, `bia.reportes.ver`, `bia.exportaciones.crear`, `bia.apis.consumir`, `tes.posicion.ver`, `sue.costoLaboral.ver`, `stk.articulos.ver`, `ins.status.ver`, `int.bitacora.verPayload`, `int.operaciones.resolverManual`) ya están registradas. Los nombres `fis.service.*` y `fac.service.*` que aparecen en filas API son servicios internos, no capabilities.
- **Opciones:**
  - A) Marcar `fac.bloqueosCausas.configurar` como reemplazada y registrarla como alias total de `mor.causas.configurar`; aclarar que las filas `fis.service.*` son servicios internos de M06 §11.1 (sin borrarlas, para no reutilizar el nombre) con sus nombres anteriores; anotar que `tec.workOrder.create` ya no es comando y queda solo como alias de capability. **(Recomendada)**.
  - B) Mantener `fac.bloqueosCausas.configurar` como capability propia de M05 - duplica el permiso sobre `holdReasons`, cuyo dueño es M08.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** 4.4.1, 4.4.2 (M05, M06, M08), 4.4.3; contratos OpenAPI de M05 (API-FAC-023) y M06 (API-FIS-42, 52).
- **Estado:** **Asumida (DEC-072)**, opción A. Aplicada el 5-11-2026 en 4.4.1 (alias nuevo y nota de `tec.workOrder.create`), 4.4.2 (`fac.bloqueosCausas.configurar`, `mor.causas.configurar`, `fis.service.calculateTaxes`, `fis.service.calculateWithholdings`) y 4.4.3. M05 debe usar `mor.causas.configurar` en §4 y PAN-FAC-17 (el alias cubre el nombre anterior). Ya no bloquea.
'''
d.rep('- **Bloquea:** contratos OpenAPI (seguridad por operación), diagramas de estados y ER de T02.\n- **Estado:** Asumida (DEC-072): opción A.\n',
      '- **Bloquea:** contratos OpenAPI (seguridad por operación), diagramas de estados y ER de T02.\n- **Estado:** Asumida (DEC-072): opción A.\n\n' + pa, 'PA')
d.save()
