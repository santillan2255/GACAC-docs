import sys, io, re, glob
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
from res_evt_ren import REN
pref = sys.argv[1]
skip = []
for a in sys.argv[2:]:
    s, e = map(int, a.split("-"))
    skip.append((s, e))
L = open(glob.glob(r"..\anexos\%s-*" % pref)[0], encoding="utf-8-sig").read().split("\n")
olds = [o for _, o, _ in REN]
for i, l in enumerate(L, 1):
    if any(s <= i <= e for s, e in skip):
        continue
    for o in olds:
        if o in l:
            print(i, o, "::", l[:260])
    for m in re.finditer(r"`\.[a-z]+-[a-z-]+`", l):
        print(i, "REL", m.group(0), "::", l[:200])
