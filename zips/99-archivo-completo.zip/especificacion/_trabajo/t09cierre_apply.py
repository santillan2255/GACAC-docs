# Pasada de cierre T09 (05-11-2026): PA 1 y PA 2 del pendiente, rutas de plataforma y §10.3. UTF-8 sin BOM, LF.
import sys

P = 'anexos/T09-COM-comunidad-comunicaciones.md'
raw = open(P, 'rb').read()
assert not raw.startswith(b'\xef\xbb\xbf') and b'\r\n' not in raw
t = raw.decode('utf-8')

def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count:
        sys.exit(f'ERROR: {n} ocurrencias de: {old[:120]}')
    t = t.replace(old, new)

# ---------------------------------------------------------------- PA 2 (PA-COM-18): communicationTypeId obligatorio
rep('| `communicationTypeId` | ObjectId | Sí | Tipo de comunicación. Las plantillas de campaña o de texto libre, que antes usaban los valores `campaign`/`free` en este campo, quedan sin tipo y se distinguen por `channel` y por su uso en `campaigns` [VERIFICAR] (antes `communicationTypeCode`; nombre según T05) |',
    '| `communicationTypeId` | ObjectId | Sí | Tipo de comunicación, obligatorio en toda plantilla (PA-COM-18, Asumida DEC-072). Las plantillas de campaña o de texto libre, que antes usaban los valores `campaign`/`free` en este campo, usan el tipo genérico "Campaña" (`code = com.campaign.generic`). Antes: "quedan sin tipo y se distinguen por `channel` y por su uso en `campaigns` [VERIFICAR]". (Antes `communicationTypeCode`; nombre según T05) |')
rep('| `platformTypeId`, `overridden` | ObjectId, Bool | No | Herencia: `platformTypeId` → `communicationTypes` (COL-COM-35, fila del tenant `PLATFORM`); `overridden` no es referencia. |\n\nÍndice único `{tenantId, code}`.\n',
    '| `platformTypeId`, `overridden` | ObjectId, Bool | No | Herencia: `platformTypeId` → `communicationTypes` (COL-COM-35, fila del tenant `PLATFORM`); `overridden` no es referencia. |\n\nÍndice único `{tenantId, code}`.\n\n'
    'Tipo genérico "Campaña" (PA-COM-18): fila de plataforma `com.campaign.generic` (`module = com`, `audienceKind = member`, `optOut = full`, `quietHoursExempt = false`, `priority = low`, `requiredMilestone = accepted`, `evidenceRequired = false`, `triggerEvents[]` vacío), heredada por cada tenant. La usan las plantillas de campaña (`campaigns.channels[].templateVersionId`) y las de texto libre del envío manual (PAN-COM-30). Su `purpose` declarado es `marketing`; el motor evalúa consentimiento y no molestar con la finalidad efectiva de la campaña (`campaigns.purpose`) o del envío manual, que nunca puede ser `security` ni `regulatory`.\n')

# ---------------------------------------------------------------- PA 1 (PA-COM-17): estados de platformNotices
rep('| `surveyId` | ObjectId | No | — | `surveys` (COL-COM-20, T09) |\n| `status` | enum | Sí | — | — |\n\n**`platformNoticeReads`**',
    '| `surveyId` | ObjectId | No | — | `surveys` (COL-COM-20, T09) |\n| `status` | enum `draft`, `published`, `expired`, `withdrawn` | Sí | Ciclo propio de T09 (§8.13.1; PA-COM-17, Asumida DEC-072); antes "enum" sin valores. No usa los estados de tenant de T01. | — |\n\n**`platformNoticeReads`**')
rep('| `platformNotices.status` | `draft`, `published`, `expired`, `withdrawn` [VERIFICAR: §7.10 declaraba `status` sin valores; se proponen estos] | `draft` | §8.13.1 |',
    '| `platformNotices.status` | `draft`, `published`, `expired`, `withdrawn` (PA-COM-17, Asumida DEC-072; antes "[VERIFICAR: §7.10 declaraba `status` sin valores; se proponen estos]") | `draft` | §8.13.1 |')

# ---------------------------------------------------------------- PA 3 (dueño T05): consecuencia en T09
rep('un corte puede afectar varios servicios de la misma red, por lo que se conserva la lista y se informa para corregir T05 [VERIFICAR]. |',
    'un corte puede afectar varios servicios de la misma red, por lo que se conserva la lista; la corrección de T05 queda a cargo de T05 (PA 3 del cierre, Asumida DEC-072; antes [VERIFICAR]). |')

# ---------------------------------------------------------------- rutas de plataforma (convención de T01 y T03)
rep('| PAN-COM-33 | `/admin/platform/avisos` (`meta.platformOnly`) |',
    '| PAN-COM-33 | `/admin/plataforma/avisos` (`meta.platformOnly`; antes `/admin/platform/avisos`, alineada a T01 §10 y T03 SM-PLT-023) |')
rep('| PAN-COM-34 | `/admin/platform/mensajeria` (`meta.platformOnly`) |',
    '| PAN-COM-34 | `/admin/plataforma/mensajeria` (`meta.platformOnly`; antes `/admin/platform/mensajeria`, alineada a T01 §10 y T03 SM-PLT-024) |')

# ---------------------------------------------------------------- §10.3
rows = [
    ('| T03 PAN-COM-10 | — | PAN-COM-08 | §10.1 |', '| T03 PAN-COM-10 | — | PAN-COM-08 | `/admin/com/boletines`, `com.newsletters.ver` (antes "§10.1") |'),
    ('| T03 PAN-COM-17 | — | PAN-COM-21 | §10.1 |', '| T03 PAN-COM-17 | — | PAN-COM-21 | `/admin/com/campanas`, `com.campaigns.ver` (antes "§10.1") |'),
    ('| T03 PAN-COM-20 | — | PAN-COM-18 | §10.1 |', '| T03 PAN-COM-20 | — | PAN-COM-18 | `/admin/com/catalogo`, `com.catalog.configurar` (antes "§10.1"); los saludos automáticos que T03 ubicaba aquí van en PAN-COM-03 (`com.posts.configurar`) |'),
    ('| T03 PAN-COM-11 | — | PAN-COM-10 | §10.1 |', '| T03 PAN-COM-11 | — | PAN-COM-10 | `/admin/com/encuestas`, `com.surveys.ver` (antes "§10.1") |'),
    ('| T03 PAN-COM-13 | — | PAN-COM-12 | §10.1 (capability `com.surveys.resultados`; T03 cita `com.surveys.crear` y ruta `modal`) |',
     '| T03 PAN-COM-13 | — | PAN-COM-12 | `/admin/com/encuestas/:id/resultados`, `com.surveys.resultados` (antes "§10.1"; T03 citaba `com.surveys.crear` y ruta `modal`) |'),
    ('| T03 PAN-COM-16 | `/admin/com/audiencias` | PAN-COM-17 | `/admin/com/segmentos` |', '| T03 PAN-COM-16 | `/admin/com/audiencias` | PAN-COM-17 | `/admin/com/segmentos`, `com.audiences.usar` |'),
    ('| T03 PAN-COM-22 | — | PAN-COM-26 | §10.1 |', '| T03 PAN-COM-22 | — | PAN-COM-26 | `/admin/com/canales`, `com.channels.configurar` (antes "§10.1") |'),
    ('| T03 PAN-COM-24 | `/admin/com/consentimientos` | PAN-COM-25 | `/admin/com/preferencias` |', '| T03 PAN-COM-24 | `/admin/com/consentimientos` | PAN-COM-25 | `/admin/com/preferencias`, `com.consents.ver` |'),
    ('| T03 PAN-COM-46 | `/admin/plataforma/avisos` | PAN-COM-33 | Ruta de §10.1 (`/admin/platform/avisos`) |',
     '| T03 PAN-COM-46 | `/admin/plataforma/avisos` | PAN-COM-33 | `/admin/plataforma/avisos`, `pla.notices.publicar` (antes "Ruta de §10.1 (`/admin/platform/avisos`)"; T09 adopta la ruta de T01 y T03) |'),
    ('| T03 PAN-COM-47 | — | PAN-COM-34 | §10.1 |', '| T03 PAN-COM-47 | — | PAN-COM-34 | `/admin/plataforma/mensajeria`, `pla.messaging.consumo.ver` (antes "§10.1") |'),
]
for o, n in rows:
    rep(o, n)
rep('| T03 PAN-COM-47 | — | PAN-COM-34 | `/admin/plataforma/mensajeria`, `pla.messaging.consumo.ver` (antes "§10.1") |\n',
    '| T03 PAN-COM-47 | — | PAN-COM-34 | `/admin/plataforma/mensajeria`, `pla.messaging.consumo.ver` (antes "§10.1") |\n\n'
    'Verificación de la pasada de cierre (05-11-2026) contra T03 §10.8 y §10.9: T03 ya cita los ID de T09 (AL-11) con la cita anterior entre paréntesis, y sus rutas y capabilities coinciden con la columna de la derecha salvo SM-ADM-004, que exige "sesión" para `/admin/avisos` en lugar de `com.inbox.ver` (PAN-COM-32); la corrección queda a cargo de T03. La primera columna conserva la numeración anterior de T03 como referencia histórica.\n')

# ---------------------------------------------------------------- §21: PA-COM-17 y PA-COM-18
anchor = '- **Impacto si no se responde:** se asume A (PRM-COM-063 = false).\n- **Bloquea:** RF-COM-160, 161, P-COM-08; O3.\n'
rep(anchor, anchor + '''
### PA-COM-17 — Estados de los avisos de plataforma
- **Pregunta:** ¿Qué estados tiene un aviso de plataforma (`platformNotices.status`)?
- **Contexto:** §7.10 declaraba `status` como enum sin valores; §8.0 y §8.13.1 proponían `draft`, `published`, `expired`, `withdrawn`. La alternativa era reutilizar los estados de ciclo de T01. Pregunta 1 del pendiente de cierre (grupo T02 y T09).
- **Opciones:**
  - A) Ciclo propio `draft` → `published` → `expired`, con `withdrawn` desde `draft` o `published` **(Recomendada)** — refleja la vigencia (`startsAt`, `endsAt`, permanencia) y el retiro manual.
  - B) Reutilizar los estados de T01 — un solo vocabulario, pero T01 no modela vigencia ni retiro de avisos.
- **Impacto si no se responde:** se asume A.
- **Estado:** Asumida la recomendada (DEC-072): opción A, aplicada en §7.10, §8.0 y §8.13.1.
- **Bloquea:** RF-COM-204, EVT-COM-38, PAN-COM-33; O1.

### PA-COM-18 — Tipo de comunicación en plantillas de campaña y de texto libre
- **Pregunta:** ¿`messageTemplates.communicationTypeId` es obligatorio también en las plantillas de campaña y de texto libre?
- **Contexto:** ProCoop usaba los valores `campaign` y `free` en el tipo de plantilla. §7.7 declaraba el campo obligatorio pero dejaba esas plantillas "sin tipo" [VERIFICAR], lo que rompía el índice único `{tenantId, communicationTypeId, channel, locale}` y la referencia a `communicationTypes`. Pregunta 2 del pendiente de cierre (grupo T02 y T09).
- **Opciones:**
  - A) Obligatorio; esas plantillas usan un tipo genérico "Campaña" (`com.campaign.generic`) precargado por plataforma, y el motor aplica la finalidad efectiva de la campaña o del envío **(Recomendada)** — integridad referencial e índice único sin excepciones.
  - B) Opcional para campañas y texto libre — menos filas de catálogo, pero el índice y las reglas de consentimiento necesitan casos especiales.
- **Impacto si no se responde:** se asume A.
- **Estado:** Asumida la recomendada (DEC-072): opción A, aplicada en §7.7 (`messageTemplates.communicationTypeId` y tipo genérico de `communicationTypes`).
- **Bloquea:** RF-COM-131, RF-COM-190 a 194, PAN-COM-19, PAN-COM-22, PAN-COM-30; O2.
''')

open(P, 'wb').write(t.encode('utf-8'))
print('OK', len(raw), '->', len(t.encode('utf-8')))
