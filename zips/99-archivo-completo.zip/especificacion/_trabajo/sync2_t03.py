import re, collections, os
from sync_lib import Doc, ROOT

d = Doc('T03-*.md')
old = open(os.path.join(ROOT, '_trabajo', 'backup-cierre-T-20261105', 'T03-antes-r3.md'), encoding='utf-8').read().split('\n')
PH = ['otra pantalla (cita en 10.9.13)', 'pantalla relacionada (cita en 10.9.13)']
PRIN = '— (sin pantalla propia en esta app; pantalla relacionada (cita en 10.9.13) ('
ID = r'([A-Z]{3}-\d+)'
KEY = r'^\| ([A-Z]+-[A-Z]+-\d+|[^|]+?) \|'


def occ(L):
    seen = collections.Counter(); m = {}
    for i, l in enumerate(L):
        g = re.match(KEY, l)
        if g:
            seen[g.group(1)] += 1; m[(g.group(1), seen[g.group(1)])] = i
    return m


def restore(cur, ref):
    """Devuelve la celda con los IDs restaurados o None."""
    pat = re.escape(cur)
    for ph in PH:
        pat = pat.replace(re.escape(ph), ID)
    m = re.fullmatch(pat, ref)
    if not m:
        return None
    it = iter(m.groups())
    out = cur
    for ph_pos in sorted([(mm.start(), ph) for ph in PH for mm in re.finditer(re.escape(ph), cur)], reverse=True):
        pass
    # reemplazo secuencial de izquierda a derecha
    res, k = '', 0
    rx = re.compile('|'.join(re.escape(p) for p in PH))
    for mm in rx.finditer(cur):
        res += cur[k:mm.start()] + next(it)
        k = mm.end()
    return res + cur[k:]


mo = occ(old)
L = d.t.split('\n')
seen = collections.Counter()
fixed, manual = [], []
for i, l in enumerate(L):
    g = re.match(KEY, l)
    if not g:
        continue
    k = g.group(1); seen[k] += 1
    if not any(ph in l for ph in PH):
        continue
    j = mo.get((k, seen[k]))
    cells, rcells = l.split(' | '), old[j].split(' | ') if j is not None else []
    ok = len(cells) == len(rcells)
    for c in range(len(cells)):
        if not ok or not any(ph in cells[c] for ph in PH):
            continue
        cur, ref = cells[c], rcells[c]
        tail = cur.endswith(' |')
        cur0, ref0 = (cur[:-2], ref[:-2]) if tail and ref.endswith(' |') else (cur, ref)
        new = restore(cur0, ref0)
        if new is None and cur0.startswith(PRIN) and cur0.endswith('))'):
            m = re.fullmatch(ID + r' \((.*)\)', ref0)
            if m:
                new = '— (sin pantalla propia en esta app; pantalla relacionada %s, citada en 10.9.13; %s)' % (m.group(1), m.group(2))
        if new is None:
            manual.append((i + 1, k, c))
            continue
        cells[c] = new + (' |' if cur0 is not cur else '')
    nl = ' | '.join(cells)
    if nl != l:
        L[i] = nl
        fixed.append(k)
d.t = '\n'.join(L)
d.rep('pantalla relacionada (cita en 10.9.13) (M19 declara `/ingresar`, `/recuperar` y `/restablecer/:token`))',
      'pantalla relacionada POR-19, citada en 10.9.13; M19 declara `/ingresar`, `/recuperar` y `/restablecer/:token`)', 'celdas restauradas')
d._k('celdas restauradas')
print('filas restauradas', len(fixed), fixed)
print('manual', manual)

# Pipes dentro de código en tablas: se escapan (no cambia el texto mostrado)
def esc_code(line):
    return re.sub(r'`[^`]*`', lambda m: m.group(0).replace('\\|', '|').replace('|', '\\|'), line)

for start in ['| RN-UXD-003 |', '| `variants` | Array `{ size, storageKey, purpose: any|', '| `variables[]` |', '| `lastContext` |', '| `ui.accion.crear` |']:
    ln = d.line(start)
    new = esc_code(ln)
    assert new != ln, start
    d.rep(ln + '\n', new + '\n', 'pipes escapados')
d.save()
