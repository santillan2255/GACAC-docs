# -*- coding: utf-8 -*-
"""Declara en el §12.1 de cada productor los eventos de solicitud que consume T06 (ronda de residuales 5-11-2026)."""
import glob, os, re

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "anexos")
EVT_LAST = {  # módulo: (último EVT-ID existente, filas nuevas, encabezado PA residual, línea PA)
    "M06": ("EVT-FIS-24", [
        "| EVT-FIS-25 | `fis.regimeFile.requested` | `filingId`, `legalEntityId`, `regimeCode`, `period`, `storedFileIds[]` (se publica cuando una `regimeFilings` pasa a `approved` y el régimen se entrega por conector, §8.7; ronda de residuales 05-11-2026, PA-FIS-22) | T06 (entrega el archivo al organismo y registra el acuse; antes solo lo nombraba T06 como `fis.regime-file.requested`) |",
    ], "### PA-FIS-22", "- **Eventos de solicitud para T06 (5-11-2026), Asumida (DEC-072):** M06 declara en §12.1 EVT-FIS-25 `fis.regimeFile.requested` (antes `fis.regime-file.requested`, nombre que solo figuraba en T06 §12), publicado al aprobar una `regimeFilings` que se entrega por conector; payload `filingId`, `legalEntityId`, `regimeCode`, `period`, `storedFileIds[]`; consumidor T06. T11 §12.4 registra el alias."),
    "M07": ("EVT-COB-27", [
        "| EVT-COB-28 | `cob.paymentIntent.requested` | Intención creada en `draft` que debe emitirse en el proveedor (portal, caja, CRM, generación masiva; §8.4) | `paymentIntentId`, `gatewayConnectorId`, `currentAccountId`, `amount`, `expiresAt` | T06 (crea la intención en la pasarela con `createPaymentIntent`; responde `int.paymentIntent.created`, EVT-INT-08) |",
        "| EVT-COB-29 | `cob.debtPublication.requested` | Exportación de deuda en `generated` con entrega por conector (§7.22, §8.6) | `agencyDebtExportId`, `agencyId`, `operation`, `period` | T06 (aplica el layout y entrega al ente; responde `int.debtPublication.acknowledged` / `int.debtPublication.rejected`, EVT-INT-09) |",
        "| EVT-COB-30 | `cob.directDebit.batchRequested` | Lote de débito armado que pasa a presentación (`draft` → `presented`, §8.8) | `directDebitBatchId`, `agencyId` o `connectorId`, `exportId`, `debitDate` | T06 (presenta el lote al ente o conector; responde `int.directDebit.resultReceived`, EVT-INT-11) |",
    ], "### PA-COB-21", "- **Eventos de solicitud para T06 (5-11-2026)**: Asumida (DEC-072): M07 declara en §12.1 EVT-COB-28 `cob.paymentIntent.requested` (antes `cob.payment-intent.requested`), EVT-COB-29 `cob.debtPublication.requested` (antes `cob.debt-publication.requested`) y EVT-COB-30 `cob.directDebit.batchRequested` (antes `cob.direct-debit.batch-requested`), que T06 §12 consumía sin que M07 los publicara; payload mínimo con `paymentIntentId`, `agencyDebtExportId` y `directDebitBatchId`; consumidor T06. T11 §12.4 registra los alias."),
    "M03": ("EVT-MED-29", [
        "| EVT-MED-30 | `med.readingRoute.published` | Lote de una ruta exportado a un sistema de telemedición o colectora de terceros conectado por T06 (`assigned` → `downloaded` por exportación, §8.3; payload: `readingRouteId`, `readingBatchId`, `meteringSystemId`, `period`) | T06 (entrega la ruta al sistema remoto o colectora) |",
    ], "### PA-MED-15", "- **Eventos de solicitud para T06 (5-11-2026), Asumida (DEC-072):** M03 declara en §12.1 EVT-MED-30 `med.readingRoute.published` (antes `med.reading-route.published`, nombre que solo figuraba en T06 §12), publicado al exportar el lote de una ruta a un sistema conectado por T06; payload `readingRouteId`, `readingBatchId`, `meteringSystemId`, `period`; consumidor T06. T11 §12.4 registra el alias."),
    "T09": ("EVT-COM-39", [
        "| EVT-COM-40 | `com.message.dispatchRequested` | Comunicación `queued` lista para envío por un canal con conector (§8.10; paso 8 del flujo de envío) | `communicationId`, `communicationAttemptId`, `channel`, `providerConnectorId`, `idempotencyKey` | T06 (envía por el conector del canal; devuelve `int.message.*`) |",
    ], "### PA-COM-19", "- **Eventos de solicitud para T06 (5-11-2026), Asumida (DEC-072):** T09 declara en §12.1 EVT-COM-40 `com.message.dispatchRequested` (antes `com.message.dispatch-requested`, nombre que solo figuraba en T06 §12), publicado cuando una comunicación queda `queued` para un canal con conector; payload `communicationId`, `communicationAttemptId`, `channel`, `providerConnectorId`, `idempotencyKey`; consumidor T06. T11 §12.4 registra el alias."),
    "M01": ("EVT-PER-25", [
        "| EVT-PER-26 | `per.person.fiscalLookupRequested` | Alta o cambio de CUIT/CUIL, o verificación manual (JOB-PER-01) | `personId`, `identifierId` | T06 (consulta el padrón de ARCA con `getPersona`; con el resultado M01 publica EVT-PER-08) |",
    ], "### PA-PER-19", "- **Eventos de solicitud para T06 (5-11-2026), Asumida (DEC-072):** M01 declara en §12.1 EVT-PER-26 `per.person.fiscalLookupRequested` (antes `per.person.fiscal-lookup-requested`, nombre que solo figuraba en T06 §12), publicado por JOB-PER-01 al dar de alta o cambiar un CUIT/CUIL o al verificar a pedido; payload `personId`, `identifierId`; consumidor T06. T11 §12.4 registra el alias."),
    "M14": ("EVT-TES-23", [
        "| EVT-TES-24 | `tes.bankSync.requested` | Inicio de una corrida de sincronización Interbanking, programada (JOB-TES-04) o manual (`interbankingSyncRuns` en `running`, §8.16.11; payload: `interbankingSyncRunId`, `connectionId`, `treasuryAccountId`, `kind`, `dateSince`) | T06 (consulta saldos y movimientos; responde `int.bank.movementsReceived` / `int.bank.balancesReceived`, EVT-INT-12) |",
        "| EVT-TES-25 | `tes.paymentFile.requested` | Archivo de pago generado para entrega por conector (`paymentFiles` en `generated`, JOB-TES-05, §8.10; payload: `paymentFileId`, `purpose`, `format`, `originTreasuryAccountId`, `executionDate`) | T06 (aplica el layout de Interbanking o del banco y lo entrega, FI-INT-59) |",
    ], "### PA-TES-19", "- **Eventos de solicitud para T06 (5-11-2026), Asumida (DEC-072):** M14 declara en §12.1 EVT-TES-24 `tes.bankSync.requested` (antes `tes.bank-sync.requested`) y EVT-TES-25 `tes.paymentFile.requested` (antes `tes.payment-file.requested`), que T06 §12 consumía sin que M14 los publicara; se publican al iniciar una `interbankingSyncRuns` y al generar un `paymentFiles`; payload mínimo con `interbankingSyncRunId` y `paymentFileId`; consumidor T06. T11 §12.4 registra los alias."),
    "M16": ("EVT-SUE-27", [
        "| EVT-SUE-28 | `sue.payrollFiles.requested` | Pedido de generación de un archivo de presentación (LSD, SICOSS/F.931 u otro `kind` de `statutoryFilings`) por empresa y período (JOB-SUE-10, API-SUE-63; payload: `statutoryFilingId`, `legalEntityId`, `kind`, `periodKey`, `payrollRunIds`) | T06 (aplica el diseño oficial vigente y deja el archivo descargable, FI-INT-16; la presentación en ARCA y el acuse siguen manuales, RN-SUE-080) |",
    ], "### PA-SUE-18", "- **Eventos de solicitud para T06 (5-11-2026), Asumida (DEC-072):** M16 declara en §12.1 EVT-SUE-28 `sue.payrollFiles.requested` (antes `sue.payroll-files.requested`, nombre que solo figuraba en T06 §12), publicado al pedir un archivo de `statutoryFilings` por empresa y período; payload `statutoryFilingId`, `legalEntityId`, `kind`, `periodKey`, `payrollRunIds`; consumidor T06. La presentación y el acuse siguen manuales (RN-SUE-080). T11 §12.4 registra el alias."),
}

for mod, (last, rows, pa_head, pa_line) in EVT_LAST.items():
    path = glob.glob(os.path.join(BASE, mod + "-*.md"))[0]
    raw = open(path, "rb").read()
    bom = raw.startswith(b"\xef\xbb\xbf")
    text = raw.decode("utf-8-sig")
    crlf = "\r\n" in text
    L = text.replace("\r\n", "\n").split("\n")
    if any(r.split(" | ")[0] + " |" in "\n".join(L) for r in rows):
        print(mod, "ya aplicado"); continue
    # fila: después de la fila del último EVT-ID existente (dentro de §12.1)
    s12 = next(i for i, l in enumerate(L) if re.match(r"^## 12\.", l))
    idx = next(i for i in range(s12, len(L)) if L[i].startswith("| " + last + " |"))
    L[idx + 1:idx + 1] = rows
    # PA: al final de los ítems de la PA de residuales
    p = next(i for i, l in enumerate(L) if l.startswith(pa_head))
    e = p + 1
    while e < len(L) and L[e].strip() != "" and not L[e].startswith("#"):
        e += 1
    L.insert(e, pa_line)
    out = "\n".join(L)
    if crlf:
        out = out.replace("\n", "\r\n")
    open(path, "wb").write((b"\xef\xbb\xbf" if bom else b"") + out.encode("utf-8"))
    print(mod, "ok", "BOM" if bom else "sinBOM", "CRLF" if crlf else "LF", "fila tras", idx + 1, "PA línea", e + 1)
