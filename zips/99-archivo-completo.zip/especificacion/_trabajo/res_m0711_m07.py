from res_m0711_lib import *

d = Doc('M07')
PA = 'PA-COB-21'
H = lambda n: '#### 7.35.%s ' % n
V = '[VERIFICAR] destino no deducible (identificador externo o interno)'

# ---- categoría 2/4: referencias y nombres en las tablas normalizadas de §7.35
d.set_row(H(10), 'closeGroupId', '| `closeGroupId` | string (UUID) | No | Cierre múltiple: identificador de correlación que comparten las sesiones cerradas juntas (antes tipo `ObjectId`). | No es referencia: no hay colección de cierres múltiples; las sesiones del grupo se buscan por este valor (%s; antes "%s") |' % (PA, V), 2)
d.set_row(H(11), 'sessionId', '| `cashSessionId` | ObjectId | [VERIFICAR] | Nombre canónico del payload de EVT-COB-12/14/25; antes `sessionId` en este anexo. | → M07 `cashSessions` (antes "`cashSessions` (M07); antes implícita por el nombre") |', 4)
d.add_rows_end_of_table(H(13), [
    '| `settlementId` | ObjectId | Cond. | Medio `agency`: rendición del ente (§7.13). | → M07 `agencySettlements` (%s; antes sin destino declarado) |' % PA,
    '| `gatewayTransactionId` | ObjectId | Cond. | Medios `gateway` y `qr` (§7.13); antes `transactionId`. | → M07 `gatewayTransactions` (%s) |' % PA,
    '| `directDebitBatchId` | ObjectId | Cond. | Medio `directDebit` (§7.13); antes `batchId`. | → M07 `directDebitBatches` (%s) |' % PA,
], 2)
d.set_row(H(15), 'surchargeProductId', '| `surchargeProductId` | ObjectId | [VERIFICAR] | Producto con que se factura el recargo de tarjeta. | → M02 `serviceProducts` (T05 §7.2.1, `productId`; %s; antes "%s") |' % (PA, V), 2)
d.set_row(H(16), 'externalQrId', '| `externalQrId` | string | [VERIFICAR] | Identificador del QR en el proveedor (antes tipo `ObjectId`). | — (identificador del sistema externo; no es referencia interna) |', 2)
d.set_row(H(17), 'deviceIds', '| `deviceIds` | ObjectId[] | [VERIFICAR] | Dispositivos de la PWA del cobrador. | → M10 `fieldDevices` (T05 §7.2.1, `deviceId`; %s; antes "%s") |' % (PA, V), 2)
d.set_row(H(19), 'sessionId', '| `cashSessionId` | ObjectId | [VERIFICAR] | Sesión de caja donde se entregan los fondos; antes `sessionId` en este anexo. | → M07 `cashSessions` (antes "`cashSessions` (M07); antes implícita por el nombre") |', 4)
d.table_to3(H(20), {})
d.set_row(H(20), 'exportLayoutId', '| `exportLayoutId` | ObjectId | → T06 `fileLayouts` (§7.20, COL-INT-10; %s; antes "`exportLayouts` (T10); antes implícita por el nombre") |' % PA, 2)
d.set_row(H(20), 'importLayoutId', '| `importLayoutId` | ObjectId | → T06 `fileLayouts` (§7.20, COL-INT-10; %s; antes "%s") |' % (PA, V), 2)
d.set_row(H(20), 'controlLayoutId', '| `controlLayoutId` | ObjectId | → T06 `fileLayouts` (§7.20, COL-INT-10; %s; antes "%s") |' % (PA, V), 2)
d.add_rows_end_of_table(H(20), ['| `fileLayoutIds` | ObjectId[] | Nombre con que T05 (COL-COB-21) agrupa `exportLayoutId`, `importLayoutId` y `controlLayoutId` → T06 `fileLayouts`. Prevalece el anexo: tres campos con rol (%s). |' % PA], 2)
d.table_to3(H(32), {})
d.set_row(H(32), 'reusedFromId', '| `reusedFromId` | ObjectId | → M07 `paymentIntents` (autorreferencia: intención reutilizada dentro de `reuseWindowMinutes`; %s; antes "%s") |' % (PA, V), 2)
d.set_row(H(32), 'connectorId', '| `gatewayConnectorId` | ObjectId | → M07 `gatewayConnectors`. Nombre de T05 (COL-COB-34); antes `connectorId` en §7.27 (el índice `{tenantId, connectorId, externalId}` se lee `{tenantId, gatewayConnectorId, externalId}`) (antes "`gatewayConnectors` (M07); antes implícita por el nombre") |', 4)
d.set_row(H(33), 'externalPaymentId', '| `externalPaymentId` | string | [VERIFICAR] | Identificador del pago en el proveedor (antes tipo `ObjectId`). | — (identificador del sistema externo; no es referencia interna) |', 2)
d.set_row(H(40), 'billingTypeId', '| `billingTypeId` | ObjectId | [VERIFICAR] | Clasificación comercial del comprobante del tercero (`COD_TPFC`). | → M05 `voucherTypes` (igual que `voucherTypeOverrideId` de M05, ex `COD_TPFC`; %s; antes "%s") |' % (PA, V), 2)
d.set_row(H(43), 'productIds', '| `productIds` | ObjectId[] | [VERIFICAR] | Productos comerciales del esquema. | → M02 `serviceProducts` (T05 §7.2.1, `productId`; %s; antes "%s") |' % (PA, V), 2)

# prosa original
d.replace_in_line('- `agency` / `gateway` / `directDebit`:', '`settlementId` / `transactionId` / `batchId`.',
                  '`settlementId` (→ M07 `agencySettlements`) / `gatewayTransactionId` (antes `transactionId`; → M07 `gatewayTransactions`) / `directDebitBatchId` (antes `batchId`; → M07 `directDebitBatches`) (%s).' % PA, 4)
d.replace_in_line('- `qr`: `intentId`, `transactionId`.', '`transactionId`.', '`gatewayTransactionId` (antes `transactionId`).', 4)

# ---- categoría 1: valores de estado en §7
def st(h, vals, sec, antes):
    d.set_row(H(h), 'status', '| `status` | enum | Sí | Valores: %s (%s); antes %s. | — |' % (', '.join('`%s`' % v for v in vals), sec, antes), 1)

st(17, ['active', 'suspended', 'inactive'], '§8.19; %s' % PA, 'sin valores')
st(18, ['draft', 'assigned', 'inProgress', 'synced', 'settled'], '§8.15', '"sección 8"')
st(23, ['generated', 'sent', 'acknowledged', 'failed', 'cancelled'], '§8.6', '"sección 8"')
st(25, ['imported', 'rejected', 'validated', 'partiallyConfirmed', 'confirmed'], '§8.5', '"sección 8"')
st(29, ['draft', 'presented', 'settled', 'closed'], '§8.8; ítems en `items.status`', '"sección 8"')
st(30, ['active', 'suspended', 'inactive'], '§8.19; %s' % PA, 'sin valores')
st(35, ['active', 'paid', 'partiallyPaid', 'expired', 'cancelled'], '§8.13', '"sección 8"')
st(37, ['received', 'applied', 'disputed', 'won', 'lost'], '§8.12', '"sección 8"')
st(38, ['open', 'inReview', 'closed'], '§8.14', '"sección 8"')
st(39, ['prepared', 'delivered', 'received', 'rejected'], '§8.14', '"sección 8"')
st(44, ['open', 'inProgress', 'resolved', 'dismissed'], '§8.15', '"sección 8"')
d.replace_in_line('- `collectors`: `code`, `personId`', '`receiptSeries`, `status`.', '`receiptSeries`, `status` enum `active`, `suspended`, `inactive` (§8.19; %s; antes sin valores).' % PA, 1)
d.replace_in_line('- `gatewayConnectors`: `provider` enum', 'lastOkAt, lastError }`; `status`.', 'lastOkAt, lastError }`; `status` enum `active`, `suspended`, `inactive` (§8.19; %s; antes sin valores).' % PA, 1)

# ---- §7.37 resumen
d.insert_before_heading('## 8. Estados y transiciones', [
    '### 7.37 Residuales del 5-11-2026: referencias, nombres canónicos y valores de estado (%s)' % PA,
    '',
    'Ronda de residuales detectados al regenerar los entregables (categorías 1, 2 y 4 de `_trabajo/residuales-instrucciones.md`). Las filas de §7.35 quedaron corregidas en su lugar con "antes"; esta tabla las resume. Referencia: colección destino precedida de → (anexo dueño); "no es referencia" indica un dato o un identificador externo.',
    '',
    '| Colección | Campo | Tipo | Referencia | Antes |',
    '|---|---|---|---|---|',
    '| `cashSessions` | `closeGroupId` | string (UUID) | No es referencia (correlación del cierre múltiple) | `ObjectId` sin destino |',
    '| `cashOperations` | `cashSessionId` | ObjectId | → M07 `cashSessions` | `sessionId` |',
    '| `paymentTenders` | `settlementId` | ObjectId | → M07 `agencySettlements` | sin destino |',
    '| `paymentTenders` | `gatewayTransactionId` | ObjectId | → M07 `gatewayTransactions` | `transactionId` |',
    '| `paymentTenders` | `directDebitBatchId` | ObjectId | → M07 `directDebitBatches` | `batchId` |',
    '| `cardPlans` | `surchargeProductId` | ObjectId | → M02 `serviceProducts` | sin destino |',
    '| `staticQrCodes` | `externalQrId` | string | No es referencia (identificador del proveedor) | tipo `ObjectId` |',
    '| `collectors` | `deviceIds` | ObjectId[] | → M10 `fieldDevices` | sin destino |',
    '| `collectorSettlements` | `cashSessionId` | ObjectId | → M07 `cashSessions` | `sessionId` |',
    '| `collectionAgencies` | `exportLayoutId` | ObjectId | → T06 `fileLayouts` | `exportLayouts` (T10), inferido por el nombre |',
    '| `collectionAgencies` | `importLayoutId`, `controlLayoutId` | ObjectId | → T06 `fileLayouts` | sin destino |',
    '| `paymentIntents` | `reusedFromId` | ObjectId | → M07 `paymentIntents` (autorreferencia) | sin destino |',
    '| `paymentIntents` | `gatewayConnectorId` | ObjectId | → M07 `gatewayConnectors` | `connectorId` |',
    '| `gatewayTransactions` | `externalPaymentId` | string | No es referencia (identificador del proveedor) | tipo `ObjectId` |',
    '| `thirdPartyBillers` | `billingTypeId` | ObjectId | → M05 `voucherTypes` | sin destino |',
    '| `collectionReportSchemes` | `productIds` | ObjectId[] | → M02 `serviceProducts` | sin destino |',
    '',
    'Campos que T05 cita con otro nombre: `collectionAgencies.fileLayoutIds[]` (T05) = los tres campos con rol del anexo (prevalece el anexo); `paymentIntents.gatewayConnectorId` (T05) se adopta; `cashOperations.sessionId` (T05) pasa a `cashSessionId` como en los payloads de EVT-COB-12, 14 y 25. Valores de `status` agregados en §7.35: `collectors` y `gatewayConnectors` (nuevos, §8.19) y los que solo decían "sección 8" (`collectionRounds`, `agencyDebtExports`, `agencySettlements`, `directDebitBatches`, `paymentCoupons`, `chargebacks`, `collectionReconciliations`, `treasuryHandovers`, `collectionExceptions`), tomados de su máquina del §8.',
])
d.count(2, 0)

# ---- §8.19 máquinas completadas y altas explícitas
rows = []
def r(c, f, t, trig, g='—', e='—'):
    rows.append('| `%s` | %s | %s | %s | %s | %s |' % (c, f, t, trig, g, e))

N = '(nuevo)'
r('collectors', N, '`active`', 'Alta del cobrador por el administrador de cobranza', 'Persona (M01) y caja de tipo `collector` asignadas')
r('collectors', '`active`', '`suspended`', 'Supervisor suspende al cobrador', 'Rendición con diferencia sin justificar o límites excedidos (RF-COB-093)')
r('collectors', '`suspended`', '`active`', 'Supervisor rehabilita', 'Diferencias justificadas')
r('collectors', '`active` · `suspended`', '`inactive`', 'Baja por el administrador', 'Sin listas de cobro en `assigned` o `inProgress` ni rendición `open`')
r('collectors', '`inactive`', '`active`', 'Reactivación por el administrador')
r('gatewayConnectors', N, '`active`', 'Alta de la pasarela por el administrador', 'Credencial en la bóveda (T06) y prueba de conexión `health.status = ok`')
r('gatewayConnectors', '`active`', '`suspended`', 'Sistema o administrador', '`health.status` en `credentialExpired` o `down` sostenido, o suspensión manual; los canales dejan de ofrecerla')
r('gatewayConnectors', '`suspended`', '`active`', 'Administrador', 'Credencial renovada y prueba de conexión correcta')
r('gatewayConnectors', '`active` · `suspended`', '`inactive`', 'Baja por el administrador', 'Sin intenciones `issued` vigentes')
r('gatewayConnectors', '`inactive`', '`active`', 'Reactivación por el administrador', 'Prueba de conexión correcta')
r('accountStatements', N, '`issued`', 'JOB-COB-11 al cierre del ciclo o emisión a demanda', 'Corte con obligaciones del grupo')
r('accountStatements', '`issued`', '`delivered`', 'Sistema: entrega confirmada por el canal (T09)')
r('accountStatements', '`issued` · `delivered`', '`superseded`', 'Sistema: emisión de un resumen posterior del mismo corte con corrección', 'Existe resumen sucesor')
r('receipts', N, '`issued`', 'Cobro confirmado (§8.3)', 'Operación de caja `confirmed`', '`cob.payment.confirmed` (EVT-COB-04)')
r('receipts', '`issued`', '`voided`', 'Anulación de la operación de caja (cajero con permiso)', 'RN-COB-073, RN-COB-074', '`cob.receipt.voided` (EVT-COB-05)')
r('paymentTenders', N, '`inRegister`', 'Registro del medio en la operación de caja')
r('paymentTenders', '`inRegister`', '`handedOver`', 'Rendición a tesorería (`handoverId`)', 'Rendición `delivered` (§8.14)')
r('paymentTenders', '`handedOver`', '`presented`', 'M14 presenta cupones de tarjeta o cheques')
r('paymentTenders', '`handedOver` · `presented`', '`deposited`', 'M14 deposita o recibe la acreditación')
r('paymentTenders', '`presented`', '`rejected`', 'Rechazo del cheque o del cupón', '—', '`cob.allocation.reversed` (EVT-COB-06)')
r('paymentTenders', '`inRegister`', '`voided`', 'Anulación de la operación de caja', 'Sesión abierta o autorización del supervisor', '`cob.receipt.voided` (EVT-COB-05)')
r('paymentReferences', N, '`active`', 'Emisión del identificador de pago (DEC-050)')
r('paymentReferences', '`active`', '`consumed`', 'Sistema: pago aplicado con el identificador', 'Pago imputado')
r('paymentReferences', '`active`', '`cancelled`', 'Anulación o vencimiento del objeto referido (obligación o cupón)')
r('agencyPublishedDebts', N, '`published`', 'Exportación `acknowledged` (§8.6)')
r('agencyPublishedDebts', '`published`', '`updated`', 'Exportación de actualización `acknowledged`', 'Cambio de importe o vencimiento')
r('agencyPublishedDebts', '`published` · `updated`', '`paid`', 'Rendición del ente aplicada', 'Obligación `paid`', '`cob.obligation.settled`')
r('agencyPublishedDebts', '`published` · `updated`', '`withdrawn`', 'Retiro por pago por otro canal o anulación del documento')
r('agencyNoveltyFiles', N, '`imported`', 'Importación del archivo del ente', 'Huella `{agencyId, fileHash}` no repetida')
r('agencyNoveltyFiles', '`imported`', '`applied`', 'Responsable confirma las novedades')
r('agencyNoveltyFiles', '`imported`', '`rejected`', 'Validación de formato fallida o rechazo del responsable')
r('gatewayWebhookEvents', N, '`received`', 'Webhook del proveedor', 'Firma válida')
r('gatewayWebhookEvents', '`received`', '`ignored`', 'Sistema: duplicado por `{connectorId, dedupeKey}` o tipo no suscripto')
r('gatewayWebhookEvents', '`received`', '`processing`', 'Worker de pasarela toma el evento')
r('gatewayWebhookEvents', '`processing`', '`processed`', 'Reconsulta al proveedor confirmada', '—', 'Transacción `received` (§8.17)')
r('gatewayWebhookEvents', '`processing`', '`failed`', 'Error de reconsulta o de proceso', '—', '`cob.exception.opened` (EVT-COB-22) al agotar reintentos')
r('gatewayWebhookEvents', '`failed`', '`processing`', 'Reintento programado')
r('allocationPolicies', N, '`draft`', 'Configurador crea una versión')
r('allocationPolicies', '`draft`', '`published`', 'Configurador o aprobador publica', 'Versión validada; publicada queda inmutable (T05 §7.1.5)')
r('allocationPolicies', '`published`', '`retired`', 'Sistema al publicar la versión sucesora', 'Existe versión sucesora')
for c in ('cashRegisters', 'staticQrCodes', 'collectionAgencies'):
    r(c, N, '`active`', 'Alta por el administrador', 'Validación del esquema (T04 §8.3)')
    r(c, '`active`', '`inactive`', 'Baja por el administrador', 'Sin sesiones abiertas (cajas), sin transacción en curso (QR) o sin exportaciones pendientes (entes); no se borra (T05 §7.1.5)')
    r(c, '`inactive`', '`active`', 'Reactivación por el administrador')
r('creditBalances', N, '`open`', 'Excedente de cobro, anticipo, nota de crédito, reverso o migración (`origin`)')
r('unidentifiedReceipts', N, '`pending`', 'Línea de rendición, transacción o movimiento bancario sin cuenta identificable')
r('collectionRounds', N, '`draft`', 'Armado de la lista de cobro por el supervisor')
r('agencyDebtExports', N, '`generated`', 'Generación del archivo o envío por API (JOB o responsable)')
r('directDebitBatches', N, '`draft`', 'Armado del lote de débito')
r('paymentCoupons', N, '`active`', 'Emisión del cupón de pago único', 'Obligaciones de una sola entidad jurídica (RN-COB-156)')
r('chargebacks', N, '`received`', 'Aviso de contracargo del proveedor', 'Transacción de pasarela identificada')
r('collectionReconciliations', N, '`open`', 'Apertura de la conciliación del día por ente, pasarela o caja')
r('treasuryHandovers', N, '`prepared`', 'Cajero prepara la entrega al cerrar la sesión', 'Sesión `closed` o rendición de cobrador cerrada')
r('collectionExceptions', N, '`open`', 'Sistema registra la excepción', '—', '`cob.exception.opened` (EVT-COB-22)')

block = [
    '### 8.19 Máquinas completadas y altas explícitas (residuales del 5-11-2026, %s)' % PA,
    '',
    'Completa las colecciones que los entregables marcaron sin valores (`collectors`, `gatewayConnectors`), con estados sin transiciones (`accountStatements`, `receipts`, `paymentTenders`, `paymentReferences`, `agencyPublishedDebts`, `agencyNoveltyFiles`, `gatewayWebhookEvents`), con patrón general sin tabla (`allocationPolicies`, `cashRegisters`, `staticQrCodes`, `collectionAgencies`) y las máquinas de §8.6 a §8.15 que decían el estado inicial solo en texto. Las filas `(nuevo)` fijan el estado inicial. Valores asumidos en %s (DEC-072); coinciden con §7.35.' % PA,
    '',
    '| Colección | Desde | Hacia | Disparador | Guarda | Evento |',
    '|---|---|---|---|---|---|',
] + rows
d.insert_before_heading('## 9. Procesos y flujos', block)
d.count(1, len(rows))

# ---- categoría 7: CU-13 dueño M07
d.replace_in_line('**CU-13 — Pago online (BASE §13).**', '**CU-13 — Pago online (BASE §13).**',
                  '**CU-13 — Pago online (BASE §13).** Dueño del ID: M07 (decisión del coordinador del 5-11-2026; el CU-13 de M14 se renumera en M14 con "antes CU-13").', 7)

# ---- PA
d.insert_before_heading('## 22. Trazabilidad', [
    '### %s — Residuales de los entregables: referencias, nombres canónicos y estados (5-11-2026)' % PA,
    '- **Pregunta**: ¿Qué destino tienen las referencias que los entregables marcaron sin colección (`closeGroupId`, `settlementId`, `surchargeProductId`, `deviceIds`, `importLayoutId`, `controlLayoutId`, `reusedFromId`, `billingTypeId`, `productIds`; `externalQrId` y `externalPaymentId` con tipo `ObjectId`), qué nombres se adoptan (`cashSessionId`, `gatewayTransactionId`, `directDebitBatchId`, `gatewayConnectorId`) y qué valores y transiciones tienen `collectors.status`, `gatewayConnectors.status` y las colecciones con estados sin transiciones o sin estado inicial explícito?',
    '- **Contexto**: residuales de `docs/entregables-analisis-diseno/03-er/M07-COB-cuenta-corriente-cobranza.md` §7 y de `06a-indice-cobertura-secuencias-estados.md` §7 (INC-06-01, 02, 08).',
    '- **Opciones**: A) **(Recomendada)** Destinos de §7.37 (T05 §7.2.1 cuando existe; `fileLayouts` de T06 para los layouts de entes, como dice §7.20; `voucherTypes` para `billingTypeId`, ex `COD_TPFC`; `closeGroupId`, `externalQrId` y `externalPaymentId` no son referencias), nombres canónicos con alias "antes" y máquinas de §8.19 (`collectors` y `gatewayConnectors` con `active`, `suspended`, `inactive`). B) Mantener `[VERIFICAR]` hasta revisar con la cooperativa.',
    '- **Impacto si no se responde**: A.',
    '- **Bloquea**: diagrama ER de M07; diagramas de estados de M07; T05 §7.2.1 y COL-COB-11, 21, 34.',
    '- **Estado**: Asumida (DEC-072): opción A. Aplicado en §7.35 (filas corregidas con "antes"), §7.37 y §8.19. T05 debe reflejar: `cashSessionId` en COL-COB-11 (antes `sessionId`), los tres campos de layout en COL-COB-21 en lugar de `fileLayoutIds[]`, y en §7.2.1 `closeGroupId`, `externalQrId` y `externalPaymentId` como "no es referencia", `deviceIds` (M07 `collectors`) → `fieldDevices`, `productIds`/`surchargeProductId` (M07) → `serviceProducts`, `billingTypeId` (M07) → `voucherTypes`.',
    '',
])
d.count(9, 1)
d.save()
report()
