from res_m0711_lib import *

d = Doc('M11')
PA = 'PA-VEN-12'
H = lambda n: '#### 7.14.%s ' % n


def set_last(heading, field, ref, cat=2):
    k = d.row_idx(heading, field)
    cells = [c.strip() for c in d.lines[k].strip().strip('|').split(' | ')]
    old = cells[-1]
    cells[-1] = '%s (%s; antes "%s")' % (ref, PA, old)
    d.lines[k] = '| ' + ' | '.join(cells) + ' |'
    d.count(cat)


# ---- punto específico: API-VEN-006 y 007 reemplazadas con API destino
d.replace_in_line('| API-VEN-006 |', '| interno M05 (`fac.facturacion.ejecutar`) | **Reemplazado por** `billableItems` de M05 (CTR-DAT-38):',
                  '| `fac.facturacion.ejecutar` (cuenta técnica de M05; antes "interno M05 (`fac.facturacion.ejecutar`)") | **Reemplazado por** API-FAC-105 (`GET /api/admin/fac/billable-items`, M05; antes "Reemplazado por `billableItems` de M05"; %s). `billableItems` de M05 (CTR-DAT-38):' % PA, 5)
d.replace_in_line('| API-VEN-007 |', '**Reemplazado por** la selección de `billableItems` que hace M05 en su propia corrida (CTR-DAT-38);',
                  '**Reemplazado por** API-FAC-044 (`POST /api/admin/fac/runs/{id}/prepare`, M05: la preparación de la corrida congela la selección de `billableItems`; antes "Reemplazado por la selección de `billableItems` que hace M05 en su propia corrida"; %s) (CTR-DAT-38);' % PA, 5)

# ---- categoría 2: fichas originales
d.replace_in_line('| `conceptId`, `conceptVersionId` |', 'Concepto facturable y versión (M02/M04) |',
                  'Concepto facturable y versión: → M02 `billableConcepts` (la versión es la vigente del concepto; antes "(M02/M04)"; %s) |' % PA, 2)
d.replace_in_line('| `sourceType`, `sourceId` |', 'Origen (`crm.request`, `tec.workOrder`, `mor.reconnection`, `manual`) |',
                  'Origen (`crm.request`, `tec.workOrder`, `mor.reconnection`, `manual`). `sourceType` no es referencia: discriminador de `sourceId`, polimórfica (→ M09 `crmCases` · M10 `workOrders` · M08 `interruptionCases`; %s) |' % PA, 2)
d.replace_in_line('| `discountAmount`, `discountReason`, `discountApprovalId` |', 'Bonificación aprobada |',
                  'Bonificación aprobada. `discountAmount` y `discountReason` no son referencias; `discountApprovalId` → T11 `approvalRequests` (%s) |' % PA, 2)
d.replace_in_line('| `contractId`, `serviceCode`, `premiseAddressId` |', 'Servicio y domicilio de prestación |',
                  'Servicio y domicilio de prestación: `contractId` → M02 `serviceContracts`; `premiseAddressId` → M01 `addresses` (%s) |' % PA, 2)
d.replace_in_line('| `quoteId`, `quoteVersion` |', 'Versión exacta |',
                  'Versión exacta: `quoteId` → M11 `salesQuotes`; `quoteVersion` no es referencia (número de `versions[]`; %s) |' % PA, 2)
d.replace_in_line('| `originType`, `originId` |', '`salesOrder`, `operationCharge`, `quote` |',
                  '`salesOrder`, `operationCharge`, `quote`. `originType` no es referencia: discriminador de `originId`, polimórfica (→ M11 `salesOrders` · `operationCharges` · `salesQuotes`; %s) |' % PA, 2)
d.replace_in_line('| `installmentType`, `billingGroupId` |', '| String, ObjectId | Sí/No | |',
                  '| String, ObjectId | Sí/No | `installmentType` no es referencia: código del tipo de comprobante de la cuota (`TIPO_FAC`, igual a `voucherTypes.code` de M05); `billingGroupId` → M05 `billingGroups` (%s) |' % PA, 2)
d.replace_in_line('| `status` | Enum | Sí | Ver §8.4 |', 'Ver §8.4 |',
                  'Valores: `scheduled`, `billed`, `partiallyPaid`, `paid`, `earlyPaidOff`, `voided`, `credited` (§8.4 y §8.6; %s); antes "Ver §8.4" |' % PA, 1)

# ---- §7.14
d.table_to3(H(1), {'sourceType': 'enum', 'discountAmount': 'Decimal128', 'discountReason': 'string', 'installmentIds': 'ObjectId[]', 'invoiceRefs': 'object[]'})
set_last(H(1), 'conceptVersionId', '→ M02 `billableConcepts` (versión vigente del concepto)')
set_last(H(1), 'sourceType', 'No es referencia: discriminador de `sourceId`')
set_last(H(1), 'sourceId', 'Polimórfica según `sourceType`: → M09 `crmCases` · M10 `workOrders` · M08 `interruptionCases`')
set_last(H(1), 'discountAmount', 'No es referencia: importe')
set_last(H(1), 'discountReason', 'No es referencia: motivo en texto libre')
set_last(H(1), 'discountApprovalId', '→ T11 `approvalRequests`')
d.table_to3(H(2), {'conditionIds': 'ObjectId[]', 'stockReservationIds': 'ObjectId[]'})
set_last(H(2), 'premiseAddressId', '→ M01 `addresses` (domicilio de prestación)')
set_last(H(2), 'projectId', '→ M09 `crmProjects` (T05 §7.2.1)')
d.table_to3(H(3), {'quoteVersion': 'int'})
set_last(H(3), 'quoteVersion', 'No es referencia: número de versión dentro de `salesQuotes.versions[]`')
d.table_to3(H(4), {'installmentIds': 'ObjectId[]'})
set_last(H(4), 'importBatchId', '→ T07 `migrationBatches` (T05 §7.2.1)')
set_last(H(5), 'freightSettlementId', '→ M18 `tripSettlements` (rendición de viaje; CTR-DAT-53)')
set_last(H(6), 'creditNoteRequestId', '→ M05 `invoiceAnnulmentRequests` (pedido de nota de crédito)')
set_last(H(6), 'stockReceiptIds', '→ M13 `stockDocuments` (reingreso de stock; no son recibos de cobranza)')
d.table_to3(H(7), {'originType': 'enum', 'installmentType': 'string'})
set_last(H(7), 'originType', 'No es referencia: discriminador de `originId`')
set_last(H(7), 'originId', 'Polimórfica según `originType`: → M11 `salesOrders` · `operationCharges` · `salesQuotes`')
set_last(H(7), 'installmentType', 'No es referencia: código `TIPO_FAC` (igual a `voucherTypes.code` de M05)')
set_last(H(10), 'productId', '→ M02 `serviceProducts` (T05 §7.2.1)')
set_last(H(10), 'bonusProductId', '→ M02 `serviceProducts` (producto bonificado)')
set_last(H(11), 'defaultAccountId', '→ M01 `accounts` (cuenta por defecto del POS, P1007)')

d.insert_before_heading('## 8. Estados y transiciones', [
    '### 7.15 Residuales del 5-11-2026: referencias y valores de estado (%s)' % PA,
    '',
    'Ronda de residuales detectados al regenerar los entregables (categorías 1 y 2 de `_trabajo/residuales-instrucciones.md`). Las filas de §7.1 a §7.8 y de §7.14 quedaron corregidas en su lugar con "antes"; esta tabla las resume.',
    '',
    '| Colección | Campo | Tipo | Referencia | Antes |',
    '|---|---|---|---|---|',
    '| `operationCharges` | `conceptVersionId` | ObjectId | → M02 `billableConcepts` | sin destino |',
    '| `operationCharges` | `sourceType` / `sourceId` | enum / ObjectId | Discriminador / polimórfica (`crmCases`, `workOrders`, `interruptionCases`) | sin destino |',
    '| `operationCharges` | `discountAmount`, `discountReason` | Decimal128 / string | No es referencia | sin destino |',
    '| `operationCharges` | `discountApprovalId` | ObjectId | → T11 `approvalRequests` | sin destino |',
    '| `salesQuotes` | `premiseAddressId` | ObjectId | → M01 `addresses` | sin destino |',
    '| `salesQuotes` | `projectId` | ObjectId | → M09 `crmProjects` | sin destino |',
    '| `salesQuoteAcceptances` | `quoteVersion` | int | No es referencia | sin destino |',
    '| `salesOrders` | `importBatchId` | ObjectId | → T07 `migrationBatches` | sin destino |',
    '| `salesDeliveries` | `freightSettlementId` | ObjectId | → M18 `tripSettlements` | sin destino |',
    '| `salesReturns` | `creditNoteRequestId` | ObjectId | → M05 `invoiceAnnulmentRequests` | sin destino |',
    '| `salesReturns` | `stockReceiptIds` | ObjectId[] | → M13 `stockDocuments` | `receipts` (M07) |',
    '| `salesInstallments` | `originType` / `originId` | enum / ObjectId | Discriminador / polimórfica (`salesOrders`, `operationCharges`, `salesQuotes`) | sin destino |',
    '| `salesInstallments` | `installmentType` | string | No es referencia (código `TIPO_FAC`) | sin destino |',
    '| `salesDiscountRules` | `productId`, `bonusProductId` | ObjectId | → M02 `serviceProducts` | sin destino |',
    '| `posTerminals` | `defaultAccountId` | ObjectId | → M01 `accounts` | sin destino |',
])

rows = []
def r(c, f, t, trig, g='—', e='—'):
    rows.append('| `%s` | %s | %s | %s | %s | %s |' % (c, f, t, trig, g, e))
N = '(nuevo)'
r('salesDeliveries', N, '`draft`', 'Depósito prepara la entrega de una venta confirmada o facturada', 'Venta en `confirmed` o `invoiced`')
r('salesDeliveries', '`draft`', '`confirmed`', 'Confirmación de la entrega', 'Egreso de stock en M13 (`stockMovementIds`); firma del receptor')
r('salesDeliveries', '`draft`', '`voided`', 'Descarte del borrador')
r('salesDeliveries', '`confirmed`', '`voided`', 'Anulación de la entrega', 'Reingreso por movimiento compensatorio en M13; período abierto')
r('salesReturns', N, '`draft`', 'Alta de la devolución sobre una venta facturada o entregada')
r('salesReturns', '`draft`', '`approved`', 'Aprobación del supervisor (`approvalId` en T11)', 'Ítems y condición informados')
r('salesReturns', '`approved`', '`completed`', 'Nota de crédito emitida por M05 y reingreso de stock en M13', '`creditNoteRequestId` resuelto; `installmentActions` aplicadas')
r('salesReturns', '`draft` · `approved`', '`cancelled`', 'Cancelación', 'Sin nota de crédito emitida')
r('salesInstallments', N, '`scheduled`', 'Generación del plan de cuotas al confirmar la venta o el cargo financiado')
r('salesInstallments', '`scheduled`', '`billed`', 'Factura de M05 que incluye la cuota')
r('salesInstallments', '`billed`', '`partiallyPaid`', 'Imputación parcial en M07')
r('salesInstallments', '`billed` · `partiallyPaid`', '`paid`', 'Imputación total en M07')
r('salesInstallments', '`scheduled`', '`earlyPaidOff`', 'Cancelación anticipada')
r('salesInstallments', '`scheduled`', '`voided`', 'Devolución o anulación de la venta')
r('salesInstallments', '`billed`', '`scheduled`', 'Anulación de la factura')
r('salesInstallments', '`billed`', '`credited`', 'Nota de crédito')
r('posSessions', N, '`open`', 'Apertura de la sesión en el terminal', 'Sin otra sesión `open` en el terminal (único parcial de T05)')
r('posSessions', '`open`', '`closed`', 'Arqueo y cierre')
r('posSessions', '`closed`', '`reconciled`', 'M07 confirma la caja')
r('posSessions', '`closed`', '`open`', 'Reapertura', 'Permiso de supervisor; antes de la conciliación')
d.insert_before_heading('## 9. Procesos y flujos', [
    '### 8.6 Máquinas completadas y altas explícitas (residuales del 5-11-2026, %s)' % PA,
    '',
    'Agrega las transiciones de `salesDeliveries` y `salesReturns`, que solo tenían valores (INC-06-02), y traslada a tabla las máquinas de §8.4 y §8.5, que daban el estado inicial solo en texto (INC-06-08). Las filas `(nuevo)` fijan el estado inicial. Valores asumidos en %s (DEC-072); coinciden con §7.' % PA,
    '',
    '| Colección | Desde | Hacia | Disparador | Guarda | Evento |',
    '|---|---|---|---|---|---|',
] + rows)
d.count(1, len(rows))

d.insert_before_heading('## 22. Trazabilidad', [
    '### %s — Residuales de los entregables: referencias, estados y API reemplazadas (5-11-2026)' % PA,
    '- **Pregunta**: ¿Qué destino tienen las referencias que los entregables marcaron sin colección en M11 (§7.15), qué transiciones tienen entregas y devoluciones, y qué API de M05 reemplaza a API-VEN-006 y API-VEN-007?',
    '- **Contexto**: residuales de `docs/entregables-analisis-diseno/03-er/M11-VEN-ventas-presupuestos.md` §7, de `06a-indice-cobertura-secuencias-estados.md` §7 (INC-06-02 e INC-06-08) y de `18-openapi/_inconsistencias.md` (filas reemplazadas sin API destino).',
    '- **Opciones**: A) **(Recomendada)** Destinos de §7.15, máquinas de §8.6 y API destino API-FAC-105 (consulta de `billableItems`) para API-VEN-006 y API-FAC-044 (preparación de la corrida) para API-VEN-007. B) Mantener `[VERIFICAR]` y el reemplazo sin API destino.',
    '- **Impacto si no se responde**: A.',
    '- **Bloquea**: diagrama ER, diagramas de estados y contrato OpenAPI de M11.',
    '- **Estado**: Asumida (DEC-072): opción A. Aplicado en §7.1 a §7.8, §7.14, §7.15, §8.6 y §11. T05 debe registrar en §7.2.1 `sourceType`, `originType`, `quoteVersion`, `installmentType`, `discountAmount` y `discountReason` como "no es referencia" y los destinos de `premiseAddressId`, `creditNoteRequestId`, `freightSettlementId` y `discountApprovalId`.',
    '',
])
d.count(9, 1)
d.save()
report()
