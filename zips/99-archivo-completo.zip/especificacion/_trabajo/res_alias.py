import re, io, sys
from collections import defaultdict
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T11-WFL-workflow-eventos-documentos.md"
L = open(P, encoding="utf-8-sig").read().split("\n")
s = next(i for i, l in enumerate(L) if l.startswith("### 12.4 "))
e = next(i for i, l in enumerate(L) if l.startswith("### 12.5 "))
amap = defaultdict(list)
sub = None
for i in range(s, e):
    l = L[i]
    if l.startswith("#### "):
        sub = l
    if not l.startswith("| `"):
        continue
    c = [x.strip() for x in l.strip().strip("|").split("|")]
    if len(c) < 4:
        continue
    names = re.findall(r"`([^`]+)`", c[0])
    canon = re.findall(r"`([^`]+)`", c[2])
    obs = c[3]
    # expand ".x" suffixes relative to previous full name
    full = []
    base = None
    for n in names:
        if n.startswith(".") and base:
            full.append(base.rsplit(".", 1)[0] + n)
        else:
            full.append(n)
            base = n
    for n in full:
        amap[n].append((i + 1, c[2][:90], obs[:40], (sub or "")[:30]))
multi = {k: v for k, v in amap.items() if len(set(x[1] for x in v)) > 1}
print(len(multi))
for k, v in multi.items():
    print(k)
    for x in v:
        print("   ", x)
