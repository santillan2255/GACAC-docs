# -*- coding: utf-8 -*-
"""Correcciones T09 (parte 2): tablas de campos de §7 (cat. 2), destinos (cat. 3) y nombres T05 (cat. 4)."""
import re, sys
sys.stdout.reconfigure(encoding='utf-8')
BASE = r'c:\Users\lenovo\Documents\GACAC\docs'
P = BASE + r'\especificacion\anexos\T09-COM-comunidad-comunicaciones.md'
ER = BASE + r'\entregables-analisis-diseno\03-er\T09-COM-comunidad-comunicaciones.md'
DRY = '--dry' in sys.argv

txt = open(P, 'rb').read().decode('utf-8')
er = open(ER, encoding='utf-8').read().split('\n')

# ---------- tipos y FK del ER (mermaid) ----------
ent = {}
cur = None
for l in er:
    m = re.match(r'^  ([A-Za-z]+) \{$', l)
    if m:
        cur = m.group(1); ent[cur] = {}; continue
    if l.strip() == '}':
        cur = None; continue
    if cur:
        m = re.match(r'^\s+(\S+) (\S+)(?: (PK|FK|UK))?(?: "(.*)")?$', l)
        if m:
            ent[cur][m.group(2)] = (m.group(1), m.group(3), m.group(4) or '')

COLID = {}
for l in er:
    m = re.match(r'^\| (COL-COM-\d+) \| `([A-Za-z]+)` \|', l)
    if m:
        COLID[m.group(2)] = m.group(1)

# ---------- referencias a otros módulos (ER §7) ----------
xref = {}
for l in er:
    m = re.match(r'^\| `([A-Za-z]+)` \| (.+?) \| [^|]+ \| `([A-Za-z]+)` \| (COL-[A-Z]+-\d+) \| ([^|]+) \|$', l)
    if m:
        for f in re.findall(r'`([A-Za-z]+)`', m.group(2)):
            mod = m.group(5).strip()
            mod = 'T09' if mod.startswith('mismo') else mod
            xref[(m.group(1), f)] = '`%s` (%s, %s)' % (m.group(3), m.group(4), mod)

CONN = '`integrationConnections` (COL-INT-02, T06)'
MANUAL = {
    ('postCategories', 'parentId'): '`postCategories` (COL-COM-02, T09)',
    ('greetingRules', 'postTemplateId'): '`postTemplates` (COL-COM-03, T09)',
    ('comments', 'mentions'): '`memberships` (COL-IAM-04, T02)',
    ('moderationPolicies', 'aiConnectorId'): CONN,
    ('moderationPolicies', 'currentGuidelinesId'): '`communityGuidelines` (COL-COM-15, T09)',
    ('moderationPolicies', 'categoryId'): '`postCategories` (COL-COM-02, T09)',
    ('moderationRules', 'policyId'): '`moderationPolicies` (COL-COM-10, T09)',
    ('moderationRules', 'categoryIds'): '`postCategories` (COL-COM-02, T09) [VERIFICAR: el ER infiere `serviceCategories` de M02; por el contexto son categorías de publicación]',
    ('contentReports', 'targetRef'): '`comments` (COL-COM-09, T09)',
    ('contentReports', 'postId'): '`posts` (COL-COM-01, T09)',
    ('communitySanctions', 'caseIds'): '`moderationCases` (COL-COM-12, T09)',
    ('newsletters', 'ruleId'): '`newsletterRules` (COL-COM-17, T09)',
    ('newsletterRecipients', 'newsletterId'): '`newsletters` (COL-COM-18, T09)',
    ('surveyResponses', 'surveyId'): '`surveys` (COL-COM-20, T09)',
    ('surveyResponses', 'invitationId'): '`surveyInvitations` (COL-COM-22, T09)',
    ('surveyResponses', 'fieldAssignmentId'): '`tasks` (COL-WFL-28, T11) [VERIFICAR: asignación de formulario de campo; T05 no la declara]',
    ('surveyInvitations', 'surveyId'): '`surveys` (COL-COM-20, T09)',
    ('surveyInvitations', 'sourceEventId'): 'evento del outbox (`eventTypes`, COL-WFL-01, T11; id del evento)',
    ('surveyTemplates', 'platformTemplateId'): '`surveyTemplates` (COL-COM-23, T09; fila del tenant `PLATFORM`)',
    ('eventRegistrations', 'eventId'): '`events` (COL-COM-25, T09)',
    ('benefits', 'benefitPartnerId'): '`benefitPartners` (COL-COM-27, T09)',
    ('benefitRedemptions', 'benefitId'): '`benefits` (COL-COM-28, T09)',
    ('benefitRedemptions', 'partnerId'): '`benefitPartners` (COL-COM-27, T09)',
    ('audienceSegments', 'lastSnapshotId'): '`audienceSnapshots` (COL-COM-33, T09)',
    ('audienceImportRows', 'listId'): '`audienceImportLists` (COL-COM-31, T09)',
    ('audienceImportLists', 'importedBy'): '`memberships` (COL-IAM-04, T02)',
    ('audienceSnapshots', 'segmentId'): '`audienceSegments` (COL-COM-30, T09)',
    ('audienceSnapshots', 'ownerId'): 'referencia polimórfica según `ownerType` (`posts`, `surveys`, `newsletters`, `campaigns`, `events`, `benefits`, `outageNotices`, `audienceSegments`; T09)',
    ('audienceSnapshotMembers', 'snapshotId'): '`audienceSnapshots` (COL-COM-33, T09)',
    ('messageTemplates', 'communicationTypeId'): '`communicationTypes` (COL-COM-35, T09)',
    ('messageTemplates', 'currentVersionId'): '`messageTemplateVersions` (COL-COM-37, T09)',
    ('messageTemplates', 'platformTemplateId'): '`messageTemplates` (COL-COM-36, T09; fila del tenant `PLATFORM`)',
    ('messageTemplateVersions', 'templateId'): '`messageTemplates` (COL-COM-36, T09)',
    ('communicationAttempts', 'communicationId'): '`communications` (COL-COM-39, T09)',
    ('communicationAttempts', 'connectorId'): CONN,
    ('communicationAttempts', 'intOperationId'): '`integrationOperations` (COL-INT-06, T06)',
    ('communicationEvents', 'communicationId'): '`communications` (COL-COM-39, T09)',
    ('communicationEvents', 'linkId'): '`trackedLinks` (COL-COM-42, T09)',
    ('trackedLinks', 'communicationId'): '`communications` (COL-COM-39, T09)',
    ('trackedLinks', 'campaignId'): '`campaigns` (COL-COM-47, T09)',
    ('senderIdentities', 'connectorId'): CONN,
    ('senderIdentities', 'credentialRef'): '`integrationSecrets` (COL-INT-03, T06)',
    ('senderIdentities', 'phoneNumberId'): '`phoneNumbers` (COL-TEC-60, M10)',
    ('channelSettings', 'connectionId'): CONN,
    ('internalNotificationRules', 'recipients'): '`memberships` (COL-IAM-04, T02), `roles` (COL-IAM-05, T02), cuadrillas (M10), áreas (T04)',
    ('invoiceMessages', 'campaignId'): '`campaigns` (COL-COM-47, T09)',
    ('invoiceMessages', 'segmentId'): '`audienceSegments` (COL-COM-30, T09)',
    ('communicationPreferences', 'personId'): '`persons` (COL-PER-01, M01)',
    ('suppressionEntries', 'sourceCommunicationId'): '`communications` (COL-COM-39, T09)',
    ('appNotifications', 'communicationId'): '`communications` (COL-COM-39, T09)',
    ('platformNoticeReads', 'noticeId'): '`platformNotices` (COL-COM-54, T09)',
    ('postReactions', 'postId'): '`posts` (COL-COM-01, T09)',
    ('postViews', 'postId'): '`posts` (COL-COM-01, T09)',
    ('postDailyStats', 'postId'): '`posts` (COL-COM-01, T09)',
    ('postUserStates', 'postId'): '`posts` (COL-COM-01, T09)',
}
NOREF = {('benefitPartners', 'taxId'): 'No es referencia: CUIT del comercio (texto).',
         ('senderIdentities', 'senderId'): 'No es referencia: remitente alfanumérico SMS.'}

# ---------- nombres de T05 que prevalecen (cat. 4) ----------
RENAME = {
    ('postCategories', 'key'): 'code', ('surveyCategories', 'key'): 'code',
    ('postReactions', 'userId'): 'membershipId', ('postUserStates', 'userId'): 'membershipId',
    ('communitySanctions', 'userId'): 'membershipId', ('guidelineAcceptances', 'userId'): 'membershipId',
    ('appNotifications', 'userId'): 'membershipId', ('pushSubscriptions', 'userId'): 'membershipId',
    ('platformNoticeReads', 'userId'): 'membershipId',
    ('postDailyStats', 'dayKey'): 'date',
    ('surveyResponses', 'respondentHash'): 'respondentKey',
    ('benefits', 'partnerId'): 'benefitPartnerId',
    ('messageTemplates', 'communicationTypeCode'): 'communicationTypeId',
    ('templateVariables', 'path'): 'key',
    ('trackedLinks', 'slug'): 'code',
    ('suppressionEntries', 'addressHash'): 'addressHmac',
    ('channelSettings', 'connectorId'): 'connectionId',
    ('contentReports', 'commentId'): 'targetRef',
    ('pushSubscriptions', 'endpoint'): 'endpointHash',
}
CODE_DESC = 'Código único por tenant (según T05).'
ADD = {  # campos que T05 declara y la ficha no
    'postTemplates': [('code', 'String', 'Sí', CODE_DESC)],
    'greetingRules': [('code', 'String', 'Sí', CODE_DESC)],
    'moderationPolicies': [('code', 'String', 'Sí', CODE_DESC + ' La política de tenant usa `tenant`.')],
    'moderationRules': [('code', 'String', 'Sí', CODE_DESC), ('policyId', 'ObjectId', 'Sí', 'Política a la que pertenece la regla (según T05).')],
    'newsletterRules': [('code', 'String', 'Sí', CODE_DESC)],
    'newsletters': [('number', 'String', 'Sistema', 'Número correlativo del boletín por tenant (según T05; numeración de T11).')],
    'surveyTemplates': [('code', 'String', 'Sí', CODE_DESC)],
    'events': [('code', 'String', 'Sí', CODE_DESC)],
    'benefitPartners': [('code', 'String', 'Sí', CODE_DESC)],
    'benefits': [('code', 'String', 'Sí', CODE_DESC)],
    'audienceSegments': [('code', 'String', 'Sí', CODE_DESC)],
    'audienceSnapshots': [('segmentId', 'ObjectId', 'No', 'Segmento evaluado cuando `ownerType = segment` o la audiencia usa `mode = segment` (según T05).')],
    'messageTemplates': [('code', 'String', 'Sí', CODE_DESC)],
    'communicationEvents': [('provider', 'String', 'Sí', 'Proveedor que emitió el evento (`ses`, `meta_cloud`, `trii`, …); forma con `providerEventId` el único de T05.')],
    'senderIdentities': [('address', 'String', 'Sí', 'Dirección o remitente normalizado del canal (email, alfanumérico SMS o número WhatsApp); forma el único `{channel, address}` de T05. Agrupa `fromAddress`/`senderId`.'),
                         ('credentialRef', 'String (ref. bóveda)', 'No', 'Credencial propia del remitente cuando no la aporta la conexión (según T05).')],
    'channelSettings': [('channel', 'enum `email`, `sms`, `whatsapp`, `push`, `ivr_export`', 'Sí', 'Canal; único por tenant (según T05).')],
    'internalNotificationRules': [('code', 'String', 'Sí', CODE_DESC)],
    'invoiceMessages': [('code', 'String', 'Sí', CODE_DESC), ('segmentId', 'ObjectId', 'No', 'Segmento guardado usado como audiencia (alternativa a `audience`, según T05).')],
    'pushSubscriptions': [('endpoint', 'String (cifrado)', 'Sí', 'URL del servicio push, cifrada; necesaria para enviar.')],
    'platformNotices': [],
}

TYPEMAP = {'string': 'String', 'ObjectId': 'ObjectId', 'Date': 'Date', 'bool': 'Bool', 'int': 'Int',
           'object': 'Objeto', 'object[]': 'Objeto[]', 'array': 'Array', 'ObjectId[]': 'ObjectId[]', 'enum[]': 'enum[]',
           'string[]': 'String[]', 'decimal': 'Decimal128', 'Decimal128': 'Decimal128', 'number': 'Number', 'int[]': 'Int[]',
           'Date[]': 'Date[]', 'any[]': 'Array', 'bool[]': 'Bool[]'}
GUESS = {'order': 'Int', 'icon': 'String', 'color': 'String', 'slug': 'String', 'cover': 'Media', 'body': 'String',
         'layout': 'enum', 'section': 'String', 'pinned': 'Bool', 'defaultAudience': 'AudienceDefinition',
         'audience': 'AudienceDefinition', 'definition': 'AudienceDefinition', 'title': 'String', 'name': 'String',
         'description': 'String', 'text': 'String', 'device': 'Objeto', 'ipHash': 'String', 'contact': 'Objeto',
         'addressText': 'String', 'conditions': 'String', 'value': 'Decimal128', 'currency': 'String (ISO 4217)',
         'genericCode': 'String', 'questions': 'Objeto[]', 'pages': 'Objeto[]', 'scoring': 'Objeto', 'consent': 'Objeto',
         'raw': 'Objeto', 'error': 'String', 'keys': 'Objeto (cifrado)', 'image': 'Media', 'link': 'String',
         'format': 'String', 'example': 'String', 'defaultValue': 'String', 'label': 'String (`dict:`)', 'legacy': 'Objeto',
         'wspPosition': 'Int', 'targetUrl': 'String (URL)', 'clicks': 'Int', 'firstClickAt': 'Date', 'payloadRef': 'String (objeto privado)',
         'providerCode': 'String', 'providerMessage': 'String', 'retryable': 'Bool', 'nextRetryAt': 'Date', 'filters': 'Objeto',
         'recipients': 'Objeto', 'schedule': 'Objeto', 'byPurpose': 'Objeto', 'byType': 'Objeto', 'locale': 'String',
         'quietHours': 'Objeto', 'invoiceDigital': 'Objeto', 'targetTenants': 'String o String[]', 'permanence': 'enum',
         'addressMasked': 'String', 'liftEvidenceRef': 'String (objeto privado)', 'qr': 'Objeto', 'area': 'enum',
         'priority': 'Int', 'fileObjectKey': 'String (objeto privado)', 'counts': 'Objeto', 'estimatedCost': 'Objeto[]',
         'resolvedChannels': 'enum[]', 'excludedReason': 'enum', 'whatsapp': 'Objeto', 'bodyHtml': 'String (bloques)',
         'bodyText': 'String', 'subject': 'String', 'preheader': 'String', 'imageRef': 'String (objeto privado)',
         'attachments': 'Objeto[]', 'variablesUsed': 'String[]', 'smsStats': 'Objeto', 'changeNote': 'String',
         'throttle': 'Objeto', 'circuitBreaker': 'Objeto', 'health': 'Objeto', 'bccForBulk': 'String[] (email)',
         'appeal': 'Objeto', 'actors': 'Objeto', 'totals': 'Objeto', 'variants': 'Objeto[]', 'posts': 'Objeto[]',
         'lede': 'String', 'greetingTemplate': 'String', 'answers': 'Objeto[]', 'alerts': 'Objeto[]', 'context': 'Objeto',
         'scoreByGroup': 'Objeto', 'location': 'Objeto', 'reminders': 'Objeto[]', 'changeLog': 'Objeto[]',
         'counters': 'Objeto', 'config': 'Objeto', 'riskThresholds': 'Objeto', 'categoryActions': 'Objeto',
         'sanctionLadder': 'Objeto[]', 'slaMinutes': 'Objeto', 'kind': 'enum', 'status': 'enum', 'channel': 'enum',
         'reason': 'enum', 'code': 'String', 'number': 'String', 'date': 'Date (día en zona del tenant)'}
CH = 'enum[] de canal (`email`, `sms`, `whatsapp`, `push`, `in_app`, …)'
TF = {
    'defaultChannels': 'enum[] `landing`, `members`, `employees`', ('greetingRules', 'channels'): 'enum[] `landing`, `members`, `employees`',
    ('newsletterRules', 'channels'): 'enum[] `email`, `in_app`', ('surveyInvitations', 'channels'): CH,
    ('internalNotificationRules', 'channels'): CH, 'reaction': 'String (clave)', 'defaultMode': 'enum `pre`, `ai_assisted`, `post`',
    'categoryActions': 'Objeto (mapa)', 'revokeReason': 'String', 'calendarWeekdays': 'Int[] (1–7)',
    'types': 'enum[] (tipos de publicación, RF-COM-005)', 'posts': 'Objeto[]', 'fingerprint': 'String',
    'deliveryStatus': 'enum (estados de `communications`, §8.10)', 'invalidReason': 'String', 'scoreBand': 'String',
    ('surveyTemplates', 'purpose'): 'enum (valores de `surveys.purpose`)', 'purpose': 'enum de finalidad (§3)',
    'questions': 'Objeto[] (subesquema de `surveys.questions`)', 'pages': 'Objeto[]', 'conditions': 'String',
    'resolvedChannels': CH, 'variablesUsed': 'String[]', 'themeVersion': 'String (versión de tema T03)',
    'dictionaryVersion': 'String', 'key': 'String', 'providerModule': 'String (código de módulo)',
    'communicationTypeCodes': 'String[]', 'module': 'String (código de módulo)', 'fromAddress': 'String',
    'replyTo': 'String (email)', 'providerKind': 'enum (por canal)', 'bccForBulk': 'String[] (email)',
    'billingPeriods': 'String[] (`yyyymm`)', 'newsletterMaxPerWeek': 'Int', 'since': 'Date', 'until': 'Date',
    'refType': 'String', 'senderDisplay': 'String', 'validUntil': 'Date', 'endpointHash': 'String (hash)',
    'keys': 'Objeto (cifrado)', 'path': 'String (ruta de la variable)', ('pushSubscriptions', 'endpoint'): 'String (hash)', 'targetTenants': 'String (`all`) u ObjectId[]', 'targetRoles': 'String[] (códigos de rol T02)',
}
SYSTEM = re.compile(r'^(counters|totals|rowsTotal|rowsMatched|rowsUnmatched|lastCount|lastEvaluatedAt|lastRunAt|nextRunAt|lastRunKey|'
                    r'clicks|firstClickAt|health|lastSuccessAt|failures|smsStats|variablesUsed|remindersSent|sentCount|'
                    r'scoreTotal|scoreByGroup|scoreBand|attemptNumber|receivedAt|syncedAt|number|counts|estimatedCost|'
                    r'impressions|views|uniqueViewers|reactionsByKey|comments|shares|count|segments|conversations|costAmount|'
                    r'waitlistPosition|lastSnapshotId)$')


def split_top(s, sep=','):
    out, depth, cur, tick = [], 0, '', False
    for ch in s:
        if ch == '`':
            tick = not tick
        if not tick:
            if ch in '({[':
                depth += 1
            elif ch in ')}]':
                depth -= 1
        if ch == sep and depth == 0 and not tick:
            out.append(cur); cur = ''
        else:
            cur += ch
    out.append(cur)
    return [x.strip() for x in out if x.strip()]


def split_fields_rest(body):
    """separa la lista de campos del resto (primer '. ' en profundidad 0)."""
    depth, tick = 0, False
    for i, ch in enumerate(body):
        if ch == '`':
            tick = not tick
        if tick:
            continue
        if ch in '({[':
            depth += 1
        elif ch in ')}]':
            depth -= 1
        elif ch == '.' and depth == 0 and (i + 1 == len(body) or body[i + 1] == ' '):
            return body[:i], body[i + 1:].strip()
    return body, ''


def uniq_fields(rest):
    u = set()
    for m in re.finditer(r'[ÚU]nic[oa]s?[^`]*`\{([^}]*)\}`', rest):
        for f in re.findall(r'[A-Za-z.]+', m.group(1)):
            u.add(f.split('.')[0])
    return u


def build(coll, body_fields, rest, intro_note=''):
    types = ent.get(coll, {})
    uq = uniq_fields(rest)
    rows = []
    for item in split_top(body_fields):
        m = re.match(r'^`([A-Za-z]+)(\[\])?`(.*)$', item, re.S)
        if not m:
            print('  item sin nombre', coll, item[:60]); continue
        name, arr, extra = m.group(1), m.group(2) or '', m.group(3).strip()
        alt = []
        while True:
            ma = re.match(r'^(?:/ ?|o )`([A-Za-z]+)`\s*', extra)
            if not ma:
                break
            alt.append(ma.group(1)); extra = extra[ma.end():]
        desc = extra
        tp = None
        mt = types.get(name)
        if mt and mt[0] != 'any':
            tp = TYPEMAP.get(mt[0], mt[0])
        enums = None
        mm = re.match(r'^\((`[^()]*`(?:, `[^()]*`)*)\)', extra)
        if mm and all(x.strip().startswith('`') for x in mm.group(1).split(',')):
            enums = mm.group(1)
        if extra.startswith('{'):
            tp = 'Objeto'
        if extra.startswith('[{'):
            tp = 'Objeto[]'
        if enums and (tp in (None, 'enum', 'String', 'enum[]') or name in ('status', 'kind')):
            tp = ('enum[] ' if (tp == 'enum[]' or name.endswith('s') and name in ('channels', 'types')) else 'enum ') + enums
            desc = extra[len(mm.group(0)):].strip()
        if tp in (None, 'Array', 'String') and not arr and not enums:
            g = None
            if re.search(r'(Count|Hours|Days|Minutes|Number|Pct|Total|Matched|Unmatched|Sent|Quota|Size|Length|PerHour|Threshold|Seconds|Sec)$', name) or \
                    name in ('impressions', 'views', 'uniqueViewers', 'comments', 'shares', 'count', 'segments', 'companions',
                             'capacity', 'maxCompanions', 'rowNumber', 'versionNumber', 'ruleVersion', 'failures', 'postCount',
                             'maxLength', 'maxAttempts', 'ttlHours', 'dailyCapPerRecipient', 'smsMaxChars', 'lastCount', 'clicks',
                             'waitlistPosition', 'attemptNumber', 'surveyVersion', 'remindersSent', 'conversations'):
                g = 'Int'
            elif re.search(r'^(is|has|can|allow|require|include)[A-Z]|Enabled$|^(active|enabled|default|included|isExternal|canEmail|avoidRepeats|visibleInApp|ledeAi|legalHold|actionPending|sampledIn|whatsappSessionOnlyFromCrm|allowEditTemplateOnSingleSend|suggestedBySystem|system|sensitive|pinned|validationLinkEnabled|waitlistEnabled|overridden|requireReview)$', name):
                g = 'Bool'
            elif name.endswith('Time') or name in ('from', 'to'):
                g = 'String (HH:mm)'
            elif name == 'timezone':
                g = 'String (zona IANA)'
            elif name in ('version', 'guidelinesVersion', 'textVersion', 'consentVersion'):
                g = 'String'
            elif name in ('period',):
                g = 'String (`yyyymm`)'
            elif name in ('dayKey',):
                g = 'String (`yyyymmdd`)'
            elif name in ('at',):
                g = 'Date'
            elif name.endswith('Key') or name.endswith('Hash') or name.endswith('Token') or name.endswith('Code') or name.endswith('Name') or name.endswith('Label'):
                g = 'String'
            if g:
                tp = g
        if tp is None:
            tp = GUESS.get(name)
        if tp is None and name.endswith('Id'):
            tp = 'ObjectId'
        if tp is None and name.endswith('Ids'):
            tp = 'ObjectId[]'
        if tp is None and name.endswith('At'):
            tp = 'Date'
        if tp is None:
            tp = '[VERIFICAR]'
        newname = RENAME.get((coll, name))
        shown = newname or name
        notes = []
        if newname:
            notes.append('antes `%s`; nombre según T05' % name)
        ref = MANUAL.get((coll, shown)) or MANUAL.get((coll, name)) or xref.get((coll, shown)) or xref.get((coll, name))
        if not ref and mt and mt[1] == 'FK':
            c = mt[2]
            m2 = re.match(r'→ ([A-Za-z]+)', c)
            if m2 and m2.group(1) in COLID:
                ref = '`%s` (%s, T09)' % (m2.group(1), COLID[m2.group(1)])
        if (coll, name) in NOREF:
            ref = '—'; notes.append(NOREF[(coll, name)])
        if not ref:
            ref = '[VERIFICAR] destino no declarado' if (name.endswith('Id') or name.endswith('Ids')) and name not in ('clientMutationId',) else '—'
        if shown in uq or name in uq or shown in ('code', 'name', 'title', 'status', 'kind', 'channel') or \
                (rows == [] and shown.endswith('Id')):
            ob = 'Sí'
        elif SYSTEM.match(shown):
            ob = 'Sistema'
        else:
            ob = 'No'
        if arr and tp in ('[VERIFICAR]', 'ObjectId', 'String', 'enum', 'Array'):
            tp = {'ObjectId': 'ObjectId[]', 'String': 'String[]', 'enum': 'enum[]'}.get(tp, 'Array')
            if name.endswith('Ids'):
                tp = 'ObjectId[]'
        if arr and tp.startswith('enum ') and not tp.startswith('enum[]'):
            tp = 'enum[] ' + tp[5:]
        tf = TF.get((coll, name)) or TF.get(name)
        if tf and tp in ('[VERIFICAR]', 'Array', 'String', 'enum[]'):
            tp = tf
        if name in ('taxId', 'clientMutationId'):
            tp = 'String'
        if name in ('providerMessageId', 'providerEventId'):
            tp, ref = 'String', '—'
            notes.append('identificador externo del proveedor, no es referencia')
        if (coll, name) == ('appNotifications', 'refId'):
            ref = 'referencia polimórfica según `refType` (objeto del módulo emisor)'
        if (coll, name) == ('platformNoticeReads', 'tenantId'):
            ref, ob = '`tenants` (COL-PLA-01, T01)', 'Sí'
            notes.append('tenant lector; la colección es de plataforma')
        if (coll, name) == ('messageTemplates', 'communicationTypeCode'):
            tp = 'ObjectId'
            desc = 'Tipo de comunicación. Las plantillas de campaña o de texto libre, que antes usaban los valores `campaign`/`free` en este campo, quedan sin tipo y se distinguen por `channel` y por su uso en `campaigns` [VERIFICAR]'
        if name == 'period':
            tp = 'String (`yyyymm`)'
        if (coll, name) == ('templateVariables', 'format'):
            tp = 'String (patrón; ej. `money:ARS:2`, `date:dd-mm-yyyy`)'
        if name == 'label':
            tp = 'String (`dict:`)'
        if (coll, name) == ('invoiceMessages', 'billingPeriods'):
            tp = 'String[] (`yyyymm`) / Date / Date'
        if 'opcional' in desc or (coll, name) == ('messageTemplateVersions', 'title'):
            ob = 'No'
        if (coll, name) == ('audienceImportLists', 'matchBy'):
            tp, ref = 'enum', '—'
            notes.append('no es referencia; el ER la dibuja como FK a `memberships` por error')
        fn = '`%s%s`' % (shown, arr)
        for a in alt:
            fn += ' / `%s`' % a
        if desc.startswith('(') and desc.endswith(')') and desc.count('(') == 1:
            desc = desc[1:-1]
        d = desc.strip()
        if d in ('Bool', 'AudienceDefinition', 'Int', 'Date', 'String'):
            d = ''
        if notes:
            d = (d + ' ' if d else '') + '(' + '; '.join(notes) + ')'
        rows.append((fn, tp, ob, d or '—', ref))
        if newname == 'targetRef':
            rows[-1] = ('`targetRef`', 'Objeto { `type` (`comment`), `id` }', 'Sí', 'Comentario reportado (antes `commentId`; nombre según T05).', MANUAL[('contentReports', 'targetRef')])
    for (n, t, o, d) in ADD.get(coll, []):
        if not any(r[0].startswith('`%s`' % n) for r in rows):
            ref = MANUAL.get((coll, n)) or '—'
            rows.append(('`%s`' % n, t, o, d, ref))
    out = ['| Campo | Tipo | Oblig. | Descripción | Referencia |', '|---|---|---|---|---|']
    for r in rows:
        out.append('| ' + ' | '.join(x.replace('|', '\\|') if False else x for x in r) + ' |')
    return out


# ---------- localizar fichas en prosa ----------
L = txt.split('\n')
s7 = next(i for i, l in enumerate(L) if l.startswith('## 7. Modelo de datos'))
s8 = next(i for i, l in enumerate(L) if l.startswith('## 8. Estados'))
SKIP = {'consentRecords'}
newL = L[:s7]
done = []
i = s7
while i < s8:
    l = L[i]
    paras = [l]
    m = re.match(r'^\*\*`([A-Za-z]+)`\*\*(.*)$', l)
    if m and m.group(1) not in SKIP and not (i + 2 < len(L) and L[i + 2].startswith('| Campo')):
        # puede haber dos colecciones en el mismo párrafo (". **`x`**: ")
        parts = re.split(r'(?<=\.) (?=\*\*`[A-Za-z]+`\*\*)', l)
        for part in parts:
            mm = re.match(r'^\*\*`([A-Za-z]+)`\*\*(.*)$', part)
            coll, tail = mm.group(1), mm.group(2)
            if coll in SKIP:
                newL.append(part); continue
            # cabecera: hasta ':' de nivel 0
            pre, body = '', tail
            depth, tick, cut = 0, False, -1
            for k, ch in enumerate(tail):
                if ch == '`':
                    tick = not tick
                if tick:
                    continue
                if ch in '({[':
                    depth += 1
                elif ch in ')}]':
                    depth -= 1
                elif ch == ':' and depth == 0:
                    cut = k; break
            if cut >= 0:
                pre, body = tail[:cut].rstrip(), tail[cut + 1:].strip()
            else:
                print('SIN ":"', coll); newL.append(part); continue
            fields, rest = split_fields_rest(body)
            olds = []
            for (cc, old), new in RENAME.items():
                if cc != coll:
                    continue
                r2 = re.sub(r'(`\{[^}`]*)\b%s\b([^}`]*\}`)' % old, lambda mo: mo.group(1) + new + mo.group(2), rest)
                r2 = re.sub(r'(`\{[^}`]*)\b%s\b([^}`]*\}`)' % old, lambda mo: mo.group(1) + new + mo.group(2), r2)
                r2 = r2.replace('`%s`' % old, '`%s`' % new)
                if r2 != rest:
                    olds.append('`%s` → `%s`' % (old, new)); rest = r2
            if olds:
                rest += ' Índices con los nombres de T05 (antes ' + ', '.join(olds) + ').'
            head = '**`%s`**%s%s' % (coll, pre, (' (' + COLID[coll] + ')') if coll in COLID else '')
            newL.append(head)
            newL.append('')
            newL.extend(build(coll, fields, rest))
            if rest:
                newL.append('')
                newL.append(rest)
            newL.append('')
            done.append(coll)
        if newL[-1] == '':
            newL.pop()
        i += 1
        continue
    newL.append(l)
    i += 1
newL.extend(L[s8:])
print('fichas convertidas:', len(done), done)
out = '\n'.join(newL)
if DRY:
    open(BASE + r'\especificacion\_trabajo\t09_fix2_preview.md', 'w', encoding='utf-8', newline='\n').write('\n'.join(newL[s7:s7 + (len(newL) - len(L)) + (s8 - s7)]))
else:
    open(P, 'wb').write(out.encode('utf-8'))
print('líneas', len(L), '->', len(newL))
