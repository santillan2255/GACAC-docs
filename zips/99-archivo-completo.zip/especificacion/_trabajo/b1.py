﻿from conc_lib import *
p = os.path.join(ANX, 'M02-CAT-catalogo-servicios.md')
L = read(p).split('\n')
s = next(i for i,l in enumerate(L) if l.startswith('### 12.1 Eventos emitidos'))
e = next(i for i,l in enumerate(L) if l.startswith('### 12.2 '))
n = 0
for i in range(s, e):
    l = L[i]
    if l.startswith('| Evento | Cuándo'):
        L[i] = '| EVT-ID | Evento | Cuándo | Payload mínimo | Consumidores |'
    elif l.startswith('|---|---|---|---|'):
        L[i] = '|---|---|---|---|---|'
    elif l.startswith('| `cat.'):
        n += 1
        L[i] = '| EVT-CAT-%02d %s' % (n, l)
print(n)
last = max(i for i in range(s, e) if L[i].startswith('| EVT-CAT-'))
new = ['| EVT-CAT-26 | `cat.serviceCopy.prepared` | Copia autorizada y validada, antes de escribir en el tenant destino | `copyRunId`, `sourceTenantId`, `targetTenantId`, `components[]` | T04 (crea el borrador de configuración del destino, si M02 no invoca su API) |',
       '| EVT-CAT-27 | `cat.command.rejected` | Un comando recibido (por ejemplo, de M09 vía EVT-CRM-13) no se pudo ejecutar | `commandRequestId`, `command`, `contractId`, `errorCode`, `errors[]` | M09 (marca el comando `rejected` en el caso) |']
L[last+1:last+1] = new
write(p, '\n'.join(L))
