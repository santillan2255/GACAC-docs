import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from repl import apply

P = []
# DEC-043
P.append(("2. Vinculación: el socio indica DNI/CUIT + prueba (PA-IAM-12; por defecto número de cuenta/suministro + dato de un comprobante de los últimos `PRM-IAM-059` meses, o código enviado al contacto registrado de la persona en M01).",
          "2. Vinculación: el socio indica DNI/CUIT + prueba según DEC-043 (verificación del vínculo usuario-titular; PA-IAM-12): número de cuenta/suministro + dato de un comprobante de los últimos `PRM-IAM-059` meses (código de factura + documento), o código enviado al contacto registrado de la persona en M01, o validación presencial en la cooperativa registrada por un operador con evidencia; los intentos son limitados (paso 4)."))
P.append(("| `por.cuentas.vincular` | Vincular cuenta con prueba (PA-IAM-12) |",
          "| `por.cuentas.vincular` | Vincular cuenta con prueba (DEC-043, PA-IAM-12) |"))
P.append(("| RF-IAM-048 | **Registro de socio** y vinculación de cuentas con prueba (PA-IAM-12);",
          "| RF-IAM-048 | **Registro de socio** y vinculación de cuentas con prueba (DEC-043: código de factura + documento, código al contacto o validación presencial, con intentos limitados; PA-IAM-12);"))
P.append(("A validar (PA-IAM-12)", "Adoptado (DEC-043)", 0))
P.append(("- **Bloquea:** RF-IAM-048, P-IAM-15, PAN-IAM-32.\n",
          "- **Bloquea:** RF-IAM-048, P-IAM-15, PAN-IAM-32.\n- **Estado:** Respondida (DEC-043): se admiten la opción A (código de factura + documento, o código enviado al contacto) y la validación presencial de la opción C, con intentos limitados (PRM-IAM-060).\n"))
# DEC-066 / DEC-067
P.append(("- **Bloquea:** RF-IAM-026, P-IAM-09, API-IAM-17/18.\n",
          "- **Bloquea:** RF-IAM-026, P-IAM-09, API-IAM-17/18.\n- **Estado:** Respondida (DEC-066): contraseña o código OTP de 6 dígitos por correo o SMS, habilitable por tenant; sin enlace mágico (opción A).\n"))
P.append(("- **Bloquea:** RF-IAM-027, P-IAM-08, PRM-IAM-051/058.\n",
          "- **Bloquea:** RF-IAM-027, P-IAM-08, PRM-IAM-051/058.\n- **Estado:** Respondida (DEC-067): mecanismo de proveedor federado en O1; CiDi habilitable por tenant al publicar el portal (O2); nivel mínimo 2 para vincular cuentas (opción A).\n"))

# Capabilities nuevas
P.append(("| `cfg.sucursales.editar` | Sucursales | S | T-ADM | tenant |",
          "| `cfg.entidadesJuridicas.ver` | Ver entidades jurídicas del tenant (DEC-064; T04 PAN-CFG-33) | — | T-ADM, T-GER, T-CON, T-FAC, T-TES, T-RRHH, T-SIN | tenant |\n"
          "| `cfg.entidadesJuridicas.editar` | Alta, edición, entidad por defecto e inactivación de entidades jurídicas (T04 RF-CFG-134 a 139) | S | T-ADM | tenant |\n"
          "| `cfg.sucursales.ver` | Ver sucursales (T04 PAN-CFG-34) | — | Todos staff | tenant |\n"
          "| `cfg.sucursales.editar` | Sucursales (`branches` de T04, RF-CFG-140) | S | T-ADM | tenant |"))
P.append(("| `cat.plataforma.copiaServicios.ejecutar` | Copia de servicios entre tenants (sin datos personales) | S | P-ADM | global |",
          "| `cat.plataforma.copiaServicios.ejecutar` | Copia de servicios entre tenants (sin datos personales) | S | P-ADM | global |\n"
          "| `cat.contratos.cambiarRegimenMedicion` | Cambiar el régimen de medición de un contrato activo o suspendido (M02 RF-CAT-114, API-CAT-35; HUE-AG-03) | S | T-SAT (supervisor comercial) | suc / srv |"))
P.append(("| `tar.subsidios.editar` | Subsidios, tarifa social, segmentación | S D | T-FAC (edita), T-GER (aprueba) | srv |\n",
          "| `tar.subsidios.editar` | Subsidios, tarifa social, segmentación | S D | T-FAC (edita), T-GER (aprueba) | srv |\n"
          "| `pwa.planObra.ver` | Ver en la PWA el plan de cuotas de obra o de derecho propio, solo lectura (M04 API-TAR-066; HUECO-OBR-03) | — | C-SOC, C-REP (si la relación incluye `ver`) | rel |\n"))
P.append(("| `fac.exportar` | Exportar facturación | S X | T-FAC, T-GER, T-CON | tenant |\n",
          "| `fac.exportar` | Exportar facturación | S X | T-FAC, T-GER, T-CON | tenant |\n"
          "| `fac.revisionPrevia.ver` | Ver la cola de revisión previa a la autorización (M05 RF-FAC-174, PAN-FAC-47; HUE-ELE-02) | — | T-FAC, T-GER | srv |\n"
          "| `fac.revisionPrevia.aprobar` | Aprobar, devolver o excluir casos de revisión previa (M05 API-FAC-159) | S D | T-FAC (revisor distinto de quien prefacturó), T-GER | srv |\n"))
P.append(("| `tec.telefonia.tasar` | Tasación de CDR | — | T-STE, T-FAC | srv |\n",
          "| `tec.telefonia.tasar` | Tasación de CDR | — | T-STE, T-FAC | srv |\n"
          "| `tec.phone.numbering` | Numeración telefónica: prefijos, plan de numeración y portabilidad (M10 PAN-TEC-43; HUE-TEL-05) | S | T-STE | srv |\n"
          "| `tec.onCall.manage` | Turnos de guardia y escalamiento de emergencias (M10 PAN-TEC-61, API-TEC-51; HUE-GAS-05) | — | T-STE (jefe de guardia) | srv / zona |\n"
          "| `tec.waterQuality.manage` | Calidad del agua: puntos de muestreo, muestras y resultados (M10 PAN-TEC-64, API-TEC-54; PA-TEC-20) | — | T-STE (responsable de calidad del agua) | srv |\n"))
P.append(("| `cmp.facturasProveedor.aprobar` | Aprobar para pago | D $ | T-GER, T-CON | tenant |\n",
          "| `cmp.facturasProveedor.aprobar` | Aprobar para pago | D $ | T-GER, T-CON | tenant |\n"
          "| `cmp.abastecimiento.aprobar` | Aprobar el control de compra mayorista y el balance de abastecimiento (M12 RF-CMP-149 a 153; HUE-ELE-01, HUE-GAS-04) | D | T-CMP, T-GER | srv |\n"
          "| `cmp.derechosSenales.liquidar` | Liquidar derechos de señales de TV (M12 API-CMP-123/124; HUE-TV-01) | — | T-CMP | srv |\n"
          "| `cmp.derechosSenales.aprobar` | Aprobar la liquidación de derechos de señales (distinto de quien liquidó) | D | T-GER, T-CMP | srv |\n"))
apply('T02', P, 'f2-g6-t02')
