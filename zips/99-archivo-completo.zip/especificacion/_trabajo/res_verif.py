import re, glob, collections
pats = ['T01-*', 'T02-*', 'T03-*', 'T04*', 'T06-*', 'T07-*', 'T08-*', 'T10-*', 'T12-*']
files = [f for p in pats for f in glob.glob('../anexos/' + p + '.md')] + ['../00-ESPECIFICACION-MAESTRA.md', '../03-plan-de-olas-y-prompts.md']
for f in files:
    raw = open(f, 'rb').read()
    bom = raw.startswith(b'\xef\xbb\xbf')
    t = raw.decode('utf-8-sig')
    crlf = t.count('\r\n')
    moj = len(re.findall(r'Ã[\x80-\xbf¡-¿]|â€|Â[ -¿]|\ufffd', t))
    sigue = t.count('<!-- SIGUE')
    # headings duplicados
    hs = collections.Counter(l.strip() for l in t.split('\n') if re.match(r'#{2,4} \d', l))
    dup = [h for h, c in hs.items() if c > 1]
    pas = collections.Counter(re.findall(r'^### (PA-[A-Z]{3}-\d+)', t, re.M))
    dpa = [p for p, c in pas.items() if c > 1]
    print(f[11:45].ljust(36), 'BOM' if bom else '   ', 'CRLF=%d' % crlf, 'moj=%d' % moj, 'sigue=%d' % sigue, 'dupH=%s' % dup[:4], 'dupPA=%s' % dpa)
# CU definidos
allf = glob.glob('../anexos/*.md')
for cu in ['CU-IAM-11', 'CU-UXD-07', 'CU-PLA-15', 'CU-ACC-01', 'CU-ARQ-01', 'CU-SEG-01']:
    defs = []
    for f in allf:
        for l in open(f, encoding='utf-8-sig').read().split('\n'):
            if re.match(r'(\| |#{2,5} )%s\b' % cu, l):
                defs.append(f[11:20])
    print(cu, defs)
