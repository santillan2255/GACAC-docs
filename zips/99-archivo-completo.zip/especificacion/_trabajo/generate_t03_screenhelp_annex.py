#!/usr/bin/env python3
"""Genera anexo canónico T03 screenHelpArticles base desde screenhelp-borrador-nucleo.md."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "_trabajo" / "screenhelp-borrador-nucleo.md"
OUT = ROOT / "anexos" / "T03-UXD-screenhelp-base-m01-t02.md"

HEADING = re.compile(r"^### (PAN-(?:PER|IAM)-\d+) — (.+)$")
FIELD = re.compile(r"^- \*\*(Qué|Quién|Cuándo|Dónde|Por qué|Cómo|CU):\*\* (.+)$", re.I)

KEY_MAP = {
    "qué": "que",
    "quién": "quien",
    "cuándo": "cuando",
    "dónde": "donde",
    "por qué": "porQue",
    "cómo": "como",
}


def parse(src: Path) -> list[tuple[str, str, dict[str, str]]]:
    items: list[tuple[str, str, dict[str, str]]] = []
    current_id = ""
    current_title = ""
    fields: dict[str, str] = {}
    for line in src.read_text(encoding="utf-8").splitlines():
        hm = HEADING.match(line)
        if hm:
            if current_id:
                items.append((current_id, current_title, fields))
            current_id, current_title = hm.group(1), hm.group(2)
            fields = {}
            continue
        fm = FIELD.match(line)
        if fm and current_id:
            label, value = fm.group(1), fm.group(2).strip()
            if label.upper() == "CU":
                fields["cu"] = value
            else:
                k = KEY_MAP.get(label.lower(), label)
                fields[k] = value
    if current_id:
        items.append((current_id, current_title, fields))
    return items


def cu_primary(cu_line: str) -> tuple[str, str]:
    first = cu_line.split(";")[0].strip()
    m = re.match(r"([A-Z]{2,3}-[A-Z0-9-]+)", first)
    cu_id = m.group(1) if m else first
    return cu_id, cu_line


def main() -> None:
    articles = parse(SRC)
    lines = [
        "# T03b — Paquete base `screenHelpArticles` (M01 + T02 núcleo)",
        "",
        "| Campo | Valor |",
        "|---|---|",
        "| Fecha | 19-11-2026 |",
        "| Dueño lógico | T03 UXD (`screenHelpArticles`, tenant `PLATFORM`, scope `base`) |",
        "| Uso | Semilla producto para export GoodApps; ver RF-UXD-049, RN-UXD-055 |",
        "| Fuente borrador | `_trabajo/screenhelp-borrador-nucleo.md` |",
        "| Inventario | `_trabajo/inventario-screenhelp-m01-t02.md` |",
        "| Estado paquete | `draft` (publicar con `uxd.ayuda.editar` en O1) |",
        "",
        "> Este anexo **complementa** `T03-UXD-experiencia-marca-diccionario.md` §7.B.7 y §8.7. No sustituye el modelo de datos; define el contenido base de ayuda para el núcleo de export fase 3.",
        "",
        "> **Norma de implementación (DEC-111, DEC-112, DEC-110, DEC-113).** Construcción GoodApps: **.NET 10**, **ASP.NET Core**, **EF Core**, **Azure SQL** (base compartida, `TenantId` en tablas de negocio), front **React 19**, **Microsoft Azure** (Container Apps, Blob, Queue, Key Vault, Application Insights), identidad **OpenIddict**. Modelo físico: `07-modelo-relacional-azure-sql.md` y `07-catalogo-tablas-sql.md`. Checklist e impacto: `06-impacto-adaptacion-stack-goodapps.md` (**DIR-13**).",
        ">",
        "> **Lectura:** «colección» en este anexo = **entidad lógica**; tablas, columnas y FK en `07-*`. RF/RN/CU del anexo **no cambian** por el stack.",
        "",
        f"**Artículos:** {len(articles)} (cobertura completa M01 28 + T02 32).",
        "",
    ]
    for screen_id, title, f in articles:
        cu_id, cu_resumen = cu_primary(f.get("cu", "—"))
        lines.extend(
            [
                f"## `{screen_id}` — {title}",
                "",
                "| Campo | Contenido |",
                "|---|---|",
                f"| `screenId` | `{screen_id}` |",
                "| `scope` | `base` |",
                "| `status` | `draft` |",
                f"| `que` | {f.get('que', '')} |",
                f"| `quien` | {f.get('quien', '')} |",
                f"| `cuando` | {f.get('cuando', '')} |",
                f"| `donde` | {f.get('donde', '')} |",
                f"| `porQue` | {f.get('porQue', '')} |",
                f"| `como` | {f.get('como', '')} |",
                f"| `casoDeUso.cuId` | `{cu_id}` |",
                f"| `casoDeUso.resumen` | {cu_resumen} |",
                "",
            ]
        )
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUT} ({len(articles)} articles)")


if __name__ == "__main__":
    main()