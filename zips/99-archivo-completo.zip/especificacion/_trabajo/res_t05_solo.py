import sys, os, json, re, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
sys.path.insert(0, r"c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo")
import generar_er_completo as g

rows, by_id, by_name, model, vol, ttl, alt = g.build()
out = []
for owner, mo in model.items():
    for n, ent in mo["ents"].items():
        annex = [k for k, f in ent["fields"].items() if f["src"] == "anexo"]
        for k, f in ent["fields"].items():
            if f["src"] != "T05":
                continue
            out.append({"owner": owner, "col": n, "id": ent["row"]["id"], "field": k,
                        "anexo": annex, "line": ent["row"]["line"], "anchor": ent.get("line"),
                        "parsed": ent["parsed"]})
print(len(out))
json.dump(out, open(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo\res_t05_solo.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
# referencias sin destino
nod = []
for owner, mo in model.items():
    for n, ent in mo["ents"].items():
        for k, f in ent["fields"].items():
            if "fk" in f and not f["fk"]:
                nod.append((owner, n, k, f.get("fkhow")))
print(len(nod))
json.dump(nod, open(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo\res_sin_destino.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
