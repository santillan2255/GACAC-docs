import glob, os, re, sys, io, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
ROOT = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
BK = glob.glob(os.path.join(ROOT, 'anexos', 'backup-sync-T02T03T05T11-*'))[0]
MOJI = ['Ã', 'â€', '\ufffd', 'Â']


def table_issues(lines):
    out = []
    i = 0
    while i < len(lines):
        if lines[i].startswith('|') and i + 1 < len(lines) and re.match(r'^\|[\s:|-]+\|\s*$', lines[i + 1]):
            n = lines[i].replace('\\|', '').count('|')
            j = i + 2
            while j < len(lines) and lines[j].startswith('|'):
                m = lines[j].replace('\\|', '').count('|')
                if m != n:
                    out.append((j + 1, n, m))
                j += 1
            i = j
        else:
            i += 1
    return out


for pat in ['T02-*.md', 'T03-*.md', 'T05-*.md', 'T11-*.md']:
    p = glob.glob(os.path.join(ROOT, 'anexos', pat))[0]
    b = os.path.join(BK, os.path.basename(p))
    raw, rawb = open(p, 'rb').read(), open(b, 'rb').read()
    bom, bomb = raw.startswith(b'\xef\xbb\xbf'), rawb.startswith(b'\xef\xbb\xbf')
    t, tb = raw.decode('utf-8-sig'), rawb.decode('utf-8-sig')
    crlf = t.count('\r\n'); lf = t.count('\n')
    crlfb = tb.count('\r\n'); lfb = tb.count('\n')
    eol = 'CRLF' if crlf == lf else ('LF' if crlf == 0 else 'MIXTO')
    eolb = 'CRLF' if crlfb == lfb else ('LF' if crlfb == 0 else 'MIXTO')
    L = t.replace('\r\n', '\n').split('\n')
    Lb = tb.replace('\r\n', '\n').split('\n')
    moji = {m: t.count(m) - tb.count(m) for m in MOJI}
    ti, tib = table_issues(L), table_issues(Lb)
    # IDs definidos al inicio de fila o como encabezado de PA
    ids = collections.Counter()
    for l in L:
        m = re.match(r'^\| ((?:COL|CU|RF|RN|EVT|API|PAN|CTR|JOB|PRM|SM|CMD)-[A-Z0-9]+-[\w.]+) \|', l)
        if m: ids[m.group(1)] += 1
        m = re.match(r'^### (PA-[A-Z]+-\d+)', l)
        if m: ids[m.group(1)] += 1
    idsb = collections.Counter()
    for l in Lb:
        m = re.match(r'^\| ((?:COL|CU|RF|RN|EVT|API|PAN|CTR|JOB|PRM|SM|CMD)-[A-Z0-9]+-[\w.]+) \|', l)
        if m: idsb[m.group(1)] += 1
        m = re.match(r'^### (PA-[A-Z]+-\d+)', l)
        if m: idsb[m.group(1)] += 1
    dup = sorted(k for k, v in ids.items() if v > 1 and v > idsb.get(k, 0))
    print(os.path.basename(p))
    print('  BOM %s (antes %s), EOL %s (antes %s), líneas %d (antes %d)' % (bom, bomb, eol, eolb, len(L), len(Lb)))
    print('  mojibake nuevo:', {k: v for k, v in moji.items() if v})
    print('  tablas con columnas distintas: %d (antes %d); nuevas: %s' % (len(ti), len(tib), [x for x in ti if x[0] > 0][:0] or len(ti) - len(tib)))
    print('  IDs duplicados nuevos:', dup)
    print('  PA nuevas:', sorted(set(k for k in ids if k.startswith('PA-')) - set(idsb)))
    if pat.startswith('T05'):
        cat = [l for l in L if re.match(r'^\| COL-[A-Z]+-\d+ \|', l)]
        est = collections.Counter(l.split(' | ')[-1].rstrip(' |').split(' ')[0] for l in cat)
        print('  filas catálogo %d; Est.: %s' % (len(cat), dict(est)))
        print('  crear (C/N/R): %d' % sum(v for k, v in est.items() if k in ('C', 'N', 'R')))
        for x in ti:
            if x not in tib: print('  tabla nueva con problema:', x)
