﻿from conc_lib import *
import re
want = {'M01':['JOB-PER-02','JOB-PER-05','JOB-PER-10'],'M04':['JOB-TAR-11','JOB-TAR-05'],'M05':['JOB-FAC-10'],'M06':['JOB-FIS-08','JOB-FIS-17'],'M09':['JOB-CRM-01','JOB-CRM-15','JOB-CRM-18'],'M10':['JOB-TEC-08','JOB-TEC-09','JOB-TEC-10'],'M14':['JOB-TES-14'],'T01':['JOB-PLA-04'],'T06':['JOB-INT-23','JOB-INT-27'],'T08':['JOB-NFR-05','JOB-NFR-12','JOB-NFR-19','JOB-NFR-21'],'M16':['JOB-SUE-04','JOB-SUE-06','JOB-SUE-19']}
for code, ids in want.items():
    f = [x for x in files() if os.path.basename(x).startswith(code+'-')][0]
    L = read(f).split('\n')
    for i,l in enumerate(L):
        for j in ids:
            if re.match(r'^\|\s*[`*]*%s\b' % j, l) or (j in l and l.startswith('JOB')):
                print('%s:%d: %s' % (code, i+1, l[:700]))
