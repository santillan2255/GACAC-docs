import re
from pathlib import Path

p = next((Path(__file__).resolve().parents[2] / 'entregables-analisis-diseno').glob('28-*.md'))
NOTAS = {
    '02': 'RNF-NFR-199 exige render aislado: contenedor sin privilegios, sin red de salida, recursos inyectados, JavaScript deshabilitado y límites de tiempo y memoria.',
    '03': 'RNF-NFR-258 fija CA privada con emisor por tenant, vigencia 90 días, renovación automática desde 30 días antes y revocación efectiva en menos de 5 minutos.',
    '04': 'RF-INT-053 toma el tenant de la conexión dueña del `endpointKey`; slug distinto = 404 sin procesar y auditado.',
    '05': 'RF-MIG-010 exige conexión saliente cifrada desde la red de la cooperativa o backup cifrado con URL prefirmada de un solo uso; SQL Server nunca expuesto.',
    '07': 'RN-MIG-013 dice ahora que se regeneran en cada proveedor y solo el valor nuevo entra a la bóveda.',
    '09': 'RNF-NFR-056 adopta `salud`, `laboral`, `judicial`, `financiero` y `secreto` con los nombres `dek-<categoría>` de T05.',
    '10': 'RF-PLA-023 y T05 §7.1.3 tienen la misma lista; T05 suma la fila de configuración de plataforma.',
    '11': 'RNF-NFR-061 alineado con RF-IAM-040: 12 para personal (8 con MFA obligatoria), 10 para socios, máximo 128.',
    '12': 'T01 (DNS/TLS) exige retirar ruta y certificado, control diario de CNAME colgantes y nueva verificación TXT para reasignar.',
    '13': 'RNF-NFR-095 ubica el pentest antes de la primera salida con datos reales de socios y antes del corte comercial de LAG (DEC-089).',
    '14': 'RF-PLA-054 crea la semilla mínima de TEN-001 y TEN-002 desde O0 para RF-PLA-034.',
}
crudo = p.read_bytes()
bom = crudo.startswith(b'\xef\xbb\xbf')
texto = crudo.decode('utf-8-sig')
nl = '\r\n' if '\r\n' in texto else '\n'
lineas = texto.split(nl)
hechas = 0
for i, l in enumerate(lineas):
    m = re.match(r'^\| OBS-TM-(\d\d) \|', l)
    if not m or m.group(1) not in NOTAS or 'Resuelta (DEC-092)' in l:
        continue
    j = l.rstrip().rstrip('|').rstrip().rfind(' | ')
    lineas[i] = l[:j] + f' **Resuelta (DEC-092):** {NOTAS[m.group(1)]}' + l[j:]
    assert lineas[i].count('|') == l.count('|')
    hechas += 1
p.write_bytes((b'\xef\xbb\xbf' if bom else b'') + nl.join(lineas).encode('utf-8'))
print('marcadas', hechas)
