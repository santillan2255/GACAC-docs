﻿from repl import *
apply('M01', [
 ('(`per.account.created`, `cat.category.changed`, `tec.workOrder.closed`)', '(`per.account.created`, `cat.contract.categoryChanged`, `tec.workOrder.closed`)'),
 ('| `tec.location.proposed` | M10 / app de campo |', '| `tec.geo.pointUpdated` (EVT-TEC-30) | M10 / app de campo |'),
 ('| `ins.membership.changed` | M17 |', '| `ins.membership.approved` / `.suspended` / `.reinstated` / `.exited` (EVT-INS-02/04/06) | M17 |'),
 ('| `col.legalStatus.changed` | M08 |', '| `mor.collectionCase.opened` / `.closed` (EVT-MOR-17) | M08 |'),
 ('| `iam.user.registered` / `iam.user.deleted` | T02 |', '| `iam.identity.created` (EVT-IAM-01) / `iam.portal.accountUnlinked` (EVT-IAM-15) | T02 |'),
 ('| `ten.tenant.provisioned` | T01 |', '| `pla.tenant.created` (EVT-PLA-01) | T01 |'),
])
apply('M03', [
 ('| `cat.category.changed` (servicio) | M01/M02 |', '| `cat.contract.categoryChanged` (EVT-CAT-19) | M02 |'),
 ('| `stk.serialItem.statusChanged` | M13 |', '| `stk.equipment.applied` / `stk.equipment.retrieved` / `stk.equipment.swapped` (EVT-STK-04/05/06) | M13 |'),
 ('| `fac.invoice.issued` / `fac.invoice.voided` | M05 |', '| `fac.invoice.issued` (EVT-FAC-07) / `fac.invoice.annulled` (EVT-FAC-08) | M05 |'),
 ('| `mor.disconnection.ordered` / `mor.reconnection.ordered` | M08 |', '| `mor.interruption.approved` (EVT-MOR-12; tipo corte o reconexión en el payload) | M08 |'),
])
apply('M04', [
 ('| `cat.contract.activated` / `tec.installation.completed` según', '| `cat.contract.activated` / `tec.installation.activationConfirmed` según'),
 ('(`fac.invoice.voided`). |', '(`fac.invoice.annulled`). |'),
 ('Si M05 anula el comprobante (`fac.invoice.voided`)', 'Si M05 anula el comprobante (`fac.invoice.annulled`, EVT-FAC-08)'),
 ('| `fac.invoice.voided` | M05 |', '| `fac.invoice.annulled` (EVT-FAC-08) | M05 |'),
 ('| `fac.batch.discarded` | M05 |', '| `fac.billingRun.discarded` (EVT-FAC-21) | M05 |'),
 ('| `cat.plan.changed` | M02 |', '| `cat.contract.planChanged` (EVT-CAT-18) | M02 |'),
 ('| `tec.installation.completed` | M10 |', '| `tec.installation.activationConfirmed` (EVT-TEC-16) | M10 |'),
 ('| `tec.workOrder.confirmed` (cambio de categoría) | M10 |', '| `tec.workOrder.closed` (EVT-TEC-07; OT de cambio de categoría) | M10 |'),
 ('emite `tec.cdr.imported` con el lote', 'emite `tec.cdr.attributed` (EVT-TEC-27) con el lote'),
 ('| `tec.cdr.imported` | M10 |', '| `tec.cdr.attributed` (EVT-TEC-27) | M10 |'),
 ('| Al recibir `tec.cdr.imported`;', '| Al recibir `tec.cdr.attributed` (EVT-TEC-27);'),
 ('| `fis.taxConfig.published` | M06 |', '| `fis.normativeAdoption.approved` (EVT-FIS-10) | M06 |'),
 ('| `cfg.parameter.published` | T04 |', '| `cfg.parameter.changed` (EVT-CFG-07) | T04 |'),
 ('| `cfg.fxRate.published` / `cfg.inflationIndex.published` | T04 |', '| `tes.exchangeRate.published` (EVT-TES-19) / `cfg.economicIndex.valuePublished` (EVT-CFG-12) | M14 / T04 |'),
])
apply('M05', [
 ('responde con eventos `fis.invoice.*`;', 'responde con `fis.invoice.authorized` y `fis.authorization.*` (EVT-FIS-01 a EVT-FIS-04);'),
 ('| `fis.invoice.authorized` / `fis.invoice.observed` / `fis.invoice.rejected` / `fis.invoice.uncertain` | M06 |', '| `fis.invoice.authorized` / `fis.authorization.detained` / `fis.authorization.rejected` / `fis.authorization.uncertain` (EVT-FIS-01/03/02/04) | M06 |'),
 ('| `med.consumption.approved` / `med.consumption.revoked` | M03 |', '| `med.consumption.approved` (EVT-MED-11) / `med.consumption.voided` (EVT-MED-13) | M03 |'),
 ('| `cat.contract.updated` / `cat.contract.terminated` | M02 |', '| `cat.contract.planChanged` / `.categoryChanged` / `.addressChanged` / `.flagChanged` (EVT-CAT-18 a EVT-CAT-21) / `cat.contract.terminated` (EVT-CAT-15) | M02 |'),
 ('| `cli.holder.taxDataChanged` | M01 |', '| `per.person.updated` (EVT-PER-02) / `per.taxId.verified` (EVT-PER-08) | M01 |'),
 ('| `mor.interestCharge.requested` | M08 |', '| `mor.deferredInterest.created` (EVT-MOR-03) | M08 |'),
 ('| `ven.installments.created` / `ven.installments.cancelled` | M11 |', '| `ven.installmentPlan.created` (EVT-VEN-11) / `ven.installment.updated` (EVT-VEN-12) | M11 |'),
 ('| `tar.version.published` | M04 |', '| `tar.schedule.published` (EVT-TAR-004) | M04 |'),
])
apply('M06', [
 ('| `cob.payment.confirmed` / `cob.allocation.applied` | M07 |', '| `cob.payment.confirmed` (EVT-COB-04) / `cob.allocation.reversed` (EVT-COB-06) | M07 |'),
 ('| `cmp.paymentOrder.prepared` / `approved` / `cancelled` | M12/M14 |', '| `cmp.paymentOrder.prepared` / `.approved` / `.cancelled` (EVT-CMP-15/11/12) | M12 |'),
 ('| `tes.movement.confirmed` | M14 |', '| `tes.paymentExecution.executed` (EVT-TES-15) / `tes.operation.posted` (EVT-TES-01) | M14 |'),
 ('| `per.person.fiscalDataChanged` | M01/M12 |', '| `per.person.updated` / `per.taxId.verified` / `.mismatch` (EVT-PER-02/08), `cmp.supplier.updated` (EVT-CMP-01) | M01/M12 |'),
 ('| `con.journalEntry.posted` | M15 |', '| `con.entry.posted` (EVT-CON-01) | M15 |'),
 ('| `sue.payroll.closed` | M16 |', '| `sue.payrollRun.closed` (EVT-SUE-13) | M16 |'),
 ('| `pla.tenant.restored` | T01 |', '| `pla.restore.completed` (EVT-PLA-14) | T01 |'),
])
