﻿$ErrorActionPreference = 'Stop'
$dir = 'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
$order = 'T01','T02','T03','T04','T06','T07','T08','T09','T10','M01','M02','M03','M04','M05','M06','M07','M08','M09','M10','M11','M12','M13','M14','M15','M16','M17','M18','M19'
$utf8 = New-Object System.Text.UTF8Encoding($false)

function Clean([string]$s, [int]$max) {
  if ($null -eq $s -or $s.Trim() -eq '') { return '—' }
  $s = $s.Trim() -replace '\s+', ' '
  $s = $s -replace '\*\*', ''
  if ($s.Length -gt $max) {
    $cut = $s.Substring(0, $max)
    $bt = ([regex]::Matches($cut, '`')).Count
    if ($bt % 2 -eq 1) { $cut = $cut + '`' }
    $s = $cut.TrimEnd() + '…'
  }
  return $s
}

function QueueOf([string]$txt, [string]$declared) {
  $d = "$declared".ToLower()
  if ($d -match 'realtime') { return 'events' }
  if ($d -match '(interactive|integration|events|notifications|batch|export|maintenance)') { return $Matches[1] }
  if ($d -match '(^|[^a-z])ai([^a-z]|$)') { return 'ai' }
  $t = $txt.ToLower()
  if ($t -match 'outbox|relay') { return 'events' }
  if ($t -match 'backup|purg|depur|limpi|archivar|retenci|anonimiz|restaur|medir-uso|vencer-borradores|ttl|expurg') { return 'maintenance' }
  if ($t -match '(^|[^a-z])ia([^a-z]|$)|extraer|clasificar-ia|moderar|ai-|asistente|transcrib') { return 'ai' }
  if ($t -match 'arca|(^|[^a-z])cae|wsfe|wsaa|pasarela|webhook|sincroniz|aprovision|radius|mikrotik|(^|[^a-z])olt|interbanking|red link|siro|pagos360|mercado ?pago|remot|importar-ami|(^|[^a-z])firma|conector|geocod|cuit|consultar-|enacom|ersep|cidi|encustody|(^|[^a-z])gps|(^|[^a-z])avl|(^|[^a-z])cdr|smtp|imap|extracto') { return 'integration' }
  if ($t -match 'notific|aviso|avisar|recordar|recordatorio|enviar|envio|envío|distribuir|invitar|alertas?-|alerta |newsletter|campa') { return 'notifications' }
  if ($t -match 'export|reporte|snapshot|indicador|tablero|libro|bi-|dataset|benchmark') { return 'export' }
  return 'batch'
}

function KindOf([string]$trig) {
  $t = $trig.ToLower(); $k = @()
  if ($t -match 'diari|mensual|semanal|anual|cada |cada\d|horari|nocturn|\d{1,2}:\d{2}|continuo|cron|trimestral|quincenal|programad|por hora|minuto|cierre de d') { $k += 'P' }
  if ($t -match 'evento|`[a-z]{3}\.|^al |^tras |aprobad|confirmad|al cerrar|al aprobar|al recibir|al registrar|al emitir|al confirmar|al publicar|al completar|alta |cambio ') { $k += 'E' }
  if ($t -match 'demanda|pedido|manual|comando|usuario|bot[oó]n|solicitud') { $k += 'D' }
  if ($k.Count -eq 0) { $k += 'E' }
  return ($k -join '+')
}

$evt = [ordered]@{}; $job = [ordered]@{}; $foreign = @{}
foreach ($code in $order) {
  $f = Get-ChildItem $dir -Filter "$code-*.md" | Where-Object { $_.Name -notlike 'T04b*' } | Select-Object -First 1
  if (-not $f) { continue }
  $L = [IO.File]::ReadAllLines($f.FullName, [Text.Encoding]::UTF8)
  for ($i = 0; $i -lt $L.Count; $i++) {
    $line = $L[$i]
    $m = [regex]::Match($line, '^\|\s*[`*]*((EVT|JOB)-[A-Z]{3}-[0-9]+)')
    if (-not $m.Success) { continue }
    $id = $m.Groups[1].Value; $kind = $m.Groups[2].Value
    $fileCode = $f.BaseName.Split('-')[1]
    if ($id.Split('-')[1] -ne $fileCode) { $foreign["$id"] = "$code L$($i + 1)"; continue }
    $j = $i; while ($j -gt 0 -and $L[$j] -notmatch '^\|\s*:?-{3}') { $j-- }
    $hdr = ($L[$j - 1] -replace '\\\|', '¦').Trim().Trim('|').Split('|') | ForEach-Object { $_.Trim() }
    $cells = ($line -replace '\\\|', '¦').Trim().Trim('|').Split('|') | ForEach-Object { $_.Trim() -replace '¦', '/' }
    $rec = @{ id = $id; src = $code; line = $i + 1; name = ''; trig = ''; desc = ''; cons = ''; cola = '' }
    for ($c = 0; $c -lt $hdr.Count -and $c -lt $cells.Count; $c++) {
      $h = $hdr[$c].ToLower(); $v = $cells[$c]
      if ($c -eq 0) {
        $rest = ($v -replace [regex]::Escape($id), '' -replace '^[`\s]+|[`\s]+$', '').Trim()
        $rest = ($v -replace ('`?' + [regex]::Escape($id) + '`?'), '').Trim()
        if ($rest -match '`') { $rec.name = $rest }
        continue
      }
      if (-not $rec.name -and $h -match '^(evento|tipo|nombre|nombre bullmq|job|cola / nombre|cola `tar)') { $rec.name = $v; continue }
      if ($h -match '^cola$' ) { $rec.cola = $v; continue }
      if ($h -match 'consumidor') { $rec.cons = $v; continue }
      if ($h -match 'productor') { continue }
      if (-not $rec.trig -and $h -match 'cu.ndo|disparador|disparo|frecuencia') { $rec.trig = $v; continue }
      if (-not $rec.desc -and $h -match 'descripci|qu. hace|detalle|pasos') { $rec.desc = $v; continue }
      if ($h -match '^frecuencia$' -and $rec.trig) { $rec.trig = $rec.trig + '; ' + $v; continue }
    }
    if ($kind -eq 'EVT' -and -not $rec.trig) {
      for ($c = 0; $c -lt $hdr.Count -and $c -lt $cells.Count; $c++) { if ($hdr[$c].ToLower() -match 'payload|carga|datos') { $rec.trig = 'Payload: ' + $cells[$c]; break } }
    }
    $store = if ($kind -eq 'EVT') { $evt } else { $job }
    if ($store.Contains($id)) {
      $o = $store[$id]
      foreach ($k in 'name', 'trig', 'desc', 'cons', 'cola') { if (-not $o[$k] -and $rec[$k]) { $o[$k] = $rec[$k] } }
    } else { $store[$id] = $rec }
  }
}

function ExpandNames([string]$cell) {
  $out = @(); $base = ''
  foreach ($m in [regex]::Matches($cell, '`([^`]+)`')) {
    $t = $m.Groups[1].Value.Trim()
    if ($t -match '^[a-z]{3}\.[A-Za-z]+\.[A-Za-z.]+$') { $p = $t.Split('.'); $base = $p[0] + '.' + $p[1]; $out += ($p[0] + '.' + $p[1] + '.' + $p[2]) }
    elseif ($base -and $t -match '^\.?[a-z][A-Za-z]+$') { $out += ($base + '.' + $t.TrimStart('.')) }
  }
  return $out
}

# Eventos sin ID: M02 §12.1, T09 y T10 (registrados por T11 con EVT-WFL-1xx)
$noid = New-Object System.Collections.ArrayList
$m02 = Get-ChildItem $dir -Filter 'M02-*.md' | Select-Object -First 1
$L2 = [IO.File]::ReadAllLines($m02.FullName, [Text.Encoding]::UTF8)
$in = $false
for ($i = 0; $i -lt $L2.Count; $i++) {
  if ($L2[$i] -match '^### 12\.1') { $in = $true; continue }
  if ($in -and $L2[$i] -match '^### ') { break }
  if ($in -and $L2[$i] -match '^\|\s*`cat\.') {
    $cells = ($L2[$i] -replace '\\\|', '¦').Trim().Trim('|').Split('|') | ForEach-Object { $_.Trim() }
    $null = $noid.Add(@{ src = 'M02'; name = $cells[0]; trig = $cells[1]; cons = $cells[3]; ref = "M02 §12.1 L$($i + 1)" })
  }
}
$static = @(
  @{ src = 'T09'; name = '`com.post.published`'; trig = 'Publicación del muro publicada (con o sin `notifyAudience`)'; cons = 'T09 (`com:notificar-publicacion`), M19 (muro del portal), T10'; ref = 'T09 §8, §9 paso 6' },
  @{ src = 'T09'; name = '`com.comment.replied`'; trig = 'Respuesta institucional o de otro usuario a un comentario'; cons = 'T09 (aviso in-app al autor)'; ref = 'T09 tipo 81 (en RF figura `com.comment.reply`)' },
  @{ src = 'T09'; name = '`com.comment.moderated`'; trig = 'Comentario ocultado o rechazado por moderación'; cons = 'T09 (aviso al autor), T02 (auditoría)'; ref = 'T09 §8 moderación, tipo 82' },
  @{ src = 'T09'; name = '`com.report.resolved`'; trig = 'Resultado de un reporte de contenido'; cons = 'T09 (aviso al denunciante)'; ref = 'T09 tipo 83' },
  @{ src = 'T09'; name = '`com.preference.changed`'; trig = 'Cambio de preferencias o consentimientos de comunicación'; cons = 'M05 (factura digital / papel), M19, T10'; ref = 'T09 RF de preferencias, tipo 90' },
  @{ src = 'T09'; name = '`com.communication.statusChanged`'; trig = 'Estado de entrega normalizado desde webhook del proveedor'; cons = 'Módulo emisor del aviso, T10'; ref = 'T09 §9 paso 6' },
  @{ src = 'T09'; name = '`com.communication.milestoneReached`'; trig = 'La comunicación alcanzó el estado exigido (`proofRequired`)'; cons = 'Módulo emisor (M08 habilita corte, M05, M09), T11 (constancia al expediente)'; ref = 'T09 §9 paso 9; AGR-024' },
  @{ src = 'T09'; name = '`com.communication.failed`'; trig = 'No se alcanzó el hito en plazo o falló definitivamente'; cons = 'Módulo emisor (reintento, otro canal, carta), T11 (tarea)'; ref = 'T09 §9 paso 9' }
)
foreach ($s in $static) { $null = $noid.Add($s) }

$own = @('wfl.definition.published','wfl.definition.retired','wfl.instance.started','wfl.instance.transitioned','wfl.instance.completed','wfl.instance.cancelled','wfl.instance.slaWarning','wfl.instance.slaBreached','wfl.instance.escalated','wfl.instance.reopened','wfl.approval.requested','wfl.approval.stepDecided','wfl.approval.decided','wfl.approval.expired','wfl.approval.withdrawn','wfl.operation.executed','wfl.operation.executionFailed','wfl.task.created','wfl.task.assigned','wfl.task.completed','wfl.task.overdue','wfl.task.cancelled','wfl.delegation.activated','wfl.delegation.revoked','wfl.document.created','wfl.document.versionAdded','wfl.document.voided','wfl.document.legalHoldChanged','wfl.document.retentionExpired','wfl.template.published','wfl.render.completed','wfl.render.failed','wfl.signature.requested','wfl.signature.completed','wfl.signature.rejected','wfl.signature.expired','wfl.dossier.created','wfl.dossier.closed','wfl.dossier.reopened','wfl.job.completed','wfl.job.failed','wfl.operationIssue.opened','wfl.operationIssue.resolved','wfl.schedule.changed','wfl.form.published')

$emittedSet = @{}
foreach ($r in $evt.Values) { foreach ($n in (ExpandNames $r.name)) { $emittedSet[$n] = $r.id } }
foreach ($r in $noid) { foreach ($n in (ExpandNames $r.name)) { $emittedSet[$n] = 'noid' } }
foreach ($n in $own) { $emittedSet[$n] = 'own' }

$mods = 'per|cat|med|tar|fac|fis|cob|mor|crm|tec|ven|cmp|stk|tes|con|sue|ins|soc|por|com|wfl|bia|int|cfg|iam|pla|uxd|nfr|mig|act'
$refs = [ordered]@{}
foreach ($code in $order) {
  $f = Get-ChildItem $dir -Filter "$code-*.md" | Where-Object { $_.Name -notlike 'T04b*' } | Select-Object -First 1
  if (-not $f) { continue }
  $txt = [IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8)
  foreach ($m in [regex]::Matches($txt, "``(($mods)\.([a-z][A-Za-z]+)\.([a-z][A-Za-z]*(ed|Ready|Due|Raised|Failed|Changed)))``")) {
    $n = $m.Groups[1].Value; $seg2 = $m.Groups[3].Value; $seg3 = $m.Groups[4].Value
    if ($emittedSet.ContainsKey($n)) { continue }
    if ($seg3 -match '(Enabled|Required|Allowed|enabled|required|allowed)$') { continue }
    if ($seg3 -match '^(include|exclude|require|cancel|hide|allow|max|first|debit|only|no[A-Z]|duplicate|debt|offer|by[A-Z]|block|open|extra|read|siro|auto|show|ignore|warn)') { continue }
    if ($seg2 -match 's$' -and $seg2 -notmatch '(status|Status)$') { continue }
    if (-not $refs.Contains($n)) { $refs[$n] = New-Object System.Collections.ArrayList }
    if (-not $refs[$n].Contains($code)) { $null = $refs[$n].Add($code) }
  }
}

$sb = New-Object System.Text.StringBuilder
$null = $sb.AppendLine('<!-- CATALOGO GENERADO DESDE LAS SECCIONES 12 DE LOS ANEXOS M01-M19, T01-T10 (4/11/2026) -->')
$null = $sb.AppendLine('')
$null = $sb.AppendLine('#### 12.A.1 Eventos de dominio emitidos por los módulos (con ID de origen)')
$null = $sb.AppendLine('')
$cnt = @{}
foreach ($code in $order) {
  $rows = @($evt.Values | Where-Object { $_.src -eq $code })
  if ($rows.Count -eq 0) { continue }
  $cnt["E$code"] = $rows.Count
  $null = $sb.AppendLine("**Emisor $code** ($($rows.Count) eventos; fuente: anexo $code §12)")
  $null = $sb.AppendLine('')
  $null = $sb.AppendLine('| EVT-ID | Evento (`type` en `outboxEvents`) | Cuándo / payload | Consumidores declarados |')
  $null = $sb.AppendLine('|---|---|---|---|')
  foreach ($r in $rows) {
    $null = $sb.AppendLine("| $($r.id) | $(Clean $r.name 140) | $(Clean $r.trig 110) | $(Clean $r.cons 130) |")
  }
  $null = $sb.AppendLine('')
}
$null = $sb.AppendLine('#### 12.A.2 Eventos emitidos sin ID en su anexo de origen (ID asignado por T11)')
$null = $sb.AppendLine('')
$null = $sb.AppendLine('M02 (§12.1), T09 y T10 publican estos eventos sin numerarlos. T11 les asigna un ID `EVT-WFL-1NN` solo para trazabilidad; el `type` (nombre) es el del anexo de origen y no cambia. Si el anexo de origen los numera en una versión posterior, se registra la equivalencia y se conserva el EVT-WFL como alias documental.')
$null = $sb.AppendLine('')
$null = $sb.AppendLine('| EVT-ID | Evento (`type`) | Emisor | Cuándo / disparo | Consumidores declarados | Fuente |')
$null = $sb.AppendLine('|---|---|---|---|---|---|')
$n = 101
foreach ($r in $noid) {
  $null = $sb.AppendLine("| EVT-WFL-$n | $(Clean $r.name 120) | $($r.src) | $(Clean $r.trig 90) | $(Clean $r.cons 120) | $($r.ref) |")
  $n++
}
$null = $sb.AppendLine('')
[IO.File]::WriteAllText("$env:TEMP\t11gen-evt.md", $sb.ToString(), $utf8)
"NOID: $($noid.Count)"

$sb = New-Object System.Text.StringBuilder
$null = $sb.AppendLine('| # | `type` referenciado por consumidores | Anexos que lo consumen o mencionan | Candidato canónico emitido (mismo módulo) | Tratamiento |')
$null = $sb.AppendLine('|---|---|---|---|---|')
$i = 1
$emittedNames = @($emittedSet.Keys)
foreach ($k in $refs.Keys) {
  $p = $k.Split('.')
  $cand = @($emittedNames | Where-Object { $_.StartsWith($p[0] + '.') -and $_.Split('.')[2] -eq $p[2] } | Select-Object -First 2)
  if ($cand.Count -eq 0) { $cand = @($emittedNames | Where-Object { $_.StartsWith($p[0] + '.' + $p[1] + '.') } | Select-Object -First 2) }
  $cs = if ($cand.Count) { ($cand | ForEach-Object { '`' + $_ + '`' }) -join ' o ' } else { '—' }
  $tr = if ($cand.Count) { 'Alias: suscribir al canónico' } else { 'Sin emisor: el módulo dueño lo agrega a su §12 o el consumidor lo retira' }
  $null = $sb.AppendLine("| $i | ``$k`` | $(($refs[$k]) -join ', ') | $cs | $tr |")
  $i++
}
[IO.File]::WriteAllText("$env:TEMP\t11gen-alias.md", $sb.ToString(), $utf8)
"ALIAS: $($refs.Count)"

$sb = New-Object System.Text.StringBuilder
$null = $sb.AppendLine('#### 12.B.1 Jobs BullMQ declarados por los módulos (con ID de origen)')
$null = $sb.AppendLine('')
$null = $sb.AppendLine('Columnas: **Tipo** de disparo `P` programado (cron por tenant, zona horaria del tenant), `E` por evento/condición, `D` a demanda (usuario o comando); **Cola** según RN-WFL-061 (si el anexo de origen declara una cola, prevalece la declarada).')
$null = $sb.AppendLine('')
foreach ($code in $order) {
  $rows = @($job.Values | Where-Object { $_.src -eq $code })
  if ($rows.Count -eq 0) { continue }
  $cnt["J$code"] = $rows.Count
  $null = $sb.AppendLine("**Módulo $code** ($($rows.Count) jobs; fuente: anexo $code §9/§12)")
  $null = $sb.AppendLine('')
  $null = $sb.AppendLine('| JOB-ID | Nombre | Disparo / frecuencia | Tipo | Cola | Descripción |')
  $null = $sb.AppendLine('|---|---|---|---|---|---|')
  foreach ($r in $rows) {
    $q = QueueOf ("$($r.name) $($r.desc)") $r.cola
    $k = KindOf $r.trig
    $null = $sb.AppendLine("| $($r.id) | $(Clean $r.name 70) | $(Clean $r.trig 80) | $k | ``$q`` | $(Clean $r.desc 120) |")
  }
  $null = $sb.AppendLine('')
}
[IO.File]::WriteAllText("$env:TEMP\t11gen-job.md", $sb.ToString(), $utf8)
"EVT total: $($evt.Count)  JOB total: $($job.Count)"
$foreign.Keys | Where-Object { -not $evt.Contains($_) -and -not $job.Contains($_) } | ForEach-Object { "SOLO FORANEO: $_ en $($foreign[$_])" }
($cnt.GetEnumerator() | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join ' '
$job.Values | Where-Object { -not $_.name } | ForEach-Object { "SIN NOMBRE: $($_.id) $($_.src) L$($_.line)" }
$evt.Values | Where-Object { -not $_.name } | ForEach-Object { "SIN NOMBRE: $($_.id) $($_.src) L$($_.line)" }
$q = @{}; $job.Values | ForEach-Object { $x = QueueOf ("$($_.name) $($_.desc)") $_.cola; if (-not $q[$x]) { $q[$x] = 0 }; $q[$x]++ }; ($q.GetEnumerator() | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join ' '
