from h import *

p, bom, crlf, t = load('M19')
t = rep(t, "/app/empleado/legajo                   PAN-POR-74 Mi legajo\n",
        "/app/empleado/legajo                   PAN-POR-74 Mi legajo\n"
        "/app/empleado/equipo                   (sin PAN-POR; incrusta PAN-SUE-44 de M16) Mi equipo (encargado), acceso desde PAN-POR-69\n"
        "/app/empleado/certificados             (sin PAN-POR; incrusta PAN-SUE-45 de M16) Mis certificados, acceso desde PAN-POR-69\n"
        "/app/empleado/evaluaciones             (sin PAN-POR; incrusta PAN-SUE-46 de M16) Mis evaluaciones, acceso desde PAN-POR-69\n")
t = rep(t, "| PAN-POR-74 | `/app/empleado/legajo` | M16 SUE | PAN-SUE-43 | API-SUE-81 | API-POR-99 |\n",
        "| PAN-POR-74 | `/app/empleado/legajo` | M16 SUE | PAN-SUE-43 | API-SUE-81 | API-POR-99 |\n"
        "| — (sin PAN-POR; acceso desde PAN-POR-69) | `/app/empleado/equipo` | M16 SUE | PAN-SUE-44 (Mi equipo del encargado; `sue.equipo.ver`) | API-SUE-83 | — (consume la API de M16) |\n"
        "| — (sin PAN-POR; acceso desde PAN-POR-69) | `/app/empleado/certificados` | M16 SUE | PAN-SUE-45 (certificados y constancias; `sue.portal.certificados.ver`) | API-SUE-82 | — (consume la API de M16) |\n"
        "| — (sin PAN-POR; acceso desde PAN-POR-69) | `/app/empleado/evaluaciones` | M16 SUE | PAN-SUE-46 (evaluaciones y objetivos propios; `sue.portal.evaluaciones.autoevaluar`) | API-SUE-84 | — (consume la API de M16) |\n")
t = rep(t, "| CU-CIC-01 | Suspensión temporal y reactivación |",
        "| CU-CIC-01 | Suspensión temporal y reactivación (definición dueña: M08 «CU-CIC-01 — Suspensión temporal y reactivación de Internet», PA-MOR-21; aquí solo el tramo del portal) |")
save(p, bom, crlf, t)

p, bom, crlf, t = load('M16')
for n, r in (('44', 'equipo'), ('45', 'certificados'), ('46', 'evaluaciones')):
    t = rep(t, f"M19 la publica como `/app/empleado/{r}`, con acceso desde PAN-POR-69; sin PAN-POR propia, que incrusta esta pantalla; PA-SUE-16)",
            f"M19 la publica como `/app/empleado/{r}` con acceso desde PAN-POR-69 e incrusta esta pantalla sin PAN-POR propia (M19 §10.3 y §10.6.A); PA-SUE-16)")
save(p, bom, crlf, t)
print('ok')
