from h import *

p, bom, crlf, t = load('M16')
n = 0
t = rep(t, "`sue.rrhh.evaluaciones.*`, `sue.rrhh.objetivos.*`, `sue.rrhh.sanciones.*`, `sue.rrhh.sumarios.*`, `sue.rrhh.accidentes.*`, `sue.datosSensibles.ver` |",
        "`sue.rrhh.evaluaciones.ver/editar`, `sue.rrhh.objetivos.ver/editar`, `sue.rrhh.sanciones.ver/editar`, `sue.rrhh.sumarios.ver/editar`, `sue.rrhh.accidentes.ver/editar`, `sue.datosSensibles.ver` (antes `sue.rrhh.evaluaciones.*`, `sue.rrhh.objetivos.*`, `sue.rrhh.sanciones.*`, `sue.rrhh.sumarios.*`, `sue.rrhh.accidentes.*`) |"); n += 5
t = rep(t, "| Asesor legal | `sue.rrhh.juicios.*`, `sue.rrhh.sumarios.ver`",
        "| Asesor legal | `sue.rrhh.juicios.ver/editar` (antes `sue.rrhh.juicios.*`), `sue.rrhh.sumarios.ver`"); n += 1
t = rep(t, "| `sue.rrhh.evaluaciones.*` / `objetivos.*` | Evaluaciones y objetivos |",
        "| `sue.rrhh.evaluaciones.ver` (GET), `sue.rrhh.evaluaciones.editar` (POST, PATCH, DELETE); `sue.rrhh.objetivos.ver` (GET), `sue.rrhh.objetivos.editar` (POST, PATCH, DELETE) (antes `sue.rrhh.evaluaciones.*` / `objetivos.*`) | Evaluaciones y objetivos |"); n += 2
t = rep(t, "| `sue.rrhh.sanciones.*` / `sumarios.*` | Disciplina |",
        "| `sue.rrhh.sanciones.ver` (GET), `sue.rrhh.sanciones.editar` (POST, PATCH, DELETE); `sue.rrhh.sumarios.ver` (GET), `sue.rrhh.sumarios.editar` (POST, PATCH, DELETE) (antes `sue.rrhh.sanciones.*` / `sumarios.*`) | Disciplina |"); n += 2
t = rep(t, "| `sue.rrhh.accidentes.*` | Accidentes |",
        "| `sue.rrhh.accidentes.ver` (GET), `sue.rrhh.accidentes.editar` (POST, PATCH, DELETE) (antes `sue.rrhh.accidentes.*`) | Accidentes |"); n += 1
t = rep(t, "| `sue.rrhh.juicios.*` | Juicios |",
        "| `sue.rrhh.juicios.ver` (GET), `sue.rrhh.juicios.editar` (POST, PATCH, DELETE) (antes `sue.rrhh.juicios.*`) | Juicios |"); n += 1
t = rep(t, "| `sue.portal.datos.*`, `sue.portal.documentos.subir` | Datos y documentos |",
        "| `sue.portal.datos.ver` (GET), `sue.portal.datos.editar` (POST `/me/change-requests`; nueva), `sue.portal.documentos.subir` (POST `/me/documents`) (antes `sue.portal.datos.*`) | Datos y documentos |"); n += 1

# Estados propuestos -> asumidos (PA-SUE-17)
for col, vals in (('payslipNotifications', '`sent`, `viewed`, `signed`, `disagreed`'),
                  ('performanceReviews', '`draft`, `inEvaluation`, `completed`, `acknowledged`'),
                  ('objectives', '`draft`, `active`, `closed`, `cancelled`')):
    pass
t = rep(t, "| `sent`, `viewed`, `signed`, `disagreed` `[VERIFICAR]` (valores propuestos en §8.12.8; antes sin valores). |",
        "| `sent`, `viewed`, `signed`, `disagreed` (valores de §8.12.8, asumidos en PA-SUE-17; antes propuestos `[VERIFICAR]` y, antes de eso, sin valores). |")
t = rep(t, "| `draft`, `inEvaluation`, `completed`, `acknowledged` `[VERIFICAR]` (valores propuestos en §8.12.9; antes sin valores). |",
        "| `draft`, `inEvaluation`, `completed`, `acknowledged` (valores de §8.12.9, asumidos en PA-SUE-17; antes propuestos `[VERIFICAR]` y, antes de eso, sin valores). |")
t = rep(t, "| `draft`, `active`, `closed`, `cancelled` `[VERIFICAR]` (valores propuestos en §8.12.10; antes sin valores). |",
        "| `draft`, `active`, `closed`, `cancelled` (valores de §8.12.10, asumidos en PA-SUE-17; antes propuestos `[VERIFICAR]` y, antes de eso, sin valores). |")
a = t.index("#### 8.12.8. Notificación de recibo")
b = t.index("## 9. Procesos y flujos", a)
sec = t[a:b]
k = sec.count("Valores propuestos `[VERIFICAR]`:")
assert k == 3, k
sec = sec.replace("Valores propuestos `[VERIFICAR]`:", "Valores (asumidos en PA-SUE-17, DEC-072; antes \"valores propuestos `[VERIFICAR]`\"):")
sec = sec.replace("Estado inicial propuesto:", "Estado inicial:")
sec = sec.replace(" `[VERIFICAR]` | — |", " | — |")
assert "[VERIFICAR]`\"):" in sec and sec.count("[VERIFICAR]") == 3, sec.count("[VERIFICAR]")
t = t[:a] + sec + t[b:]

# PAN-SUE-41..46: M16 dueño, M19 incrusta (PA-SUE-16)
routes = {
    'PAN-SUE-41': ('`/empleado/recibos`', 'M19 la publica como `/app/empleado/recibos` y `/app/empleado/recibos/:id` (PAN-POR-70, PAN-POR-71)'),
    'PAN-SUE-42': ('`/empleado/licencias`', 'M19 la publica como `/app/empleado/vacaciones` y `/app/empleado/licencias` (PAN-POR-72, PAN-POR-73)'),
    'PAN-SUE-43': ('`/empleado/datos`', 'M19 la publica como `/app/empleado/legajo` (PAN-POR-74)'),
    'PAN-SUE-44': ('`/empleado/equipo`', 'M19 la publica como `/app/empleado/equipo`, con acceso desde PAN-POR-69; sin PAN-POR propia'),
    'PAN-SUE-45': ('`/empleado/certificados`', 'M19 la publica como `/app/empleado/certificados`, con acceso desde PAN-POR-69; sin PAN-POR propia'),
    'PAN-SUE-46': ('`/empleado/evaluaciones`', 'M19 la publica como `/app/empleado/evaluaciones`, con acceso desde PAN-POR-69; sin PAN-POR propia'),
}
for pan, (r, note) in routes.items():
    t = rep(t, f"| {pan} | pwa-empleado | {r} |",
            f"| {pan} | pwa-empleado | {r} (ruta de referencia de M16, dueño del contenido; {note}, que incrusta esta pantalla; PA-SUE-16) |")

t = rep(t, "- **Impacto si no se responde:** se asume A.\n- **Bloquea:** §2.2.\n\n## 22. Trazabilidad de fuentes",
        "- **Impacto si no se responde:** se asume A.\n- **Bloquea:** §2.2.\n\n"
        "### PA-SUE-16 — Dueño de las pantallas del empleado (PA 17 del pendiente de cierre)\n"
        "- **Pregunta:** ¿Las pantallas de autoservicio del empleado (recibos, licencias, datos, equipo, certificados, evaluaciones) son de M16 o de M19?\n"
        "- **Contexto:** M16 declara PAN-SUE-41 a PAN-SUE-46 y M19 declara PAN-POR-69 a PAN-POR-76 para las mismas funciones, con rutas distintas (`/empleado/...` y `/app/empleado/...`).\n"
        "- **Opciones:**\n"
        "  - A) M16 es dueño del contenido, las reglas y las API (PAN-SUE-41 a PAN-SUE-46, API-SUE-78 a API-SUE-81); M19 es dueño de la ruta publicada en la PWA y la incrusta (HUE-SRV-04) **(Recomendada)**.\n"
        "  - B) M19 es dueño de todo y M16 solo expone API.\n"
        "- **Impacto si no se responde:** se asume A.\n"
        "- **Bloquea:** PAN-SUE-41 a PAN-SUE-46; PAN-POR-69 a PAN-POR-74 de M19.\n"
        "- **Estado:** Asumida la recomendada (DEC-072). La ruta publicada es la de M19; la de M16 queda como referencia. PAN-SUE-44 a PAN-SUE-46 no tienen PAN-POR propia en M19.\n\n"
        "### PA-SUE-17 — Estados de notificación de recibo, evaluación y objetivo (PA 19 del pendiente de cierre)\n"
        "- **Pregunta:** ¿Se confirman los estados propuestos para `payslipNotifications`, `performanceReviews` y `objectives`?\n"
        "- **Contexto:** el §7 declaraba `status` sin valores; la corrección del 05-11-2026 propuso valores con `[VERIFICAR]` en §8.12.8 a §8.12.10.\n"
        "- **Opciones:**\n"
        "  - A) Confirmar los valores y transiciones de §8.12.8 a §8.12.10 **(Recomendada)**.\n"
        "  - B) Derivar el estado de las fechas (`sentAt`, `viewedAt`, `signedAt`, `feedbackAt`) sin campo `status`.\n"
        "- **Impacto si no se responde:** se asume A.\n"
        "- **Bloquea:** §8.12.8 a §8.12.10.\n"
        "- **Estado:** Asumida la recomendada (DEC-072); se quitan los `[VERIFICAR]` de esas secciones.\n\n"
        "## 22. Trazabilidad de fuentes")
save(p, bom, crlf, t)
print('M16 ok; renombres:', n)
