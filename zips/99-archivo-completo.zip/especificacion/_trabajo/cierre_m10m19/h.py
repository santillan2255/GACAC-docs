import re, sys, glob
sys.stdout.reconfigure(encoding='utf-8')

PIPE = re.compile(r'(?<!\\)\|')


def path(prefix):
    return glob.glob('anexos/' + prefix + '-*.md')[0]


def load(prefix):
    p = path(prefix)
    raw = open(p, 'rb').read()
    bom = raw[:3] == b'\xef\xbb\xbf'
    t = raw.decode('utf-8-sig' if bom else 'utf-8')
    crlf = '\r\n' in t
    return p, bom, crlf, t.replace('\r\n', '\n')


def save(p, bom, crlf, t):
    if crlf:
        t = t.replace('\n', '\r\n')
    data = t.encode('utf-8')
    if bom:
        data = b'\xef\xbb\xbf' + data
    open(p, 'wb').write(data)


def rep(t, old, new, count=1):
    n = t.count(old)
    if n != count:
        raise SystemExit('ERROR: esperado %d, encontrado %d: %r' % (count, n, old[:120]))
    return t.replace(old, new)


def split_cells(line):
    idx = [m.start() for m in PIPE.finditer(line)]
    return [line[idx[i] + 1:idx[i + 1]] for i in range(len(idx) - 1)]


def join_cells(cells):
    return '|' + '|'.join(cells) + '|'


def cap_rename_line(line, mapping, slash_first=()):
    """Renombra capabilities en cada celda y agrega '(antes `x`)' en la celda modificada."""
    cells = split_cells(line)
    changed = 0
    for ci, c in enumerate(cells):
        olds = []
        for old, new in slash_first:
            tok = '`' + old + '`'
            if tok in c:
                c = c.replace(tok, '`' + new + '`')
                olds.append(old)
        for old, new in mapping:
            pat = re.compile(r'`' + re.escape(old) + r'`')
            if pat.search(c):
                c = pat.sub('`' + new + '`', c)
                olds.append(old)
        if olds:
            seen = []
            for o in olds:
                if o not in seen:
                    seen.append(o)
            note = ' (antes ' + ', '.join('`' + o + '`' for o in seen) + ')'
            c = c.rstrip() + note + ' '
            cells[ci] = c
            changed += len(seen)
    return join_cells(cells), changed
