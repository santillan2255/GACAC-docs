from h import *

p, bom, crlf, t = load('M19')

# crm.openCase
t = rep(t, "→ `crm.openCase(type=solicitudAlta)`; constancia.",
        "→ `crm.openCase(caseTypeCode=serviceActivation)` (antes `crm.openCase(type=solicitudAlta)`: `solicitudAlta` es el `kind` del formulario de M19, no un tipo de caso; el tipo de caso de M09 es `serviceActivation` y la firma de `crm.openCase` está en M09 §11.5); constancia.")

# API-POR-01
t = rep(t, "| API-POR-01 | GET | `/api/public/:tenantSlug/bootstrap` | `public: true` (antes: Pública) | Marca, diccionario público, landing publicada, parámetros públicos, estado del tenant | Sí (GET) |",
        "| API-POR-01 | GET | `/api/public/:tenantSlug/bootstrap?app=` (antes sin `?app=`) | `public: true` (antes: Pública) | Bootstrap público único: API-UXD-01 (T03) y API-PLA-64 (T01) lo referencian. `app` = `admin`, `pwa` o `landing`. Payload: de T03, la marca publicada (colores, URLs de recursos por canal), `themePolicy`, release del diccionario público y URL del paquete pre-login, métodos de login (de T02) y flags públicos; de T01, los módulos y canales activos y el estado del tenant (sin datos internos); de M19, la landing publicada y los parámetros públicos (antes \"Marca, diccionario público, landing publicada, parámetros públicos, estado del tenant\") | Sí (GET, `ETag`) (antes Sí (GET)) |")

# CU-MAR-01
t = rep(t, "| CU-MAR-01 | Alta de tenant con marca y landing |",
        "| CU-MAR-01 | Alta de tenant con marca y landing (definición dueña: T03 «CU-MAR-01 — Personalizar la marca de la cooperativa»; aquí se cita el caso original de BASE §43 y M19 solo es dueño de los pasos de landing y app del socio) |")

# Tabbar (PA 16)
t = rep(t, "- **Tabbar por espacio**: socio = Inicio · Servicios · (+) · Facturas · Perfil;",
        "- **Tabbar por espacio**: socio = Inicio · Cuentas y servicios · (+) · Gestiones · Comunidad, con Perfil desde el avatar de la topbar y FAB = Pagar por defecto (PA-POR-20; T03 RF-UXD-066 y CTR-UXD-12; antes Inicio · Servicios · (+) · Facturas · Perfil; Facturas se abre desde Cuentas y servicios y desde el FAB Pagar); Comunidad abre PAN-POR-105;")
t = rep(t, "/app/encuestas(/:id)                   PAN-POR-54 Encuestas\n",
        "/app/comunidad                         PAN-POR-105 Comunidad (tabbar; agrega muro, encuestas y novedades)\n/app/encuestas(/:id)                   PAN-POR-54 Encuestas\n")

# PAN-POR-105
t = rep(t, "| PAN-POR-56 | pwa-socio | `/app/novedades(/:id)` | `com.wall.ver` (+ `por.portal.ver`) | Boletines y novedades | Leer | — | `WEB_NOVEDADES` |\n",
        "| PAN-POR-56 | pwa-socio | `/app/novedades(/:id)` | `com.wall.ver` (+ `por.portal.ver`) | Boletines y novedades | Leer | — | `WEB_NOVEDADES` |\n"
        "| PAN-POR-105 | pwa-socio | `/app/comunidad` | `por.portal.ver`; cada pestaña exige además la capability de T09 (`com.wall.ver` muro y novedades, `com.surveys.responder` encuestas) | Destino \"Comunidad\" de la tabbar (PA-POR-20, RF-POR-180): agregador con pestañas Muro (PAN-POR-55), Encuestas (PAN-POR-54) y Novedades (PAN-POR-56); muestra las últimas publicaciones y las encuestas pendientes, y cada tarjeta abre la pantalla de detalle | Cambiar de pestaña, abrir publicación, responder encuesta, leer novedad | 3 skeleton cards; «Todavía no hay novedades de tu cooperativa»; una pestaña sin capability no se muestra | — (nueva; maestro §9.2) |\n")

# RF-POR-180
i = t.index("| RF-POR-178 |")
j = t.index('\n', i) + 1
t = t[:j] + ("| RF-POR-180 | **Comunidad en la tabbar del socio** (PAN-POR-105): la tabbar del socio es Inicio · Cuentas y servicios · (+) · Gestiones · Comunidad, con Perfil desde el avatar y FAB = Pagar por defecto; Comunidad agrega en pestañas el muro, las encuestas y las novedades de T09 filtrados por audiencia (API-POR-92), y muestra solo las pestañas para las que el usuario tiene capability. | PA-POR-20; T03 RF-UXD-066, CTR-UXD-12; maestro §9.2 | N | O2 | A | Un socio con `com.wall.ver` y sin `com.surveys.responder` ve Comunidad con Muro y Novedades, sin la pestaña Encuestas; la tabbar no muestra \"Facturas\" ni \"Perfil\". |\n") + t[j:]

# 10.6.A: incrustaciones de M16 y Comunidad
t = rep(t, "| PAN-POR-104 | `/cementerio/buscar` | M18 SOC | — (vista propia de M19) | API-SOC-061 | API-POR-124 |\n",
        "| PAN-POR-104 | `/cementerio/buscar` | M18 SOC | — (vista propia de M19) | API-SOC-061 | API-POR-124 |\n"
        "| PAN-POR-69 | `/app/empleado` | M16 SUE, T09 COM | Resumen de PAN-SUE-41 a PAN-SUE-46 (último recibo, saldo de vacaciones, solicitudes, accesos a equipo, certificados y evaluaciones); muro interno de T09 | API-SUE-78, API-SUE-80 | API-POR-93 |\n"
        "| PAN-POR-70 | `/app/empleado/recibos` | M16 SUE | PAN-SUE-41 (listado de recibos) | API-SUE-78 | API-POR-94 |\n"
        "| PAN-POR-71 | `/app/empleado/recibos/:id` | M16 SUE, T11 WFL | PAN-SUE-41 (vista del recibo y firma) | API-SUE-78, API-SUE-79; firma en T11 (API-WFL-77 a API-WFL-79) | API-POR-94 a API-POR-96 |\n"
        "| PAN-POR-72 | `/app/empleado/vacaciones` | M16 SUE | PAN-SUE-42 (saldo y solicitudes de vacaciones) | API-SUE-80 | API-POR-97 |\n"
        "| PAN-POR-73 | `/app/empleado/licencias` | M16 SUE | PAN-SUE-42 (licencias) | API-SUE-80 | API-POR-98 |\n"
        "| PAN-POR-74 | `/app/empleado/legajo` | M16 SUE | PAN-SUE-43 | API-SUE-81 | API-POR-99 |\n"
        "| PAN-POR-105 | `/app/comunidad` | T09 COM | Muro (PAN-POR-55), encuestas (PAN-POR-54) y novedades (PAN-POR-56) en pestañas | Feeds de T09 filtrados por audiencia | API-POR-92 |\n")

# PAN-POR-69..76 incrustación (PA 17)
emb = {
    'PAN-POR-69': "**Incrusta un resumen de PAN-SUE-41 a PAN-SUE-46 de M16** (dueño del contenido; PA-SUE-16 de M16) — ",
    'PAN-POR-70': "**Incrusta PAN-SUE-41 de M16** (dueño; PA-SUE-16) — ",
    'PAN-POR-71': "**Incrusta PAN-SUE-41 de M16** (dueño; PA-SUE-16) — ",
    'PAN-POR-72': "**Incrusta PAN-SUE-42 de M16** (dueño; PA-SUE-16) — ",
    'PAN-POR-73': "**Incrusta PAN-SUE-42 de M16** (dueño; PA-SUE-16) — ",
    'PAN-POR-74': "**Incrusta PAN-SUE-43 de M16** (dueño; PA-SUE-16) — ",
    'PAN-POR-75': "**Incrusta el componente de muro interno de T09** (dueño) — ",
    'PAN-POR-76': "**Incrusta la bandeja de avisos de T09** (dueño) — ",
}
lines = t.split('\n')
done = 0
for k, l in enumerate(lines):
    for pan, pre in emb.items():
        if l.startswith(f'| {pan} | pwa-empleado |'):
            c = split_cells(l)
            assert len(c) == 8, l
            c[4] = ' ' + pre + c[4].strip() + ' '
            lines[k] = join_cells(c)
            done += 1
assert done == 8, done
t = '\n'.join(lines)

# API-POR-99
t = rep(t, "| `sue.portal.datos.ver` (antes `sue.legajo.ver`) | Legajo y solicitudes de actualización |",
        "| `sue.portal.datos.ver` (GET), `sue.portal.datos.editar` (POST `/update-requests`; nueva en M16) (antes `sue.legajo.ver`) | Legajo y solicitudes de actualización |")

# PA 18: versiones en formVersions de T11
t = rep(t, "| `currentVersion` | Int | Sí |  | — |",
        "| `currentVersion` | Int | Sí | Reemplazado por `formVersionId` (versión publicada vigente en `formVersions` de T11; PA-POR-21). Se conserva como número de versión de lectura. | — |")
t = rep(t, "| `versions` | Array | Sí | `[{ number, publishedAt, steps: [{ stepId, titleKey, fields: [...] }] }]` | — |",
        "| `versions` | Array | No (antes Sí) | Reemplazado por `formVersions` de T11 (PA-POR-21): las versiones publicadas, sus pasos y campos viven en T11 y son inmutables; antes `[{ number, publishedAt, steps: [{ stepId, titleKey, fields: [...] }] }]` embebido. | `formVersions` (T11) |")
t = rep(t, "| `versions[].steps[].fields[]` | Object | Sí | `{ fieldId,",
        "| `versions[].steps[].fields[]` | Object | No (antes Sí) | Reemplazado por los campos de `formVersions` de T11 (PA-POR-21); definición anterior: `{ fieldId,")
t = rep(t, "| `formVersionId` | ObjectId | [VERIFICAR] | Versión del formulario en T11; T05 (COL-POR-06) declara `portalForms` \"sobre `formVersions` de T11\", mientras este anexo versiona en `versions` embebido: [VERIFICAR] cuál prevalece (propuesta de PA en el informe de corrección) | `formVersions` (T11) |",
        "| `formVersionId` | ObjectId | Sí (al publicar) | Versión publicada vigente del formulario en `formVersions` de T11 (PA-POR-21, como T05 COL-POR-06); antes \"[VERIFICAR] cuál prevalece\" frente a `versions` embebido. | `formVersions` (T11) |")
t = rep(t, "| `formId` / `formVersion` | ObjectId / Int | Sí | Versión usada (inmutable) | `portalForms` (M19) (solo `formId`) |",
        "| `formId` / `formVersion` | ObjectId / Int | Sí | Versión usada (inmutable) | `portalForms` (M19) (solo `formId`) |\n"
        "| `formVersionId` | ObjectId | Sí | Versión de T11 usada en la presentación (inmutable; PA-POR-21). `formVersion` queda como número de lectura. | `formVersions` (T11) |")
t = rep(t, "| `formId` / `formVersion` | ObjectId / Int | No |  | `portalForms` (M19) (solo `formId`) |",
        "| `formId` / `formVersion` | ObjectId / Int | No |  | `portalForms` (M19) (solo `formId`) |\n"
        "| `formVersionId` | ObjectId | No | Versión de T11 del formulario en armado (PA-POR-21). | `formVersions` (T11) |")
t = rep(t, "`borrador` → `publicado` (publicador; crea `versions[n]` inmutable)",
        "`borrador` → `publicado` (publicador; crea una versión inmutable en `formVersions` de T11 y actualiza `formVersionId`, PA-POR-21; antes crea `versions[n]` inmutable)")

# PA-POR-20 y PA-POR-21
t = rep(t, "- **Bloquea:** RF-POR-145; O10.\n\n## 22. Trazabilidad de fuentes",
        "- **Bloquea:** RF-POR-145; O10.\n\n"
        "### PA-POR-20 — Tabbar del socio y pantalla Comunidad (PA 16 del pendiente de cierre)\n"
        "- **Pregunta:** ¿Cuál es la tabbar del socio y qué abre el destino \"Comunidad\"?\n"
        "- **Contexto:** este anexo tenía Inicio · Servicios · (+) · Facturas · Perfil; T03 (RF-UXD-066, CTR-UXD-12) y el maestro §9.2 fijan Inicio · Cuentas y servicios · (+) · Gestiones · Comunidad, con Perfil en la topbar, y T03 SM-PWS-026 espera una pantalla Comunidad de M19.\n"
        "- **Opciones:**\n"
        "  - A) Alinear con T03 y el maestro; FAB = Pagar por defecto; nueva PAN-POR-105 `/app/comunidad` que agrega muro, encuestas y novedades con la capability existente `por.portal.ver` (RF-POR-180) **(Recomendada)**.\n"
        "  - B) Mantener la tabbar de este anexo y que T03 se ajuste.\n"
        "- **Impacto si no se responde:** se asume A.\n"
        "- **Bloquea:** §10.1, §10.3, PAN-POR-105, RF-POR-180.\n"
        "- **Estado:** Asumida la recomendada (DEC-072). Las tabbars de empleado y de registrado sin cuenta no cambian en esta corrección.\n\n"
        "### PA-POR-21 — Versiones de formularios del portal (PA 18 del pendiente de cierre)\n"
        "- **Pregunta:** ¿Las versiones de `portalForms` se guardan embebidas (`versions`) o en `formVersions` de T11?\n"
        "- **Contexto:** T05 (COL-POR-06) declara `portalForms` sobre `formVersions` de T11; este anexo versionaba en `versions` embebido.\n"
        "- **Opciones:**\n"
        "  - A) `formVersions` de T11: `portalForms` guarda la configuración del portal y `formVersionId`; las presentaciones y borradores guardan el `formVersionId` usado **(Recomendada)**.\n"
        "  - B) Versionado embebido en M19.\n"
        "- **Impacto si no se responde:** se asume A.\n"
        "- **Bloquea:** §7.6 a §7.8, §8.4.\n"
        "- **Estado:** Asumida la recomendada (DEC-072); `versions` y `currentVersion` quedan marcados como reemplazados.\n\n"
        "## 22. Trazabilidad de fuentes")
save(p, bom, crlf, t)
print('M19 ok')
