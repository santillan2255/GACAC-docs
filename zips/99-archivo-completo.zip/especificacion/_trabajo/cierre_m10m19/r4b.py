from h import *

p, bom, crlf, t = load('M10')
t = rep(t, "que T02 registraba con acción en inglés).\n",
        "que T02 registraba con acción en inglés). Barrido final de T02 (§4.4.1 y §4.4.3): T02 fijó como canónicas `tec.servicioTecnico.*` (antes en este anexo `tec.serviceTechnical.*`), `tec.estimaciones.gestionar`, `tec.despacho.gestionar`, `tec.cuadrillas.gestionar`, `tec.formulariosCampo.gestionar`, `tec.equiposRed.gestionar`, `tec.contribucionesObra.gestionar`, `tec.dispositivos.gestionar`, `tec.perfilTecnico.verSecretos` y las acciones de campo `tec.campo.marcarEnCamino`, `tec.campo.registrarConformidad`, `tec.campo.registrarMateriales`, `tec.campo.crearOrden`; se renombraron en §4 y §10–§11 con \"antes\". Los comandos (`tec.workOrder.create`) no son capabilities y no cambian.\n")
save(p, bom, crlf, t)
print('ok')
