import difflib, glob, os
B = glob.glob('_trabajo/backup-cierre-M10M19-202611051500/*.md')
for b in sorted(B):
    n = os.path.basename(b)
    a = open(b, encoding='utf-8', newline='').read().splitlines()
    c = open('anexos/' + n, encoding='utf-8', newline='').read().splitlines()
    add = rem = 0
    for l in difflib.unified_diff(a, c, lineterm='', n=0):
        if l.startswith('+') and not l.startswith('+++'):
            add += 1
        elif l.startswith('-') and not l.startswith('---'):
            rem += 1
    print(n[:3], 'lineas', len(a), '->', len(c), '+', add, '-', rem)
