import re, glob, sys, json
sys.stdout.reconfigure(encoding='utf-8')
PIPE = re.compile(r'(?<!\\)\|')
T = open(glob.glob('anexos/T02-*.md')[0], encoding='utf-8').read().replace('\r', '').split('\n')


def cells(l):
    idx = [m.start() for m in PIPE.finditer(l)]
    return [l[idx[i] + 1:idx[i + 1]].strip() for i in range(len(idx) - 1)]


def section(start, end):
    a = next(i for i, l in enumerate(T) if l.startswith(start))
    b = next(i for i in range(a + 1, len(T)) if T[i].startswith(end))
    return T[a:b]


mapping = {}  # nombre -> (canónica o None, origen, fila)
for l in section('#### 4.4.1', '#### 4.4.2'):
    if l.startswith('| `'):
        c = cells(l)
        olds = re.findall(r'`([^`]+)`', c[0])
        news = re.findall(r'`([^`]+)`', c[1])
        for o in olds:
            mapping[o] = (news[0] if len(news) == 1 else None, '4.4.1 ' + c[2], c[1])
for l in section('#### 4.4.3', '### 4.5'):
    if l.startswith('| ') and not l.startswith('| Módulo') and not l.startswith('|---'):
        c = cells(l)
        if len(c) < 5:
            continue
        olds = re.findall(r'`([^`]+)`', c[1])
        canon = c[2]
        m = re.match(r'`([^`]+)`', canon)
        for o in olds:
            mapping.setdefault(o, (m.group(1) if m else None, '4.4.3 ' + c[4], canon))
json.dump(mapping, open('_trabajo/cierre_m10m19/r4_map.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('nombres', len(mapping))

ANTES = re.compile(r'\((?:[^()]|\([^()]*\))*?\bantes\b(?:[^()]|\([^()]*\))*\)', re.I)
for f in sorted(glob.glob('anexos/M1*.md')):
    L = open(f, encoding='utf-8').read().replace('\r', '').split('\n')
    in21 = False
    for i, l in enumerate(L, 1):
        if l.startswith('## '):
            in21 = l.startswith('## 21')
        if in21 or l.startswith('> **Corrección'):
            continue
        s = ANTES.sub('', l)
        s = re.sub(r'\bantes `[^`]+`', '', s, flags=re.I)
        toks = set()
        for tok in re.findall(r'`([^`]+)`', s):
            toks.add(tok)
            if '/' in tok and re.match(r'^[a-z]+\.[A-Za-z.]+/[A-Za-z/]+$', tok):
                base, rest = tok.split('/', 1)
                pre = base.rsplit('.', 1)[0]
                toks.add(base)
                for a in rest.split('/'):
                    toks.add(pre + '.' + a)
        for tok in toks:
            if tok in mapping and 'Solo ruta' not in mapping[tok][1]:
                print(f[7:10], i, tok, '->', mapping[tok][0], '|', mapping[tok][1][:40], '::', l[:140])
