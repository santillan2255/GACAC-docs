import re
from h import *

p, bom, crlf, t = load('M10')

SLASH = [
    ('tec.workOrder.read/update/close', 'tec.ordenes.ver/editar/cerrar'),
    ('tec.serviceTechnical.read/update', 'tec.serviceTechnical.ver/editar'),
    ('tec.factibilidades.ver/crear/editar/aprobar/anular', 'tec.factibilidad.ver/crear/editar/evaluar/cancelar/reabrir'),
    ('tec.factibilidades.ver/crear/editar', 'tec.factibilidad.ver/crear/editar'),
    ('tec.ot.ver/crear/editar/asignar/confirmar/anular/reabrir/exportar', 'tec.ordenes.ver/crear/editar/asignar/cerrar/cancelar/reabrir/imprimir`, `tec.reportes.ver'),
    ('tec.ot.ver/crear/editar/asignar', 'tec.ordenes.ver/crear/editar/asignar'),
]
MAP = [
    ('tec.feasibility.read', 'tec.factibilidad.ver'),
    ('tec.feasibility.create', 'tec.factibilidad.crear'),
    ('tec.feasibility.update', 'tec.factibilidad.editar'),
    ('tec.feasibility.evaluate', 'tec.factibilidad.evaluar'),
    ('tec.feasibility.cancel', 'tec.factibilidad.cancelar'),
    ('tec.feasibility.reopen', 'tec.factibilidad.reabrir'),
    ('tec.estimate.manage', 'tec.estimate.gestionar'),
    ('tec.workOrder.read', 'tec.ordenes.ver'),
    ('tec.workOrder.create', 'tec.ordenes.crear'),
    ('tec.workOrder.update', 'tec.ordenes.editar'),
    ('tec.workOrder.close', 'tec.ordenes.cerrar'),
    ('tec.workOrder.execute', 'tec.ordenes.ejecutar'),
    ('tec.workOrder.cancel', 'tec.ordenes.cancelar'),
    ('tec.workOrder.reopen', 'tec.ordenes.reabrir'),
    ('tec.workOrder.print', 'tec.ordenes.imprimir'),
    ('tec.workOrder.bulkCreate', 'tec.ordenes.crearMasivo'),
    ('tec.workOrder.bulkClose', 'tec.ordenes.cerrarMasivo'),
    ('tec.serviceTechnical.read', 'tec.serviceTechnical.ver'),
    ('tec.serviceTechnical.update', 'tec.serviceTechnical.editar'),
    ('tec.dispatch.manage', 'tec.dispatch.gestionar'),
    ('tec.schedule.read', 'tec.agenda.ver'),
    ('tec.schedule.manage', 'tec.agenda.gestionar'),
    ('tec.schedule.configure', 'tec.agenda.configurar'),
    ('tec.crew.manage', 'tec.crew.gestionar'),
    ('tec.config.manage', 'tec.config.gestionar'),
    ('tec.material.authorize', 'tec.materiales.autorizar'),
    ('tec.material.request', 'tec.materiales.solicitar'),
    ('tec.syncConflict.resolve', 'tec.conflictos.resolver'),
    ('tec.installation.read', 'tec.instalaciones.ver'),
    ('tec.installation.review', 'tec.instalaciones.revisar'),
    ('tec.fieldForm.manage', 'tec.fieldForm.gestionar'),
    ('tec.maintenance.manage', 'tec.mantenimiento.gestionar'),
    ('tec.outage.manage', 'tec.cortes.gestionar'),
    ('tec.map.read', 'tec.mapa.ver'),
    ('tec.network.configure', 'tec.redes.configurar'),
    ('tec.network.manage', 'tec.redes.gestionar'),
    ('tec.network.read', 'tec.redes.ver'),
    ('tec.network.export', 'tec.redes.exportar'),
    ('tec.networkDevice.manage', 'tec.networkDevice.gestionar'),
    ('tec.provisioning.configure', 'tec.aprovisionamiento.configurar'),
    ('tec.provisioning.operate', 'tec.aprovisionamiento.operar'),
    ('tec.work.manage', 'tec.obras.gestionar'),
    ('tec.levy.manage', 'tec.levy.gestionar'),
    ('tec.inspection.manage', 'tec.inspecciones.gestionar'),
    ('tec.inspection.approve', 'tec.inspecciones.aprobar'),
    ('tec.phone.plant', 'tec.telefonia.redFisica.ver`, `tec.telefonia.redFisica.editar'),
    ('tec.phone.numbering', 'tec.telefonia.numeracion.ver`, `tec.telefonia.numeracion.editar'),
    ('tec.phone.lines', 'tec.telefonia.lineas.ver`, `tec.telefonia.lineas.editar'),
    ('tec.cdr.import', 'tec.cdr.importar'),
    ('tec.mobile.import', 'tec.mobile.importar'),
    ('tec.report.read', 'tec.reportes.ver'),
    ('tec.geo.review', 'tec.geo.revisar'),
    ('tec.device.manage', 'tec.device.gestionar'),
    ('tec.onCall.manage', 'tec.guardias.gestionar'),
    ('tec.waterQuality.manage', 'tec.calidadAgua.gestionar'),
    ('tec.ot.cierreMasivo', 'tec.ordenes.cerrarMasivo'),
    ('tec.ot.crearDerivada', 'tec.ordenes.crear'),
    ('tec.ot.asignar', 'tec.ordenes.asignar'),
    ('tec.ot.ver', 'tec.ordenes.ver'),
]

# RF-TEC-062: sin barra vertical dentro del código
t = rep(t, "`sourceRef = { type: 'workOrderCharge', id: '<workOrderId>:<regla>:<antes\\|luego>' }`",
        "`sourceRef = { type: 'workOrderCharge', id: '<workOrderId>:<regla>:<momento>' }`, con `<momento>` = `antes` o `luego` (antes el código mostraba las dos opciones separadas por una barra vertical escapada)")

# PAN-TEC-49
t = rep(t, "| PAN-TEC-49 | Carga rápida de reclamo | Sin ruta en M10: se abre la carga de caso de M09 | Reemplazada por M09 (caso) + derivación a OT. |",
        "| PAN-TEC-49 | Carga rápida de reclamo | Sin ruta en M10: se abre la carga de caso de M09 | **Reemplazada por PAN-CRM-04** (M09: modal global \"Nuevo caso\" y `/crm/carga-rapida`) + derivación a OT (antes \"Reemplazada por M09 (caso) + derivación a OT.\"). |")
t = rep(t, "| `frmCargaRapidaReclamo` | PAN-TEC-49 (reemplazado por M09) |",
        "| `frmCargaRapidaReclamo` | PAN-TEC-49 (reemplazado por PAN-CRM-04 de M09; antes \"reemplazado por M09\") |")

lines = t.split('\n')
total = 0
def in_section(i, start_h, end_h):
    return start_h <= i < end_h
# localizar secciones
def idx(h):
    for i, l in enumerate(lines):
        if l.startswith(h):
            return i
    raise SystemExit('no hallado ' + h)
s4, s5 = idx('## 4. Actores'), idx('## 5. Requisitos')
s10, s12 = idx('## 10. Pantallas'), idx('## 12. Eventos y jobs')
for i in range(len(lines)):
    l = lines[i]
    if not l.startswith('|'):
        continue
    if (s4 <= i < s5) or (s10 <= i < s12) or l.startswith('| ESC-TEC-24 '):
        if l.startswith('| ID ') or l.startswith('| API-ID ') or l.startswith('| Rol ') or l.startswith('| Servicio '):
            continue
        nl, n = cap_rename_line(l, MAP, SLASH)
        if n:
            lines[i] = nl
            total += n
t = '\n'.join(lines)
print('M10 renombres de capability:', total)

# Nota en §4
t = rep(t, "\nPermisos negativos relevantes: el técnico no ve OT fuera de su alcance",
        "\n> **Corrección de cierre 05-11-2026 (PA-TEC-21; PA 4 y 7 del pendiente de cierre):** las capabilities de este anexo con acción en inglés o fuera de la convención de T02 (`tec.workOrder.*`, `tec.feasibility.*`, `tec.schedule.*`, `tec.network.*`, `tec.provisioning.*`, acciones `manage`, `read`, `configure`, `import`, `review`, y `tec.phone.plant`, `tec.phone.numbering`, `tec.phone.lines`) y el vocabulario `tec.ot.*` / `tec.factibilidades.*` de esta tabla se renombran a la canónica de T02 §4.4.3 (`tec.ordenes.*`, `tec.factibilidad.*`, `tec.agenda.*`, `tec.redes.*`, `tec.aprovisionamiento.*`, acciones `gestionar`, `ver`, `configurar`, `importar`, `revisar`, y `tec.telefonia.*`). Cada celda conserva el nombre anterior como alias \"antes `x`\" en §4, §10, §11 y ESC-TEC-24. Las que T02 registra con acción en inglés sin canónica propuesta pasan a `tec.materiales.autorizar` (antes `tec.material.authorize`), `tec.materiales.solicitar` (antes `tec.material.request`), `tec.conflictos.resolver` (antes `tec.syncConflict.resolve`), `tec.guardias.gestionar` (antes `tec.onCall.manage`) y `tec.calidadAgua.gestionar` (antes `tec.waterQuality.manage`). Los códigos de error (`tec.workOrder.duplicate`…), los nombres de evento y los comandos que recibe M10 (`tec.workOrder.create`, `tec.feasibility.request` de EVT-CRM-13) no son capabilities y no cambian.\n\nPermisos negativos relevantes: el técnico no ve OT fuera de su alcance")

# technicalProcedures: estados
t = rep(t, "`contact`, `serviceId`, `openedAt`, `status`, `stages [{",
        "`contact`, `serviceId`, `openedAt`, `status` (`open`, `inReview`, `observed`, `approved`, `rejected`, `cancelled`; §8.15, PA-TEC-22), `stages [{")
t = rep(t, "| `status` | [VERIFICAR] | [VERIFICAR] | — | — |\n| `externalUserRef` |",
        "| `status` | Enum | Sí | `open`, `inReview`, `observed`, `approved`, `rejected`, `cancelled` (§8.15; PA-TEC-22; antes sin valores ni máquina). | — |\n| `externalUserRef` |")
t = rep(t, "\n## 9. Procesos y flujos\n",
        "\n### 8.15 Expediente técnico (`technicalProcedures.status`)\n\n"
        "Corrección de cierre 05-11-2026 (PA-TEC-22, PA 8 del pendiente de cierre): el §7 declaraba `status` sin valores ni transiciones. Estado inicial: `open`. Las etapas (`stages[]`) se agregan sin borrar las anteriores; la resolución de cada etapa define la transición.\n\n"
        "| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |\n|---|---|---|---|---|\n"
        "| (alta) | `open` | Alta del expediente (presentación del profesional certificado o carga interna) | `installerId` vigente en `certifiedInstallers` | — |\n"
        "| `open`, `observed` | `inReview` | Presentación de una etapa (`stages[].submittedAt`) | — | — |\n"
        "| `inReview` | `observed` | Resolución de la etapa con observación | Observación obligatoria | — |\n"
        "| `inReview` | `approved` | Resolución aprobatoria de la última etapa | — | — |\n"
        "| `inReview` | `rejected` | Resolución de rechazo | Motivo obligatorio | — |\n"
        "| `open`, `inReview`, `observed` | `cancelled` | Anulación del expediente | Motivo obligatorio; auditoría (AGR-003) | — |\n\n"
        "`approved`, `rejected` y `cancelled` son finales; un nuevo trámite abre otro expediente vinculado al mismo `dossierId` de T11.\n\n"
        "## 9. Procesos y flujos\n")

# PA-TEC-21 y PA-TEC-22
t = rep(t, "- **Bloquea:** RF-TEC-235, RF-TEC-236; REP-BIA-020 (sección de calidad), REP-BIA-024.\n- **Estado:** Asumida la recomendada (DEC-072) salvo respuesta del solicitante.\n\n## 22. Trazabilidad de fuentes",
        "- **Bloquea:** RF-TEC-235, RF-TEC-236; REP-BIA-020 (sección de calidad), REP-BIA-024.\n- **Estado:** Asumida la recomendada (DEC-072) salvo respuesta del solicitante.\n\n"
        "### PA-TEC-21 — Vocabulario de capabilities de M10 (PA 4 y 7 del pendiente de cierre)\n"
        "- **Pregunta:** ¿Las capabilities de M10 con acción en inglés (`tec.workOrder.read`, `tec.network.manage`, `tec.schedule.configure`…) se mantienen como excepción o se renombran al español?\n"
        "- **Contexto:** la guía §62 fija acciones en español. T02 §4.4.3 lista los nombres de M10 fuera de convención con su canónica propuesta y, hasta que se corrijan, el chequeo de permisos no los reconoce. El §4 de este anexo usaba además un vocabulario propio (`tec.ot.*`, `tec.factibilidades.*`) que T02 no registra.\n"
        "- **Opciones:**\n"
        "  - A) Renombrar al español con la canónica de T02 (`tec.ordenes.ver/editar/cerrar`, `tec.serviceTechnical.ver/editar`, `tec.redes.*`, `tec.agenda.*`…) y conservar el nombre anterior como alias \"antes `x`\" en cada celda **(Recomendada)**.\n"
        "  - B) Mantener los nombres en inglés como excepción registrada en T02.\n"
        "- **Impacto si no se responde:** se asume A.\n"
        "- **Bloquea:** §4, §10, §11 y ESC-TEC-24; catálogo de T02 §4.4.\n"
        "- **Estado:** Asumida la recomendada (DEC-072). Aplicada en la corrección de cierre del 05-11-2026. El pendiente proponía `tec.ot.*` y `tec.servicioTecnico.*`; se usan `tec.ordenes.*` y `tec.serviceTechnical.*` porque son los nombres que registra T02. T02 debe registrar `tec.materiales.autorizar`, `tec.materiales.solicitar`, `tec.conflictos.resolver`, `tec.guardias.gestionar` y `tec.calidadAgua.gestionar` (reemplazan a `tec.material.authorize`, `tec.material.request`, `tec.syncConflict.resolve`, `tec.onCall.manage` y `tec.waterQuality.manage`, que T02 registraba con acción en inglés).\n\n"
        "### PA-TEC-22 — Estados de `technicalProcedures` (PA 8 del pendiente de cierre)\n"
        "- **Pregunta:** ¿El expediente técnico (`EXPEDIENTES`, `EXPEDIENTES_TRAM`) tiene máquina de estados propia o solo un código de estado libre?\n"
        "- **Contexto:** el §7.11 declaraba `status` sin valores y el §8 no tenía su máquina; las etapas (`stages[]`) ya registran presentación y resolución.\n"
        "- **Opciones:**\n"
        "  - A) Máquina propia con `open`, `inReview`, `observed`, `approved`, `rejected` y `cancelled` (§8.15), dirigida por la resolución de cada etapa **(Recomendada)**.\n"
        "  - B) Sin máquina: `status` como texto libre migrado de ProCoop.\n"
        "- **Impacto si no se responde:** se asume A.\n"
        "- **Bloquea:** §7.11, §8.15; migración de `EXPEDIENTES` (§19).\n"
        "- **Estado:** Asumida la recomendada (DEC-072). T05 (COL-TEC-17) toma los valores de §8.15.\n\n"
        "## 22. Trazabilidad de fuentes")

save(p, bom, crlf, t)
print('M10 ok')
