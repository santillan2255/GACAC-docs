from h import *

p, bom, crlf, t = load('M18')
t = rep(t, "| `wfl.approval.decided` | T11 | Avanza transiciones con aprobación. |\n",
        "| `wfl.approval.decided` | T11 | Avanza transiciones con aprobación. |\n"
        "| `ins.membership.exited` (EVT-INS-06) | M17 | Con `associateMembershipId`, `cause` y `effectiveDate` del payload (antes `membershipId`), registra con fecha efectiva que el titular dejó de ser asociado y abre una tarea de revisión de elegibilidad para los beneficios que exigen esa condición (coberturas, convenios con aporte del asociado, `memberStatus` de traslados); no da de baja adherentes, derechos de sepultura ni planes de vivienda en forma automática. Consumo declarado en T11 §12 (corrección de cierre 05-11-2026, Asumida DEC-072). |\n")
save(p, bom, crlf, t)

p, bom, crlf, t = load('M19')
t = rep(t, "| `cat.contract.meteringRegimeChanged` (EVT-CAT-28) | M02 | Mostrar u ocultar Consumos y Autolectura en PAN-POR-30 desde la fecha efectiva (HUE-AG-03) |\n",
        "| `cat.contract.meteringRegimeChanged` (EVT-CAT-28) | M02 | Mostrar u ocultar Consumos y Autolectura en PAN-POR-30 desde la fecha efectiva (HUE-AG-03) |\n"
        "| `ins.membership.approved` (EVT-INS-02) | M17 | Con `associateMembershipId` y `memberNumber` (antes `membershipId`), invalida la caché de \"Mi asociación\" (PAN-POR-102), deja de ofrecer \"Asociarme\" y avisa al socio. Consumo declarado en T11 §12 (corrección de cierre 05-11-2026, Asumida DEC-072) |\n"
        "| `ins.membership.suspended` / `ins.membership.reinstated` (EVT-INS-04) | M17 | Con `associateMembershipId` y `date` (antes `membershipId`), invalida la caché de \"Mi asociación\" (PAN-POR-102) y actualiza el estado de asociado mostrado. Consumo declarado en T11 §12 |\n"
        "| `ins.membership.exited` (EVT-INS-06) | M17 | Con `associateMembershipId` y `effectiveDate` (antes `membershipId`), invalida la caché de \"Mi asociación\" (PAN-POR-102) y muestra la condición de ex asociado desde la fecha efectiva; no revoca accesos a cuentas ni servicios. Consumo declarado en T11 §12 |\n"
        "| `ins.capital.movement.recorded` (EVT-INS-08) | M17 | Invalida la caché de capital social en \"Mi asociación\" (PAN-POR-102). Consumo declarado en T11 §12 |\n")
save(p, bom, crlf, t)

p, bom, crlf, t = load('M17')
t = rep(t, "| `associateMembershipId` (antes `membershipId`), `date` | M19 |",
        "| `associateMembershipId` (antes `membershipId`), `date` | M19, M01 (antes solo M19; alineado con T11 §12) |")
t = rep(t, "| `associateMembershipId` (antes `membershipId`) | Bandeja secretaría |",
        "| `associateMembershipId` (antes `membershipId`) | T11 (bandeja de secretaría; antes \"Bandeja secretaría\", alineado con T11 §12) |")
save(p, bom, crlf, t)
print('ok')
