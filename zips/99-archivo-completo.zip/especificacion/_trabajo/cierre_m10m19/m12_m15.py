from h import *

# ---------------- M12 ----------------
p, bom, crlf, t = load('M12')
t = rep(t, "`cmp.cotizaciones.*`, `cmp.concursos.*`, `cmp.ordenes.ver`",
        "`cmp.cotizaciones.*`, `cmp.concursos.ver`, `cmp.concursos.editar`, `cmp.concursos.adjudicar` (antes `cmp.concursos.*`), `cmp.ordenes.ver`")
t = rep(t, "| Auditor | `cmp.*.ver`, `cmp.*.exportar` |",
        "| Auditor | `cmp.*.ver`, `cmp.reportes.exportar` (antes `cmp.*.exportar`) |")
t = rep(t, "- **App / ruta:** admin `/cmp/concursos/:id` · **Capability:** `cmp.concursos.*`",
        "- **App / ruta:** admin `/cmp/concursos/:id` · **Capability:** `cmp.concursos.ver`, `cmp.concursos.editar`, `cmp.concursos.adjudicar` (antes `cmp.concursos.*`)")
t = rep(t, "· **Capability:** `cmp.portal.*`",
        "· **Capability:** `cmp.portal.verOrdenes`, `cmp.portal.cotizar`, `cmp.portal.subirComprobante`, `cmp.portal.verPagos` (rol `supplier`; antes `cmp.portal.*`)")
save(p, bom, crlf, t)
print('M12 ok: 4 renombres')

# ---------------- M13 ----------------
p, bom, crlf, t = load('M13')
t = rep(t, "| Jefe de planta / fabricación | `stk.fabricacion.estructuras.*`, `stk.fabricacion.ordenes.ver/crear/lanzar/finalizar/cancelar/anular`, `stk.fabricacion.partes.*`,",
        "| Jefe de planta / fabricación | `stk.fabricacion.estructuras.ver`, `stk.fabricacion.estructuras.editar` (antes `stk.fabricacion.estructuras.*`), `stk.fabricacion.ordenes.ver/crear/lanzar/finalizar/cancelar/anular`, `stk.fabricacion.partes.ver`, `stk.fabricacion.partes.crear`, `stk.fabricacion.partes.lanzar`, `stk.fabricacion.partes.finalizar` (antes `stk.fabricacion.partes.*`),")
t = rep(t, "`fixedAssetId`, `type` (`impairment`/`improvement`/`inflationAdjustment`/`revaluation`), `date` (`FECHA`), `amount` (`IMPORTE`), `reason`, `status`, `eventId`.",
        "`fixedAssetId`, `type` (`impairment`/`improvement`/`inflationAdjustment`/`revaluation`), `date` (`FECHA`), `amount` (`IMPORTE`), `reason`, `status` (`draft`, `posted`, `voided`; §8.13, PA-STK-10), `eventId`.")
t = rep(t, "| `reason` | string | [VERIFICAR] | — | — |\n| `status` | [VERIFICAR] | [VERIFICAR] | — | — |\n| `eventId` |",
        "| `reason` | string | [VERIFICAR] | — | — |\n| `status` | Enum | Sí | `draft`, `posted`, `voided` (§8.13; PA-STK-10; antes sin valores ni máquina). | — |\n| `eventId` |")
t = rep(t, "`excludedLines`, `requisitionIds`, `status`. Reemplaza P168",
        "`excludedLines`, `requisitionIds`, `status` (`calculated`, `confirmed`, `discarded`, `failed`; §8.13, PA-STK-10). Reemplaza P168")
t = rep(t, "| `status` | Date | [VERIFICAR] | . Reemplaza P168 (última fecha de requerimiento) por el historial de corridas | — |",
        "| `status` | Enum | Sí | `calculated`, `confirmed`, `discarded`, `failed` (§8.13; PA-STK-10; antes tipo `Date` por error y sin valores). Reemplaza P168 (última fecha de requerimiento) por el historial de corridas | — |")
t = rep(t, "| `reorderSuggestions` | `open` | `dismissed` | Descarte por el usuario | — | — |\n\n## 9. Procesos y flujos",
        "| `reorderSuggestions` | `open` | `dismissed` | Descarte por el usuario | — | — |\n\n"
        "### 8.13 `fixedAssetValueChanges.status` y `mrpRuns.status`\n\n"
        "Corrección de cierre 05-11-2026 (PA-STK-10, PA 8 del pendiente de cierre): el §7 declaraba `status` sin valores ni transiciones (en `mrpRuns`, además, con tipo `Date`). Estado inicial: `fixedAssetValueChanges` `draft`; `mrpRuns` `calculated` (o `failed` si el cálculo no termina).\n\n"
        "| Colección | Desde | Hacia | Disparador | Guarda | Evento |\n|---|---|---|---|---|---|\n"
        "| `fixedAssetValueChanges` | (nuevo) | `draft` | Registro de mejora, disminución, ajuste o revalúo (RF-STK-099) | Bien no `disposed` ni `cancelled` | — |\n"
        "| `fixedAssetValueChanges` | `draft` | `posted` | Confirmación: actualiza el valor del bien y emite el evento contable (`eventId`, `journalEntryId` de M15) | Período abierto | `stk.fixedAsset.valueChanged` (EVT-STK-17) |\n"
        "| `fixedAssetValueChanges` | `draft` | `voided` | Descarte del borrador | — | — |\n"
        "| `fixedAssetValueChanges` | `posted` | `voided` | Anulación con contramovimiento de valor y reversión contable (no se borra; RN-STK-052) | Período abierto; sin amortizaciones posteriores contabilizadas que dependan del cambio | `stk.fixedAsset.valueChanged` (EVT-STK-17, reversión) |\n"
        "| `mrpRuns` | (nuevo) | `calculated` | Corrida de aprovisionamiento (JOB-STK-08, API-STK-67) | RN-STK-066 | — |\n"
        "| `mrpRuns` | (nuevo) | `failed` | Error del cálculo (falta estructura vigente o datos de stock) | — | — |\n"
        "| `mrpRuns` | `calculated` | `confirmed` | Generar requisiciones por proveedor en M12 (`requisitionIds`) | Solo requisiciones, nunca OC directa (RN-STK-044, CTR-STK-09) | — |\n"
        "| `mrpRuns` | `calculated` | `discarded` | Descarte por el usuario o nueva corrida del mismo rango | — | — |\n\n"
        "## 9. Procesos y flujos")
t = rep(t, "- **Bloquea:** RN-STK-035, RF-STK-094, RF-STK-095; O3/O5.\n\n## 22. Trazabilidad de fuentes",
        "- **Bloquea:** RN-STK-035, RF-STK-094, RF-STK-095; O3/O5.\n\n"
        "### PA-STK-10 — Estados de `fixedAssetValueChanges` y `mrpRuns` (PA 8 del pendiente de cierre)\n"
        "- **Pregunta:** ¿Los cambios de valor de bienes de uso y las corridas de aprovisionamiento de fabricación tienen máquina de estados propia?\n"
        "- **Contexto:** el §7 declaraba `status` sin valores en ambas colecciones (en `mrpRuns` con tipo `Date`) y el §8 no tenía sus transiciones.\n"
        "- **Opciones:**\n"
        "  - A) Máquina por colección (§8.13): `fixedAssetValueChanges` `draft` → `posted` → `voided` con reversión contable; `mrpRuns` `calculated` → `confirmed` / `discarded`, o `failed` **(Recomendada)**.\n"
        "  - B) Sin máquina: el cambio de valor se contabiliza al registrarse y la corrida de MRP no guarda estado.\n"
        "- **Impacto si no se responde:** se asume A.\n"
        "- **Bloquea:** §7.26, §7.35, §8.13; RF-STK-099, RF-STK-126.\n"
        "- **Estado:** Asumida la recomendada (DEC-072). T05 (COL-STK-28, COL-STK-40) toma los valores de §8.13.\n\n"
        "## 22. Trazabilidad de fuentes")
save(p, bom, crlf, t)
print('M13 ok: 2 renombres (2 comodines expandidos)')

# ---------------- M14 ----------------
p, bom, crlf, t = load('M14')
t = rep(t, "| `status` | Enum | Sí | `draft`, `active`, `archived` `[VERIFICAR]` (valores propuestos en §8.16.10; antes sin valores). | — |",
        "| `status` | Enum | Sí | `draft`, `active`, `archived` (valores de §8.16.10, asumidos en PA-TES-18; antes propuestos `[VERIFICAR]` y, antes de eso, sin valores). | — |")
t = rep(t, "Valores propuestos `[VERIFICAR]`: `draft`, `active`, `archived` (el §7 declaraba `status` sin valores; ver propuesta de PA en el informe de corrección). Estado inicial propuesto: `draft`.\n\n| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |\n|---|---|---|---|---|\n| (alta) | `draft` | Creación del escenario de simulación `[VERIFICAR]` | — | — |\n| `draft` | `active` | Uso del escenario en la proyección `[VERIFICAR]` | — | — |\n| `draft`, `active` | `archived` | Archivo del escenario `[VERIFICAR]` | — | — |",
        "Valores: `draft`, `active`, `archived` (asumidos en PA-TES-18, DEC-072; antes \"valores propuestos `[VERIFICAR]`\"; el §7 declaraba `status` sin valores). Estado inicial: `draft`.\n\n| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |\n|---|---|---|---|---|\n| (alta) | `draft` | Creación del escenario de simulación | — | — |\n| `draft` | `active` | Uso del escenario en la proyección | — | — |\n| `draft`, `active` | `archived` | Archivo del escenario | — | — |\n\nUn escenario `archived` no se reactiva: se copia como escenario nuevo. El escenario nunca modifica datos reales (`isSimulation = true`).")
t = rep(t, "- **Bloquea:** RN-TES-086 (O5).\n- **Estado:** Asumida la recomendada (DEC-072).\n\n## 22. Trazabilidad",
        "- **Bloquea:** RN-TES-086 (O5).\n- **Estado:** Asumida la recomendada (DEC-072).\n\n"
        "### PA-TES-18 — Estados de `cashFlowScenarios` (PA 19 del pendiente de cierre)\n"
        "- **Pregunta:** ¿Se confirman los estados propuestos del escenario de flujo de fondos?\n"
        "- **Contexto:** el §7.41 declaraba `status` sin valores; la corrección del 05-11-2026 propuso `draft`, `active`, `archived` con `[VERIFICAR]` (§8.16.10).\n"
        "- **Opciones:**\n"
        "  - A) Confirmar `draft` → `active` → `archived` (§8.16.10); un escenario archivado se copia para reutilizarlo **(Recomendada)**.\n"
        "  - B) Sin estado: el escenario existe o se elimina.\n"
        "- **Impacto si no se responde:** se asume A.\n"
        "- **Bloquea:** §7.41, §8.16.10; CU-TES-11.\n"
        "- **Estado:** Asumida la recomendada (DEC-072); se quitan los `[VERIFICAR]` de §8.16.10.\n\n"
        "## 22. Trazabilidad")
save(p, bom, crlf, t)
print('M14 ok')

# ---------------- M15 ----------------
p, bom, crlf, t = load('M15')
t = rep(t, "centros de costo, grupos, reglas y modelos de asignación, corridas",
        "centros de costo, grupos, reglas, modelos de centro de costo (`costCenterModels`, PA-CON-18) y modelos de asignación, corridas")
t = rep(t, "| `costCenterModelId` | ObjectId | No | — | `distributionModels` (M15) [VERIFICAR] |",
        "| `costCenterModelId` | ObjectId | No | Modelo de centro de costo por defecto del rol (PA-CON-18). | `costCenterModels` (M15) (antes `distributionModels` (M15) [VERIFICAR]) |")
t = rep(t, "| `costCenterModelId` / `costCenterId` | ObjectId | No | Centro o modelo. | `distributionModels` (M15) [VERIFICAR] / `costCenters` (M15) |",
        "| `costCenterModelId` / `costCenterId` | ObjectId | No | Centro o modelo (PA-CON-18). | `costCenterModels` (M15) (antes `distributionModels` (M15) [VERIFICAR]) / `costCenters` (M15) |")
t = rep(t, "| `version` | Int | Sí | — | — |\n\n### 7.20 `costDistributionRuns`",
        "| `version` | Int | Sí | — | — |\n\n"
        "### 7.19.1 `costCenterModels` — modelos de centro de costo (PA-CON-18)\n\n"
        "Propósito: modelo con nombre que define cómo se reparte entre centros de costo un importe imputado a una cuenta. Lo citan `accountRoles.costCenterModelId`, `postingRules.costCenterModelId` y las líneas de plantillas de asiento (`lines[].costCenterModelId`); antes esas referencias no tenían colección destino (T05 §7.2 lo marcaba `[VERIFICAR]`). Se distingue de `distributionModels`, que reparte costos comunes en la corrida analítica (§7.20): un modelo de centro de costo puede delegar en un modelo de distribución para el reparto dinámico.\n\n"
        "| Campo | Tipo | Oblig. | Descripción | Referencia |\n|---|---|---|---|---|\n"
        "| `code` | String | Sí | Ej. `MCC-COMUN-01`. | — |\n"
        "| `name` | String | Sí | — | — |\n"
        "| `splits` | `[{ costCenterId, pct }]` | Cond. | Reparto fijo; los porcentajes suman 100. Obligatorio si no hay `distributionModelId`. | `costCenters` (M15) (solo `costCenterId`) |\n"
        "| `distributionModelId` | ObjectId | Cond. | Reparto dinámico delegado; alternativo a `splits`. | `distributionModels` (M15) |\n"
        "| `validFrom` / `validTo` | Date | Sí / No | Vigencia. | — |\n"
        "| `status` | Enum | Sí | `active`, `inactive` (§8.11.8). | — |\n"
        "| `version` | Int | Sí | — | — |\n\n"
        "Índice: `{ tenantId, code, version }` único.\n\n"
        "### 7.20 `costDistributionRuns`")
t = rep(t, "#### 8.11.8 Centros de costo, grupos y modelos de reparto (`costCenters.status`, `costCenterGroups.status`, `distributionModels.status`)",
        "#### 8.11.8 Centros de costo, grupos y modelos de reparto (`costCenters.status`, `costCenterGroups.status`, `distributionModels.status`, `costCenterModels.status`)")
t = rep(t, "- **Impacto si no se responde**: A (PRM-CON-193). **Bloquea**: M-134, M-135, RN-CON-124, ficha CEM de T12 parte 2.\n\n## 22. Trazabilidad",
        "- **Impacto si no se responde**: A (PRM-CON-193). **Bloquea**: M-134, M-135, RN-CON-124, ficha CEM de T12 parte 2.\n\n"
        "### PA-CON-18 — Colección del modelo de centro de costo (PA 10 del pendiente de cierre)\n\n"
        "- **Pregunta**: ¿`costCenterModelId` (en `accountRoles`, `postingRules` y plantillas de asiento) apunta a una colección propia o es un código?\n"
        "- **Contexto**: el campo existía sin colección destino; T05 §7.2 lo marcaba `[VERIFICAR]` y este anexo apuntaba a `distributionModels` con duda.\n"
        "- **Opciones**: A) **(Recomendada)** M15 declara la colección `costCenterModels` (§7.19.1) con reparto fijo o delegado en un modelo de distribución. B) `costCenterModelId` como código sin colección.\n"
        "- **Estado**: Asumida la recomendada (DEC-072). T05 agrega la colección `costCenterModels` (M15) y la referencia de `costCenterModelId`. No cambia ninguna ola de RF.\n"
        "- **Impacto si no se responde**: A. **Bloquea**: §7.5, §7.6, §7.19.1; T05 §7.2.\n\n"
        "## 22. Trazabilidad")
save(p, bom, crlf, t)
print('M15 ok')
