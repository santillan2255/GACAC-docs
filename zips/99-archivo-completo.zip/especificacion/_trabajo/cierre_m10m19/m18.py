import re
from h import *

p, bom, crlf, t = load('M18')
TOK = re.compile(r'(?<![A-Za-z])productId(?![A-Za-z])')
lines = t.split('\n')
cnt = 0
for i, l in enumerate(lines):
    if not TOK.search(l):
        continue
    if l.startswith('| `productId` |'):
        cells = split_cells(l)
        assert len(cells) == 5, l
        cells[0] = ' `inventoryItemId` '
        d = cells[3].strip()
        cells[3] = ' ' + ('Antes `productId` (PA-SOC-16).' if d in ('—', '') else d + ' Antes `productId` (PA-SOC-16).') + ' '
        cells[4] = ' `inventoryItems` (M13) (antes `inventoryItems` (M13) [VERIFICAR] (T05 nombra `inventoryItemId` a esta referencia)) '
        assert '[VERIFICAR] (T05 nombra' in l
        lines[i] = join_cells(cells)
    else:
        m = TOK.search(l)
        l2 = TOK.sub('inventoryItemId', l)
        pos = m.end() + len('inventoryItemId') - len('productId')
        if l2[:pos].count('`') % 2 == 1:
            pos = l2.index('`', pos) + 1
        lines[i] = l2[:pos] + ' (antes `productId`; PA-SOC-16)' + l2[pos:]
    cnt += 1
t = '\n'.join(lines)

t = rep(t, "| API key con scope `soc.gps.write` |",
        "| API key con scope `soc.gps.registrar` (antes `soc.gps.write`) |")

# housingPlans.status
t = rep(t, "| `status` | Enum | Sí | Valores `[VERIFICAR]`: el anexo no los enumera ni define su máquina en el §8. | — |",
        "| `status` | Enum | Sí | `draft`, `active`, `closed` (§8.1.8; PA-SOC-18; antes \"Valores `[VERIFICAR]`: el anexo no los enumera ni define su máquina en el §8\"). | — |")
# providerAgreements / donationCampaigns
t = rep(t, "| `draft`, `active`, `ended` `[VERIFICAR]` (valores propuestos en §8.1.6; antes sin valores). |",
        "| `draft`, `active`, `ended` (valores de §8.1.6, asumidos en PA-SOC-18; antes propuestos `[VERIFICAR]` y, antes de eso, sin valores). |")
t = rep(t, "| `planned`, `open`, `closed`, `cancelled` `[VERIFICAR]` (valores propuestos en §8.1.7; antes sin valores). |",
        "| `planned`, `open`, `closed`, `cancelled` (valores de §8.1.7, asumidos en PA-SOC-18; antes propuestos `[VERIFICAR]` y, antes de eso, sin valores). |")
a = t.index("#### 8.1.6 Convenio con prestador")
b = t.index("## 9. Procesos y flujos", a)
sec = t[a:b]
assert sec.count("Valores propuestos `[VERIFICAR]`:") == 2
sec = sec.replace("Valores propuestos `[VERIFICAR]`:", "Valores (asumidos en PA-SOC-18, DEC-072; antes \"valores propuestos `[VERIFICAR]`\"):")
sec = sec.replace("Estado inicial propuesto:", "Estado inicial:")
sec = sec.replace(" `[VERIFICAR]` | — |", " | — |")
assert sec.count("[VERIFICAR]") == 2, sec.count("[VERIFICAR]")
sec += ("#### 8.1.8 Plan de vivienda (`housingPlans.status`)\n\n"
        "Valores: `draft`, `active`, `closed` (PA-SOC-18; antes el §7 no los enumeraba). Estado inicial: `draft`.\n\n"
        "| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |\n|---|---|---|---|---|\n"
        "| (alta) | `draft` | Carga del plan y sus tipologías | — | — |\n"
        "| `draft` | `active` | Habilitación del plan para nuevas adhesiones | Al menos una tipología con precio vigente (`housingPrices`) | — |\n"
        "| `active` | `closed` | Cierre del plan a nuevas adhesiones | — | — |\n\n"
        "Un plan `closed` no admite adhesiones nuevas, pero conserva las unidades, aportes y adjudicaciones existentes hasta su entrega.\n\n")
t = t[:a] + sec + t[b:]

t = rep(t, "**Bloquea:** Priorización de §5.7 y §5.8.\n\n## 22. Trazabilidad",
        "**Bloquea:** Priorización de §5.7 y §5.8.\n\n"
        "### PA-SOC-16 — Referencia al artículo de stock en vivienda (PA 20 del pendiente de cierre)\n\n"
        "**Pregunta:** ¿Cómo se llama el campo que referencia al artículo de M13 en tipologías y materiales de vivienda?\n"
        "**Contexto:** el anexo usaba `productId` (de `COD_PRO`) y T05 lo nombra `inventoryItemId`, apuntando a `inventoryItems` (M13).\n"
        "**Opciones:**\n"
        "- A) **(Recomendada)** `inventoryItemId`, como T05 y M13.\n"
        "- B) Mantener `productId`.\n"
        "**Impacto si no se responde:** se aplica A.\n"
        "**Bloquea:** §7 (`housingPlans`, `housingActivityMaterials`, `housingProgressMaterials`, `housingMaterialAllocations`, `housingMaterialWithdrawals`).\n"
        "**Estado:** Asumida la recomendada (DEC-072). Renombrado con la nota \"antes `productId`\".\n\n"
        "### PA-SOC-17 — API-SOC-006: endpoint HTTP o servicio interno (PA 21 del pendiente de cierre)\n\n"
        "**Pregunta:** ¿Los insumos de facturación de servicios sociales (API-SOC-006) son un endpoint HTTP o un servicio interno?\n"
        "**Contexto:** M04 y T12 la citan como API-SOC-006; el anexo la describía como servicio interno para M04.\n"
        "**Opciones:**\n"
        "- A) **(Recomendada)** Endpoint HTTP `GET /api/admin/soc/contracts/:id/billing-inputs` que consume M04, con capability `soc.adherentes.ver`.\n"
        "- B) Servicio interno sin ruta HTTP.\n"
        "**Impacto si no se responde:** se aplica A.\n"
        "**Bloquea:** API-SOC-006; cálculo de M04.\n"
        "**Estado:** Asumida la recomendada (DEC-072); API-SOC-006 ya figura como endpoint HTTP en §11.\n\n"
        "### PA-SOC-18 — Estados de convenios, campañas de donación y planes de vivienda (PA 19 del pendiente de cierre)\n\n"
        "**Pregunta:** ¿Se confirman los estados de `providerAgreements`, `donationCampaigns` y `housingPlans`?\n"
        "**Contexto:** el §7 declaraba `status` sin valores; la corrección del 05-11-2026 propuso valores con `[VERIFICAR]` para convenios y campañas (§8.1.6, §8.1.7), y `housingPlans` no tenía valores.\n"
        "**Opciones:**\n"
        "- A) **(Recomendada)** Confirmar §8.1.6 y §8.1.7 y agregar §8.1.8 (`draft`, `active`, `closed`) para planes de vivienda.\n"
        "- B) Derivar el estado de las fechas de vigencia sin campo `status`.\n"
        "**Impacto si no se responde:** se aplica A.\n"
        "**Bloquea:** §8.1.6 a §8.1.8.\n"
        "**Estado:** Asumida la recomendada (DEC-072); se quitan los `[VERIFICAR]` de esas secciones.\n\n"
        "## 22. Trazabilidad")
save(p, bom, crlf, t)
print('M18 ok; lineas productId:', cnt, '; renombres capability: 1')
