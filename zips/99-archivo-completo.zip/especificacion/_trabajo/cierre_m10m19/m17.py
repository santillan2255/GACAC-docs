import re
from h import *

p, bom, crlf, t = load('M17')
TOK = re.compile(r'(?<![A-Za-z])membershipId(?![A-Za-z])')
NOTE355 = "Los campos `membershipId` de las demás colecciones apuntan a `associateMemberships`."
t = rep(t, NOTE355,
        "Los campos que apuntan a `associateMemberships` se llaman `associateMembershipId` (PA-INS-12; antes `membershipId`, que se confundía con `memberships` de T02).")
lines = t.split('\n')
fields = other = 0
for i, l in enumerate(lines):
    if not TOK.search(l) or 'PA-INS-12' in l:
        continue
    if l.startswith('| `membershipId` |'):
        cells = split_cells(l)
        assert len(cells) == 5, l
        cells[0] = ' `associateMembershipId` '
        d = cells[3].strip()
        d = 'Antes `membershipId` (PA-INS-12).' if d in ('—', '') else d + ' Antes `membershipId` (PA-INS-12).'
        cells[3] = ' ' + d + ' '
        lines[i] = join_cells(cells)
        fields += 1
    else:
        m = TOK.search(l)
        first = m.end()
        l2 = TOK.sub('associateMembershipId', l)
        # nota "antes" tras la primera ocurrencia renombrada (y cierre de backtick si lo hay)
        pos = first + len('associateMembershipId') - len('membershipId')
        if l2[:pos].count('`') % 2 == 1:
            pos = l2.index('`', pos) + 1
        lines[i] = l2[:pos] + ' (antes `membershipId`)' + l2[pos:]
        other += 1
t = '\n'.join(lines)
assert not TOK.search(t.replace('antes `membershipId`', '').replace('Antes `membershipId`', '')), 'quedan'

t = rep(t, "| Sistema externo (API key) | Scope `ins.status.read` |",
        "| Sistema externo (API key) | Scope `ins.status.ver` (antes `ins.status.read`) |")
t = rep(t, "| API key con scope `ins.status.read` |",
        "| API key con scope `ins.status.ver` (antes `ins.status.read`) |")
t = rep(t, "| `plataforma.catalogos.gestionar` | Catálogo base de categorías INAES |",
        "| `ins.catalogosBase.gestionar` (capability de plataforma; antes `plataforma.catalogos.gestionar`) | Catálogo base de categorías INAES |")
t = rep(t, "| CU-INS-01 | Solicitar ingreso como asociado (PWA) |",
        "| CU-INS-15 (antes CU-INS-01; ese ID es de M10, «CU-INS-01 (BASE §73, parte técnica) — Instalación integral») | Solicitar ingreso como asociado (PWA) |")
t = rep(t, "**Bloquea:** RF-INS-064, JOB-INS-07.\n\n## 22. Trazabilidad",
        "**Bloquea:** RF-INS-064, JOB-INS-07.\n\n"
        "### PA-INS-12 — Nombre del campo que apunta al padrón de asociados (PA 9 del pendiente de cierre)\n\n"
        "**Pregunta:** ¿Cómo se llama el campo que referencia a `associateMemberships` en las colecciones de M17 y en los eventos `ins.membership.*`?\n"
        "**Contexto:** el anexo usaba `membershipId`, que coincide con la referencia a `memberships` (relación usuario–tenant) de T02 y produce ambigüedad en T05 y en los consumidores de eventos.\n"
        "**Opciones:**\n"
        "- A) **(Recomendada)** `associateMembershipId`, alineado con el nombre de la colección `associateMemberships`.\n"
        "- B) Mantener `membershipId` y aclarar el destino en cada referencia.\n"
        "**Impacto si no se responde:** se aplica A.\n"
        "**Bloquea:** §7, EVT-INS-01 a EVT-INS-07, JOB-INS-07; T05 §7.7.\n"
        "**Estado:** Asumida la recomendada (DEC-072). Se renombra en todo el anexo con la nota \"antes `membershipId`\"; T05 y los consumidores de `ins.membership.*` (M01, M04, M05, M18, M19, T09, T11) adoptan el nombre nuevo.\n\n"
        "## 22. Trazabilidad")
save(p, bom, crlf, t)
print('M17 ok; filas de campo:', fields, 'otras lineas:', other, '; renombres capability: 3')
