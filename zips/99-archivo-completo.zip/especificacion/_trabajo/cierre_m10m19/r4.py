import re
from h import *

ANTES = re.compile(r'\((?:[^()]|\([^()]*\))*?\bantes\b(?:[^()]|\([^()]*\))*\)', re.I)


def rename_cell(c, mp):
    # protege notas "antes" existentes
    prot = []

    def keep(m):
        prot.append(m.group(0))
        return '\x00%d\x00' % (len(prot) - 1)
    s = ANTES.sub(keep, c)
    olds = []
    for old, new in mp:
        pat = re.compile('`' + re.escape(old) + '`')
        if pat.search(s):
            s = pat.sub('`' + new + '`', s)
            olds.append(old)
    if not olds:
        return c, 0
    for i, p in enumerate(prot):
        s = s.replace('\x00%d\x00' % i, p)
    note = ', '.join('`' + o + '`' for o in olds)
    m = re.search(r'\(antes `', s)
    if m and s.count('(antes `') == 1:
        s = s[:m.start()] + '(antes ' + note + '; ' + s[m.start() + len('(antes '):]
    else:
        s = s.rstrip() + ' (antes ' + note + ') '
    return s, len(olds)


def apply(prefix, mp, only=None):
    p, bom, crlf, t = load(prefix)
    L = t.split('\n')
    n = 0
    in21 = False
    for i, l in enumerate(L):
        if l.startswith('## '):
            in21 = l.startswith('## 21')
        if in21 or not l.startswith('|'):
            continue
        if only and not any(k in l for k in only):
            continue
        cells = split_cells(l)
        ch = 0
        for ci, c in enumerate(cells):
            c2, k = rename_cell(c, mp)
            if k:
                cells[ci] = c2
                ch += k
        if ch:
            L[i] = join_cells(cells)
            n += ch
    save(p, bom, crlf, '\n'.join(L))
    return n


M10 = [
    ('tec.campo.enCamino', 'tec.campo.marcarEnCamino'),
    ('tec.campo.conformidad', 'tec.campo.registrarConformidad'),
    ('tec.campo.materiales', 'tec.campo.registrarMateriales'),
    ('tec.campo.crearOt', 'tec.campo.crearOrden'),
    ('tec.perfilTecnico.secretos', 'tec.perfilTecnico.verSecretos'),
    ('tec.telefonia.redFisica.*', 'tec.telefonia.redFisica.ver`, `tec.telefonia.redFisica.editar'),
    ('tec.telefonia.numeracion.*', 'tec.telefonia.numeracion.ver`, `tec.telefonia.numeracion.editar`, `tec.telefonia.numeracion.configurar'),
    ('tec.telefonia.lineas.*', 'tec.telefonia.lineas.ver`, `tec.telefonia.lineas.editar'),
    ('tec.estimate.gestionar', 'tec.estimaciones.gestionar'),
    ('tec.dispatch.gestionar', 'tec.despacho.gestionar'),
    ('tec.crew.gestionar', 'tec.cuadrillas.gestionar'),
    ('tec.fieldForm.gestionar', 'tec.formulariosCampo.gestionar'),
    ('tec.networkDevice.gestionar', 'tec.equiposRed.gestionar'),
    ('tec.levy.gestionar', 'tec.contribucionesObra.gestionar'),
    ('tec.serviceTechnical.ver/editar', 'tec.servicioTecnico.ver/editar'),
    ('tec.serviceTechnical.ver', 'tec.servicioTecnico.ver'),
    ('tec.serviceTechnical.editar', 'tec.servicioTecnico.editar'),
    ('tec.device.gestionar', 'tec.dispositivos.gestionar'),
]
print('M10', apply('M10', M10))
print('M12', apply('M12', [('cmp.cotizaciones.*', 'cmp.cotizaciones.ver`, `cmp.cotizaciones.crear`, `cmp.cotizaciones.editar`, `cmp.cotizaciones.evaluar')]))
print('M14', apply('M14', [('cob.cajas.ver', 'cob.caja.ver')]))
print('M16', apply('M16', [('sue.portal.datos.ver/proponerCambio', 'sue.portal.datos.ver/editar')]))
print('M18', apply('M18', [('soc.vivienda.cobranza', 'soc.vivienda.gestionarCobranza')]))
