from h import *

p, bom, crlf, t = load('M18')
t = rep(t, "| `inventoryItems` (M13) (antes `inventoryItems` (M13) [VERIFICAR] (T05 nombra `inventoryItemId` a esta referencia)) |",
        "| `inventoryItems` (M13) (antes con `[VERIFICAR]`; T05 ya la nombraba `inventoryItemId`) |", count=3)
save(p, bom, crlf, t)
print('ok')
