import glob, os, re
for f in sorted(glob.glob('../anexos/M1[2-9]-*.md')):
    for i, l in enumerate(open(f, encoding='utf-8').read().split('\n'), 1):
        if re.search(r'\(alta[^)]*→', l) or re.search(r'[Ee]stado inicial', l):
            print(os.path.basename(f)[:3], i, l[:200])
