import re, sys
# uso: python res_sec.py archivo "^## 8\." [ancho]  -> imprime la sección desde el encabezado hasta el siguiente del mismo nivel
f, pat = sys.argv[1], sys.argv[2]
w = int(sys.argv[3]) if len(sys.argv) > 3 else 400
L = open(f, encoding='utf-8-sig').read().split('\n')
ini = next(i for i, l in enumerate(L) if re.search(pat, l))
lvl = len(L[ini]) - len(L[ini].lstrip('#'))
fin = next((i for i in range(ini + 1, len(L)) if re.match(r'^#{1,%d} ' % lvl, L[i])), len(L))
for i in range(ini, fin):
    print(i + 1, L[i][:w])
