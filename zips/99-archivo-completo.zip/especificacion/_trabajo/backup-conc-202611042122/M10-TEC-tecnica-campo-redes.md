# M10 TEC — Técnica, campo, agenda, instalación, GIS/redes, obras, aprovisionamiento TIC y telefonía

| Campo | Valor |
|---|---|
| Versión | 1.0 |
| Estado | Especificación consolidada — pendiente de validar preguntas abiertas |
| Solución (BASE §105) | ERP (operación técnica, redes, obras) / CRM (OT derivada de reclamos, visitas) / Landing-autogestión (reserva y seguimiento de visita) / APIs (aprovisionamiento e importación de CDR) |
| Olas | **O3** (factibilidad, presupuesto de conexión, agenda y visitas, OT núcleo, instalación integral, cuadrillas y recursos, app de campo offline, aprovisionamiento de Internet, geolocalización operativa, inventario mínimo de nodos/equipos ISP) · **O6** (ejecución de cortes y reconexiones integrados con mora y aprovisionamiento) · **O7** (GIS de red eléctrica y genérica, mantenimiento e infraestructura, análisis de impacto, obras y contribución por mejoras, inspecciones y consumo no registrado, necesidades de materiales de mantenimiento, exportaciones GIS) · **O10** (telefonía: red física, numeración, líneas, importación de CDR de 20+ centrales, CPP de operadoras, telefonía móvil; TV/otros TIC; correo provisto) · **O11** (informes avanzados y estadísticas técnicas en BI) |
| Dueño de datos | `feasibilityRequests`, `connectionEstimates`, `technicalNotes`, `operationTypes`, `workTypes`, `incidentCategories`, `resolutionCodes`, `taskCatalog`, `taskGroups`, `workOrderPrintTemplates`, `chainedOrderRules`, `workOrders`, `workOrderMaterials`, `fieldEvidence`, `serviceConformities`, `damageAssessments`, `technicalProcedures`, `visitTypes`, `schedulingZones`, `resourceCalendars`, `visitBookings`, `visits`, `crews`, `fieldResources`, `responsibleNotificationRules`, `certifiedInstallers`, `fieldForms`, `fieldDevices`, `syncMutations`, `syncConflicts`, `maintenancePlans`, `outagePlans`, `networks`, `networkLayers`, `networkComponentTypes`, `networkComponentRelations`, `networkAttributeDefs`, `networkElements`, `serviceNetworkConnections`, `gisExportTemplates`, `networkDevices`, `provisioningSystems`, `provisioningProfiles`, `serviceTechnicalProfiles`, `provisioningCommands`, `works`, `workGroups`, `workBeneficiaries`, `inspectionCases`, `seals`, `phoneExchanges`, `phoneFrames`, `phoneFrameGroups`, `phoneStrips`, `phoneStripPositions`, `phoneBoxes`, `dslams`, `phonePorts`, `phonePrefixes`, `phoneNumbers`, `phoneLines`, `numberingPlan`, `telecomOperators`, `telecomServiceTypes`, `telecomModalities`, `cdrImports`, `callRecords`, `mobileUsageImports`, `providedMailboxes` |
| Fuentes consolidadas | BASE §17, §18, §50 (AUT-003, AUT-004, agenda y visitas, CU-AUT-01), §73 (INS-001 a INS-007), §74, §77 (GEO-001 a GEO-003, operativo), §79, §80, §86, §37, §98, §101, §106 (pendientes técnicos), MER-004, MER-009, MER-015 (ref.), MER-017, MER-019 (ref.), MER-020 (ref.); AGR-003, AGR-010, AGR-016, AGR-023, AGR-025, AGR-026, ESC-03; DFA M14 (§15), M15 (§16), telefonía/internet (§27 M26), M27 (§28), §31 proceso 1; FIC 4 (PMovil), 9 (telemedición y aprovisionamiento), 10 (mapas/GIS), 14.2, 16, 17; RN-07 §0 a §11 completo; RN-10 §4, §9, §10; RN-09 TECNICA (95 parámetros) y TELEFONIA (16 parámetros), más parámetros de RN-07 §9; CAT §10, §11, §12 completas (y tablas citadas de otras secciones: `CONEXION`, `ALTASEAU`, `VIAINGTE`, `ESTASER`, `SERVICIO_EXTRAS`, `OBSESTAD`, `ITEMSORD`, `PROD_TRH`, `RETI_MAT`, `UBICACIONES`, `CAT_INCI_CTSEC`, `CTSECCION`, `MAPA`, `EQUIPOS`, `MODEMS`, `SERVINT`, `CUADRI`, `TELEMEDICION`, `TELEMED_COMM`, `PRESUPU`, `SERSOC_EXTRAS`); INV `ProMod_Tecnica.md` (142 tipos, 61 formularios, 3 controles); CNX §3.7, §3.8, §4.4, §7.7, §7.8 |

## 1. Objetivo

Especificar de forma completa y desarrollable la **operación técnica** de la cooperativa en GoodApps Cooperativas: desde que una solicitud de servicio necesita evaluarse en terreno hasta que el trabajo está ejecutado, revisado, con evidencia y con su efecto contractual autorizado. El módulo cubre:

1. **Factibilidad técnica** de nuevas conexiones, traslados y reconexiones, con inspección, dictamen, vigencia y vínculo con el alta.
2. **Estimación técnica y presupuesto de conexión** (cómputo de materiales, mano de obra y obra necesaria) que alimenta el presupuesto comercial.
3. **Órdenes de trabajo (OT)** de todos los tipos (trabajo sobre servicio, mantenimiento sobre activo/obra, OT derivada de reclamo, inspección), con catálogo de operaciones de efecto declarativo, tareas, participantes y horas, vehículos, necesidades y consumo de materiales, resolución, notas, datos extra, reportes de impresión, numeración visible, órdenes encadenadas y operaciones masivas.
4. **Agenda y visitas**: zonas, tipos de visita, franjas, capacidad por recurso, reserva temporal y confirmada sin doble asignación, reprogramación, cancelación, resultado de visita y estado visible al socio ("En camino" sin GPS en vivo).
5. **Instalación integral** (BASE §73): cita, equipo identificado en custodia del instalador, prueba, conformidad/firma, aplicación única del movimiento de stock, encuesta posterior independiente y **hito de activación con fecha efectiva** para el contrato y la facturación.
6. **Cuadrillas, recursos de campo, profesionales matriculados, tipos de trabajo** y reglas de notificación por horario/feriado.
7. **App de campo única offline-first** (perfiles técnico, lecturista, cobrador) con cola única, fotos, GPS, firma, materiales que descuentan stock, idempotencia y **tratamiento de conflictos de sincronización** (AGR-025, ESC-03).
8. **Cortes y reconexiones** ejecutados en terreno o en forma remota, decididos por el módulo de mora o por el CRM.
9. **Mantenimiento e infraestructura y mapas** (BASE §18): inventario técnico por ubicación, planes preventivos, averías, interrupciones planificadas, contratos afectados, historial y costo por activo.
10. **Red / GIS** genérica configurable (red eléctrica, agua, gas, telecomunicaciones): componentes, atributos tipados, capas, relaciones permitidas, red instalada georreferenciada, vínculo servicio-red con historial y **análisis de impacto** ante el corte de un elemento (por ejemplo un transformador) con aviso masivo.
11. **Equipos de red y centrales** (OLT, routers, NAS/Radius, centrales telefónicas, DSLAM).
12. **Obras, loteos y contribución por mejoras** (MER-009): obra, presupuesto, avance, costeo, padrón de beneficiarios y prorrateo.
13. **Inspecciones y consumo no registrado/fraude** (MER-004): caso, inspección con acta y fotos, precintos, descargo, propuesta de recupero aprobada y derivación a facturación.
14. **Aprovisionamiento de Internet/TV** (MikroTik, Wispro, Radius, SmartOlt, Ispfull, Sensa, Sopnet, SITSA y otros): alta, corte, reconexión, cambio de plan y baja con confirmación del resultado (BASE §86, MER-017).
15. **Telefonía**: red física (centrales, repartidores, regletas, cajas, DSLAM), prefijos, pool de números, líneas del abonado, plan de numeración ENACOM, **importación de CDR** de 20+ modelos de central, CPP de operadoras y telefonía móvil (Claro/Personal). La **tasación** se especifica en M04 TAR.
16. **Geolocalización operativa del servicio** con Google Maps (BASE §77): punto de prestación confirmado/aproximado/pendiente usado por factibilidad, agenda, OT, mapa y red.

Es el corazón operativo del **piloto Internet (DEC-005)**: contratación → **factibilidad → visita/instalación → equipo en comodato → activación/aprovisionamiento** → facturación → pago → reclamo → **mora/suspensión** → baja.

## 2. Límite y responsabilidades

### 2.1 Qué hace este módulo

- Es **dueño** de factibilidades, estimaciones técnicas, OT y su catálogo, agenda y visitas, evidencias de campo, conformidades, cuadrillas y recursos, sincronización offline y conflictos, red/GIS, equipos de red, aprovisionamiento técnico (comandos y su resultado), obras técnicas, inspecciones, red e infraestructura telefónica, numeración y mediación de CDR (importación, normalización, atribución de origen y destino, duplicados).
- Emite **hechos técnicos** con fecha efectiva y fecha de registro (AGR-010): factibilidad dictaminada, visita realizada/fallida, OT ejecutada/cerrada/anulada, equipo aplicado/retirado, instalación probada, aprovisionamiento confirmado, servicio conectado/desconectado físicamente, inspección con irregularidad, llamada importada y atribuida.
- Ejecuta las órdenes de corte y reconexión que **otros módulos deciden** y confirma su resultado.

### 2.2 Qué NO hace

- **No** decide condiciones comerciales, precios, cobros ni cambios de titularidad (BASE §17 límite). No activa el contrato por sí mismo: entrega el **hito técnico** y el módulo dueño del contrato registra la activación con su fecha efectiva (BASE §73, CTR-TEC-18).
- **No** calcula cargos, proporcionales de reconexión o cambio de categoría, prorrateos ni promociones (CTR-TEC-10): los pide a M04/M05 mediante eventos.
- **No** tasa llamadas (M04), **no** emite CVLP (M05/M06), **no** decide la suspensión por mora (M08), **no** administra stock general ni equipos serializados (M13), **no** gestiona el reclamo del socio (M09), **no** construye conectores técnicos genéricos (T06).
- **No** muestra la ubicación en vivo del técnico al socio (BASE §73, §77, MER-015).
- **No** realiza simulación eléctrica avanzada (flujo de carga, caída de tensión) salvo acuerdo expreso (BASE §18; PA-TEC-11).
- **No** inventa consumos de Internet: solo presenta uso si existe una fuente de medición definida (BASE §50 control, §86).

### 2.3 Qué delega y a quién

| Tema | Responsable | Interfaz con TEC |
|---|---|---|
| Solicitudes de alta/baja, reclamos, tickets del socio, SLA de atención, mesa de entradas, actividades internas recurrentes | **M09 CRM** | M09 crea el caso; TEC recibe `crm.case.workOrderRequested` y crea la **OT derivada**; TEC publica avances (`tec.workOrder.*`, `tec.visit.*`) que M09 muestra. Reclamos `RECLAMOS*`, `RUB_REC`, `FALLAS`, tickets (`TICKETS*`) y actividades (`ACT_*`) se especifican en M09 (ver §22). |
| Stock, depósitos, reservas, custodia por persona, equipos serializados, RMA, bienes de uso, valorización | **M13 STK** | TEC solicita reserva/entrega a custodia/aplicación/devolución desde la OT (`stk` service API); M13 registra los movimientos y garantiza aplicación única (BASE §73 tabla, AGR-026). |
| Medidores, lecturas, rutas de lectura, telemedición, prepago, observaciones de lectura | **M03 MED** | La OT de cambio/retiro de medidor invoca a M03; la observación de lectura con `generaOt` crea OT en TEC; el perfil lecturista de la app de campo usa pantallas de M03 sobre el shell común de TEC. |
| Conceptos a cobrar por evento técnico (`CONEXION`), proporcionales, tasación telefónica (`TARTEL`, `TARESP`, `TARCLA`, `BANDAS`, `TIPOBAN`, `BANCLA`, `CLAVES`, `TIPOLLAM`, `PLANDES`, `GRATIS`, `SERTEL`), clearing móvil | **M04 TAR** | TEC emite eventos; M04 evalúa reglas y calcula. |
| Cargos, primera factura, prorrateo de activación, cargos de próxima facturación, CVLP | **M05 FAC** (+ M06 FIS) | Consume `tec.installation.activationConfirmed`, `tec.workOrder.closed`. |
| Decisión de corte/suspensión/reconexión por mora, convenios | **M08 MOR** | M08 emite `mor.suspension.ordered` / `mor.reconnection.ordered`; TEC crea OT o comando de red y responde `tec.disconnection.executed` / `tec.reconnection.executed`. |
| Cobro en campo (perfil cobrador) | **M07 COB** | Pantallas y reglas propias sobre el shell de campo y la cola offline común. |
| Presupuesto comercial al socio (`PRESUPU`), venta de equipo | **M11 VEN** | TEC entrega la estimación técnica; M11 emite presupuesto y registra aceptación. |
| Compras de materiales para obras | **M12 CMP** | Necesidades de obra pueden generar requerimiento de compra. |
| Costos por OT/obra, centros de costo, asiento de consumo | **M15 CON** | Eventos de consumo valorizado por M13; TEC informa horas (`PARTIORD`) y centro de costo. |
| Vehículos, choferes, AVL (`MOVIL`, `CHOFERES`, `AVL_REG`) | **M18 SOC** (flota, MER-015) | TEC referencia vehículos asignados a la OT. |
| Personal y valor hora | **M16 SUE** | Participantes de OT referencian legajo cuando corresponde. |
| Encuestas (motor), notificaciones, plantillas y canales (SMS, WhatsApp, mail, push), avisos masivos | **T09 COM** | TEC dispara invitación de encuesta y avisos; T09 entrega y registra constancias (AGR-024). |
| Conectores, bóveda de credenciales, reintentos, monitoreo de integraciones | **T06 INT** | TEC define comandos de dominio; T06 provee adaptadores (MikroTik, Radius, SmartOlt, Wispro, Ispfull, Sensa, Sopnet, SITSA, AION, Discar, Gretix, Tecnored, Google Maps, Georef). |
| Catálogo geográfico (provincias, localidades, calles), feriados, numeradores, parámetros versionados | **T04 CFG** | TEC consume; la georreferenciación operativa del punto de prestación es de TEC + M01. |
| Inmueble, domicilio de prestación, cuentas, titulares | **M01 PER** | TEC lee y propone corrección de punto; M01 guarda el domicilio. |
| Contrato de servicio y su estado | Módulo dueño del contrato según T05 (colección `serviceContracts`) | TEC envía hito técnico; el contrato registra activación, suspensión y baja. |
| Expediente documental, retención y acceso a evidencias | **T11 WFL** | TEC registra evidencias como documentos del expediente de la OT/caso (AGR-023). |
| Informes regulatorios (OCEBA, ENRE, ENACOM, ERSeP) | **T10 BIA** + M06 | TEC provee datos de interrupciones, reclamos por daños y tráfico. |

## 3. Glosario del módulo

| Término | Definición | Clave de diccionario | Término ProCoop |
|---|---|---|---|
| Factibilidad | Evaluación técnica previa de si es posible conectar/trasladar/reconectar un servicio en un domicilio, con dictamen Factible / No factible y vigencia. | `dict:tec.feasibility` | Factibilidad (`FACTIBIL`) |
| Dictamen técnico | Resultado de la factibilidad con observación técnica, responsable y estado provisorio/definitivo. | `dict:tec.feasibility.verdict` | `FACTIBLE`, `OBS_TEC`, `ESTADO_TEC` |
| Estimación técnica | Cómputo de materiales, mano de obra, obra civil/red necesaria para conectar; base del presupuesto de conexión. | `dict:tec.estimate` | Presupuesto de conexión (`PRESUPU` vinculado, estado Facturado) |
| Orden de trabajo (OT) | Instrucción de trabajo técnico sobre un servicio, un activo/obra o derivada de un reclamo. | `dict:tec.workOrder` | `TECNICA` (`TIP_INCI=2` OT, `=3` OM) |
| Clase de OT | `service` (trabajo sobre servicio), `maintenance` (sobre activo/obra), `claim` (derivada de reclamo), `inspection` (inspección/fraude), `network` (trabajo de red sin servicio). | `dict:tec.workOrder.kind` | `TipoOrden`, `RECLAMO` |
| Operación técnica | Qué se hace en la OT y con qué efecto declarativo sobre el servicio (conectar, desconectar, trasladar, etc.). | `dict:tec.operationType` | Operación / Transacción (`TRANSAC`) |
| Tipo de trabajo | Clasificación del trabajo realizado (instalación, reparación, poda…), con reporte asociado. | `dict:tec.workType` | `TPTRAB` |
| Categoría de incidente | Tipificación técnica de la causa (para reclamos y mantenimiento) con distribución % por sección/centro de costo. | `dict:tec.incidentCategory` | `CAT_INCI`, `CAT_INCI_CTSEC` |
| Resolución | Cómo se resolvió la OT; catálogo por servicio + operación. | `dict:tec.resolution` | `RESOL_OT` |
| Tarea | Actividad elemental registrada en la OT, agrupable. | `dict:tec.task` | `TAREAS`, `TAREASOM`, `GRPTAREA`, `TAROTM` |
| Participante | Persona que intervino en la OT con horas normales y extras. | `dict:tec.participant` | `PARTIORD`, `PARTIINC` |
| Cuadrilla | Equipo de trabajo con integrantes, zona, capacidad y depósito/custodia. | `dict:tec.crew` | `CUADRI` + `PARTICUA` |
| Recurso de campo / responsable | Persona operativa (técnico, instalador, lecturista, cobrador) con depósito propio y canales de aviso. | `dict:tec.fieldResource` | `RESPONSA` |
| Profesional matriculado | Instalador externo con matrícula y certificado (electricidad, gas). | `dict:tec.certifiedInstaller` | `PROFESIO`, `NRO_CERT`, `VTO_CERT` |
| Necesidad de materiales | Circuito solicitado → autorizado → retirado → utilizado por producto y depósito. | `dict:tec.materialNeed` | `TECNICA_NECESIDAD` |
| Material de la OT | Línea propia de material previsto/usado/devuelto que genera movimientos en M13. | `dict:tec.workOrderMaterial` | `MOV_PRO` op. 3/5/6/8, `RETI_MAT` (vales) |
| Vale de retiro | Comprobante de retiro de materiales de depósito para una OT u obra. | `dict:tec.withdrawalSlip` | `RETI_MAT` |
| Visita | Presencia programada en el domicilio con franja, recurso y resultado. | `dict:tec.visit` | — (no existe en ProCoop) |
| Reserva temporal | Bloqueo de capacidad por tiempo limitado mientras el socio/operador confirma. | `dict:tec.booking.hold` | — |
| Reserva confirmada | Turno asignado al caso/servicio, notificado al socio. | `dict:tec.booking.confirmed` | — |
| En camino | Estado de avance informado por el técnico; no implica GPS en vivo. | `dict:tec.visit.enRoute` | — |
| Visita fallida | Visita sin poder realizar el trabajo (sin acceso, ausente, falta material, condición técnica). | `dict:tec.visit.failed` | — |
| Conformidad | Constancia de aceptación/disconformidad del receptor sobre el detalle presentado, con firma manuscrita en pantalla u otro mecanismo. | `dict:tec.conformity` | `RESP_ENC`, `MOTIVO_DISCONFORME`, firma PMovil (V2 #50) |
| Hito de activación | Hecho técnico (instalación probada y confirmada) que habilita al contrato a activarse desde una fecha efectiva. | `dict:tec.activationMilestone` | Cierre OT de Alta (`Conectar_SERSOC(FEC_CONFIR)`) |
| Custodia | Responsable físico actual de un equipo/material (depósito, técnico, domicilio). | `dict:tec.custody` | `RESPONSA.COD_DPS` |
| Comodato | Modalidad de entrega de equipo propiedad de la cooperativa al socio. | `dict:tec.equipment.loan` | — |
| App de campo | PWA única offline-first con landing por perfil técnico, lecturista y cobrador. | `dict:tec.fieldApp` | PMovil / Captor / Procoop Integra |
| Mutación de campo | Operación registrada sin conexión con `clientMutationId` para envío idempotente. | `dict:tec.sync.mutation` | Sincronización por tablas MySQL |
| Conflicto de sincronización | Diferencia entre lo hecho en campo y el estado del servidor que requiere decisión. | `dict:tec.sync.conflict` | `BLOQUEAR`, parámetro V2 #57 |
| Red | Conjunto de infraestructura de un servicio (eléctrica, agua, telecom). | `dict:tec.network` | `REDES` (v2), `NIV_*` (v1) |
| Capa | Subdivisión de la red (MT, BT, troncal, distribución). | `dict:tec.network.layer` | `REDES_CAPAS`, `NIV_CAPA` |
| Componente | Tipo de elemento de red (subestación, alimentador, transformador, poste, caja, OLT, splitter). | `dict:tec.network.componentType` | `REDES_COMPONENTES`, `NIV_SERV` |
| Elemento de red | Instancia instalada de un componente, con padre, ubicación, atributos y estado. | `dict:tec.network.element` | `REDES_RED_INSTALADA`, `NIV_REDES` |
| Punto de conexión | Elemento que admite conectar servicios (uno o varios, rango de bornes/pares/puertos). | `dict:tec.network.connectionPoint` | `PERMITE_CONECTAR`, `MULTIPLES_CONEXIONES`, `ELEMENTO_INICIAL..FINAL` |
| Análisis de impacto | Cálculo de servicios y contratos aguas abajo de un elemento afectado. | `dict:tec.network.impact` | — (mejora DFA M15) |
| Interrupción planificada | Corte programado de un tramo de red con aviso a afectados. | `dict:tec.outagePlan` | — |
| Equipo de red | OLT, router/BRAS MikroTik, NAS/Radius, central telefónica, DSLAM. | `dict:tec.networkDevice` | `MIKROTIK`, `TEL_CENTRAL`, `CENTRALT`, `TEL_DSLAM` |
| Sistema de aprovisionamiento | Plataforma externa que ejecuta altas/cortes/cambios de plan. | `dict:tec.provisioningSystem` | `Sistemas_Telemedicion` (ISP/TV) |
| Comando de aprovisionamiento | Solicitud durable e idempotente de acción en red con resultado confirmado. | `dict:tec.provisioningCommand` | `TELEMED_COMM` |
| Perfil técnico del servicio | Datos técnicos de la conexión (usuario PPPoE, MAC, IP, OLT/slot/puerto/vport, ONU, perfil de velocidad). | `dict:tec.serviceTechnicalProfile` | `INTERNET`, `SERSOC.INT_RED/INT_TEL/ID_SYS_TEL` |
| Obra | Proyecto de infraestructura con presupuesto, avance y costeo; puede distribuir su costo entre beneficiarios. | `dict:tec.work` | `OBRAS`, `GRPOBRA` |
| Contribución por mejoras | Distribución aprobada del costo de una obra entre frentistas/beneficiarios. | `dict:tec.improvementLevy` | — (MER-009) |
| Caso de inspección | Expediente de sospecha de consumo no registrado/fraude con inspección, acta, descargo y recupero. | `dict:tec.inspectionCase` | `TECNICA_EXTRAS` (parcial) |
| Precinto | Sello numerado colocado/retirado en medidor o caja. | `dict:tec.seal` | — |
| Central telefónica | Equipo de conmutación con modalidad de CDR, prefijo y moneda. | `dict:tec.phoneExchange` | `TEL_CENTRAL`, `CENTRALT` |
| Repartidor / regleta / caja | Elementos de la red física telefónica con posiciones de conexión. | `dict:tec.phoneFrame` | `TEL_REPARTIDOR`, `TEL_REGLETAS_*`, `TEL_CAJAS`, `TEL_POS_REG_*` |
| Pool de números | Números telefónicos disponibles/asignados por prefijo. | `dict:tec.phoneNumber` | `TEL_NUMEROS`, `TEL_PREFIJO` |
| Línea telefónica | Vínculo vigente entre servicio, número y plan tarifario. | `dict:tec.phoneLine` | `TEL_SERSOC` |
| Plan de numeración | Prefijos de destino ENACOM con operador, modalidad y clave. | `dict:tec.numberingPlan` | `CARACTER` |
| CDR | Registro de detalle de llamada importado de una central u operadora. | `dict:tec.cdr` | `LLAMADAS`, `ENTRANTE`, `INTERNAC`, `LLA_CEL`, `RECHAZOS` |
| CPP | Llamada a celular donde el importe lo fija la operadora móvil (Calling Party Pays). | `dict:tec.cdr.cpp` | `LLA_CEL` |
| Numeración visible | Número legible de OT por año/servicio/operación. | `dict:tec.workOrder.visibleNumber` | `COD_SLS` |
| Orden encadenada | OT creada automáticamente a partir de otra por regla. | `dict:tec.chainedOrder` | `ALTASEAU` (`TIPO_AS=6`), `OT_RELACION` |
| Punto de prestación | Ubicación georreferenciada donde se presta el servicio (≠ domicilio fiscal/postal). | `dict:tec.servicePoint` | `SERSOC` GPS, `MAPA` |

## 4. Actores, permisos y alcance

| Rol | Capabilities principales | Alcance de datos |
|---|---|---|
| Administrador técnico del tenant | `tec.*.configurar`, `tec.operaciones.configurar`, `tec.agenda.configurar`, `tec.redes.configurar`, `tec.aprovisionamiento.configurar`, `tec.telefonia.configurar`, `tec.parametros.configurar` | tenant |
| Supervisor técnico | `tec.factibilidades.ver/crear/editar/aprobar/anular`, `tec.ot.ver/crear/editar/asignar/confirmar/anular/reabrir/exportar`, `tec.ot.cierreMasivo`, `tec.agenda.ver/editar/forzar`, `tec.conflictos.resolver`, `tec.materiales.autorizar`, `tec.instalaciones.confirmar` | sucursales / zonas / servicios / cuadrillas asignadas |
| Despachante / operador técnico | `tec.ot.ver/crear/editar/asignar`, `tec.agenda.ver/reservar/reprogramar/cancelar`, `tec.visitas.ver/editar`, `tec.factibilidades.ver/crear/editar` | zonas / servicios |
| Técnico / instalador (app de campo) | `tec.campo.ver`, `tec.campo.ejecutar`, `tec.campo.enCamino`, `tec.campo.evidencia`, `tec.campo.conformidad`, `tec.campo.materiales`, `tec.campo.crearOt` (si V2 #2/#30), `tec.campo.cerrar` (si V2 #48), `stk.custodia.ver` | propios + cuadrilla |
| Líder de cuadrilla | lo del técnico + `tec.ot.asignar` dentro de su cuadrilla, `tec.campo.cerrarCuadrilla` | cuadrilla |
| Lecturista (app de campo) | `tec.campo.ver` + capabilities de M03 (`med.lecturas.*`) + `tec.campo.crearOt` desde observación de lectura | rutas asignadas |
| Cobrador (app de campo) | `tec.campo.ver` + capabilities de M07 (`cob.campo.*`) | listas de cobro asignadas |
| Responsable de mantenimiento | `tec.activos.ver/editar`, `tec.mantenimiento.ver/crear/editar`, `tec.interrupciones.ver/crear/aprobar`, `tec.materiales.solicitar` | servicios / zonas |
| Responsable de red / GIS | `tec.redes.ver/editar/configurar/exportar`, `tec.conexionesRed.editar`, `tec.impacto.ver`, `tec.gis.exportar` | servicio / red |
| Operador NOC / aprovisionamiento | `tec.aprovisionamiento.ver/ejecutar/reintentar/marcarManual`, `tec.equiposRed.ver/editar`, `tec.perfilTecnico.ver/editar`, `tec.perfilTecnico.secretos` (ver secretos con auditoría) | servicios TIC |
| Responsable de obras | `tec.obras.ver/crear/editar/aprobar`, `tec.obras.padron.editar`, `tec.obras.prorrateo.proponer` | servicios / obras |
| Inspector | `tec.inspecciones.ver/crear/editar`, `tec.precintos.editar`, `tec.campo.*` para inspección | zonas |
| Comité/responsable de recupero | `tec.inspecciones.aprobarRecupero`, `tec.inspecciones.anular` | tenant |
| Operador de telefonía | `tec.telefonia.redFisica.*`, `tec.telefonia.numeracion.*`, `tec.telefonia.lineas.*`, `tec.telefonia.cdr.importar/asignar/revertir` | servicio telefonía |
| Atención (CRM) | `tec.ot.ver`, `tec.ot.crearDerivada`, `tec.agenda.reservar`, `tec.visitas.ver` | según M09 |
| Socio (PWA) | `por.visitas.reservar`, `por.visitas.ver`, `por.visitas.reprogramar`, `por.visitas.cancelar` (según reglas) | propios (contratos/casos del titular o relación autorizada) |
| Integración (cuenta de servicio) | `tec.ext.aprovisionamiento.callback`, `tec.ext.cdr.importar` | tenant, token de T06 |
| Soporte plataforma | lectura temporal auditada (T01) | tenant con acceso temporal |

Permisos negativos relevantes: el técnico no ve OT fuera de su alcance ni los secretos de red; un supervisor no puede confirmar una OT cuya instalación tiene conflicto abierto; nadie edita libremente estados (`Activo`, `Cerrada`) sin transición (AGR-003).

## 5. Requisitos funcionales

### 5.1 Factibilidad

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-001 | Registrar solicitudes de factibilidad por servicio y operación (alta, traslado, reconexión, aumento de potencia/plan) desde CRM, admin o portal, con comprobante/numeración propia por punto de venta o secuencia del tenant. | BASE §17; RN-07 §3.1; DFA M14 | Núcleo | O3 | Informado | Se crea con número único; sin punto de venta o secuencia válida se rechaza con error explícito. |
| RF-TEC-002 | Cargar persona existente o crear persona provisoria en M01 (prospecto) al registrar la factibilidad; si es nueva, copiar el domicilio de conexión como domicilio de contacto solo si el usuario lo confirma. | RN-07 §3.1 (`CargarDatosPersona`) | Núcleo | O3 | Adoptado | No se crean personas duplicadas por documento; se valida DNI/CUIT. |
| RF-TEC-003 | Registrar domicilio de conexión georreferenciado (punto de prestación), catastro (circunscripción, sección, manzana, parcela, PH, lote), calles linderas (derecha, izquierda, atrás con números), barrio, zona-sector-recorrido de lectura y referencias de acceso. | RN-07 §3.1; BASE §77 | Núcleo | O3 | Informado | La factibilidad muestra punto en mapa con su estado (confirmado/aproximado/pendiente). |
| RF-TEC-004 | Registrar observaciones administrativa, comercial y operativa y notas de seguimiento con título, texto, fecha, usuario y responsable. | RN-07 §3.1; CAT `FACTIBIL_NOTA` | Estándar | O3 | Adoptado | Las notas son de solo agregado; no se editan ni borran. |
| RF-TEC-005 | Registrar propiedades adicionales configurables de la factibilidad (por servicio): potencia solicitada, tipo de inmueble, tecnología, distancia al nodo, etc. | RN-07 §3.1 (`clsPropiedadesItems`) | Estándar | O3 | Adoptado | Atributos tipados validados por esquema del tenant. |
| RF-TEC-006 | Programar inspección de factibilidad como visita/OT de clase `inspection` y registrar condiciones encontradas con fotos y GPS. | BASE §17 ("Registrar inspecciones y condiciones") | Núcleo | O3 | Informado | La inspección queda vinculada y su resultado alimenta el dictamen. |
| RF-TEC-007 | Consultar automáticamente cobertura y disponibilidad del recurso de conexión (zona, nodo, puertos/bornes libres en red GIS, capacidad de OLT/splitter) y proponerla al evaluador. | BASE §86 (cobertura y recurso); RN-07 §5.1/5.2 disponibilidad | Núcleo | O3 | Adoptado | Si no hay recurso libre, la propuesta es "No factible: sin capacidad" y el evaluador puede justificar excepción. |
| RF-TEC-008 | Dictaminar factibilidad Factible/No factible con motivo obligatorio, observación técnica, responsable técnico y estado técnico provisorio/definitivo; estado administrativo provisorio/definitivo separado. | BASE §17; RN-07 §3.1 | Núcleo | O3 | Informado | No se puede dictaminar sin motivo; el cambio queda auditado. |
| RF-TEC-009 | Anular factibilidad con motivo; una factibilidad anulada nunca es utilizable para un alta. | RN-07 §3.1 (bug corregido) | Núcleo | O3 | Adoptado | Intentar usar una anulada devuelve error 409. |
| RF-TEC-010 | Vigencia configurable de la factibilidad para su uso en un alta (default 90 días) y uso único (sin servicio asociado previo). | RN-07 §3.1 (`Get_FACTIBIL_Solicitud`) | Núcleo | O3 | A validar (PA-TEC-05) | Factibilidad vencida o ya usada no aparece como seleccionable. |
| RF-TEC-011 | Exigir factibilidad vigente y factible en altas y reconexiones de servicios que la requieran (configurable por servicio/operación). | V2 #388; DFA M14 mejora | Núcleo | O3 | A validar (PA-TEC-04) | Si el parámetro está activo, no se crea OT de alta sin factibilidad válida. |
| RF-TEC-012 | Guardar en el contrato/servicio el identificador de la factibilidad que lo originó. | DFA M14 [P] | Núcleo | O3 | Informado | Trazabilidad factibilidad → contrato → OT. |
| RF-TEC-013 | Permitir modificar factibilidades cerradas y adjuntar documentos a factibilidades cerradas solo con capability y parámetro, conservando versión anterior. | V2 #2654, #3082 | Estándar | O3 | Adoptado | La versión dictaminada original se conserva (AGR-023). |
| RF-TEC-014 | Auditoría de acciones de factibilidad (alta, modificación, cierre, anulación) con diferencias. | RN-07 §3.1 | Núcleo | O3 | Adoptado | Pantalla de cambios muestra antes/después por campo. |
| RF-TEC-015 | Enviar la factibilidad por mail al solicitante y generar su PDF (con mapa estático opcional). | INV `frm_Factibilidad.EnviarPorMail`, `frmImpresiones.GetPdfFactibilidad` | Estándar | O3 | Adoptado | Envío registra constancia en T09. |
| RF-TEC-016 | Informe de factibilidades con estado (Pendiente/Cerrado/Anulado/Facturado), Factible, días entre fecha y confirmación (u hoy), agrupable por barrio. | RN-07 §1.11 (`clsInformes_Factibilidad`) | Estándar | O3 | Adoptado | Los días se calculan en zona horaria del tenant. |
| RF-TEC-017 | Notificar al socio el resultado de la factibilidad por su canal y reflejarlo en el caso del CRM. | BASE §50 AUT-002 | Núcleo | O3 | Adoptado | El socio ve "Factible"/"No factible" con motivo público. |

### 5.2 Estimación técnica y presupuesto de conexión

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-018 | Preparar estimación técnica de conexión con materiales (desde catálogo M13), mano de obra (horas por rol), obra de red necesaria y extensión de red, vinculada a la factibilidad. | BASE §17 ("Preparar presupuestos"); DFA §31 paso 3 | Núcleo | O3 | Informado | La estimación calcula cantidades; los precios los aporta M04/M11. |
| RF-TEC-019 | Enviar la estimación a M11 para emitir el presupuesto comercial al socio; reflejar aceptado/rechazado/vencido en la factibilidad. | RN-07 §3.1 (estado Facturado ↔ `PRESUPU`) | Núcleo | O3 | Adoptado | Con presupuesto aceptado, la factibilidad pasa a `quoted→accepted` y habilita la OT. |
| RF-TEC-020 | Plantillas de estimación por servicio/tecnología (por ejemplo, "Conexión FTTH aérea hasta 100 m") reutilizables. | Benchmark | Estándar | O3 | Adoptado | Al aplicar la plantilla se copian líneas editables. |
| RF-TEC-021 | Convertir los materiales de la estimación aceptada en materiales previstos y reserva de stock de la OT de conexión. | BASE §17 ("Reservar materiales") | Núcleo | O3 | Informado | Al crear la OT se generan `workOrderMaterials` en estado `requested`. |

### 5.3 Órdenes de trabajo: núcleo

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-022 | Modelo único de OT con clase `service`, `maintenance`, `claim`, `inspection`, `network` y enums únicos coherentes. | RN-07 §1.1, §10.1; CTR-TEC-08 | Núcleo | O3 | Adoptado | No existen dos enums para el mismo concepto. |
| RF-TEC-023 | Catálogo configurable de operaciones técnicas por servicio con **efecto declarativo**: `connect`, `move`, `disconnect`, `meterChange`, `reconnect`, `incident`, `statusChange`, `meterRemoval`, `categoryChange`, `planChange`, `prepaidTopUp`, `equipmentSwap`, `equipmentRetrieval`, `inspection`, `none`. | RN-07 §1.2, §10.2 | Núcleo | O3 | Adoptado | Los 8 efectos cableados de ProCoop y los de parámetros 2330/238 están disponibles como tipos de efecto. |
| RF-TEC-024 | Atributos por operación: servicio, es reclamo, modifica matrícula, estado de servicio resultante, agregar nota visible en caja, registrar estado/lectura, envío al socio (nunca/al generar/al confirmar/siempre) y canal, plantillas de alta/confirmación, excluir de la web, disponible en app de campo, requiere factibilidad, requiere punto de red, requiere dispositivo, requiere equipo serializado, genera aprovisionamiento, reporte de impresión. | RN-07 §1.2; CAT `TRANSAC` | Núcleo | O3 | Adoptado | Cada flag se valida al crear/cerrar. |
| RF-TEC-025 | Crear OT desde: administración, ficha del titular/servicio, CRM (OT derivada), mora (corte/reconexión), API de integración, app de campo, observación de lectura (M03) y reglas encadenadas; registrar origen y vía de ingreso. | RN-07 §1.3 (`OrigenOrden`, `COD_VIA`), §Reglas adicionales (`GenerarOrden`) | Núcleo | O3 | Adoptado | Cada OT tiene `origin` y `intakeChannel`. |
| RF-TEC-026 | Al crear la OT, copiar instantánea del servicio: domicilio, punto GPS, medidor (número, dígitos, última lectura y fecha), catastro, certificado de instalador, teléfono del titular, línea telefónica activa, condición de moroso y origen gestión de mora; opcionalmente la observación del servicio como observación administrativa. | RN-07 §1.3 (`Crear_OT`); V2 #2339 | Núcleo | O3 | Adoptado | La instantánea no cambia si luego cambia el servicio; el GPS no se trunca. |
| RF-TEC-027 | Validaciones previas por operación: no sobre servicio inexistente; no sobre servicio dado de baja salvo incidente/reconexión; no sobre pendiente de conectar salvo parámetro; reconexión solo sobre servicio desconectado, no con titular fallecido salvo parámetro, no en planes de vivienda; cambio/retiro de medidor exigen medidor y no retirado; retiro solo sobre desconectado (telefonía: línea abierta); alta no si hay alta o reconexión pendiente. | RN-07 §1.4 validaciones; V2 #2655, #2301 | Núcleo | O3 | Adoptado | Cada rechazo devuelve código de regla (`RN-TEC-0xx`). |
| RF-TEC-028 | Impedir OT pendiente duplicada de la misma operación para el mismo servicio (ventana configurable; default sin límite temporal). | RN-07 §1.3 (`Existe_OT_Pendiente`, 90 días) | Núcleo | O3 | Adoptado | Segundo intento devuelve 409 con enlace a la existente. |
| RF-TEC-029 | Numeración interna inmutable (ObjectId) + número de comprobante por talonario/operación + **numeración visible** configurable: no usar, por año separando reclamos, por año y operación, por año + reclamo + operación, y secuencia continua de reclamos por servicio; asignada al crear o al cerrar según parámetro. | RN-07 §1.1, §1.6; V2 #344, #2998, #3031 | Núcleo | O3 | Adoptado | Secuencias atómicas sin huecos por concurrencia (CTR-TEC-19). |
| RF-TEC-030 | Asignar responsable, cuadrilla, participantes concretos, cantidad de personas y vehículos (N a N) a la OT. | RN-07 §1.7 | Núcleo | O3 | Informado | La cuadrilla precarga sus integrantes editables. |
| RF-TEC-031 | Registrar tareas realizadas (catálogo por grupo y servicio) en OT de trabajo y de mantenimiento. | RN-07 §1.7 (`TAROTM`); CAT `TAREAS`, `TAREASOM`, `GRPTAREA` | Estándar | O3 | Adoptado | Tareas obligatorias por operación configurables. |
| RF-TEC-032 | Registrar horas normales y extras por participante, si es contratado y valor hora (default parámetro). | CAT `PARTIORD`; V2 #2354, #3085 | Estándar | O3 | Adoptado | Si V2 #2354 activo, no se cierra sin horas. |
| RF-TEC-033 | Notas de OT de solo agregado (título, texto, fecha, usuario, responsable), visibles internamente; opción de nota pública al socio. | CAT `TECNICA_NOTA` | Núcleo | O3 | Adoptado | Notas públicas se reflejan en M09/portal. |
| RF-TEC-034 | Descripción de la OT acumulativa (agregar texto, no reemplazar). | RN-07 §Reglas adicionales (`Guardar_OT_Descripcion`) | Estándar | O3 | Adoptado | Historial de descripciones con autor. |
| RF-TEC-035 | Datos extra de la OT por tipo (formulario configurable): reclamos por daños a artefactos (fecha de pago, transferencia, libro/folio, monto reclamado/aprobado, daños anteriores, aceptado, reclamo ante el regulador, causa, artefactos dañados). | CAT `TECNICA_EXTRAS`; V2 #3120 | Estándar | O7 | Adoptado | Se modela en `damageAssessments` vinculada a la OT y al caso M09. |
| RF-TEC-036 | Cierre de la OT con fecha real de ejecución, responsable, categoría de incidente, resolución, tipo de trabajo, cuadrilla, horas, personas, observaciones técnicas; exigencias configurables (responsable, categorías, resolución, personas, observaciones administrativas, certificado, número de dispositivo, móvil). | RN-07 §1.3, §1.4; V2 #342, #474, #497, #2084, #174, #2421, #2470, #2505 | Núcleo | O3 | Adoptado | Faltantes listados todos juntos antes de cerrar. |
| RF-TEC-037 | Doble paso opcional por operación: **Ejecutada** (campo) y **Cerrada/Confirmada** (revisión administrativa/supervisión); no mezclar ambos conceptos. | RN-07 §1.3 (DTO vs enum), §10.1; BASE §17 ("Revisar el cierre") | Núcleo | O3 | A validar (PA-TEC-01) | Los efectos contractuales se aplican solo en Confirmada. |
| RF-TEC-038 | Efectos al confirmar según efecto declarativo: conectar servicio (hito), trasladar domicilio (y opcionalmente adherentes), desconectar servicio + adherentes + beneficiarios con retiro de medidor opcional, cambio de medidor (M03), reconexión, cambio de estado de servicio, retiro de medidor, cambio de categoría, punto de red, matrícula, lectura inicial/final (M03), nota visible en caja. Todos vía servicios de los módulos dueños, en una transacción con outbox. | RN-07 §1.4 | Núcleo | O3 | Adoptado | Un fallo de un efecto deja la OT en `closing` con paso pendiente reparable (AGR-016), nunca a medio aplicar sin registro. |
| RF-TEC-039 | Datos opcionales actualizables al cerrar: recorrido de lectura/factura, cantidad, domicilio, teléfonos y mails de persona y cuenta, catastro, certificado, observación de medidor; con aviso si en traslado no cambió el recorrido y pregunta de modificar domicilio postal/recorrido postal. | RN-07 §1.4 (`DatosExtraTecnica`); V2 #2480, #2637, #2638 | Estándar | O3 | Adoptado | Cada actualización genera propuesta a M01/M03 con auditoría. |
| RF-TEC-040 | Registrar lectura/consumo al cerrar cuando la operación lo pide y siempre en alta y reconexión (servicios medidos), encadenando con el consumo anterior; preguntar si agregar consumo calculado. | RN-07 §Reglas adicionales (`Registra_EstadoMedidor`, `CargarConsumoAnterior`); V2 #254 | Estándar | O7 | Adoptado | Lectura se envía a M03 con origen OT. |
| RF-TEC-041 | Retiro de medidor en desconexión: marcar retirado por defecto, preguntar si retirar, limpiar número y matrícula si parámetro. | RN-07 §1.4; V2 #2399, #2440, #2531 | Estándar | O7 | Adoptado | Efecto aplicado en M03. |
| RF-TEC-042 | Confirmar órdenes con fecha anterior al alta del servicio o fecha posterior a hoy solo si parámetros lo permiten; permitir cambiar fecha de ingreso/solicitud con capability y parámetro. | V2 #441, #752, #2268, #2439 | Estándar | O3 | Adoptado | Fecha efectiva y fecha de registro se guardan separadas (AGR-010). |
| RF-TEC-043 | Verificar pagos pendientes al confirmar (por ejemplo, cargo de conexión no pagado) salvo parámetro; el bloqueo es configurable por operación. | V2 #2891; INV `abm_Tecnica.ExistenPagosPendientes` | Estándar | O3 | Adoptado | Mensaje indica comprobantes pendientes según M07. |
| RF-TEC-044 | Anulación de OT con motivo y **reversión por compensación** de efectos ya aplicados (reconexión anulada → restaurar baja; alta anulada → baja/“No vigente” si factura cargo fijo en la baja; desconexión anulada → limpiar baja y moroso); devolver materiales con movimientos inversos (nunca borrado físico); nota en la cuenta. | RN-07 §1.3 (`PreDelete_TECNICA`); V2 #2753 | Núcleo | O3 | Adoptado | La anulación genera movimientos compensatorios en M13 y eventos de reversión. |
| RF-TEC-045 | Restablecer (reabrir) una OT anulada o cerrada con capability, motivo y reglas de reversión. | RN-07 §1.3 ("Restablecer vuelve a 1") | Estándar | O3 | Adoptado | La reapertura conserva historial y no duplica efectos. |
| RF-TEC-046 | Cambio de subestado/estadio libre configurable por tenant (por ejemplo "Esperando permiso municipal"). | RN-07 §1.3 (`SUBESTADO`, `Cambiar_Estadio`) | Estándar | O3 | Adoptado | Subestados no alteran el estado principal. |
| RF-TEC-047 | Órdenes encadenadas por reglas: al crear OT de operación X sobre servicio S (filtros: categoría, localidad, referencia, zona de lectura, actividad, clase, propiedad, tipo de medidor, operación) crear OT de operación Y sobre servicio S' con otra vía; dependencia de confirmación (origen primero o destino primero); error si 0 o más de una regla aplicable al confirmar. | RN-07 §1.5 (`ALTASEAU` tipo 6) | Estándar | O3 | Adoptado | Creación idempotente; numeración atómica (no `COD_SOL+1`). |
| RF-TEC-048 | Bajas automáticas de servicios dependientes: si el dependiente usa técnica se genera OT de desconexión; si no, se solicita la baja directa al dueño del contrato. | RN-07 §1.5 (`AltasBajasAutomaticas`) | Estándar | O3 | Adoptado | Evento `tec.dependentDisconnection.requested`. |
| RF-TEC-049 | Servicios que no usan técnica: la operación se aplica sin OT (desconexión directa) mediante solicitud al dueño del contrato, registrando el hecho técnico "sin intervención". | RN-07 §4 (`DesconectarServicio`) | Núcleo | O3 | Adoptado | Configuración por servicio `usesTechnicalOrders`. |
| RF-TEC-050 | Generación masiva de OT por filtros (servicio, operación, estado, días, morosos, fecha de estado) con selección parcial/cantidad y vista previa, mostrando la última OT pendiente/en proceso por servicio para evitar duplicados. | INV `frmOT_Notificaciones`; RN-07 §Reglas adicionales (`Get_ServiciosNotificados`) | Estándar | O3 | Adoptado | Job `tec:generar-ot-masivas` idempotente por lote. |
| RF-TEC-051 | Cambio de estado masivo de servicios por OT (con nota visible en caja) y en transacción. | INV `frmTecnica_CambioEstadoMasivo`; RN-07 §Reglas adicionales | Estándar | O3 | Adoptado | Resultado por ítem. |
| RF-TEC-052 | Confirmación/cierre masivo de OT con los mismos datos (fecha, responsable, incidente, resolución, tipo de trabajo, móviles, cuadrilla, horas, personas, observaciones) y notificación opcional al socio; excluye las bloqueadas por campo o sistema externo. | RN-07 §1.3 (cierre masivo), §1.7 (`BLOQUEAR`) | Núcleo | O3 | Adoptado | Las OT con ejecución en campo pendiente de sincronizar no se cierran masivamente. |
| RF-TEC-053 | Eliminación/anulación masiva de OT seleccionadas con reversión por ítem. | INV `frmBajaMasivaOrdenes.btnEliminarSeleccionados` | Estándar | O3 | Adoptado | Reporte de resultado por OT. |
| RF-TEC-054 | Asistentes de generación por operación: traslado (domicilio nuevo, adherentes), desconexión (baja por mora, contrato de baja imprimible), reconexión (mora saldada, factibilidad), cambio de medidor (nuevo tipo/número, materiales, con/sin técnica), cambio de categoría (solicitud imprimible), cambio de estado, OT especial. | INV `frmTecnica_*`, `frmOT_Especial` | Núcleo | O3 | Adoptado | Cada asistente aplica validaciones RF-TEC-027. |
| RF-TEC-055 | Formularios de solicitud para firma del socio por operación (traslado con diseño propio y domicilio nuevo, cambio de medidor, reconexión, desconexión, alta, cambio de categoría). | RN-07 §1.11 (`Get_Reporte_Solicitud_OT`) | Estándar | O3 | Adoptado | PDF con versión y firma capturable en mostrador o campo. |
| RF-TEC-056 | Modelos de impresión de OT por servicio + operación (único por combinación), informe por defecto, con mapa estático opcional del punto, materiales (con vales opcionales), informe de incidentes; la impresión no cambia el estado salvo configuración. | RN-07 §1.10, §1.11; V2 #180, #358, #465, #2808, #2819, #3173; CAT `OT_REPORTE` | Estándar | O3 | Adoptado | Imprimir pasa a `dispatched` solo si V2 #2808 = falso y la operación lo indica. |
| RF-TEC-057 | Antigüedad visual de la OT (≤10, 11–20, 21–30, >30 días) y estado de envío a campo. | RN-07 §Reglas adicionales (`ObtenerDetalleOrden`) | Estándar | O3 | Adoptado | Badges por rango en tablero. |
| RF-TEC-058 | Aviso en tiempo real a usuarios técnicos cuando se crean OT pendientes nuevas en su alcance (reemplaza sondeo). | RN-07 §Reglas adicionales (`NotificarNuevaOrden`) | Estándar | O3 | Adoptado | Notificación in-app vía T09. |
| RF-TEC-059 | Tablero de órdenes en kanban, lista y mapa, con asignación por arrastre a cuadrillas/recursos y filtros por estado, operación, zona, servicio, antigüedad, prioridad. | DFA M14 mejora; CNX §4.4 | Núcleo | O3 | Adoptado | Arrastrar a otra cuadrilla valida capacidad y conflicto de agenda. |
| RF-TEC-060 | Prioridad y vencimiento (fecha objetivo) en la OT, con SLA heredado del caso M09 cuando es derivada. | RN-07 §2 (sin prioridad), §10.6; CAT `TECNICA.VENCE` | Núcleo | O3 | Adoptado | Alertas de OT por vencer y vencidas. |
| RF-TEC-061 | Tipificación de causa con categoría de incidente y distribución % por sección/centro de costo que debe sumar 100 %. | RN-07 §2, §Reglas adicionales (no valida 100 %) | Estándar | O7 | Adoptado | No se guarda una distribución distinta de 100 %. |
| RF-TEC-062 | Cargos asociados a la OT: al generar ("antes", cobro en mostrador) y al cerrar ("luego"), por regla de M04 según servicio, socio activo, moroso, prepago, referencia, localidad, categoría, clase, retirado, provisorio, propiedad, estado del servicio, operación, solo reclamo (ej. visita improcedente), una vez; precio editable o no por parámetro. TEC solo dispara el evento y muestra la propuesta. | RN-07 §1.9; V2 #443, #448, #65 | Núcleo | O3 | Adoptado | Sin doble cargo por resincronización (idempotencia por OT + regla). |
| RF-TEC-063 | Proporcionales por reconexión (crédito por días desconectados o débito por días restantes si el período no se facturó) y por cambio de categoría (diferencia de precio por días, con tope de día y sin negativos opcional): solicitados a M04/M05; opción de cerrar sin generar comprobante. | RN-07 §1.9; V2 #2483, #2485, #2661, #2907, #2570, #2587, #2625, #2755, #3111 | Estándar | O4 | Adoptado | Evento `tec.workOrder.closed` con `effect=reconnect|categoryChange`; M05 decide documento inmediato o próxima factura. |

### 5.4 Materiales de la OT

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-064 | Entidad propia de material de la OT (producto, cantidad prevista/usada/devuelta, depósito o custodia de origen, serie si corresponde, precio de referencia, facturable sí/no) que solicita a M13 los movimientos. | RN-07 §1.8, §10.5; DFA M14 (`ITEMSORD` → CTR-TEC-01) | Núcleo | O3 | Adoptado | Cada movimiento M13 referencia `workOrderMaterialId`. |
| RF-TEC-065 | Origen del descuento: depósito indicado, custodia del técnico/responsable (depósito propio) o depósito por defecto configurado. | RN-07 §1.8 (`RESPONSA.COD_DPS`, depósito 1) | Núcleo | O3 | Adoptado | Sin depósito resuelto no se confirma el consumo. |
| RF-TEC-066 | Necesidades de materiales (OT de mantenimiento y obras): solicitada → autorizada (usuario y fecha) → retirada → utilizada, por producto y depósito, con usuario en cada paso; listas de autorizados pendientes de retiro y retirados pendientes de uso. | RN-07 §1.8 (`TECNICA_NECESIDAD`); V2 #2997 | Estándar | O7 | Adoptado | El filtro de estado corrige el bug `(≠3)|(≠4)`. |
| RF-TEC-067 | Vales de retiro de depósito vinculados a la OT/obra y su consulta; importar productos de presupuesto en vales. | RN-07 §1.8 (`RETI_MAT`); INV `frmConsultar_Vales`; V2 #2899 | Estándar | O3 | Adoptado | El vale es un movimiento M13 a custodia, no consumo. |
| RF-TEC-068 | Materiales en productos sin stock solo si parámetro lo permite; advertencia al cerrar OT sin materiales; mostrar detalle de materiales en el registro. | V2 #2627, #3201, #2657 | Estándar | O3 | Adoptado | Mensajes configurables. |
| RF-TEC-069 | Bloqueo de edición de materiales en OT cerradas (parámetro); corrección posterior solo por ajuste trazado. | V2 #2667 | Estándar | O3 | Adoptado | Ajuste genera movimiento compensatorio. |
| RF-TEC-070 | Validación de cierre de stock: no registrar materiales con fecha de un período de stock cerrado. | INV `abm_Tecnica_Partiord.ValidarCierreStock` | Estándar | O8 | Adoptado | Error si período cerrado en M13. |
| RF-TEC-071 | Facturación de materiales al socio solo si la operación/presupuesto lo define; por defecto los materiales no se facturan automáticamente. | RN-07 §1.8, §11 duda 4 | Estándar | O3 | A validar (PA-TEC-03) | Línea `billable=true` genera solicitud a M05. |
| RF-TEC-072 | Costeo de la OT: materiales valorizados (M13) + horas normales/extras (valor hora parámetro o legajo) + vehículos; concepto de horas hombre. | V2 #460, #2722, #2723, #3085; RN-07 §1.11 recursos | Estándar | O7 | Adoptado | El informe no sobrescribe parámetros (CTR-TEC-26). |

### 5.5 Agenda y visitas

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-073 | Configurar zonas de agenda (polígonos o lista de localidades/barrios), tipos de visita con duración, franjas, requisitos (habilidad, cuadrilla, vehículo, equipo) y servicios. | BASE §50 agenda | Núcleo | O3 | Informado | Tipo "Instalación Internet" con franja de 2 h precargado. |
| RF-TEC-074 | Calendarios de recursos (cuadrillas/técnicos) con disponibilidad, feriados (T04), turnos, ausencias y capacidad por franja (cantidad de visitas o minutos). | BASE §50; AGR-025 | Núcleo | O3 | Informado | La capacidad disponible se calcula por zona/tipo/franja. |
| RF-TEC-075 | Ofrecer turnos compatibles con servicio, domicilio (zona por punto de prestación), requisitos del caso y factibilidad aprobada. | BASE §50 AUT-003 | Núcleo | O3 | Informado | Solo se ofrecen franjas con capacidad > 0. |
| RF-TEC-076 | **Reserva temporal** con expiración configurable al elegir franja y **reserva confirmada** al aceptar; sin doble reserva del mismo cupo por carrera (control atómico). | AGR-025 | Núcleo | O3 | Adoptado | Dos solicitudes simultáneas por el último cupo: una confirma, la otra recibe 409 con alternativas. |
| RF-TEC-077 | Confirmar fecha/franja al socio por su canal con constancia y recordatorio previo configurable. | BASE §50; AGR-024 | Núcleo | O3 | Informado | Constancia en T09 con estado de entrega. |
| RF-TEC-078 | Reprogramar y cancelar visitas por socio (portal, con reglas de anticipación) u operador, con motivo y trazabilidad; cancelar visita no cancela la contratación. | BASE §50; AGR-003 ejemplo | Núcleo | O3 | Informado | Se liberan cupos y se conserva la reserva anterior en historial. |
| RF-TEC-079 | Asignación de cuadrilla/empleado a la visita (manual o sugerida por zona, carga y habilidad) y novedades de agenda. | BASE §50 | Núcleo | O3 | Informado | Reasignación notifica al técnico y actualiza su "Mi día". |
| RF-TEC-080 | Resultado de visita: realizada, fallida (sin acceso, ausente, falta material, condición técnica, clima, rechazo del socio), reprogramada, cancelada u otro definido por tenant; visita no terminada genera otra visita. | BASE §50; BASE §17 excepción | Núcleo | O3 | Informado | Visita fallida no activa contrato ni descuenta equipo. |
| RF-TEC-081 | Estado real visible al socio (Confirmada, Asignada, En camino, En sitio, Realizada, Fallida, Reprogramada) vinculado a la OT y a la activación. | BASE §50; INS-002 | Núcleo | O3 | Informado | El socio no ve datos internos ni ubicación del técnico. |
| RF-TEC-082 | Costo de visita fallida/improcedente configurable por prestación (concepto M04), nunca automático sin regla. | BASE §50 ("eventual costo"); RN-07 §2 (`CONEXION.RECLAMO`) | Estándar | O3 | A validar (PA-TEC-06) | Cargo solo con regla activa y motivo imputable. |
| RF-TEC-083 | Forzar sobrecupo con capability y motivo (urgencias), marcado en agenda. | Benchmark | Estándar | O3 | Adoptado | Auditoría de sobrecupo. |
| RF-TEC-084 | Vista de agenda por recurso (día/semana), por zona y mapa de visitas del día. | BASE §50; CNX §3.8 `/agenda` | Núcleo | O3 | Adoptado | Drag & drop respeta reglas de capacidad. |

### 5.6 Instalación integral (BASE §73)

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-085 | Concertar cita de instalación (visita confirmada) con asignación operativa. | INS-001 | Núcleo | O3 | Informado | OT de instalación con visita `confirmed` y recurso. |
| RF-TEC-086 | Reservar equipo identificado (serie) a la OT y transferir custodia del depósito al instalador antes de la visita. | INS-004; BASE §73 tabla stock | Núcleo | O3 | Informado | Reserva reduce disponible; entrega mueve custodia una sola vez. |
| RF-TEC-087 | El instalador informa **En camino**; la app del socio muestra la novedad y la cita. | INS-002 | Núcleo | O3 | Informado | Notificación al socio; sin coordenadas. |
| RF-TEC-088 | Registrar llegada e inicio; verificar orden, domicilio y equipo (escaneo de serie/QR). | BASE §73 paso 5 | Núcleo | O3 | Informado | Serie no coincidente exige registrar sustitución. |
| RF-TEC-089 | Instalar, realizar pruebas (checklist por tecnología: potencia óptica, velocidad, señal Wi-Fi, ping) y registrar resultado, materiales y serie efectiva. | BASE §73 paso 6; INS-003 | Núcleo | O3 | Informado | Prueba fallida impide cerrar como instalada. |
| RF-TEC-090 | Sustitución de equipo: si el efectivo difiere del reservado, registrar y validar la sustitución sin adjudicar dos equipos. | BASE §73 controles | Núcleo | O3 | Informado | El reservado vuelve a disponible/custodia; solo el efectivo se aplica. |
| RF-TEC-091 | Mostrar el detalle de instalación (versión) y capturar firma/conformidad del receptor identificado (nombre, documento, relación con el titular), fecha/hora, instalador, equipo, trabajos, conformidad/disconformidad, observaciones, adjuntos; o registrar disconformidad/ausencia de firma con su procedimiento. | INS-003; BASE §73 firma | Núcleo | O3 | A validar (PA-TEC-07) | El documento aceptado queda inmutable con hash; modificación posterior genera nueva versión. |
| RF-TEC-092 | Aplicar el equipo desde la custodia del instalador a la prestación (salida a domicilio) y vincularlo al contrato/suministro con modalidad (comodato, venta, alquiler). | INS-004; BASE §73 paso 8 | Núcleo | O3 | Informado | Aplicación única por `clientMutationId` y por OT. |
| RF-TEC-093 | Confirmar el **hito de activación** con fecha efectiva (día/hora y zona horaria) mediante el mecanismo autorizado por servicio (instalación probada + aprovisionamiento confirmado + revisión si aplica). | INS-006; BASE §17 regla; §73 paso 9 | Núcleo | O3 | A validar (PA-TEC-02) | Sin activación por mera agenda; evento `tec.installation.activationConfirmed`. |
| RF-TEC-094 | Disparar a M05/M04 la generación del cargo de instalación y el primer abono según reglas de devengamiento, promoción, prorrateo y modalidad anticipada/vencida. | INS-007; BASE §73 paso 10 | Núcleo | O4 | Informado | TEC no calcula importes; los ejemplos de §73 se validan en M05. |
| RF-TEC-095 | Enviar o disponibilizar la encuesta de satisfacción (T09) vinculada a visita, OT y servicio, posterior e independiente de la activación. | INS-005; BASE §73 paso 11 | Núcleo | O3 | Informado | La ausencia de respuesta no bloquea activación. |
| RF-TEC-096 | Derivar insatisfacción a M09 según umbral configurable sin eliminar la evidencia de la encuesta. | BASE §73 paso 12 | Estándar | O3 | A validar (PA-TEC-08) | Respuesta ≤ umbral crea caso de seguimiento. |
| RF-TEC-097 | Estados propios para ausencia de firma, falla de prueba e incidencia; prohibido marcar todo como realizado para cerrar la agenda. | BASE §73 | Núcleo | O3 | Informado | Transiciones explícitas en §8. |
| RF-TEC-098 | Visita fallida: el equipo se mantiene en custodia o se devuelve; no se registra instalado ni se vuelve a descontar. | BASE §73 tabla | Núcleo | O3 | Informado | Prueba ESC "visita fallida" verde. |
| RF-TEC-099 | Retiro posterior del equipo (baja, cambio, falla) con OT de retiro, condición del equipo y devolución a depósito/RMA; devolver el router no equivale a baja comercial. | BASE §73 tabla; §86 baja | Núcleo | O3 | Informado | Retiro genera movimiento domicilio → custodia → depósito. |
| RF-TEC-100 | Bandeja de instalaciones: pendientes de cita, citadas, en curso, ejecutadas sin activación, con conflicto, activadas, con encuesta pendiente. | BASE §86 indicadores | Núcleo | O3 | Adoptado | Contadores por estado y antigüedad. |
| RF-TEC-101 | Una sincronización repetida no genera otro cargo, otra instalación ni otra encuesta. | BASE §73 controles; AGR-016 | Núcleo | O3 | Informado | Reenvío del mismo lote devuelve `duplicate` por ítem. |

### 5.7 Cuadrillas, recursos y tipos de trabajo

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-102 | ABM de cuadrillas con integrantes (responsables), líder, zona, servicios, habilidades, vehículo habitual y capacidad diaria. | RN-07 §1.7; CAT `CUADRI`, `PARTICUA`; INV `abm_Cuadri`, `abm_Cuadri_Particua` | Núcleo | O3 | Adoptado | Un integrante puede estar en varias cuadrillas con vigencia. |
| RF-TEC-103 | ABM de recursos de campo/responsables: nombre, actividad (técnico, lecturista, cobrador, inspector), mail, teléfono, usuario IAM vinculado, depósito/custodia propia, asigna OT a app, inactivo. Sin contraseñas propias (IAM T02). | CAT `RESPONSA`; RN-07 §1.7 | Núcleo | O3 | Adoptado | `PAS_RES` no se migra (CTR-TEC-27). |
| RF-TEC-104 | Responsables por servicio y operación (relación servicio-responsable) para sugerencia de asignación. | RN-07 §1.7 (`RELACION_ENTIDADES`); V2 #3084 | Estándar | O3 | Adoptado | Sugerencia ordenada por regla. |
| RF-TEC-105 | Reglas de notificación a responsables por servicio, tipo de orden, operaciones, días de semana, franja horaria, feriados y momento (al generar / al enviar a campo), con canal (WhatsApp, mail, SMS, push) y plantilla oficial. | RN-07 §1.7 (`RESPONSA_NOTIFICA`); V2 #3088, #3105 | Estándar | O3 | Adoptado | Guardia fuera de horario recibe aviso. |
| RF-TEC-106 | Profesionales/instaladores matriculados: matrícula, documento, servicio, categoría de instalador, contacto, domicilio; certificado y vencimiento en la OT con validación configurable (no exigir / advertir / exigir). | CAT `PROFESIO`; RN-07 §1.3; V2 #2421 | Estándar | O7 | Adoptado | Certificado vencido se advierte o bloquea. |
| RF-TEC-107 | Tipos de trabajo con clase de orden (trabajo/mantenimiento) y reporte asociado. | CAT `TPTRAB`; INV `abm_Tptrab` | Núcleo | O3 | Adoptado | Enum único `kind`. |
| RF-TEC-108 | Categorías de incidente con rubro, servicio, operación por defecto y cuentas contables (debe/haber), con distribución por sección. | CAT `CAT_INCI`; INV `abm_Cat_Insi` | Estándar | O3 | Adoptado | Cuentas referencian plan de M15. |
| RF-TEC-109 | Resoluciones por servicio + operación más genéricas (sin servicio). | CAT `RESOL_OT`; RN-07 §Reglas adicionales | Núcleo | O3 | Adoptado | Selector muestra específicas + genéricas. |
| RF-TEC-110 | Catálogo de tareas y grupos de tareas por servicio. | CAT `TAREAS`, `TAREASOM`, `GRPTAREA`; INV `abm_TareasOm` | Estándar | O3 | Adoptado | Unifica `TAREAS` y `TAREASOM` (CTR-TEC-28). |
| RF-TEC-111 | Vías de ingreso de OT (teléfono, mostrador, web, app, WhatsApp, API) con validación de celular/mail y vía por defecto; solicitar vía al crear según parámetro. | CAT `VIAINGTE`; V2 #333, #2629 | Estándar | O3 | Adoptado | Catálogo compartido con M09. |

### 5.8 App de campo offline-first (perfiles técnico / lecturista / cobrador)

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-112 | Una sola PWA con landing por perfil (técnico, lecturista, cobrador, inspector) y menú recortado por allowlist; sin app distinta por función. | DFA M27 mejora; BASE §73 límite; CNX §3.8 | Núcleo | O3 | Informado | Un usuario con dos perfiles elige perfil activo. |
| RF-TEC-113 | Descarga de trabajo asignado ("Mi día") con versión de cada tarea: OT, visitas, datos del servicio, materiales previstos, equipos en custodia, formularios, mapas de la zona. | AGR-025; CNX §3.8 `/mi-dia` | Núcleo | O3 | Adoptado | Cada paquete descargado lleva `serverVersion`. |
| RF-TEC-114 | Cola única de mutaciones en IndexedDB con `clientMutationId`, fotos/evidencias en IndexedDB, envío por lotes a `/sync` con resultado por ítem, reintento automático y botón "Reintentar" en banner único. | CNX §3.7 [COPIAR][MEJORAR] | Núcleo | O3 | Adoptado | Cortes de red no pierden datos; reenvío no duplica. |
| RF-TEC-115 | No encolar login, administración ni operaciones con riesgo de duplicado no idempotente. | CNX §3.7 | Núcleo | O3 | Adoptado | Esas acciones se deshabilitan offline con mensaje. |
| RF-TEC-116 | Fotos con marca de fecha/hora, GPS y orientación; foto obligatoria por paso configurable; compresión y límite de tamaño. | DFA M14 mejora; BASE §17 ("Capturar fotografías") | Núcleo | O3 | Informado | Paso obligatorio sin foto no permite avanzar. |
| RF-TEC-117 | Captura de GPS del dispositivo con permiso explícito y alternativa manual; precisión registrada. | BASE §77 (GEO-F6) | Núcleo | O3 | Informado | Sin permiso se registra "sin GPS" y se permite continuar si la regla lo admite. |
| RF-TEC-118 | Firma del receptor en pantalla y datos de identificación (RF-TEC-091) offline, con hash del detalle presentado. | INS-003; V2 #50 | Núcleo | O3 | Informado | La firma se asocia a la versión del detalle. |
| RF-TEC-119 | Registro de materiales usados desde la custodia del técnico (lista de su stock) que descuentan stock al sincronizar en M13. | DFA M14 mejora; BASE §73 | Núcleo | O3 | Informado | Material no disponible en custodia se marca para revisión, no se bloquea el trabajo. |
| RF-TEC-120 | Cierre con lectura de medidor cuando aplica (servicios medidos) usando el componente de lectura de M03. | DFA M14 mejora | Estándar | O7 | Adoptado | Lectura validada por reglas de M03. |
| RF-TEC-121 | Crear OT desde campo (anomalía, reclamo en sitio, cambio de medidor de servicio no medido) si parámetros lo permiten. | V2 #2, #30, #70 | Estándar | O3 | Adoptado | OT creada offline obtiene número al sincronizar. |
| RF-TEC-122 | Cerrar OT desde la app (si V2 #48), cerrar operaciones seleccionadas en lote (V2 #54), confirmación al cancelar (V2 #62), mostrar número de medidor en lista (V2 #64). | V2 #48, #54, #62, #64 | Estándar | O3 | Adoptado | Comportamientos configurables por tenant. |
| RF-TEC-123 | Encuesta/conformidad al cierre en sitio (V2 #51) limitada a la conformidad del receptor; la encuesta de satisfacción es posterior por canal del socio. | V2 #51; BASE §73 (CTR-TEC-15) | Núcleo | O3 | Adoptado | Ver CTR-TEC-15. |
| RF-TEC-124 | **Conflictos de sincronización**: versionar la tarea descargada; al recibir una mutación sobre versión desactualizada (OT cancelada, reasignada, equipo cambiado, titular modificado) conservar ambas evidencias, crear conflicto con responsable y no sobrescribir sin revisión. | AGR-025; ESC-03 | Núcleo | O3 | Adoptado | ESC-03 superado (§17). |
| RF-TEC-125 | Registrar fecha real de intervención (dispositivo) y fecha de recepción (servidor); validar desvío de reloj. | AGR-010; AGR-025 | Núcleo | O3 | Adoptado | Desvío > umbral marca la mutación para revisión. |
| RF-TEC-126 | Bloqueo de OT enviadas a campo o a sistema externo (AION/otros) para evitar doble cierre; desbloqueo con capability. | RN-07 §1.7 (`BLOQUEAR`); V2 #2811, #3086 | Núcleo | O3 | Adoptado | OT bloqueada no se confirma masivamente en admin. |
| RF-TEC-127 | No sincronizar órdenes modificadas en servidor sin aviso al técnico (V2 #57 reemplazado por conflicto/actualización con aviso). | V2 #57 | Estándar | O3 | Adoptado | El técnico ve "Orden actualizada" antes de ejecutar. |
| RF-TEC-128 | Registro de dispositivos de campo (modelo, versión de app, último sync, usuario) y revocación remota que purga datos locales. | FIC 4 (`GetVersionCode`); T08 | Estándar | O3 | Adoptado | Dispositivo revocado no puede sincronizar. |
| RF-TEC-129 | Formularios/checklists de campo configurables (motor de relevamientos CNX) embebidos en la OT (hasta 3 formularios por visita), con check-in GPS y geocerca opcional. | CNX §7.7, §7.8 | Estándar | O3 | Adoptado | Respuestas versionadas por formulario. |
| RF-TEC-130 | Mapa del técnico con sus visitas del día, red cercana y navegación externa (abrir en Google Maps). | CNX §3.8; BASE §77 | Estándar | O3 | Adoptado | Sin conexión muestra lista y último mapa cacheado permitido. |
| RF-TEC-131 | Sistema de AVL/flota opcional para recorridos y kilometraje del vehículo, sin exponer ubicación al socio. | MER-015; V2 #341, #430 | Extensión | O10 | Adoptado | Integración en M18. |

### 5.9 Cortes y reconexiones ejecutados

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-132 | Recibir órdenes de corte/suspensión/reconexión de M08 (mora) y de M09 (solicitud del socio) y crear OT (`disconnect`/`reconnect`) con marca moroso y origen gestión de mora, o comando remoto si el servicio admite corte remoto. | RN-07 §4; MER-019; MER-017 | Núcleo | O6 | Informado | Ninguna acción de red sin origen CRM/mora autorizado. |
| RF-TEC-133 | Generar OT de corte por mora sin observación técnica completa si el parámetro lo permite. | V2 #2694 | Estándar | O6 | Adoptado | — |
| RF-TEC-134 | Reconexión automática tras regularización: cerrar y reconectar en un paso (`reconnect`) con comando remoto; si no hay sistema remoto vigente, la OT queda pendiente para cuadrilla. | RN-07 §4 (`Confirmar_OT_Reconectar`), §4 (vuelve a Pendiente) | Núcleo | O6 | Adoptado | Evento `tec.reconnection.executed` con fecha efectiva. |
| RF-TEC-135 | Informar a M08 el resultado de cada corte/reconexión (ejecutado, no ejecutado con motivo: sin acceso, medidor inaccesible, socio pagó en sitio, error de sistema remoto). | MER-019; BASE §68 (controles, M08) | Núcleo | O6 | Adoptado | M08 recibe evento por cada orden. |
| RF-TEC-136 | Notificar al socio el cierre de OT de desconexión por SMS/WhatsApp/mail según configuración. | RN-07 §1.7 (`NotificarCierreOt`) | Estándar | O6 | Adoptado | Constancia en T09. |
| RF-TEC-137 | Cortes masivos con vista de a quién ya se generó la orden y exclusión de servicios con orden en curso. | RN-07 §Reglas adicionales (`Get_ServiciosNotificados`) | Estándar | O6 | Adoptado | Sin duplicados. |

### 5.10 Mantenimiento, infraestructura y mapas (BASE §18)

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-138 | Inventariar infraestructura por ubicación como elementos de red (válvulas, transformadores, nodos, postes, cámaras) con marca, modelo, serie, características técnicas, fecha de instalación y sustitución. | BASE §18; CAT `NIV_REDES` | Núcleo | O7 | Informado | Precarga VAL-001. |
| RF-TEC-139 | Relacionar activos y componentes (jerarquía y relaciones permitidas). | BASE §18 | Núcleo | O7 | Informado | Ver RF-TEC-148. |
| RF-TEC-140 | Planes de mantenimiento preventivo por activo o tipo de componente con frecuencia (semanal, mensual, bimestral, trimestral, cuatrimestral, semestral, anual o cada N días), margen anterior/posterior y generación automática de OT de mantenimiento. | BASE §18 CU-18; RN-07 §7 (patrón de frecuencias) | Núcleo | O7 | Informado | Job `tec:generar-mantenimiento` crea la próxima OT al alcanzarse fecha − margen. |
| RF-TEC-141 | Gestionar averías como OT correctivas vinculadas a incidentes/reclamos sin ocultar el preventivo programado original. | BASE §18 CU-18 excepción | Núcleo | O7 | Informado | Preventivo y correctivo coexisten. |
| RF-TEC-142 | Registrar intervenciones, tareas, materiales y resultado por activo; programar el próximo control. | BASE §18 | Núcleo | O7 | Informado | Historial por activo. |
| RF-TEC-143 | Consultar historial y costo por activo (materiales, horas, vehículos). | BASE §18 | Estándar | O7 | Informado | Informe de costo acumulado por período. |
| RF-TEC-144 | Planificar interrupciones (tramo, elemento, fecha/hora inicio/fin, motivo), con aprobación y aviso masivo a contratos afectados. | BASE §18; DFA M15 mejora | Núcleo | O7 | Informado | Aviso vía T09 con constancia. |
| RF-TEC-145 | Identificar contratos potencialmente afectados por un elemento o zona (análisis de impacto aguas abajo). | BASE §18; DFA M15 mejora | Núcleo | O7 | Informado | Ver RF-TEC-156. |
| RF-TEC-146 | Visualizar infraestructura, suministros, OT, reclamos y visitas en mapa web con capas activables. | BASE §18; DFA M15 mejora | Núcleo | O7 | Informado | Capa de OT disponible desde O3. |
| RF-TEC-147 | Documentación técnica adjunta por activo (planos, manuales, fotos) y control de garantías y vencimientos (con M13 para RMA). | BASE §18; MER-020 | Estándar | O7 | Informado | Alertas de vencimiento. |

### 5.11 Red / GIS

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-148 | Definir redes (eléctrica, agua, gas, cloacas, telecom) y los servicios que usan cada red. | RN-07 §5.2; CAT `REDES`, `REDES_SERVICIOS` | Núcleo | O7 | Adoptado | Una red puede servir a varios servicios. |
| RF-TEC-149 | Capas por red (MT, BT, troncal, distribución); componentes y relaciones sin capa son comunes a todas las capas. | RN-07 §5.2; CAT `REDES_CAPAS` | Núcleo | O7 | Adoptado | Consulta por capa incluye comunes. |
| RF-TEC-150 | Tipos de componente con ícono, permite conectar servicios, múltiples conexiones, múltiples elementos (rango), nombre de los elementos (bornes/pares/puertos), distribuye en hijos. | CAT `REDES_COMPONENTES`; RN-07 §5.2 | Núcleo | O7 | Adoptado | "Transformador" es un componente configurado (no entidad fija). |
| RF-TEC-151 | Relaciones permitidas padre → hijo entre componentes por red/capa; la red instalada solo admite relaciones permitidas. | CAT `REDES_RELACIONES_COMPONENTES` | Núcleo | O7 | Adoptado | Alta de nodo con padre no permitido se rechaza. |
| RF-TEC-152 | Atributos tipados por componente: texto (largo), entero, decimal (N decimales), fecha, booleano, lista, referencia a catálogo del sistema (lista blanca, no reflexión), visible sí/no. | CAT `REDES_ATRIBUTOS_COMPONENTES`, `REDES_ATRIBUTOS`; RN-07 §5.2 | Núcleo | O7 | Adoptado | Potencia kVA, tensión, fases como atributos. |
| RF-TEC-153 | Red instalada: elementos con padre, componente, capa, descripción, número, rango inicial–final, geometría (punto/línea/polígono GeoJSON), domicilio, estado (Disponible, Utilizado, Dañado, No aplica, Planificado, Retirado), activo. Alta simple y múltiple. | CAT `REDES_RED_INSTALADA`; INV `frmRedes_RedInstalada_*` | Núcleo | O7 | Adoptado | Coordenadas numéricas (no texto con coma). |
| RF-TEC-154 | No borrar elementos con servicios conectados o hijos; retirar con fecha y motivo. | RN-07 §5.2 (borrado sin verificar) | Núcleo | O7 | Adoptado | 409 si tiene conexiones vigentes. |
| RF-TEC-155 | Vínculo servicio-red con historial (fecha de conexión/desconexión, estado, observaciones), validando que el punto admita conexión, tenga capacidad (rango/múltiple), esté en estado utilizable y que el servicio no esté conectado a otro punto de la misma red/capa. | RN-07 §5.1, §5.2; CAT `SERSOC_REDES`; V2 #401 | Núcleo | O3 (Internet) / O7 | Adoptado | Exigir punto de conexión en OT según V2 #401. |
| RF-TEC-156 | Análisis de impacto: dado un elemento (p. ej. transformador) o un conjunto, listar servicios, contratos, titulares y servicios críticos (electrodependientes, grandes usuarios) aguas abajo, con conteo y exportación, y lanzar aviso masivo. | DFA M15 mejora; BASE §18 | Núcleo | O7 | Adoptado | Resultado en < 5 s para 50.000 suministros. |
| RF-TEC-157 | Descripción del punto de conexión del servicio recorriendo ancestros ("Red \| Capa \| Nodo → Padre → …"). | RN-07 §5.2 | Estándar | O7 | Adoptado | Visible en ficha del servicio. |
| RF-TEC-158 | Informes de red: estructura, red instalada, red conectada por servicio (incluye ancestros), cuentas sin conexión a red física (corrigiendo el bug de reconexión a otro nodo), cuentas conectadas por punto (con filtro de rango de consumos y suma), conexiones disponibles (considerando estado y capacidad). | RN-07 §5.2 informes | Estándar | O7 | Adoptado | Corrección de bugs verificada en pruebas. |
| RF-TEC-159 | Migrar la red v1 (niveles por capa, nodos con padre, disponibilidad) a la red genérica. | RN-07 §5.1; CAT `NIV_*` | Estándar | O7 | Adoptado | Ver §19. |
| RF-TEC-160 | Exportar red y elementos a KML y GeoJSON (puntos con ícono por componente, líneas padre→hijo); importar parcelas/capas GIS (shapefile/GeoJSON/KML). | RN-07 §5.3; FIC 16; RN-10 §10 | Estándar | O7 | Adoptado | Coordenadas con punto decimal. |
| RF-TEC-161 | Exportaciones GIS a sistemas externos y reguladores como **plantillas configurables** (usuarios, consumos, movimientos altas/bajas, activos, RTI OCEBA), sin códigos de concepto/categoría fijos: mapeos por tenant. | RN-07 §5.4; V2 #2933, #2823 | Estándar | O7 | Adoptado | Las 10 variantes de ProCoop se reproducen como plantillas de ejemplo. |
| RF-TEC-162 | Marca "con dato GIS" por servicio y servicios a usar en mapas GIS. | CAT `SERSOC_EXTRAS.GIS`; V2 #2425 | Estándar | O7 | Adoptado | Filtro en mapa. |
| RF-TEC-163 | Edición de red en mapa (dibujar elemento, mover, conectar) además de árbol jerárquico. | DFA M15 mejora | Estándar | O7 | Adoptado | Cambios versionados con autor. |

### 5.12 Equipos de red y centrales

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-164 | Inventario de equipos de red (OLT, router/BRAS MikroTik, NAS/Radius, switch, AP inalámbrico, central telefónica, DSLAM, cabecera TV) con ubicación (elemento de red), IP de gestión, puerto, marca, modelo, serie, firmware y sistema de aprovisionamiento asociado. | DFA M15 (`EQUIPOS`, `CENTRALT`); CAT `MIKROTIK`; BASE §86 | Núcleo | O3 | Adoptado | Credenciales solo en bóveda T06 (CTR-TEC-29). |
| RF-TEC-165 | Credenciales de equipos (usuario/clave/token) gestionadas en la bóveda del tenant; nunca visibles en catálogo, BI ni API pública. | RN-10 §9; BASE §86 ("no exponer secretos") | Núcleo | O3 | Adoptado | Acceso a secretos auditado. |
| RF-TEC-166 | Monitoreo de nodos y equipos (estado arriba/abajo vía integración) asociado a incidentes de zona en M09. | MER-017 | Estándar | O3 | Adoptado | Caída de OLT crea/propone incidente de zona con impacto. |
| RF-TEC-167 | Puertos y capacidad de OLT/PON/splitter como elementos de red para factibilidad y asignación. | BASE §86 (recurso de conexión); RN-07 §1.11 (OLT, SLOT, PORT, VPORT) | Núcleo | O3 | Adoptado | Asignación de puerto en la OT de instalación. |

### 5.13 Obras, loteos y contribución por mejoras (MER-009)

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-168 | Obras con descripción, servicio, tipo, grupo, fechas de inicio/fin, ocultar, presupuesto, avance (% y hitos), costeo real (materiales, horas, compras), centro de costo. | CAT `OBRAS`; MER-009; INV `abm_Obras` | Núcleo | O7 | Informado | Desvío presupuesto vs real visible. |
| RF-TEC-169 | Grupos de obra con cuentas contables y distribución % por sección (suma 100 %). | CAT `GRPOBRA`; RN-07 §2 (`clsGrpObra`) | Estándar | O7 | Adoptado | Validación de 100 %. |
| RF-TEC-170 | Órdenes de mantenimiento sobre obra (`maintenance`) con materiales imputados a la obra y vales. | RN-07 §1.1, §1.8 | Núcleo | O7 | Adoptado | Informe de recursos asignados a obras. |
| RF-TEC-171 | Base de aprobación obligatoria para cobrar (ordenanza, convenio, asamblea) adjunta y vigente. | MER-009 límite | Núcleo | O7 | Informado | Sin base aprobada no se habilita el prorrateo. |
| RF-TEC-172 | Padrón de beneficiarios por lote o frente (inmueble, titular, metros de frente, superficie, unidades), importable por Excel. | MER-009 | Núcleo | O7 | Informado | ExcelImportWizard con validación de inmueble. |
| RF-TEC-173 | Prorrateo por metros de frente, superficie, partes iguales, unidades u otro criterio explícito; simulación y aprobación; envío a M05/M08 para facturar en cuotas o plan de pago. | MER-009 | Núcleo | O7 | A validar (PA-TEC-16) | Suma de cuotas = costo a distribuir (redondeo explícito). |
| RF-TEC-174 | Loteos: alta de red y puntos de conexión del loteo antes de existir las calles en catálogo (texto + punto para revisión). | MER-009; BASE §77 CU-GEO-01 | Estándar | O7 | Adoptado | Calle pendiente queda en revisión de T04. |
| RF-TEC-175 | Expedientes de trámites técnicos (presentación de planos, certificado de instalador, habilitaciones) con etapas, resolución, adjuntos y fechas. | CAT `EXPEDIENTES`, `EXPEDIENTES_TRAM` | Estándar | O7 | Adoptado | Etapas con estado y resolución. |

### 5.14 Inspecciones y consumo no registrado (MER-004)

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-176 | Casos de inspección por alerta de patrón de consumo (M03), denuncia, hallazgo de lecturista o plan de control; una sospecha no es infracción. | MER-004 | Núcleo | O7 | Informado | Estado inicial `suspected`. |
| RF-TEC-177 | OT de inspección con acta (checklist configurable por servicio), fotos, GPS, testigos, firma del usuario o constancia de negativa. | MER-004 | Núcleo | O7 | Informado | Acta inmutable con hash. |
| RF-TEC-178 | Gestión de precintos numerados (alta de lote, asignación a inspector, colocación, retiro, rotura) vinculada a medidor y acta. | MER-004 | Estándar | O7 | Informado | Un precinto no se coloca dos veces. |
| RF-TEC-179 | Notificación al usuario y registro de descargo dentro del plazo configurable. | MER-004 | Núcleo | O7 | Informado | Sin descargo vencido el plazo se habilita propuesta. |
| RF-TEC-180 | Propuesta de recupero según método aprobado (versionado por régimen del servicio) calculada por M04, con aprobación obligatoria; facturación separada por M05; nunca automática. | MER-004 límite | Núcleo | O7 | A validar (PA-TEC-15) | Sin aprobación no hay documento. |
| RF-TEC-181 | Seguimiento del caso hasta regularización, con reincidencias y estadística por zona. | MER-004 | Estándar | O7 | Informado | Indicadores en §15. |

### 5.15 Aprovisionamiento de Internet/TV (BASE §86, MER-017)

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-182 | Configurar sistemas de aprovisionamiento por tenant y servicio: tipo (MikroTik, Radius, Radius Gretix, SmartOlt, Wispro, Sopnet, Silexis, Ispfull, Sensa, SITSA, AION, manual), endpoint, credenciales en bóveda, modo solo consultas, eliminar usuario al dar de baja, perfil de desconectado. | RN-10 §9; FIC 17; V2 #2393, #2897, #3165, #3189, #3034, #3035 | Núcleo | O3 | Adoptado | Prueba de conexión desde la pantalla. |
| RF-TEC-183 | Perfiles de aprovisionamiento: mapeo plan comercial (M02) → perfil técnico por sistema (velocidad subida/bajada, VLAN, pool IP, perfil PPPoE/queue, perfil ONU). | BASE §86 (plan con tecnología y velocidades) | Núcleo | O3 | Adoptado | Cambio de plan resuelve perfil destino. |
| RF-TEC-184 | Perfil técnico del servicio: identificador de acceso (usuario PPPoE, generado), clave en bóveda, MAC, IP fija/dinámica, AP/nodo, OLT/slot/puerto/vport, serie ONU/CPE, terminal, posición, datos de partner, fecha y usuario de registro. | CAT `INTERNET`; RN-07 §1.11; V2 #2422 | Núcleo | O3 | Adoptado | Secretos nunca en BI ni API pública. |
| RF-TEC-185 | Comandos de aprovisionamiento durables e idempotentes: `activate`, `changePlan`, `suspend`, `reactivate`, `deactivate`, `delete`, `query`, `resetCredentials`, con estado, intentos, respuesta, correlación y origen (OT, M08, M09). | AGR-016; MER-017; CAT `TELEMED_COMM` | Núcleo | O3 | Adoptado | Reintento no duplica; resultado confirmado o pendiente manual. |
| RF-TEC-186 | Alta: al confirmar instalación se emite `activate`; el hito de activación espera confirmación del sistema (o registro manual autorizado). | BASE §86; §73 | Núcleo | O3 | A validar (PA-TEC-02, PA-TEC-09) | Sin confirmación la instalación queda `executed` pendiente de aprovisionar. |
| RF-TEC-187 | Corte/suspensión por mora y reactivación (desde M08), cambio de plan con fecha efectiva (desde M09/contrato), baja con desconexión y retiro de equipo. | BASE §86 casos; MER-017 | Núcleo | O6 | Informado | Evento por resultado al módulo origen. |
| RF-TEC-188 | Fallback manual: cuando no hay integración o falla definitivamente, generar tarea al NOC con datos y registrar ejecución manual con evidencia. | BASE §86 ("integración autorizada o registro técnico") | Núcleo | O3 | Adoptado | Tarea manual con SLA y confirmación. |
| RF-TEC-189 | Exportación masiva para OLT (CSV con OLT, SLOT, PORT, VPORT y acción 0 desconexión / 1 alta-otros) como plantilla. | RN-07 §1.11 (`ExportarArchivo`) | Estándar | O3 | Adoptado | Archivo `Alta_Desconexion_ddMMyyyy.csv`, separador `;`. |
| RF-TEC-190 | Sincronización con sistemas externos de clientes y servicios (AION y equivalentes): clientes, servicios, servicios de socio, con conciliación de diferencias. | INV `frmSincronizacionAION` | Estándar | O3 | Adoptado | Reporte de diferencias sin sobrescritura automática. |
| RF-TEC-191 | Identificador externo por contrato/conexión (no por cuenta) y tabla de correspondencia por sistema. | RN-07 §4 (SITSA usa cuenta); BASE §86 ejemplo hermanos | Núcleo | O3 | Adoptado | Baja de B no apaga A (BASE §86 ejemplo). |
| RF-TEC-192 | Diagnóstico desde la ficha (consultar estado de sesión, señal ONU, último login) vía `query`, visible a NOC y atención con permiso. | BASE §86 (diagnóstico) | Estándar | O3 | Adoptado | Resultado no se persiste como medición facturable. |
| RF-TEC-193 | Medición de tráfico/uso solo si existe fuente definida; no convierte GB en cargo sin regla. | BASE §86; §50 control | Estándar | O3 | Informado | Sin fuente, la app del socio no muestra consumo. |
| RF-TEC-194 | Aprovisionamiento de TV y otros TIC (Sensa, Sopnet, SITSA) con la misma interfaz. | FIC 17 | Estándar | O10 | Adoptado | Mismo modelo de comandos. |
| RF-TEC-195 | Casillas de correo provistas como servicio (usuario, dominio, otros) con clave en bóveda. | CAT `CORREOSINT` | Extensión | O10 | Adoptado | Claves no se migran en claro. |
| RF-TEC-196 | Comandos de telemedición/medición inteligente desde la OT (conectar, desconectar, tomar lectura, vincular/desvincular medidor, alta de cuenta, cambio de categoría, carga de crédito, consulta de datos, cambio de usuario/clave del portal externo) delegados a M03 con resultado explícito. | RN-07 §4 (Discar, telemetría); INV `ComandosDiscar`, `ComandosNexo`, `ComandosTelemedicion`; V2 #3175 | Estándar | O7 | Adoptado | "Operación cancelada por el usuario" no es éxito (CTR-TEC-25). |

### 5.16 Telefonía (MER-017; tasación en M04)

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-197 | Red física telefónica: centrales (modalidad de CDR, prefijo, moneda, último disco, GPS, importar segundos/clave), puertos de central, repartidores (GPS), grupos de entrada/salida, regletas, posiciones (terminal, color, posición anterior, puerto DSLAM, puerto central), cajas (GPS), regletas de caja, posiciones de caja, DSLAM (marca, modelo, serie) y puertos; estados Disponible / No disponible / Inactivo; conexiones entrante/saliente y conexión masiva. | RN-07 §8.1; CAT §12 `TEL_*` | Núcleo | O10 | Adoptado | No se conecta una posición inactiva. |
| RF-TEC-198 | Servicio conectado a una posición de caja seleccionable al crear la OT entre puntos disponibles. | RN-07 §8.1 (`Get_PuntoConexionDisponibles`) | Núcleo | O10 | Adoptado | Posición ocupada no se ofrece. |
| RF-TEC-199 | KML de central, repartidor y cajas. | RN-07 §5.3 | Estándar | O10 | Adoptado | — |
| RF-TEC-200 | Prefijos locales y pool de números con alta/baja por rango, validación de superposición, estados disponible/reservado/asignado/cuarentena/retirado; baja solo de no asignados (lógica, no física). | RN-07 §8.1, §8.10 | Núcleo | O10 | Adoptado | Rango superpuesto rechazado. |
| RF-TEC-201 | Líneas del abonado: servicio + número + plan tarifario (M04) con fechas de alta/baja (vigencia usada para atribuir llamadas); un número no puede estar en uso por otro servicio en la misma fecha; desvincular cierra la línea conservando el plan. | RN-07 §8.1, §8.10 | Núcleo | O10 | Adoptado | Validación por intervalo de fechas (no solo línea abierta). |
| RF-TEC-202 | Reserva de números propuestos en OT abiertas. | RN-07 §8.10 (`GetNumerosEnOT`) | Estándar | O10 | Adoptado | Número reservado no se ofrece a otra OT. |
| RF-TEC-203 | Telefonía prepaga: categoría prepaga y recarga mediante OT/operación de recarga y concepto de crédito. | RN-07 §8.1; V2 #236, #238, #332, #2099 | Estándar | O10 | Adoptado | Recarga como operación `prepaidTopUp`. |
| RF-TEC-204 | Plan de numeración ENACOM (número completo, localidad, provincia, indicativo, bloque, operador, servicio, modalidad con flag móvil, clave, local) importable desde planilla, creando operadores/servicios/modalidades nuevos sin distinguir mayúsculas; número = 0+indicativo+bloque o 0+indicativo+15+bloque si móvil. | RN-07 §8.2, §8.10; CAT `CARACTER`, `OPERADOR`, `TEL_SERVICIO`, `TEL_MODALIDAD` | Núcleo | O10 | Adoptado | Búsqueda por prefijo más largo con índice (no stored procedures). |
| RF-TEC-205 | Importación de CDR por central según modalidad (≈35 formatos y descargas online sin archivo): lectores como plugins; salientes y entrantes; lote por central (cabecera o último + 1); origen con "0"; segundos/clave del archivo según central; error de fila aborta el archivo con número de fila. | RN-07 §8.3, §8.10; FIC 17 | Núcleo | O10 | A validar (PA-TEC-13) | Cada formato habilitado tiene archivo de prueba. |
| RF-TEC-206 | Detección de duplicados por (origen, destino, fecha, segundos) con decisión de reprocesar; reutilizar identidad de las ya existentes. | RN-07 §8.3; V2 #2302 | Núcleo | O10 | Adoptado | Reimportar el mismo archivo no duplica. |
| RF-TEC-207 | Atribución de origen al número vigente a la fecha (0 → "origen no encontrado"; >1 → "duplicado") y de entrantes al destinatario (con y sin prefijo); asignación manual de no atribuidas; borrado/reversión de lote solo si no está agrupado/facturado. | RN-07 §8.3 | Núcleo | O10 | Adoptado | Reversión bloqueada tras agrupación en M05. |
| RF-TEC-208 | Exclusión de números en importadores (Lucent) e importe 0 para Telco IP clave 99 como reglas configurables por lector. | V2 #2444, #2346 | Estándar | O10 | Adoptado | — |
| RF-TEC-209 | Importación de archivos CPP de operadoras (CPP, CP2, CP4, CP5, CP6) e internacionales de carrier (TRL, carga manual con control de repetidos) con operador por defecto. | RN-07 §8.5, §8.6; V2 #2295 | Estándar | O10 | Adoptado | Liquidación CVLP en M05/M06. |
| RF-TEC-210 | Telefonía móvil (reventa Claro/Personal): importación de factura del proveedor por línea y asignación al servicio; el clearing y los conceptos en M04. | RN-07 §8.8; FIC 17; V2 #301, #2253, #13 | Extensión | O10 | A validar (PA-TEC-14) | Línea sin servicio queda en pendientes de asignar. |
| RF-TEC-211 | Envío de llamadas atribuidas a tasación (M04) y recepción del resultado; retasación solo de no agrupadas. | RN-07 §8.4, §8.10 | Núcleo | O10 | Adoptado | Evento `tec.cdr.attributed`. |
| RF-TEC-212 | Guía telefónica (tradicional, compacta A/B, Excel) de titulares que desean figurar. | RN-07 §8.1 | Estándar | O10 | Adoptado | Respeta consentimiento. |
| RF-TEC-213 | Informes de telefonía: llamadas CNC, categorías CNC, realizadas, no asignadas, no agrupadas, no facturadas, números en central, conectados sin tráfico, por operador, números disponibles, entrantes por central. | RN-07 §8.7 | Estándar | O10 | Adoptado | Exportables XLSX/CSV. |
| RF-TEC-214 | Llamadas rechazadas (público, abonado, duración) importadas cuando el formato las trae. | CAT `RECHAZOS` | Extensión | O10 | Adoptado | — |

### 5.17 Geolocalización operativa (BASE §77)

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-215 | Mostrar el punto de prestación en Google Maps en factibilidad, OT, visita, ficha del servicio y mapa operativo. | GEO-003 | Núcleo | O3 | Informado | Marcador con estado confirmado/aproximado/pendiente. |
| RF-TEC-216 | Confirmar o corregir el punto por usuario autorizado (operador, técnico en sitio) registrando fuente, momento y motivo; historial de cambios. | BASE §77 | Núcleo | O3 | Informado | Corrección del técnico queda "propuesta" hasta aprobación si la regla lo exige. |
| RF-TEC-217 | Distinguir punto confirmado, aproximado y pendiente; no presentar precisión no disponible; no inventar coordenadas. | BASE §77 | Núcleo | O3 | Informado | Pendiente no muestra marcador falso. |
| RF-TEC-218 | Ubicación por coordenadas o referencias cuando no exista coincidencia de calle/altura (rural, loteo nuevo), con revisión. | BASE §77 | Núcleo | O3 | Informado | Bandeja de revisión PAN-TEC-48. |
| RF-TEC-219 | Manejo de caída o límite de cuota de Google/Georef sin perder el formulario; enriquecimiento posterior por job. | BASE §77 | Núcleo | O3 | Informado | Job `tec:geocodificar-pendientes`. |
| RF-TEC-220 | Usar ubicación del dispositivo solo con permiso y como ayuda; la posición del dispositivo no es automáticamente el domicilio contratado. | BASE §77; GEO-F6 | Núcleo | O3 | Informado | — |
| RF-TEC-221 | Control de acceso a mapa, exportaciones y API de domicilios por tenant y relación autorizada. | BASE §77 | Núcleo | O3 | Informado | Prueba de aislamiento de tenant. |
| RF-TEC-222 | Mapa estático opcional en la impresión de OT y factibilidad con la clave del tenant (bóveda), nunca una clave fija. | RN-10 §10 (clave hardcodeada); V2 #358 | Estándar | O3 | Adoptado | Sin clave configurada no se imprime mapa. |
| RF-TEC-223 | Zona de agenda y elemento de red sugerido a partir del punto de prestación. | BASE §50; §86 | Estándar | O3 | Adoptado | Sugerencia editable. |

### 5.18 Informes, notificaciones y otros

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-TEC-224 | Informes técnicos: planilla de control, planilla de relevamiento, detalle de orden, auditoría, reclamos (con numeración por servicio), reincidencias (cuenta / cuenta+servicio / cuenta+servicio+operación), estadísticas de demora, altas y desconexiones, trabajos pendientes, recursos asignados a obras, parte diario, estado de órdenes enviadas a campo; filtros por fecha de emisión, resolución o nota; orden por defecto, domicilio o zona-sector-recorrido; ocultar informes de socio para OM. | RN-07 §1.10, §1.11; INV `frmInformesTecnica` | Estándar | O3 | Adoptado | Ver §15. |
| RF-TEC-225 | Vista previa de resultados con marcado de registros y exportación a mapa (KML/Google Earth). | INV `frmInformes_Preview` | Estándar | O3 | Adoptado | — |
| RF-TEC-226 | Notificación al socio al generar/confirmar OT según operación y canal (SMS, WhatsApp con plantilla `generacion_ot`, mail, push), con texto que incluye retiro/no retiro de medidor en desconexión/reconexión y teléfono destino según preferencia. | RN-07 §1.7, §Reglas adicionales; V2 #2693 | Estándar | O3 | Adoptado | Constancia de entrega en T09. |
| RF-TEC-227 | Publicación de OT al portal del socio (estado y notas públicas) sin sincronización a base externa. | RN-07 §1.7 (CoopOnline); FIC 14.1 | Núcleo | O3 | Adoptado | Lectura directa de la misma base. |
| RF-TEC-228 | Generar OT de reclamo desde la web/portal (vía M09) según parámetro. | V2 #58 | Estándar | O3 | Adoptado | Caso M09 → OT derivada. |
| RF-TEC-229 | Carga rápida de OT derivada desde la ficha de atención (servicio, descripción) para operadores. | INV `frmCargaRapidaReclamo` | Estándar | O3 | Reemplazado por RF-TEC-025 vía M09 | El reclamo nace en M09. |
| RF-TEC-230 | API para terceros de consulta de estado de OT y visitas del tenant (T10), sin secretos. | BASE §105 APIs | Extensión | O11 | Adoptado | Token con scope. |

## 6. Reglas de negocio

| ID | Regla | Comportamiento ProCoop (fuente) | Decisión en GoodApps | Parámetros | [VERIFICAR] |
|---|---|---|---|---|---|
| RN-TEC-001 | Factibilidad usable en un alta: confirmada, factible, no anulada, dentro de vigencia y sin servicio asociado. | Confirmada + factible + ≤90 días + sin servicio; no filtra anuladas (RN-07 §3.1) | **Mejorar**: excluir anuladas y vencidas; vigencia por servicio. | PRM-TEC-130 | — |
| RN-TEC-002 | Anular factibilidad cambia estado a `cancelled` y limpia uso posible; no altera dictamen histórico. | Anular pone `CONFIRMADO=true` y no toca `FACTIBLE` (bug) | **Reemplazar** | — | — |
| RN-TEC-003 | Al editar factibilidad sin imagen de mapa no se borra el punto ni archivos; el punto se versiona. | Edición sin imagen borra `MAPA` y archivo (RN-07 §3.1) | **Reemplazar** | — | — |
| RN-TEC-004 | Dictamen exige motivo, responsable técnico y estado técnico; el estado técnico solo se informa si hay confirmación. | `ESTADO_TEC` solo si confirmado (RN-07 §3.1) | **Replicar** | — | — |
| RN-TEC-005 | Exigencia de factibilidad para alta/reconexión según servicio. | V2 #388 | **Replicar** configurable por servicio/operación | PRM-TEC-024 | — |
| RN-TEC-006 | Factibilidad cerrada solo editable con permiso y parámetro, con versión. | V2 #2654, #3082 | **Mejorar** (versión) | PRM-TEC-064, PRM-TEC-086 | — |
| RN-TEC-007 | Teléfono y celular se validan por formato E.164 (no truncado). | Truncado a 20/40 caracteres | **Mejorar** | — | — |
| RN-TEC-008 | Factibilidad no crea catastro de facturación (`GRU_FAC=0`); grupo de factura lo define el contrato. | `CargarDatosCatastro` fija `GRU_FAC=0` | **Descartar** (no aplica) | — | — |
| RN-TEC-009 | Una OT pertenece a una clase única; mantenimiento no exige titular (sí activo/obra). | `TIP_INCI` 2/3 + `TipoOrd` 1/2 inconsistentes | **Mejorar** (enum único) | — | ¿`TIP_INCI=1` histórico? (RN-07 §11.2) → migración lo mapea a `service` con observación |
| RN-TEC-010 | Estados de OT unificados (§8); "cerrada" y "confirmada" no se mezclan; doble paso opcional. | Enum 1/2/3/4 vs DTO web 1/2/3 | **Reemplazar** | PRM-TEC-132 | Significado real de `COD_EST=2` por cooperativa (RN-07 §11.1) → regla de migración en §19 |
| RN-TEC-011 | Pasaje a "Enviada a campo" al imprimir solo si la configuración lo indica. | Imprimir pasa a En proceso salvo V2 #2808 | **Replicar** configurable | PRM-TEC-072 | — |
| RN-TEC-012 | Validación general de creación: servicio existente, no dado de baja (salvo incidente y reconexión), no pendiente de conectar salvo parámetro. | `Validar_OrdenTrabajo_General` | **Replicar** | PRM-TEC-065 | — |
| RN-TEC-013 | Incidente/reclamo solo exige servicio existente (admite servicios dados de baja o pendientes). | `Validar_OrdenTrabajo_Incidente` | **Replicar** | — | — |
| RN-TEC-014 | Traslado y desconexión: validación general + sin otra OT pendiente de la misma operación. | `Validar_OrdenTrabajo_Traslado/Desconexion` | **Replicar** | — | — |
| RN-TEC-015 | Reconexión: solo servicio desconectado; no titular fallecido salvo parámetro; no planes de vivienda; sin otra reconexión pendiente. | `Validar_OrdenTrabajo_Reconexion` | **Replicar** | PRM-TEC-114 | — |
| RN-TEC-016 | Cambio de medidor: requiere medidor o datos de guía, no retirado, sin otra OT pendiente. | `Validar_OrdenTrabajo_CambioMedidor` | **Replicar** | — | — |
| RN-TEC-017 | Retiro de medidor: requiere medidor o guía, servicio desconectado; en telefonía, última línea abierta; para todos los servicios se controla además el flag retirado. | No controla `RETIRADO` salvo telefonía | **Mejorar** (controlar siempre) | — | — |
| RN-TEC-018 | Alta: no si el servicio está dado de baja ni con alta/reconexión pendiente; admite pendiente de conectar. | `Validar_OrdenTrabajo_Alta` | **Replicar** | — | — |
| RN-TEC-019 | No dos OT abiertas de la misma operación para el mismo servicio. | `Existe_OT_Pendiente` (variante 90 días) | **Mejorar**: ventana configurable, default sin límite | PRM-TEC-131 | — |
| RN-TEC-020 | OT pendiente = no cerrada ni anulada; por cuenta excluye también cerradas. | `Existe_OrdenesTrabajoPendientes` | **Replicar** | — | — |
| RN-TEC-021 | Instantánea del servicio al crear (domicilio, medidor, catastro concatenado, GPS, certificado, teléfono, línea, moroso, gestión de mora). | `Crear_OT` (GPS truncado a 20, "0" si vacío) | **Mejorar** (sin truncado; GPS numérico) | PRM-TEC-038 | — |
| RN-TEC-022 | Observación del servicio se precarga como observación administrativa si parámetro. | V2 #2339 | **Replicar** | PRM-TEC-038 | — |
| RN-TEC-023 | La OT hereda la factibilidad del servicio si existe. | `COD_FACTIBIL` | **Replicar** | — | — |
| RN-TEC-024 | Efectos por operación al confirmar (§1.4 RN-07): alta → hito de conexión con fecha efectiva; traslado → domicilio (+ adherentes si corresponde); desconexión → desconexión servicio + adherentes + beneficiarios, moroso según OT, retiro de medidor opcional; cambio de medidor → M03; reconexión → reconectar, limpiar moroso, solicitar proporcional; cambio de estado → estado de servicio resultante; retiro de medidor → retirado y limpieza opcional; cambio de categoría → aviso de consumos pendientes con categoría vieja, proporcional, nueva categoría. | Cableado por código 1..8 + parámetros 2330/238 | **Mejorar**: efecto declarativo en catálogo; ejecución vía servicios de módulos dueños | PRM-TEC-115, PRM-TEC-102 | — |
| RN-TEC-025 | Condición resultante del servicio: desconexión → desconectado; alta/reconexión → conectado; lo registra el dueño del contrato. | `CONDICION` 4/2 al cerrar | **Replicar** por evento | — | — |
| RN-TEC-026 | Estado de servicio automático por operación o por default del servicio (alta, baja, reconexión, cambio de medidor, transferencia). | `Guardar_CambioEstadoAutomatico`; `SERVICIO_EXTRAS.ESTASER*` | **Replicar** | — | — |
| RN-TEC-027 | Nota visible en caja/atención si la operación lo indica. | `TRANSAC.AGREGAR_OBSERVACION` | **Replicar** (nota en cuenta M01/M07) | — | — |
| RN-TEC-028 | Lectura obligatoria al cerrar si la operación registra estado y siempre en alta y reconexión de servicios medidos. | `Registra_EstadoMedidor` | **Replicar** | PRM-TEC-018 | — |
| RN-TEC-029 | Retiro de medidor limpia número y matrícula si parámetro; marcado por defecto y pregunta configurables. | V2 #2399, #2440, #2531 | **Replicar** | PRM-TEC-042, PRM-TEC-047, PRM-TEC-055 | — |
| RN-TEC-030 | Traslado: alertar si no cambió zona-sector-recorrido y preguntar por domicilio postal/recorrido postal. | `EsIgualRecorrido`; V2 #2637, #2638 | **Replicar** | PRM-TEC-061, PRM-TEC-062 | — |
| RN-TEC-031 | Catastro de la OT se descompone en circunscripción, lote, manzana, parcela, PH, LT; teléfono actualizado en el campo correcto (no `FAX`). | `ActualizarDatosOpcionales` (guarda teléfono en `FAX`) | **Mejorar** | — | — |
| RN-TEC-032 | Numeración visible: tipos 0–3 y secuencia continua de reclamos por servicio; asignación atómica. | `Get_New_CODSLS` con max+1 | **Mejorar** (secuencia atómica T04) | PRM-TEC-022, PRM-TEC-082, PRM-TEC-083 | — |
| RN-TEC-033 | Número de comprobante de OT por talonario de la operación (OT/OM) o secuencia del tenant. | `COD_COM/SUC_COM/NUM_COM` | **Replicar** opcional | — | — |
| RN-TEC-034 | Órdenes encadenadas: regla aplicable por servicio + filtros; clona OT con otra operación/servicio/vía; orden de confirmación origen/destino; error si 0 o >1 regla al confirmar. | `ALTASEAU` tipo 6, `ConfirmarOrdenSiRelacion` | **Replicar** | — | — |
| RN-TEC-035 | Numeración de órdenes automáticas con secuencia atómica (no `COD_SOL+1`). | `GenerarOrdenAutomatica` sin bloqueo | **Reemplazar** | — | — |
| RN-TEC-036 | Anulación revierte efectos por compensación y materiales por movimientos inversos; nota "Orden de X anulada" en la cuenta. | `PreDelete_TECNICA`, borrado físico `MOV_PRO` | **Mejorar** | — | — |
| RN-TEC-037 | Anular alta de servicio que factura cargo fijo en la baja deja el servicio "No vigente" previa confirmación. | V2 #2753, `CATE_SER.COBRAR_CF_BAJA` | **Replicar** | PRM-TEC-116 | — |
| RN-TEC-038 | Cierre masivo aplica mismos datos, concatena observaciones (sin truncar a 300; límite 4000) y registra "Confirmada por X mediante confirmación masiva". | RN-07 §1.3 (trunca a 300) | **Mejorar** | — | — |
| RN-TEC-039 | Cierre desde campo guarda GPS, fecha de cierre del dispositivo, receptor/conformidad y motivo de disconformidad. | PMovil `RESP_ENC`, `MOTIVO_DISCONFORME` | **Replicar** | — | — |
| RN-TEC-040 | Cargos "antes" se ofrecen al generar (OT pendiente); "luego" al cerrar; filtrados por cambio de estado que desconecta. | `TIPO_CON` 5/6; `CAMBIO_EST` | **Replicar** vía M04 | PRM-TEC-028, PRM-TEC-029 | — |
| RN-TEC-041 | En cierres masivos/campo, los cargos "luego" se generan como comprobante a "próxima facturación" con fecha según regla. | `Validar_ConceptosCobrar_Confirmacion`; V2 #65 | **Replicar** vía M05 (cargo pendiente) | PRM-TEC-113 | — |
| RN-TEC-042 | Proporcional por cambio de categoría: mismo mes, días restantes (adelantado) o transcurridos con signo inverso (vencido); sin negativos opcional; tope de día; comprobante inmediato o próxima factura. | `Generar_ProporcionalCambioCategoria` | **Reemplazar** por función de M04/M05 invocada por evento | PRM-TEC-056, 057, 058, 117, 118 | — |
| RN-TEC-043 | Proporcional por reconexión: crédito por días desconectados del mes o débito por días restantes si no facturado; opción cerrar sin comprobante. | `Generar_DescuentoReconexion` | **Reemplazar** por M04/M05 | PRM-TEC-051, 052, 067, 078 | — |
| RN-TEC-044 | Materiales: entidad propia; descuento desde depósito indicado, custodia del responsable o depósito por defecto; precio de referencia `precioVentaSinImpuestos` del producto. | `MOV_PRO` op. 3/5/6/8, depósito 1 | **Mejorar** | PRM-TEC-151 | — |
| RN-TEC-045 | Necesidades: cuatro cantidades con usuario y fecha; listados de autorizados pendientes de retiro y retirados pendientes de uso solo para OT abiertas. | `TECNICA_NECESIDAD` con bug de filtro | **Mejorar** | PRM-TEC-081 | — |
| RN-TEC-046 | Los materiales no se facturan automáticamente salvo línea facturable por regla/presupuesto. | Sin facturación automática (RN-07 §1.8) | **Replicar** + opción | PRM-TEC-028, 029 | Duda 4 RN-07 → PA-TEC-03 |
| RN-TEC-047 | Impresión de OT: hasta N renglones de materiales (sin límite fijo de 16 en PDF), con vales opcionales. | 16 renglones; V2 #2819 | **Mejorar** | PRM-TEC-074 | — |
| RN-TEC-048 | Un único modelo de impresión por servicio + operación. | `Existe_OT_REPORTE` | **Replicar** | — | — |
| RN-TEC-049 | Sincronización de participantes, cuadrilla y tareas por diferencia sin borrado de historial (se registra baja lógica). | `Save_PARTICUA/PARTIORD/TAROTM` borran e insertan | **Mejorar** | — | — |
| RN-TEC-050 | Notificación a responsables según reglas de servicio + tipo de orden + operaciones + días + franja + feriados + momento; canal y plantilla. | `NotificarResponsables`; V2 #3088, #3105 | **Replicar** | PRM-TEC-119, 120 | — |
| RN-TEC-051 | Notificación al socio por operación: nunca / al generar / al confirmar / siempre; teléfono destino móvil → teléfono → teléfono web. | `TRANSAC.ENVIO_SMS`, `SendSMS`; V2 #2693 | **Replicar** con preferencias de T09 | PRM-TEC-121 | — |
| RN-TEC-052 | Bloqueo por campo/sistema externo: OT enviada a campo o a sistema externo no se confirma masivamente en administración. | `BLOQUEAR` 0/1/2 | **Replicar** | PRM-TEC-073, 089 | — |
| RN-TEC-053 | Envío automático a campo al guardar según parámetro (reemplaza envío a base MySQL). | V2 #2913 | **Reemplazar** (asignación publica a app) | PRM-TEC-079 | — |
| RN-TEC-054 | Estado de la OT respecto de campo: sin acción, pendiente de envío, enviada, recibida, en dispositivo. | `EstadoOrdenCaptor` | **Replicar** | — | — |
| RN-TEC-055 | Reserva temporal expira y libera capacidad; confirmación atómica por cupo. | — (AGR-025) | **Nuevo** | PRM-TEC-133, 134 | — |
| RN-TEC-056 | Capacidad de franja = capacidad del recurso − reservas confirmadas − reservas temporales vigentes; sobrecupo solo con capability. | — | **Nuevo** | PRM-TEC-135 | — |
| RN-TEC-057 | Reprogramación/cancelación por el socio solo con anticipación mínima configurable; luego vía atención. | BASE §50 | **Nuevo** | PRM-TEC-136 | — |
| RN-TEC-058 | Visita fallida no activa contrato ni consume equipo; genera nueva visita o cierre según motivo. | BASE §17, §50, §73 | **Nuevo** | — | — |
| RN-TEC-059 | "En camino" no publica coordenadas; solo estado y hora. | BASE §73, §77 | **Nuevo** | — | — |
| RN-TEC-060 | Stock del equipo: reserva (disponible −1), entrega a custodia (sale de depósito), aplicación (sale de custodia, queda en domicilio/contrato), fallida (sin cambio o devolución), retiro (vuelve). No se descuenta dos veces del depósito central un equipo ya transferido. | BASE §73 tabla; CU-OPE-01 | **Nuevo** (delegado a M13) | — | — |
| RN-TEC-061 | Sustitución de equipo efectivo vs reservado: libera el reservado y aplica el efectivo; nunca dos equipos aplicados por una instalación. | BASE §73 | **Nuevo** | — | — |
| RN-TEC-062 | Conformidad: documento con versión y hash; modificación sustantiva posterior genera nueva versión; no sustitución silenciosa. | BASE §73 firma; AGR-023 | **Nuevo** | — | — |
| RN-TEC-063 | Encuesta posterior e independiente; no bloquea activación; respuestas repetidas/corregidas versionadas. | BASE §73 | **Nuevo** | PRM-TEC-137 | — |
| RN-TEC-064 | Hito de activación = instalación probada y confirmada + (si aplica) aprovisionamiento confirmado + (si aplica) revisión supervisora; nunca la fecha de reserva. | BASE §73 parámetros | **Nuevo** | PRM-TEC-138 | PA-TEC-02 |
| RN-TEC-065 | Fecha efectiva de activación = fecha/hora real de prueba exitosa en zona horaria del tenant, salvo corrección autorizada. | BASE §73; AGR-010 | **Nuevo** | — | — |
| RN-TEC-066 | Idempotencia: cada mutación de campo y cada comando externo tiene identidad única por tenant; repetir devuelve el resultado original. | AGR-016 | **Nuevo** | — | — |
| RN-TEC-067 | Conflicto: si la versión base de la mutación ≠ versión actual y el cambio afecta estado, asignación, equipo, titular o servicio, se crea conflicto; se aplica la evidencia (fotos, firma, materiales usados) pero no los efectos contractuales hasta resolver. | AGR-025; ESC-03 | **Nuevo** | — | — |
| RN-TEC-068 | Responsable de resolución del conflicto: supervisor de la zona/cuadrilla; vencido el plazo, escala al administrador técnico. | AGR-025 ("responsable de resolución") | **Nuevo** | PRM-TEC-139 | PA-TEC-17 |
| RN-TEC-069 | Desvío de reloj del dispositivo > umbral marca la mutación para revisión sin rechazarla. | AGR-010 | **Nuevo** | PRM-TEC-140 | — |
| RN-TEC-070 | Corte/reconexión solo con orden de M08 o M09 válida; el comando registra su origen. | MER-017 | **Nuevo** | — | — |
| RN-TEC-071 | Corte remoto en confirmación de desconexión (MikroTik y otros) se ejecuta como comando asíncrono; falla del sistema externo no aborta silenciosamente: deja la OT en `closing` con paso pendiente o pendiente manual. | Error de telemedición aborta cierre; MikroTik en cierre masivo | **Mejorar** | — | — |
| RN-TEC-072 | Reconexión automática sin sistema remoto vigente: la OT queda pendiente para cuadrilla (no se marca reconectada). | Vuelve a Pendiente sin fecha | **Replicar** | — | — |
| RN-TEC-073 | MikroTik: al cortar se asigna el perfil de desconectado o se elimina el usuario según parámetro; al reconectar se restaura perfil del plan. | V2 #2393, #2897 | **Replicar** | PRM-TEC-041, PRM-TEC-076 | — |
| RN-TEC-074 | SITSA: alta → alta/modificación de contrato; desconexión → suspendido; reconexión → habilitado; cambio de categoría → modificación; identificador por contrato GoodApps (no cuenta); nombre/apellido reales; API key en encabezado. | `clsSitsa` (cuenta como contrato, nombre vacío, key en query string) | **Mejorar** | PRM-TEC-084, 085 | ¿SITSA solo un servicio por cuenta? → mapeo por contrato resuelve |
| RN-TEC-075 | Discar/telemedición: operaciones que requieren fecha la exigen; cancelación del usuario es "no ejecutado", nunca éxito. | Devuelve éxito "Operación cancelada" | **Reemplazar** | PRM-TEC-093 | — |
| RN-TEC-076 | Perfil de aprovisionamiento resuelto por plan vigente a la fecha efectiva del cambio. | — (BASE §86) | **Nuevo** | — | — |
| RN-TEC-077 | Secretos técnicos (claves PPPoE, credenciales de equipos, casillas) nunca se exponen en catálogo público, BI o API; ver secreto requiere capability y deja auditoría. | Claves en claro (`INTERNET.USER_PASS`, `MIKROTIK`, `CORREOSINT`) | **Reemplazar** | — | — |
| RN-TEC-078 | Contratos independientes por conexión en un mismo domicilio: comandos y OT se dirigen al contrato, no a la cuenta. | BASE §86 ejemplo | **Nuevo** | — | — |
| RN-TEC-079 | Disponibilidad de un punto de red: componente admite conexión; si múltiple, conexiones vigentes < capacidad (rango); si único, sin conexión vigente ni OT abierta que lo use; estado Disponible/Utilizado (no Dañado/Retirado). | v1 `Ge_NIV_REDES_Disponibles`; v2 no valida | **Mejorar** (validar siempre) | PRM-TEC-025 | — |
| RN-TEC-080 | Componentes y relaciones sin capa son comunes a todas las capas; los elementos se filtran estrictamente por capa. | `Get_Componentes` | **Replicar** | — | — |
| RN-TEC-081 | Guardado de estructura de red por diferencia sin borrado físico de relaciones/capas usadas. | `Presave_Red` borra lo que no viene | **Mejorar** | — | — |
| RN-TEC-082 | Elementos nuevos reciben ID definitivo y los hijos se reapuntan en la misma transacción. | IDs negativos + max+1 | **Mejorar** (ObjectId) | — | — |
| RN-TEC-083 | Conexión de servicio: nace `connected`; al informar fecha de desconexión pasa a `disconnected`; validaciones RN-TEC-079. | `Save_SERSOC_REDES` sin validar | **Mejorar** | — | — |
| RN-TEC-084 | Atributos tipo "referencia" solo contra catálogos en lista blanca; se guarda ID y texto visible. | Reflexión sobre todas las entidades | **Mejorar** | — | — |
| RN-TEC-085 | Análisis de impacto recorre descendientes del elemento por la jerarquía y relaciones `distribuyeEnHijos`, incluye conexiones vigentes. | — (mejora DFA) | **Nuevo** | — | — |
| RN-TEC-086 | Exportaciones GIS: mapeos por plantilla (conceptos/categorías por banda, formato de cuenta, ruta, fase real del dato — nunca aleatoria), servicio parametrizable (no fijo 1). | 10 clases con códigos fijos; fase al azar; servicio 1 fijo; bug CUIT | **Reemplazar** | PRM-TEC-080, PRM-TEC-122 | Bandas por coop (RN-07 §5.4) → mapeo por tenant |
| RN-TEC-087 | KML con coordenadas de punto decimal invariante. | Cultura es-ES con coma | **Mejorar** | — | — |
| RN-TEC-088 | Distribución por sección de categoría de incidente y grupo de obra suma exactamente 100 %. | No se valida | **Mejorar** | — | — |
| RN-TEC-089 | Informe de recursos por obra valoriza horas con valores vigentes sin sobrescribir parámetros desde el informe. | El informe sobrescribe V2 #2722/2723 | **Reemplazar** | PRM-TEC-070, 071 | ¿El reporte multiplica por esos valores? → se calcula en el servicio |
| RN-TEC-090 | Estadísticas: cantidad y demora promedio (días) de pendientes, resueltas, con/sin reclamo, resueltas dentro y después del período, no resueltas; demora desde fecha de orden y desde fecha de ingreso hasta confirmación o ahora, piso 0; período anterior = todo lo previo a fecha desde. | `Get_Reporte_Estadisticas` | **Replicar** | — | — |
| RN-TEC-091 | Reincidencias: grupos con más de una orden por cuenta / cuenta+servicio / cuenta+servicio+operación en el rango. | `Get_Reporte_Reincidencias` | **Replicar** | — | — |
| RN-TEC-092 | Parte diario: una fila por nota en el rango con responsable, participante, título y texto; sin rango no devuelve nada (exigir rango). | `Get_ParteDiario` (1900) | **Mejorar** (rango obligatorio) | — | — |
| RN-TEC-093 | Obras: cobro solo con base aprobada y criterio de prorrateo explícito. | MER-009 | **Nuevo** | — | — |
| RN-TEC-094 | Inspección: sospecha ≠ infracción; recupero y multa solo con procedimiento, evidencia, descargo y aprobación; nunca automático. | MER-004 | **Nuevo** | PRM-TEC-143 | PA-TEC-15 |
| RN-TEC-095 | Precinto numerado único por tenant; estados disponible/asignado/colocado/retirado/roto/anulado. | — | **Nuevo** | — | — |
| RN-TEC-096 | Pool telefónico: alta de rango crea números disponibles saltando existentes; baja solo de no asignados (lógica). | Borrado físico | **Mejorar** | — | — |
| RN-TEC-097 | Número en uso: ninguna línea de otro servicio con intervalo de vigencia superpuesto. | Cualquier línea abierta bloquea sin importar fecha | **Mejorar** | — | — |
| RN-TEC-098 | Desvincular número: cierra la línea con fecha efectiva, limpia número del servicio y crea línea sin número con el mismo plan ("Desvinculación sin OT"). | `DesvincularMedidor` | **Replicar** | — | — |
| RN-TEC-099 | Plan de numeración: búsqueda por prefijo más largo; número de móvil con "15". | Stored procedure creado en runtime | **Mejorar** (índice) | — | — |
| RN-TEC-100 | Importación CDR: lector por modalidad; error de fila aborta archivo con número de fila; lote de cabecera o último + 1; duplicados por clave compuesta. | `clsImportacion` | **Replicar** | PRM-TEC-108 | Formatos activos por cooperativa (RN-07 §11.15) → PA-TEC-13 |
| RN-TEC-101 | Atribución de origen por número normalizado `0+prefijo+número` vigente a la fecha; 0 → no encontrado; >1 → duplicado. | `Tasacion_Set_OrigenLlamada` | **Replicar** | — | — |
| RN-TEC-102 | Entrantes: destinatario buscado con y sin prefijo; 0 o >1 coincidencias = observación. | `SetDestino_ENTRANTE` | **Replicar** | — | — |
| RN-TEC-103 | Lote de llamadas reversible solo si ninguna llamada está agrupada/facturada. | `EliminarLlamadasLlamadas` (`GRUPO=0`) | **Replicar** | — | — |
| RN-TEC-104 | Retasación reutiliza identidad de la llamada (no borra y reinserta con nuevo ID). | Borra y reinserta con nuevo `COD_LLA` | **Mejorar** (M04) | — | — |
| RN-TEC-105 | Recarga prepaga telefónica genera operación `prepaidTopUp` con importe. | Parámetro 238 | **Replicar** | PRM-TEC-102 | — |
| RN-TEC-106 | Punto de prestación: confirmado / aproximado / pendiente; no se completa con calle homónima ni coordenadas inventadas. | BASE §77 | **Nuevo** | — | — |
| RN-TEC-107 | Clave de mapas del tenant obligatoria; sin clave no hay mapa estático (nunca clave fija). | Clave hardcodeada si vacía | **Reemplazar** | PRM-TEC-123 | — |
| RN-TEC-108 | Integra/app: no hay API key fija en código; tokens por dispositivo/usuario (T02/T06). | API_KEY hardcodeada | **Reemplazar** | — | — |
| RN-TEC-109 | Tickets del proveedor (horas facturables, bolsas de soporte) no son atención al socio. | `ReglasNegocio.Varios.Tickets` | **Descartar** del ámbito TEC (soporte de plataforma T01; atención M09) | — | — |
| RN-TEC-110 | Actividades internas recurrentes se especifican en M09 (incluye corrección de filtros "en término/fuera de término" invertidos); los planes preventivos de TEC reutilizan el motor de frecuencias. | `ReglasNegocio.Actividades` | **Ver M09**; reutilizar motor | — | — |
| RN-TEC-111 | Cambio de categoría al cambiar medidor solo si parámetro. | V2 #2474 | **Replicar** | PRM-TEC-049 | — |
| RN-TEC-112 | Exigir modelo de medidor/dispositivo en servicios que lo requieren en alta. | V2 #2470, #2652 | **Replicar** | PRM-TEC-048, PRM-TEC-063 | — |
| RN-TEC-113 | Telefonía: operación `move`/`disconnect` cierra/abre `phoneLines` coherentes con la fecha efectiva de la OT. | RN-07 §8.1 | **Nuevo** | — | — |

## 7. Modelo de datos

**Campos comunes** (no se repiten en cada colección): `tenantId` (ObjectId, obligatorio, primer campo de todo índice compuesto), `createdAt`, `updatedAt`, `createdBy`, `updatedBy`, `version` (entero, control optimista), `deletedAt` (borrado lógico solo en catálogos; OT, evidencias, conformidades, comandos y CDR nunca se borran). Fechas en UTC; `effectiveAt` (fecha efectiva del hecho) y `recordedAt` (fecha de recepción en el servidor) donde se indica (AGR-010). Importes `Decimal128`. Coordenadas como GeoJSON (`{ type: 'Point', coordinates: [lng, lat] }`) con índice `2dsphere` (CTR-TEC-09). Textos de UI por `dict:`.

### 7.1 `feasibilityRequests` — factibilidades

Propósito: solicitud y dictamen de factibilidad técnica. Origen: `FACTIBIL`, `FACTIBIL_NOTA` (→ `technicalNotes`), `MAPA` (→ `servicePoint`).

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `number` | string | sí | Número visible (secuencia T04 o talonario del punto de venta). |
| `documentRef` | `{ typeCode, branch, number }` | no | Comprobante ProCoop/talonario (`COD_COM/SUC_COM/NUM_COM`). |
| `serviceCode` | ObjectId → servicio M02 | sí | Servicio solicitado. |
| `operationTypeId` | ObjectId → `operationTypes` | sí | Alta, traslado, reconexión, aumento de potencia/plan. |
| `requestedAt` | Date | sí | Fecha de la solicitud (`FECHA`). |
| `personId` / `prospect` | ObjectId → M01 / objeto | sí (uno) | Persona existente o datos de prospecto (`COD_PER`). |
| `accountId` | ObjectId → M01 | no | Cuenta si existe. |
| `caseId` | ObjectId → M09 | no | Caso CRM origen. |
| `address` | objeto (M01 `addressSnapshot`): calle (id catálogo + texto original), altura, piso, dpto, torre, barrio, localidad, provincia, CP, entrecalles, referencias | sí | Domicilio de conexión (`COD_CAL, NUM_CAL, PISO, DPTO, COD_BAR`…). |
| `servicePoint` | `{ geo: Point, status: confirmed|approximate|pending, source: google|georef|device|manual, confirmedBy, confirmedAt, reason }` | sí | Punto de prestación (BASE §77). |
| `cadastre` | `{ circunscription, section, block, parcel, ph, lot }` | no | Catastro. |
| `adjacentStreets` | `{ right:{streetId,number}, left:{…}, back:{…} }` | no | Calles linderas. |
| `readingRoute` | `{ zone, sector, route }` | no | Zona-sector-recorrido. |
| `properties` | objeto tipado según esquema del servicio | no | Propiedades adicionales (`clsPropiedadesItems`). |
| `observations` | `{ administrative, commercial, operational }` | no | Observaciones. |
| `status` | enum (§8.1) | sí | `draft, pending, inEvaluation, closed, cancelled, used, expired`. |
| `adminStatus` | enum `provisional|definitive` | sí | `ESTADO_ADM`. |
| `techStatus` | enum `provisional|definitive` | no | `ESTADO_TEC` (solo si cerrada). |
| `verdict` | enum `feasible|notFeasible` | no | `FACTIBLE`. |
| `verdictReasonCode` / `technicalObservation` | string | si verdict | Motivo y `OBS_TEC`. |
| `technicalResponsibleId` | ObjectId → `fieldResources` | si verdict | Responsable técnico. |
| `substatus` | string (catálogo tenant) | no | `SUBESTADO`. |
| `inspectionWorkOrderIds` | ObjectId[] | no | OT de inspección. |
| `resourceProposal` | `{ networkElementId, port, capacityOk, distanceM }` | no | Recurso de conexión propuesto. |
| `estimateId` / `quoteRef` | ObjectId / `{ module:'ven', id, status }` | no | Estimación y presupuesto M11. |
| `validUntil` | Date | si feasible | Vigencia para alta (PRM-TEC-130). |
| `usedByContractId` | ObjectId | no | Contrato que la consumió (uso único). |
| `closedAt`, `closedBy`, `cancelledAt`, `cancelledBy`, `cancelReason` | Date/ObjectId/string | según estado | — |
| `attachments` | `documentRef[]` (T11) | no | Adjuntos. |

Índices: `{tenantId, number}` único; `{tenantId, status, serviceCode, requestedAt}`; `{tenantId, personId}`; `{tenantId, 'servicePoint.geo'}` 2dsphere; `{tenantId, usedByContractId}`.

### 7.2 `connectionEstimates` — estimación técnica de conexión

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `feasibilityRequestId` | ObjectId | sí | Factibilidad. |
| `templateId` | ObjectId | no | Plantilla aplicada. |
| `lines` | `[{ kind: material|labor|networkWork|other, productId?, description, quantity: Decimal128, unit, laborRole?, hours? }]` | sí | Cómputo. |
| `status` | enum `draft|submitted|accepted|rejected|expired` | sí | Refleja el presupuesto M11. |
| `quoteRef` | `{ id, number, status, acceptedAt }` | no | Presupuesto comercial. |
| `notes` | string | no | — |

Índices: `{tenantId, feasibilityRequestId}`.
Colección auxiliar `connectionEstimateTemplates` (mismos `lines`, `serviceCode`, `technology`, `name`).

### 7.3 `technicalNotes` — notas de solo agregado

Origen: `FACTIBIL_NOTA`, `TECNICA_NOTA`. Campos: `entityType` (`feasibility|workOrder|work|inspectionCase|networkElement`), `entityId`, `title`, `text`, `occurredAt`, `authorUserId`, `responsibleId`, `visibility` (`internal|public`), `source` (`admin|field|integration|system`). Índices: `{tenantId, entityType, entityId, occurredAt}`. Sin edición ni borrado.

### 7.4 Catálogos de OT

**`operationTypes`** (origen `TRANSAC`, enum `Transaccion`, parámetros 2330/238):

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `code`, `name` (`dict:`) | string | sí | `COD_TRAN`, `DES_TRAN`. |
| `serviceCode` | ObjectId | sí | `COD_SER`. |
| `effect` | enum `connect, move, disconnect, meterChange, reconnect, incident, statusChange, meterRemoval, categoryChange, planChange, prepaidTopUp, equipmentSwap, equipmentRetrieval, inspection, none` | sí | Efecto declarativo. |
| `kind` | enum `service|maintenance|claim|inspection|network` | sí | Clase de OT por defecto. |
| `isClaim` | bool | sí | `TRANSAC_RECLAMO`. |
| `modifiesRegistration` | bool | sí | `MODIFICA_MATRICULA`. |
| `resultingServiceStatusId` | ObjectId → estado de servicio | no | `COD_EST`/`ESTASER`. |
| `addCashierNote` | bool | sí | `AGREGAR_OBSERVACION`. |
| `recordsReading` | bool | sí | `REG_EST`. |
| `memberNotification` | `{ when: never|onCreate|onClose|always, channels[], templateCreate, templateClose }` | sí | `ENVIO_SMS`, `METODO_ENVIO`, `COD_PLA_ALTA`, `COD_PLA_CONFIRM`. |
| `excludeFromWeb` | bool | sí | `EXCLUIR_WEB`. |
| `availableInFieldApp` | bool | sí | `ALTA_PMOVIL`. |
| `requiresFeasibility`, `requiresNetworkPoint`, `requiresDevice`, `requiresSerializedEquipment`, `triggersProvisioning` (`provisioningAction`) | bool / enum | sí | Nuevas exigencias. |
| `twoStepClose` | bool | sí | Ejecutada + Confirmada (PA-TEC-01). |
| `defaultWorkTypeId`, `defaultResolutionIds[]`, `requiredTaskIds[]`, `checklistFormIds[]`, `visitTypeId` | ObjectId | no | — |
| `closeRequirements` | `{ responsible, categories, resolution, peopleCount, adminObservation, certificate: none|warn|require, deviceNumber, vehicle: none|ask|require, participantHours, materials: none|warn }` | sí | Parámetros 342/474/497/2084/174/2421/2470/2505/2354/3201 por operación (override del global). |
| `active` | bool | sí | — |

Índices: `{tenantId, serviceCode, code}` único; `{tenantId, effect}`.

**`workTypes`** (`TPTRAB`): `code`, `name`, `kind` (`service|maintenance`; reemplaza `TIP_ORD` 1/2), `printTemplateId`, `active`.
**`incidentCategories`** (`CAT_INCI`, `CAT_INCI_CTSEC`, `CLAS_INC`): `code`, `name`, `rubric`, `serviceCode`, `defaultOperationTypeId`, `debitAccountId`, `creditAccountId` (M15), `sectionAllocations [{ costCenterId, percent: Decimal128 }]` (suma 100), `classCode` (clase con numerador propio, de `CLAS_INC`), `regulatorCode` (para informes de calidad), `active`.
**`resolutionCodes`** (`RESOL_OT`, `abm_Resestad`): `code`, `name`, `serviceCode?` (nulo = genérica), `operationTypeId?`, `outcome` (`resolved|notResolved|improcedent|referred`), `active`.
**`taskCatalog`** (`TAREAS`, `TAREASOM`): `code`, `name`, `groupId`, `serviceCode?`, `standardMinutes`, `active`. **`taskGroups`** (`GRPTAREA`): `code`, `name`.
**`workOrderPrintTemplates`** (`OT_REPORTE`, V2 #180/#465): `serviceCode`, `operationTypeId`, `templateKey` (plantilla PDF), `includeMap`, `includeWithdrawalSlips`, `includeIncidentReport`, `maxMaterialLines`; índice único `{tenantId, serviceCode, operationTypeId}`.
**`chainedOrderRules`** (`ALTASEAU` con `TIPO_AS=6`, `OT_RELACION`): `name`, `sourceServiceCode`, `sourceOperationTypeId?`, filtros `{ categoryIds, localityIds, referenceIds, readingZones, activityIds, classIds, propertyTypeIds, meterTypeIds }`, `targetServiceCode`, `targetOperationTypeId`, `targetIntakeChannelId`, `confirmOrder` (`sourceFirst|targetFirst`; `CONFIRMAR_ULTIMA`), `active`.
**`intakeChannels`** (compartido con M09, `VIAINGTE`): `code`, `name`, `validateMobile`, `validateEmail`, `isDefault`.

### 7.5 `workOrders` — órdenes de trabajo

Origen: `TECNICA` (+117 columnas), `TECNICA_MOVIL`, `PARTIORD`, `PARTIINC`, `TAROTM`, `TECNOTEXP`/`TECNGREXP`/`TECNSEEXP` (exportaciones → `dispatch`).

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `kind` | enum `service|maintenance|claim|inspection|network` | sí | Reemplaza `TIP_INCI` + `RECLAMO`. |
| `number` | string | sí | Número interno legible (secuencia tenant). |
| `visibleNumber` | `{ year, scope, seq, display }` | no | `COD_SLS` (PRM-TEC-022/082). |
| `documentRef` | `{ typeCode, branch, number }` | no | Talonario OT/OM. |
| `operationTypeId` | ObjectId | sí | `COD_TRAN`. |
| `serviceCode` | ObjectId | sí | `COD_SER`. |
| `contractId` / `accountId` / `personId` | ObjectId | si `service`/`claim` | `ID_SERSOC`/`COD_SUM`/`COD_PER`. |
| `assetRef` | `{ networkElementId?, workId? }` | si `maintenance`/`network` | Obra (`OBRAS`) o activo. |
| `caseId` | ObjectId → M09 | si `claim` | Caso del reclamo. |
| `feasibilityRequestId` | ObjectId | no | `COD_FACTIBIL`. |
| `inspectionCaseId` | ObjectId | si `inspection` | — |
| `origin` | enum `admin, memberRecord, crm, dunning, integration, fieldApp, meterReading, chainedRule, maintenancePlan, outagePlan, bulk` | sí | `OrigenOrden`. |
| `intakeChannelId` | ObjectId | según PRM-TEC-060 | `COD_VIA`. |
| `dunningOrigin` | `{ orderedBy:'mor', orderId, isDelinquent: bool }` | no | `GEST_MORA`, `MOROSO`. |
| `snapshot` | `{ address, servicePoint, meter:{number,digits,lastReading,lastReadingAt}, cadastre, installerCertificate:{number, expiresAt, installerId}, holderPhone, activePhoneLine, serviceObservation }` | sí | Copia al crear (RN-TEC-021). |
| `newData` | `{ address?, meter?{typeId, number}, categoryId?, phoneNumberId?, statusId?, planId? }` | según efecto | `NEW_*`, `N_COD_MED`, `N_TIP_MED`, `N_COD_CAT`, `N_COD_NUM`, `COD_ESTASER`. |
| `description` | `[{ text, at, by }]` | sí | `DES_SOL` acumulativa. |
| `observations` | `{ administrative, technical }` | no | `OBS_ADM`, `OBS_TEC`. |
| `priority` | enum `critical|high|normal|low` | sí | Nuevo (RN-07 §2 sin prioridad). |
| `dueAt` | Date | no | `VENCE` / SLA heredado. |
| `status` | enum (§8.4) | sí | `pending, scheduled, assigned, dispatched, inProgress, onHold, executed, closing, closed, cancelled`. |
| `substatus` | string | no | `SUBESTADO`. |
| `conflictOpen` | bool | sí | Hay `syncConflicts` abierto. |
| `dispatch` | `{ state: none|pendingSend|sent|received|onDevice, lockedBy: none|fieldApp|external, externalSystem?, sentAt, receivedAt }` | sí | `BLOQUEAR`, `EstadoOrdenCaptor`. |
| `assignment` | `{ responsibleId, crewId, participantIds[], peopleCount, vehicleIds[] }` | no | `COD_RES`, `COD_CUA`, `PARTIORD`, `PERSONAS`, `TECNICA_MOVIL`. |
| `visitIds` | ObjectId[] | no | Visitas. |
| `participants` | `[{ fieldResourceId, employeeId?, normalHours: Decimal128, overtimeHours: Decimal128, contracted: bool, hourRate: Decimal128, recordedAt }]` | según PRM-TEC-039 | `PARTIORD` (`HORAS_N`, `HORAS_E`, `CONTRATADA`, `VALOR_HORA`). |
| `tasks` | `[{ taskId, done: bool, notes }]` | no | `TAROTM`. |
| `closing` | `{ executedAt (effective), executedBy, confirmedAt, confirmedBy, incidentCategoryId, resolutionId, workTypeId, hours, peopleCount, technicalObservation, fieldGeo, fieldClosedAt, receiverConformityId, dissatisfactionReason, pendingSteps:[{step, status, error}] }` | al ejecutar/cerrar | `FEC_CONFIR`, `USER_CON`, `COD_CIN`, `ID_RLT`, `COD_TIP`, `HORAS`, `RESP_ENC`, `MOTIVO_DISCONFORME`. |
| `effectsApplied` | `[{ effect, targetModule, commandId, appliedAt, reversedAt? }]` | sí | Para reversión por compensación. |
| `chained` | `{ parentWorkOrderId?, ruleId?, childWorkOrderIds[] }` | no | `OT_RELACION`. |
| `charges` | `[{ ruleRef, moment: before|after, status: proposed|accepted|declined|billed, billingRef }]` | no | Propuestas de M04 (`CONEXION` 5/6). |
| `provisioningCommandIds` | ObjectId[] | no | Comandos emitidos. |
| `installation` | subdocumento §7.6 | si efecto `connect` en servicio con instalación integral | — |
| `extraFields` | objeto tipado por operación | no | `DatosExtraTecnica`, `TECNICA_EXTRAS`. |
| `networkPoint` | `{ networkElementId, position?, phoneBoxPositionId? }` | según PRM-TEC-025 | `INT_RED`, `TEL_POS_REG_CAJA`. |
| `provisional` | bool | no | `PROVI`. |
| `registration` | string | no | `MATRICULA` si cambia. |
| `requestedAt` | Date | sí | `FECHA`/`FEC_OPE`. |
| `recordedAt` | Date | sí | `FEC_REG`. |
| `cancelledAt`, `cancelledBy`, `cancelReason` | — | si `cancelled` | `FECHA_BAJA`, `USUARIO_BAJA`. |
| `reopenHistory` | `[{ at, by, reason, fromStatus }]` | no | Restablecer. |

Índices: `{tenantId, number}` único; `{tenantId, status, serviceCode, operationTypeId}`; `{tenantId, contractId, operationTypeId, status}` (duplicados); `{tenantId, 'assignment.crewId', status}`; `{tenantId, 'assignment.responsibleId', status}`; `{tenantId, caseId}`; `{tenantId, kind, requestedAt}`; `{tenantId, 'snapshot.servicePoint.geo'}` 2dsphere; `{tenantId, dueAt}` parcial `status ∉ {closed, cancelled}`.

### 7.6 Subdocumento `workOrders.installation` — instalación integral

| Campo | Tipo | Descripción |
|---|---|---|
| `stage` | enum `pendingAppointment, appointed, equipmentReserved, equipmentInCustody, enRoute, onSite, installing, testing, testFailed, awaitingConformity, conformityRefused, executed, awaitingProvisioning, awaitingReview, activationConfirmed, failedVisit` | Etapa (§8.5). |
| `reservedEquipment` | `[{ stockItemId (M13), serial, model, reservationId }]` | Reservado. |
| `effectiveEquipment` | `[{ stockItemId, serial, model, applicationMovementId, modality: loan|sale|rent }]` | Aplicado. |
| `substitution` | `{ fromSerial, toSerial, reason, validatedBy, validatedAt }` | Sustitución. |
| `tests` | `[{ testCode, value, unit, passed, at }]` | Pruebas (potencia óptica dBm, velocidad Mbps, señal). |
| `conformityId` | ObjectId → `serviceConformities` | Firma/conformidad. |
| `activation` | `{ milestoneRule, effectiveAt, timezone, confirmedBy, provisioningConfirmedAt, reviewConfirmedAt, eventId }` | Hito. |
| `surveyInvitationRef` | `{ module:'com', id, status }` | Encuesta T09. |

### 7.7 `workOrderMaterials` — materiales y necesidades

Origen: `MOV_PRO` (op. 3, 5, 6, 8) por inferencia, `TECNICA_NECESIDAD`, `RETI_MAT`, `PROD_TRH`.

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `workOrderId` / `workId` | ObjectId | uno | OT u obra. |
| `productId` | ObjectId → M13 | sí | `COD_PRO`. |
| `serial` / `stockItemId` | string / ObjectId | si serializado | `PROD_TRH`. |
| `source` | `{ kind: depot|custody, depotId?, custodianId? }` | sí | `COD_DEP`, `RESPONSA.COD_DPS`. |
| `status` | enum `requested, authorized, reserved, withdrawn, used, returned, cancelled` | sí | §8.6. |
| `quantities` | `{ requested, authorized, withdrawn, used, returned }` Decimal128 | sí | Cuatro cantidades + devolución. |
| `steps` | `[{ step, quantity, userId, at }]` | sí | Usuario y fecha por paso (`USUARIO_SOLICITO`, `USUARIO_AUTORIZO`, `FECHA_AUTORIZO`, `USUARIO_RETIRO`, `USUARIO_UTILIZO`). |
| `withdrawalSlipRef` | `{ id, number }` | no | Vale (`RETI_MAT`). |
| `stockMovementIds` | ObjectId[] → M13 | no | Movimientos generados. |
| `referencePrice` | Decimal128 | no | `PROD_SER.PRE_VSI`. |
| `billable` | bool | sí | PA-TEC-03. |
| `clientMutationId` | string | si campo | Idempotencia. |
| `reviewFlag` | enum `none|notInCustody|periodClosed|other` | sí | Revisión. |

Índices: `{tenantId, workOrderId}`; `{tenantId, workId}`; `{tenantId, status, 'source.custodianId'}`; `{tenantId, clientMutationId}` único parcial.

### 7.8 `fieldEvidence` — evidencias de campo

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `entityType` / `entityId` | string / ObjectId | sí | OT, visita, inspección, elemento de red, factibilidad. |
| `kind` | enum `photo|signature|document|audio|checklist|geoCheckIn` | sí | — |
| `stepCode` | string | no | Paso del checklist. |
| `storageKey` | string | sí | Objeto privado (URL firmada, DEC-001). |
| `sha256` | string | sí | Integridad. |
| `capturedAt` / `recordedAt` | Date | sí | Dispositivo / servidor. |
| `geo` | Point + `accuracyM` | no | GPS. |
| `capturedBy` / `deviceId` | ObjectId | sí | — |
| `clientMutationId` | string | si campo | — |
| `documentId` | ObjectId → T11 | sí | Expediente documental (AGR-023). |
| `supersededBy` | ObjectId | no | Sustitución trazada (nunca silenciosa). |

Índices: `{tenantId, entityType, entityId}`; `{tenantId, clientMutationId}` único parcial.

### 7.9 `serviceConformities` — conformidad y firma

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `workOrderId`, `visitId` | ObjectId | sí | — |
| `detailVersion` / `detailHash` | int / string | sí | Versión del detalle presentado. |
| `detailSnapshot` | objeto (equipos, trabajos, materiales, pruebas) | sí | Lo aceptado. |
| `receiver` | `{ fullName, documentType, documentNumber, relation: holder|authorized|family|tenant|other, authorizationRef? }` | sí | Receptor. |
| `result` | enum `accepted|acceptedWithObservations|refused|absent|notSigned` | sí | Conformidad. |
| `mechanism` | enum `handwrittenOnScreen|otp|digitalSignature|paper` | sí | PA-TEC-07. |
| `signatureEvidenceId` | ObjectId → `fieldEvidence` | si handwritten | — |
| `otpRef` | `{ channel, sentTo, verifiedAt }` | si otp | — |
| `observations` | string | no | — |
| `signedAt` / `recordedAt` | Date | sí | — |
| `installerId` | ObjectId | sí | — |
| `supersedesId` | ObjectId | no | Nueva versión. |

### 7.10 `damageAssessments` — reclamos por daños (`TECNICA_EXTRAS`)

Campos: `workOrderId`, `caseId` (M09), `paymentDate`, `transferCenter`, `bookNumber`, `folioNumber`, `claimedAmount` (Decimal128), `approvedAmount` (Decimal128), `previousDamages` (bool/texto), `accepted` (bool), `regulatorClaim` (`{ regulator: 'OCEBA'|..., number, filedAt }`), `cause`, `damagedAppliances [{ type, brand, model, serial, description }]`, más los 11 campos restantes de `TECNICA_EXTRAS` en `extra` tipado [VERIFICAR nombres en base real], `status` (`open|inReview|approved|rejected|paid`), `settlementRef` (M05/M14).

### 7.11 `technicalProcedures` — expedientes técnicos (`EXPEDIENTES`, `EXPEDIENTES_TRAM`)

Campos: `number`, `installerId` (`COD_PROF`), `address` (calle, número, barrio, localidad, provincia, CP, piso, torre, dpto), `contact`, `serviceCode`, `openedAt`, `status`, `stages [{ previousStageId, submittedAt, at, stage, resolution, observation, attachmentDocId, resolvedAt }]`, `externalUserRef` (`COD_USER_MYSQL` → portal, se migra como referencia de usuario del portal M19).

### 7.12 Agenda

**`visitTypes`**: `code`, `name`, `serviceCodes[]`, `durationMinutes`, `slotTemplate` (franjas, ej. 09–11, 11–13, 14–16, 16–18), `requiredSkills[]`, `requiresCrew` (bool), `requiresVehicle`, `requiresEquipment`, `memberBookable` (bool), `minLeadHours`, `maxHorizonDays`, `failedVisitChargeRuleRef?`, `active`.
**`schedulingZones`**: `code`, `name`, `geometry` (Polygon/MultiPolygon) o `localityIds[]`/`neighborhoodIds[]`, `crewIds[]`, `active`. Índice 2dsphere.
**`resourceCalendars`**: `resourceType` (`crew|fieldResource`), `resourceId`, `weeklyPattern [{ dow, from, to, capacityUnits }]`, `exceptions [{ date, from?, to?, capacityUnits, reason (feriado/ausencia/capacitación) }]`, `zoneIds[]`, `visitTypeIds[]`, `validFrom`, `validTo`.
**`visitBookings`** (reservas de cupo):

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `slotKey` | string | sí | `zoneId|visitTypeId|date|from` (unidad de capacidad). |
| `resourceId` | ObjectId | no | Si se reserva recurso concreto. |
| `capacityUnits` | int | sí | Consumo de capacidad. |
| `status` | enum `held|confirmed|released|expired|cancelled` | sí | §8.2. |
| `holdExpiresAt` | Date | si held | PRM-TEC-133. |
| `ownerRef` | `{ kind: member|operator, userId }` | sí | Quién reserva. |
| `targetRef` | `{ workOrderId?, caseId?, contractId?, feasibilityRequestId? }` | sí | — |
| `idempotencyKey` | string | sí | — |

Índices: `{tenantId, slotKey, status}`; `{tenantId, holdExpiresAt}` TTL lógico (job libera); contador atómico en `slotCounters` (`{tenantId, slotKey}` único, `capacity`, `used`) actualizado con `findOneAndUpdate` condicional `used + units <= capacity`.

**`visits`**:

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `number` | string | sí | VIS-… |
| `workOrderId` | ObjectId | sí | — |
| `bookingId` | ObjectId | sí | — |
| `visitTypeId`, `zoneId` | ObjectId | sí | — |
| `window` | `{ date, from, to, timezone }` | sí | Franja. |
| `assignedCrewId` / `assignedResourceIds[]` | ObjectId | no | — |
| `status` | enum §8.3 | sí | `confirmed, assigned, enRoute, onSite, completed, failed, rescheduled, cancelled`. |
| `timeline` | `[{ status, at (effective), recordedAt, by, deviceId? }]` | sí | Historial. |
| `failure` | `{ reasonCode: noAccess|customerAbsent|missingMaterial|technicalCondition|weather|customerRefused|other, notes, evidenceIds[] }` | si failed | — |
| `rescheduledToVisitId` / `rescheduledFromVisitId` | ObjectId | no | Cadena. |
| `memberVisible` | bool | sí | — |
| `reminders` | `[{ channel, scheduledAt, sentRef }]` | no | — |

Índices: `{tenantId, workOrderId}`; `{tenantId, 'window.date', assignedCrewId}`; `{tenantId, status, 'window.date'}`.

### 7.13 Recursos

**`crews`** (`CUADRI`, `PARTICUA`): `code`, `name`, `leaderId`, `members [{ fieldResourceId, role, validFrom, validTo }]`, `zoneIds[]`, `serviceCodes[]`, `skills[]`, `defaultVehicleId` (M18), `custodyDepotId` (M13), `dailyCapacityUnits`, `active`.
**`fieldResources`** (`RESPONSA`): `code`, `name`, `activity` (`technician|installer|meterReader|collector|inspector|supervisor|other`), `userId` (T02; sin contraseña propia), `email`, `phone`, `custodyDepotId` (`COD_DPS`), `assignToFieldApp` (`ASIGNAOT_PMOVIL`), `serviceCodes[]`, `operationTypeIds[]` (responsables por servicio/operación, `RELACION_ENTIDADES`), `skills[]`, `employeeId?` (M16), `defaultHourRate` (Decimal128), `inactive`.
**`responsibleNotificationRules`** (`RESPONSA_NOTIFICA`): `serviceCode`, `orderKind`, `operationTypeIds[]` (reemplaza `COD_OPER` con `|`), `fieldResourceId`, `daysOfWeek[]` (1–7 ISO), `from`, `to`, `includeHolidays` (bool), `notifyAt` (`onCreate|onDispatch`), `channel` (`whatsapp|email|sms|push`), `templateKey`, `active`.
**`certifiedInstallers`** (`PROFESIO`): `name`, `registrationNumber` (matrícula), `documentNumber`, `serviceCodes[]`, `installerCategory`, `phone`, `email`, `whatsapp`, `address`, `active`; certificados `[{ number, issuedAt, expiresAt, scope }]`.

### 7.14 App de campo y sincronización

**`fieldForms`** (motor de relevamientos CNX §7.8): `code`, `name`, `version`, `questions [{ key, type: text|number|select|multi|photo|signature|geo|date|boolean|meterReading, required, options, validation }]`, `serviceCodes[]`, `operationTypeIds[]`, `geofenceMeters?`, `status` (`draft|published|retired`).
**`fieldDevices`**: `deviceId` (UUID), `userId`, `model`, `os`, `appVersion`, `lastSyncAt`, `status` (`active|revoked`), `revokedAt`, `revokedBy`, `pushToken?`.
**`syncMutations`**:

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `clientMutationId` | string (UUID v7) | sí | Idempotencia. |
| `deviceId`, `userId`, `profile` | — | sí | — |
| `domain` | enum `workOrder|visit|material|evidence|conformity|inspection|reading|collection|networkPoint|servicePoint` | sí | Lecturas y cobros se derivan a M03/M07. |
| `action` | string | sí | `enRoute`, `arrive`, `saveChecklist`, `useMaterial`, `captureSignature`, `execute`, `fail`, etc. |
| `entityId` | ObjectId | no | — |
| `baseVersion` | int | sí | Versión descargada. |
| `payload` | objeto | sí | — |
| `occurredAt` / `recordedAt` | Date | sí | AGR-010. |
| `clockSkewMs` | int | sí | — |
| `result` | enum `applied|duplicate|conflict|rejected|deferred` | sí | Por ítem. |
| `resultDetail` | `{ code, message, conflictId? }` | no | — |

Índice único `{tenantId, clientMutationId}`; `{tenantId, deviceId, recordedAt}`.

**`syncConflicts`**: `workOrderId`/`entityRef`, `mutationIds[]`, `type` (`orderCancelled|orderReassigned|orderModified|equipmentChanged|holderChanged|serviceChanged|duplicateExecution|stockMismatch`), `serverStateSnapshot`, `fieldStateSnapshot`, `evidenceIds[]`, `status` (`open|inReview|resolved|dismissed`), `assigneeId`, `dueAt` (PRM-TEC-139), `resolution` (`acceptField|acceptServer|merge|compensate|newWorkOrder`), `resolutionNotes`, `resolvedBy`, `resolvedAt`, `followUpWorkOrderId?`. Índices: `{tenantId, status, assigneeId}`.

### 7.15 Mantenimiento e interrupciones

**`maintenancePlans`**: `name`, `target` (`{ networkElementId? , componentTypeId?, workId? }`), `operationTypeId`, `frequency` (`weekly|monthly|bimonthly|quarterly|fourMonthly|semiannual|annual|everyNDays`), `everyNDays?`, `marginBeforeDays`, `marginAfterDays`, `nextDueAt`, `lastGeneratedWorkOrderId`, `checklistFormIds[]`, `responsibleId`/`crewId`, `validUntil`, `active`. Índice `{tenantId, active, nextDueAt}`.
**`outagePlans`**: `number`, `networkElementIds[]`, `zoneGeometry?`, `reason`, `plannedStart`, `plannedEnd`, `actualStart`, `actualEnd`, `status` (§8.10), `impactSnapshot` (`{ computedAt, serviceCount, contractIds[] (o ref a export), criticalCount }`), `notificationCampaignRef` (T09), `approvedBy`, `workOrderIds[]`, `regulatorReportRefs[]`.

### 7.16 Red / GIS

Origen v2: `REDES`, `REDES_SERVICIOS`, `REDES_CAPAS`, `REDES_COMPONENTES`, `REDES_RELACIONES_COMPONENTES`, `REDES_ATRIBUTOS_COMPONENTES`, `REDES_ATRIBUTOS`, `REDES_RED_INSTALADA`, `SERSOC_REDES`; v1: `NIV_CAPA`, `NIV_SERV`, `NIV_REDES`, `SERSOC.INT_RED`.

| Colección | Campos |
|---|---|
| `networks` | `code`, `name` (`DES_RED`), `observations` (`OBS_RED`), `networkKind` (`electric|water|gas|sewer|telecom|generic`), `serviceCodes[]` (`REDES_SERVICIOS`), `active`. |
| `networkLayers` | `networkId`, `name` (`DES_CAPA`), `order`, `style`. |
| `networkComponentTypes` | `networkId`, `layerId?` (nulo = común), `name` (`DES_COMPONENTE`), `icon` (`ICON`), `allowsServiceConnection` (`PERMITE_CONECTAR`), `multipleConnections` (`MULTIPLES_CONEXIONES`), `multipleElements` (`MULTIPLES_ELEMENTOS`), `elementsName` (`NOMBRE_ELEMENTOS`), `distributesToChildren` (`DISTRIBUYE_EN_HIJOS`), `geometryType` (`point|line|polygon`), `isCritical` (para impacto). |
| `networkComponentRelations` | `networkId`, `layerId?`, `parentTypeId`, `childTypeId` (`ID_PADRE`, `ID_HIJO`). Único `{tenantId, networkId, layerId, parentTypeId, childTypeId}`. |
| `networkAttributeDefs` | `componentTypeId`, `label` (`DESCRIPCION`), `type` (`text|integer|decimal|date|boolean|list|catalogRef`), `maxLength` (`LARGO`), `decimals` (`DECIMALES`), `catalogRef` (`{ catalog: whitelist, idField, labelField }` ← `TABLA/ID_TABLA/DES_TABLA`), `options[]`, `visible` (`VISIBLE`), `required`. |
| `networkElements` | `networkId`, `layerId`, `componentTypeId`, `parentId` (`ID_PADRE_RED_INSTALADA`), `ancestorIds[]` (materializado para impacto), `code`, `description`, `number`, `rangeStart`/`rangeEnd` (`ELEMENTO_INICIAL/FINAL`), `geometry` (GeoJSON), `address` (`COD_CAL`, número), `status` (`planned|available|used|damaged|notApplicable|retired`; `Estado_NodoRed`), `active` (`ACTIVO`), `attributes` (`{ [attributeDefId]: { value, displayText } }` ← `REDES_ATRIBUTOS`: `VALOR_CARACTER/FECHA/NUMERICO/ID_TABLA`), `equipment` (`{ brand, model, serial, technicalCharacteristics, installedAt, replacedAt }` ← `NIV_REDES.MARCA/MODELO/SERIE/CAR_TEC/FEC_INST/FEC_SUST`), `reference`, `networkDeviceId?`, `documents[]`, `warrantyUntil?`, `legacyRef` (`{ source: 'v1'|'v2', id }`). Índices: `{tenantId, networkId, layerId, parentId}`; `{tenantId, ancestorIds}`; `{tenantId, geometry}` 2dsphere; `{tenantId, code}` único. |
| `serviceNetworkConnections` | `contractId` (`ID_SERSOC`), `networkElementId` (`ID_RED_INSTALADA`), `position?` (borne/par/puerto dentro del rango), `connectedAt` (`FECHA_CONEXION`), `disconnectedAt` (`FECHA_DESCONEXION`), `status` (`connected|disconnected`; 1/2), `observations`, `workOrderId`. Índices: `{tenantId, contractId, status}`; `{tenantId, networkElementId, status}`; único parcial `{tenantId, networkElementId, position}` con `status=connected`. |
| `gisExportTemplates` | `name`, `target` (`externalGis|regulator`), `files [{ fileName, format: fixedWidth|csv|txt, separator, encoding, dateFormat, header, fields [{ source, transform, width, pad }] }]`, `mappings` (`{ energyBands: { peak:[conceptIds], offPeak:[...], rest:[...], valley:[...] }, power:{...}, accountFormat, routeFormat, phaseSource }`), `serviceCode`, `dateMode` (`readingDate|invoiceDate`), `distributorCode` (V2 #2823). |

### 7.17 Equipos de red y aprovisionamiento

| Colección | Campos |
|---|---|
| `networkDevices` | `kind` (`olt|router|bras|nas|switch|accessPoint|phoneExchange|dslam|tvHeadend|other`), `name`, `brand`, `model`, `serial`, `firmware`, `managementIp`, `port`, `networkElementId`, `provisioningSystemId?`, `credentialsRef` (bóveda T06; reemplaza `MIKROTIK.USUARIO/CONTRASEÑA/IP/PUERTO/BMU`), `bmu` (bool, de `MIKROTIK.BMU`), `monitoring` (`{ enabled, lastStatus: up|down|unknown, lastCheckAt }`), `active`. |
| `provisioningSystems` | `type` (`mikrotik|radius|radiusGretix|smartOlt|wispro|sopnet|silexis|ispfull|sensa|sitsa|aion|manual`), `name`, `serviceCodes[]`, `endpoint`, `credentialsRef`, `options` (`{ queryOnly, deleteUserOnDeactivate, disconnectedProfile, timeoutMs, rateLimit }`), `connectorId` (T06), `status` (`active|disabled`), `lastHealthAt`. |
| `provisioningProfiles` | `provisioningSystemId`, `planId` (M02), `externalProfile` (nombre de perfil/queue/plan externo), `downMbps`, `upMbps`, `vlan`, `ipPool`, `onuProfile`, `validFrom`, `validTo`. Único `{tenantId, provisioningSystemId, planId, validFrom}`. |
| `serviceTechnicalProfiles` | `contractId`, `serviceCode`, `technology` (`ftth|wireless|dsl|cable|tv|phone`), `accessUser` (`USER_ID`), `accessSecretRef` (bóveda; `USER_PASS`), `mac` (`MAC_ADR`), `ip` (`IP_ADR`), `ipMode` (`static|dynamic`), `accessPoint` (`AP_CON`), `ldCon` (`LD_CON` [VERIFICAR significado]), `olt`, `slot`, `port`, `vport`, `onuSerial`, `cpeSerial`, `terminal` (`TERMINAL`), `position` (`POSIC`), `partnerData` (V2 #2422), `others` (`OTROS`), `externalIds [{ provisioningSystemId, externalCustomerId, externalContractId }]`, `provisioningStatus` (`notProvisioned|active|suspended|deactivated|error`), `lastCommandId`, `registeredAt`, `registeredBy`. Único `{tenantId, contractId}`. |
| `provisioningCommands` | `commandId` (UUID; idempotencia), `provisioningSystemId`, `contractId`, `action` (`activate|changePlan|suspend|reactivate|deactivate|delete|query|resetCredentials|telemetryCommand`), `payload` (sin secretos en claro), `origin` (`{ module: tec|mor|crm|contract, refId, reason }`), `workOrderId?`, `status` (§8.9), `attempts`, `nextAttemptAt`, `lastError`, `response` (normalizada), `confirmedAt`, `effectiveAt`, `manualTaskRef?`, `compensatesCommandId?`. Índices: `{tenantId, commandId}` único; `{tenantId, status, nextAttemptAt}`; `{tenantId, contractId, createdAt}`. Origen `TELEMED_COMM` (`OPERACION`, `COMANDO`, `RESPUESTA`, `SUMINISTRO`, `OBSERVACION`). |
| `providedMailboxes` | `contractId`, `userId` (`USER_ID`), `domain` (`DOMINIO`), `secretRef` (no se migra `USER_PASS`), `others`, `status`, `registeredAt` (`FEC_REG`), `registeredBy` (`USU_REG`). |

### 7.18 Obras y contribución por mejoras

| Colección | Campos |
|---|---|
| `works` | `code`, `name` (`DES_OBR`), `serviceCode` (`COD_SER`), `type` (`COD_TIP`), `groupId` (`COD_GRP`), `startAt` (`FEC_INI`), `endAt` (`FEC_FIN`), `hidden` (`OCULTAR`), `budget` (`{ total: Decimal128, lines[] }`), `progress` (`{ percent, milestones[{ name, plannedAt, doneAt }] }`), `costCenterId`, `approvalBasis` (`{ kind: ordinance|agreement|assembly, reference, documentId, approvedAt }`), `levy` (`{ enabled, criterion: frontMeters|surface|equalShares|units|custom, amountToDistribute: Decimal128, rounding, installments, financingPlanRef, status }`), `status` (§8.11). |
| `workGroups` | `code`, `name` (`DES_GRP`), `debitAccountId`, `creditAccountId` (`COD_CTA`, `COD_CTH`), `sectionAllocations [{ costCenterId, percent }]`. |
| `workBeneficiaries` | `workId`, `propertyId` (M01), `accountId`, `holderPersonId`, `frontMeters` (Decimal128), `surfaceM2`, `units`, `share` (Decimal128 calculado), `amount` (Decimal128), `exempt` (bool + motivo), `billingRef`. Índice `{tenantId, workId, propertyId}` único. |

### 7.19 Inspecciones

| Colección | Campos |
|---|---|
| `inspectionCases` | `number`, `contractId`, `serviceCode`, `origin` (`consumptionAlert|complaint|meterReader|controlPlan|other`), `alertRef` (M03), `status` (§8.12), `workOrderIds[]`, `act` (`{ formResponseId, findings[], irregularityType, witnesses[{name, document}], signedByUser: bool, refusalNote, evidenceIds[], actHash, actAt }`), `sealIds[]`, `notification` (`{ sentAt, channel, deliveryRef, defenseDeadline }`), `defense` (`{ receivedAt, text, documentIds[] }`), `recoveryProposal` (`{ methodVersionRef (M04), periodFrom, periodTo, estimatedConsumption, amount: Decimal128, computedAt }`), `approval` (`{ approvedBy, approvedAt, resolutionDocId }`), `billingRef` (M05), `closedAt`, `outcome`. |
| `seals` | `number` (único), `batch`, `status` (`available|assigned|placed|removed|broken|voided`), `assignedTo` (inspector), `placement` (`{ meterId, contractId, at, workOrderId, evidenceId }`), `removal` (`{ at, reason, workOrderId }`). |

### 7.20 Telefonía (red, numeración, líneas, CDR)

| Colección | Campos (origen) |
|---|---|
| `phoneExchanges` | `code`, `name` (`DES_CEN`/`NOM_CEN`), `cdrModality` (`MODALIDAD`, enum de ≈35 formatos), `importSeconds` (`IMP_SEGUNDOS`), `importKey` (`IMP_CLAVE`), `lastDisk` (`ULTIMO_DISCO`/`ULT_DSK`), `geo` (`GPS_LATITUD/LONGITUD`), `prefixId` (`COD_PRE`), `currency` (`COD_MON`), `externalId` (`ID_TEL`), `networkDeviceId`, `onlineSource?` (Gretix, Tecnored Sunsip, AION, Central Online), `readerOptions` (`{ excludedNumbers[] (V2 #2444), zeroAmountForKey99 (V2 #2346) }`). Unifica `TEL_CENTRAL` y `CENTRALT`. |
| `phonePorts` | `ownerType` (`exchange|dslam`), `ownerId`, `number`/`name` (`NUMERO`, `DES_PTO_DSLAM`), `linkedDslamPortId` (`COD_PTO_DSLAM`), `outgoingConnected` (`CON_SAL`), `incomingConnected` (`CON_ENT`), `status` (`available|unavailable|inactive`; `INACTIVO`). |
| `phoneFrames` | `name` (`DES_REP`), `exchangeId` (`COD_CEN`), `geo`. |
| `phoneFrameGroups` | `frameId`, `name` (`DES_GRU`), `direction` (`TIPO`: entrada/salida). |
| `phoneStrips` | `ownerType` (`frameGroup|box`), `ownerId`, `name` (`DES_REG`). |
| `phoneStripPositions` | `stripId`, `ownerType`, `name` (`DES_POS`), `number`, `terminal` (`TER`), `trm` (`TRM`), `color`, `previousPositionId` (`COD_POS_ANT`), `dslamPortId`, `exchangePortId`, `groupPositionId` (`COD_POS_REG_GRU`), `outgoingConnected`, `incomingConnected`, `status`, `contractId?` (servicio conectado). |
| `phoneBoxes` | `name` (`DES_CAJA`), `frameId` (`COD_REP`), `address`, `geo`. |
| `dslams` | `name` (`DES_DESLAM`), `brand`, `model`, `serial`, `observations`, `networkDeviceId`. |
| `phonePrefixes` | `code`, `name` (`DES_PRE`). |
| `phoneNumbers` | `prefixId`, `number`, `status` (`available|reserved|assigned|quarantine|retired`; `ESTADO`), `createdOn` (`FEC_ALTA`), `reservedByWorkOrderId?`. Único `{tenantId, prefixId, number}`. |
| `phoneLines` | `contractId` (`ID_SERSOC`), `phoneNumberId?` (`COD_NUM`), `tariffPlanId` (M04, `COD_TAR`), `validFrom` (`FEC_ALTA`), `validTo` (`FEC_BAJA`), `observation`, `workOrderId?`. Índice `{tenantId, phoneNumberId, validFrom, validTo}`. |
| `numberingPlan` | `fullNumber` (`NUMERO`), `description` (`DES_CAR`), `provinceId` (`COD_PRV`), `locality`, `indicative`, `block`, `operatorId` (`COD_OPE`), `serviceTypeId` (`COD_SERV`), `modalityId` (`COD_MOD`), `tariffKey` (`CLAVE`, M04), `isLocal` (`LOCAL`), `source` (`{ file, importedAt }`). Índice `{tenantId, fullNumber}` y búsqueda por prefijo más largo (prefijos expandidos `prefixes[]`). |
| `telecomOperators` | `name` (`DES_OPE`), `accountId?` (`COD_SUM`, para liquidar CPP), `generic` (`GENERICO`). |
| `telecomServiceTypes` / `telecomModalities` | `name` (`DES_SERV`) / `name` (`DES_MOD`), `isMobile` (`MOVIL`). |
| `cdrImports` | `exchangeId?`, `operatorId?`, `kind` (`outgoing|incoming|international|cpp|rejected|mobileInvoice`), `fileName`, `fileHash`, `lot` (`LOTE`), `status` (§8.14), `rows` (`{ total, imported, duplicates, errors, unattributed }`), `errors [{ row, message }]`, `ratingRequestedAt`, `rolledBackAt`. Índice único `{tenantId, fileHash}`. |
| `callRecords` | `cdrImportId`, `direction` (`outgoing|incoming`), `kind` (`regular|international|cpp|rejected`), `origin` (`NRO_ORI`/`ORIGEN`), `destination` (`NRO_DES`/`DESTINO`), `destinationDescription` (`DES_DES`), `startedAt` (`FECHA`/`FEC_LLA`), `seconds` (`SEGUNDOS`/`SEC_LLA`), `roundedSeconds` (`SEC_CPP`), `trunk` (`TRONCAL`), `ncnt`/`ndisk` (`NCNT`, `NDISK`), `sourceKey` (`IMP_CLAVE`), `sourceAmount` (Decimal128; `IMP_CPP` o importe del CDR), `operatorId` (`COD_OPE`), `operatorLot` (`LOT_OPE`), `attributedLineId` (`COD_TSE`), `attributedContractId`, `attributionStatus` (`attributed|originNotFound|duplicate|manual|destinationNotFound`), `dedupeKey` (origen+destino+fecha+segundos), `ratingRef` (M04 `callRatings` id), `grouped` (bool; `GRUPO≠0`), `rejected` (`{ publicNumber, subscriber, calledNo, calledYa, amount, cppDuration, realDuration, previousCall, previousCallNo, at }` ← `RECHAZOS`). Índices: `{tenantId, dedupeKey}` único; `{tenantId, attributedContractId, startedAt}`; `{tenantId, attributionStatus}`. |
| `mobileUsageImports` | `provider` (`claro|personal`), `period`, `fileName`, `lines [{ lineNumber, contractId?, concepts[{ type, quantity, amount }] }]`, `status`. |

### 7.21 Colecciones referenciadas (no propias)

`serviceContracts` (dueño según T05), `persons`/`accounts`/`properties` (M01), `services`/`plans` (M02), `meters` (M03), `tariffPlans`, `chargeRules`, `callRatings` (M04), `stockItems`, `depots`, `stockMovements`, `custodies` (M13), `quotes` (M11), `vehicles` (M18), `surveys` (T09), `documents` (T11), `streets`/`localities`/`holidays`/`sequences` (T04), `cases` (M09).

## 8. Estados y transiciones

Regla general (AGR-003): toda transición tiene actor, precondición, efectos y reversión; no existe edición libre de estados. El estado del trámite (OT, visita) es distinto del estado real del contrato, del equipo y del pago.

### 8.1 Factibilidad (`feasibilityRequests.status`)

| Origen → Destino | Actor | Precondición | Efectos | Reversión |
|---|---|---|---|---|
| — → `draft` | Operador, socio (portal), CRM | — | Número reservado | Descartar borrador |
| `draft` → `pending` | Operador | Datos mínimos (servicio, persona, domicilio) | Evento `tec.feasibility.requested`; aviso al socio | — |
| `pending` → `inEvaluation` | Supervisor/evaluador | — | Propuesta de recurso (RF-TEC-007); opcional OT de inspección | Volver a `pending` |
| `inEvaluation` → `closed` (verdict) | Supervisor | Motivo, responsable técnico, estado técnico | `tec.feasibility.verdictIssued`; `validUntil` si factible | Reabrir con permiso (PRM-TEC-064) creando versión |
| `pending`/`inEvaluation`/`closed` → `cancelled` | Supervisor | Motivo; no usada | `tec.feasibility.cancelled`; nunca usable | No reversible (nueva factibilidad) |
| `closed (feasible)` → `used` | Sistema (alta de contrato) | Vigente, no usada | Vincula contrato | Si el contrato se anula antes de instalar, vuelve a `closed` |
| `closed (feasible)` → `expired` | Job | `validUntil` < hoy | — | Renovar con nueva evaluación |

Estado de presupuesto (`estimate.status`) en paralelo: `draft → submitted → accepted|rejected|expired` (equivale a "Facturado" de ProCoop cuando se acepta y factura).

### 8.2 Reserva de cupo (`visitBookings.status`)

| Origen → Destino | Actor | Precondición | Efectos | Reversión |
|---|---|---|---|---|
| — → `held` | Socio/operador | Capacidad disponible (contador atómico) | Reduce capacidad; `holdExpiresAt` | — |
| `held` → `confirmed` | Socio/operador | No expirada | Crea `visit` `confirmed`; constancia al socio | Cancelar |
| `held` → `expired` | Job `tec:liberar-reservas` | `holdExpiresAt` vencido | Libera capacidad | — |
| `held` → `released` | Socio/operador | — | Libera capacidad | — |
| `confirmed` → `cancelled` | Socio (con anticipación) / operador | Reglas PRM-TEC-136 | Libera capacidad; visita `cancelled` | — |

### 8.3 Visita (`visits.status`)

| Origen → Destino | Actor | Precondición | Efectos | Reversión |
|---|---|---|---|---|
| — → `confirmed` | Sistema | Reserva confirmada | Aviso + recordatorio | — |
| `confirmed` → `assigned` | Despachante/supervisor | Recurso con capacidad | OT `assigned`; publica en "Mi día" | Reasignar |
| `assigned` → `enRoute` | Técnico | — | Aviso "En camino" al socio (sin GPS) | Volver a `assigned` (error del técnico) |
| `enRoute` → `onSite` | Técnico | — | Marca llegada | — |
| `onSite` → `completed` | Técnico | Trabajo de la visita registrado | OT → `executed` si era la última visita necesaria | Solo vía conflicto/supervisor |
| `assigned`/`enRoute`/`onSite` → `failed` | Técnico | Motivo y evidencia | No activa; equipo sin aplicar; propuesta de nueva visita; cargo solo si regla (PA-TEC-06) | — |
| `confirmed`/`assigned` → `rescheduled` | Socio/operador | Nueva reserva confirmada | Libera cupo anterior; enlaza nueva visita | — |
| cualquiera no final → `cancelled` | Operador/socio | Motivo | Libera cupo; no cancela la contratación | — |

### 8.4 OT (`workOrders.status`)

| Origen → Destino | Actor | Precondición | Efectos | Reversión |
|---|---|---|---|---|
| — → `pending` | Admin, CRM, mora, campo, regla, plan | Validaciones RF-TEC-027/028 | Número; nota en cuenta; órdenes encadenadas; cargos "antes" propuestos; notificaciones (RN-TEC-050/051); `tec.workOrder.created` | Anular |
| `pending` → `scheduled` | Despachante/socio | Visita confirmada | — | Cancelar visita → `pending` |
| `pending`/`scheduled` → `assigned` | Despachante | Recurso/cuadrilla | — | Desasignar |
| `assigned` → `dispatched` | Sistema / impresión (RN-TEC-011) / envío automático (PRM-TEC-079) | — | `dispatch.state=sent`; bloqueo campo | Recuperar (desbloquear con capability) |
| `dispatched` → `inProgress` | Técnico (llegada/inicio) | — | — | — |
| `inProgress` → `onHold` | Técnico/supervisor | Motivo (falta material, permiso, acceso) | Subestado | `onHold` → `inProgress`/`scheduled` |
| `inProgress` → `executed` | Técnico (campo) o administrativo | Requisitos de cierre de campo | Evidencia, materiales usados, conformidad; si `twoStepClose=false` pasa directo a `closing` | Supervisor puede devolver a `inProgress` con motivo |
| `executed` → `closing` | Supervisor (confirmar) / automático | Requisitos de confirmación (RF-TEC-036); sin conflicto abierto | Aplica efectos (RF-TEC-038) con outbox, paso a paso | — |
| `closing` → `closed` | Sistema | Todos los pasos `done` | `tec.workOrder.closed`; cargos "luego"; numeración visible si corresponde | Reabrir (RF-TEC-045) con compensación |
| `closing` → `closing` (paso fallido) | Sistema | Error en un efecto | Registra `pendingSteps`; reintento; bandeja operativa (AGR-016) | Reparación |
| `pending`…`executed` → `cancelled` | Supervisor | Motivo; si hay evidencia de ejecución en campo, se exige resolver conflicto | Reversión por compensación (RN-TEC-036); materiales devueltos | Restablecer → `pending` |
| `closed` → `pending` (reabrir) | Supervisor con capability | Motivo | Compensa efectos; historial | — |

### 8.5 Instalación (`workOrders.installation.stage`)

`pendingAppointment → appointed` (visita confirmada) `→ equipmentReserved` (M13 reserva) `→ equipmentInCustody` (entrega al instalador) `→ enRoute → onSite → installing → testing → (testFailed → installing | failedVisit) → awaitingConformity → (conformityRefused → decisión supervisor: reintentar, cerrar como fallida, activar con disconformidad registrada) → executed → awaitingProvisioning` (si `triggersProvisioning`) `→ awaitingReview` (si revisión supervisora) `→ activationConfirmed`.
`failedVisit`: equipo permanece en custodia o se devuelve; nueva cita → `appointed`. Reversión de `activationConfirmed`: solo por OT de desactivación/retiro o anulación con compensación coordinada con el contrato (no edición).

### 8.6 Material (`workOrderMaterials.status`)

`requested → authorized` (supervisor; cantidad autorizada ≤ solicitada) `→ reserved` (M13) `→ withdrawn` (vale/entrega a custodia) `→ used` (aplicación en sitio; descuenta de custodia) `→ returned` (devolución parcial/total del no usado). `requested|authorized|reserved → cancelled` libera reserva. `used` solo se corrige por ajuste compensatorio (RF-TEC-069).

### 8.7 Mutación de sincronización (`syncMutations.result`)

`received → applied` | `duplicate` (mismo `clientMutationId`, devuelve resultado original) | `conflict` (versión base desactualizada con impacto; crea `syncConflicts`) | `rejected` (permiso, validación dura) | `deferred` (dependencia aún no recibida en el lote; se reintenta en el mismo lote).

### 8.8 Conflicto (`syncConflicts.status`)

`open → inReview` (asignado al supervisor) `→ resolved` con resolución `acceptField` (aplicar efectos de campo), `acceptServer` (conservar evidencia, no aplicar efectos; si hubo instalación real se genera OT de regularización), `merge`, `compensate` (revertir movimientos de stock ya aplicados), `newWorkOrder`; o `dismissed` (sin impacto). Vencido `dueAt` escala (RN-TEC-068). Nunca se borra la evidencia (ESC-03).

### 8.9 Comando de aprovisionamiento (`provisioningCommands.status`)

| Origen → Destino | Actor | Efectos |
|---|---|---|
| — → `queued` | TEC (desde OT, M08, M09) | Outbox |
| `queued` → `sending` | Worker | Llamada al conector T06 |
| `sending` → `confirmed` | Worker | Respuesta OK verificada (o consulta posterior); `tec.provisioning.confirmed` |
| `sending` → `retrying` | Worker | Error transitorio; `nextAttemptAt` con backoff (PRM-TEC-142) |
| `retrying` → `sending` | Worker | — |
| `sending|retrying` → `failed` | Worker | Agotados reintentos o error definitivo; `tec.provisioning.failed` |
| `failed` → `manualPending` | Sistema | Tarea NOC |
| `manualPending` → `manualDone` | Operador NOC | Evidencia de ejecución manual; equivale a confirmado |
| `queued|retrying` → `cancelled` | Sistema/NOC | Orden origen revocada (p. ej., pagó antes del corte) |
| `confirmed` → `compensated` | Sistema | Comando inverso confirmado (rollback) |
| `sending` (resultado incierto) → `unknown` → `confirmed|failed` | Worker con `query` | No se reenvía sin conciliar (ESC-04) |

### 8.10 Interrupción planificada (`outagePlans.status`)

`draft → approved` (responsable) `→ notified` (aviso masivo con constancia) `→ inProgress` (inicio real) `→ completed` (fin real, informe); `draft|approved|notified → cancelled` (aviso de cancelación si ya notificada).

### 8.11 Obra (`works.status`)

`draft → budgeted → approved` (base de aprobación cargada) `→ inProgress → finished`; con contribución: `finished|inProgress → levyProposed → levyApproved → billing` (M05/M08) `→ closed`; `draft|budgeted → cancelled`.

### 8.12 Caso de inspección (`inspectionCases.status`)

`suspected → inspectionOrdered` (OT) `→ inspected → (noIrregularity → closed) | irregularityConfirmed → userNotified → (defenseReceived | defenseExpired) → recoveryProposed → (recoveryApproved → billed → regularized → closed) | recoveryRejected → closed`; cualquier estado → `annulled` con motivo y aprobación.

### 8.13 Elemento de red y conexión

Elemento: `planned → available ↔ used` (por conexiones) `→ damaged → available` (reparación) `→ retired` (sin conexiones vigentes ni hijos activos). Conexión servicio-red: `connected → disconnected` (fecha de desconexión); reconexión crea nueva conexión (historial).

### 8.14 Número, línea e importación de CDR

Número: `available → reserved` (OT) `→ assigned` (línea) `→ quarantine` (tras baja, plazo configurable) `→ available`; `available → retired`. Línea: `active → closed`. Importación: `uploaded → parsing → parsed | withErrors` (archivo abortado con fila) `→ attributed → sentToRating → rated → grouped` (por M05) ; `parsed|attributed|rated → rolledBack` solo si ninguna llamada agrupada.

## 9. Procesos y flujos

### 9.1 Alta de Internet de punta a punta (piloto DEC-005, CU-AUT-01, CU-INS-01)

1. M09 recibe la solicitud (landing/app) y valida requisitos; si el servicio exige factibilidad (PRM-TEC-024), emite `crm.case.feasibilityRequested`.
2. TEC crea `feasibilityRequests` con el punto de prestación (BASE §77); propone recurso (OLT/puerto/splitter libre en la red) y, si hace falta, agenda inspección.
3. El evaluador dictamina; si requiere obra o materiales extraordinarios, prepara `connectionEstimates` y M11 emite presupuesto; al aceptarse, la factibilidad queda apta.
4. El contrato se crea en el módulo dueño (pendiente de conectar) con `feasibilityRequestId`; M09 solicita OT de alta (`connect`).
5. TEC crea la OT con instalación integral (`pendingAppointment`), materiales previstos desde la estimación y reglas encadenadas.
6. El socio elige franja en la app: reserva temporal → confirmada (RF-TEC-076); OT `scheduled`.
7. El despachante asigna cuadrilla; TEC solicita a M13 reservar ONT/módem serializado y transferirlo a custodia del instalador (vale) — `equipmentInCustody`.
8. El técnico descarga "Mi día"; el día de la visita informa **En camino** (aviso al socio), llega, verifica equipo (escaneo), instala, prueba, registra materiales usados desde su custodia y fotos.
9. Presenta el detalle de instalación (versión + hash), captura conformidad/firma del receptor identificado.
10. Al sincronizar: mutaciones aplicadas idempotentemente; M13 aplica el equipo (custodia → domicilio/contrato, modalidad comodato); OT `executed`.
11. TEC emite `provisioningCommands.activate` con perfil del plan; al confirmarse, `installation.stage=activationConfirmed` (o `awaitingReview` si hay revisión).
12. TEC publica `tec.installation.activationConfirmed { contractId, effectiveAt, workOrderId }`; el contrato se activa desde `effectiveAt`; M05 genera cargo de instalación y primer abono (prorrateo y modalidad según reglas; ejemplo §73 se valida en M05).
13. TEC solicita a T09 la invitación de encuesta; respuesta ≤ umbral crea caso en M09 (PA-TEC-08). La encuesta no afecta la activación.
14. Excepciones: visita fallida (8.3) → nueva cita, equipo sigue en custodia; prueba fallida → `testFailed`; disconformidad → decisión supervisor; aprovisionamiento fallido → `manualPending` y activación diferida; conflicto offline → §9.4.

### 9.2 OT genérica de trabajo (creación → cierre)

1. Validaciones por operación y duplicados → creación con instantánea, numeración y nota en cuenta.
2. Reglas encadenadas (`chainedOrderRules`) → OT hijas idempotentes por `(parentId, ruleId)`.
3. Propuesta de cargos "antes" (M04) mostrada al operador; aceptación genera cargo (M05) o cobro en mostrador (M07).
4. Notificaciones a responsables según reglas y al socio según operación.
5. Asignación/visita/despacho → ejecución (campo o administrativa) → confirmación.
6. Confirmación: validar requisitos (PRM globales + `closeRequirements` de la operación), pagos pendientes (PRM-TEC-075), cadena (orden origen/destino), conflicto abierto.
7. Aplicación de efectos por pasos (servicio de cada módulo dueño) dentro de transacción + outbox; si un paso externo (aprovisionamiento/telemedición) es asíncrono, la OT queda `closing` hasta confirmar o pasar a manual.
8. Cierre: numeración visible (si se asigna al cerrar), cargos "luego", proporcionales (evento a M04/M05), lectura (M03), notificación de cierre, evento `tec.workOrder.closed`.

### 9.3 Cierre masivo (JOB-TEC-03)

Selección por filtros → excluye bloqueadas por campo/sistema externo y con conflicto → aplica datos comunes → por cada OT ejecuta 9.2 paso 6–8 de forma independiente (resultado por ítem, idempotente por `(batchId, workOrderId)`) → informe imprimible y notificación opcional → reanudable.

### 9.4 Sincronización offline y conflictos (AGR-025, ESC-03)

1. Descarga: `GET /api/field/my-day` devuelve paquetes con `serverVersion` por entidad y la lista de custodia del técnico.
2. Offline: cada acción genera una mutación en la cola única IndexedDB (`clientMutationId`, `baseVersion`, `occurredAt`); fotos/firmas como blobs en IndexedDB.
3. Al volver la red: `POST /api/field/sync` por lotes (PRM-TEC-145) con evidencias subidas previamente por URL firmada.
4. Servidor por ítem: si `clientMutationId` existe → `duplicate` con resultado original; si permiso inválido → `rejected`; si `baseVersion` = actual o el cambio no afecta campos sensibles → `applied`; si la OT fue cancelada/reasignada/modificada o el equipo/titular cambió → **guardar evidencias y materiales como "hechos de campo"**, crear `syncConflicts`, marcar `workOrders.conflictOpen=true` y responder `conflict`.
5. Desvío de reloj > PRM-TEC-140 → aplica pero marca revisión.
6. El supervisor resuelve (8.8). Ejemplo ESC-03: OT cancelada en admin mientras el técnico instaló offline con firma y equipo: se conserva evidencia, M13 registra que el equipo salió de custodia (hecho físico), y el supervisor decide `acceptField` (reabrir y activar con fecha real) o `acceptServer` (crear OT de retiro y devolver equipo). No hay doble salida de equipo ni borrado.
7. El dispositivo recibe el resultado por ítem y actualiza estado local; banner único con pendientes y "Reintentar".

### 9.5 Corte y reconexión por mora (O6)

1. M08 emite `mor.suspension.ordered { contractId, orderId, mode }`.
2. TEC decide modo por servicio: remoto (comando `suspend`) o en terreno (OT `disconnect` con `dunningOrigin`, `isDelinquent=true`), o directo sin técnica (RF-TEC-049).
3. Remoto: comando idempotente por `orderId`; confirmado → `tec.disconnection.executed`; fallido → OT en terreno o manual.
4. En terreno: se agenda/asigna; si el socio paga antes de ejecutar, M08 emite `mor.suspension.revoked` → TEC cancela OT/comando pendiente (`cancelled`) e informa.
5. Reconexión: `mor.reconnection.ordered` → comando `reactivate` o OT `reconnect` (cierre y reconexión en un paso si remoto confirmado); sin sistema remoto, OT pendiente para cuadrilla (RN-TEC-072). Proporcionales por evento a M04/M05.

### 9.6 Interrupción planificada y análisis de impacto (O7)

1. El responsable selecciona elementos (p. ej., transformador TR-DEMO-01) → `GET impact` recorre descendientes (`ancestorIds`) y conexiones vigentes → lista de contratos, críticos (electrodependientes) y conteos.
2. Crea `outagePlans` con ventana y motivo → aprobación → T09 envía aviso masivo (constancia por destinatario) → OT de mantenimiento asociadas.
3. Inicio/fin reales registrados → informe de interrupción para regulador (T10) → avisos de restablecimiento.

### 9.7 Mantenimiento preventivo (JOB-TEC-05)

Diario: para cada plan activo con `nextDueAt − marginBeforeDays ≤ hoy` y `nextDueAt ≤ validUntil`, crear OT `maintenance` (idempotente por `(planId, nextDueAt)`), recalcular `nextDueAt` por frecuencia. Avería detectada durante el preventivo → OT correctiva vinculada sin cerrar el preventivo.

### 9.8 Importación de CDR (O10)

1. Subida de archivo o descarga online (Gretix, Tecnored Sunsip, AION, Central Online) por central/fechas → `cdrImports` (`uploaded`), rechazo por `fileHash` repetido.
2. JOB-TEC-09 parsea con el lector de la modalidad; error de fila aborta con número de fila (`withErrors`).
3. Normaliza (origen con "0"), aplica opciones de lector (exclusiones, clave 99), deduplica por `dedupeKey` (PRM-TEC-108).
4. Atribuye origen (línea vigente a la fecha) y destino de entrantes; marca no atribuidas para asignación manual.
5. Envía a M04 (`tec.cdr.attributed`) para tasación; recibe `tar.call.rated`.
6. M05 agrupa en consumos al facturar; desde entonces el lote no se revierte.

### 9.9 Aprovisionamiento: reintentos y recuperación (AGR-016, ESC-04)

Worker `tec:aprovisionar` toma comandos `queued|retrying` por `nextAttemptAt`, aplica rate limit por sistema, envía con `commandId` como clave de idempotencia cuando el sistema la soporta; ante timeout consulta estado (`query`) antes de reenviar; tras restauración de backup, JOB-TEC-11 concilia comandos `sending/unknown` con el estado real del sistema externo antes de reanudar.

### 9.10 Contribución por mejoras (O7)

Obra aprobada con base legal → importación del padrón (ExcelImportWizard) → elección de criterio → simulación (`share = medida / Σ medidas`, importe con redondeo explícito y ajuste de centavos al último beneficiario) → aprobación → envío a M05/M08 (cuotas o plan) → seguimiento de cobro por beneficiario.

### 9.11 Inspección y recupero (O7)

Alerta M03 o denuncia → caso `suspected` → OT de inspección (acta, fotos, precintos) → irregularidad confirmada → notificación con plazo (PRM-TEC-143) → descargo → propuesta de recupero (M04, método versionado) → aprobación del comité → M05 emite documento separado → regularización (OT de normalización/precinto) → cierre.

### 9.12 Jobs

| Job | Nombre | Frecuencia | Descripción | Idempotencia / recuperación |
|---|---|---|---|---|
| JOB-TEC-01 | `tec:liberar-reservas` | cada minuto | Expira reservas `held` vencidas y devuelve capacidad. | Condicional por estado. |
| JOB-TEC-02 | `tec:generar-ot-masivas` | a demanda | Generación masiva por filtros. | `(batchId, contractId, operationTypeId)`. |
| JOB-TEC-03 | `tec:cerrar-ot-masivas` | a demanda | Cierre/confirmación masiva. | `(batchId, workOrderId)`; reanudable. |
| JOB-TEC-04 | `tec:reparar-efectos` | cada 5 min | Reintenta `pendingSteps` de OT en `closing`; tras N fallos, bandeja operativa. | Paso con id. |
| JOB-TEC-05 | `tec:generar-mantenimiento` | diario 02:00 TZ tenant | Planes preventivos. | `(planId, dueAt)`. |
| JOB-TEC-06 | `tec:aprovisionar` | continuo (cola BullMQ) | Ejecuta comandos de aprovisionamiento. | `commandId`. |
| JOB-TEC-07 | `tec:monitorear-equipos` | cada 5 min | Estado de equipos de red; caída → propuesta de incidente de zona. | Por `deviceId` y ventana. |
| JOB-TEC-08 | `tec:recordatorios-visitas` | cada 15 min | Recordatorios previos a la visita. | `(visitId, reminderKind)`. |
| JOB-TEC-09 | `tec:importar-cdr` | a demanda / programado para fuentes online | Parseo, deduplicación y atribución de CDR. | `fileHash`, `dedupeKey`. |
| JOB-TEC-10 | `tec:geocodificar-pendientes` | cada hora | Enriquecer puntos pendientes respetando cuotas. | Por domicilio. |
| JOB-TEC-11 | `tec:conciliar-aprovisionamiento` | diario + tras restauración | Concilia estado local vs sistemas externos. | Sin reenvíos ciegos. |
| JOB-TEC-12 | `tec:escalar-conflictos` | cada hora | Escala conflictos vencidos. | Por conflicto. |
| JOB-TEC-13 | `tec:exportar-gis` | a demanda / programado | Ejecuta plantillas de exportación GIS/regulatorias. | `(templateId, period)`. |
| JOB-TEC-14 | `tec:vencer-factibilidades` | diario | Marca `expired`. | Condicional. |
| JOB-TEC-15 | `tec:impacto-interrupcion` | a demanda | Cálculo de impacto para planes grandes. | `(outagePlanId, version)`. |
| JOB-TEC-16 | `tec:alertas-ot-vencidas` | cada 30 min | Alertas de OT por vencer/vencidas. | `(workOrderId, level)`. |

## 10. Pantallas

Patrón común (CNX §4): `AdminShell` + `AdminStickyHeader` (título `dict:`, acciones primarias, ayuda `ScreenHelp`), `DataTable` con filtros persistentes, paginación servidor, selección múltiple y exportación; modales `sm/md/lg/xl`; importación con `ExcelImportWizard` (plantilla, validación por fila, previsualización, confirmación). La PWA de campo es **una sola** app con landing por rol (AGR-025). Todas las acciones están condicionadas por capability; los botones no permitidos no se muestran.

### 10.1 Administración (web)

| ID | Pantalla | Ruta | Propósito / componentes | Capabilities | Formularios ProCoop reemplazados | Ola |
|---|---|---|---|---|---|---|
| PAN-TEC-01 | Bandeja de factibilidades | `/admin/tec/feasibility` | DataTable por estado, servicio, zona, vigencia; buscador por persona/domicilio/número; acciones evaluar/anular. | `tec.feasibility.read` | `frm_Factibilidad` (lista), `frmBuscadorFactibilidad` | O3 |
| PAN-TEC-02 | Ficha de factibilidad | `/admin/tec/feasibility/:id` | Datos, punto en mapa, recurso propuesto, dictamen, notas, historial de cambios, vínculo a contrato/estimación. | `tec.feasibility.evaluate` | `frm_Factibilidad`, `abm_Factibil_Notas`, `frm_CambiosFactibilidad` | O3 |
| PAN-TEC-03 | Estimación técnica | `/admin/tec/estimates/:id` | Ítems de mano de obra/material/obra desde plantilla, totales, envío a M11 para presupuesto. | `tec.estimate.manage` | (cálculo de presupuesto de factibilidad) | O3 |
| PAN-TEC-04 | Tablero de OT | `/admin/tec/work-orders` | DataTable con filtros (estado, operación, tipo de trabajo, zona, cuadrilla, fechas, vencimiento, morosidad, conflicto); vistas guardadas; KPI en encabezado; impresión de selección. | `tec.workOrder.read` | `frmInformes_Preview` (consulta) | O3 |
| PAN-TEC-05 | Ficha de OT | `/admin/tec/work-orders/:id` | Pestañas: datos, tareas, materiales, visitas, evidencias, conformidad, notas, datos extra, efectos (pasos), auditoría; acciones según estado (8.4). | `tec.workOrder.read/update/close` | `abm_Tecnica`, `abm_Tecnica_Notas`, `abm_Tecnica_Partiord`, `abm_Tecnica_Tareas` | O3 |
| PAN-TEC-06 | Asistentes de operación | modal `xl` desde cuenta/contrato | Asistente por efecto: desconexión, reconexión, traslado (domicilio nuevo + factibilidad), cambio de medidor, categoría, estado, plan; OT especial. | `tec.workOrder.create` | `frmOT_Especial`, `frmTecnica_Desconexion`, `frmTecnica_Reconexion`, `frmTecnica_Translado`, `frmTecnica_CambioMedidor`, `frmTecnica_CambioCategoria`, `frmTecnica_CambioEstado` | O3 |
| PAN-TEC-07 | Generación masiva | `/admin/tec/work-orders/bulk-create` | Filtros de contratos, operación, previsualización de cantidad, ejecución como job con progreso. | `tec.workOrder.bulkCreate` | `frmOT_Notificaciones`, `frmTecnica_CambioEstadoMasivo` | O3 |
| PAN-TEC-08 | Cierre masivo | `/admin/tec/work-orders/bulk-close` | Selección, datos comunes de cierre, resultado por ítem, informe. | `tec.workOrder.bulkClose` | `frmBajaMasivaOrdenes`, `frmBajaMasivaOrdenes_Confirmar` | O3 |
| PAN-TEC-09 | Necesidades de materiales | `/admin/tec/materials` | Solicitudes por OT, autorización, estado de reserva/vale (consulta a M13). | `tec.material.authorize` | `frmTecnica_AutorizarNecesidad`, `frmConsultar_Vales` | O3 |
| PAN-TEC-10 | Despacho | `/admin/tec/dispatch` | Tablero por recurso/día (carriles), arrastrar OT a recurso, capacidad, mapa lateral, estado de envío al dispositivo, recuperación. | `tec.dispatch.manage` | `frmSincronizarCaptor` (reemplazado) | O3 |
| PAN-TEC-11 | Agenda | `/admin/tec/schedule` | Calendario por zona/tipo de visita, cupos, reservas, reprogramación, bloqueos. | `tec.schedule.manage` | — (nuevo, BASE §73) | O3 |
| PAN-TEC-12 | Configuración de agenda | `/admin/tec/schedule/config` | Tipos de visita, zonas, franjas, calendarios de recursos, feriados, sobrecupo. | `tec.schedule.configure` | — | O3 |
| PAN-TEC-13 | Cuadrillas | `/admin/tec/crews` | ABM, integrantes con vigencia, zonas, tipos de trabajo, depósito/custodia asociada. | `tec.crew.manage` | `abm_Cuadri`, `abm_Cuadri_Particua` | O3 |
| PAN-TEC-14 | Recursos de campo | `/admin/tec/resources` | Técnicos/contratistas, habilidades, vehículo, dispositivo asignado. | `tec.crew.manage` | — | O3 |
| PAN-TEC-15 | Responsables a notificar | `/admin/tec/notification-rules` | Reglas por operación/tipo/zona/evento. | `tec.config.manage` | `abm_ResponsaNotifica` | O3 |
| PAN-TEC-16 | Profesionales certificados | `/admin/tec/installers` | Electricistas/instaladores habilitados, matrícula, vigencia. | `tec.config.manage` | — | O7 |
| PAN-TEC-17 | Tipos de operación | `/admin/tec/catalog/operations` | ABM con efecto, requisitos de cierre, cargos antes/después, numeración, reglas. | `tec.config.manage` | `abm_Transac` | O3 |
| PAN-TEC-18 | Tipos de trabajo | `/admin/tec/catalog/work-types` | ABM, SLA, vencimiento. | `tec.config.manage` | `abm_Tptrab` | O3 |
| PAN-TEC-19 | Categorías de incidencia | `/admin/tec/catalog/incident-categories` | ABM jerárquico. | `tec.config.manage` | `abm_Cat_Insi` | O3 |
| PAN-TEC-20 | Resoluciones | `/admin/tec/catalog/resolutions` | Códigos de resolución y estados resultantes. | `tec.config.manage` | `abm_ResolOt`, `abm_Resestad` | O3 |
| PAN-TEC-21 | Tareas y grupos | `/admin/tec/catalog/tasks` | Catálogo de tareas, duración estándar, grupos. | `tec.config.manage` | `abm_TareasOm` | O3 |
| PAN-TEC-22 | Plantillas de impresión | `/admin/tec/catalog/print-templates` | Diseño de comprobante de OT por operación (variables). | `tec.config.manage` | OT_REPORTE | O3 |
| PAN-TEC-23 | Reglas de OT encadenadas | `/admin/tec/catalog/chained-rules` | Origen → destino, condición, demora. | `tec.config.manage` | ALTASEAU | O3 |
| PAN-TEC-24 | Conflictos de sincronización | `/admin/tec/sync-conflicts` | Bandeja, comparación lado a lado (servidor vs campo con evidencias), resolución. | `tec.syncConflict.resolve` | — (nuevo, ESC-03) | O3 |
| PAN-TEC-25 | Bandeja de instalaciones | `/admin/tec/installations` | Vista por etapa (8.5), bloqueos, pendientes de aprovisionamiento/revisión. | `tec.installation.read` | — (nuevo, BASE §73) | O3 |
| PAN-TEC-26 | Formularios de campo | `/admin/tec/field-forms` | Diseñador versionado (CNX §7.8): campos, validaciones, obligatoriedad por operación. | `tec.fieldForm.manage` | — | O3 |
| PAN-TEC-27 | Activos y mantenimiento | `/admin/tec/maintenance` | Planes preventivos, historial por activo, OT generadas. | `tec.maintenance.manage` | — (BASE §18) | O7 |
| PAN-TEC-28 | Interrupciones e impacto | `/admin/tec/outages` | Selección en mapa/árbol, impacto, críticos, aviso, seguimiento. | `tec.outage.manage` | — (BASE §18) | O7 |
| PAN-TEC-29 | Mapa operativo | `/admin/tec/map` | Capas: OT por estado, recursos (última posición informada), red, contratos, reclamos derivados; filtros y selección por polígono. | `tec.map.read` | (mapas Bing/Google Earth) | O3 (OT) / O7 (red) |
| PAN-TEC-30 | Estructura de redes | `/admin/tec/networks/structure` | Redes, capas, tipos de componente, atributos, relaciones permitidas. | `tec.network.configure` | `abm_Redes`, `abm_Redes_Capas`, `abm_Redes_Componentes`, `abm_Redes_Atributos_Componentes`, `frmRedes_Relaciones`, `frmRedes_Relaciones_Add` | O7 (O3 para FTTH) |
| PAN-TEC-31 | Red instalada | `/admin/tec/networks/elements` | Árbol + mapa, alta individual/múltiple, edición de atributos, estado. | `tec.network.manage` | `frmRedes_RedInstalada`, `_Add`, `_AddMultiple`, `_EditAtributo` | O7 (O3 FTTH) |
| PAN-TEC-32 | Conexiones servicio–red | `/admin/tec/networks/connections` | Conexión vigente e historial por contrato/elemento, nueva conexión. | `tec.network.manage` | `frmRedes_Conexiones`, `frmRedes_ConexionNueva` | O3/O7 |
| PAN-TEC-33 | Red v1 (absorbida) | — | No existe como pantalla; se migra a PAN-TEC-30/31. | — | `abm_Niv_Capa`, `abm_Niv_Redes`, `abm_Niv_Serv` | — |
| PAN-TEC-34 | Exportación GIS | `/admin/tec/networks/exports` | Plantillas, ejecución, descargas. | `tec.network.export` | `frmActualizarGis` | O7 |
| PAN-TEC-35 | Equipos de red | `/admin/tec/network-devices` | Inventario lógico (routers, OLT, NAS, centrales), estado de monitoreo, credenciales en bóveda (solo referencia). | `tec.networkDevice.manage` | `abm_Mikrotik` | O3 |
| PAN-TEC-36 | Sistemas de aprovisionamiento | `/admin/tec/provisioning/systems` | Alta de sistema (tipo, endpoint, credencial en bóveda, perfiles), prueba de conexión, sincronización de catálogos. | `tec.provisioning.configure` | `frmSincronizacionAION` | O3 |
| PAN-TEC-37 | Datos técnicos del servicio | pestaña en contrato | IP/PPPoE/ONT/VLAN/plan técnico/casillas, historial. | `tec.serviceTechnical.read/update` | `frmDatosInternet` | O3 |
| PAN-TEC-38 | Consola de comandos | `/admin/tec/provisioning/commands` | Bandeja por estado (8.9), reintentar, marcar manual, ver solicitud/respuesta (sanitizada). | `tec.provisioning.operate` | `ComandosDiscar`, `ComandosNexo`, `ComandosTelemedicion`, `frmTecnica_Nexo` | O3 |
| PAN-TEC-39 | Obras y loteos | `/admin/tec/works` | ABM de obras, grupos, presupuesto, avance, OT asociadas. | `tec.work.manage` | `abm_Obras`, `abm_GrpObra` | O7 |
| PAN-TEC-40 | Contribución por mejoras | `/admin/tec/works/:id/levy` | Padrón (importación), criterio, simulación, aprobación, envío a facturación. | `tec.levy.manage` | — (MER-009) | O7 |
| PAN-TEC-41 | Inspecciones y fraude | `/admin/tec/inspections` | Casos, acta, precintos, descargos, recupero. | `tec.inspection.manage` | — (MER-004) | O7 |
| PAN-TEC-42 | Red telefónica física | `/admin/tec/phone/plant` | Centrales, puertos, repartidores, grupos, regletas/posiciones, cajas, DSLAM. | `tec.phone.plant` | (ABM de centrales/regletas, ver §22.4) | O10 |
| PAN-TEC-43 | Numeración | `/admin/tec/phone/numbering` | Prefijos, plan de numeración, números y estados. | `tec.phone.numbering` | (ABM prefijos/números) | O10 |
| PAN-TEC-44 | Líneas | `/admin/tec/phone/lines` | Línea por contrato, puerto/posición/número, historial. | `tec.phone.lines` | — | O10 |
| PAN-TEC-45 | Importación de CDR | `/admin/tec/phone/cdr` | Importaciones, errores, no atribuidas, reversión. | `tec.cdr.import` | (importadores por central) | O10 |
| PAN-TEC-46 | Telefonía móvil | `/admin/tec/phone/mobile` | Importación de consumos Claro/Personal, conciliación por línea. | `tec.mobile.import` | — (MER-017) | O10 |
| PAN-TEC-47 | Informes técnicos | `/admin/tec/reports` | Catálogo de informes (§15), parámetros, exportación. | `tec.report.read` | `frmInformesTecnica`, `frmInformesFactibilidad`, `frmInformes_Redes`, `frmImpresiones` | O3/O7/O10 |
| PAN-TEC-48 | Revisión de geolocalización | `/admin/tec/geo-review` | Puntos dudosos/sin ubicar, corrección en mapa, confianza. | `tec.geo.review` | — (BASE §77) | O3 |
| PAN-TEC-49 | Carga rápida de reclamo | — | Reemplazada por M09 (caso) + derivación a OT. | — | `frmCargaRapidaReclamo` | — |

### 10.2 App de campo (PWA única)

| ID | Pantalla | Ruta | Propósito / componentes | Perfil | Ola |
|---|---|---|---|---|---|
| PAN-TEC-60 | Shell de campo | `/field` | Landing por rol, banner único de sincronización, estado de red, cambio de perfil si tiene varios, bloqueo por PIN/biometría del dispositivo. | Todos | O3 |
| PAN-TEC-50 | Mi día | `/field/today` | Lista ordenada de visitas/OT con franja, dirección, botón navegar (app de mapas del dispositivo), estado. | Técnico | O3 |
| PAN-TEC-51 | Ejecución de OT | `/field/work-orders/:id` | Pasos: En camino → Llegué → checklist/formulario → escaneo de equipo → materiales → fotos → prueba → conformidad/firma → cerrar. Funciona sin red. | Técnico | O3 |
| PAN-TEC-52 | Mi stock | `/field/stock` | Custodia del técnico (consulta de M13 en caché), devolución, diferencias. | Técnico | O3 |
| PAN-TEC-53 | Cola de sincronización | `/field/sync` | Mutaciones pendientes, resultado por ítem, conflictos, reintentar; nunca permite descartar evidencia sin supervisor. | Todos | O3 |
| PAN-TEC-54 | Inspección | `/field/inspections/:id` | Acta guiada, precintos, fotos, firma o negativa a firmar. | Técnico/inspector | O7 |
| PAN-TEC-55 | Crear OT en campo | `/field/work-orders/new` | Alta desde campo por tipos permitidos (PRM-TEC-112). | Técnico/lecturista | O3 |
| PAN-TEC-56 | Mapa del técnico | `/field/map` | OT del día, red cercana (capas cacheadas), ubicación propia (no se transmite en continuo). | Técnico | O3/O7 |

Los perfiles lecturista (M03) y cobrador (M07) reutilizan PAN-TEC-60 y PAN-TEC-53; sus pantallas específicas se especifican en sus anexos.

### 10.3 Portal del socio

| ID | Pantalla | Ruta | Propósito | Ola |
|---|---|---|---|---|
| PAN-TEC-57 | Reservar visita | `/portal/visits/book` | Elegir franja disponible, reserva temporal con cuenta regresiva, confirmación y constancia. | O3 |
| PAN-TEC-58 | Seguimiento de visita | `/portal/visits/:id` | Estado (confirmada, asignada, en camino, en sitio, completada), reprogramar/cancelar dentro de reglas, detalle de instalación y conformidad. | O3 |
| PAN-TEC-59 | Estado de factibilidad | `/portal/feasibility/:id` | Estado y dictamen visibles al socio (sin datos internos de red). | O3 |

Enumeraciones globales de ProCoop absorbidas en los enums del §7: `EstadoTecnica`, `ModoFormulario` (descartado, propio de VB6), `OpcionesDesconexion`, `Estado_AbmTecnica`, `Estados_Factibilidad`, `Origen`.

## 11. API

Convenciones: JSON, `tenantId` derivado de la sesión (nunca del cuerpo), paginación `{items,total,page,size}`, errores RFC 9457 (`type`, `title`, `status`, `detail`, `code`, `errors[]`), `Idempotency-Key` obligatorio en todo POST que crea o aplica efectos, `If-Match`/`version` en PATCH (concurrencia optimista; 409 si no coincide), validación con Zod compartida con el front. Rutas `/api/admin/tec/...` (back office), `/api/field/...` (PWA), `/api/portal/tec/...` (socio), `/api/v1/ext/tec/...` (integraciones con token de servicio).

| ID | Método y ruta | Propósito | Capability | Notas |
|---|---|---|---|---|
| API-TEC-01 | `GET/POST /api/admin/tec/feasibility` | Listar / crear factibilidad | `tec.feasibility.read/create` | Filtros estado, servicio, zona, vigencia. |
| API-TEC-02 | `GET/PATCH /api/admin/tec/feasibility/:id` | Ficha / editar | `tec.feasibility.read/update` | Cambios versionados. |
| API-TEC-03 | `POST /api/admin/tec/feasibility/:id/verdict` | Dictaminar | `tec.feasibility.evaluate` | Motivo y responsable obligatorios. |
| API-TEC-04 | `POST /api/admin/tec/feasibility/:id/cancel` · `/reopen` | Anular / reabrir | `tec.feasibility.cancel/reopen` | Reapertura según PRM-TEC-064. |
| API-TEC-05 | `GET /api/admin/tec/feasibility/:id/resource-proposal` | Proponer recurso de red | `tec.feasibility.evaluate` | Consulta GIS de capacidad. |
| API-TEC-06 | `GET/POST/PATCH /api/admin/tec/estimates[/:id]` · `POST /:id/submit` | Estimación y envío a M11 | `tec.estimate.manage` | — |
| API-TEC-07 | `GET/POST /api/admin/tec/work-orders` | Listar / crear OT | `tec.workOrder.read/create` | Creación valida duplicados (409 `tec.workOrder.duplicate`). |
| API-TEC-08 | `GET/PATCH /api/admin/tec/work-orders/:id` | Ficha / editar | `tec.workOrder.read/update` | Bloqueada si `dispatch.locked` (423). |
| API-TEC-09 | `POST /api/admin/tec/work-orders/:id/{schedule,assign,dispatch,recall,hold,resume}` | Transiciones operativas | `tec.dispatch.manage` | — |
| API-TEC-10 | `POST /api/admin/tec/work-orders/:id/execute` | Marcar ejecutada (administrativa) | `tec.workOrder.execute` | — |
| API-TEC-11 | `POST /api/admin/tec/work-orders/:id/close` | Confirmar / cerrar | `tec.workOrder.close` | Devuelve 202 si quedan pasos asíncronos. |
| API-TEC-12 | `POST /api/admin/tec/work-orders/:id/{cancel,reopen,restore}` | Anular / reabrir / restablecer | `tec.workOrder.cancel/reopen` | Compensación. |
| API-TEC-13 | `GET/POST /api/admin/tec/work-orders/:id/{tasks,notes,extra-data,evidence}` | Subrecursos | `tec.workOrder.update` | Evidencias: URL firmada de subida. |
| API-TEC-14 | `GET/POST /api/admin/tec/work-orders/:id/materials` · `POST /materials/:mid/{authorize,cancel,return}` | Materiales | `tec.material.request/authorize` | Delegan reserva/vale a M13. |
| API-TEC-15 | `POST /api/admin/tec/work-orders/bulk-create` · `bulk-close` · `GET /api/admin/tec/jobs/:id` | Masivos | `tec.workOrder.bulkCreate/bulkClose` | Job con resultado por ítem. |
| API-TEC-16 | `GET /api/admin/tec/work-orders/:id/print` | Comprobante PDF | `tec.workOrder.print` | Marca despacho (RN-TEC-011). |
| API-TEC-17 | `GET /api/admin/tec/schedule/availability` | Disponibilidad por zona/tipo/fecha | `tec.schedule.read` | También en portal (API-TEC-40). |
| API-TEC-18 | `POST /api/admin/tec/bookings` · `/:id/{confirm,release,cancel}` | Reservas | `tec.schedule.manage` | Contador atómico; 409 `tec.booking.noCapacity`. |
| API-TEC-19 | `GET/POST/PATCH /api/admin/tec/visits[/:id]` · `/:id/{reschedule,assign,cancel}` | Visitas | `tec.schedule.manage` | — |
| API-TEC-20 | `CRUD /api/admin/tec/schedule/{visit-types,zones,calendars}` | Configuración de agenda | `tec.schedule.configure` | — |
| API-TEC-21 | `CRUD /api/admin/tec/{crews,resources,installers,notification-rules}` | Recursos | `tec.crew.manage`, `tec.config.manage` | — |
| API-TEC-22 | `CRUD /api/admin/tec/catalog/{operations,work-types,incident-categories,resolutions,tasks,task-groups,print-templates,chained-rules,intake-channels}` | Catálogos | `tec.config.manage` | Importación Excel. |
| API-TEC-23 | `GET /api/admin/tec/installations` · `POST /:workOrderId/{confirm-activation,review}` | Instalaciones | `tec.installation.read/review` | — |
| API-TEC-24 | `GET /api/admin/tec/sync-conflicts` · `POST /:id/resolve` | Conflictos | `tec.syncConflict.resolve` | Resolución con motivo. |
| API-TEC-25 | `CRUD /api/admin/tec/field-forms` · `POST /:id/publish` | Formularios de campo | `tec.fieldForm.manage` | Versionado inmutable al publicar. |
| API-TEC-26 | `CRUD /api/admin/tec/maintenance-plans` · `CRUD /outages` · `POST /outages/:id/{approve,notify,start,finish,cancel}` | Mantenimiento e interrupciones | `tec.maintenance.manage`, `tec.outage.manage` | — |
| API-TEC-27 | `GET /api/admin/tec/networks/impact?elementIds=` | Análisis de impacto | `tec.network.read` | Async (JOB-TEC-15) si supera umbral. |
| API-TEC-28 | `CRUD /api/admin/tec/networks/{networks,layers,component-types,relations,attributes}` | Estructura de red | `tec.network.configure` | — |
| API-TEC-29 | `CRUD /api/admin/tec/networks/elements` · `POST /elements/bulk` · `GET /elements/tree` · `GET /elements/geo?bbox=` | Red instalada | `tec.network.manage/read` | GeoJSON; bbox con índice 2dsphere. |
| API-TEC-30 | `GET/POST /api/admin/tec/networks/connections` · `POST /:id/disconnect` | Conexiones | `tec.network.manage` | — |
| API-TEC-31 | `CRUD /api/admin/tec/networks/export-templates` · `POST /:id/run` | Exportación GIS | `tec.network.export` | — |
| API-TEC-32 | `CRUD /api/admin/tec/network-devices` · `GET /:id/status` | Equipos de red | `tec.networkDevice.manage` | Credencial solo como `secretRef`. |
| API-TEC-33 | `CRUD /api/admin/tec/provisioning/{systems,profiles}` · `POST /systems/:id/{test,sync-catalog}` | Sistemas de aprovisionamiento | `tec.provisioning.configure` | — |
| API-TEC-34 | `GET /api/admin/tec/provisioning/commands` · `POST /:id/{retry,mark-manual,cancel}` | Consola | `tec.provisioning.operate` | — |
| API-TEC-35 | `GET/PATCH /api/admin/tec/service-technical/:contractId` | Datos técnicos del servicio | `tec.serviceTechnical.read/update` | Cambios generan comando. |
| API-TEC-36 | `CRUD /api/admin/tec/works` · `/works/:id/{beneficiaries,levy/simulate,levy/approve,levy/send}` | Obras y contribución | `tec.work.manage`, `tec.levy.manage` | — |
| API-TEC-37 | `CRUD /api/admin/tec/inspections` · `/:id/{order,notify,defense,propose-recovery,approve,annul}` · `CRUD /seals` | Inspecciones | `tec.inspection.manage/approve` | Separación de funciones (RN). |
| API-TEC-38 | `CRUD /api/admin/tec/phone/{exchanges,ports,frames,frame-groups,strips,positions,boxes,dslams,prefixes,numbers,lines,operators,service-types,modalities}` | Telefonía | `tec.phone.*` | — |
| API-TEC-39 | `POST /api/admin/tec/phone/cdr-imports` · `GET /:id` · `POST /:id/{attribute,rollback}` · `POST /mobile-imports` | CDR y móvil | `tec.cdr.import`, `tec.mobile.import` | Subida por URL firmada. |
| API-TEC-40 | `GET /api/portal/tec/availability` · `POST /api/portal/tec/bookings` · `POST /:id/confirm` | Reserva del socio | sesión de socio (titular/autorizado) | Rate limit. |
| API-TEC-41 | `GET /api/portal/tec/visits/:id` · `POST /:id/{reschedule,cancel}` · `GET /api/portal/tec/feasibility/:id` | Seguimiento | sesión de socio | Solo datos propios. |
| API-TEC-42 | `GET /api/field/my-day` | Paquete del día | perfil técnico | ETag; delta desde `since`. |
| API-TEC-43 | `POST /api/field/sync` | Lote de mutaciones | perfil de campo | Resultado por ítem (`applied|duplicate|conflict|rejected|deferred`). |
| API-TEC-44 | `POST /api/field/evidence/upload-url` | URL firmada para foto/firma | perfil de campo | Tamaño máx. PRM-TEC-144. |
| API-TEC-45 | `GET /api/field/custody` | Custodia del técnico (proxy a M13) | perfil técnico | — |
| API-TEC-46 | `POST /api/field/devices/register` · `POST /revoke` | Dispositivos | perfil de campo / `tec.device.manage` | Revocación borra caché local al próximo contacto. |
| API-TEC-47 | `GET /api/admin/tec/geo/review` · `POST /geo/points/:id` · `POST /geo/geocode` | Geolocalización | `tec.geo.review` | Proveedor abstraído (PRM-TEC-149). |
| API-TEC-48 | `GET /api/admin/tec/reports/:reportId` | Informes | `tec.report.read` | Exportación CSV/XLSX/PDF. |
| API-TEC-49 | `POST /api/v1/ext/tec/work-orders` | Alta externa de OT (contratistas, sistemas) | token de servicio con scope `tec.ext.workOrder` | Idempotente. |
| API-TEC-50 | `POST /api/v1/ext/tec/provisioning/callback/:systemId` | Callback de sistemas externos | firma HMAC del sistema | Verifica firma y replay. |

Errores de dominio (campo `code`): `tec.feasibility.required`, `tec.feasibility.expired`, `tec.feasibility.alreadyUsed`, `tec.workOrder.duplicate`, `tec.workOrder.locked`, `tec.workOrder.invalidTransition`, `tec.workOrder.closeRequirementsMissing`, `tec.workOrder.pendingPayment`, `tec.workOrder.conflictOpen`, `tec.booking.noCapacity`, `tec.booking.expired`, `tec.reschedule.tooLate`, `tec.material.notInCustody`, `tec.material.exceedsAuthorized`, `tec.equipment.serialMismatch`, `tec.provisioning.systemUnavailable`, `tec.network.relationNotAllowed`, `tec.network.elementInUse`, `tec.phone.numberUnavailable`, `tec.cdr.duplicateFile`, `tec.cdr.parseError`, `tec.inspection.segregationOfDuties`, `tec.version.mismatch`.

## 12. Eventos y jobs

### 12.1 Eventos publicados (outbox)

| ID | Evento | Payload mínimo | Consumidores |
|---|---|---|---|
| EVT-TEC-01 | `tec.feasibility.requested` | feasibilityId, serviceType, personId, addressId | M09 (seguimiento), T09 |
| EVT-TEC-02 | `tec.feasibility.verdictIssued` | feasibilityId, verdict, validUntil, estimateId? | M09, M11, T09 |
| EVT-TEC-03 | `tec.feasibility.cancelled` | feasibilityId, reason | M09 |
| EVT-TEC-04 | `tec.workOrder.created` | workOrderId, operationTypeId, contractId?, origin, caseId? | M09, M15, T09 |
| EVT-TEC-05 | `tec.workOrder.statusChanged` | workOrderId, from, to, at | M09 (estado del caso), portal |
| EVT-TEC-06 | `tec.workOrder.executed` | workOrderId, executedAt, resourceId | M09, M13 |
| EVT-TEC-07 | `tec.workOrder.closed` | workOrderId, effect, contractId?, closedAt, resolutionCodeId | M09, M05 (cargos "luego"), M03 (lectura), M15 |
| EVT-TEC-08 | `tec.workOrder.cancelled` | workOrderId, reason | M09, M13 (liberar reservas) |
| EVT-TEC-09 | `tec.workOrder.reopened` | workOrderId, reason | M09, M05 |
| EVT-TEC-10 | `tec.charge.proposed` | workOrderId, contractId, conceptId, moment (before/after), quantity | M04/M05 |
| EVT-TEC-11 | `tec.material.requested` / `tec.material.returned` / `tec.material.used` | workOrderId, itemId, serial?, qty | M13 |
| EVT-TEC-12 | `tec.equipment.installed` / `tec.equipment.retrieved` | workOrderId, serial, contractId, propertyId, modality | M13, contrato |
| EVT-TEC-13 | `tec.visit.statusChanged` | visitId, status, eta? | T09 (aviso "En camino", recordatorio), portal |
| EVT-TEC-14 | `tec.visit.failed` | visitId, reason, chargeable | M09, M04/M05 (si regla de cobro) |
| EVT-TEC-15 | `tec.conformity.signed` / `tec.conformity.refused` | workOrderId, documentHash | M09, contrato |
| EVT-TEC-16 | `tec.installation.activationConfirmed` | contractId, workOrderId, effectiveAt | Contrato (T05), M05, M09, T09 (encuesta) |
| EVT-TEC-17 | `tec.survey.requested` | workOrderId, personId, channel | T09 |
| EVT-TEC-18 | `tec.disconnection.executed` | contractId, orderId (M08), mode, at | M08, M05/M04 (proporcional), contrato |
| EVT-TEC-19 | `tec.reconnection.executed` | contractId, orderId, mode, at | M08, M05/M04, contrato |
| EVT-TEC-20 | `tec.dependentDisconnection.requested` | parentContractId, dependentContractIds | M08/contrato |
| EVT-TEC-21 | `tec.provisioning.confirmed` / `tec.provisioning.failed` | commandId, contractId, action, systemId | M08, M09, contrato |
| EVT-TEC-22 | `tec.meter.changed` | contractId, oldMeterId, newMeterId, readings, at | M03, M13 |
| EVT-TEC-23 | `tec.outage.notified` / `tec.outage.finished` | outagePlanId, affectedCount, window | T09, T10, M09 |
| EVT-TEC-24 | `tec.networkDevice.down` | deviceId, since, affectedCount | M09 (incidente de zona), T09 |
| EVT-TEC-25 | `tec.levy.approved` | workId, beneficiaries[{contractId, amount}] | M05/M08 |
| EVT-TEC-26 | `tec.inspection.recoveryApproved` | caseId, contractId, method, period | M04 (cálculo), M05 |
| EVT-TEC-27 | `tec.cdr.attributed` | importId, count, period | M04 |
| EVT-TEC-28 | `tec.mobileUsage.imported` | importId, operator, period | M04/M05 |
| EVT-TEC-29 | `tec.syncConflict.opened` / `tec.syncConflict.resolved` | conflictId, workOrderId, resolution? | M09, supervisor (T09) |
| EVT-TEC-30 | `tec.geo.pointUpdated` | addressId, location, confidence | M01, M03 (rutas) |
| EVT-TEC-31 | `tec.phoneLine.changed` | contractId, number, portId, at | M04 |

### 12.2 Eventos consumidos

| Evento | Origen | Acción en TEC |
|---|---|---|
| `crm.case.workOrderRequested` | M09 | Crear OT derivada con `caseId` y categoría. |
| `crm.case.feasibilityRequested` | M09 | Crear factibilidad. |
| `crm.case.closed` | M09 | Si la OT sigue abierta, alerta (no cierra automáticamente). |
| `mor.suspension.ordered` / `mor.suspension.revoked` | M08 | Ejecutar o cancelar corte (9.5). |
| `mor.reconnection.ordered` | M08 | Ejecutar reconexión. |
| `con.contract.created` / `con.contract.planChanged` / `con.contract.terminated` | Contrato (T05) | OT de alta / comando de cambio de plan / OT de retiro. |
| `fac.estimate.accepted` | M11 | Marcar estimación aceptada; liberar factibilidad. |
| `pag.payment.applied` | M07 | Reevaluar bloqueo por pagos pendientes (PRM-TEC-075). |
| `med.anomaly.detected` | M03 | Proponer caso de inspección. |
| `inv.custody.changed` / `inv.reservation.failed` | M13 | Actualizar custodia en caché / bloquear etapa. |
| `tar.call.rated` | M04 | Marcar CDR tasado. |
| `iam.user.deactivated` | M01/T01 | Revocar dispositivos y desasignar recursos. |

### 12.3 Jobs

Ver §9.12 (JOB-TEC-01 a JOB-TEC-16). Todos corren en workers BullMQ con `tenantId` en el job, reintentos con backoff exponencial, dead-letter visible en la bandeja operativa (AGR-016) y métricas de duración/fallos.

## 13. Integraciones

Todas a través de conectores T06 (contrato común: `capabilities()`, `test()`, `execute(command)`, `query(ref)`, mapeo de errores a transitorio/definitivo, credenciales por `secretRef` en bóveda del tenant, registro sanitizado de solicitud/respuesta, rate limit y circuit breaker). TEC define **qué** se pide y **cuándo**; T06 define **cómo**.

| Sistema | Tipo | Acciones requeridas por TEC | Ola | Notas |
|---|---|---|---|---|
| MikroTik (RouterOS API) | Router/NAS | alta/baja de cliente (PPPoE secret, colas, address-list), suspensión/reactivación, cambio de plan, estado | O3 | Corte directo de ProCoop reemplazado por comando (CTR-TEC-11). |
| Radius (FreeRADIUS u otro) | AAA | alta/baja de usuario, atributos de plan, desconexión de sesión (CoA) | O3 | — |
| SmartOLT | Gestión OLT/ONT | autorizar ONT por serie, perfil de velocidad, suspender, consultar señal | O3 | Serie de ONT validada contra M13. |
| Wispro | Plataforma ISP | alta/baja/suspensión de cliente y plan | O3 si alguna cooperativa a migrar lo usa (PA-TEC-10) | — |
| Ispfull | Plataforma ISP | ídem | O3/O10 | — |
| Sensa | Plataforma ISP/TV | ídem; tickets del proveedor (CTR-TEC-16) | O10 | — |
| Sopnet | Plataforma ISP | ídem | O10 | — |
| Sitsa | Plataforma TV | alta/baja/suspensión por cuenta (CTR-TEC-24) | O10 | Identifica por cuenta, no por contrato. |
| Discar / Nexo | Conmutación telefónica / IVR | comandos de línea | O10 | "Cancelada" como éxito (CTR-TEC-25) se normaliza. |
| Centrales telefónicas (Gretix, Tecnored Sunsip, AION, Central Online y más de 20 formatos de archivo) | CDR | descarga/lectura de CDR, sincronización de catálogos (AION) | O10 | Lectores como plugins (PA-TEC-13). |
| Claro / Personal | Telefonía móvil | importación de consumos | O10 | PA-TEC-14. |
| Telemedición (M03/T06) | Medición remota | corte/reconexión remota de medidores inteligentes | O7 | Comando originado por TEC o M08. |
| Google Maps (Geocoding, Maps JS) | Mapas | geocodificación, mapa base, navegación por deep link | O3 | Proveedor abstraído (PA-TEC-12); clave por tenant en bóveda (PRM-TEC-123). |
| T09 Notificaciones | Interno | aviso de visita, "En camino", recordatorio, interrupción, encuesta | O3 | Constancia de envío. |
| Correo provisto (casillas) | Hosting de correo | alta/baja de casillas `providedMailboxes` | O10 | Credenciales nunca en claro (CTR-TEC-29). |

## 14. Parámetros

Todos los parámetros se gestionan en T04 (`tenantSettings`, con alcance tenant / servicio / operación cuando se indica), versionados y auditados. Decisión: **R** replicar, **M** mejorar, **Rz** reemplazar (otra mecánica), **D** descartar (con motivo), **Ref** propiedad de otro anexo (solo se consume). Ninguna credencial es parámetro: las claves se guardan en la bóveda y el parámetro solo lleva `secretRef`.

### 14.1 Parámetros de origen ProCoop — sección TECNICA (V2)

| ID | V2 | Clave GoodApps | Tipo / default | Alcance | Descripción | Decisión |
|---|---|---|---|---|---|---|
| PRM-TEC-001 | #2 | `field.allowCreateWorkOrders` | bool / true | tenant, perfil | Permite crear OT desde la app de campo. | R (unificado con PRM-TEC-112) |
| PRM-TEC-002 | #10 | — | — | — | Sincronización automática de lecturas desde el colector. | Ref M03 (la cola offline es única, AGR-025) |
| PRM-TEC-003 | #11 | — | — | — | Registrar pagos a través del portal/app. | Ref M07 |
| PRM-TEC-004 | #16 | — | — | — | Foto obligatoria del medidor al leer. | Ref M03 |
| PRM-TEC-005 | #33 | — | — | — | URL de servicio web para generar OT desde el colector. | D: la app es propia y usa la API (CTR-TEC-13) |
| PRM-TEC-006 | #48 | `field.allowCloseWorkOrders` | bool / true | tenant, operación | Permitir ejecutar/cerrar OT desde campo. | M: por operación |
| PRM-TEC-007 | #50 | `field.requireSignatureOnClose` | bool / true para alta/instalación | operación | Firma del receptor al cerrar. | M (PA-TEC-07) |
| PRM-TEC-008 | #51 | `survey.afterClose` | enum `none|afterClose|afterActivation` / `afterActivation` | operación | Encuesta de conformidad. | Rz: posterior e independiente (CTR-TEC-15) |
| PRM-TEC-009 | #53 | — | — | — | Mensaje automático al registrar ventas. | Ref M07/T09 |
| PRM-TEC-010 | #54 | `field.allowCloseSelectedOperations` | lista de operaciones | tenant | Operaciones cerrables desde campo. | M: integrado a PRM-TEC-006 por operación |
| PRM-TEC-011 | #57 | `field.skipModifiedOrders` | — | — | No sincronizar OT modificadas. | Rz: conflicto explícito (§9.4), nunca descarte silencioso |
| PRM-TEC-012 | #58 | `portal.claimCreatesWorkOrder` | — | — | Generar OT de reclamo desde la web. | Ref M09 (el caso deriva OT por regla) |
| PRM-TEC-013 | #62 | `field.confirmOnCancel` | bool / true | tenant | Pedir confirmación al cancelar en campo. | R (patrón de UI estándar) |
| PRM-TEC-014 | #64 | `field.showMeterInList` | bool / true | tenant | Mostrar medidor en la lista de OT de campo. | R |
| PRM-TEC-015 | #70 | `field.allowMeterChangeOnUnmetered` | bool / false | servicio | Crear OT de cambio de medidor en servicio no medido desde campo. | R |
| PRM-TEC-016 | #174 | `workOrder.requireAdminNotes` | bool / false | operación | Exigir observación administrativa. | R |
| PRM-TEC-017 | #180 | `workOrder.defaultPrintTemplate` | ref `workOrderPrintTemplates` | operación | Comprobante de OT por defecto. | M: plantilla por operación |
| PRM-TEC-018 | #254 | `workOrder.offerCalculatedConsumption` | bool / false | operación | Ofrecer consumo calculado al cerrar (servicio sin lectura). | R vía evento a M03 |
| PRM-TEC-019 | #333 | `workOrder.defaultIntakeChannel` | ref `intakeChannels` | tenant | Vía de ingreso por defecto. | R |
| PRM-TEC-020 | #341 | — | — | — | Usuario para ProCoop AVL. | D: sin AVL propietario (CTR-TEC-12) |
| PRM-TEC-021 | #342 | `workOrder.close.requireResponsible` | bool / true | operación | Exigir responsable al confirmar. | R |
| PRM-TEC-022 | #344 | `workOrder.numbering.scheme` | enum `continuous|byService|byServiceYear|byWorkType|byWorkTypeAndClaim` / `byServiceYear` | tenant | Numeración visible de OT. | M: contador atómico (CTR-TEC-19) |
| PRM-TEC-023 | #358 | `workOrder.print.includeMap` | bool / true | operación | Imprimir OT con mapa. | R (mapa estático con clave del tenant) |
| PRM-TEC-024 | #388 | `feasibility.required` | enum `never|optional|required` / `required` para Internet y servicios con red | servicio, operación (alta, reconexión, traslado) | Exigir factibilidad. | M (PA-TEC-04, CTR-TEC-33) |
| PRM-TEC-025 | #401 | `workOrder.close.requireNetworkPoint` | bool / true si el servicio usa red | servicio | Exigir punto de conexión a la red física. | R |
| PRM-TEC-026 | #430 | — | — | — | Integración AVL Plus. | D (CTR-TEC-12) |
| PRM-TEC-027 | #441 | `workOrder.close.allowDateBeforeCreation` | bool / false | tenant | Cierre con fecha anterior al alta de la OT. | R (con capability y motivo) |
| PRM-TEC-028 | #443 | `workOrder.materials.lockBillingPrice` | bool / true | tenant | No permitir cambiar precio de materiales a facturar. | R (unifica #448) |
| PRM-TEC-029 | #448 | (= PRM-TEC-028) | — | — | Duplicado del anterior en ProCoop. | M: unificado |
| PRM-TEC-030 | #460 | `workOrder.laborConceptId` | ref concepto M02 | tenant | Concepto de horas hombre para costeo. | R (costeo; informes) |
| PRM-TEC-031 | #465 | `workOrder.printTemplateByOperation` | bool / true | tenant | Modelo de comprobante según operación. | M: siempre posible; parámetro queda como default |
| PRM-TEC-032 | #474 | `workOrder.close.requireCategory` | bool / false | operación | Exigir categoría de incidencia. | R |
| PRM-TEC-033 | #497 | `workOrder.close.requireResolution` | bool / true | operación | Exigir resolución. | R |
| PRM-TEC-034 | #752 | `workOrder.close.allowFutureDate` | bool / false | tenant | Cierre con fecha posterior a hoy. | R (default no) |
| PRM-TEC-035 | #911 | — | — | — | Adhesión a factura web. | Ref M05/T09 |
| PRM-TEC-036 | #2084 | `workOrder.close.requireCrewSize` | bool / false | operación | Exigir cantidad de personas. | R |
| PRM-TEC-037 | #2268 | `workOrder.allowEditIntakeDate` | bool / false | tenant | Cambiar fecha de ingreso. | R (con auditoría) |
| PRM-TEC-038 | #2339 | `workOrder.prefillAdminNotesFromService` | bool / false | servicio | Precargar observación desde el servicio. | R |
| PRM-TEC-039 | #2354 | `workOrder.close.requireParticipantHours` | bool / false | operación | Exigir horas de participantes. | R |
| PRM-TEC-040 | #2370 | `provisioning.nexo.responseTimeoutSeconds` | int / 30 | sistema | Espera de respuesta de Nexo. | Rz: configuración del conector T06 |
| PRM-TEC-041 | #2393 | `provisioning.mikrotik.suspendedProfile` | texto | sistema | Perfil MikroTik de servicio suspendido. | Rz: en `provisioningProfiles` (`suspend`) |
| PRM-TEC-042 | #2399 | `meter.clearOnRemoval` | bool / false | servicio | Borrar datos del medidor al marcar retirado. | M: se cierra la vinculación con fecha (no se borra el historial; M03/M13) |
| PRM-TEC-043 | #2421 | `workOrder.close.installerCertificate` | enum `none|warn|require` / `warn` | operación | Validar número de certificado del instalador. | R (con `certifiedInstallers`) |
| PRM-TEC-044 | #2422 | `serviceTechnical.usePartnerData` | bool / false | servicio | Datos técnicos de Internet del partner. | Rz: perfiles por sistema |
| PRM-TEC-045 | #2425 | `gis.serviceTypes` | lista de servicios | tenant | Servicios incluidos en GIS. | R |
| PRM-TEC-046 | #2439 | `workOrder.allowEditRequestDate` | bool / false | tenant | Cambiar fecha de solicitud. | R |
| PRM-TEC-047 | #2440 | `disconnection.defaultMeterRemoved` | bool / false | operación | Medidor retirado por defecto en desconexión. | R |
| PRM-TEC-048 | #2470 | `workOrder.close.requireDeviceSerial` | bool / true | operación | Exigir número de dispositivo en altas que lo requieren. | R (validado contra M13) |
| PRM-TEC-049 | #2474 | `meterChange.allowCategoryChange` | bool / false | servicio | Cambio de categoría junto al cambio de medidor. | R |
| PRM-TEC-050 | #2480 | `workOrder.allowContactUpdate` | bool / true | tenant | Actualizar teléfono y correo desde la OT. | M: propone cambio a M01 con confirmación |
| PRM-TEC-051 | #2483 | `reconnection.creditDisconnectedDays` | — | — | Crédito por días desconectado al reconectar. | Ref M04/M05 (TEC emite evento, CTR-TEC-10) |
| PRM-TEC-052 | #2485 | `reconnection.creditConceptId` | — | — | Concepto para ese crédito. | Ref M04/M05 |
| PRM-TEC-053 | #2491 | `provisioning.nexo.loginPerPrepaidSale` | bool | sistema | Login por venta prepaga en Nexo. | Rz: conector T06 |
| PRM-TEC-054 | #2505 | `workOrder.vehicleControl` | enum `none|ask|require` / `none` | tenant | Control de móvil (vehículo) en la OT. | R |
| PRM-TEC-055 | #2531 | `disconnection.askMeterRemoval` | bool / true | operación | Preguntar retiro de medidor en desconexión. | R |
| PRM-TEC-056 | #2570 | `categoryChange.proportionalConceptId` | — | — | Concepto de proporcional por cambio de categoría. | Ref M04/M05 |
| PRM-TEC-057 | #2587 | `categoryChange.proportionalPositiveOnly` | — | — | Proporcional solo positivo. | Ref M04 |
| PRM-TEC-058 | #2625 | `categoryChange.chargeImmediately` | — | — | Cobrar el proporcional en el momento. | Ref M05/M07 |
| PRM-TEC-059 | #2627 | `workOrder.materials.allowNonStockProducts` | bool / true | tenant | Registrar materiales sin stock (servicios, mano de obra). | R |
| PRM-TEC-060 | #2629 | `workOrder.requireIntakeChannel` | bool / true | tenant | Exigir vía de ingreso. | R |
| PRM-TEC-061 | #2637 | `move.warnIfRouteUnchanged` | bool / true | servicio | Alertar si no se cambió el recorrido en traslado. | R (ruta en M03) |
| PRM-TEC-062 | #2638 | `move.askUpdatePostalAddress` | bool / true | servicio | Preguntar si se actualiza domicilio postal y recorrido. | R |
| PRM-TEC-063 | #2652 | `workOrder.close.requireMeterModel` | bool / true | servicio | Exigir modelo de medidor en altas con dispositivo. | R |
| PRM-TEC-064 | #2654 | `feasibility.allowEditClosed` | bool / false | tenant | Modificar factibilidades cerradas. | M: reapertura con versión |
| PRM-TEC-065 | #2655 | `workOrder.allowOnPendingConnection` | bool / false | operación | OT sobre servicios pendientes de conexión. | R |
| PRM-TEC-066 | #2657 | `workOrder.materials.showDetail` | bool / true | tenant | Mostrar detalle en el registro de materiales. | D: siempre visible (UI) |
| PRM-TEC-067 | #2661 | `reconnection.debitIfNotBilled` | — | — | Débito al reconectar servicio no facturado en el período. | Ref M04/M05 |
| PRM-TEC-068 | #2667 | `workOrder.materials.lockOnClosed` | bool / true | tenant | Bloquear materiales en OT cerradas. | R (corrección solo compensatoria) |
| PRM-TEC-069 | #2694 | `dunning.allowWithoutTechnicalNotes` | bool / true | tenant | OT por mora sin observación técnica. | R |
| PRM-TEC-070 | #2722 | `labor.normalHourRate` | decimal | tenant | Importe de hora normal (costeo). | M: tarifa con vigencia; el informe no la sobrescribe (CTR-TEC-26) |
| PRM-TEC-071 | #2723 | `labor.overtimeHourRate` | decimal | tenant | Importe de hora extra. | M (ídem) |
| PRM-TEC-072 | #2808 | `workOrder.print.marksDispatched` | bool / true | operación | Imprimir cambia estado a despachada (inverso de V2 "no modificar"). | R |
| PRM-TEC-073 | #2811 | `workOrder.allowDispatchLock` | bool / true | tenant | Bloquear OT enviada a campo. | R |
| PRM-TEC-074 | #2819 | `workOrder.print.includeVouchers` | bool / true | operación | Mostrar vales en el comprobante. | R |
| PRM-TEC-075 | #2891 | `workOrder.close.checkPendingPayments` | bool / true | operación | Verificar pagos pendientes al cerrar (inverso de V2). | R |
| PRM-TEC-076 | #2897 | `provisioning.deleteUserOnTermination` | bool / false | sistema | Eliminar usuario en el sistema de red al dar de baja. | Rz: en `provisioningProfiles` (`terminate`) |
| PRM-TEC-077 | #2899 | `materials.allowImportFromEstimate` | bool / true | tenant | Importar productos del presupuesto a los vales. | R (estimación → materiales previstos; vale en M13) |
| PRM-TEC-078 | #2907 | `reconnection.allowCloseWithoutDocuments` | — | — | Cerrar sin comprobantes de reconexión. | Ref M05 |
| PRM-TEC-079 | #2913 | `field.autoDispatchOnCreate` | bool / false | operación | Enviar automáticamente a campo al crear. | Rz: despacho a la app propia (sin MySQL intermedia, CTR-TEC-13) |
| PRM-TEC-080 | #2933 | `gis.exportTemplateId` | ref `gisExportTemplates` | tenant | Exportador GIS. | Rz: plantillas (CTR-TEC-32) |
| PRM-TEC-081 | #2997 | `maintenance.useDepotAuthorization` | bool / true | tenant | Autorización de materiales en mantenimiento. | R |
| PRM-TEC-082 | #2998 | `claims.numbering.continuous` | — | — | Numeración continua de reclamos. | Ref M09 |
| PRM-TEC-083 | #3031 | `claims.report.numberingByService` | — | — | Numeración por servicio en informe de reclamos. | Ref M09 |
| PRM-TEC-084 | #3034 | (sistema `sitsa`) | `endpoint` en `provisioningSystems` | sistema | URL del servicio web Sitsa. | Rz: configuración de conector |
| PRM-TEC-085 | #3035 | (sistema `sitsa`) | `secretRef` | sistema | Clave API Sitsa. | Rz: bóveda (CTR-TEC-29) |
| PRM-TEC-086 | #3082 | `feasibility.allowAttachmentsWhenClosed` | bool / true | tenant | Adjuntos en factibilidad cerrada. | R (agregar sin modificar dictamen) |
| PRM-TEC-087 | #3084 | `notifications.responsiblesByServiceAndOperation` | bool / true | tenant | Responsables por servicio y operación. | R (reglas) |
| PRM-TEC-088 | #3085 | `labor.defaultParticipantHourRate` | decimal | tenant | Valor de hora por defecto por participante. | R |
| PRM-TEC-089 | #3086 | `workOrder.dispatch.requireResponsible` | bool / true | tenant | Exigir responsable al despachar a campo. | R |
| PRM-TEC-090 | #3120 | `regulatory.showOcebaTab` | — | — | Pestaña de reclamos OCEBA. | Ref M09/T10 |
| PRM-TEC-091 | #3165 | (sistema `wispro`) | `secretRef` | sistema | Clave API Wispro. | Rz: bóveda |
| PRM-TEC-092 | #3173 | `workOrder.print.includeIncidentReport` | bool / false | operación | Incluir informe de incidentes en el comprobante. | R |
| PRM-TEC-093 | #3175 | `provisioning.discar.showConnectAction` | bool | sistema | Botón "Conectar servicio" de Discar. | Rz: acción de la consola según capacidades del conector |
| PRM-TEC-094 | #3189 | `provisioning.radius.queryOnly` | bool / false | sistema | Radius solo para consultas. | Rz: `capabilities` del sistema |
| PRM-TEC-095 | #3201 | `workOrder.warnWithoutMaterials` | bool / false | operación | Advertir al cerrar sin materiales. | R |

### 14.2 Parámetros de origen ProCoop — sección TELEFONIA (V2)

| ID | V2 | Clave GoodApps | Descripción | Decisión |
|---|---|---|---|---|
| PRM-TEC-096 | #13 | — | Tarifa de celulares. | Ref M04 |
| PRM-TEC-097 | #18 | `phone.callDetailServiceId` | Servicio del detalle de llamadas. | Ref M04/M05 (TEC solo atribuye) |
| PRM-TEC-098 | #62 | — | Tasar automáticamente internacionales. | Ref M04 (CTR-TEC-17) |
| PRM-TEC-099 | #64 | — | Importe mínimo de llamadas no gratuitas. | Ref M04 |
| PRM-TEC-100 | #82 | `phone.virtualExchangeServiceId` | Servicio para central virtual. | R (atribución de llamadas a central virtual) |
| PRM-TEC-101 | #236 | `phone.prepaidEnabled` | Habilita telefonía prepaga. | R (TEC: OT de recarga; tasación M04) |
| PRM-TEC-102 | #238 | `phone.prepaidTopUpOperationTypeId` | Operación de OT para compra de minutos. | R (efecto `prepaidTopUp`) |
| PRM-TEC-103 | #301 | `mobile.personal.importConfig` | Configuración de datos de Personal. | M: plantilla de importador (PA-TEC-14) |
| PRM-TEC-104 | #332 | `phone.prepaidServiceId` | Servicio de telefonía prepaga. | R |
| PRM-TEC-105 | #471 | — | No aplicar consumo mínimo en claves 0 y 1. | Ref M04 |
| PRM-TEC-106 | #2099 | — | Concepto de crédito prepago. | Ref M04/M05 |
| PRM-TEC-107 | #2295 | `cdr.cppOperatorForNextel` | Operador para importador CPP Nextel. | M: opción del lector |
| PRM-TEC-108 | #2302 | `cdr.dedupeOnImport` | Validar llamadas existentes al importar. | M: siempre activo con `dedupeKey`; parámetro define la clave |
| PRM-TEC-109 | #2344 | — | Tarifa de telefonía por defecto en alta. | Ref M04 |
| PRM-TEC-110 | #2346 | `cdr.telcoIpKey99ZeroAmount` | Importe 0 a llamadas Telco IP clave 99. | M: opción del lector; el importe lo fija M04 |
| PRM-TEC-111 | #2444 | `cdr.lucent.excludedNumbers` | Números a excluir en importador Lucent. | M: opción del lector |

### 14.3 Otros parámetros de origen ProCoop consumidos por TEC

| ID | V2 | Clave GoodApps | Descripción | Decisión |
|---|---|---|---|---|
| PRM-TEC-112 | #30 (TELEMED) | `field.allowCreateWorkOrderTypes` | Crear OT desde la app de campo; lista de operaciones permitidas. | M (unifica #2) |
| PRM-TEC-113 | #65 | `workOrder.deferredChargeInstallmentType` | Tipo de cuota por defecto de cargos "luego". | Ref M05 (TEC solo lo pasa) |
| PRM-TEC-114 | #2301 | `reconnection.allowDeceasedHolder` | Reconectar a titular fallecido. | R |
| PRM-TEC-115 | #2330 | `operations.categoryChangeOperationTypeId` | Operación de cambio de categoría. | M: el efecto vive en el catálogo; parámetro para compatibilidad de M05 |
| PRM-TEC-116 | #2753 | `workOrder.cancelConnection.setNotCurrent` | Estado "No vigente" al anular OT de alta. | R |
| PRM-TEC-117 | #2755 | — | Día límite de facturación para proporcional por cambio de categoría. | Ref M04/M05 |
| PRM-TEC-118 | #3111 | — | Categoría histórica para fijos por mes vencido. | Ref M05 (TEC publica fecha efectiva del cambio) |
| PRM-TEC-119 | #3088 | `notifications.responsibleChannel` | Canal de aviso a responsables (WhatsApp/Email/SMS). | R vía T09 |
| PRM-TEC-120 | #3105 | — | Usar API oficial de WhatsApp. | Ref T09 |
| PRM-TEC-121 | #2693 | — | Proveedor SMS propio de ProCoop. | Ref T09 |
| PRM-TEC-122 | #2823 | — | Código de distribuidora OCEBA (exportaciones). | Ref T10 (usado por plantillas GIS regulatorias) |
| PRM-TEC-123 | #2251 | `maps.apiKeyRef` | Clave del proveedor de mapas (en bóveda). | M: obligatoria por tenant, sin clave fija |
| PRM-TEC-124 | #2027–#2029 | `maps.initialCenter`, `maps.initialZoom`, `maps.baseLayer` | Centro, zoom y tipo de mapa inicial. | R |
| PRM-TEC-125 | #19, #24, #70, #79, #353, #543 (CVLP) | — | Parámetros CVLP usados en validaciones de alta/categoría. | Ref M05/M06/M04 |
| PRM-TEC-126 | #2253 | — | Servicio de Pack SMS (telefonía móvil). | Ref M04/M05 |
| PRM-TEC-127 | #518/#519, #2824/#3051/#3121, #2870/#2873/#2874 | — | Mensajería y conectores varios. | Ref T09/T06 |
| PRM-TEC-128 | #681, #2488, #210 | — | Reclamos y seguridad relacionados. | Ref M09/T01 |

### 14.4 Parámetros nuevos de GoodApps

| ID | Clave | Tipo / default | Alcance | Descripción |
|---|---|---|---|---|
| PRM-TEC-130 | `feasibility.validityDays` | int / 90 | servicio | Vigencia de la factibilidad para un alta (PA-TEC-05). |
| PRM-TEC-131 | `workOrder.duplicateWindowDays` | int / 0 (sin límite) | operación | Ventana para detectar OT duplicadas. |
| PRM-TEC-132 | `workOrder.twoStepClose` | bool por operación / true para alta, desconexión, reconexión, cambio de medidor | operación | Doble paso ejecutada/confirmada (PA-TEC-01). |
| PRM-TEC-133 | `booking.holdMinutes` | int / 15 | tenant | Duración de la reserva temporal. |
| PRM-TEC-134 | `booking.reminderHours` | int / 24 | tipo de visita | Anticipación del recordatorio. |
| PRM-TEC-135 | `booking.overbookingAllowed` | bool / false | zona | Sobrecupo con capability. |
| PRM-TEC-136 | `booking.memberRescheduleMinHours` | int / 24 | tipo de visita | Anticipación mínima para que el socio reprograme o cancele. |
| PRM-TEC-137 | `survey.dissatisfactionThreshold` | int / 2 (escala 1–5) | tenant | Puntaje que crea seguimiento en M09 (PA-TEC-08). |
| PRM-TEC-138 | `installation.activationMilestone` | enum `tested|testedAndProvisioned|testedProvisionedAndReviewed` / `testedAndProvisioned` | servicio | Hito de activación (PA-TEC-02). |
| PRM-TEC-139 | `sync.conflictResolutionSlaHours` | int / 24 | tenant | Plazo de resolución antes de escalar (PA-TEC-17). |
| PRM-TEC-140 | `sync.clockSkewToleranceMinutes` | int / 10 | tenant | Tolerancia de reloj del dispositivo. |
| PRM-TEC-141 | `provisioning.maxRetries` | int / 5 | sistema | Reintentos antes de pasar a manual. |
| PRM-TEC-142 | `provisioning.retryBackoff` | lista de segundos / `[30,120,600,1800,3600]` | sistema | Backoff de reintentos. |
| PRM-TEC-143 | `inspection.defenseDays` | int / 10 | tenant | Plazo de descargo (validar con normativa local). |
| PRM-TEC-144 | `evidence.photoMaxMb` | int / 5 | tenant | Tamaño máximo por foto (se comprime en el dispositivo). |
| PRM-TEC-145 | `sync.batchSize` | int / 50 | tenant | Mutaciones por lote. |
| PRM-TEC-146 | `visit.failedVisitChargeRule` | ref regla M04 / ninguna | tipo de visita | Cobro por visita fallida (PA-TEC-06). |
| PRM-TEC-147 | `service.usesTechnicalOrders` | bool / true | servicio | El servicio informa a técnica (altas/bajas generan OT). |
| PRM-TEC-148 | `provisioning.requireConfirmationForActivation` | bool / true | servicio | La activación espera la confirmación del sistema de red. |
| PRM-TEC-149 | `geo.geocodingProvider` | enum `google|none` / `google` | tenant | Proveedor de geocodificación (abstraído). |
| PRM-TEC-150 | `impact.criticalServiceFlags` | lista / `electroDependent` | tenant | Marcas que destacan contratos críticos en el impacto. |
| PRM-TEC-151 | `materials.defaultDepotId` | ref depósito M13 | tenant, cuadrilla | Depósito por defecto cuando no hay custodia. |

PRM-TEC-129 queda reservado (sin asignar) para mantener los bloques.

## 15. Reportes, indicadores y exportaciones

Regla AGR-022: cada indicador declara fórmula, universo, fecha de corte y zona horaria del tenant; los cálculos se hacen sobre datos confirmados salvo que se indique "operativo". Exportación CSV/XLSX/PDF desde PAN-TEC-47; los indicadores avanzados pasan a BI en O11.

| ID | Reporte / indicador | Fórmula | Universo | Fecha de corte | Reemplaza (ProCoop) | Ola |
|---|---|---|---|---|---|---|
| REP-TEC-01 | OT por estado | Conteo por `status` | OT del tenant filtradas por servicio, operación, zona, cuadrilla | Instantánea al momento de la consulta | `frmInformesTecnica` (listado de OT) | O3 |
| REP-TEC-02 | Backlog y antigüedad | OT no finales agrupadas por días desde `requestedAt` (0–2, 3–7, 8–15, >15) | OT no `closed`/`cancelled` | Fecha de consulta | `frmInformesTecnica` (pendientes) | O3 |
| REP-TEC-03 | Cumplimiento de SLA | OT cerradas con `closedAt ≤ dueAt` / OT cerradas | OT cerradas en el período con tipo de trabajo con SLA | `closedAt` en el período | — (nuevo) | O3 |
| REP-TEC-04 | Tiempo medio de resolución | Promedio de `closedAt − requestedAt` (horas hábiles opcional) | OT cerradas del período | `closedAt` | `frmInformesTecnica` | O3 |
| REP-TEC-05 | Primera visita exitosa | Instalaciones activadas con una sola visita / instalaciones activadas | Instalaciones con `activationConfirmed` en el período | Fecha de activación | — (BASE §73) | O3 |
| REP-TEC-06 | Visitas fallidas por motivo | Conteo de `visits.failed` por `failureReason` | Visitas del período | `scheduledStart` | — | O3 |
| REP-TEC-07 | Puntualidad | Visitas con llegada dentro de la franja / visitas completadas | Visitas completadas del período | `scheduledStart` | — | O3 |
| REP-TEC-08 | Ocupación de agenda | Reservas confirmadas / capacidad ofrecida, por zona y día | Franjas del período | Día de la franja | — | O3 |
| REP-TEC-09 | Productividad por recurso | OT ejecutadas, horas registradas y OT por jornada, por técnico/cuadrilla | OT ejecutadas del período | `executedAt` | `frmInformesTecnica` (por cuadrilla) | O3 |
| REP-TEC-10 | Costo de OT | Materiales usados × costo (de M13) + horas normales/extras × tarifa vigente a la fecha de la OT | OT cerradas del período | `closedAt` | `GetCosto_OT` / `GetCosto_OM` (CTR-TEC-26) | O3 |
| REP-TEC-11 | Consumo de materiales | Cantidad usada y devuelta por ítem, servicio, cuadrilla | `workOrderMaterials` `used`/`returned` | Fecha del movimiento | `frmConsultar_Vales`, informe de materiales | O3 |
| REP-TEC-12 | Factibilidades | Conteo por resultado y servicio; tasa factible = factibles / dictaminadas; tiempo medio de dictamen | Factibilidades dictaminadas del período | `verdictAt` | `frmInformesFactibilidad` | O3 |
| REP-TEC-13 | Satisfacción post instalación | Promedio de encuesta y % ≤ umbral (PRM-TEC-137) | Encuestas respondidas | Fecha de respuesta | — (BASE §73) | O3 |
| REP-TEC-14 | Sincronización y conflictos | Mutaciones por resultado; conflictos abiertos y vencidos; tiempo medio de resolución | `syncMutations`, `syncConflicts` | Fecha de recepción | — (AGR-025) | O3 |
| REP-TEC-15 | Aprovisionamiento | Comandos por estado y sistema; tasa de éxito al primer intento; manuales pendientes | `provisioningCommands` del período | `createdAt` | — | O3 |
| REP-TEC-16 | Cortes y reconexiones ejecutados | Conteo por modo (remoto/terreno), tiempo orden→ejecución | Órdenes de M08 del período | `executedAt` | informes de cortes | O6 |
| REP-TEC-17 | Interrupciones | Cantidad, duración real, contratos afectados, críticos; insumo regulatorio (T10) | `outagePlans` completadas | `actualEnd` | — (BASE §18) | O7 |
| REP-TEC-18 | Red instalada | Elementos por tipo, estado y capa; ocupación = conexiones vigentes / capacidad | `networkElements` | Instantánea | `frmInformes_Redes` | O7 |
| REP-TEC-19 | Mantenimiento preventivo | Cumplimiento = preventivos ejecutados en término / programados | Planes activos | `nextDueAt` del período | — | O7 |
| REP-TEC-20 | Obras y contribución | Avance de obra; recaudación de contribución = cobrado / emitido por obra | Obras con contribución | Fecha de corte elegida | — (MER-009) | O7 |
| REP-TEC-21 | Inspecciones | Casos por estado, irregularidades confirmadas / inspeccionadas, recupero aprobado | `inspectionCases` | Fecha de cambio de estado | — (MER-004) | O7 |
| REP-TEC-22 | Importación de CDR | Llamadas importadas, duplicadas, no atribuidas, por central y período | `cdrImports`, `callRecords` | Fecha de la llamada | informes de importación de llamadas | O10 |
| REP-TEC-23 | Comprobante de OT | Documento imprimible por plantilla (con mapa, vales e informe de incidentes según parámetros) | Una OT o selección | — | OT_REPORTE, `frmImpresiones` | O3 |
| REP-TEC-24 | Exportaciones GIS/regulatorias | Según plantilla (`gisExportTemplates`) | Red y contratos | Período de la plantilla | `frmActualizarGis`, 10 exportadores | O7 |

## 16. Casos de uso

### CU-17 (BASE §17) — Conectar Internet con OT

- **Actor:** supervisor y cuadrilla técnica.
- **Precondición:** SOL-001 con documentación completa (M09) y factibilidad favorable.
- **Flujo:** 1) El supervisor aprueba la cobertura y crea OT-001 (`connect`). 2) TEC pide a M13 reservar el equipo; el despachante asigna CUA-01. 3) La cuadrilla registra instalación, prueba y conformidad; TEC envía la fecha efectiva al contrato.
- **Resultado:** OT revisada, contrato habilitable desde la fecha confirmada, materiales y evidencias vinculados.
- **Trazabilidad:** RF-TEC-022 a 063, 085 a 101; §9.1.

### CU-18 (BASE §18) — Mantenimiento preventivo de un activo

- **Actor:** responsable de mantenimiento.
- **Precondición:** la válvula VAL-001 tiene un plan preventivo.
- **Flujo:** 1) Consulta ubicación e historial en PAN-TEC-27/29. 2) Crea la intervención y marca la zona afectada (análisis de impacto, PAN-TEC-28). 3) Registra tareas, materiales y resultado; el plan recalcula el próximo control.
- **Resultado:** historial técnico actualizado y trazable por activo.
- **Trazabilidad:** RF-TEC-138 a 147; §9.6, §9.7.

### CU-AUT-01 (BASE §50, parte técnica) — Contratación con turno desde la app

- **Actor:** socia ASO-001 (ficticia) y cooperativa TEN-001.
- **Flujo técnico:** M09 crea el caso → TEC dictamina factibilidad → la socia elige la franja VIS-DEMO-001 (10/11/2026, 09:00 a 11:00) en PAN-TEC-57 → TEC confirma la reserva → asignación y visita → instalación → activación desde la fecha efectiva.
- **Control:** una visita fallida no activa el contrato (RN de visitas; §8.3).
- **Trazabilidad:** RF-TEC-073 a 084; API-TEC-40/41; EVT-TEC-13/16.

### CU-INS-01 (BASE §73, parte técnica) — Instalación integral

- **Actor:** instalador EMP-INS-001 y socia.
- **Flujo:** cita VIS-DEMO-002 el 10/11/2026; MOD-DEMO-001 en custodia del instalador; informa **En camino**; instala y prueba; registra la serie; captura la conformidad. La confirmación vincula el equipo al contrato (M13), actualiza la custodia y publica la activación del 10/11/2026. Se genera ENC-DEMO-001 y la respuesta 4/5 va al tablero, sin modificar el precio ni la fecha.
- **Fuera de TEC:** el primer cobro (prorrateo de 21/30 días, ARS 21.000 de abono más ARS 20.000 de instalación en la hipótesis de BASE) lo calculan M04/M05/M11.
- **Trazabilidad:** RF-TEC-085 a 101; §8.5; §9.1.

### CU-GEO-01 (BASE §77, parte operativa) — Punto de prestación

- **Flujo:** M01/T04 normalizan la dirección DIR-DEMO-001. TEC usa el punto confirmado para la factibilidad, la agenda y la ruta. Si el punto está "pendiente de georreferenciación", la OT se crea igual con la marca y entra a la cola de PAN-TEC-48. Nunca se inventan coordenadas.
- **Trazabilidad:** RF-TEC-215 a 223.

### CU-OPE-01 (BASE §78, referencia) — Módem comprado y aplicado

TEC solo interviene en la aplicación del equipo a una OT de Internet: lo consume desde la custodia del instalador una sola vez (sin doble descuento) y no genera cargo al socio por el costo del equipo. La compra y el pago se describen en M13, M14 y M15.

### CU-TEC-01 — Visita fallida y reprogramación

- **Actor:** técnico, socio y despachante.
- **Flujo:** el técnico llega y no hay acceso → marca `failed` con motivo y foto → la OT vuelve a `pending` y la instalación a `failedVisit` → el socio recibe la propuesta de nueva franja → reserva → nueva visita confirmada. El equipo sigue en custodia.
- **Control:** no hay activación ni movimiento de stock al domicilio. El cargo solo existe si lo define una regla (PA-TEC-06).

### CU-TEC-02 — Instalación offline con conflicto (ESC-03)

- **Flujo:** el técnico ejecuta sin red y captura firma, fotos y la serie. Mientras tanto, un operador cancela la OT en la administración. Al sincronizar, el servidor responde `conflict`, conserva las evidencias y abre el conflicto. El supervisor elige `acceptField`: reabre la OT, aplica el equipo y activa con la fecha real.
- **Control:** sin doble salida de equipo, sin borrado de evidencias y con auditoría completa.

### CU-TEC-03 — Corte por mora remoto con pago previo

- **Flujo:** M08 ordena la suspensión → TEC encola `suspend` en MikroTik. El socio paga antes del envío → M08 revoca → el comando pasa a `cancelled`. No hay corte ni proporcionales.

### CU-TEC-04 — Aprovisionamiento con caída del sistema de red

- **Flujo:** la OT de alta se ejecuta y el comando `activate` falla 5 veces → `failed` → `manualPending`. El NOC activa a mano y registra la evidencia → `manualDone` → activación confirmada con la fecha de la evidencia.

### CU-TEC-05 — Interrupción planificada

- **Flujo:** el responsable selecciona el transformador TR-DEMO-01 → el impacto muestra 120 contratos ficticios, 2 de ellos críticos → aprueba → T09 avisa con constancia → OT de mantenimiento → cierre e informe.

### CU-TEC-06 — Traslado de servicio

- **Flujo:** la socia pide el traslado → factibilidad en el nuevo domicilio → OT `move` con la visita → al confirmar: cambio de domicilio del contrato, nueva conexión de red, retiro de la conexión anterior y aviso para revisar el recorrido (PRM-TEC-061/062).

### CU-TEC-07 — Cambio de medidor

- **Flujo:** OT `meterChange` → el técnico registra la lectura de retiro, la serie y la lectura de instalación → evento `tec.meter.changed` a M03 y M13.

### CU-TEC-08 — Inspección con irregularidad

- **Flujo:** alerta de consumo de M03 → caso → OT de inspección con acta, precintos y fotos → irregularidad → notificación con 10 días de descargo → propuesta de recupero (M04) → aprobación por un rol distinto al del inspector → documento separado (M05).

### CU-TEC-09 — Contribución por mejoras

- **Flujo:** obra OBR-DEMO-01 de ARS 1.000.000 (ficticio) con 4 frentistas de 10, 20, 30 y 40 m → shares 10 %, 20 %, 30 % y 40 % → importes ARS 100.000, 200.000, 300.000 y 400.000 → aprobación → envío a M05/M08.

### CU-TEC-10 — Importación de CDR

- **Flujo:** se sube el archivo de una central → se rechaza si su hash ya existe → se parsea; un error en la fila 152 aborta con el número de fila → se corrige y se reimporta → deduplicación → atribución → M04 tasa la llamada.

### CU-TEC-11 — Cierre masivo con OT bloqueadas

- **Flujo:** se seleccionan 50 OT; 3 están despachadas a campo y 1 tiene un conflicto. El job cierra 46 y devuelve las 4 restantes con su motivo, por ítem. Se puede reanudar si se interrumpe.

### CU-TEC-12 — Reclamo que deriva en OT

- **Flujo:** M09 registra el reclamo y lo clasifica → `crm.case.workOrderRequested` → TEC crea la OT con `caseId` → los estados de la OT se reflejan en el caso → el cierre de la OT no cierra el caso automáticamente (lo cierra M09).

## 17. Criterios de aceptación y escenarios de prueba

| ID | Escenario | Dado / Cuando / Entonces | Requisitos |
|---|---|---|---|
| ESC-TEC-01 | Factibilidad vencida | **Dado** una factibilidad favorable con `validUntil` vencido, **cuando** se intenta un alta, **entonces** se rechaza con `tec.feasibility.expired`. | RN-TEC-001 |
| ESC-TEC-02 | Factibilidad anulada | **Dado** una factibilidad anulada, **cuando** se usa en un alta, **entonces** se rechaza (corrige el comportamiento de ProCoop, CTR-TEC-14). | RN-TEC-001 |
| ESC-TEC-03 | OT duplicada | **Dado** una OT `disconnect` abierta para el contrato, **cuando** se crea otra igual, **entonces** responde 409 `tec.workOrder.duplicate`. | RN-TEC-019 |
| ESC-TEC-04 | Idempotencia de alta | **Cuando** se repite POST con la misma `Idempotency-Key`, **entonces** se devuelve la misma OT, sin crear otra. | API-TEC-07 |
| ESC-TEC-05 | Reserva concurrente | **Dado** un cupo con capacidad 1 y dos socios que confirman a la vez, **entonces** uno obtiene `confirmed` y el otro `tec.booking.noCapacity`. | RN-TEC-055/056 |
| ESC-TEC-06 | Expiración de reserva | **Dado** una reserva `held` de 15 min, **cuando** pasan 16 min sin confirmar, **entonces** queda `expired` y libera el cupo. | JOB-TEC-01 |
| ESC-TEC-07 | Visita fallida no activa | **Cuando** la visita se marca `failed`, **entonces** no hay evento de activación ni movimiento de equipo a domicilio. | BASE §50 control |
| ESC-TEC-08 (ESC-03) | Conflicto offline | El escenario de CU-TEC-02: evidencia conservada, conflicto abierto, sin doble movimiento de stock, resolución auditada. | RF-TEC-112 a 131 |
| ESC-TEC-09 | Mutación duplicada | **Cuando** el dispositivo reenvía un lote con el mismo `clientMutationId`, **entonces** el resultado es `duplicate` y no hay efectos repetidos. | API-TEC-43 |
| ESC-TEC-10 | Reintentos de aprovisionamiento | **Dado** un sistema que falla de forma transitoria 2 veces, **entonces** el tercer intento confirma y no se crean usuarios duplicados (clave de idempotencia). | §9.9 |
| ESC-TEC-11 (ESC-04) | Resultado incierto | **Dado** un timeout después del envío, **entonces** el worker consulta el estado antes de reenviar; tras restaurar un backup, JOB-TEC-11 concilia sin reenviar a ciegas. | §8.9 |
| ESC-TEC-12 | Corte revocado | Escenario de CU-TEC-03: el comando queda `cancelled` y M08 recibe el resultado. | §9.5 |
| ESC-TEC-13 | Cierre con requisitos | **Dado** `requireResolution=true`, **cuando** se cierra sin resolución, **entonces** se rechaza con `tec.workOrder.closeRequirementsMissing` y la lista de campos. | RN de cierre |
| ESC-TEC-14 | Paso de efecto fallido | **Dado** que M03 no responde al cerrar un cambio de medidor, **entonces** la OT queda `closing` con el paso pendiente, JOB-TEC-04 reintenta y no se duplica el efecto. | §8.4 |
| ESC-TEC-15 | Anulación con compensación | **Dado** una OT de alta cerrada, **cuando** se anula, **entonces** se generan las compensaciones (contrato, equipo, cargos) y no hay borrado físico (CTR-TEC-20). | RN-TEC-036 |
| ESC-TEC-16 | Material sin custodia | **Cuando** el técnico registra una serie que no está en su custodia, **entonces** se rechaza con `tec.material.notInCustody` (o se marca la diferencia para revisar, según la operación). | RF-TEC-064 a 072 |
| ESC-TEC-17 | Impacto de red | **Dado** un árbol de 3 niveles con 120 conexiones bajo TR-DEMO-01, **entonces** el impacto devuelve 120 contratos y marca los críticos. | RF-TEC-148 a 163 |
| ESC-TEC-18 | Relación de red inválida | **Cuando** se conecta un tipo de componente no permitido, **entonces** el error es `tec.network.relationNotAllowed`. | RN de red |
| ESC-TEC-19 | Contribución con redondeo | **Dado** ARS 100.000 entre 3 frentistas iguales, **entonces** 33.333,33 + 33.333,33 + 33.333,34 = 100.000,00. | §9.10 |
| ESC-TEC-20 | Separación de funciones | **Cuando** el inspector intenta aprobar su propio recupero, **entonces** recibe `tec.inspection.segregationOfDuties`. | RN-TEC-094 |
| ESC-TEC-21 | CDR duplicado | **Cuando** se reimporta el mismo archivo, **entonces** se rechaza por hash; si una llamada se repite en otro archivo, se descarta por `dedupeKey`. | §9.8 |
| ESC-TEC-22 | Permiso negativo (técnico) | Un técnico no puede ver OT de otra cuadrilla ni autorizar materiales: 403 y sin datos en la respuesta. | §4 |
| ESC-TEC-23 | Permiso negativo (socio) | Un socio no puede consultar la visita de otra cuenta: 404, sin revelar que existe. | API-TEC-41 |
| ESC-TEC-24 | Permiso negativo (configuración) | Un operador sin `tec.config.manage` no ve el menú de catálogos y la API responde 403. | §4 |
| ESC-TEC-25 | Aislamiento de tenant | Con un usuario de TEN-001, toda consulta por un ID de TEN-002 devuelve 404. Los índices empiezan por `tenantId`, los jobs llevan `tenantId` y los archivos se guardan con prefijo por tenant. | DEC-002 |
| ESC-TEC-26 | Credenciales | Ninguna respuesta de la API ni ningún log contiene contraseñas o claves de sistemas de red: solo `secretRef`. | CTR-TEC-29 |
| ESC-TEC-27 | Dispositivo revocado | **Cuando** se revoca un dispositivo, **entonces** su próxima sincronización se rechaza y su caché local se borra. | API-TEC-46 |
| ESC-TEC-28 | Desvío de reloj | **Cuando** llega una mutación con 30 min de desvío, **entonces** se aplica y queda marcada para revisión. | RN-TEC-069 |
| ESC-TEC-29 | Conciliación de custodia | Al cierre del día, la suma de los movimientos de la OT es igual a las variaciones de la custodia del técnico en M13 (conciliación diaria sin diferencias). | M13 |
| ESC-TEC-30 | Activación con fecha efectiva | **Dado** una instalación probada el 10/11 y un aprovisionamiento confirmado el 11/11 con `activationMilestone=testedAndProvisioned`, **entonces** `effectiveAt` es el 11/11 y se registran ambos hechos (PA-TEC-02). | RN-TEC-064 |

## 18. Datos de precarga de demostración (ficticios)

Todos los datos son inventados. Ningún nombre, documento, domicilio, coordenada real ni credencial proviene de cooperativas reales. Las coordenadas de demo se generan dentro de un polígono genérico configurado por el tenant demo y se marcan con `demo=true`. Importes en ARS.

| Colección | Registros de demo |
|---|---|
| `operationTypes` | `ALTA-INT` (connect, doble paso, aprovisiona), `BAJA-INT` (disconnect + retiro de equipo), `CORTE-MORA` (disconnect, origen mora), `RECON` (reconnect), `TRASLADO` (move), `CAMBIO-MED` (meterChange), `CAMBIO-PLAN` (planChange), `RECLAMO-TEC` (incident), `INSPECCION` (inspection), `MANT-PREV` (none, mantenimiento). |
| `workTypes` | `INST` (SLA de 72 h), `REP` (SLA de 24 h), `MANT` (sin SLA), `INSP` (SLA de 120 h). |
| `resolutionCodes` | `RES-OK` (resuelto), `RES-SIN-ACC` (sin acceso), `RES-MAT` (falta material), `RES-DERIV` (derivado a otra área). |
| `taskCatalog` / `taskGroups` | Grupo `FTTH`: tendido de drop (45 min), fusión (20 min), instalación de ONT (15 min), prueba de potencia (10 min). |
| `schedulingZones` / `visitTypes` | Z-01 "Centro", Z-02 "Norte"; visita `INSTALACION` de 120 min y franjas 09:00–11:00, 11:00–13:00, 14:00–16:00, 16:00–18:00 con capacidad 2 por cuadrilla. |
| `crews` / `fieldResources` | CUA-01 (Z-01) con EMP-INS-001 y EMP-INS-002; CUA-02 (Z-02) con EMP-INS-003; supervisor SUP-DEMO-01. |
| `feasibilityRequests` | FAC-DEMO-001 (Internet, DIR-DEMO-001, favorable, vigente 90 días), FAC-DEMO-002 (no factible: sin puerto libre). |
| `connectionEstimates` | EST-DEMO-001: drop de 150 m, mano de obra de 2 h; total ARS 45.000 (ficticio). |
| `visitBookings` / `visits` | VIS-DEMO-001 (10/11/2026 09:00–11:00, confirmada), VIS-DEMO-002 (10/11/2026, asignada a EMP-INS-001). |
| `workOrders` | OT-001 (CU-17), OT-INT-DEMO-001 (CU-AUT-01, cerrada con activación), OT-DEMO-003 (reclamo derivado de un caso de M09), OT-DEMO-004 (corte por mora remoto), OT-DEMO-005 (visita fallida). |
| `workOrderMaterials` | MOD-DEMO-001 (módem en custodia de EMP-INS-001, usado en OT-INT-DEMO-001), 150 m de drop, 2 conectores SC/APC. |
| `serviceConformities` | Conformidad de OT-INT-DEMO-001, firmada por "Ana Demo" (ficticia) con hash del documento. |
| Encuesta | ENC-DEMO-001, respuesta 4/5. |
| `networks` / `networkElements` | Red `FTTH-DEMO`: OLT-DEMO-01 → PON 1/1 → splitter SPL-DEMO-01 (1:8) → NAP-DEMO-01; red `ELEC-DEMO`: SET-DEMO → alimentador AL-01 → TR-DEMO-01 → 120 conexiones ficticias (2 críticas). |
| `networkDevices` | ONT-DEMO-001, OLT-DEMO-01, router RTR-DEMO-01 (credencial solo como `secretRef` de demo). |
| `provisioningSystems` / `provisioningProfiles` | `mikrotik-demo` y `smartolt-demo` en modo simulador (sin endpoints reales); perfiles INT-100 e INT-300. |
| `serviceTechnicalProfiles` | INT-H-A-001: PPPoE `demo-ana`, IP 10.0.0.10 (rango privado), ONT ONT-DEMO-001. |
| `maintenancePlans` | VAL-001 (válvula, inspección trimestral), TR-DEMO-01 (termografía semestral). |
| `outagePlans` | INT-PLAN-DEMO-01 sobre TR-DEMO-01, ventana de 2 h. |
| `works` / `workBeneficiaries` | OBR-DEMO-01 (cordón cuneta, ARS 1.000.000, 4 frentistas de 10/20/30/40 m). |
| `inspectionCases` / `seals` | INSP-DEMO-01 (sospecha por consumo cero); precintos PRE-DEMO-0001 a 0010. |
| Telefonía | Central CEN-DEMO-01, repartidor REP-DEMO-01, regleta REG-DEMO-01 de 10 posiciones, prefijo 0000 (ficticio), números 0000-400100 a 0000-400199, CDR de demo `cdr-demo.csv` con 50 llamadas sintéticas. |
| `syncConflicts` | CNF-DEMO-01 (OT cancelada vs instalación offline, ESC-03). |

## 19. Migración desde ProCoop

Principios (T07): migración repetible e idempotente por `legacyRef { source, table, id }`; conversión de fechas a la zona horaria del tenant; importes a Decimal128; credenciales a la bóveda (nunca a colecciones); conciliación por conteos y sumas antes de habilitar el paralelo. Las tablas que pertenecen a otros anexos se migran allí.

| Origen ProCoop | Destino | Transformación | Validación de conciliación |
|---|---|---|---|
| `FACTIBIL`, `FACTIBIL_NOTA` | `feasibilityRequests`, `technicalNotes` | `Estados_Factibilidad` al enum del §8.1; anuladas → `cancelled` (nunca usables); vencidas → `expired`; vínculo a contrato si `SERSOC` la usó → `used`. | Conteo por estado; ninguna `cancelled` vinculada a altas posteriores a la migración. |
| `PRESUPU` (los de factibilidad) | `connectionEstimates` | Ítems copiados; vínculo a M11. | Total por presupuesto igual al de origen. |
| `TECNICA` | `workOrders` | `COD_EST` → estado (CTR-TEC-07; la regla del valor 2 se fija por cooperativa en el mapeo, RN-07 §11.1); `COD_TRAN` → `operationTypeId`; `NEW_*` → `operationPayload`; `OBS_ADM`/`OBS_TEC` → notas; numeración visible conservada en `number` con `legacyNumber`. | Conteo por estado y operación; OT abiertas = OT abiertas de origen. |
| `TECNICA_NOTA` | `technicalNotes` | Con autor y fecha. | Conteo. |
| `TECNICA_EXTRAS` | `damageAssessments` / `workOrders.extraData` | Reclamos por daños: montos a Decimal128. | Suma de reclamado y aprobado. |
| `TECNICA_NECESIDAD`, `MOV_PRO` (operaciones 3/5/6/8 de OT) | `workOrderMaterials` | Solicitado/autorizado/retirado/utilizado → estados del §8.6; los movimientos de stock se migran en M13. | Cantidad utilizada por OT = salidas de stock de origen. |
| `PARTIORD`, `PARTIINC` | `workOrders.participants` | Horas normales y extras; valor de hora histórico. | Horas totales por OT. |
| `TAROTM` | `workOrders.tasks` | — | Conteo. |
| `TECNICA_MOVIL` | `workOrders.vehicleIds` (referencia a M18) | — | Conteo. |
| `TECNOTEXP`, `TECNGREXP`, `TECNSEEXP` | `workOrders.dispatch` (histórico) | Solo el último estado exportado. | — |
| `TRANSAC` | `operationTypes` | `TIP_TRAN` → efecto; `REG_EST`/`COD_EST` → estado resultante; `ENVIO_SMS` → regla de notificación; `ALTA_PMOVIL` → permitida en campo; `EXCLUIR_WEB` → canal. | Una operación por `COD_TRAN` y servicio. |
| `TPTRAB` | `workTypes` | `REPORTE` → plantilla. | Conteo. |
| `CAT_INCI`, `CAT_INCI_CTSEC`, `CLAS_INC` | `incidentCategories` | Porcentajes por sección que sumen 100 (si no suman, se informa el error). | Suma de porcentajes. |
| `RESOL_OT` (+ estados de resolución) | `resolutionCodes` | — | Conteo. |
| `TAREAS`, `TAREASOM`, `GRPTAREA` | `taskCatalog`, `taskGroups` | Unificación de `TAREAS`/`TAREASOM` (CTR-TEC-28) con deduplicación por descripción y servicio. | Ninguna tarea referenciada sin destino. |
| `OT_REPORTE` | `workOrderPrintTemplates` | El diseño se rehace; se migra solo la asignación por operación. | — |
| `ALTASEAU` | `chainedOrderRules` | — | Conteo. |
| `VIAINGTE` | `intakeChannels` | — | — |
| `CUADRI`, `PARTICUA` | `crews` | Integrantes con vigencia desde la fecha de migración. | Conteo. |
| `RESPONSA` | `fieldResources` + usuarios de T01 | `PAS_RES` **no se migra** (CTR-TEC-27): el usuario se invita y crea su credencial. | Ningún hash ni contraseña en destino. |
| `RESPONSA_NOTIFICA` | `responsibleNotificationRules` | — | Conteo. |
| `PROFESIO` | `certifiedInstallers` | Datos de contacto con consentimiento (M01). | Conteo. |
| `EXPEDIENTES`, `EXPEDIENTES_TRAM` | `technicalProcedures` | Adjuntos al almacenamiento privado. | Conteo de etapas. |
| `OBRAS`, `GRPOBRA` | `works`, `workGroups` | Cuentas contables → referencia a M15. | Conteo. |
| `REDES`, `REDES_CAPAS`, `REDES_COMPONENTES`, `REDES_ATRIBUTOS_COMPONENTES`, `REDES_RELACIONES_COMPONENTES`, `REDES_SERVICIOS` | `networks`, `networkLayers`, `networkComponentTypes`, `networkAttributeDefs`, `networkComponentRelations` | — | Conteo por red. |
| `REDES_RED_INSTALADA`, `REDES_ATRIBUTOS` | `networkElements` | Latitud/longitud → GeoJSON (las coordenadas inválidas o en 0,0 se marcan "pendiente"); se calcula `ancestorIds`. | Conteo de elementos; árbol sin ciclos. |
| `NIV_CAPA`, `NIV_REDES`, `NIV_SERV` (red v1) | Misma estructura de red v2 (CTR-TEC-21) | Se crea una red por servicio y los niveles pasan a ser capas; `legacyRef.source='v1'`. | Conteo. |
| `SERSOC_REDES` | `serviceNetworkConnections` | — | Conexiones vigentes = servicios conectados. |
| `MAPA` (puntos de domicilio) | Punto de prestación en M01/T04 | Confianza "migrado". | — |
| `MIKROTIK` | `networkDevices` + bóveda | Contraseña → bóveda (CTR-TEC-29). | Ninguna credencial en claro. |
| `INTERNET` | `serviceTechnicalProfiles` | `USER_PASS` → bóveda; MAC, IP, nodo y OLT a los campos. | Un perfil por servicio de Internet activo. |
| `CORREOSINT` | `providedMailboxes` | Contraseña → bóveda o reinicio obligatorio. | Conteo. |
| `TELEMEDICION`, `TELEMED_COMM` (configuración de sistemas) | `provisioningSystems` | Credenciales → bóveda. | Prueba de conexión antes de habilitar. |
| `SERVINT` | `provisioningProfiles` | — | — |
| `CENTRALT`, `TEL_CENTRAL` | `phoneExchanges` | Unificación (CTR-TEC-30). | Conteo. |
| `TEL_PUERTOS_CENTRAL`, `TEL_PUERTOS_DSLAM`, `TEL_DSLAM` | `phonePorts`, `dslams` | — | Conteo. |
| `TEL_REPARTIDOR`, `TEL_GRUPOS_REPARTIDOR`, `TEL_REGLETAS_GRUPOS`, `TEL_POS_REG_GRUPOS`, `TEL_CAJAS`, `TEL_REGLETAS_CAJAS`, `TEL_POS_REG_CAJA` | `phoneFrames`, `phoneFrameGroups`, `phoneStrips`, `phoneStripPositions`, `phoneBoxes` | Las posiciones conservan la conexión de entrada y salida. | Conteo por regleta. |
| `TEL_PREFIJO`, `TEL_NUMEROS` | `phonePrefixes`, `phoneNumbers` | Estado → enum del §8.14. | Números asignados = líneas vigentes. |
| `TEL_SERSOC` | `phoneLines` | Tarifa → referencia a M04. | Conteo. |
| `CARACTER`, `OPERADOR`, `TEL_SERVICIO`, `TEL_MODALIDAD` | `numberingPlan`, `telecomOperators`, `telecomServiceTypes`, `telecomModalities` | — | Conteo. |
| `LLAMADAS`, `ENTRANTE`, `INTERNAC`, `LLA_CEL`, `RECHAZOS` | `callRecords` | Solo el período abierto (no facturado) y 13 meses de histórico para consulta; la tasación histórica queda como `sourceAmount`. | Conteo y segundos totales por período. |
| `EQUIPOS`, `MODEMS`, `UBICACIONES` | No se migran en M10 (CTR-TEC-04/05/06) | `EQUIPOS` (terminales y kioscos) va al agente de hardware local (T06); `MODEMS` (módems GSM para SMS) va a T09; `UBICACIONES` (ubicaciones dentro de depósitos) va a M13. | — |
| `RECLAMOS*`, `RUB_REC`, `FALLAS` | M09 | OT vinculadas por `legacyRef`. | — |
| `MOVIL`, `CHOFERES`, `AVL_REG` | M18 | — | — |

## 20. Contraposiciones resueltas

Regla de prevalencia (guía §3): 1 = DEC, 2 = BASE, 3 = AGR, 4 = CNX, 5 = benchmark ProCoop (DFA, FIC, RN, CAT, INV, REL), con reemplazo cuando hay deuda técnica o de seguridad.

| ID | Fuentes | Conflicto | Resolución | Prevalencia |
|---|---|---|---|---|
| CTR-TEC-01 | DFA M14 vs CAT, RN-07 §1.8 | DFA trata `ITEMSORD` como los materiales de la OT; CAT lo describe como el orden de impresión de los ítems de factura, y RN-07 muestra que los materiales se registran en `MOV_PRO` y `TECNICA_NECESIDAD`. | `ITEMSORD` pasa a M05. Los materiales de la OT son una entidad propia (`workOrderMaterials`). | 5 (código y catálogo sobre la descripción funcional) |
| CTR-TEC-02 | CAT vs RN-07 | CAT describe `CUADRI` como "cuadros"; el código lo usa como cuadrillas (con `PARTICUA`). | Cuadrillas (`crews`). | 5 (comportamiento del código) |
| CTR-TEC-03 | DFA M14 vs CAT | DFA ubica `OPERADOR` en cuadrillas; CAT lo define como operador telefónico. | `telecomOperators` (telefonía). | 5 |
| CTR-TEC-04 | DFA M15 vs CAT | DFA dice que `EQUIPOS` son equipos de red; CAT dice que son terminales y kioscos. | Los equipos de red son `networkDevices` (nuevo, a partir de `MIKROTIK`, `CENTRALT` y BASE §86). `EQUIPOS` va al agente de hardware local (T06). | 2 + 5 |
| CTR-TEC-05 | DFA vs CAT | `MODEMS` parecía ser módems de clientes; en realidad son módems GSM para enviar SMS. | Va a T09. Los módems y ONT de clientes son equipos serializados de M13. | 5 |
| CTR-TEC-06 | DFA vs CAT | `UBICACIONES` parecía ser ubicaciones geográficas de red; son ubicaciones dentro de los depósitos. | Va a M13. | 5 |
| CTR-TEC-07 | RN-07 §1.1, §11.1 | Los estados de la OT tienen valores distintos en el enum del escritorio (1/2/3/4) y en el DTO web (1/2/3). | Enum único del §8.4; mapeo por cooperativa en la migración. | 4 (CNX: enums únicos) |
| CTR-TEC-08 | RN-07 §10.1 | Hay dos enums para el tipo de orden (`TipoOrden` y `TipoOrd`). | Una sola `class` de OT (RF-TEC-022). | 4 |
| CTR-TEC-09 | RN-07 (recomienda PostGIS) vs DEC-001 | RN-07 sugiere PostGIS para el GIS; DEC-001 fija MongoDB. | GeoJSON con índice 2dsphere y `ancestorIds` materializados. Un motor GIS externo solo como posible exportación (T10). | 1 |
| CTR-TEC-10 | RN-07 §1.4 vs BASE §17 límite | ProCoop calcula en el módulo técnico los proporcionales y créditos de reconexión y cambio de categoría. | TEC publica el hecho con su fecha efectiva; M04/M05 calculan. | 2 |
| CTR-TEC-11 | RN-07 §4 (MikroTik) vs AGR-016 | ProCoop corta directo en MikroTik de forma síncrona, sin trazabilidad del origen. | Comando asíncrono, idempotente, con origen (OT o mora) y reintentos. | 3 |
| CTR-TEC-12 | BASE §73 ("En camino") vs AVL de ProCoop | ProCoop integra AVL o GPS en vivo; BASE pide solo el aviso "En camino". | Aviso de estado sin seguimiento continuo. El GPS de flota queda en M18 (O10). | 2 |
| CTR-TEC-13 | FIC 4 (PMovil con MySQL intermedia) vs AGR-025, CNX §3.7 | La app móvil de ProCoop sincroniza mediante una base MySQL externa. | PWA propia con cola única en IndexedDB y `/sync` por lotes. | 3 + 4 (y deuda técnica) |
| CTR-TEC-14 | RN-07 §3.1 | ProCoop no filtra las factibilidades anuladas al validar un alta. | Las anuladas y vencidas nunca son usables. | 5 corregido (defecto) |
| CTR-TEC-15 | V2 #51 vs BASE §73 | ProCoop hace la encuesta al cerrar en sitio; BASE pide una encuesta posterior e independiente. | En sitio solo se registra la conformidad; la encuesta es posterior y no bloquea. | 2 |
| CTR-TEC-16 | RN-10 (tickets de Sensa) vs M09 | Los tickets del proveedor de red se confundían con la atención al socio. | Son tickets técnicos con el proveedor (consola TEC). La atención al socio queda en M09. | 2 |
| CTR-TEC-17 | DFA (telefonía) vs alcance | La tasación aparece dentro del módulo de telefonía. | TEC importa y atribuye los CDR; M04 tasa. | 1 (asignación de anexos del maestro) |
| CTR-TEC-18 | RN-07 (activa al cerrar la OT) vs BASE §73 | ProCoop activa el servicio al confirmar la OT. | Hito de activación con fecha efectiva configurable (PA-TEC-02). | 2 |
| CTR-TEC-19 | RN-07 §1.6 | La numeración usa `max+1`, con riesgo de duplicados por concurrencia. | Contador atómico por esquema y período. | 4 |
| CTR-TEC-20 | RN-07 §1.10 | ProCoop borra físicamente las OT y revierte efectos a mano. | Anulación con compensación y sin borrado físico. | 3 (AGR-003) |
| CTR-TEC-21 | RN-07 §5 | Conviven dos modelos de red (v1 `NIV_*` y v2 `REDES_*`). | Un solo modelo (v2 generalizado); v1 se migra. | 5 + 4 |
| CTR-TEC-22 | BASE §18 ("simulación") vs RN-07 | BASE habla de simular impactos; ProCoop no tiene cálculo eléctrico. | Análisis topológico de impacto sin cálculo eléctrico (PA-TEC-11). | 2 interpretado |
| CTR-TEC-23 | RN-07 §1.8 | Los materiales no tienen entidad propia (son movimientos de stock sueltos). | Entidad `workOrderMaterials` con ciclo de vida propio. | 4 |
| CTR-TEC-24 | RN-10 (Sitsa) | Sitsa identifica al cliente por cuenta y no por servicio. | El conector mapea cuenta ↔ contrato; TEC opera por contrato. | 5 adaptado |
| CTR-TEC-25 | RN-07 §4 (Discar) | La respuesta "operación cancelada por el usuario" se trata como éxito. | Se mapea a `failed`; el éxito solo es explícito. | 5 corregido (defecto) |
| CTR-TEC-26 | RN-08 / RN-07 (informe de costos) | El informe de costo de OT sobrescribe los parámetros #2722 y #2723. | Tarifas con vigencia; los informes solo leen. | 5 corregido (defecto) |
| CTR-TEC-27 | CAT `RESPONSA.PAS_RES` | Los responsables tienen contraseñas propias guardadas en la tabla. | Identidad única en IAM (T01/T02); no se migran contraseñas. | 1 + deuda de seguridad |
| CTR-TEC-28 | CAT `TAREAS` vs `TAREASOM` | Hay dos catálogos de tareas superpuestos. | Catálogo único con grupos. | 4 |
| CTR-TEC-29 | CAT `MIKROTIK`, `INTERNET`, `CORREOSINT`, `TELEMEDICION` | Credenciales guardadas en claro. | Bóveda por tenant con `secretRef`. | 1 (DEC-001) + deuda de seguridad |
| CTR-TEC-30 | CAT `CENTRALT` vs `TEL_CENTRAL` | Hay dos tablas de centrales telefónicas. | `phoneExchanges` única. | 4 |
| CTR-TEC-31 | CAT `RECLAMOS` / RN-07 ("reclamo = OT") vs maestro | En ProCoop el reclamo es a la vez una OT y una tabla propia. | El reclamo es un caso de M09; la OT derivada es de TEC. | 1 (asignación) + 2 |
| CTR-TEC-32 | RN-07 §5.4 | Hay 10 exportadores GIS con códigos fijos por cooperativa. | Plantillas de exportación configurables por tenant. | 4 + deuda técnica |
| CTR-TEC-33 | DFA M14 vs V2 #388 | DFA pide factibilidad obligatoria; ProCoop la tiene como opcional. | Configurable por servicio y operación, obligatoria por defecto en Internet (PA-TEC-04). | 5 (DFA y V2 son benchmark; decide el solicitante) |
| CTR-TEC-34 | FIC 10 (Bing, Google Earth) vs BASE §77 | ProCoop usa mapas de Bing y exportaciones a Google Earth. | Google Maps con el proveedor abstraído (PA-TEC-12); exportación KML opcional. | 2 |

## 21. Preguntas abiertas

### PA-TEC-01 — Doble paso "ejecutada" y "confirmada"
- **Pregunta:** ¿Las OT deben pasar por dos pasos de cierre (el técnico la ejecuta y un supervisor la confirma) o alcanza con uno?
- **Contexto:** ProCoop distingue estados según la cooperativa (RN-07 §11.1). El doble paso agrega control, pero también demora.
- **Opciones:**
  - A) Configurable por tipo de operación, con doble paso por defecto en altas, desconexiones, reconexiones y cambios de medidor **(Recomendada)**: control donde hay efectos sobre el contrato y agilidad en el resto.
  - B) Doble paso siempre: más control y más trabajo para los supervisores.
  - C) Un solo paso siempre: más rápido, pero sin revisión.
- **Impacto si no se responde:** se asume A (PRM-TEC-132).
- **Bloquea:** RF-TEC-035 a 038, §8.4, O3.

### PA-TEC-02 — Hito de activación del servicio
- **Pregunta:** ¿Qué hecho fija la fecha desde la que el contrato queda activo (y se empieza a facturar)?
- **Contexto:** BASE §73 pide una fecha efectiva confirmada. ProCoop activa al cerrar la OT (CTR-TEC-18).
- **Opciones:**
  - A) Instalación probada más aprovisionamiento confirmado **(Recomendada)**: el socio paga desde que tiene servicio real.
  - B) Solo la instalación probada: más simple, pero puede facturar sin servicio si falla el aprovisionamiento.
  - C) Instalación, aprovisionamiento y revisión del supervisor: más control, con demora en la facturación.
- **Impacto si no se responde:** se asume A (PRM-TEC-138).
- **Bloquea:** RF-TEC-085 a 101, RN-TEC-064, EVT-TEC-16, O3 y O4.

### PA-TEC-03 — Facturación de materiales usados en la OT
- **Pregunta:** ¿Los materiales usados en una OT se le facturan al socio?
- **Contexto:** ProCoop permite facturar materiales con precio editable (V2 #443/#448). BASE §78 dice que el costo del equipo no se convierte automáticamente en un cargo.
- **Opciones:**
  - A) No por defecto; solo si lo define una regla de la operación o un presupuesto aceptado **(Recomendada)**: evita cobros no pactados.
  - B) Sí, todos los materiales marcados como facturables.
  - C) Nunca: todo cobro va por presupuesto de M11.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** RF-TEC-064 a 072, EVT-TEC-10.

### PA-TEC-04 — Factibilidad obligatoria
- **Pregunta:** ¿La factibilidad es obligatoria para dar un alta?
- **Contexto:** DFA la pide siempre; ProCoop la tiene como opcional (V2 #388, CTR-TEC-33).
- **Opciones:**
  - A) Configurable por servicio y operación, obligatoria por defecto en Internet y en servicios con red **(Recomendada)**.
  - B) Obligatoria siempre: más control, pero frena altas simples (por ejemplo, servicios sociales).
  - C) Opcional siempre.
- **Impacto si no se responde:** se asume A (PRM-TEC-024).
- **Bloquea:** RF-TEC-001 a 017, O3.

### PA-TEC-05 — Vigencia de la factibilidad
- **Pregunta:** ¿Por cuánto tiempo vale una factibilidad favorable para dar el alta?
- **Contexto:** ProCoop usa 90 días fijos. La capacidad de la red cambia con el tiempo.
- **Opciones:**
  - A) Parámetro por servicio, con 90 días por defecto **(Recomendada)**.
  - B) 90 días fijos para todos los servicios.
  - C) Sin vencimiento.
- **Impacto si no se responde:** se asume A (PRM-TEC-130).
- **Bloquea:** RN-TEC-001.

### PA-TEC-06 — Costo de la visita fallida
- **Pregunta:** ¿Se le cobra al socio una visita fallida por causas atribuibles a él (por ejemplo, ausencia)?
- **Contexto:** BASE §73 menciona la visita fallida, pero no define el cargo.
- **Opciones:**
  - A) Sin costo por defecto, con una regla configurable por tipo de visita **(Recomendada)**.
  - B) Siempre se cobra a partir de la segunda visita fallida.
  - C) Nunca se cobra.
- **Impacto si no se responde:** se asume A (PRM-TEC-146).
- **Bloquea:** EVT-TEC-14, CU-TEC-01.

### PA-TEC-07 — Mecanismo de la firma de conformidad
- **Pregunta:** ¿Qué validez debe tener la firma de conformidad en el domicilio?
- **Contexto:** BASE §73 pide la conformidad; ProCoop captura una firma en el colector (V2 #50).
- **Opciones:**
  - A) Firma manuscrita en pantalla + identificación del receptor (nombre y documento) + hash del documento, con fecha y hora **(Recomendada)**: suficiente como evidencia operativa.
  - B) Firma con validación por código enviado al teléfono del titular: más fuerte, pero depende de cobertura.
  - C) Solo una foto del remito firmado.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** RF-TEC-085 a 101, `serviceConformities`.

### PA-TEC-08 — Umbral de insatisfacción
- **Pregunta:** ¿Desde qué puntaje de la encuesta post instalación se abre un seguimiento?
- **Contexto:** BASE §73 incorpora la encuesta al tablero, pero no define la acción.
- **Opciones:**
  - A) Un puntaje de 2 o menos (en escala de 1 a 5) crea un caso de seguimiento en M09 **(Recomendada)**.
  - B) Un puntaje de 3 o menos.
  - C) Solo se informa en el tablero, sin seguimiento.
- **Impacto si no se responde:** se asume A (PRM-TEC-137).
- **Bloquea:** EVT-TEC-17, REP-TEC-13.

### PA-TEC-09 — Modo de aprovisionamiento
- **Pregunta:** ¿El aprovisionamiento en los sistemas de red debe ser automático o manual?
- **Contexto:** ProCoop combina corte directo y acciones manuales. AGR-016 pide reintentos y trazabilidad.
- **Opciones:**
  - A) Automático y asíncrono, con respaldo manual cuando se agotan los reintentos **(Recomendada)**.
  - B) Solo manual, con una tarea para el NOC.
  - C) Automático sin respaldo manual.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** RF-TEC-182 a 196, §9.9, O3.

### PA-TEC-10 — Sistemas de red del piloto
- **Pregunta:** ¿Qué sistemas de red deben estar integrados para el piloto de Internet (O3)?
- **Contexto:** ProCoop integra MikroTik, Wispro, Radius, SmartOlt, Ispfull, Sensa, Sopnet y Sitsa. Integrar todos en O3 no es viable.
- **Opciones:**
  - A) MikroTik + Radius + SmartOLT en O3 y el resto por demanda de las cooperativas a migrar **(Recomendada)**.
  - B) Solo MikroTik en O3.
  - C) Todos en O3.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** §13, O3.

### PA-TEC-11 — Alcance del análisis de red
- **Pregunta:** ¿El análisis de red debe incluir cálculo eléctrico (caídas de tensión, cargas) o solo topología e impacto?
- **Contexto:** BASE §18 habla de "simulación"; ProCoop no tiene cálculo eléctrico (CTR-TEC-22).
- **Opciones:**
  - A) Topología e impacto (qué contratos quedan afectados), sin cálculo eléctrico **(Recomendada)**.
  - B) Incluir cálculo eléctrico básico.
  - C) Integrarse con un software eléctrico externo.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** RF-TEC-148 a 163, O7.

### PA-TEC-12 — Mapa base
- **Pregunta:** ¿Qué proveedor de mapas se usa?
- **Contexto:** BASE §77 nombra Google Maps. ProCoop usa Bing y Google Earth (CTR-TEC-34). Google Maps tiene costo por uso.
- **Opciones:**
  - A) Google Maps con el proveedor abstraído, para poder cambiarlo más adelante **(Recomendada)**.
  - B) OpenStreetMap, sin costo de licencia.
  - C) Google Maps sin abstracción.
- **Impacto si no se responde:** se asume A (PRM-TEC-149).
- **Bloquea:** RF-TEC-215 a 223.

### PA-TEC-13 — Formatos de CDR prioritarios
- **Pregunta:** ¿Qué formatos de CDR se implementan primero?
- **Contexto:** ProCoop tiene lectores para más de 20 centrales. Implementarlos todos de una vez es costoso.
- **Opciones:**
  - A) Los formatos de las cooperativas que se migran primero, con lectores como plugins **(Recomendada)**.
  - B) Todos los formatos en O10.
  - C) Solo un formato estándar (CSV) y conversión fuera del sistema.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** RF-TEC-197 a 214, O10.

### PA-TEC-14 — Telefonía móvil (Claro y Personal)
- **Pregunta:** ¿Cómo se integran los consumos de telefonía móvil?
- **Contexto:** MER-017 los incluye; ProCoop tiene configuración propia para Personal (V2 #301).
- **Opciones:**
  - A) Importador configurable por operadora en O10 **(Recomendada)**.
  - B) Integración por API con cada operadora.
  - C) Fuera de alcance.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** PAN-TEC-46, EVT-TEC-28.

### PA-TEC-15 — Procedimiento de recupero por fraude
- **Pregunta:** ¿Cómo se define el procedimiento de recupero de consumo no registrado?
- **Contexto:** MER-004 pide el debido proceso; la normativa varía según el regulador.
- **Opciones:**
  - A) Flujo configurable con aprobación obligatoria por un rol distinto del inspector y método de cálculo versionado **(Recomendada)**.
  - B) Flujo fijo según una normativa de referencia.
  - C) Solo registro de la inspección, con el recupero fuera del sistema.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** RF-TEC-176 a 181, RN-TEC-094, O7.

### PA-TEC-16 — Criterio de prorrateo de la contribución por mejoras
- **Pregunta:** ¿Con qué criterio se reparte el costo de una obra entre los beneficiarios?
- **Contexto:** MER-009 lo deja abierto; cada ordenanza puede definir uno distinto.
- **Opciones:**
  - A) Metros de frente por defecto, con el criterio configurable por obra (superficie, partes iguales, valuación) **(Recomendada)**.
  - B) Siempre en partes iguales.
  - C) Importe cargado a mano por beneficiario.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** RF-TEC-168 a 175, §9.10.

### PA-TEC-17 — Responsable de resolver conflictos de sincronización
- **Pregunta:** ¿Quién resuelve los conflictos entre lo hecho en campo y lo cambiado en la administración?
- **Contexto:** AGR-025 exige un responsable definido.
- **Opciones:**
  - A) El supervisor de la zona o cuadrilla, con escalamiento al administrador técnico al vencer el plazo **(Recomendada)**.
  - B) Siempre el administrador técnico.
  - C) Quien haya hecho el cambio en la administración.
- **Impacto si no se responde:** se asume A (PRM-TEC-139).
- **Bloquea:** RN-TEC-068, PAN-TEC-24.

### PA-TEC-18 — Retención de evidencias de campo
- **Pregunta:** ¿Cuánto tiempo se guardan las fotos y firmas de las OT?
- **Contexto:** Las evidencias ocupan espacio y pueden tener datos personales. T11 define la retención documental.
- **Opciones:**
  - A) 10 años para conformidades e inspecciones; 2 años para el resto de las fotos operativas, configurable por tenant **(Recomendada)**.
  - B) Todo por 10 años.
  - C) Según la política general de T11, sin distinción.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** `fieldEvidence`, T11.

## 22. Trazabilidad de fuentes

### 22.1 BASE

| Fuente | Destino en este anexo |
|---|---|
| §17 Técnica y OT (objetivo, límite, alcance, CU-17, precarga) | §1, §2.2; RF-TEC-022 a 063, 085 a 101; RN-TEC-058; CU-17; §18 (OT-001, CUA-01) |
| §18 Mantenimiento, infraestructura y mapas (CU-18) | RF-TEC-138 a 163; RN-TEC-085; §9.6, §9.7; CU-18; CTR-TEC-22; PA-TEC-11; §18 (VAL-001) |
| §50 AUT-003, AUT-004, agenda y visitas, CU-AUT-01 | RF-TEC-073 a 084; RN-TEC-055 a 058; §8.2, §8.3; PAN-TEC-11, 12, 57, 58; CU-AUT-01; ESC-TEC-05 a 07 |
| §73 Instalación integral INS-001 a INS-007 (tabla de stock, firma, encuesta, parámetros, CU-INS-01, controles) | RF-TEC-085 a 101; RN-TEC-059 a 065; §7.6; §8.5; §9.1; CU-INS-01; CTR-TEC-15, 18; PA-TEC-02, 07, 08 |
| §74 Pendientes de instalación | §21 (PA-TEC-02, 06, 07, 08) |
| §77 Geolocalización GEO-001 a GEO-003 (operativo), CU-GEO-01 | RF-TEC-215 a 223; RN-TEC-059, 106, 107; PAN-TEC-48; CU-GEO-01; PA-TEC-12 |
| §79 Fuentes geográficas GEO-F1 a GEO-F6 | §13 (Google Maps; Georef en T04/T06); PRM-TEC-149 |
| §80 Pendientes geográficos | PA-TEC-12; §2.3 (T04, M01) |
| §86 Particularidades de Internet | RF-TEC-164 a 167, 182 a 196; RN-TEC-076 a 078; §13; PA-TEC-09, 10 |
| §37 (glosario y entidades técnicas) | §3 |
| §98 (matriz de módulos) | Encabezado (olas); §2.3 |
| §101 (requisitos transversales) | §11 (convenciones), §17 (ESC-TEC-25, 26) |
| §105 (soluciones) | Encabezado |
| §106 Pendientes técnicos | §21 |
| MER-004 Inspecciones y fraude | RF-TEC-176 a 181; RN-TEC-094, 095; §8.12; §9.11; CU-TEC-08; PA-TEC-15 |
| MER-009 Obras y contribución por mejoras | RF-TEC-168 a 175; RN-TEC-093; §8.11; §9.10; CU-TEC-09; PA-TEC-16 |
| MER-015 Flota (referencia) | §2.3 (M18); CTR-TEC-12 |
| MER-017 Telecomunicaciones (Internet, TV, telefonía, móvil) | RF-TEC-182 a 214; RN-TEC-070, 096 a 105, 113; PA-TEC-13, 14 |
| MER-019, MER-020 (referencia) | §2.3 (M13, T09) |

### 22.2 AGR, DFA, FIC, RN-10 y CNX

| Fuente | Destino |
|---|---|
| AGR-003 Transiciones con actor y reversión | §8 completo |
| AGR-010 Fechas efectivas y de registro | §7 (campos comunes); RN-TEC-065, 069 |
| AGR-016 Reintentos e idempotencia en integraciones | RN-TEC-066; §8.9; §9.9; JOB-TEC-04, 06, 11; ESC-TEC-10, 11 |
| AGR-023 Evidencias documentales | `fieldEvidence`, `serviceConformities`; RN-TEC-062; PA-TEC-18 |
| AGR-024 Constancia de notificaciones | §2.3 (T09); EVT-TEC-13, 23 |
| AGR-025 App de campo offline única | RF-TEC-112 a 131; RN-TEC-055, 067, 068; §9.4; PAN-TEC-50 a 56, 60; PA-TEC-17 |
| AGR-026 Aplicación única del stock | RN-TEC-060; §2.3 (M13); ESC-TEC-29 |
| ESC-01, ESC-02 | No aplican a M10 (escenarios de facturación y cobranza) |
| ESC-03 Conflicto offline | §9.4; CU-TEC-02; ESC-TEC-08 |
| ESC-04 Restauración y reintentos | §8.9; JOB-TEC-11; ESC-TEC-11 |
| DFA M14 (técnica y OT) | RF-TEC-001 a 147; CTR-TEC-01, 03, 33 |
| DFA M15 (redes y equipos) | RF-TEC-148 a 167; CTR-TEC-04 a 06 |
| DFA telefonía e Internet (M26) | RF-TEC-182 a 214; CTR-TEC-17 |
| DFA M27 | RF-TEC-224 a 230 (informes y otros) |
| DFA §31 proceso 1 (alta de suministro) | §9.1 |
| FIC 4 (PMovil) | RF-TEC-112 a 131; CTR-TEC-13 |
| FIC 9 (telemedición y aprovisionamiento) | RF-TEC-182 a 196; §13 |
| FIC 10 (mapas y GIS) | RF-TEC-148 a 163, 215 a 223; CTR-TEC-34 |
| FIC 14.1, 14.2, 15, 16, 17 | §5.3, §5.11, §5.15, §5.16; §13 |
| RN-10 §3.6 a §11 (integraciones externas: MikroTik, Wispro, Radius, SmartOlt, Ispfull, Sensa, Sopnet, Sitsa, AION, Discar, Nexo, centrales, mapas) | §13; RN-TEC-073 a 075; CTR-TEC-16, 24, 25 |
| CNX §3.7 Offline | §9.4; API-TEC-42, 43 |
| CNX §3.8 PWA | §10.2 |
| CNX §4.1 a §4.4 Admin | §10.1 |
| CNX §7.7, §7.8 Relevamientos (`FieldForm`, `FieldAssignment`, `FieldSubmission`) | `fieldForms`; PAN-TEC-26; RF-TEC-112 a 131 |

### 22.3 RN-07 (técnica, reclamos, GIS y telefonía)

| Sección | Destino |
|---|---|
| §0 Mapa de fuentes | Encabezado |
| §1.1 Concepto y tipos | RF-TEC-022; RN-TEC-009; CTR-TEC-08 |
| §1.2 Operaciones (`TRANSAC`) | `operationTypes`; PAN-TEC-17; RN-TEC-024 a 027 |
| §1.3 Estados y circuito | §8.4; RN-TEC-010, 038; CTR-TEC-07 |
| §1.4 Efectos del cierre | RN-TEC-024 a 031; §9.2; CTR-TEC-10 |
| §1.5 Órdenes encadenadas (`ALTASEAU`) | `chainedOrderRules`; RN-TEC-034, 035; PAN-TEC-23 |
| §1.6 Numeración visible | RN-TEC-032, 033; PRM-TEC-022; CTR-TEC-19 |
| §1.7 Asignación (responsables, cuadrillas, móviles, captores) | RF-TEC-102 a 111; RN-TEC-049 a 054 |
| §1.8 Materiales e impacto en stock | RF-TEC-064 a 072; RN-TEC-044 a 047; CTR-TEC-01, 23 |
| §1.9 Cargos asociados (`CONEXION`) | RN-TEC-040 a 043; EVT-TEC-10; §2.3 (M04) |
| §1.10, §1.11 Informes técnicos | §15; RN-TEC-089 a 092; CTR-TEC-26 |
| §2 Reclamos | M09 (CTR-TEC-31); CU-TEC-12; §12.2 |
| §3.1 Factibilidad | RF-TEC-001 a 017; RN-TEC-001 a 008; §8.1; CTR-TEC-14 |
| §3.2 Conexión nueva | §9.1; RN-TEC-018 |
| §4 Cortes y reconexiones | RF-TEC-132 a 137; RN-TEC-070 a 075; §9.5; CTR-TEC-11, 25 |
| §5.1 Red v1 | RN-TEC-079; PAN-TEC-33; CTR-TEC-21 |
| §5.2 Red genérica v2 | RF-TEC-148 a 163; RN-TEC-079 a 085 |
| §5.3 KML y Google Earth | RN-TEC-087; CTR-TEC-34 |
| §5.4 Exportaciones GIS por cooperativa | RN-TEC-086; `gisExportTemplates`; CTR-TEC-32 |
| §6, §6.1 Tickets y mesa de ayuda | RN-TEC-109 (tickets del proveedor); el resto en M09 |
| §7, §7.1 Actividades internas | RN-TEC-110; M09 |
| §8.1 Abonados, numeración y líneas | RF-TEC-197 a 203; RN-TEC-096 a 098, 113 |
| §8.2 Plan de numeración y claves | RF-TEC-204; RN-TEC-099 |
| §8.3 Importación de CDR | RF-TEC-205 a 212; RN-TEC-100 a 103; §9.8 |
| §8.4 Tasación | M04 (CTR-TEC-17); RN-TEC-104 (identidad de la llamada) |
| §8.5 CPP y CVLP | Importación en RF-TEC-205 a 212; cálculo en M04; PRM-TEC-125 |
| §8.6 Internacionales y larga distancia | Importación en TEC; tasación en M04 |
| §8.7 Interconexión | M04 |
| §8.8 Telefonía móvil Claro/Personal | RF-TEC-213; PA-TEC-14; PAN-TEC-46 |
| §8.9 Mensajería (SMS, WhatsApp, IVR) | T09 (PRM-TEC-119 a 121) |
| §8.10 Tasación y facturación telefónica (segunda pasada) | M04/M05; RN-TEC-105 (recarga prepaga) |
| Reglas adicionales (segunda pasada) | RN-TEC-011 a 049 según el tema |
| §9 Parámetros | §14 |
| §10 Implicancias para GoodApps | §7 (modelo), §20 |
| §11 Dudas abiertas | §21 (PA-TEC-01, 02, 04, 05); §19 (mapeo de `COD_EST`, RN-07 §11.1) |

### 22.4 CAT §10 Técnica, reclamos y obras

| Tabla | Destino | Tabla | Destino |
|---|---|---|---|
| `AVL_REG` | M18 (CTR-TEC-12) | `PROFESIO` | `certifiedInstallers` |
| `CAT_INCI` | `incidentCategories` | `RECLAMOS` | M09 (CTR-TEC-31) |
| `CHOFERES` | M18 | `RECLAMOS_HIST` | M09 |
| `CLAS_INC` | `incidentCategories.classCode` | `RECLAMOS_NOTAS` | M09 |
| `EXPEDIENTES` | `technicalProcedures` | `RESOL_OT` | `resolutionCodes` |
| `EXPEDIENTES_TRAM` | `technicalProcedures.steps` | `RESPONSA` | `fieldResources` + T01 (CTR-TEC-27) |
| `FACTIBIL` | `feasibilityRequests` | `RESPONSA_NOTIFICA` | `responsibleNotificationRules` |
| `FACTIBIL_NOTA` | `technicalNotes` | `RUB_REC` | M09 |
| `FALLAS` | M09 | `TAREAS` | `taskCatalog` (CTR-TEC-28) |
| `GRPOBRA` | `workGroups` | `TAREASOM` | `taskCatalog` |
| `GRPTAREA` | `taskGroups` | `TAROTM` | `workOrders.tasks` |
| `MOVIL` | M18 | `TECNGREXP` | `workOrders.dispatch` |
| `OBRAS` | `works` | `TECNICA` | `workOrders` |
| `OT_REPORTE` | `workOrderPrintTemplates` | `TECNICA_EXTRAS` | `damageAssessments` |
| `PARTICUA` | `crews.members` | `TECNICA_MOVIL` | `workOrders.vehicleIds` (M18) |
| `PARTIINC` | `workOrders.participants` | `TECNICA_NECESIDAD` | `workOrderMaterials` |
| `PARTIORD` | `workOrders.participants` | `TECNICA_NOTA` | `technicalNotes` |
| `TECNOTEXP` | `workOrders.dispatch` | `TECNSEEXP` | `workOrders.dispatch` |
| `TPTRAB` | `workTypes` | `TRANSAC` | `operationTypes` |

Tablas de otras secciones citadas: `CONEXION` → M04 (RN-TEC-040); `ALTASEAU` → `chainedOrderRules`; `VIAINGTE` → `intakeChannels`; `ESTASER`, `OBSESTAD`, `SERVICIO_EXTRAS`, `SERSOC_EXTRAS` → estado y datos del contrato (T05) leídos por RN-TEC-025/026; `ITEMSORD` → M05 (CTR-TEC-01); `PROD_TRH` → precio de referencia del producto (M02/M13); `RETI_MAT`, `UBICACIONES` → M13 (CTR-TEC-06); `CAT_INCI_CTSEC`, `CTSECCION` → `incidentCategories.sectionAllocations` y M15; `MAPA` → punto de prestación (M01); `EQUIPOS` → agente de hardware local en T06 (CTR-TEC-04); `MODEMS` → T09 (CTR-TEC-05); `SERVINT` → `provisioningProfiles`; `CUADRI` → `crews` (CTR-TEC-02); `TELEMEDICION`, `TELEMED_COMM` → `provisioningSystems` y M03; `PRESUPU` → M11 con `connectionEstimates`.

### 22.5 CAT §11 Redes (GIS)

| Tabla | Destino |
|---|---|
| `NIV_CAPA`, `NIV_REDES`, `NIV_SERV` | Red v2 (CTR-TEC-21) |
| `REDES` | `networks` |
| `REDES_ATRIBUTOS` | `networkElements.attributes` |
| `REDES_ATRIBUTOS_COMPONENTES` | `networkAttributeDefs` |
| `REDES_CAPAS` | `networkLayers` |
| `REDES_COMPONENTES` | `networkComponentTypes` |
| `REDES_RED_INSTALADA` | `networkElements` |
| `REDES_RELACIONES_COMPONENTES` | `networkComponentRelations` |
| `REDES_SERVICIOS` | `networks.serviceTypes` |
| `SERSOC_REDES` | `serviceNetworkConnections` |

### 22.6 CAT §12 Telefonía e Internet

| Tabla | Destino | Tabla | Destino |
|---|---|---|---|
| `BANCLA` | M04 | `TARCLA` | M04 |
| `BANDAS` | M04 | `TARESP` | M04 |
| `CARACTER` | `numberingPlan` | `TARTEL` | M04 |
| `CENTRALT` | `phoneExchanges` (CTR-TEC-30) | `TEL_CAJAS` | `phoneBoxes` |
| `CLAVES` | M04 (la clave queda como dato del CDR) | `TEL_CENTRAL` | `phoneExchanges` |
| `CORREOSINT` | `providedMailboxes` | `TEL_DSLAM` | `dslams` |
| `ENTRANTE` | `callRecords` (`incoming`) | `TEL_FRACCIONES` | M04 |
| `GRATIS` | M04 | `TEL_GRUPOS_REPARTIDOR` | `phoneFrameGroups` |
| `INTERNAC` | `callRecords` (`international`) | `TEL_MODALIDAD` | `telecomModalities` |
| `INTERNET` | `serviceTechnicalProfiles` | `TEL_NUMEROS` | `phoneNumbers` |
| `LLAMADAS` | `callRecords` | `TEL_POS_REG_CAJA` | `phoneStripPositions` |
| `LLA_CEL` | `callRecords` (`cpp`) | `TEL_POS_REG_GRUPOS` | `phoneStripPositions` |
| `MIKROTIK` | `networkDevices` + bóveda | `TEL_PREFIJO` | `phonePrefixes` |
| `OPERADOR` | `telecomOperators` (CTR-TEC-03) | `TEL_PUERTOS_CENTRAL` | `phonePorts` |
| `PLANDES` | M04 | `TEL_PUERTOS_DSLAM` | `phonePorts` |
| `RECHAZOS` | `callRecords.rejected` | `TEL_REGLETAS_CAJAS` | `phoneStrips` |
| `SERTEL` | M04 | `TEL_REGLETAS_GRUPOS` | `phoneStrips` |
| `TEL_REPARTIDOR` | `phoneFrames` | `TEL_SERSOC` | `phoneLines` |
| `TEL_SERVICIO` | `telecomServiceTypes` | `TIPOBAN` | M04 |
| `TIPOLLAM` | M04 (el tipo queda como dato del CDR) | | |

### 22.7 Parámetros RN-09

- **TECNICA (95):** cada número V2 tiene su fila en §14.1. #2→PRM-TEC-001, #10→002, #11→003, #16→004, #33→005, #48→006, #50→007, #51→008, #53→009, #54→010, #57→011, #58→012, #62→013, #64→014, #70→015, #174→016, #180→017, #254→018, #333→019, #341→020, #342→021, #344→022, #358→023, #388→024, #401→025, #430→026, #441→027, #443→028, #448→029, #460→030, #465→031, #474→032, #497→033, #752→034, #911→035, #2084→036, #2268→037, #2339→038, #2354→039, #2370→040, #2393→041, #2399→042, #2421→043, #2422→044, #2425→045, #2439→046, #2440→047, #2470→048, #2474→049, #2480→050, #2483→051, #2485→052, #2491→053, #2505→054, #2531→055, #2570→056, #2587→057, #2625→058, #2627→059, #2629→060, #2637→061, #2638→062, #2652→063, #2654→064, #2655→065, #2657→066, #2661→067, #2667→068, #2694→069, #2722→070, #2723→071, #2808→072, #2811→073, #2819→074, #2891→075, #2897→076, #2899→077, #2907→078, #2913→079, #2933→080, #2997→081, #2998→082, #3031→083, #3034→084, #3035→085, #3082→086, #3084→087, #3085→088, #3086→089, #3120→090, #3165→091, #3173→092, #3175→093, #3189→094, #3201→095.
- **TELEFONIA (16):** #13→096, #18→097, #62→098, #64→099, #82→100, #236→101, #238→102, #301→103, #332→104, #471→105, #2099→106, #2295→107, #2302→108, #2344→109, #2346→110, #2444→111.
- **Otros consumidos:** TELEMED #30→112; #65→113; #2301→114; #2330→115; #2753→116; #2755→117; #3111→118; #3088→119; #3105→120; #2693→121; #2823→122; #2251→123; #2027 a #2029→124; CVLP (#19, #24, #70, #79, #353, #543)→125; #2253→126; mensajería y conectores (#518, #519, #2824, #3051, #3121, #2870, #2873, #2874)→127; reclamos y seguridad (#681, #2488, #210)→128.
- **Resto de TELEMED (45):** son de M03 (medición y telemedición); TEC solo consume el resultado de los comandos (RF-TEC-196).

### 22.8 INV `ProMod_Tecnica` (61 tipos en `Forms`: 58 formularios y 3 enums; más `frmTecnica_CambioEstadoMasivo`, 3 controles y enums globales)

| Formulario | Destino | Formulario | Destino |
|---|---|---|---|
| `abm_Cat_Insi` | PAN-TEC-19 | `frmInformesFactibilidad` | PAN-TEC-47 (REP-TEC-12) |
| `abm_Cuadri` | PAN-TEC-13 | `frmInformesTecnica` | PAN-TEC-47 |
| `abm_Cuadri_Particua` | PAN-TEC-13 | `frmInformes_Preview` | PAN-TEC-04 (Google Earth reemplazado, CTR-TEC-34) |
| `abm_Factibil_Notas` | PAN-TEC-02 | `frmInformes_Redes` | PAN-TEC-47 (REP-TEC-18) |
| `abm_GrpObra` | PAN-TEC-39 | `frmOT_Especial` | PAN-TEC-06 |
| `abm_Mikrotik` | PAN-TEC-35 | `frmOT_Notificaciones` | PAN-TEC-07 |
| `abm_Niv_Capa` | PAN-TEC-33 → 30 | `frmRedes_RedInstalada` | PAN-TEC-31 |
| `abm_Niv_Redes` | PAN-TEC-33 → 31 | `frmRedes_RedInstalada_Add` | PAN-TEC-31 |
| `abm_Niv_Serv` | PAN-TEC-33 → 30 | `frmRedes_RedInstalada_AddMultiple` | PAN-TEC-31 |
| `abm_Obras` | PAN-TEC-39 | `frmRedes_RedInstalada_ConexionNueva` | PAN-TEC-32 |
| `abm_Redes` | PAN-TEC-30 | `frmRedes_RedInstalada_Conexiones` | PAN-TEC-32 |
| `abm_Redes_Atributos_Componentes` | PAN-TEC-30 | `frmRedes_RedInstalada_EditAtributo` | PAN-TEC-31 |
| `abm_Redes_Capas` | PAN-TEC-30 | `frmRedes_Relaciones` | PAN-TEC-30 |
| `abm_Redes_Componentes` | PAN-TEC-30 | `frmRedes_Relaciones_Add` | PAN-TEC-30 |
| `abm_Resestad` | PAN-TEC-20 | `frmSincronizacionAION` | PAN-TEC-36 |
| `abm_ResolOt` | PAN-TEC-20 | `frmSincronizarCaptor` | PAN-TEC-10 (CTR-TEC-13) |
| `abm_ResponsaNotifica` | PAN-TEC-15 | `frmTecnica_AutorizarNecesidad` | PAN-TEC-09 |
| `abm_TareasOm` | PAN-TEC-21 | `frmTecnica_CambioCategoria` | PAN-TEC-06 |
| `abm_Tecnica` | PAN-TEC-05 | `frmTecnica_CambioEstado` | PAN-TEC-06 |
| `abm_Tecnica_Notas` | PAN-TEC-05 | `frmTecnica_CambioEstadoMasivo` | PAN-TEC-07 |
| `abm_Tecnica_Partiord` | PAN-TEC-05 | `frmTecnica_CambioMedidor` | PAN-TEC-06 |
| `abm_Tecnica_Tareas` | PAN-TEC-05 | `frmTecnica_Desconexion` | PAN-TEC-06 |
| `abm_Tptrab` | PAN-TEC-18 | `frmTecnica_Nexo` | PAN-TEC-38 |
| `abm_Transac` | PAN-TEC-17 | `frmTecnica_Reconexion` | PAN-TEC-06 |
| `frmActualizarGis` | PAN-TEC-34 | `frmTecnica_Translado` | PAN-TEC-06 |
| `frmBajaMasivaOrdenes` | PAN-TEC-08 | `frm_CambiosFactibilidad` | PAN-TEC-02 |
| `frmBajaMasivaOrdenes_Confirmar` | PAN-TEC-08 | `frm_Factibilidad` | PAN-TEC-01, 02 |
| `frmBuscadorFactibilidad` | PAN-TEC-01 | `frmImpresiones` | PAN-TEC-47, REP-TEC-23 |
| `frmCargaRapidaReclamo` | PAN-TEC-49 (reemplazado por M09) | `frmDatosInternet` | PAN-TEC-37 |
| `frmConsultar_Vales` | PAN-TEC-09 | | |

Controles: `ComandosDiscar`, `ComandosNexo` y `ComandosTelemedicion` → PAN-TEC-38 y RF-TEC-196. Enums: `EstadoTecnica`, `Estado_AbmTecnica` → §8.4; `Estados_Factibilidad` → §8.1; `OpcionesDesconexion` → `operationTypes` (efecto `disconnect` con opciones); `Origen` → `workOrders.origin`; `ModoFormulario` → descartado (mecánica de formularios de escritorio).
