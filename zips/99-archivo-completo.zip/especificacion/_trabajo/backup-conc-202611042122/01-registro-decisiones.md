# 01 — Registro de decisiones

Las decisiones del solicitante prevalecen sobre toda fuente (ver `00-ESPECIFICACION-MAESTRA.md` §2.2). IDs estables; una decisión que cambia se marca `Reemplazada por DEC-xxx` y no se borra.

| ID | Fecha | Pregunta | Opción elegida | Texto del solicitante | Fundamento / consecuencias | Estado |
|---|---|---|---|---|---|---|
| DEC-001 | 04-11-2026 | Stack tecnológico | Node + Mongo + Vue (Connectia) | — | Se reutilizan patrones y componentes de Connectia con sus mejoras [MEJORAR]. Reemplaza .NET/Azure/SQL Server de DFA. | Vigente |
| DEC-002 | 04-11-2026 | Modelo de tenancy | Base única compartida con identificador de cooperativa | "multitenant tradicional, una base de datos única con todo pero con identificadores de a qué cooperativa pertenecés" | `tenantId` obligatorio, índices compuestos con `tenantId` primero, plugin de filtro forzado, tenant del token. | Vigente |
| DEC-003 | 04-11-2026 | Estilo de arquitectura | Monolito modular | — | Outbox + BullMQ; fronteras de módulo estrictas. | Vigente |
| DEC-004 | 04-11-2026 | Nube | Agnóstico con Docker | — | AWS como referencia, sin dependencia de servicios propietarios no sustituibles. | Vigente |
| DEC-005 | 04-11-2026 | Piloto | Internet | — | Olas O2–O6 cierran Internet de punta a punta. | Vigente |
| DEC-006 | 04-11-2026 | Fechas | Olas sin fechas | — | Las fechas de DFA quedan sin efecto. | Vigente |
| DEC-007 | 04-11-2026 | Alcance de módulos marginales | Todos | — | Telefonía/CDR, TV, vivienda, salud/ambulancias/sepelio, fabricación, flota/GPS, turnero y agente de hardware en alcance. | Vigente |
| DEC-008 | 04-11-2026 | Modelo del muro | Editorial con comentarios moderados | — | Moderación IA + humana; habilitable por tenant y por publicación. | Vigente |
| DEC-009 | 04-11-2026 | Momento de la contabilidad | Núcleo temprano | — | Plan de cuentas, ejercicios, centros de costo y asientos automáticos en O5; resto en O8. | Vigente |
| DEC-010 | 04-11-2026 | Formato del entregable | Maestro + anexos + olas con prompts | — | Estructura `docs/especificacion/`. | Vigente |

## Decisiones sobre preguntas abiertas

| ID | Fecha | Pregunta | Decisión | Anexos afectados | Estado |
|---|---|---|---|---|---|
| DEC-011 | 04-11-2026 | PA-CAT-01 Momento de creación del contrato | Al admitir la solicitud en CRM, en estado Solicitado | M02, M09 | Vigente |
| DEC-012 | 04-11-2026 | PA-CAT-05 Jerarquía del catálogo | Servicio → producto (subservicio = producto adicional) → plan versionado → conceptos facturables | M02, M04, M05 | Vigente |
| DEC-013 | 04-11-2026 | PA-CAT-10 Modalidad de equipos | Configurable por plan; comodato por defecto en Internet y TV, valorizado en stock | M02, M13, M10 | Vigente |
| DEC-014 | 04-11-2026 | PA-CFG-P1-05 + PA-CFG-P3-04 Reconexión al pagar | Automática en servicios remotos al confirmarse el pago y sin deuda vencida del servicio; si requiere técnico, OT automática | M07, M08, M10 | Vigente |
| DEC-015 | 04-11-2026 | PA-CFG-P3-05 Pasarelas en O5 | Pagos360, Mercado Pago, SIRO y Red Link en O5; el resto Extensión en O11 | M07, T06 | Vigente |
| DEC-016 | 04-11-2026 | PA-VEN-08 Facturación de la instalación del piloto | En la primera factura del ciclo tras la OT confirmada (concepto vinculado) | M11, M05 | Vigente |
| DEC-017 | 04-11-2026 | PA-CFG-P1-01 Numeración de titulares | Secuencia única por tenant con atributo de tipo; número manual solo en migración | M01, T07 | Vigente |
| DEC-018 | 04-11-2026 | PA-CFG-P2-06 ARCA sin respuesta en mostrador | Espera del CAE con tiempo máximo; luego contingencia CAEA o comprobante pendiente no entregable como fiscal | M05, M06, M11 | Vigente |
| DEC-019 | 04-11-2026 | PA-INS-03 Ola del capital social | Mínimo en O5 (rubros, regla, facturado/pagado, estado de cuenta); resto O10 | M17, M05, M07 | Vigente |
| DEC-020 | 04-11-2026 | PA-CFG-P1-03 Claves de mapas e IA | Provistas por la plataforma, con opción de clave propia del tenant | T01, T06 | Vigente |
| DEC-021 | 04-11-2026 | PA-CAT-02 Habilitar y publicar servicios | Plataforma habilita según licencia; admin del tenant publica con aprobación de otro usuario en producción | M02, T01 | Vigente |
| DEC-022 | 04-11-2026 | PA-CAT-03 Apagar oferta con contratos vigentes | Cerrar oferta frena altas; cerrar operación exige plan de salida | M02 | Vigente |
| DEC-023 | 04-11-2026 | PA-CAT-04 Altas automáticas | Directas solo obligatorios con fundamento normativo; opcionales se proponen con consentimiento | M02, M01 | Vigente |
| DEC-024 | 04-11-2026 | PA-CAT-06 Banco de sangre | Solo administrativo por convenio, sin datos clínicos | M02, M18 | Vigente |
| DEC-025 | 04-11-2026 | PA-CAT-07 Copias entre tenants | Autorización explícita del tenant origen | M02, T01 | Vigente |
| DEC-026 | 04-11-2026 | PA-CAT-08 Plantillas de plataforma | Sí, sin precios ni condiciones reguladas | M02, T01 | Vigente |
| DEC-027 | 04-11-2026 | PA-CAT-09 Provisorio | Suministro transitorio con vencimiento obligatorio, facturable en esa condición | M02, M05 | Vigente |
| DEC-028 | 04-11-2026 | PA-CAT-11 Contratos iguales en una cuenta | Permitido en no medidos; en medidos uno por punto de suministro | M02, M03 | Vigente |
| DEC-029 | 04-11-2026 | PA-CAT-12 Deuda previa en el domicilio | Advertencia con autorización opcional; nunca bloqueo ni traslado de deuda | M02, M07 | Vigente |
| DEC-030 | 04-11-2026 | PA-CAT-13 Modalidades de gas | Red natural, propano por red y envasado, habilitables por tenant | M02, M03, M04 | Vigente |
| DEC-031 | 04-11-2026 | PA-CAT-14 Suspensión voluntaria | Configurable por servicio, deshabilitada por defecto | M02, M08 | Vigente |
| DEC-032 | 04-11-2026 | PA-CAT-15 Vigencia del cambio de plan | Próximo período; inmediato con prorrateo si el tenant lo habilita | M02, M04 | Vigente |
| DEC-033 | 04-11-2026 | PA-CAT-16 Hecho de activación | Confirmación técnica de instalación y aprovisionamiento; revisión del supervisor posterior | M02, M10, M05 | Vigente |
| DEC-034 | 04-11-2026 | PA-FAC-01 Modalidad de factura por defecto | Separada por servicio; agrupada multiservicio solo si se activa por grupo | M05 | Vigente |
| DEC-035 | 04-11-2026 | PA-FAC-04 Asignación del número fiscal | Al emitir, en orden del lote; si ARCA rechaza se reenvía el mismo número | M05, M06 | Vigente |
| DEC-036 | 04-11-2026 | PA-FAC-05 Factura con total negativo | Política por servicio; por defecto NC; generación distribuida como crédito a futuro | M05, M03 | Vigente |
| DEC-037 | 04-11-2026 | PA-FAC-06 Factura en cero | No emitir; registrar "sin cargo", configurable por servicio | M05 | Vigente |
| DEC-038 | 04-11-2026 | PA-FAC-19 Caída de ARCA en masiva | Emitir y encolar; pausar solo la autorización; CAEA si está habilitado | M05, M06, T06 | Vigente |
| DEC-039 | 04-11-2026 | PA-TEC-01 Cierre de OT | Dos pasos por defecto en altas, desconexiones, reconexiones y cambios de medidor; configurable por operación | M10 | Vigente |
| DEC-040 | 04-11-2026 | PA-TEC-04 Factibilidad obligatoria | Configurable por servicio; obligatoria por defecto en Internet y servicios con red | M10, M02 | Vigente |
| DEC-041 | 04-11-2026 | PA-TEC-09 Aprovisionamiento | Automático asíncrono vía conector con respaldo manual | M10, T06 | Vigente |
| DEC-042 | 04-11-2026 | PA-TEC-10 Sistemas de red del piloto | MikroTik, Radius y SmartOLT en O3 | M10, T06 | Vigente |
| DEC-043 | 04-11-2026 | PA-PER-01 Verificación del vínculo usuario-titular | Código de factura + documento, código al contacto o validación presencial, con intentos limitados | M01, M19, T02 | Vigente |
| DEC-044 | 04-11-2026 | PA-PER-02 Documento duplicado | Único por tenant, con excepción aprobada y auditada | M01 | Vigente |
| DEC-045 | 04-11-2026 | PA-PER-06 Deuda en cambio de titularidad | Queda en el saliente; el nuevo solo la asume por convenio | M01, M07, M08 | Vigente |
| DEC-046 | 04-11-2026 | PA-PER-13 Proveedor geográfico | Georef para normalizar/geocodificar; Google Maps para mapa y autocompletado | M01, T04, T06 | Vigente |
| DEC-047 | 04-11-2026 | Política de preguntas | Se preguntan solo las de alto impacto o que bloquean olas tempranas; las de detalle se asumen con la opción recomendada y quedan `Asumida (recomendada)` para revisión posterior | Todos | Vigente |
| DEC-048 | 04-11-2026 | PA-COB-01 Imputación de pagos | Por antigüedad, recargos/intereses primero, respetando elección explícita del socio o cajero | M07 | Vigente |
| DEC-049 | 04-11-2026 | PA-COB-03 Créditos entre servicios | Automático solo dentro del mismo servicio; entre servicios con elección o autorización | M07 | Vigente |
| DEC-050 | 04-11-2026 | PA-COB-09 Identificador de pago en la migración | Identificador nuevo autocontenido + resolución por clave ProCoop hasta vencer sus facturas | M07, M05, T07 | Vigente |
| DEC-051 | 04-11-2026 | PA-CFG-P1-04 Interés en pago online de factura vencida | Diferido a la próxima factura, configurable por canal | M07, M08 | Vigente |
| DEC-052 | 04-11-2026 | PA-CFG-P3-01 Plazo de prescripción de deuda | Plazos **por tipo de obligación** (`prescriptionRules`): **24 meses** para facturas periódicas de servicios (CCyC art. 2562 inc. c) y **60 meses** para el resto (ventas, cuotas de convenio, otros; CCyC art. 2560). Todo es editable por tenant y servicio y requiere validación legal (`validationStatus`) antes de la primera corrida productiva. *Revisada el 04-11-2026: el solicitante había elegido 5 años para todo y, ante la observación sobre el art. 2562, confirmó la diferenciación.* | M08, M07, T04b parte 3 | Vigente |
| DEC-053 | 04-11-2026 | PA-FIS-03 Certificado ARCA | La plataforma genera clave y CSR (clave privada en bóveda) y admite PFX existente | M06, T06 | Vigente |
| DEC-054 | 04-11-2026 | PA-FIS-09 Jurisdicciones de IIBB | Córdoba en O4; resto como configuración en O8 | M06 | Vigente |
| DEC-055 | 04-11-2026 | PA-CRM-06 Proveedor de WhatsApp | Meta Cloud API por defecto, adaptador para Trii | M09, T06, T09 | Vigente |
| DEC-056 | 04-11-2026 | PA-CRM-09 IA en atención | Clasificar/resumir/sugerir en O6; adjuntos en O10; apagada hasta aceptación del tenant | M09 | Vigente |
| DEC-057 | 04-11-2026 | PA-CRM-15 Botón de baja | Habilitado en Internet, TV y telefonía; configurable en otros; código en 24 h | M09, M19 | Vigente |
| DEC-058 | 04-11-2026 | PA-SUE-01 Estrategia de sueldos | O8 importación de liquidador externo; O9 liquidación propia con 2 períodos en paralelo | M16, M15, M14 | Vigente |
| DEC-059 | 04-11-2026 | PA-TES-16 Tesorería en O5 | Cuentas, rendición, depósitos, extractos y conciliación en O5; valores, cupones, retenciones e Interbanking en O8 | M14 | Vigente |
| DEC-060 | 04-11-2026 | PA-MED-08 Generación distribuida | Configurable por régimen; default compensación monetaria (Ley 27.424) | M03, M04, M05 | Vigente |
| DEC-061 | 04-11-2026 | PA-INS-02 Capital social en la factura | Renglón identificado en la factura del servicio con auxiliar separado y leyenda | M17, M05 | Vigente |
| DEC-062 | 04-11-2026 | PA-PLA-01 Región de alojamiento | AWS sa-east-1 (San Pablo) con cláusulas contractuales de transferencia internacional según la AAIP; diseño agnóstico de nube (DEC-008) | T01, T08 | Vigente |
| DEC-063 | 04-11-2026 | PA-PLA-02/03 Continuidad y niveles de servicio | Disponibilidad 99,5 % mensual; RPO ≤ 15 min; RTO ≤ 4 h por tenant y ≤ 8 h plataforma completa; p95 interactivo ≤ 800 ms; soporte lunes a viernes 8–18 con P1 24×7 | T01, T08 | Vigente |
| DEC-064 | 04-11-2026 | PA-PLA-14 Varias personas jurídicas por tenant | Sí: `legalEntities` del tenant (equivalente a `EMPRESAS` de ProCoop), gestionadas en T04, con emisión, contabilidad y sueldos por entidad; `legalEntityId` en los documentos económicos desde O0 | T01, T04, T05, M05, M06, M15, M16 | Vigente |
| DEC-065 | 04-11-2026 | PA-PLA-08/09 Modelo comercial y facturación del SaaS | Packs por tamaño + complementos con cupo por contratos activos; facturación con M05 bajo el tenant `PLATFORM` desde O5 y prefactura exportable en O1 | T01, M05 | Vigente |
| DEC-066 | 04-11-2026 | PA-IAM-01 Ingreso del socio | Contraseña o código OTP de 6 dígitos por correo/SMS habilitable por tenant; sin enlace mágico | T02, M19 | Vigente |
| DEC-067 | 04-11-2026 | PA-IAM-02 CiDi Córdoba | Mecanismo de proveedor federado en O1; CiDi habilitable por tenant al publicar el portal (O2); nivel mínimo 2 para vincular cuentas | T02, T06, M19 | Vigente |
| DEC-068 | 04-11-2026 | PA-MIG-04 Orden de reemplazo de ProCoop | Por etapas: corte comercial (M01–M09) primero; contabilidad, compras, stock, tesorería y sueldos siguen en ProCoop hasta el corte administrativo | T07 | Vigente |
| DEC-069 | 04-11-2026 | PA-CON-03 y PA-MIG-18 Contabilidad durante la convivencia | Oficial en ProCoop hasta el corte administrativo; GoodApps contabiliza en un plan marcado no oficial, concilia contra ProCoop y se oficializa en el corte | M15, T07 | Vigente |
| DEC-070 | 04-11-2026 | PA-MIG-01 Profundidad del histórico | Ejercicio en curso + 24 meses en estructuras tipadas; el resto en `legacyRecords` consultables; copia del origen conservada 10 años | T07 | Vigente |
| DEC-071 | 04-11-2026 | PA-SOC-14 Ola de adherentes | Adherentes y sus entradas a facturar (`billing-inputs`) en O4; el resto de M18 en O10 | M18, M05 | Vigente |
| DEC-072 | 04-11-2026 | Preguntas no consultadas (política DEC-047) | Toda PA de `02-preguntas-abiertas.md` marcada "Asumida (DEC-072)" adopta su opción recomendada; el usuario puede revisarla en cualquier momento | Todos | Vigente |
| DEC-073 | 04-11-2026 | Cómo queda especificado cada servicio de punta a punta | Nuevo anexo `T12-SRV-fichas-verticales-servicios.md`: una ficha por cada uno de los 17 dominios de M02 §6.C (INT, TEL, TV, ELE, AG, CLO, GAS, ALU, OBR, SEP, CEM, SAN, SAL, VIV, TAS, CAP, OTR) que recorre contrato, medición, tarifa, facturación, fiscal, cobro, mora, técnica, atención, portal, reportes y migración, con IDs exactos de cada anexo. Se arma cuando estén completos todos los anexos y sirve de control de cobertura | T12, M02–M19 | Vigente |
| DEC-074 | 04-11-2026 | PA-INT-02 Bóveda de secretos | Cifrado por sobre (envelope encryption) propio en MongoDB con clave maestra en AWS KMS, detrás de una interfaz agnóstica de proveedor; nunca se transcriben ni registran valores | T06, T01, T08 | Vigente |
| DEC-075 | 04-11-2026 | PA-NFR-03 Perfil de capacidad | Tenant estándar 25.000 suministros y grande 150.000; diseño para 100 tenants y hasta 300 sin rediseño | T08, T01 | Vigente |
| DEC-076 | 04-11-2026 | PA-NFR-07 Rol ante la Ley 25.326 | GoodApps es prestador de servicios de tratamiento por cuenta de la cooperativa (art. 25): contrato tipo de encargo, registro público de subencargados, destrucción o devolución al fin del encargo | T08, T01 | Vigente |
| DEC-077 | 04-11-2026 | PA-COM-04 Contratación de mensajería | Dos modelos: conector propio del tenant, o proveedor de plataforma revendido con consumo medido como complemento del pack (DEC-065) | T09, T06, T01 | Vigente |
| DEC-078 | 04-11-2026 | PA-INT-22 y PA-WFL-06 Firma de documentos | Firma electrónica con OTP por defecto (instalación, convenios, trámites); firma digital con proveedor licenciado solo para recibos de sueldo y actas (O8/O9); interfaz de firma propia y proveedor elegido antes de O3 | T11, T06, M16, M17 | Vigente |
| DEC-079 | 04-11-2026 | PA-WFL-04 Diseñador de trámites | El tenant ajusta plantillas de plataforma en puntos de extensión y crea trámites nuevos solo de tipo "solicitud genérica" que terminan en tarea o caso | T11 | Vigente |
| DEC-080 | 04-11-2026 | PA-WFL-05 Motor de PDF | HTML + CSS renderizado con Chromium sin interfaz en workers dedicados, con validación PDF/A posterior | T11, T03, T08 | Vigente |
| DEC-081 | 04-11-2026 | Cooperativa piloto | La cooperativa piloto (comercial y de migración) **no está definida**; los anexos la nombran "cooperativa piloto". Laguna Larga (`LAG`, base `PR_LAG_DEMO`) es solo la **base relevada de referencia** de ProCoop: sus configuraciones, formatos (Red Link, SIRO) y valores se usan para el mapeo, las pruebas de paralelo y los `[VERIFICAR]`, no como piloto. Los requisitos marcados para LAG aplican a toda cooperativa migrada con la misma configuración | T07, M07, T06, todos | Vigente |

Las siguientes decisiones (DEC-082 en adelante) se registrarán a medida que se respondan las preguntas de `02-preguntas-abiertas.md`.
