# M02 CAT — Catálogo de servicios, productos, planes, categorías, estados, contrato de servicio, habilitación por tenant, copia entre tenants y particularidades por servicio

| Campo | Valor |
|---|---|
| Versión | 1.0 |
| Estado | Especificación consolidada — pendiente de validar preguntas abiertas |
| Solución (BASE §105) | ERP (catálogo y contrato de servicio) / CRM (consumidor de oferta y estados) / Landing-autogestión (oferta pública y "Mis servicios") / Plataforma (catálogo global de capacidades y habilitación por tenant) |
| Olas | O2 (núcleo: catálogo, habilitación, perfil, productos, planes, categorías, estados, contrato, copia entre tenants, oferta en landing/PWA), O3 (activación de Internet, equipos en comodato), O4 (estructura de conceptos facturables consumida por tarifas y facturación, tasas por cuenta de terceros, telefonía básica como abono), O7 (fichas de Electricidad, Agua, Cloacas, Gas, Alumbrado, obras, generación distribuida, grandes usuarios, recategorización por segmentación), O10 (Sepelio, Cementerio parque, Banco de sangre, Salud/ambulancias, Vivienda, Telefonía con CDR, TV, adherentes y beneficiarios, Capital social como concepto), O11 (migración repetible) |
| Dueño de datos | `serviceCapabilities`, `tenantServices`, `serviceConfigVersions`, `serviceConcessions`, `serviceProducts`, `billableConcepts`, `servicePlans`, `servicePlanVersions`, `serviceBundles`, `serviceCategories`, `serviceCategoryGroups`, `serviceClasses`, `serviceProperties`, `serviceStatuses`, `eventChargeRules`, `eventChargeWaivers`, `autoServiceRules`, `serviceContracts`, `serviceContractHistory`, `contractEquipmentAssignments`, `contractMembers`, `applianceTypes`, `contractDeclaredAppliances`, `generationAgreements`, `contractSpecialConditions`, `serviceCopyRuns`, `bulkContractOperations`, `serviceTemplates` |
| Fuentes consolidadas | BASE §1 (servicios habilitables, configuración independiente, titularidad y particularidades — líneas 99-116), §5 (CU-05), §32, §37, §39.2, §48 (SOL-001/002, CU-SOL-01, en lo que define el servicio), §53 (CIC-001..004, CU-CIC-01, en lo que define estados), §66 (CAT-001..003, CU-CAT-01), §71, §72 (PRO-001..004, CU-PRO-01), §74, §80, §81 (COP-001..003, CU-COP-01), §84, §85, §86, §87 (CU-ESP-ELE), §88 (CU-ESP-AG), §89 (CU-ESP-GAS), §90 (CU-ESP-CEM), §91 (CU-ESP-SAN), §92, §93 (ESP-001..006), §94 (ESP1–ESP28), §95, §98, §101, §106, §102 MER-001 (CU-MER-01), MER-003, MER-017 · AGR-002, AGR-003, AGR-005, AGR-009, AGR-010, AGR-017 · DFA M4 (catálogo de servicios, categorías y conexiones), DFA M25 (telefonía, Internet, vivienda, salud como servicios) · REL "Administración de Servicios" (ficha del servicio) · RN-01 §2 (tipos de cálculo `TIP_CAL`, condición del servicio), RN-01 §9 (adherentes), RN-01 §10 (telefonía) · RN-06 §3 (altas, validaciones, configuración, guardado, altas automáticas, conceptos por conexión), §4 (estados, conexión/desconexión, trámites masivos), §5 (bajas de socio, en lo relativo a servicios), §6 (cambios de categoría y clase, segmentación), §7 (transferencias), §8 (domicilios del servicio), §10 (adherentes y beneficiarios), §11 (grupos de facturación) · RN-09 §6.4 parámetros TITULARES y VENTAS_Y_FACTURACION relativos a servicios · CAT §1 (tablas `SERSOC*`, `ADHSOC`, `BENSOC`, `VINCULOS`), CAT §2 completa (Servicios, categorías y tarifas), CAT §12 (Telefonía e Internet, en lo que define servicios TIC como productos) · INV `Configuracion.md` (abm_Servicio y afines), `ProMod_Titulares.md`, `ProMod_Facturacion.md` · CNX §2.4 (licencia/activación/pantallas/alcance; "un renglón en Suscriptores = un producto que se vende"), §4.2, §4.3 |

---

## 1. Objetivo

Definir, sin necesidad de programar, **qué servicios puede prestar cada cooperativa (tenant), con qué productos, planes, categorías, conceptos facturables, requisitos, estados y reglas propias**, y administrar el **contrato de servicio** (suscripción) que vincula a un titular identificado por DNI/CUIT con una prestación concreta, desde que se solicita hasta su baja, conservando la historia completa.

El módulo resuelve cuatro necesidades del solicitante:

1. **Catálogo de capacidades de plataforma y habilitación por tenant** (BASE §66, CAT-001..003): cada cooperativa enciende un conjunto distinto de servicios (Agua, Electricidad, Cementerio parque en una; Electricidad y Gas en otra), y esa selección determina qué ve su comunidad en landing, PWA y administración.
2. **Configuración independiente por servicio y tenant, y copia entre tenants** (BASE §81, COP-001..003): cada servicio tiene un perfil de configuración propio (BASE §84) y puede copiarse como base a otra cooperativa sin copiar datos operativos.
3. **Composición económica estructural** (BASE §72, PRO-001..004): servicio → producto/subservicio → plan/oferta (versionada) → conceptos facturables y reglas → condiciones congeladas del contrato. Los **importes y el motor de cálculo** pertenecen a M04 TAR; este módulo define la estructura y el vínculo al cuadro tarifario.
4. **Particularidades por dominio** (BASE §84–95, DEC-007): fichas para Internet (piloto, DEC-005), Telefonía, TV/cable, Energía, Agua, Cloacas, Gas, Alumbrado público, Pavimento/obras, Sepelio, Cementerio parque, Banco de sangre, Ambulancias/salud, Vivienda, Tasas por cuenta de terceros, Capital social como concepto y otras prestaciones (banco ortopédico, traslados, seguro, vehículo eléctrico, dispenser de agua, correo electrónico, pack SMS), sin forzar todas en una fórmula universal P × Q.

El resultado esperado es que el piloto Internet (contratación → factibilidad → instalación → equipo en comodato → activación → facturación → mora/suspensión → baja) funcione extremo a extremo sobre este catálogo y que cualquier otro servicio de ProCoop pueda configurarse luego sin cambiar el núcleo.

## 2. Límite y responsabilidades

### 2.1 Qué hace

- Mantiene el **catálogo global de capacidades de servicio** (tenant `PLATFORM`) y la **habilitación por tenant** dentro de lo licenciado.
- Mantiene, por tenant y servicio, el **perfil de configuración** (13 dimensiones de BASE §84) versionado y publicable de forma íntegra (AGR-009).
- Mantiene **productos, subservicios, conceptos facturables (estructura), planes y sus versiones, paquetes, categorías, grupos de categorías, clases, propiedades, estados operativos, reglas de conceptos por evento, bonificaciones de conexión y reglas de altas automáticas**.
- Es **dueño del contrato de servicio** (`serviceContracts`): su creación, condiciones contratadas, estado canónico y operativo, fechas solicitadas y efectivas, flags, cambios de plan/categoría/clase, transferencias, traslado del domicilio del servicio, adherentes/beneficiarios, equipos asignados en comodato, declaración de artefactos, vínculos de generación distribuida y condiciones especiales de grandes usuarios (AGR-002).
- Ejecuta las **transiciones de estado** del contrato cuando recibe el comando del módulo que corresponde (CRM, Técnica, Mora) o la confirmación del hecho (instalación, desconexión), y publica eventos.
- Ejecuta la **copia de configuración de servicio entre tenants** (BASE §81).
- Expone la **oferta** a landing y PWA y la vista **"Mis servicios"** del socio.

### 2.2 Qué NO hace y a quién lo delega

| Tema | Responsable | Qué consume/expone CAT |
|---|---|---|
| Precios, cuadros tarifarios, tramos, coeficientes, cargos adicionales con fórmulas, descuentos, recargos, tarifas de adherentes, promociones (cálculo), prorrateos, motor P×Q y tipos de cálculo | **M04 TAR** | CAT declara `calculationType`, conceptos, categorías y el vínculo plan/categoría → cuadro tarifario por vigencia. |
| Emisión de comprobantes, ciclos, lotes, grupos de facturación (definición), cuentas no facturables a nivel cuenta | **M05 FAC** | CAT guarda en el contrato el grupo de facturación asignado y el flag `doNotBill`; FAC lee contratos facturables. |
| IVA, percepciones, tasas e impuestos, tratamiento fiscal de cada concepto, padrones | **M06 FIS** | CAT referencia la clase fiscal del concepto. |
| Cuenta corriente, cobranza, reconexión automática por pago | **M07 COB**, **M08 MOR** | CAT recibe órdenes de suspensión/reactivación de MOR. |
| Mora, suspensión por deuda (política), corte, convenios, financiación (cronograma) | **M08 MOR** | CAT define en el plan si existe opción de financiación de instalación (estructura); MOR genera el cronograma. |
| Circuito de solicitud de alta/baja/cambio, tickets, botón de baja, conversación | **M09 CRM** | CAT expone oferta, requisitos y contrato; recibe "solicitud admitida/desistida". |
| Factibilidad, visitas, órdenes de trabajo, instalación, aprovisionamiento de red (MikroTik/Radius/OLT), numeración telefónica, CDR, centrales, red | **M10 TEC** | CAT pide factibilidad/instalación/desconexión y recibe confirmación; guarda solo referencias técnicas no secretas. |
| Medidores, lecturas, consumos, demandas por período, factores de corrección, telemedición, prepago | **M03 MED** | CAT asocia el contrato al punto de suministro; MED vincula medidor. |
| Stock, unidades serializadas, depósitos, valorización de equipos, RMA | **M13 STK** | CAT registra la **asignación** del equipo al contrato (comodato); STK es dueño de la unidad. |
| Personas, titulares, cuentas, inmuebles, domicilios postales, vínculos de parentesco (catálogo), fallecimiento | **M01 PER** | CAT usa `personId`, `accountId`, `propertyId`. |
| Registro físico de parcelas, inhumaciones, convenios de banco de sangre, expedientes de vivienda, traslados de ambulancia | **M18 SOC** | CAT define el servicio, productos, planes y contrato; SOC opera el dominio. |
| Capital social, asociados, rescate | **M17 INS** | CAT define el concepto facturable de capital; INS lleva el libro. |
| Licencias SaaS de módulos de plataforma, packs, ciclo de vida del tenant | **T01 PLA** | CAT solo habilita servicios cuya capacidad está licenciada. |
| Roles, capabilities, alcance | **T02 IAM** | CAT declara sus capabilities. |
| Diccionario, branding | **T03 UXD** | Etiquetas por `dict:`. |
| Parámetros versionados, tablas maestras, geografía | **T04 CFG** | CAT registra sus parámetros en el catálogo de T04. |
| Workflow de autorizaciones, expediente documental | **T11 WFL** | Aprobaciones de publicación y documentos del contrato. |
| Asientos contables | **M15 CON** | CAT emite eventos con referencias contables mapeadas. |

### 2.3 Principios de frontera

- **Solicitar no equivale a ejecutar** (BASE §48): un caso CRM nunca cambia por sí solo el estado del contrato; CAT confirma el cambio efectivo y FAC calcula consecuencias (AGR-002).
- **Encender no contrata** (BASE §66): habilitar o publicar un servicio no crea contratos ni obligaciones para los usuarios del tenant (BASE §81).
- **Apagar no borra** (BASE §66, AGR-005): deshabilitar una oferta no da de baja contratos, no oculta facturas ni elimina expedientes.
- **Copiar no es publicar** (BASE §81).

## 3. Glosario del módulo

| Término | Definición | Clave de diccionario | Equivalente ProCoop |
|---|---|---|---|
| Capacidad de servicio | Dominio funcional que la plataforma sabe gestionar (Internet, Agua, Cementerio parque…), con su perfil de registración y tipos de cálculo soportados. | `dict:cat.capability` | (no existe; ProCoop instala todo) |
| Servicio del tenant | Habilitación y configuración de una capacidad en una cooperativa; es lo que se oferta a su comunidad. | `dict:cat.tenantService` | `SERVICIO` |
| Dominio de servicio | Clasificación funcional de la capacidad (INT, TEL, TV, ELE, AG, CLO, GAS, ALU, OBR, SEP, CEM, SAN, SAL, VIV, TAS, CAP, OTR). | `dict:cat.domain` | `TIP_SERVI` (aproximado) |
| Perfil de configuración | Conjunto de definiciones por tenant y servicio en las 13 dimensiones de BASE §84. | `dict:cat.configProfile` | Flags de `SERVICIO` y `SERVICIO_EXTRAS` |
| Versión de configuración | Paquete coherente de cambios de un servicio con validaciones, simulación y fecha efectiva (AGR-009). | `dict:cat.configVersion` | `HIS_SERVICIO`, `HIS_SERVICIO_EXTRAS` (por cuadro) |
| Producto / subservicio | Oferta identificable dentro de un servicio (Fibra hogar, Línea fija, Parcela). Un subservicio es un producto adicional o componente (IP fija, decodificador adicional). | `dict:cat.product` | `PROD_SER` (parcial), `TEL_SERVICIO`, `SERTEL` |
| Concepto facturable | Elemento económico individualizable (instalación, abono, cargo por evento, cuota, ajuste, tasa de tercero, capital). Su precio vive en TAR. | `dict:cat.billableConcept` | `PROD_SER` (productos/conceptos) |
| Plan / oferta | Combinación comercial versionada de producto, componentes, requisitos y condiciones. | `dict:cat.plan` | Categoría + productos (no hay plan explícito) |
| Paquete | Combinación de planes de distintos servicios ofrecida en conjunto. | `dict:cat.bundle` | (no existe) |
| Categoría | Clasificación tarifaria/regulatoria del suministro o contrato (Residencial, Comercial, Alumbrado público, Jubilados). | `dict:cat.category` | `CATE_SER` |
| Grupo de categorías | Agrupación de categorías con código regulatorio (ej. ENARGAS). | `dict:cat.categoryGroup` | `GRP_CAT` |
| Clase de servicio | Clasificación complementaria con valores asociados (ej. tasa hospital, tipo de suministro). | `dict:cat.serviceClass` | `CLASESER` |
| Propiedad del servicio | Atributo técnico-comercial del suministro (tensión, mínimos, cargo fijo asociado). | `dict:cat.serviceProperty` | `PROPIESER` |
| Contrato de servicio | Vínculo entre un titular (DNI/CUIT), una cuenta, un servicio/plan y un punto de prestación, con estado y condiciones. | `dict:cat.contract` | `SERSOC` (servicio de la cuenta) |
| Estado canónico | Estado del contrato controlado por el sistema (Solicitado, Activo, Suspendido, Baja…). | `dict:cat.contract.lifecycle` | `CONDICION` (derivada de fechas) |
| Estado operativo | Estado configurable por servicio que se muestra y opera (CONECTADO, CORTADO, BAJA…) mapeado a un estado canónico. | `dict:cat.contract.operationalStatus` | `ESTASER` |
| Alta administrativa / técnica | Fecha en que se carga el contrato / fecha efectiva de conexión. | `dict:cat.contract.adminStart` / `dict:cat.contract.effectiveStart` | `ALTA_ADM` / `FEC_ALTA` |
| Baja administrativa / efectiva | Fecha de solicitud o decisión de baja / fecha efectiva de desconexión. | `dict:cat.contract.terminationRequested` / `dict:cat.contract.effectiveEnd` | `BAJA_ADM` / `FEC_BAJA` |
| Servicio técnico | Servicio cuyas altas y bajas se ejecutan por orden de trabajo. | `dict:cat.requiresWorkOrder` | `SERVICIO.TECNICA` |
| Equipo en comodato | Bien entregado al titular en préstamo vinculado al contrato, con devolución. | `dict:cat.equipmentLoan` | `SERSOC_PRODUCTOS` |
| Adherente | Persona vinculada a un contrato que cuenta para la categoría o la tarifa (sepelio, salud). | `dict:cat.member.adherent` | `ADHSOC` |
| Beneficiario | Persona que goza de un beneficio o cobertura del contrato (banco de sangre, tarifa social). | `dict:cat.member.beneficiary` | `BENSOC` |
| Carencia | Período desde el alta durante el cual una cobertura no rige. | `dict:cat.waitingPeriod` | `SERVICIO_EXTRAS.CARENCIA` |
| Regla de alta automática | Regla que, ante un evento, propone o crea otro contrato (ej. alumbrado al conectar energía). | `dict:cat.autoRule` | `ALTASEAU` |
| Concepto por evento | Cargo estructural que se genera al alta, reconexión, transferencia u OT. | `dict:cat.eventCharge` | `CONEXION` |
| Copia de servicio | Creación en un tenant destino de una configuración independiente tomada de otro tenant. | `dict:cat.serviceCopy` | (no existe; una base por cooperativa) |
| Matrícula | Identificador del punto de suministro del servicio, único por servicio salvo parámetro. | `dict:cat.contract.supplyCode` | `SERSOC.MATRICULA` |
| ZSR | Zona, sector y recorrido del servicio (ruta de lectura/reparto). | `dict:cat.contract.route` | `ZONA/SECTOR/RECORRIDO` |
| Provisorio | Contrato de carácter transitorio (ver PA-CAT-09). | `dict:cat.contract.provisional` | Marca "Provisorio" |
| Alta desde portal | Contrato originado por autogestión. | `dict:cat.contract.originPortal` | "Alta desde CoopOnline" |

## 4. Actores, permisos y alcance

| Rol | Capabilities | Alcance de datos |
|---|---|---|
| Operador de plataforma (GoodApps) | `cat.capacidades.ver`, `cat.capacidades.crear`, `cat.capacidades.editar`, `cat.habilitacion.ver`, `cat.habilitacion.configurar`, `cat.plantillas.crear`, `cat.plantillas.editar`, `cat.copias.ejecutar`, `cat.copias.leerOrigen` (con autorización del tenant origen, PA-CAT-07) | Tenant `PLATFORM`; datos de configuración de tenants autorizados; nunca datos personales de contratos |
| Administrador del tenant | `cat.servicios.ver`, `cat.servicios.configurar`, `cat.servicios.publicar`, `cat.servicios.retirar`, `cat.versiones.crear`, `cat.versiones.aprobar`, `cat.estados.configurar`, `cat.reglasAuto.configurar`, `cat.copias.ejecutar` (como destino), `cat.copias.autorizarOrigen` | Tenant |
| Responsable comercial | `cat.productos.ver/crear/editar`, `cat.planes.ver/crear/editar/publicar/discontinuar`, `cat.paquetes.*`, `cat.categorias.ver/crear/editar`, `cat.clases.*`, `cat.propiedades.*`, `cat.conceptos.ver/crear/editar`, `cat.versiones.crear` | Tenant / servicios asignados |
| Responsable fiscal/contable | `cat.conceptos.ver`, `cat.conceptos.configurarFiscal`, `cat.versiones.aprobar` (cambios fiscales) | Tenant |
| Operador de atención / comercial de mostrador | `cat.contratos.ver`, `cat.contratos.crear`, `cat.contratos.editar`, `cat.contratos.solicitarBaja`, `cat.contratos.cambiarPlan`, `cat.adherentes.ver/crear/editar`, `cat.comodatos.ver` | Sucursales / servicios asignados |
| Supervisor comercial | Todo lo anterior + `cat.contratos.activar` (servicios no técnicos), `cat.contratos.suspender`, `cat.contratos.reactivar`, `cat.contratos.baja`, `cat.contratos.anular`, `cat.contratos.transferir`, `cat.contratos.cambiarCategoria`, `cat.contratos.forzarAdvertencia`, `cat.masivos.ejecutar` | Sucursales / servicios |
| Técnico / coordinador técnico (vía M10) | `cat.contratos.ver`, `cat.comodatos.asignar`, `cat.comodatos.devolver`; las transiciones las ejecuta el sistema al cerrar la OT | Zonas / cuadrillas |
| Proceso del sistema (workers) | Identidad técnica con `cat.contratos.transicionSistema`, `cat.reglasAuto.ejecutar` | Tenant del job |
| Socio / titular (PWA) | `cat.misServicios.ver`, `cat.oferta.ver`; inicia solicitudes vía CRM | Propios (contratos donde es titular o representante vigente, AGR-007) |
| Visitante (landing) | Oferta pública sin login | Servicios publicados del tenant |
| Auditor | `cat.*.ver`, `cat.auditoria.ver` | Tenant |

Reglas: denegación por defecto; alcance por servicio obligatorio para contratos de dominios sensibles (Banco de sangre, Salud): un supervisor de Agua no ve beneficiarios de Banco de sangre (AGR-008). Toda transición de contrato verifica permiso **y** alcance en servidor.

## 5. Requisitos funcionales

### 5.1 Catálogo de plataforma y habilitación por tenant

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-CAT-001 | Mantener un catálogo global de capacidades de servicio con código, nombre (dict), dominio, descripción, estado (`draft`, `available`, `deprecated`), madurez (`confirmed`, `candidate`), perfiles de registración y tipos de cálculo soportados, capacidades técnicas asociadas y ficha de dominio. | BASE §66 CAT-001, §92 | Núcleo | O2 | Informado | Plataforma crea INT y lo marca `available`; un tenant no lo ve hasta habilitarlo. |
| RF-CAT-002 | Habilitar y deshabilitar capacidades por tenant con fecha desde/hasta, solo si el tenant tiene la licencia correspondiente (T01). | BASE §66 CAT-001, AGR-005, CNX §2.4 | Núcleo | O2 | Informado | Intentar habilitar Gas sin licencia devuelve 409 con explicación de dependencia de licencia. |
| RF-CAT-003 | Distinguir tres niveles: capacidad de plataforma, servicio habilitado/ofertado por el tenant y contrato de una persona. | BASE §66 | Núcleo | O2 | Informado | Habilitar Agua en TEN-001 no crea ningún contrato. |
| RF-CAT-004 | Definir por separado disponibilidad para nuevas contrataciones (`offerStatus`) y operación de contratos existentes (`operationStatus`). | BASE §66 | Núcleo | O2 | Informado | Con oferta cerrada, landing no muestra el servicio pero los contratos activos siguen facturándose. |
| RF-CAT-005 | Al retirar una oferta, exigir que el administrador declare el alcance (solo nuevas contrataciones / cierre total con plan de salida) y no borrar contratos, documentos, deuda ni casos. | BASE §66, §71, AGR-005 | Núcleo | O2 | A validar (PA-CAT-03) | Retirar Agua de A deja contratos activos visibles y facturables. |
| RF-CAT-006 | Auditar toda habilitación, deshabilitación, publicación, retiro y modificación de alcance con actor, fecha, antes/después. | BASE §66, §54 GOB-004 | Núcleo | O2 | Informado | Cada cambio genera registro de auditoría consultable. |
| RF-CAT-007 | Reflejar la selección del tenant en landing, contratación, apps y pantallas de administración según perfiles. | BASE §66 CAT-002 | Núcleo | O2 | Informado | Un usuario de B ve solo Electricidad y Gas (CU-CAT-01). |
| RF-CAT-008 | Incluir Cementerio parque como prestación distinta de servicios sociales, sin equivalencia con consumo medido ni con sepelio. | BASE §66 CAT-003, §90 | Estándar | O2 (catálogo) / O10 (operación) | Informado | Existe capacidad CEM separada de SEP y SOC. |
| RF-CAT-009 | Registrar por dominio si es servicio confirmado por el solicitante o candidato investigado, y la documentación prioritaria pendiente para pasar a configuración real (BASE §95). | BASE §92, §95 | Estándar | O2 | Informado | La ficha de capacidad muestra madurez y checklist de insumos. |
| RF-CAT-010 | Ofrecer como capacidades todos los dominios que ProCoop gestiona: Internet, Telefonía fija, Telefonía móvil, Pack SMS, TV/cable, Energía eléctrica, Agua, Cloacas, Gas, Alumbrado público, Pavimento/obras (cuotas de obras), Sepelio, Subsidio por fallecimiento, Cementerio parque, Banco de sangre, Ambulancias/salud, Vivienda, Seguro, Vehículo eléctrico, Dispenser de agua, Correo electrónico, Banco ortopédico, Traslados, Tasas por cuenta de terceros y Capital social como concepto. | DEC-007, DFA M4, M25, RN-06 §3.3, BASE §92 | Estándar | según ficha | Adoptado | El catálogo de plataforma contiene las 25 capacidades con ficha. |
| RF-CAT-011 | Permitir marcar un servicio principal del tenant (por defecto en búsquedas, reportes y altas). | RN-09 V2 573 | Estándar | O2 | Adoptado | La ficha de cuenta abre por defecto el servicio principal. |
| RF-CAT-012 | Mantener tipos de servicio (agrupador de reporte) configurables por tenant, independientes del dominio. | CAT `TIP_SERVI` | Extensión | O2 | Adoptado | Un reporte agrupa contratos por tipo "Energía y conexos". |

### 5.2 Perfil de configuración por servicio

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-CAT-013 | Mantener por tenant y servicio un perfil de configuración en las 13 dimensiones: prestador y jurisdicción, titularidad, unidad de prestación, oferta, cantidad, excepciones, facturación, cuenta y pago, ciclo comercial, operación, cambios y salida, atención, control. | BASE §84 | Núcleo | O2 | Informado | La ficha de servicio tiene una pestaña por dimensión y cada una admite "No aplica". |
| RF-CAT-014 | Registrar prestador y jurisdicción: modalidad (prestación directa, subdistribución, convenio, intermediación administrativa), autoridad de aplicación/regulador, título habilitante, concesión, fuente normativa, jurisdicción y vigencia de cada configuración regulada. | BASE §84, §85, ESP-005, CAT `CONCESIO` | Núcleo | O2 | Informado | No se publica un servicio regulado sin autoridad y título habilitante cargados. |
| RF-CAT-015 | Definir la unidad de prestación del servicio (conexión, suministro, punto de medición, cobertura, parcela/unidad, acto, línea, grupo/beneficiario, plan de vivienda, cuota de obra) sin equivalencias automáticas entre dominios. | BASE §84, §93 | Núcleo | O2 | Informado | CEM usa unidad "derecho/unidad de sepultura" y no admite lectura. |
| RF-CAT-016 | Asignar al servicio un perfil de registración que determina qué datos y pestañas pide el contrato (medidor, adherentes, dispositivos, línea, perfil Internet, vivienda, seguro, cuotas de obra, vehículo eléctrico, cantidad). | RN-06 §3.3 `TipoRegistracion` | Núcleo | O2 | Adoptado | Un servicio con perfil "Adherentes" muestra la pestaña de adherentes y oculta la de medidor. |
| RF-CAT-017 | Declarar el tipo de cálculo del servicio (17 tipos de ProCoop más los nuevos que defina TAR) y su variante para grandes clientes; el algoritmo lo ejecuta TAR. | RN-01 §2, RN-06 §3.3 | Núcleo | O2 (declaración) / O4-O7 (motor) | Adoptado | Cambiar el tipo de cálculo exige nueva versión de configuración y simulación TAR. |
| RF-CAT-018 | Configurar los requisitos de alta del contrato: domicilio del servicio, fecha de alta (salvo servicio técnico), categoría, cantidad/dispositivos, matrícula, designación catastral, inmueble, actividad, clase, zona/sector/recorrido, dispositivo, factibilidad previa, garante, profesional/certificado, referencia, zona, propiedades, grupo contable; cada requisito con modo `noExigir`/`advertir`/`exigir`. | RN-06 §3.2, V2 213, 319, 343, 2050, 2343, 2462, 2529, 2738 | Núcleo | O2 | Adoptado | Con factibilidad en `exigir`, el alta sin factibilidad aprobada se rechaza con mensaje. |
| RF-CAT-019 | Marcar si el servicio es técnico (altas, bajas, reconexiones y cambios por orden de trabajo), si genera OT automáticamente al guardar, si consulta dar baja administrativa al generar OT de desconexión y qué tipo de operación técnica corresponde a cada evento (alta, baja, reconexión, cambio de categoría, transferencia, cambio de estado). | RN-06 §3.3, §4.2, §6, V2 332, 2330, 3194 | Núcleo | O2 | Adoptado | En INT técnico, aprobar el alta crea pedido de instalación a TEC y el contrato queda Pendiente de instalación. |
| RF-CAT-020 | Configurar grupo de facturación por defecto del servicio y su herencia en altas automáticas; el valor "sin grupo" es inválido. | RN-06 §3.2 paso 5, §3.5, §11 | Núcleo | O2 | Adoptado | Un contrato sin grupo de facturación no puede pasar a Activo. |
| RF-CAT-021 | Declarar para servicios medidos: medidor registrado en stock, lectura inicial al conectar, facturar sin consumo (cobrar cargo fijo), servicio relacionado cuyo consumo se usa (ej. cloaca sobre agua) y modo de división de consumo; la ejecución pertenece a MED/TAR. | RN-06 §3.3, RN-01 §2, V2 2701, 3143 | Estándar | O7 | Adoptado | CLO configurado con servicio relacionado AG; TAR toma lecturas de AG de la misma cuenta. |
| RF-CAT-022 | Declarar si el servicio admite adherentes y/o beneficiarios, exclusiones de cómputo (menores del último año, mayores, personas con discapacidad, jubilados), carencia, recategorización por edad del titular y si se exige adherente titular. | RN-01 §9, RN-06 §10, CAT `SERVICIO` (ADHER, BENEF, MENORES, MAYORES, DISCAPA, JUBILAD), `SERVICIO_EXTRAS.CARENCIA`, V2 109 | Estándar | O10 | Adoptado | Un sepelio con carencia 6 meses muestra la fecha de inicio de cobertura de cada adherente. |
| RF-CAT-023 | Configurar el estado operativo por defecto que asume el contrato en cada evento: alta, baja, reconexión, cambio de medidor, transferencia, desconectado, y selección automática del estado principal al dar de alta. | CAT `SERVICIO_EXTRAS` (COD_EST_*), V2 2435 | Núcleo | O2 | Adoptado | Al confirmar la instalación el contrato toma el estado operativo configurado para "alta". |
| RF-CAT-024 | Configurar documentos y plantillas por servicio: contrato de alta, fianza del servicio, informe/constancia de baja, formulario de desconexión, DDJJ (artefactos), constancia de entrega y devolución de equipos; y si se consulta imprimir/enviar al dar de alta o baja. | RN-09 V2 206, 2522, 2532, 2535, 2742, 2781 | Estándar | O2 | Adoptado | Al activar INT se genera la constancia de alta con la versión de condiciones. |
| RF-CAT-025 | Configurar canales habilitados por servicio y operación: landing, PWA, mostrador, teléfono, bot, botón de baja público. | BASE §48, §53, §66 | Núcleo | O2 | Informado | Si INT tiene baja por PWA habilitada, el socio ve "Solicitar baja" en su contrato. |
| RF-CAT-026 | Referenciar por servicio los motivos y tiempos de atención aplicables (catálogo en CRM), incluidos los plazos diferenciados por motivo de ENACOM para TIC. | BASE §84 Atención, §86 | Estándar | O2 | Informado | INT referencia motivos técnico/facturación/otros con plazos distintos. |
| RF-CAT-027 | Mapear por servicio área responsable, centro de costos, cuentas contables, depósito de equipos y sucursales, usando entidades del tenant. | BASE §81, §84 | Núcleo | O2 (estructura) / O5 (contable) | Informado | La publicación se detiene si falta la equivalencia contable (AGR-009). |
| RF-CAT-028 | Representar las diferencias por configuración y componentes de dominio explícitos; prohibido convertir particularidades en texto libre o forzarlas en P × Q. | BASE §84 | Núcleo | O2 | Informado | Las fichas de dominio exponen atributos tipados, no un campo "observaciones regulatorias". |
| RF-CAT-029 | Permitir marcar "No aplica" en cualquier dimensión o concepto que no corresponda al dominio, en lugar de forzar un cargo o proceso ficticio. | BASE §93 | Núcleo | O2 | Informado | SAN marca "Cantidad: No aplica". |
| RF-CAT-030 | Declarar permisos y operaciones admitidas por servicio: suspensión voluntaria (sí/no, duración máxima), reactivación, cambio de plan, cambio de titular, transferencia, traslado, baja parcial, cesión (CEM). | BASE §53, §84 Cambios y salida | Núcleo | O2 | Informado | Si CEM no admite baja por botón, la PWA muestra "Consultar trámite" (BASE §90). |

### 5.3 Versionado y publicación

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-CAT-031 | Agrupar los cambios de un servicio en una versión de configuración con dependencias, validaciones, simulación, revisión, aprobación y fecha efectiva. | AGR-009, BASE §5 | Núcleo | O2 | Adoptado | Una versión no aprobada no afecta landing ni contratos. |
| RF-CAT-032 | Clasificar cada cambio como comercial, fiscal, técnico o de presentación; un cambio solo de etiqueta no exige revisión tarifaria. | AGR-009 | Estándar | O2 | Adoptado | Corregir una etiqueta publica sin simulación TAR. |
| RF-CAT-033 | Publicación íntegra: impedir publicar un plan sin precio vigente en TAR, sin equivalencia contable, con referencias al tenant origen o con impuestos no configurados. | AGR-009 | Núcleo | O2 | Adoptado | Publicar INT-100 sin cuadro tarifario vigente devuelve lista de bloqueos. |
| RF-CAT-034 | Conservar fecha efectiva y fecha de registro de cada versión y cambio; consultar la configuración vigente a una fecha. | AGR-010, CAT `HIS_SERVICIO`, `HIS_SERVICIO_EXTRAS` | Núcleo | O2 | Adoptado | Consultar INT "a 01-03-2026" devuelve la versión entonces vigente. |
| RF-CAT-035 | Exigir aprobación de un segundo usuario para publicar versiones con cambios comerciales o fiscales en producción (configurable). | AGR-008, AGR-009, BASE §39.1 | Estándar | O2 | A validar (PA-CAT-02) | El autor no puede aprobar su propia versión. |

### 5.4 Productos, conceptos, planes y paquetes

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-CAT-036 | Definir productos y subservicios dentro de cada servicio del tenant. | BASE §72 PRO-001, §5 | Núcleo | O2 | Informado | INT tiene productos "Fibra hogar" y "IP fija" (subservicio). |
| RF-CAT-037 | Definir conceptos facturables individualizables por servicio, tipificados: una sola vez, recurrente, por cantidad, por evento, cuota, ajuste, tasa por cuenta de terceros, aporte de capital. | BASE §72 PRO-002, CAT `PROD_SER` | Núcleo | O2 | Informado | Instalación (una vez) y abono (recurrente) de INT son conceptos distintos vinculados a INT. |
| RF-CAT-038 | Establecer el disparador de cada concepto: aprobación, instalación efectiva, activación, inicio de período, evento (reconexión, transferencia, OT), vencimiento de hito. | BASE §72 | Núcleo | O2 | Informado | La instalación de INT se devenga al confirmar la instalación, no al aprobar. |
| RF-CAT-039 | Referenciar en cada concepto su clase fiscal (FIS), cuenta/rubro contable (CON), centro de costo y unidad de medida; el importe lo define TAR. | BASE §72, §84 | Núcleo | O2 / O4 | Informado | No se publica un concepto sin clase fiscal. |
| RF-CAT-040 | Distinguir costo interno de prestación y precio al socio; un costo interno no se factura sin concepto habilitado. | BASE §72, §74, §87 | Núcleo | O2 | Informado | El costo de instalación interna no aparece en factura si no existe concepto de instalación publicado. |
| RF-CAT-041 | Registrar planes comerciales con atributos del dominio (tecnología, velocidad bajada/subida, unidad, periodicidad, modalidad medida/no medida, requisitos, componentes incluidos, opciones, equipamiento requerido, necesidad de instalación/evaluación técnica). | BASE §5, CU-05, §86 | Núcleo | O2 | Informado | INT-100 declara 100 Mbps, mensual, requiere factibilidad y equipo. |
| RF-CAT-042 | Mantener versiones históricas de cada plan; un plan discontinuado no se ofrece a nuevos clientes pero conserva sus condiciones en los contratos anteriores; un cambio comercial puede aplicarse solo a nuevas contrataciones. | BASE §5 | Núcleo | O2 | Informado | Discontinuar INT-50 no modifica contratos INT-50 existentes. |
| RF-CAT-043 | Vincular plan y categoría a la tarifa vigente de TAR por vigencia; el contrato guarda referencia a la versión de plan y a condiciones pactadas, no un precio libre. | BASE §5 CU-05, §72 | Núcleo | O2 / O4 | Informado | El contrato muestra "Tarifa vigente: cuadro X" y no un importe editable. |
| RF-CAT-044 | Administrar paquetes de prestaciones (planes de varios servicios) con componentes y condiciones; la contratación de un paquete crea un contrato por servicio vinculados por `bundleSubscriptionId`. | BASE §5 | Estándar | O4 | Informado | Paquete INT+TV crea dos contratos enlazados; la baja de uno sigue la regla del paquete. |
| RF-CAT-045 | Definir promociones como componentes del plan con inicio/fin de vigencia de oferta, base (concepto afectado), duración (meses calendario, ciclos facturados u otra explícita) y regla de inicio; el cálculo es de TAR. | BASE §5, §72 PRO-003, AGR-017 | Núcleo | O2 / O4 | Informado | "50 % sobre abono durante 3 ciclos" queda en el contrato con su criterio de duración. |
| RF-CAT-046 | Ofrecer en el plan opciones de financiación de instalación (principal, anticipo, cuotas, método) como alternativa excluyente del pago de contado; el cronograma lo genera MOR y se evita la duplicación. | BASE §72 PRO-004, CU-PRO-01 | Estándar | O4 / O6 | Informado | Elegir financiar anula la alternativa de contado en el mismo contrato. |
| RF-CAT-047 | No aplicar subsidios por defecto; un subsidio exige régimen o beneficio real autorizado y se representa con categoría o beneficio vinculado a TAR/FIS. | BASE §72 | Núcleo | O2 | Informado | Un plan INT no tiene subsidio salvo régimen configurado. |
| RF-CAT-048 | Declarar compatibilidad y orden entre promociones, subsidios, bonificaciones y otras excepciones del plan. | BASE §72 | Estándar | O4 | Informado | Dos promociones incompatibles no pueden asignarse al mismo contrato. |
| RF-CAT-049 | Definir unidades de medición y periodicidad del servicio y del plan (mensual, bimestral, anual, por evento). | BASE §5 | Núcleo | O2 | Informado | GAS bimestral y INT mensual conviven en el tenant. |
| RF-CAT-050 | Configurar conceptos por evento (alta de servicio, alta de cuenta, alta de titular, reconexión, después de OT, antes de OT, transferencia) con filtros (socio activo, moroso, prepago, referencia, localidad, categoría, clase, medidor retirado, provisorio, propiedad, estado), cantidad, "una sola vez" y bonificaciones de conexión por cuenta. | RN-06 §3.6, CAT `CONEXION`, `CONE_BONIF` | Estándar | O3 / O4 | Adoptado | Al reconectar ELE se propone "Cargo de reconexión" solo si la política de MOR lo habilita. |
| RF-CAT-051 | Declarar productos entregables en comodato (equipos) por plan, con modalidad (comodato, venta, alquiler, propio del cliente). | BASE §74, §86, CAT `SERSOC_PRODUCTOS` | Núcleo | O3 | A validar (PA-CAT-10) | INT-100 declara ONT en comodato obligatoria. |
| RF-CAT-052 | Mostrar al socio el detalle de su precio vigente y la fecha de finalización de beneficios temporales. | BASE §72 | Estándar | O4 | Informado | "Mis servicios" muestra "Promoción 50 % hasta el ciclo 03-2027". |
| RF-CAT-053 | Mantener clases de servicio con valores asociados (ej. tasa hospital, tipo de suministro). | CAT `CLASESER`, REL ficha | Estándar | O2 | Adoptado | Un contrato ELE con clase "Tasa hospital municipal" informa VALOR1 al motor. |
| RF-CAT-054 | Mantener propiedades del servicio (tensión, mínimos, cargo fijo asociado, tensión regulatoria) y propiedades personalizadas tipadas con lista de valores. | CAT `PROPIESER`, INV abm_propieItems | Estándar | O2 / O7 | Adoptado | ELE tiene propiedad "Tensión" con valores BT/MT. |

### 5.5 Categorías

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-CAT-055 | Mantener categorías por servicio con atributos estructurales: social, prepaga, residencial, generador, categoría con subsidio asociada, categoría SEF asociada, código de tarifa regulatorio, perfil de red (Internet), grupo, códigos para ENARGAS/ARBA/Secretaría de Energía, cantidad de adherentes que la determina, permite cambio de categoría proporcional. | CAT `CATE_SER`, `CATE_SER_EXTRAS`, RN-06 §6, RN-01 §9 | Núcleo | O2 / O7 | Adoptado | La categoría "Jubilados" se marca `isSocial` explícitamente. |
| RF-CAT-056 | Mantener grupos de categorías con código regulatorio. | CAT `GRP_CAT` | Estándar | O7 | Adoptado | Grupo "Residencial gas" informa su código ENARGAS. |
| RF-CAT-057 | Conservar historial de categoría por vigencia en el contrato para facturar cada período con la categoría que correspondía. | DFA M4 mejora, AGR-010 | Núcleo | O2 | Adoptado | Un cambio de categoría del día 15 genera dos tramos consultables. |
| RF-CAT-058 | Permitir recategorización automática (por segmentación, consumo, edad o adherentes) respetando la marca "No aplica recategorización" del contrato. | DFA M4, RN-06 §6, REL flags | Estándar | O7 | Adoptado | El contrato marcado queda excluido del job de recategorización. |
| RF-CAT-059 | Para servicios con adherentes según cantidad, determinar la categoría por cantidad de adherentes computables y registrarla en el contrato como cambio de categoría. | RN-01 §9 | Estándar | O10 | Adoptado | Al pasar de 3 a 4 adherentes el contrato cambia a categoría "Familiar 4". |
| RF-CAT-060 | Restablecer en bloque categorías subsidiadas a su categoría base (por niveles o por régimen), excluyendo contratos marcados y bajas de más de 60 días. | RN-06 §6, V2 3155 | Estándar | O7 | Adoptado | El restablecimiento informa cantidad de contratos excluidos por cada motivo. |

### 5.6 Estados del contrato

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-CAT-061 | Mantener una máquina de estados canónica explícita del contrato (sección 8) con transiciones, actores, precondiciones, efectos y reversión; no existe edición libre del estado. | AGR-003, BASE §53 | Núcleo | O2 | Adoptado | Un PATCH de `lifecycleStatus` devuelve 405; solo existen comandos de transición. |
| RF-CAT-062 | Mantener por servicio un catálogo de estados operativos configurables, cada uno mapeado a un estado canónico, con marca de "implica desconexión" y "estado principal". | CAT `ESTASER`, DFA M4 | Núcleo | O2 | Adoptado | El estado operativo "CORTADO" de ELE mapea a `suspended` con `impliesDisconnection=true`. |
| RF-CAT-063 | Registrar por separado fecha solicitada y fecha efectiva de alta, suspensión, reactivación y baja; nunca presumir que coinciden. | BASE §48, §53, RN-06 §4.1 | Núcleo | O2 | Informado | Un contrato tiene `terminationRequestedAt` 10-05 y `effectiveEnd` 31-05. |
| RF-CAT-064 | Registrar fecha, actor, origen y motivo del último cambio de estado y la historia completa. | DFA M4, REL "fecha del último estado" | Núcleo | O2 | Adoptado | La ficha muestra "Activo desde 12-04-2026 por cierre de OT-123". |
| RF-CAT-065 | Distinguir suspensión temporal solicitada por el socio, suspensión por mora, suspensión técnica/seguridad, suspensión regulatoria/administrativa y reactivación; cada una con duración, motivo, fecha efectiva y modo (restringido o interrumpido). | BASE §53 CIC-002, CIC-003 | Núcleo | O2 / O6 | Informado | Una suspensión por mora de INT con modo "restringido" no figura como "Baja". |
| RF-CAT-066 | Mostrar "Rehabilitación en trámite" mientras falte la confirmación técnica; el contrato no vuelve a Activo por el solo registro de un pago. | BASE §53, §89 | Núcleo | O6 | Informado | Pagar la deuda de GAS suspendido deja el contrato en `reactivationPending` hasta la inspección. |

### 5.7 Contrato de servicio

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-CAT-067 | Vincular cada contrato con un titular identificado por DNI o CUIT y una cuenta; un mismo domicilio puede tener varios contratos del mismo servicio con titulares distintos; la dirección no es clave del contrato ni determina responsabilidad de pago. | BASE §1 (Titularidad), §83, §86 | Núcleo | O2 | Informado | Dos hermanos con INT en DIR-CASA-001 tienen contratos, equipos y deudas independientes. |
| RF-CAT-068 | La ficha del contrato contiene: cabecera (id, servicio, clase, plan y versión, categoría), ubicación (domicilio del servicio, referencia, nomenclatura catastral Cod/Sec/Man/Par/PH/Lote, DDJJ, número de contrato, inmueble, GIS, latitud/longitud), servicio (actividad ARCA, observaciones, garante, grupo de facturación, fechas de alta/baja), generalidades (estado y fecha del último estado), otros (profesional instalador, certificado número/vencimiento, id cliente externo, fecha de vencimiento), lectura (zona, sector, recorrido), varios (última facturación, id de factibilidad, matrícula). Medidor y demanda se muestran desde MED. | REL "Administración de Servicios", DFA M4 | Núcleo | O2 | Adoptado | Todos los bloques aparecen en la ficha, ocultando los que el perfil marca "No aplica". |
| RF-CAT-069 | Mantener flags del contrato: No facturar (con autorización y vigencia), Provisorio, Cobrar provisorio, No aplica recategorización, Alta desde portal (origen), Lectura con factor de multiplicación, Enviar factura electrónica por defecto, No cobrar recargo (referencia a COB). | REL flags, DFA M4, V2 2303, 2642, 3135 | Núcleo | O2 | A validar (PA-CAT-09) | Marcar "No facturar" exige permiso, motivo y fecha hasta; FAC excluye el contrato y lo lista en la bandeja de no facturables. |
| RF-CAT-070 | Congelar en el contrato las condiciones contratadas: versión del plan, componentes, promociones con su criterio de duración, financiación elegida, aceptación (fecha, canal, evidencia) y documento de condiciones. | BASE §5, §72, §86 | Núcleo | O2 | Informado | Cambiar el plan publicado no modifica las condiciones guardadas del contrato. |
| RF-CAT-071 | Registrar cantidad o dispositivos en servicios por cantidad (tipos 7/8) y por dispositivos. | RN-06 §3.2 paso 2, RN-01 §2 | Estándar | O4 | Adoptado | Un servicio "por cantidad" exige cantidad > 0 para activarse. |
| RF-CAT-072 | Registrar origen del contrato (canal, caso CRM, usuario, regla automática, migración, transferencia) y enlazar el caso. | BASE §48, REL "Alta desde CoopOnline" | Núcleo | O2 | Informado | Un alta desde PWA queda con `origin.channel=pwa` y `crmCaseId`. |
| RF-CAT-073 | Ejecutar las validaciones de alta configuradas (sección 6, RN-CAT-020..031) devolviendo todos los errores y advertencias juntos. | RN-06 §3.2 | Núcleo | O2 | Adoptado | Un alta con tres faltantes devuelve los tres en un único problem+json. |
| RF-CAT-074 | Controlar matrícula única por servicio entre contratos no dados de baja salvo parámetro, y generar matrícula automática cuando el servicio lo indique. | RN-06 §3.2 paso 3, V2 2250 | Estándar | O2 | Adoptado | Con unicidad activa, repetir la matrícula ELE-0001 devuelve 409. |
| RF-CAT-075 | Impedir que un asociado tenga más de un contrato del mismo servicio en categoría social cuando el parámetro lo indique, usando la marca explícita `isSocial` de la categoría. | RN-06 §3.2 paso 9, V2 2740 | Estándar | O7 | Adoptado | El segundo contrato social ELE del mismo titular se rechaza o se recategoriza según la regla de prioridad. |
| RF-CAT-076 | Advertir (o exigir autorización) si existen deudas, vencidas o totales, en otras cuentas con el mismo domicilio o la misma parcela catastral al dar de alta o cambiar el titular. | RN-06 §3.1, V2 2482, 2668, 2669 | Estándar | O2 | A validar (PA-CAT-12) | El alta muestra advertencia y registra quién continuó. |
| RF-CAT-077 | Configurar si se permiten contratos para titulares no activos o dados de baja. | V2 734, 741 | Estándar | O2 | Adoptado | Con el parámetro activo, un titular dado de baja no puede recibir un contrato nuevo. |
| RF-CAT-078 | Configurar si se permiten contratos iguales (mismo servicio) medidos o no medidos en una misma cuenta. | V2 2269, 2715 | Estándar | O2 | A validar (PA-CAT-11) | Por defecto INT admite dos contratos en la misma cuenta; ELE no admite dos en el mismo punto de suministro. |
| RF-CAT-079 | Registrar equipos asignados al contrato en comodato: producto, unidad serializada (STK), depósito, fecha de entrega, fecha de devolución prevista, fecha devuelto, precio de referencia, observaciones, constancia firmada; bandeja de equipos pendientes de devolución al dar de baja. | CAT `SERSOC_PRODUCTOS`, INV abm_Sersoc_Productos, BASE §74, §86 | Núcleo | O3 | Adoptado | Dar de baja INT con ONT no devuelta crea pendiente de retiro y no bloquea la baja comercial. |
| RF-CAT-080 | Gestionar adherentes y beneficiarios del contrato: persona, vínculo, titular sí/no, fechas de alta/baja, tarifa de adherente asignada, inicio de cobertura tras carencia, cascada de desconexión/reconexión configurable, consulta al reconectar, aviso de mayoría de edad, baja por fallecimiento, ocultar fallecidos, adherente repetido, control de deuda de adherentes. | RN-06 §10, RN-01 §9, CAT `ADHSOC`, `BENSOC`, V2 109, 2400, 2401, 2521, 2545, 3058, 3186, 3187 | Estándar | O10 | Adoptado | Registrar el fallecimiento de un adherente en PER da de baja su vínculo con fecha y causa y conserva la historia. |
| RF-CAT-081 | Cambiar el plan de un contrato registrando nueva oferta, aceptación, fecha efectiva y tratamiento de promociones y período en curso. | BASE §86 Cambio | Núcleo | O3 / O4 | A validar (PA-CAT-15) | Un cambio de INT-100 a INT-300 queda como nuevo tramo de condiciones con fecha efectiva. |
| RF-CAT-082 | Cambiar la categoría de un contrato de forma inmediata, en fecha futura, o al cerrar la OT correspondiente, impidiendo dos OT pendientes del mismo tipo, y aplicando el día límite para cobrar proporcional. | RN-06 §6, V2 2330, 2455, 2755 | Estándar | O2 / O7 | Adoptado | Con modo "al cerrar OT", la categoría nueva se aplica en la fecha de cierre. |
| RF-CAT-083 | Ejecutar cambios masivos de categoría solicitados por otros módulos (paso a prepago por deuda desde MOR; recategorización por segmentación desde TAR) con origen, criterio, simulación previa y reversión. | RN-06 §6 | Estándar | O6 / O7 | Adoptado | Un lote de recategorización muestra antes/después y puede revertirse mientras no haya facturación con la nueva categoría. |
| RF-CAT-084 | Transferir un contrato a otra cuenta/titular creando un contrato nuevo (con o sin mantener fecha de alta) y dejando el original en "No vigente", trasladando línea, beneficiarios, vivienda, punto de suministro y propiedades; adherentes según política; generando conceptos de transferencia; permitiendo o no transferir contratos dados de baja y marcar como principal. | RN-06 §7, V2 422, 2291, 2541, 2599, 2782, 3195 | Estándar | O2 | Adoptado | La transferencia conserva la deuda en el titular original y la historia en el contrato original. |
| RF-CAT-085 | Trasladar el domicilio del servicio por orden de trabajo (aplicar el domicilio nuevo al cerrarla, opcionalmente también a las personas adherentes) y, a pedido, copiar el domicilio de la cuenta a sus contratos; validar mismo domicilio cuando el parámetro lo indique. | RN-06 §8, V2 2461, 2710 | Estándar | O3 | Adoptado | El traslado de INT queda con domicilio anterior y nuevo con fechas. |
| RF-CAT-086 | Ejecutar reglas de altas automáticas ante eventos (alta de servicio, alta de cuenta, baja, reconexión, cambio de categoría, nueva OT, cambio de domicilio) con filtros (categoría, propiedad, clase, actividad, localidad, referencia, zona, tipo de medidor, condición del titular) y herencia de grupo de facturación. | RN-06 §3.5, CAT `ALTASEAU`, V2 332 | Estándar | O4 / O7 | A validar (PA-CAT-04) | Conectar ELE en una localidad con alumbrado configurado crea el contrato ALU vinculado. |
| RF-CAT-087 | Ejecutar trámites masivos sobre listas de contratos: marcar provisorio, cambiar actividad, clase, categoría (opcionalmente en consumos no facturados), referencia y baja; la baja masiva procesa solo los contratos que pasan la validación de desconexión. | RN-06 §4.3 | Estándar | O4 | Adoptado | Un trámite masivo informa procesados, rechazados y motivo por contrato. |
| RF-CAT-088 | Dar de baja un contrato: recibir la solicitud sin cargo, fijar fecha efectiva, ordenar desactivación/retiro, conservar facturas, deuda e historia, dejar equipos pendientes, no extinguir la condición de asociado. | BASE §48, §53 CIC-001, §86 | Núcleo | O3 / O6 | Informado | La baja de INT de B no afecta INT de A ni la asociación de B. |
| RF-CAT-089 | Configurar si se permite la baja de contratos con cuotas relacionadas pendientes (financiaciones, cuotas de obra o vivienda) y cómo se informan. | V2 2316 | Estándar | O6 | Adoptado | Con el parámetro apagado, la baja muestra las cuotas pendientes y requiere supervisor. |
| RF-CAT-090 | Reconectar/reactivar un contrato aplicando la regla de fecha de alta para no medidos en el mismo mes de la desconexión y la regla sobre titulares fallecidos. | RN-06 §4.2, V2 2707, 2301 | Estándar | O6 | Adoptado | La reconexión de un no medido en el mismo mes conserva la fecha de alta anterior si el parámetro está apagado. |
| RF-CAT-091 | Anular un contrato antes de su activación (desistimiento, factibilidad negativa, OT de alta eliminada) sin exigir circuito de retiro de equipo no instalado. | AGR-003, V2 2753 | Núcleo | O3 | Adoptado | Anular un contrato en `pendingInstallation` sin equipo asignado lo pasa a `cancelled`. |
| RF-CAT-092 | Al desconectar el último servicio de un titular, informar si sigue siendo adherente, beneficiario o garante en otros contratos. | V2 2571 | Extensión | O2 | Adoptado | La baja muestra el aviso con enlaces. |
| RF-CAT-093 | Declarar por servicio si se admiten consumos de contratos dados de baja (no permitir/controlar/permitir); la carga la gestiona MED. | V2 2550 | Estándar | O7 | Adoptado | MED rechaza una lectura posterior a la baja si el servicio está en "no permitir". |
| RF-CAT-094 | En listados: mostrar por defecto solo contratos activos, mostrar observación del servicio junto a su descripción, permitir desagrupar servicios de la cuenta y buscar por matrícula aproximada. | V2 2321, 2557, 3152, 3108 | Extensión | O2 | Adoptado | La búsqueda "ELE-00" devuelve todas las matrículas que empiezan así si el parámetro está activo. |
| RF-CAT-095 | Registrar la declaración jurada de artefactos del contrato de gas (artefacto, cantidad, marca, serie, modelo, año, usuario, estado, observaciones) con historial y plantilla de trámite. | CAT `ARTEFACTO`, `ARTEFSUMS`, `HIS_ARTEFSUMS`, V2 44, 2742, DFA M4 Gas | Estándar | O7 | Adoptado | Cada cambio de la DDJJ queda en historia con fecha y usuario. |
| RF-CAT-096 | Registrar el vínculo de generación distribuida asociado al suministro eléctrico: clasificación del usuario-generador, potencia, equipo, fecha de conexión, instalador, medidor bidireccional; su cambio de titular y baja siguen al suministro. | BASE MER-001, CAT `SERSOC_EXTRAS` (ALTA_GENERA, POTENCIA_GENERA), `CATE_SER_EXTRAS.GENERADOR` | Estándar | O7 | Informado | Un contrato ELE con GD muestra su vínculo y potencia; la baja del suministro cierra el vínculo. |
| RF-CAT-097 | Registrar condiciones especiales de grandes usuarios: precio particular, potencia contratada, plazo, penalidades, aprobación y versión; revisión previa obligatoria de la factura por su importe (marca para FAC). | BASE MER-003, RN-06 §3.3 (cálculo grandes clientes) | Estándar | O7 | Informado | Un contrato GU no puede activarse sin condiciones aprobadas. |
| RF-CAT-098 | Telefonía: asignar número/línea al contrato (con fechas y tarifa), modalidad (fija/móvil), plan, pack SMS, producto de telefonía prepaga que genera OT al venderse; la numeración y CDR los gestiona TEC. | BASE §32, §92, MER-017, CAT `TEL_SERSOC`, `TEL_MODALIDAD`, `TEL_SERVICIO`, `SERTEL`, V2 2253, 2708 | Estándar | O4 (abono) / O10 (CDR) | Informado | Un contrato TEL muestra su número vigente y los anteriores con fechas. |
| RF-CAT-099 | Internet: referenciar el perfil técnico del contrato (identificador de acceso, nodo/OLT, puerto/recurso, perfil de velocidad de la categoría) sin almacenar secretos en CAT ni exponerlos en catálogo público o BI. | BASE §86, CAT `INTERNET`, `CATE_SER_EXTRAS.PERFIL_MIKROTIK` | Núcleo | O3 | Informado | La API de contratos nunca devuelve contraseñas de acceso. |
| RF-CAT-100 | Correo electrónico como producto TIC del contrato (casilla, dominio) con credenciales gestionadas en la bóveda. | CAT `CORREOSINT` | Extensión | O10 | Adoptado | La casilla se lista sin contraseña. |
| RF-CAT-101 | Dispenser de agua como servicio con límite diario de litros, litros por atención y días para cálculo de deuda. | V2 2581, 2582, 2583, 2584 | Extensión | O10 | Adoptado | El contrato de dispenser informa el límite diario vigente. |
| RF-CAT-102 | Vehículo eléctrico como perfil de registración (datos del vehículo, carga habilitable desde el portal). | RN-06 §3.3, V2 75 (canal portal) | Extensión | O10 | Adoptado | El perfil pide dominio y modelo del vehículo. |
| RF-CAT-103 | Seguro como perfil de registración (cobertura, asegurados, vigencia). | RN-06 §3.3 | Extensión | O10 | Adoptado | El perfil pide asegurados como adherentes. |

### 5.8 Configuración independiente y copia entre tenants

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-CAT-104 | Cada servicio de cada tenant tiene configuración propia e independiente sobre la misma capacidad de plataforma. | BASE §81 COP-001 | Núcleo | O2 | Informado | Cambiar INT en A no altera INT en B. |
| RF-CAT-105 | Copiar la configuración de un servicio (tenant, servicio y versión de origen) a un destino autorizado, eligiendo componentes (productos, planes, conceptos, reglas comerciales, categorías, estados, formularios, tipos de gestión, plantillas), clasificando qué se copia, qué se conserva del destino y qué debe mapearse; sin copiar asociados, usuarios, contratos, direcciones, facturas, deuda, pagos, tickets, respuestas, stock físico, series ni credenciales. | BASE §81 COP-002 | Núcleo | O2 | Informado | La copia de INT de A a B no trae ningún documento con `tenantId` de A salvo la procedencia. |
| RF-CAT-106 | Crear en destino una configuración nueva o una nueva versión borrador de una existente, sin sobrescribir en silencio; revisar diferencias, simular y completar pendientes antes de habilitar y publicar. | BASE §81 COP-003, AGR-009 | Núcleo | O2 | Informado | La copia sobre un INT existente en B crea "versión 2 borrador" y conserva la versión 1 publicada. |
| RF-CAT-107 | Registrar identidad de la copia, procedencia, versión, componentes elegidos, actor, fecha, resultado, dependencias pendientes; evitar duplicados por reintentos. | BASE §81 | Núcleo | O2 | Informado | Reintentar con el mismo `Idempotency-Key` devuelve la misma ejecución. |
| RF-CAT-108 | Exigir permiso explícito de lectura en origen y de escritura en destino; ser administrador de B no autoriza a leer A. | BASE §81 | Núcleo | O2 | A validar (PA-CAT-07) | Un administrador de B sin autorización de A recibe 403. |
| RF-CAT-109 | Mantener plantillas de servicio de plataforma (sin precios ni referencias de tenants) reutilizables para lanzar servicios. | DFA M4 mejora "plantillas reutilizables" | Estándar | O2 | A validar (PA-CAT-08) | Un tenant nuevo crea INT desde la plantilla "Internet FTTH base". |

### 5.9 Oferta, portal y landing

| ID | Requisito | Origen | Prioridad | Ola | Estado | Criterio de aceptación |
|---|---|---|---|---|---|---|
| RF-CAT-110 | Publicar en la landing del tenant los servicios y planes con oferta abierta, sus requisitos y canales para solicitar, sin login. | BASE §66 CAT-002, §1 | Núcleo | O2 | Informado | La landing de TEN-002 muestra Electricidad y Gas. |
| RF-CAT-111 | En la PWA, mostrar servicios disponibles y contratados con estado, condiciones, beneficios temporales, equipos asignados y acciones permitidas. | BASE §48, §72 | Núcleo | O2 | Informado | Ana ve su INT Activo, su ONT en comodato y "Solicitar baja". |
| RF-CAT-112 | Desde la oferta o el contrato, iniciar solicitudes de alta, baja, suspensión, reactivación o cambio de plan; la solicitud la gestiona CRM y no cambia el contrato hasta su ejecución. | BASE §48 SOL-001, SOL-002, §53 | Núcleo | O2 | Informado | Solicitar la baja deja el contrato Activo con marca "Baja solicitada" hasta su ejecución. |
| RF-CAT-113 | Proveer indicadores del catálogo: contratos por servicio/estado/plan/categoría, altas pendientes, suspensiones, bajas, equipos pendientes de devolución, contratos no facturables, planes discontinuados con contratos vigentes. | BASE §54, §86 Indicadores | Estándar | O2 / O11 | Informado | El tablero muestra cada indicador con universo y fecha de corte. |

## 6. Reglas de negocio

### 6.A Reglas generales

| ID | Regla | Comportamiento ProCoop (fuente) | Decisión en GoodApps | Parámetros | [VERIFICAR] |
|---|---|---|---|---|---|
| RN-CAT-001 | Un servicio solo puede habilitarse en un tenant si la capacidad está `available` y licenciada. | Todo instalado; módulos por licencia `.pro` (RN-09 §5.4). | Reemplazar (T01 + CAT). | — | — |
| RN-CAT-002 | Habilitar/publicar no genera contratos ni cobros. | No aplica. | Replicar principio BASE §66/§81. | — | — |
| RN-CAT-003 | Deshabilitar oferta (`offerStatus=closed`) impide nuevas solicitudes y altas; los contratos existentes siguen su ciclo. Deshabilitar operación (`operationStatus=closed`) solo es posible sin contratos no terminados o con plan de salida aprobado. | No aplica. | Mejorar. | PRM-CAT-001 | — |
| RN-CAT-004 | Toda modificación de configuración publicada se hace mediante una nueva versión; la versión publicada es inmutable. | `HIS_SERVICIO` por cuadro tarifario; edición directa de `SERVICIO`. | Mejorar (AGR-009). | — | — |
| RN-CAT-005 | Una versión no se publica si falla alguna validación bloqueante: plan sin precio vigente en TAR, concepto sin clase fiscal, servicio regulado sin autoridad/título, falta de equivalencia contable, referencia a otro tenant, estado operativo sin mapeo canónico, evento sin estado por defecto. | No aplica. | Mejorar. | — | — |
| RN-CAT-006 | La fecha efectiva de una versión puede ser futura; nunca anterior a la última facturación cerrada del servicio salvo versión correctiva aprobada que dispara ajustes en FAC. | Cuadros con desde/hasta (`CUADROS`). | Mejorar (AGR-010). | — | — |
| RN-CAT-007 | Un plan discontinuado no se ofrece a nuevas contrataciones y conserva condiciones de contratos anteriores. | No hay plan explícito. | Replicar BASE §5. | — | — |
| RN-CAT-008 | Un cambio comercial del plan genera nueva versión; los contratos conservan la versión aceptada hasta un cambio de plan propio o una política de migración aprobada y comunicada. | No aplica. | Replicar BASE §5/§72. | — | — |
| RN-CAT-009 | Cada concepto facturable pertenece a un único servicio del tenant (salvo conceptos transversales: capital, tasas de terceros, franqueo), conservando su vínculo con el servicio aun en facturas agrupadas. | `PROD_SER` global con rubro. | Mejorar (BASE §72). | — | — |
| RN-CAT-010 | No se crea un servicio de facturación independiente por concepto: instalación y abono de Internet pertenecen a Internet. | — | Replicar BASE §72. | — | — |
| RN-CAT-011 | Instalación al contado y financiada son alternativas excluyentes en el contrato; elegir una anula la otra. | — | Replicar BASE §72 CU-PRO-01. | — | — |
| RN-CAT-012 | Una bonificación comercial no es subsidio estatal; un subsidio exige régimen registrado. | Categoría con subsidio (`COD_CATSER_SS`). | Replicar con tipificación explícita. | — | — |
| RN-CAT-013 | Promoción: guarda base, porcentaje/importe (TAR), duración, unidad de duración (`calendarMonths`, `billedCycles`, `days`), regla del primer período parcial (consume/no consume) y fin. | — | Replicar BASE §72, AGR-017. | — | A validar con TAR |
| RN-CAT-014 | Un plan solo puede incluir conceptos del mismo servicio o transversales permitidos; un paquete combina planes de servicios habilitados. | — | Mejorar. | — | — |
| RN-CAT-015 | La categoría del contrato es la base estructural; si una lectura trae otra categoría del mismo servicio, prevalece la de la lectura para ese período (regla de TAR; CAT valida que exista). | RN-01 §2 "categoría del consumo". | Replicar (delegado a TAR). | — | — |
| RN-CAT-016 | Una categoría se considera social solo si tiene `isSocial=true`; se descarta la inferencia por descripción "JUBILADOS". | `Es_Categoria_Social` por `CAT_SOC` o descripción. | Reemplazar. | PRM-CAT-030 | — |
| RN-CAT-017 | El estado operativo siempre mapea a un estado canónico; la transición la gobierna el estado canónico. | `ESTASER` libre + `CONDICION` derivada de fechas. | Reemplazar (AGR-003). | — | — |
| RN-CAT-018 | Las fechas nulas se guardan como `null`; se elimina la fecha centinela. | Fechas nulas normalizadas a 1901-01-01 (RN-06 §4.1). | Reemplazar. | — | — |
| RN-CAT-019 | "Conectado a efectos de facturación y lecturas" = estados canónicos `active`, `suspended` (cuando el servicio declara que la suspensión factura cargos), `pendingTermination`. | Condición 2 o 3 (RN-06 §4.1). | Mejorar (configurable por servicio). | PRM-CAT-040 | — |
| RN-CAT-020 | Alta: servicio y domicilio del servicio son obligatorios; fecha de alta obligatoria salvo servicio técnico (la pone el cierre de la OT). | RN-06 §3.2 paso 1. | Replicar. | — | — |
| RN-CAT-021 | Alta: categoría obligatoria; cantidad obligatoria en servicios por cantidad o por dispositivos. | RN-06 §3.2 paso 2. | Replicar. | — | — |
| RN-CAT-022 | Matrícula única dentro del servicio entre contratos no dados de baja salvo parámetro "permitir duplicada"; si el servicio genera matrícula automática, se controla siempre. | RN-06 §3.2 paso 3 (V2 2250, corregido en segunda pasada). | Replicar. | PRM-CAT-020 | — |
| RN-CAT-023 | Designación catastral e inmueble obligatorios si el servicio lo exige; no se duplica la misma parcela en el mismo servicio salvo autorización (subdivisión/unificación, BASE §88). | RN-06 §3.2 paso 4, V2 319. | Replicar y mejorar con excepción autorizada. | PRM-CAT-011 | — |
| RN-CAT-024 | Grupo de facturación obligatorio y válido. | RN-06 §3.2 paso 5 (−1 inválido). | Replicar. | — | — |
| RN-CAT-025 | Actividad, clase, ZSR y dispositivo obligatorios según el perfil. | RN-06 §3.2 paso 6. | Replicar. | PRM-CAT-010, 012 | — |
| RN-CAT-026 | Factibilidad: si el servicio la exige, el contrato no pasa de `feasibility` a `pendingInstallation` sin factibilidad aprobada por TEC asociada. | RN-06 §3.2 paso 7, V2 2050. | Replicar con estado explícito. | PRM-CAT-013 | — |
| RN-CAT-027 | Garante: si el servicio lo exige, bloquea siempre. | RN-06 §3.2 paso 8. | Replicar. | PRM-CAT-014 | — |
| RN-CAT-028 | Tarifa social única: un titular no puede tener más de un contrato social del mismo servicio; si el proceso de segmentación encuentra varios, prioriza jubilado, luego cuenta principal, luego el contrato más antiguo. | RN-06 §3.2 paso 9, §6 (V2 2740). | Replicar. | PRM-CAT-030 | — |
| RN-CAT-029 | Certificado de instalador: según parámetro no exigir/advertir/exigir; si se informa número, se exigen profesional y fecha salvo parámetro. | V2 2343, 2529. | Replicar. | PRM-CAT-015, 016 | — |
| RN-CAT-030 | Deuda en domicilio/parcela: buscar otras cuentas con el mismo domicilio (calle, número, barrio, localidad, piso, departamento, edificio) o misma nomenclatura; según parámetro, total o vencida; resultado advertencia (por defecto) o autorización de supervisor; nunca traslada deuda. | RN-06 §3.1, V2 2482, 2668, 2669. | Mejorar (BASE §1/§89). | PRM-CAT-017, 018 | — |
| RN-CAT-031 | Titular no activo / dado de baja: según parámetro se impide el alta. | V2 734, 741. | Replicar. | PRM-CAT-019 | — |
| RN-CAT-032 | Dos contratos iguales en la misma cuenta: según parámetro por servicio (medidos/no medidos). | V2 2269, 2715. | Replicar con default distinto (PA-CAT-11). | PRM-CAT-021, 022 | — |
| RN-CAT-033 | Guardado del contrato es transaccional con: creación del pedido de OT (servicio técnico), movimiento de stock del medidor/equipo trazable (vía STK), orden de telemedición (vía MED), extras, adherentes, beneficiarios y datos de dominio; todo efecto externo se publica por outbox. | RN-06 §3.4 (una transacción, `UPDATE` directos). | Mejorar (DEC-003 outbox). | — | — |
| RN-CAT-034 | "Forzar guardado aunque no haya cambios" no se replica; el control optimista por `version` reemplaza al guardado rápido. | V2 2286. | Descartar (deuda técnica). | — | — |
| RN-CAT-035 | Altas automáticas: ante el evento configurado y si se cumplen los filtros, se propone o crea el contrato del servicio destino; grupo de facturación = defecto del destino salvo "tomar grupo" del origen; condición del titular: todos / solo activos / solo no activos. | RN-06 §3.5. | Replicar con modo `propose`/`create` (PA-CAT-04). | PRM-CAT-050 | — |
| RN-CAT-036 | Una regla automática no crea duplicados: si ya existe contrato no terminado del servicio destino en la misma cuenta y punto, no actúa. | No documentado. | Mejorar. | — | — |
| RN-CAT-037 | Conceptos por evento: con "una sola vez", no se repite el mismo concepto dentro del mismo lote ni (mejora) si ya se cobró para el mismo contrato y evento; no se configuran dos conceptos "una vez" con el mismo producto y tipo. | RN-06 §3.6 (no controla operaciones anteriores). | Mejorar. | — | — |
| RN-CAT-038 | Conceptos por evento con costo para suspensión/reactivación solo se aplican si la política de MOR los habilita para ese servicio y jurisdicción; la solicitud de baja nunca genera cargo. | `CONEXION` tipo 4 (reconexión) sin control normativo. | Mejorar (BASE §53 CIC-004). | — | — |
| RN-CAT-039 | Servicio técnico: la baja administrativa no corta; crea pedido de desconexión a TEC y el contrato pasa a `pendingTermination`; la baja efectiva ocurre al confirmar la OT. Servicio no técnico: la baja efectiva puede registrarse en el acto por un usuario con permiso. | RN-06 §4.2. | Replicar. | — | — |
| RN-CAT-040 | Al generar OT de desconexión, si el servicio "consulta baja", se pregunta si se registra también la baja administrativa. | RN-06 §4.2 (`CONSULTA_BAJA`). | Replicar como opción del comando. | — | — |
| RN-CAT-041 | Al confirmar desconexión efectiva, si la baja administrativa estaba vacía se completa con la misma fecha. | RN-06 §4.2. | Replicar. | — | — |
| RN-CAT-042 | Cierre de OT (eventos de TEC): alta → `active` con fecha efectiva, copia de matrícula, lectura inicial 0 si el servicio lo pide (MED); traslado → domicilio nuevo; desconexión → medidor retirado (MED) y, según parámetro, se limpian matrícula y número de medidor; reconexión → `active` y posible bonificación de reconexión. Si la integración de telemedición falla, la OT no se cierra y el contrato no cambia. | RN-06 §4.2 "Cierre de la OT". | Replicar con eventos y saga. | PRM-CAT-041 | — |
| RN-CAT-043 | Reconexión de no medido en el mismo mes y año de la última baja efectiva: si el parámetro está apagado se restaura la fecha de alta anterior para no partir el período; en medidos o con parámetro activo, fecha nueva. | RN-06 §4.2 (V2 2707, corregido). | Replicar. | PRM-CAT-042 | — |
| RN-CAT-044 | Reconexión a titulares fallecidos: prohibida salvo parámetro. | V2 2301. | Replicar. | PRM-CAT-043 | — |
| RN-CAT-045 | Desconexión/reconexión del contrato se propaga a adherentes y beneficiarios según política del servicio (`cascade`, `ask`, `none`); con "consultar al reconectar" se pregunta. | RN-06 §10 (siempre en cascada), V2 2401. | Mejorar (CTR-CAT-03). | PRM-CAT-060 | — |
| RN-CAT-046 | Integraciones externas por cambio de estado (BATCOM, Discar, SITSA, AION, telemedición) se configuran por servicio y se ejecutan por outbox con confirmación; nunca con código de servicio fijo. | V2 2713 + V2 car 2264 "BAT" con `COD_SER = 1` fijo; V2 3116; V2 car 3034. | Reemplazar (T06). | — | — |
| RN-CAT-047 | Cambio de categoría individual: si el servicio genera OT, no se admite una segunda OT pendiente del mismo tipo; la categoría se aplica inmediata, en fecha o al cierre de la OT según `categoryChangeMode`. | RN-06 §6 (V2 2330, V2 2455). | Replicar con modo explícito. | PRM-CAT-044, 045 | [VERIFICAR] semántica V2 2455 (CTR-CAT-07) |
| RN-CAT-048 | Cambio de categoría dentro del período: si la fecha es posterior al día límite configurado, se cobra proporcional (TAR). | V2 2755. | Replicar. | PRM-CAT-046 | — |
| RN-CAT-049 | Cambio masivo por deuda solo a categorías prepagas (paso a prepago del moroso) y solo por orden de MOR con política habilitada. | RN-06 §6 `ModificarCategoria`. | Replicar acotado. | — | — |
| RN-CAT-050 | Recategorización por segmentación: guarda categoría anterior, actualiza consumos no facturados (MED/TAR), deja nota "Recategorización" en el contrato; excluye marcados "No aplica recategorización" y bajas de más de 60 días; opción de incluir desconectados. | RN-06 §6, V2 2825, 3155. | Replicar. | PRM-CAT-031, 032 | — |
| RN-CAT-051 | Transferencia: siempre se crea contrato nuevo en destino (fecha de alta = fecha de transferencia salvo "mantener fecha"); el original recibe baja efectiva y estado `superseded` (si el parámetro está activo) o `terminated`; la deuda queda en el titular original. | RN-06 §7 (modos eliminar y clonado; V2 2541, V2 422). | Mejorar: se descarta el modo "eliminar" (CTR-CAT-08). | PRM-CAT-051 | — |
| RN-CAT-052 | Transferencia de adherentes y beneficiarios: copiar dados de baja (histórico) / copiar activos / no copiar (equivalente a "eliminar": en GoodApps se dan de baja en origen sin borrarlos). | V2 int 2291. | Replicar sin borrado físico. | PRM-CAT-052 | — |
| RN-CAT-053 | Transferencia de contratos dados de baja: solo con parámetro. | V2 2599. | Replicar. | PRM-CAT-053 | — |
| RN-CAT-054 | Al transferir a un titular nuevo puede marcarse la cuenta destino como principal según parámetro. | V2 3195. | Replicar (efecto en PER). | PRM-CAT-054 | — |
| RN-CAT-055 | Traslado de domicilio del servicio solo por OT en servicios técnicos; en no técnicos por comando con permiso; se guarda domicilio anterior con vigencia. | RN-06 §8. | Replicar. | PRM-CAT-055 | — |
| RN-CAT-056 | Adherentes computables: los no dados de baja, excluyendo según marcas del servicio (menores nacidos en el último año al fin del mes siguiente, jubilados, personas con discapacidad); la edad se calcula al último día del período. | RN-01 §9. | Replicar (cálculo en TAR, datos en CAT). | — | — |
| RN-CAT-057 | Adherentes fuera de rango (edad, ocupación, vínculo no admitido por la categoría) se detectan en lote; se dan de baja o cambian de categoría por trámite masivo con aprobación; se excluyen personas con discapacidad. | RN-06 §10. | Replicar. | — | — |
| RN-CAT-058 | Aviso de hijos que cumplen 21 años a la fecha (job) y por correo si el parámetro lo indica. | RN-06 §10, V2 3186, 3187. | Replicar (notificación T09). | PRM-CAT-061, 062 | — |
| RN-CAT-059 | Fallecimiento registrado en PER da de baja los vínculos (adherente, beneficiario) con fecha de fallecimiento; según parámetro se ocultan en la ficha. | RN-06 §10, V2 3058. | Replicar por evento `per.person.deceased`. | PRM-CAT-063 | — |
| RN-CAT-060 | Adherente que ya existe en el mismo servicio: según parámetro se permite o se consulta si darlo de baja del otro titular. | V2 2400, 2521. | Replicar. | PRM-CAT-064, 065 | — |
| RN-CAT-061 | Equipo en comodato: solo se asigna una unidad serializada disponible en STK del depósito del técnico/servicio; al asignar, STK mueve la unidad a "en comodato"; al devolver, STK la recibe; la baja comercial no espera la devolución. | `SERSOC_PRODUCTOS` + stock trazable. | Replicar y mejorar (BASE §86). | — | — |
| RN-CAT-062 | "No facturar": requiere parámetro habilitante, permiso, motivo y vigencia; FAC lista estos contratos en la bandeja de no facturables; al vencer, se reanuda la facturación y se avisa. | V2 2303, `SUMNOFAC` (a nivel cuenta). | Mejorar (vigencia obligatoria). | PRM-CAT-070 | — |
| RN-CAT-063 | "Provisorio": contrato transitorio con fecha de vencimiento obligatoria; al vencer, se notifica y se propone baja o conversión a definitivo. "Cobrar provisorio" indica si se factura durante la condición provisoria. | Marcas Provisorio / Cobrar provisorio; filtro "provisorio" en `CONEXION`; trámite masivo "marcar provisorio". | Mejorar | PRM-CAT-071 | [VERIFICAR] semántica exacta (PA-CAT-09) |
| RN-CAT-064 | Un contrato no pasa a `active` sin: titular, cuenta, plan/categoría vigente, grupo de facturación, requisitos del perfil cumplidos y, si es técnico, confirmación de instalación. | RN-06 §3.2. | Replicar. | — | — |
| RN-CAT-065 | La baja del servicio no da de baja al asociado; la baja del titular con servicios activos está prohibida salvo parámetro (regla de PER que CAT informa). | BASE §48; RN-06 §5 (V2 340, 337). | Replicar (PER). | — | — |
| RN-CAT-066 | Consulta histórica: toda consulta del contrato "a una fecha" declara si interpreta fecha efectiva o fecha de registro. | — | Adoptar AGR-010. | — | — |
| RN-CAT-067 | Cambios dentro del período (plan, categoría, titular, suspensión) guardan cada tramo con su regla y zona horaria del tenant; inclusión de días según la regla del servicio (TAR). | — | Adoptar AGR-017. | — | — |
| RN-CAT-068 | Copia entre tenants: nunca se copian datos operativos ni credenciales; toda referencia interna se mapea al destino o queda pendiente; la configuración copiada es independiente (sin sincronización posterior). | No aplica (una base por cooperativa). | Replicar BASE §81. | — | — |
| RN-CAT-069 | Copia: marca y diccionario del destino prevalecen; el régimen fiscal y subsidios no se presumen aplicables. | — | Replicar BASE §81. | — | — |
| RN-CAT-070 | Las transiciones son idempotentes por `commandId`; un reintento no duplica cargos ni ejecuciones. | — | Adoptar AGR-016, BASE §53. | — | — |
| RN-CAT-071 | Un ticket CRM cerrado no cambia por sí solo el contrato ni cancela deuda. | — | Adoptar AGR-002. | — | — |
| RN-CAT-072 | Baja de contrato con cuotas relacionadas (financiación, obra, vivienda) según parámetro: permitir, o exigir supervisor mostrando las cuotas; las cuotas no desaparecen. | V2 2316. | Replicar. | PRM-CAT-072 | — |
| RN-CAT-073 | "Facturar sin consumo": en servicios medidos (tipos 1 a 4) conectados o pendientes de desconexión, si no hay consumos se factura cargo fijo con consumo 0; sin la marca, no genera ítems. | RN-01 §2. | Replicar (TAR lee la marca de CAT). | — | — |
| RN-CAT-074 | Servicio relacionado: si el servicio usa consumo de otro, TAR toma las lecturas del servicio relacionado en la misma cuenta (opcionalmente solo no facturadas). | RN-01 §2 (`REL_SER`, `USA_COT`, V2 2701, 3143). | Replicar. | PRM-CAT-080 | — |
| RN-CAT-075 | Telefonía: el contrato telefónico factura la suma de llamadas tarifadas (TEC/TAR); si no hay llamadas y el parámetro lo indica, el ítem va en 0; CPP e internacionales a conceptos propios configurados en el servicio. | RN-01 §10 (V2 2514, 19, 24). | Replicar (CAT define conceptos; TAR calcula). | PRM-CAT-090..092 | — |

### 6.B Perfil de configuración por servicio (BASE §84) — estructura obligatoria

Cada `tenantService` tiene un perfil con estas 13 dimensiones. Para cada una se indica qué campos la materializan (sección 7) y qué módulo la consume.

| Dimensión | Contenido obligatorio | Campos (`tenantServices.profile.*`) | Consumidor |
|---|---|---|---|
| Prestador y jurisdicción | Modalidad: `direct`, `subdistribution`, `agreement`, `administrativeIntermediation`; autoridad/regulador; título habilitante; concesión; jurisdicción (nacional/provincial/municipal); fuente normativa con vigencia. | `provider.mode`, `provider.authorityIds[]`, `provider.licenseRef`, `provider.concessionId`, `provider.jurisdiction`, `provider.normativeSources[]{code,title,url,validFrom,validTo,verifiedAt}` | FIS, BIA (reguladores) |
| Titularidad | Identificación DNI/CUIT obligatoria, representación admitida, responsables, beneficiarios, cambio de titular admitido y condiciones. | `ownership.idTypes[]`, `ownership.allowsRepresentation`, `ownership.allowsBeneficiaries`, `ownership.allowsAdherents`, `ownership.ownerChangeMode` | PER, CRM |
| Unidad de prestación | Unidad central del dominio sin equivalencias automáticas. | `unit.kind` (enum sección 7), `unit.label` (dict) | TAR, FAC |
| Oferta | Productos, planes, lista/versión de precios vinculada y condiciones. | `offer.productIds[]`, `offer.planIds[]`, `offer.tariffBinding` | TAR, landing |
| Cantidad | Medida real/estimada, capacidad, tiempo, unidad o cobertura. | `quantity.mode` (`metered`, `unmetered`, `byQuantity`, `byDevices`, `byAdherents`, `byCalls`, `byProperty`, `installments`, `coverage`, `notApplicable`), `quantity.unitOfMeasure` | MED, TAR |
| Excepciones | Beneficios, descuentos, exclusiones, cargos, recargos e intereses habilitados con base y vigencia. | `exceptions.allowed[]` (referencias a TAR/MOR) | TAR, MOR |
| Facturación | Conceptos permitidos, ciclos, corte, anticipado/vencido, prorrateo, clase fiscal, grupo de facturación por defecto, facturar sin consumo. | `billing.conceptIds[]`, `billing.cycleIds[]`, `billing.timing` (`inAdvance`/`inArrears`), `billing.prorationRule`, `billing.defaultBillingGroupId`, `billing.billWithoutConsumption` | FAC, TAR |
| Cuenta y pago | Auxiliar por contrato/servicio, agrupación autorizada, imputación, conciliación. | `account.ledgerMode` (`perContract`, `perService`, `unified`), `account.allowGrouping` | COB |
| Ciclo comercial | Solicitud, validación, presupuesto, alta y fecha efectiva; requisitos de alta; factibilidad; aprobación. | `commercial.requirements{}` (sección 7), `commercial.requiresFeasibility`, `commercial.requiresQuote`, `commercial.approvalMode` | CRM, TEC |
| Operación | Visitas, recursos, equipos, registros, evidencia, responsables; servicio técnico; operaciones técnicas por evento. | `operation.requiresWorkOrder`, `operation.autoWorkOrderOnSave`, `operation.askAdminTerminationOnDisconnectionWO`, `operation.workOrderTypes{}`, `operation.equipment[]` | TEC, STK |
| Cambios y salida | Cambio de plan/titular, suspensión, reactivación, baja, obligaciones remanentes, cascadas. | `lifecycle.allowedOperations{}`, `lifecycle.defaultOperationalStatus{}`, `lifecycle.memberCascade`, `lifecycle.categoryChangeMode` | CRM, MOR |
| Atención | Motivos, urgencias, tiempos, escalamiento y canales regulatorios. | `support.reasonCatalogRef`, `support.regulatoryChannel` | CRM |
| Control | Auditoría, reportes específicos, integraciones y restricciones de datos (sensibles). | `control.sensitiveData` (bool), `control.integrations[]`, `control.reports[]` | IAM, BIA, INT |

### 6.C Fichas por dominio de servicio

Cada ficha es la **plantilla de capacidad** que la plataforma ofrece (`serviceCapabilities.domainSheet`) y que el tenant completa en su perfil. Los atributos listados se materializan como `domainAttributes` tipados del contrato (sección 7.18) validados por el esquema de la capacidad. Importes: siempre en TAR; aquí solo estructura. "No aplica" se marca explícitamente (BASE §93).

#### 6.C.1 INT — Internet (piloto, DEC-005)

| Aspecto | Definición |
|---|---|
| Unidad central | Conexión/contrato por titular; varias conexiones independientes en un domicilio (BASE §86). |
| Régimen y autoridad | Servicio TIC; ENACOM; Reglamento de Clientes TIC (Res. 733/2017): contratación, información, facturación, reclamos con plazos diferenciados por motivo y número de gestión previa ante el prestador [ESP10–ESP12]. |
| Perfil de registración / cálculo | Perfil "Internet"; tipo de cálculo "importe fijo" (6) con proporcional de alta y baja; medición de tráfico solo si existe fuente definida (BASE §86). |
| Atributos de dominio | Tecnología (FTTH, inalámbrico, cablemódem, DSL), velocidad bajada/subida ofrecida, cobertura/zona, nodo/OLT/puerto (referencia TEC), identificador de acceso (referencia; secreto en bóveda), MAC/IP asignada (referencia TEC), perfil de red de la categoría (`networkProfileCode`, ex `PERFIL_MIKROTIK`), IP fija (subservicio), id de factibilidad. |
| Estados propios | Canónicos completos; suspensión por mora en modo `restricted` (velocidad reducida) o `interrupted`; `reactivationPending` hasta confirmación del aprovisionamiento. |
| Hito de alta / salida | Alta: instalación/activación confirmada (prueba y conformidad). Salida: baja comercial + orden de desactivación + retiro de equipo; devolver el router no equivale a baja procesada (BASE §86). |
| Documentos | Contrato/condiciones TIC versionadas, constancia de instalación con firma, constancia de entrega de equipo en comodato, constancia de baja con número de gestión. |
| Productos y conceptos típicos | Producto "Fibra hogar"; planes por velocidad; instalación (una vez, devenga al instalar), abono (recurrente desde activación), promoción por ciclos, financiación de instalación, IP fija, equipo en comodato/venta, cambio de domicilio, reconexión (si la política lo habilita). |
| Límites | Aprovisionamiento (MikroTik/Radius/OLT), diagnóstico, monitoreo de nodos e incidentes de zona → M10 TEC; ninguna acción de red sin circuito CRM o MOR (MER-017). Mostrar estado en la app no configura la red. |
| Ola | O2 (catálogo, contrato) – O3 (activación, equipos) – O4 (facturación) – O6 (suspensión). |
| Origen | BASE §72, §86, §93, MER-017; CAT `INTERNET`, `MIKROTIK`, `CATE_SER_EXTRAS.PERFIL_MIKROTIK`; DFA M25. |

#### 6.C.2 TEL — Telefonía (fija, móvil, pack SMS)

| Aspecto | Definición |
|---|---|
| Unidad central | Línea/número asignado a un contrato. |
| Régimen y autoridad | Servicio TIC; ENACOM; reglas TIC específicas. |
| Perfil / cálculo | Perfil "Teléfono"; tipo de cálculo 5 (suma de llamadas tarifadas) o 14 (telefonía móvil, importe fijo) o 16 (pack SMS, importe fijo). |
| Atributos de dominio | Número asignado con fecha alta/baja y tarifa telefónica (ex `TEL_SERSOC`), modalidad (fija/móvil, ex `TEL_MODALIDAD`), servicio telefónico (ex `TEL_SERVICIO`), central/repartidor/regleta/puerto (referencia TEC), plan de descuento (TAR), operador (móvil), guía telefónica (publicar sí/no). |
| Estados propios | Canónicos; sub-estado "línea bloqueada saliente" mapeado a `suspended/restricted`. |
| Hito de alta / salida | Alta: línea activa en central. Salida: baja de línea, liberación del número a "en cuarentena" en TEC. |
| Documentos | Contrato TIC, detalle de llamadas (impresión desde ficha), guía telefónica. |
| Productos y conceptos típicos | Abono de línea, minutos/llamadas (tasación de CDR en TEC/TAR), CPP (concepto configurado, V2 19), internacionales (concepto configurado, V2 24), servicios telefónicos adicionales (ex `SERTEL`: código, producto, importe, precio proveedor, consumo, tipo), pack SMS (V2 2253), telefonía prepaga (producto que genera OT al venderse, V2 2708). |
| Límites | Centrales, DSLAM, numeración, importación/tasación de CDR, bandas, claves, rechazos → M10 TEC / M04 TAR. |
| Ola | O4 (abono) – O10 (CDR y tasación). |
| Origen | BASE §32, §39.2, §92, MER-017; RN-01 §10; CAT §12 (`TEL_*`, `TARTEL`, `SERTEL`, `LLAMADAS`, `LLA_CEL`, `INTERNAC`, `GRATIS`, `OPERADOR`, `PLANDES`); DFA M25. |

#### 6.C.3 TV — Televisión / cable

| Aspecto | Definición |
|---|---|
| Unidad central | Contrato con paquete y puntos/equipos. |
| Régimen y autoridad | Servicio TIC/audiovisual; ENACOM. |
| Perfil / cálculo | Perfil "Fijos con dispositivos"; importe fijo; cantidad de puntos/decodificadores como dispositivos. |
| Atributos de dominio | Paquete, puntos de conexión, decodificadores (series en STK), señales adicionales, tecnología (cable/IPTV). |
| Estados propios | Canónicos. |
| Hito de alta / salida | Alta: activación de señal. Salida: corte de señal y retiro de equipos. |
| Documentos | Contrato, constancia de equipos. |
| Productos y conceptos típicos | Abono por paquete, adicionales (pack de señales), punto adicional, decodificador en comodato, instalación. |
| Límites | Derechos de señales, aprovisionamiento → TEC; a relevar por tenant (BASE §92). |
| Ola | O10. |
| Origen | BASE §32, §39.2, §48, §92. |

#### 6.C.4 ELE — Energía eléctrica (incluye generación distribuida y grandes usuarios)

| Aspecto | Definición |
|---|---|
| Unidad central | Suministro y punto de medición. |
| Régimen y autoridad | Córdoba: ERSeP (Ley 8835) regulador; EPEC prestadora mayorista con tarifa de abastecimiento a cooperativas [ESP1–ESP4]; Reglamento de Suministros (RG ERSeP 11/2005, referencia histórica) [ESP26]; Ley 10281 seguridad eléctrica e instalador habilitado [ESP7]; electrodependencia Ley 27351 y Ley 10511 [ESP8–ESP9]; Ley 10739 contenido de facturas [ESP5]; Secretaría de Energía y OCEBA/EPRE en otras jurisdicciones. |
| Perfil / cálculo | Perfil "Energía"; tipos 1, 2 o 4; variante grandes clientes (incluye medidor testigo). |
| Atributos de dominio | Destino/uso, categoría local, tipo de suministro (permanente/transitorio), tensión, potencia solicitada/autorizada (kW), características de acometida, tipo de medidor (monofásico/trifásico — MED), demanda pico/fuera de pico (MED), aptitud de instalación (fecha, instalador habilitado, certificado número/vencimiento), condición de electrodependencia acreditada (vigencia), NIS u otro identificador regulatorio, código de empresa ERSeP (tenant), descripción de lectura HP/kVA (V2 2477). |
| Estados propios | `suspended` con `impliesDisconnection`; restricción de corte para electrodependientes (MOR). |
| Hito de alta / salida | Alta: conexión habilitada con lectura inicial. Salida: baja con lectura final; tratamiento de medidor; la deuda queda en quien corresponda. |
| Documentos | Solicitud de suministro, certificado de instalador, presupuesto de obra, constancia de electrodependencia, contrato de suministro, fianza. |
| Productos y conceptos típicos | Cargo fijo, energía (kWh), potencia/demanda (kW), franjas, energía reactiva/factor de potencia, cargos y fondos habilitados por norma, derecho de conexión, reconexión, subsidios/segmentación (categoría con subsidio, SEF). |
| Generación distribuida (vínculo, no servicio) | `generationAgreements`: clasificación del usuario-generador, potencia, equipo, fecha de conexión, instalador, medidor bidireccional; liquidación de demanda e inyección separadas y cuenta de créditos → TAR/FAC/COB; rendición ARCA (RG 5746/2025) → FIS (MER-001). |
| Grandes usuarios | `contractSpecialConditions`: precio particular, potencia contratada, plazo, penalidades, aprobación y versión; lecturas por franja pico/valle/resto, demanda en punta y fuera de punta, reactiva (MED/TAR); revisión previa de factura (FAC) (MER-003). |
| Límites | No equiparar kWh y kW; no aplicar tarifa mayorista como minorista; compra de energía (`FACT_EPEC`), pérdidas y costos → CMP/CON (BASE §87). |
| Ola | O7. |
| Origen | BASE §32, §39.2, §87, MER-001, MER-003; DFA M4; REL ficha; CAT `PROPIESER` (tensión OCEBA), `CATE_SER_EXTRAS` (GENERADOR, CODIGO_TARIFA), `SERSOC_EXTRAS` (ALTA_GENERA, POTENCIA_GENERA). |

#### 6.C.5 AG — Agua potable

| Aspecto | Definición |
|---|---|
| Unidad central | Conexión / unidad de facturación (inmueble, parcela, unidad funcional). |
| Régimen y autoridad | Según concesión: ERSeP, autoridad local o marco hídrico provincial (Decreto 529/94) [ESP1, ESP6]; Ley 10739 [ESP5]; referencias de modalidades: Aguas Cordobesas medido/no medido y lecturas [ESP15, ESP16, ESP28]; cooperativa del interior [ESP17]. |
| Perfil / cálculo | Perfil "Otros medidos" o "Fijos"; tipo 1/2 (medido) o 15 (agua según inmueble: fórmula sobre datos catastrales) o 6 (fijo). |
| Atributos de dominio | Régimen `metered`/`unmetered` con fecha efectiva, destino de uso, urbano/rural, radio servido, datos catastrales usados por la fórmula (superficie, frente, categoría de inmueble — PER), punto de servicio, diámetro de conexión. |
| Estados propios | Canónicos; baja contractual distinta de la situación física de la conexión y de la obligación regulatoria del inmueble (BASE §88). |
| Hito de alta / salida | Alta: conexión y condición del régimen. Salida: baja y efectos sobre el inmueble según régimen. |
| Documentos | Solicitud de conexión, factibilidad, presupuesto de obra, inspección. |
| Productos y conceptos típicos | Cargo fijo, bloques/franquicias, excedente (solo si el régimen local los prevé), conexión, obras urbanas/rurales, rehabilitación. |
| Límites | Calidad/laboratorio no se certifica por dato libre; red, válvulas, pozos → TEC; no copiar suspensión de Internet. Dispenser de agua → ficha OTR. |
| Ola | O7. |
| Origen | BASE §39.2, §88; RN-01 §2 (tipo 15). |

#### 6.C.6 CLO — Cloacas / saneamiento

| Aspecto | Definición |
|---|---|
| Unidad central | Conexión al inmueble. |
| Régimen y autoridad | Concesión local/provincial [ESP6]. |
| Perfil / cálculo | Perfil "Fijos" o "Otros medidos" con **servicio relacionado AG** (usa consumo de agua de la misma cuenta) o tipo 17 si es cuota de obra. |
| Atributos de dominio | Servicio relacionado y base de cálculo, conexión domiciliaria, frente. |
| Estados propios | Canónicos. |
| Hito de alta / salida | Alta: conexión habilitada. Salida: según régimen. |
| Productos y conceptos típicos | Cargo de saneamiento, conexión, cuota de obra de red cloacal. |
| Límites | No se habilita automáticamente por existir agua (BASE §88). |
| Ola | O7. |
| Origen | BASE §88, §92; RN-01 §2 (`REL_SER`, `USA_COT`, tipo 17). |

#### 6.C.7 GAS — Gas (natural por red, propano por red, envasado)

| Aspecto | Definición |
|---|---|
| Unidad central | Suministro/medidor/modalidad. |
| Régimen y autoridad | ENReGE (funciones federales ex ENARGAS/ENRE) [ESP13]; subdistribuidor autorizado [ESP14]; distribuidora de referencia (ej. Ecogas: primera alta con aprobación técnica, reglamento de medición y corrección) [ESP22–ESP23]; derechos del usuario [ESP24]. |
| Perfil / cálculo | Perfil "Otros medidos"; tipo 3 (corrección por factor calórico y tramas). |
| Atributos de dominio | Tipo de gas y modalidad (red natural / propano por red / envasado — PA-CAT-13), condición de subdistribución, distribuidora de referencia, zona (zona fría), categoría y grupo con código regulatorio, legajo técnico (referencia TEC), matriculado interviniente, aprobación de instalación, DDJJ de artefactos (sección 7.21), estado de beneficio por zona. |
| Estados propios | `reactivationPending` obligatorio tras suspensión con revisión técnica: "Rehabilitación en trámite" hasta inspección; el pago no acredita instalación segura (BASE §89). |
| Hito de alta / salida | Alta: aprobación técnica/habilitación y colocación del medidor. Salida: baja con lectura final, estado técnico, documentación. |
| Documentos | Legajo, formularios y respuestas de la distribuidora, DDJJ de artefactos, constancia de inspección. |
| Productos y conceptos típicos | Cargo fijo, m³ corregidos (factores por período/categoría, PCS — MED/TAR), componentes del precio, subsidios (SEF), rehabilitación. |
| Límites | El bot recibe y deriva incidentes pero no sustituye emergencias ni decide seguridad; cambiar titular no traslada deuda histórica del inmueble (BASE §89). Informes ENARGAS → BIA/FIS. |
| Ola | O7. |
| Origen | BASE §39.2, §89; DFA M4 Gas; CAT `ARTEFACTO`, `ARTEFSUMS`, `HIS_ARTEFSUMS`, `CORREGAS`, `FACTOR_CAL`, `PRCAGAS`, `GRP_CAT`, `ENGAS_CANTMESES`. |

#### 6.C.8 ALU — Alumbrado público

| Aspecto | Definición |
|---|---|
| Unidad central | Contrato accesorio al suministro eléctrico o al inmueble (tasa). |
| Régimen y autoridad | Ordenanza/convenio municipal; puede ser tasa por cuenta de terceros (ver TAS). |
| Perfil / cálculo | Perfil "Fijos"; importe fijo o porcentaje sobre energía (TAR). |
| Atributos de dominio | Convenio municipal, localidad, base de cálculo. |
| Estados propios | Sigue al suministro principal (vínculo `parentContractId`). |
| Hito de alta / salida | Alta automática al conectar ELE si la regla lo prevé (RN-06 §3.5) — sujeto a PA-CAT-04; baja junto con el principal. |
| Productos y conceptos típicos | Cargo de alumbrado; categoría "19 Alumbrado público" para suministros del municipio (REL). |
| Límites | Rendición al municipio → FIS/COB. |
| Ola | O4 (como tasa) – O7. |
| Origen | REL ficha (categoría 19 Alumbrado público), RN-06 §3.5, RN-01 §2 tipo 17. |

#### 6.C.9 OBR — Pavimento y obras (cuotas de obras, contribución por mejoras)

| Aspecto | Definición |
|---|---|
| Unidad central | Cuota de obra por inmueble/frente. |
| Régimen y autoridad | Convenio u ordenanza de obra pública, contribución por mejoras. |
| Perfil / cálculo | Perfil "Cuotas de obras"; tipo 17 (pavimento, cloaca, alumbrado o vivienda). |
| Atributos de dominio | Obra, tramo, metros de frente, cantidad de cuotas, cuotas pagas, unidades totales/facturadas/originales, porcentajes de instalaciones básicas/redes (ex `SERSOC_EXTRAS`: CNT_CUOTAS, CNT_UNIDADES, CNT_UNIDADES_FACTURADAS, CNT_UNIDADES_TOTALES, CNT_CUOTAS_PAGAS, PORC_INST_BASICAS, PORC_INST_REDES, CNT_UNIDADES_ORIGINAL), plan (COD_PLA). |
| Estados propios | `active` hasta completar cuotas → `terminated` (fin natural); baja anticipada solo con cancelación (V2 2316). |
| Hito de alta / salida | Alta: adhesión/asignación de la obra. Salida: última cuota o cancelación. |
| Productos y conceptos típicos | Cuota de obra, cancelación anticipada, intereses de financiación (MOR). |
| Límites | Gestión de la obra → TEC (obras); grupos de obra (V2 2900). |
| Ola | O7. |
| Origen | RN-01 §2 tipo 17, RN-06 §3.3 (perfil Cuotas de obras), CAT `SERSOC_EXTRAS`, BASE §102 (obras y contribución por mejoras). |

#### 6.C.10 SEP — Sepelio (y subsidio por fallecimiento)

| Aspecto | Definición |
|---|---|
| Unidad central | Cobertura por grupo (titular + adherentes). |
| Régimen y autoridad | Reglamento del servicio/fondo de la cooperativa; prestador de sepelio. |
| Perfil / cálculo | Perfil "Adherentes" / "Adherentes según tarifas"; tipos 9 a 13. |
| Atributos de dominio | Grupo cubierto, carencia, alcance territorial, exclusiones, prestador. Subsidio por fallecimiento: beneficiario, expediente, aprobación, pago (no es automáticamente seguro). |
| Estados propios | Canónicos; cobertura por adherente con `coverageFrom` (alta + carencia). |
| Hito de alta / salida | Alta: adhesión con grupo registrado. Salida: baja de adhesión o de adherente. |
| Documentos | Ficha de adherentes, credencial, solicitud de servicio por evento. |
| Productos y conceptos típicos | Cuota por grupo, cuota por adherente según edad/vínculo/ocupación, excedente de adherentes (`COBRAEXCEDENTE`), servicio por evento no cubierto. |
| Límites | Coordinación del evento → SOC; distinguir de cementerio parque y subsidio (BASE §90). |
| Ola | O10. |
| Origen | BASE §92; RN-01 §9; RN-06 §3.5 (alta automática de sepelio), §10; CAT `ADHSOC`, `TAR_ADHE`. |

#### 6.C.11 CEM — Cementerio parque

| Aspecto | Definición |
|---|---|
| Unidad central | Derecho sobre unidad de sepultura (parcela, nicho, urnario). |
| Régimen y autoridad | Código Civil y Comercial arts. 2103–2113 (cementerios privados: afectación, reglamento, registros de inhumaciones y titulares, derechos de sepultura, mantenimiento) y policía mortuoria nacional/provincial/municipal [ESP18]; verificar si encuadra o es concesión. |
| Perfil / cálculo | Perfil propio "Derecho de sepultura" (nuevo); importe fijo/cuotas por derecho, mantenimiento periódico, actos por evento. |
| Atributos de dominio | Establecimiento, habilitación, reglamento y versión, modalidad jurídica del derecho, unidad (sector, manzana/fila, número — registro en SOC), titular del derecho, responsables y autorizados, instrumento firmado. |
| Estados propios | Contrato: canónicos; la unidad tiene estados propios en SOC (disponible, reservada, adjudicada, ocupada) separados; la mora no libera la unidad ni autoriza disponer de restos (BASE §90). |
| Hito de alta / salida | Alta: constitución/adjudicación del derecho. Salida: transferencia, cesión, extinción según régimen; sin botón de baja simple. |
| Documentos | Instrumento del derecho, reglamento aceptado, autorizaciones de actos. |
| Productos y conceptos típicos | Derecho (cuotas de adquisición), mantenimiento, inhumación, exhumación, reducción, traslado. |
| Límites | Registro de ocupaciones, actos y turnos → M18 SOC; restos humanos no son stock. |
| Ola | O2 (catálogo) – O10 (operación). |
| Origen | BASE §66 CAT-003, §90, §93, §95. |

#### 6.C.12 SAN — Banco de sangre (cobertura por convenio)

| Aspecto | Definición |
|---|---|
| Unidad central | Convenio / grupo / beneficiario. |
| Régimen y autoridad | Ley 22990 (habilitación, prohibición de intermediación lucrativa, límites al cobro al receptor) [ESP19]; autoridad sanitaria; modelos COOPLA y Tío Pujio [ESP20–ESP21]. |
| Perfil / cálculo | Perfil "Adherentes" o "Beneficiarios"; modalidad financiada por la cooperativa (importe 0 al socio), aporte permitido o gratuita según convenio; nunca precio por unidad de sangre. |
| Atributos de dominio | Convenio (referencia SOC), red/prestador, ámbito, vigencia, grupo familiar/conviviente, beneficiarios con fechas. Datos de salud: ninguno en CAT (`control.sensitiveData=true`). |
| Estados propios | Contrato: canónicos; cobertura del beneficiario a la fecha. |
| Hito de alta / salida | Alta: cobertura vigente por convenio. Salida: baja de adhesión o de beneficiario. |
| Documentos | Adhesión, constancia de cobertura. |
| Productos y conceptos típicos | Adhesión (puede ser 0), aporte de cobertura (si el convenio lo permite). |
| Límites | Solicitudes de cobertura, campañas, turnos de donación, costos del convenio → M18 SOC; el ERP no decide aptitud clínica ni compatibilidad; edades de donante (V2 2527) solo como filtro administrativo de campañas; no publicar en muro ni BI general (BASE §91). |
| Ola | O10. |
| Origen | BASE §39.2, §91, §93, §95; RN-09 V2 2527. |

#### 6.C.13 SAL — Ambulancias y salud (traslados, médicos, internación)

| Aspecto | Definición |
|---|---|
| Unidad central | Cobertura por grupo o servicio por evento (traslado). |
| Régimen y autoridad | Habilitación sanitaria del prestador; tipo de traslado. |
| Perfil / cálculo | Perfil "Adherentes" (cobertura) y servicio por evento (traslado con km, importe). |
| Atributos de dominio | Grupo cubierto, plan de cobertura, carencia; para eventos: referencia al traslado en SOC (origen/destino, km, médico). |
| Estados propios | Canónicos. |
| Productos y conceptos típicos | Cuota de cobertura, traslado no cubierto (por km), coseguro. |
| Límites | Registro de traslados (`AMBULANC`), médicos (`MEDICOS`), internaciones (`INTERNAC` en salud) → M18 SOC; no asumir urgencias médicas (BASE §92). |
| Ola | O10. |
| Origen | BASE §32 (servicios sociales), §39.2 (SOC-FAM), §92; DFA M4, M25. |

#### 6.C.14 VIV — Planes de vivienda

| Aspecto | Definición |
|---|---|
| Unidad central | Plan de vivienda por titular (inscripción → adjudicación → construcción → entrega). |
| Régimen y autoridad | Reglamento del plan de la cooperativa. |
| Perfil / cálculo | Perfil "Plan de vivienda"; tipo 17 (cuotas) o aportes con mínimos/máximos por categoría. |
| Atributos de dominio | Plan (categoría con mínimos: eventual, después de adjudicación, antes/después de entrega, máximo anual antes de entrega, fecha de aporte teórico — ex `CATE_SER_EXTRAS.VIV_*`, `PLANESVIV`), fechas de inscripción, adjudicación, forma de adjudicación, entrega, inicio/fin de construcción (ex `VIVIENDAS`), tipología. |
| Estados propios | Contrato canónico + etapa del plan (inscripto, adjudicado, en construcción, entregado) en SOC. |
| Hito de alta / salida | Alta: inscripción. Salida: baja de plan con comisión configurada (V2 413/414) o rescisión; transferencia con texto propio (V2 417). |
| Documentos | Texto de transferencias, bajas, cambios de planes (V2 417, 418, 419), comprobante a generar (V2 415). |
| Productos y conceptos típicos | Aporte/cuota, comisión por baja, materiales (SOC/STK). |
| Límites | Etapas, actividades, progreso, materiales y retiros → M18 SOC. |
| Ola | O10. |
| Origen | DFA M25; CAT `PLANESVIV`, `VIVIENDAS`, `PRECIOSVIV`, `VIV_*`; RN-09 VIVIENDA y V2 413–419. |

#### 6.C.15 TAS — Tasas y conceptos por cuenta de terceros

| Aspecto | Definición |
|---|---|
| Unidad central | Obligación de tercero (municipio, hospital, bomberos) cobrada en la factura del servicio o como contrato propio. |
| Régimen y autoridad | Convenio u ordenanza con fundamento; Ley 10739 limita conceptos en facturas de energía/agua en Córdoba [ESP5]. |
| Perfil / cálculo | Concepto transversal o contrato "Fijos"; base fija, porcentaje o por clase de servicio (ej. clase "4 Tasa hospital municipal"). |
| Atributos de dominio | Tercero beneficiario, convenio, fundamento normativo, base, rendición. |
| Productos y conceptos típicos | Tasa municipal, tasa hospital, aporte bomberos. |
| Límites | Liquidación, rendición y tratamiento fiscal → FIS/COB; no se habilita un rubro por un campo editable (BASE §85). |
| Ola | O4. |
| Origen | REL ficha (clase 4 Tasa hospital municipal), DFA M4 (clase de servicio), BASE §85, §98 (convenios por cuenta de terceros), CAT `CLASESER`, `CON_TASAS`. |

#### 6.C.16 CAP — Capital social como concepto

| Aspecto | Definición |
|---|---|
| Unidad central | Concepto facturable transversal, no servicio con contrato propio. |
| Régimen y autoridad | Ley de cooperativas, estatuto; INAES. |
| Perfil / cálculo | Concepto de tipo `capitalContribution`, generable desde ítems facturados, comprobantes, importe de capital del servicio al alta (`IMP_CAPITAL`) o pagos. |
| Atributos | Rubro capitalizable, momento de suscripción (al facturar / en la afiliación — V2 73, 2636). |
| Límites | Libro de capital, integración, reserva, rescate → M17 INS (RN-06 §9). CAT solo define el concepto y el importe de capital por servicio al alta. |
| Ola | O10 (O4 si el piloto factura capital — dependencia con INS). |
| Origen | RN-06 §9, BASE §98 (capital y aportes), CAT `RUBCAPI` (referencia). |

#### 6.C.17 OTR — Otras prestaciones

| Prestación | Definición estructural | Origen | Ola |
|---|---|---|---|
| Banco ortopédico | Elementos identificados en préstamo (comodato) con devolución, limpieza/mantenimiento; no es venta por defecto. | BASE §92 | O10 |
| Traslados (no médicos) | Solicitud, origen/destino, agenda, recursos, constancia. | BASE §92 | O10 |
| Seguro | Perfil "Seguro": cobertura, asegurados como adherentes, vigencia. | RN-06 §3.3 | O10 |
| Vehículo eléctrico | Perfil "Vehículo eléctrico": datos del vehículo, carga desde el portal (V2 75). | RN-06 §3.3 | O10 |
| Dispenser de agua | Servicio con límite diario de litros, litros por atención, días para cálculo de deuda (V2 2581–2584). | RN-09 | O10 |
| Correo electrónico | Producto TIC: casilla, dominio; credenciales en bóveda (ex `CORREOSINT`). | CAT §12 | O10 |
| Pack SMS | Producto TEL de importe fijo (tipo 16, V2 2253). | RN-01 §2 | O10 |

## 7. Modelo de datos

Convenciones comunes a todas las colecciones (no se repiten): `_id` ObjectId; `tenantId` ObjectId obligatorio (en catálogo de plataforma = tenant `PLATFORM`); `createdAt`, `updatedAt`, `createdBy`, `updatedBy`, `version` (control optimista); `deletedAt` solo en configuración no publicada (los contratos y documentos económicos nunca se borran). Todo índice compuesto empieza por `tenantId`. Etiquetas por `labelKey` (`dict:`). Importes en `Decimal128`.

### 7.1 `serviceCapabilities` (plataforma)

Propósito: catálogo global de capacidades de servicio. Origen ProCoop: no existe (implícito en `SERVICIO`, `TIP_SERVI`, `TipoRegistracion`).

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `code` | string | Sí | INT, TEL, TV, ELE, AG, CLO, GAS, ALU, OBR, SEP, SUBF, CEM, SAN, SAL, VIV, SEG, VEL, DSP, MAIL, SMS, ORT, TRA, TAS, CAP (único). |
| `domain` | enum | Sí | `tic`, `energy`, `water`, `sanitation`, `gas`, `publicLighting`, `works`, `social`, `funeral`, `cemetery`, `bloodBank`, `health`, `housing`, `insurance`, `thirdPartyFees`, `capital`, `other`. |
| `labelKey`, `descriptionKey` | string | Sí | Claves dict. |
| `status` | enum | Sí | `draft`, `available`, `deprecated`. |
| `maturity` | enum | Sí | `confirmed` (solicitante), `candidate` (investigado), `procoopParity` (DEC-007). |
| `registrationProfiles[]` | enum[] | Sí | `energy`, `otherMetered`, `phone`, `fixed`, `fixedWithDevices`, `adherents`, `adherentsByTariff`, `devicesAndAdherents`, `internet`, `quantity`, `housingPlan`, `insurance`, `worksInstallments`, `electricVehicle`, `burialRight`, `beneficiaries`. |
| `calculationTypes[]` | int[] | Sí | Tipos de cálculo admitidos (1–17 ProCoop + nuevos TAR). |
| `unitKinds[]` | enum[] | Sí | `connection`, `supply`, `meteringPoint`, `coverage`, `burialUnit`, `act`, `line`, `group`, `housingPlan`, `worksInstallment`, `device`, `concept`. |
| `domainAttributeSchema` | object (JSON Schema) | Sí | Atributos de dominio tipados (fichas 6.C). |
| `domainSheet` | object | Sí | Ficha: régimen, autoridades sugeridas, hitos de alta/salida, documentos, productos típicos, límites. |
| `requiredPlatformModules[]` | string[] | Sí | Capabilities de licencia T01 requeridas (ej. `mod.tec.aprovisionamiento`). |
| `sensitiveData` | bool | Sí | Datos sensibles (SAN, SAL). |
| `insumosPendientes[]` | string[] | No | Checklist BASE §95. |

Índices: `{tenantId, code}` único.

### 7.2 `tenantServices`

Propósito: servicio habilitado/ofertado por el tenant y su perfil. Origen: `SERVICIO`, `SERVICIO_EXTRAS`, `TIP_SERVI`.

| Campo | Tipo | Oblig. | Descripción / origen |
|---|---|---|---|
| `capabilityId` | ObjectId | Sí | → `serviceCapabilities`. |
| `code` | string | Sí | Código del tenant (ej. "INT"); ex `COD_SER`. |
| `labelKey` | string | Sí | ex `DES_SER`. |
| `serviceTypeCode` | string | No | Agrupador de reporte; ex `TIP_SERVI`. |
| `isPrincipal` | bool | No | V2 573. |
| `enablement` | object | Sí | `{status: enabled|disabled, validFrom, validTo, enabledBy, licenseCheckAt}`. |
| `offerStatus` | enum | Sí | `notPublished`, `open`, `closed`. |
| `operationStatus` | enum | Sí | `operating`, `windingDown`, `closed`. |
| `currentConfigVersionId` | ObjectId | No | Versión publicada vigente. |
| `profile` | object | Sí | 13 dimensiones (6.B). |
| `registrationProfile` | enum | Sí | ex `TIP_REG`/`TipoRegistracion`. |
| `calculationType` | int | Sí | ex `TIP_CAL`. |
| `calculationTypeLargeCustomers` | int | No | ex `TipoCalculo_GrandesClientes`. |
| `flags` | object | Sí | `requiresWorkOrder` (ex `TECNICA`), `autoWorkOrderOnSave` (ex `GENERAR_OT`, V2 332), `askAdminTerminationOnDisconnectionWO` (ex `CONSULTA_BAJA`), `meterInStock` (ex `REG_STO`), `autoSupplyCode` (ex `MATRICULA_AUTO`), `requiresFeasibility` (ex `FACTI_ALTA`), `initialReadingOnConnect` (ex `CONSUMO_ALTA`), `billWithoutConsumption` (ex `FAC_SIN_CONSUMO`), `autoCategoryByAge` (ex `CAT_AUTO`), `monthly` (ex `MENSUAL`). |
| `requirements` | object | Sí | Cada uno `noRequire|warn|require`: `cadastre` (ex `REG_CATASTRO`, V2 319), `property` (ex `REG_INMUEBLE`, V2 2462), `activity` (ex `REG_ACT`), `serviceClass` (ex `REG_CLS`), `route` (ex `REG_ZSR`, V2 213), `device` (ex `REG_DSP`), `guarantor` (ex `REG_GARANTE`), `reference` (V2 343), `installerCertificate` (V2 2343), `installerAndDateWhenCertificate` (V2 2529), `accountingGroup` (V2 2738). |
| `relatedService` | object | No | `{tenantServiceId, useConsumption: bool, onlyUnbilled: bool}` ex `REL_SER`, `USA_COT`, V2 2701/3143. |
| `consumptionSplitMode` | enum | No | `none`, `generalPeriod`, `periodAndSequence` (ex `DIVISION_CONSUMO` 1/2). |
| `members` | object | No | `{allowsAdherents (ADHER), allowsBeneficiaries (BENEF), adherentPricing (PRE_C_AD, ADH_PRE), excludeUnderOneYear (MENORES), excludeOlder (MAYORES), excludeDisability (DISCAPA), excludeRetired (JUBILAD), waitingPeriodDays (CARENCIA), requireHolderAdherent (V2 109), cascade: cascade|ask|none (V2 2401), allowDuplicateInService (V2 2400), askRemoveDuplicate (V2 2521), controlMemberDebt (V2 2545)}`. |
| `defaultOperationalStatus` | object | Sí | `{onActivation, onTermination, onReconnection, onMeterChange, onTransfer, onDisconnected}` → `serviceStatuses` (ex `COD_EST_ALTA`, `COD_EST_BAJA`, `COD_EST_RECONEXION`, `COD_EST_CAMBIOMEDIDOR`, `COD_EST_TRANSFERENCIA`, `COD_CON_DESCONECTADO`); `autoSelectPrincipal` (V2 2435). |
| `workOrderTypes` | object | No | `{activation (COD_TRAN_ALTA), categoryChange (V2 2330), transfer (COD_TRAN_TRANSFERENCIA), statusChange[] (V2 3194)}` → tipos de OT de TEC. |
| `transfer` | object | No | `{conditionAfter (CONDICION_TRANSFERENCIA), markOriginalSuperseded (V2 2541), memberMode (V2 2291), allowTerminated (V2 2599), chargeConcepts (V2 2782), markPrincipal (V2 3195)}`. |
| `defaultBillingGroupId` | ObjectId | Sí | ex `GF_DEFECTO`. |
| `phoneMobileType` | enum | No | ex `TIP_CELULAR`. |
| `uniqueness` | object | Sí | `{supplyCodeUnique (¬V2 2250), allowSameMeteredInAccount (V2 2269), allowSameUnmeteredInAccount (V2 2715), oneSocialPerHolder (V2 2740), validateSameAddress (V2 2710)}`. |
| `addressDebtCheck` | object | Sí | `{enabled (V2 2482), mode: warn|requireApproval (V2 2668), overdueOnly (V2 2669)}`. |
| `holderRules` | object | Sí | `{blockInactiveHolders (V2 734), blockTerminatedHolders (V2 741), allowReconnectionDeceased (V2 2301)}`. |
| `lifecycle` | object | Sí | `{allowedOperations{voluntarySuspension{enabled,maxDays}, reactivation, planChange, ownerChange, transfer, relocation, partialTermination, cession}, categoryChangeMode: immediate|scheduled|onWorkOrderClose (V2 2455), prorateCategoryChangeAfterDay (V2 2755), reconnectionKeepsStartSameMonth (¬V2 2707), allowTerminationWithInstallments (V2 2316), consumptionAfterTermination: deny|warn|allow (V2 2550), billingStatesCanonical[] }`. |
| `documents` | object | No | Plantillas (T11): `activationContract`, `serviceGuarantee` (V2 206), `terminationReport`, `disconnectionForm` (V2 2522), `applianceDeclaration` (V2 2742), `equipmentDelivery`, `equipmentReturn`; `askPrint{activation (V2 2532), termination (V2 2535)}`. |
| `channels` | object | Sí | `{landing, pwa, counter, phone, bot, publicTerminationButton}` por operación. |
| `mappings` | object | No | `{areaId, costCenterId, accountingAccounts{}, warehouseId, branchIds[]}`. |
| `integrations[]` | object[] | No | `{kind (provisioning, telemetering, batcom, discar, sitsa, aion), connectorId, events[]}`. |
| `copiedFrom` | object | No | `{tenantId, tenantServiceId, configVersionId, copyRunId}`. |

Índices: `{tenantId, code}` único; `{tenantId, capabilityId}`; `{tenantId, offerStatus}`.

### 7.3 `serviceConfigVersions`

Propósito: paquete versionado y publicable (AGR-009). Origen: `HIS_SERVICIO`, `HIS_SERVICIO_EXTRAS` (por cuadro).

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `tenantServiceId` | ObjectId | Sí | |
| `number` | int | Sí | Correlativo por servicio. |
| `status` | enum | Sí | `draft`, `inReview`, `approved`, `scheduled`, `published`, `superseded`, `rejected`, `discarded`. |
| `changeKinds[]` | enum[] | Sí | `commercial`, `fiscal`, `technical`, `presentation`. |
| `snapshot` | object | Sí | Copia inmutable de perfil + ids/versiones de productos, conceptos, planes, categorías, estados, reglas. |
| `diffFromPrevious` | object | No | Diferencias calculadas. |
| `validations[]` | object[] | Sí | `{code, severity: blocking|warning, message, ref}`. |
| `simulationRunIds[]` | ObjectId[] | No | Simulaciones TAR. |
| `effectiveFrom` | Date | Sí | Fecha efectiva. |
| `recordedAt` | Date | Sí | Fecha de registro (AGR-010). |
| `submittedBy`, `approvedBy`, `approvedAt`, `publishedAt` | | No | |
| `workflowInstanceId` | ObjectId | No | T11. |

Índices: `{tenantId, tenantServiceId, number}` único; `{tenantId, tenantServiceId, status, effectiveFrom}`.

### 7.4 `serviceConcessions`

Origen: `CONCESIO`. Campos: `code`, `name` (ex `NOM_CESI`), `grantor`, `authorityIds[]`, `jurisdiction`, `instrumentRef`, `validFrom`, `validTo`, `tenantServiceIds[]`, `documents[]`. Índice `{tenantId, code}` único.

### 7.5 `serviceProducts`

Propósito: productos y subservicios dentro de un servicio. Origen: `PROD_SER` (parte comercial), `TEL_SERVICIO`, `SERTEL`.

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `tenantServiceId` | ObjectId | Sí | |
| `code`, `labelKey` | string | Sí | |
| `kind` | enum | Sí | `main`, `addon` (subservicio), `equipment`, `oneTimeService`, `ticAccount` (correo), `phoneService`. |
| `attributes` | object | No | Según esquema de dominio (tecnología, velocidad…). |
| `requiresProductIds[]`, `excludesProductIds[]` | ObjectId[] | No | Compatibilidad. |
| `stockItemId` | ObjectId | No | Ítem STK cuando `kind=equipment`. |
| `status` | enum | Sí | `active`, `discontinued`. |
| `validFrom`, `validTo` | Date | Sí/No | |

Índices: `{tenantId, tenantServiceId, code}` único.

### 7.6 `billableConcepts`

Propósito: estructura de conceptos facturables (el precio vive en TAR). Origen: `PROD_SER` (COD_PRO, COD_RUB, DES_PRO, DES_FOR, UNI_MED, IVA_*), `SERTEL`, `IMPUESTOS_X_CAT` (referencia), `RUBCAPI`.

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `tenantServiceId` | ObjectId | No | Nulo = transversal (capital, tasas, franqueo). |
| `code`, `labelKey`, `invoiceLabelKey` | string | Sí | ex `DES_PRO`, `DES_FOR`. |
| `kind` | enum | Sí | `oneTime`, `recurring`, `perQuantity`, `perEvent`, `installment`, `adjustment`, `thirdPartyFee`, `capitalContribution`, `usage`, `penalty`, `waiver`. |
| `trigger` | enum | Sí | `approval`, `installationConfirmed`, `activation`, `periodStart`, `event`, `milestone`, `manual`. |
| `eventTypes[]` | enum[] | No | Para `perEvent`: `serviceActivation`, `accountCreation`, `holderCreation`, `reconnection`, `afterWorkOrder`, `beforeWorkOrder`, `transfer`, `suspension`, `relocation`. |
| `unitOfMeasure` | string | Sí | ex `UNI_MED`. |
| `fiscalClassId` | ObjectId | Sí | FIS. |
| `accountingRubricId` | ObjectId | No | ex `COD_RUB`. |
| `costCenterId` | ObjectId | No | |
| `thirdPartyId` | ObjectId | No | Para tasas. |
| `isInternalCost` | bool | Sí | true = costo interno, no facturable (BASE §72). |
| `rounding` | object | No | Precisión y regla (AGR-011). |
| `status`, `validFrom`, `validTo` | | Sí | |

Índices: `{tenantId, code}` único; `{tenantId, tenantServiceId, kind}`.

### 7.7 `servicePlans` y 7.8 `servicePlanVersions`

`servicePlans`: `tenantServiceId`, `productId`, `code` (ej. INT-100), `labelKey`, `status` (`draft`, `published`, `discontinued`, `retired`), `currentVersionId`, `offerChannels[]`, `publicVisibility`.

`servicePlanVersions`:

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `planId` | ObjectId | Sí | |
| `number` | int | Sí | |
| `attributes` | object | Sí | Esquema de dominio (velocidad, tecnología, unidad, modalidad medida/no medida). |
| `periodicity` | enum | Sí | `monthly`, `bimonthly`, `quarterly`, `yearly`, `perEvent`, `oneTime`. |
| `allowedCategoryIds[]` | ObjectId[] | Sí | |
| `components[]` | object[] | Sí | `{conceptId, mandatory, quantity, triggerOverride}`. |
| `promotions[]` | object[] | No | `{code, conceptIds[], durationUnit: calendarMonths|billedCycles|days, duration, partialFirstPeriodConsumes: bool, offerValidFrom, offerValidTo, compatibleWith[], priority}`. |
| `financingOptions[]` | object[] | No | `{conceptId, installments, downPaymentRule, method, mutuallyExclusiveWithCash: true}` (cronograma: MOR). |
| `equipment[]` | object[] | No | `{productId, mode: loan|sale|rent|customerOwned, mandatory, returnRequired}`. |
| `requirements` | object | Sí | `{feasibility, installation, technicalEvaluation, documents[]}`. |
| `tariffBinding` | object | Sí | `{tariffScheduleRef, categoryMap}` → TAR. |
| `effectiveFrom`, `effectiveTo`, `recordedAt` | Date | Sí | |
| `configVersionId` | ObjectId | Sí | |

Índices: `{tenantId, planId, number}` único; `{tenantId, planId, effectiveFrom}`.

### 7.9 `serviceBundles`

`code`, `labelKey`, `planVersionIds[]` (de servicios distintos), `rules` (`{terminationOfOne: keepOthers|terminateAll|loseBundleBenefit}`), `status`, `validFrom`, `validTo`.

### 7.10 `serviceCategories`

Propósito: categorías estructurales. Origen: `CATE_SER` (COD_SER, COD_CAT, DES_CAT; IVA y mínimos → TAR/FIS), `CATE_SER_EXTRAS`, `HIS_CATE_SER`, `HIS_CATE_SER_EXTRAS`.

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `tenantServiceId` | ObjectId | Sí | |
| `code`, `labelKey` | string | Sí | ex `COD_CAT`, `DES_CAT`. |
| `groupId` | ObjectId | No | → `serviceCategoryGroups`. |
| `isSocial` | bool | Sí | Reemplaza inferencia (RN-CAT-016). |
| `isPrepaid` | bool | Sí | Destino válido del paso a prepago. |
| `isResidential` | bool | No | |
| `isGenerator` | bool | No | ex `GENERADOR`. |
| `subsidizedCategoryId`, `sefCategoryId` | ObjectId | No | ex `COD_CATSER_SS`, `COD_CATSER_SEF`. |
| `regulatoryCodes` | object | No | `{tariffCode (CODIGO_TARIFA), arbaPresentationType (TIPO_PRESENTACION_ARBA), seId (ID_SE), enargas}`. |
| `networkProfileCode` | string | No | ex `PERFIL_MIKROTIK` (INT). |
| `adherentCount` | int | No | ex `CAN_ADH` (tipos 9/10). |
| `allowsProportionalChange` | bool | No | ex `PROP_CAMBIO_CAT`. |
| `housingMinimums` | object | No | ex `VIV_MIN_*`, `VIV_MAX_ANUAL_ANTES_ENTREGA`, `VIV_FECHA_APORTE_TEORICO`. |
| `consumeMinimumOnTermination` | bool | No | V2 2465 (marca consumida por TAR). |
| `status`, `validFrom`, `validTo` | | Sí | |

Índices: `{tenantId, tenantServiceId, code}` único.

### 7.11 `serviceCategoryGroups`

Origen `GRP_CAT`: `code`, `labelKey` (ex `DES_GRU`), `regulatoryCode` (ex `COD_ENGAS`), `tenantServiceId`.

### 7.12 `serviceClasses`

Origen `CLASESER`: `tenantServiceId`, `code`, `labelKey` (ex `DES_CLS`), `value1`, `value2` (Decimal128; ex `VALOR1`, `VALOR2`), `notes` (ex `OBS_CLS`), `thirdPartyConceptId` (si la clase representa una tasa).

### 7.13 `serviceProperties`

Origen `PROPIESER` y propiedades personalizadas (`abm_propieItems`): `tenantServiceId`, `code`, `labelKey` (ex `DES_PROP`/`NOM_PROP`), `valueType` (`text`, `number`, `list`, `bool`, `date`), `listValues[]`, `tension` (ex `TENSION_OCEBA`), `linkedConcepts` (`{minimumConceptId (IMP_MINM/IMP_CMINM), fixedChargeConceptId (COD_CF/IMP_CF/CAN_CF), cmConceptId (COD_CM)}` — importes en TAR).

### 7.14 `serviceStatuses`

Origen `ESTASER` (COD_EST, COD_SER, DES_EST, DESCONEC, PRINCIPAL).

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `tenantServiceId` | ObjectId | Sí | |
| `code`, `labelKey` | string | Sí | ej. CONECTADO, CORTADO, BAJA. |
| `canonicalStatus` | enum | Sí | Estado canónico (sección 8). |
| `impliesDisconnection` | bool | Sí | ex `DESCONEC`. |
| `isPrincipal` | bool | Sí | ex `PRINCIPAL` (uno por canónico). |
| `visibleToMember` | bool | Sí | Si se muestra al socio o se muestra el canónico. |
| `color`, `order` | | No | |

Índices: `{tenantId, tenantServiceId, code}` único.

### 7.15 `eventChargeRules` y 7.16 `eventChargeWaivers`

`eventChargeRules` (origen `CONEXION`, `abm_Conexion`): `tenantServiceId`, `eventType` (1 alta de servicio, 2 alta de cuenta, 3 alta de titular, 4 reconexión, 5 después de la OT, 6 antes de la OT, 7 transferencia), `conceptId` (ex `COD_PRO`/`COD_CON`), `quantity`, `oncePerContractEvent` (ex `UNA_VEZ`), `filters` (`{memberActive, delinquent, prepaid, referenceIds[], localityIds[], categoryIds[], classIds[], meterRemoved, provisional, propertyIds[], statusIds[], workOrderTypeIds[] (COD_TRAN)}`), `allowAmountOverride`, `amountCap`, `requiresMorPolicy` (bool), `status` (ex `DESACTIVAR`), `validFrom`, `validTo`.

`eventChargeWaivers` (origen `CONE_BONIF`): `accountId` (ex `COD_SUM`), `tenantServiceId`, `eventType` (ex `COD_TRAN`), `conceptId`, `categoryId`, `waivedQuantity` (ex `CANT_BONIFICADAS`), `usedQuantity`, `reason`, `approvedBy`.

### 7.17 `autoServiceRules`

Origen `ALTASEAU` (ID_AS, DES_AS, TIPO_AS, COD_SER, COD_CAT, COD_LOC, ZONA, TIT_SOC, COD_SAS, COD_CAS, COD_REF, COD_CLS, COD_ACT…).

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `labelKey` | string | Sí | ex `DES_AS`. |
| `triggerEvent` | enum | Sí | `serviceActivated`, `accountCreated`, `serviceTerminated`, `serviceReconnected`, `categoryChanged`, `workOrderCreated`, `addressChanged` (ex `OperacionServicioAutomatico` 1–7). |
| `sourceTenantServiceId` | ObjectId | Sí | ex `COD_SER`. |
| `targetTenantServiceId`, `targetCategoryId` | ObjectId | Sí | ex `COD_SAS`, `COD_CAS`. |
| `filters` | object | No | `{categoryIds, propertyIds, classIds, activityIds, localityIds, referenceIds, zones, meterTypeIds, holderCondition: all|activeOnly|inactiveOnly}`. |
| `billingGroupMode` | enum | Sí | `targetDefault`, `inheritFromSource` (ex `TOMAR_GRUPO`). |
| `mode` | enum | Sí | `propose`, `create` (PA-CAT-04). |
| `legalBasis` | string | Cond. | Obligatorio si `mode=create` y el servicio destino es opcional para el socio. |
| `status`, `validFrom`, `validTo` | | Sí | |

### 7.18 `serviceContracts`

Propósito: contrato de servicio (suscripción). Origen: `SERSOC` (+106 columnas), `SERSOC_EXTRAS`, `INTERNET` (no secretos), `TEL_SERSOC`, `VIVIENDAS` (referencia).

| Campo | Tipo | Oblig. | Descripción / origen |
|---|---|---|---|
| `number` | string | Sí | Número de contrato visible; único por tenant (ex `ID_SERSOC` / "Contrato"). |
| `tenantServiceId` | ObjectId | Sí | ex `COD_SER`. |
| `holderPersonId` | ObjectId | Sí | Titular DNI/CUIT (ex `COD_SOC`). |
| `accountId` | ObjectId | Sí | Cuenta (ex `COD_SUM`). |
| `payerAccountId` | ObjectId | No | Si difiere (AGR-007). |
| `planId`, `planVersionId` | ObjectId | Cond. | Obligatorio si el servicio tiene planes. |
| `categoryId` | ObjectId | Sí | ex `COD_CAT`. |
| `categoryHistory[]` | object[] | Sí | `{categoryId, validFrom, validTo, reason, origin, previousCategoryId (CAT_ANT)}`. |
| `serviceClassId` | ObjectId | No | ex clase. |
| `propertyValues[]` | object[] | No | `{propertyId, value, validFrom}`. |
| `activityId` | ObjectId | No | Actividad ARCA. |
| `quantity` | Decimal128 | Cond. | ex `CANTIDAD`. |
| `serviceAddress` | object | Sí | `{streetId, number, floor, unit, neighborhood, localityId, postalCode, referenceId, cadastre{cod,sec,man,par,ph,lote} (CAT_CIR/CAT_LOT/CAT_MAN/CAT_PAR/CAT_PH/CAT_LT), propertyId, geo{lat,lng}, gisRef, validFrom}`. |
| `addressHistory[]` | object[] | Sí | Domicilios anteriores con vigencia. |
| `route` | object | No | `{zone, sector, route}` (ZSR). |
| `supplyCode` | string | No | Matrícula. |
| `meteringPointId` | ObjectId | No | → MED. |
| `externalClientId` | string | No | "Id Cliente". |
| `feasibilityRef` | ObjectId | No | ex `COD_SOL` (`FACTIBIL`, TEC). |
| `declaredAffidavitRef` | ObjectId | No | DD JJ. |
| `guarantorPersonId` | ObjectId | No | Garante. |
| `installer` | object | No | `{professionalId (PROFESIO), certificateNumber, certificateExpiresAt}`. |
| `dueDate` | Date | No | "Fecha Vto". |
| `billingGroupId` | ObjectId | Sí | ex `GRUPO_FACTURA`. |
| `lastBilledPeriod` | string | No | ex `ULT_FAC` (proyección de FAC). |
| `lifecycleStatus` | enum | Sí | Canónico (sección 8). |
| `operationalStatusId` | ObjectId | Sí | → `serviceStatuses`. |
| `statusChangedAt`, `statusChangedBy`, `statusReason` | | Sí | "fecha del último estado". |
| `suspension` | object | No | `{reason: voluntary|debt|technical|regulatory|administrative, mode: restricted|interrupted, requestedAt, effectiveAt, expectedEndAt, orderedBy (module), commandId}`. |
| `dates` | object | Sí | `{requestedAt, adminStart (ALTA_ADM), effectiveStart (FEC_ALTA), terminationRequestedAt (BAJA_ADM), effectiveEnd (FEC_BAJA), cancelledAt}` — `null` cuando no corresponde. |
| `flags` | object | Sí | `{doNotBill{active, reason, until, approvedBy}, provisional{active, until}, billWhileProvisional, noRecategorization (NO_APLICA_RECATEGORIZACION), readingWithMultiplier, sendEInvoice (V2 2642), noLateFee (V2 3135, referencia COB)}`. |
| `origin` | object | Sí | `{channel: counter|pwa|landing|bot|phone|autoRule|transfer|migration, crmCaseId, autoRuleId, transferFromContractId, createdFromPortal (Alta desde CoopOnline)}`. |
| `agreedConditions[]` | object[] | Sí | Tramos `{planVersionId, components[], promotions[]{code, startsAt, endsAt, unitsConsumed}, financingChoice, acceptedAt, acceptanceChannel, evidenceDocId, validFrom, validTo}`. |
| `domainAttributes` | object | No | Según `domainAttributeSchema` (INT: `accessIdRef`, `nodeRef`, `oltPortRef`, `macRef`, `ipRef`; TEL: `lines[]{numberRef, tariffRef, from, to}`; ELE: `voltage`, `contractedPowerKw`, `supplyType`, `electroDependent{validFrom, validTo, evidenceDocId}`, `nis`; GAS: `gasType`, `subdistribution`, `technicalFileRef`; OBR: `installments{total, paid, units, unitsBilled, unitsTotal, unitsOriginal, pctBasic, pctNetworks, planRef}`; VIV: `housingFileRef`; CEM: `rightRef`; SAN/SAL: `agreementRef`). |
| `capitalAmountAtActivation` | Decimal128 | No | ex `IMP_CAPITAL` (concepto CAP). |
| `parentContractId` | ObjectId | No | Contrato principal (ALU sobre ELE). |
| `bundleSubscriptionId` | ObjectId | No | Paquete. |
| `observations` | string | No | ex `OBSERVA` (visible según V2 2557). |
| `supersededByContractId` | ObjectId | No | Transferencia. |
| `migration` | object | No | `{sourceSystem: 'procoop', sourceId (ID_SERSOC), importedAt}`. |

Índices: `{tenantId, number}` único; `{tenantId, accountId, tenantServiceId, lifecycleStatus}`; `{tenantId, holderPersonId}`; `{tenantId, tenantServiceId, supplyCode}` (único parcial cuando `uniqueness.supplyCodeUnique` y estado ≠ `terminated|superseded|cancelled`); `{tenantId, lifecycleStatus, tenantServiceId}`; `{tenantId, "serviceAddress.propertyId"}`; `{tenantId, billingGroupId}`.

### 7.19 `serviceContractHistory`

Origen `SERSOC_HST` (+109 columnas, foto completa por cambio). En GoodApps: evento por transición o cambio de atributo.

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `contractId` | ObjectId | Sí | |
| `eventType` | enum | Sí | `created`, `statusChanged`, `planChanged`, `categoryChanged`, `classChanged`, `activityChanged`, `referenceChanged`, `addressChanged`, `holderTransferred`, `flagChanged`, `memberChanged`, `equipmentChanged`, `attributeChanged`, `note` (ej. "Recategorización"). |
| `from`, `to` | object | Sí | Valores anteriores y nuevos. |
| `effectiveAt` | Date | Sí | Fecha efectiva. |
| `recordedAt` | Date | Sí | Fecha de registro. |
| `actor` | object | Sí | `{userId|system, module, commandId}`. |
| `sourceRef` | object | No | `{crmCaseId, workOrderId, bulkOperationId, morOrderId}`. |

Índices: `{tenantId, contractId, effectiveAt}`; colección append-only.

### 7.20 `contractEquipmentAssignments`

Origen `SERSOC_PRODUCTOS` (ID_SERPROD, ID_SERSOC, COD_PRO, COD_PTH, FECHA_ENTREGA, FECHA_DEVOLUCION, FECHA_DEVUELTO, OBSERVA, COD_DPS, PRECIO).

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `contractId` | ObjectId | Sí | |
| `productId` | ObjectId | Sí | ex `COD_PRO`. |
| `stockUnitId` | ObjectId | Cond. | Unidad serializada STK (ex `COD_PTH`). |
| `serialNumber` | string | Cond. | Proyección. |
| `warehouseId` | ObjectId | Sí | ex `COD_DPS`. |
| `mode` | enum | Sí | `loan`, `sale`, `rent`, `customerOwned`. |
| `status` | enum | Sí | `assigned`, `delivered`, `returnPending`, `returned`, `lost`, `chargedAsLost`, `replaced`. |
| `deliveredAt` | Date | Sí | ex `FECHA_ENTREGA`. |
| `expectedReturnAt` | Date | No | ex `FECHA_DEVOLUCION`. |
| `returnedAt` | Date | No | ex `FECHA_DEVUELTO`. |
| `referencePrice` | Decimal128 | No | ex `PRECIO` (valorización en STK). |
| `deliveryEvidenceDocId`, `returnEvidenceDocId` | ObjectId | No | Constancias firmadas. |
| `workOrderId` | ObjectId | No | |
| `notes` | string | No | ex `OBSERVA`. |

Índices: `{tenantId, contractId, status}`; `{tenantId, stockUnitId}` único parcial con `status in [assigned, delivered, returnPending]`.

### 7.21 `applianceTypes` y `contractDeclaredAppliances`

`applianceTypes` (origen `ARTEFACTO`): `code`, `labelKey` (ex `DES_ART`), `isObservation` (ex `ES_OBSERVA`), `tenantServiceIds[]`.

`contractDeclaredAppliances` (origen `ARTEFSUMS`, `HIS_ARTEFSUMS`): `contractId`, `applianceTypeId` (ex `COD_ART`), `quantity` (ex `CAN_ART`), `brand` (ex `MAR_ART`), `serialNumber` (ex `SN_ART`), `model` (ex `MD_ART`), `declaredDate` (ex `FEC_ART`), `use` (ex `USU_ART`), `status` (ex `ESTADO`), `notes` (ex `OBS_ART`/`OBSERVA`), `declarationDocId`, `history[]` (append-only, ex `HIS_ARTEFSUMS`), `recordedAt` (ex `FEC_REG`).

### 7.22 `contractMembers`

Origen `ADHSOC` (COD_ADH, COD_SOC, COD_SUM, COD_SER, COD_PER, COD_VIN, TITULAR, FEC_ALT, FEC_BAJ, FEC_IMP, MAR_IMP, RECUPERA, COD_TAD…), `BENSOC` (COD_BEN, COD_SOC, COD_SUM, COD_SER, COD_PER, COD_VIN, FEC_ALT, FEC_BAJ, COD_CSE, OBSERVA, ACTIVO, ID_SERSOC).

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `contractId` | ObjectId | Sí | |
| `role` | enum | Sí | `adherent`, `beneficiary`. |
| `personId` | ObjectId | Sí | PER. |
| `relationshipTypeId` | ObjectId | Sí | PER (ex `VINCULOS`). |
| `isHolder` | bool | Sí | ex `TITULAR`. |
| `adherentTariffId` | ObjectId | No | TAR (ex `COD_TAD`). |
| `benefitRef` | ObjectId | No | Para beneficiarios de beneficio (tarifa social) o cobertura. |
| `joinedAt`, `leftAt`, `leaveReason` | Date/enum | Sí/No | `voluntary`, `deceased`, `outOfRange`, `transfer`, `contractTerminated`. |
| `coverageFrom` | Date | No | `joinedAt` + carencia. |
| `cardPrintedAt`, `cardPrintMark` | | No | ex `FEC_IMP`, `MAR_IMP` (credencial). |
| `recovered` | bool | No | ex `RECUPERA` [VERIFICAR] semántica. |
| `notes` | string | No | |

Índices: `{tenantId, contractId, role, leftAt}`; `{tenantId, personId}`.

### 7.23 `generationAgreements`

MER-001: `contractId` (suministro ELE), `generatorClassification`, `installedPowerKw` (ex `POTENCIA_GENERA`), `equipment`, `connectedAt` (ex `ALTA_GENERA`), `installerId`, `bidirectionalMeterRef` (MED), `injectionTariffRef` (TAR), `status` (`requested`, `active`, `terminated`), `validFrom`, `validTo`, `documents[]`. La cuenta de créditos vive en COB/FAC.

### 7.24 `contractSpecialConditions`

MER-003: `contractId`, `version`, `priceTermsRef` (TAR), `contractedPower{peakKw, offPeakKw}`, `termMonths`, `penalties[]`, `requiresInvoicePreReview` (bool), `approvedBy`, `approvedAt`, `validFrom`, `validTo`, `status`.

### 7.25 `serviceCopyRuns`

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `sourceTenantId`, `sourceTenantServiceId`, `sourceConfigVersionId` | ObjectId | Sí | |
| `targetTenantId` | ObjectId | Sí | `tenantId` del documento = destino. |
| `targetTenantServiceId` | ObjectId | No | Existente o creado. |
| `targetMode` | enum | Sí | `createService`, `newDraftVersion`. |
| `components` | object | Sí | `{products, plans, concepts, categories, classes, properties, statuses, eventChargeRules, autoRules, forms, ticketTypes, templates, surveyTemplates}` (bool cada uno). |
| `dependencies[]` | object[] | Sí | `{kind (area, costCenter, account, warehouse, tariff, tax, authority, branch, connector), sourceRef, resolution: mapped|pending|keepTarget, targetRef}`. |
| `excluded[]` | string[] | Sí | Constante: persons, users, contracts, addresses, invoices, debt, payments, tickets, surveyResponses, physicalStock, serials, credentials. |
| `status` | enum | Sí | `requested`, `authorized`, `running`, `completedWithPending`, `completed`, `failed`, `cancelled`. |
| `authorization` | object | Sí | `{sourceApprovedBy, sourceApprovedAt, platformOperatorId}`. |
| `idempotencyKey` | string | Sí | |
| `result` | object | No | Ids creados, advertencias, versión destino. |

Índices: `{tenantId, idempotencyKey}` único.

### 7.26 `bulkContractOperations`

Origen: trámites masivos (`clsTramites`) y cambios masivos de categoría. Campos: `operation` (`markProvisional`, `changeActivity`, `changeClass`, `changeCategory`, `changeReference`, `terminate`, `recategorize`, `resetCategories`, `memberOutOfRangeAction`), `criteria`, `contractIds[]`, `alsoUnbilledConsumption` (bool), `requestedBy`, `originModule` (`cat`, `mor`, `tar`), `status` (`draft`, `simulated`, `approved`, `running`, `completed`, `partiallyFailed`, `reverted`), `results[]{contractId, outcome, message}`, `revertibleUntil`, `jobId`.

### 7.27 `serviceTemplates` (plataforma)

`capabilityId`, `code`, `labelKey`, `snapshot` (perfil, productos, planes sin precios, categorías, estados, reglas), `version`, `status`. A validar (PA-CAT-08).

### 7.28 Relaciones principales

`serviceCapabilities 1—N tenantServices 1—N serviceConfigVersions`; `tenantServices 1—N serviceProducts 1—N servicePlans 1—N servicePlanVersions`; `tenantServices 1—N serviceCategories / serviceClasses / serviceProperties / serviceStatuses / billableConcepts / eventChargeRules`; `serviceContracts N—1 tenantServices, N—1 persons, N—1 accounts, N—1 servicePlanVersions`; `serviceContracts 1—N serviceContractHistory / contractEquipmentAssignments / contractMembers / contractDeclaredAppliances`; `serviceContracts 1—0..1 generationAgreements / contractSpecialConditions`.

## 8. Estados y transiciones

### 8.1 Reconciliación de fuentes

| ProCoop `CONDICION` (RN-01 §2, RN-06 §4.1) | ProCoop `ESTASER` (ejemplos) | BASE §48/§53/§89 | Estado canónico GoodApps |
|---|---|---|---|
| — (la solicitud vive en trámites/CoopOnline) | — | Solicitud registrada sin contrato activo | `requested` — Solicitado |
| — (`FACTIBIL` separado) | — | Factibilidad/cobertura | `feasibility` — En factibilidad |
| 1 Pendiente de conexión (sin `FEC_ALTA`) | (pendiente) | Aprobado, pendiente de instalación | `pendingInstallation` — Pendiente de instalación/conexión |
| 2 Conectado | CONECTADO | Activo | `active` — Conectado/Activo |
| 2 (con `ESTASER` que implica desconexión) | CORTADO | Suspensión por mora / otro motivo / temporal solicitada | `suspended` — Suspendido (motivo y modo) |
| — | — | Rehabilitación en trámite | `reactivationPending` — Rehabilitación en trámite |
| 3 Pendiente de desconexión (`BAJA_ADM` sin `FEC_BAJA`) | — | Baja solicitada/en ejecución | `pendingTermination` — Baja en trámite |
| 4 Baja/desconectado (`FEC_BAJA`) | BAJA | Baja contractual efectiva | `terminated` — Baja |
| — (OT de alta eliminada, V2 2753 → 5) | — | Desistimiento/rechazo antes de activar | `cancelled` — Anulado/Desistido |
| 5 No vigente (transferencia, V2 2541) | — | — | `superseded` — No vigente (reemplazado) |

Los estados operativos del tenant (`serviceStatuses`) se muestran y operan; el canónico gobierna reglas, facturación y permisos.

### 8.2 Transiciones del contrato

| # | Origen → Destino | Comando / evento | Actor | Precondiciones | Efectos | Reversión |
|---|---|---|---|---|---|---|
| T01 | (nuevo) → `requested` | `cat.contract.create` desde `crm.request.admitted` o mostrador | CRM / operador | Servicio con oferta abierta; titular identificado; plan publicado; canal habilitado | Contrato con `dates.requestedAt`; sin facturación; evento `cat.contract.requested` | `cancel` (T13) |
| T02 | `requested` → `feasibility` | `requestFeasibility` | Sistema/operador | Servicio exige factibilidad | Pedido a TEC; `feasibilityRef` | `cancel` |
| T03 | `feasibility` → `pendingInstallation` | `tec.feasibility.resolved` (aprobada) | TEC | Factibilidad aprobada | Si técnico: pedido de instalación/OT de alta; `dates.adminStart` | Volver a `feasibility` solo si TEC revoca antes de agendar |
| T04 | `feasibility` → `cancelled` | `tec.feasibility.resolved` (rechazada) | TEC | — | Motivo; notificación al socio vía CRM | Nueva solicitud |
| T05 | `requested` → `pendingInstallation` | `approve` | Supervisor | Servicio sin factibilidad; requisitos cumplidos | Igual T03 | `cancel` |
| T06 | `pendingInstallation` → `active` | `tec.installation.completed` / `tec.workOrder.closed(activation)` (técnico) o `activate` (no técnico) | TEC / supervisor | RN-CAT-064; equipos obligatorios asignados; provisión confirmada (INT) | `dates.effectiveStart`; estado operativo `onActivation`; conceptos por evento tipo 1/5; lectura inicial (MED); `cat.contract.activated` (FAC inicia devengamiento; altas automáticas) | Solo por `cancelActivation` en el mismo día sin facturación emitida; si no, baja |
| T07 | `pendingInstallation` → `pendingInstallation` (reagenda) | `tec.visit.failed` | TEC | Visita fallida | Registra intento; no cambia estado; indicador "visitas fallidas" (BASE §86) | — |
| T08 | `active` → `suspended` | `suspend{reason, mode}` desde `mor.suspension.ordered`, solicitud voluntaria ejecutada, orden técnica/regulatoria | MOR / CRM / TEC / supervisor | Operación permitida en el perfil; para mora: política MOR y límites normativos (electrodependencia, etc.) | `suspension{}`; estado operativo con `impliesDisconnection` si corresponde; orden técnica si `interrupted` en servicio técnico; `cat.contract.suspended` | `reactivate` |
| T09 | `suspended` → `reactivationPending` | `requestReactivation` (pago confirmado por MOR, fin de suspensión voluntaria, solicitud) | MOR / CRM / sistema | Causa de suspensión levantada | Pedido de reconexión a TEC (si técnico o requiere inspección) | Volver a `suspended` si TEC rechaza (ej. inspección de gas fallida) |
| T10 | `reactivationPending` → `active` | `tec.workOrder.closed(reconnection)` / `tec.provisioning.confirmed` o `reactivate` directo en no técnico | TEC / sistema | Confirmación técnica | Regla de fecha de alta (RN-CAT-043); conceptos tipo 4 si la política MOR lo habilita; estado `onReconnection`; `cat.contract.reactivated` | — |
| T11 | `suspended` → `active` | `reactivate` | Sistema / supervisor | Servicio no técnico sin inspección (reconexión automática por pago, V2 3112 en MOR) | Igual T10 | — |
| T12 | `active`/`suspended` → `pendingTermination` | `requestTermination` (solicitud CRM ejecutable, decisión de la cooperativa con causa, orden de MOR para baja definitiva) | CRM / supervisor / MOR | Ninguna para baja solicitada por el socio (sin cargo, sin bloqueo por deuda) | `dates.terminationRequestedAt`; OT de desconexión si técnico (RN-CAT-039/040); equipos → `returnPending` | `withdrawTermination` antes de la efectiva (desistimiento del socio) → estado previo |
| T13 | `requested`/`feasibility`/`pendingInstallation` → `cancelled` | `cancel{reason}` | Socio (desistimiento) vía CRM / supervisor / TEC (OT de alta eliminada) | Sin activación; si hay equipo entregado → `returnPending` | `dates.cancelledAt`; no genera retiro si no hubo instalación | Nueva solicitud |
| T14 | `pendingTermination` → `terminated` | `tec.workOrder.closed(disconnection)` o `terminate` (no técnico) | TEC / supervisor | — | `dates.effectiveEnd` (y `terminationRequestedAt` si vacío, RN-CAT-041); lectura final (MED); facturación final (FAC); cascada a miembros; altas automáticas de evento baja; `cat.contract.terminated` | No reversible: reactivar un contrato terminado exige nueva alta (BASE §53), salvo `reopenTermination` dentro de N días sin facturación final emitida (PRM-CAT-047) |
| T15 | `active`/`suspended`/`pendingTermination` → `superseded` | `transfer` | Supervisor | Reglas de transferencia (RN-CAT-051..054) | Contrato nuevo en destino (`requested`→`active` inmediato con fecha de transferencia o mantenida); original con `effectiveEnd` y `supersededByContractId` | No reversible; corrección por nueva transferencia |
| T16 | `terminated` → `superseded` | `transfer` de contrato dado de baja | Supervisor | V2 2599 activo | Igual T15 | — |
| T17 | cualquier no terminal → mismo estado | `changePlan`, `changeCategory`, `changeClass`, `relocate`, `setFlag`, `changeHolderPayer` | según capability | Operación permitida | Nuevo tramo/historia; OT si corresponde | Por nueva operación |

Estados terminales: `terminated`, `cancelled`, `superseded`. Marcas no canónicas que se muestran en la ficha sin cambiar el estado: "Baja solicitada (en CRM)", "Suspensión solicitada", "Cambio de plan programado", "Provisorio vence el dd-mm-yyyy".

### 8.3 Estados de otras entidades

| Entidad | Estados | Transiciones clave |
|---|---|---|
| `serviceCapabilities` | `draft` → `available` → `deprecated` | `deprecated` impide nuevas habilitaciones; tenants existentes siguen operando. |
| `tenantServices.enablement` | `enabled` ⇄ `disabled` | `disabled` solo si `operationStatus=closed` o con plan de salida (RN-CAT-003). |
| `tenantServices.offerStatus` | `notPublished` → `open` ⇄ `closed` | `open` exige versión publicada sin bloqueos. |
| `serviceConfigVersions` | `draft` → `inReview` → `approved` → `scheduled` → `published` → `superseded`; `inReview` → `rejected` → `draft`; `draft` → `discarded` | Publicar exige validaciones sin bloqueos; la anterior pasa a `superseded` en `effectiveFrom`. |
| `servicePlans` | `draft` → `published` → `discontinued` → `retired` | `retired` solo sin contratos no terminales. |
| `contractEquipmentAssignments` | `assigned` → `delivered` → `returnPending` → `returned` / `lost` → `chargedAsLost`; `delivered` → `replaced` | `lost` dispara concepto de equipo no devuelto solo si está configurado y aceptado en condiciones. |
| `serviceCopyRuns` | `requested` → `authorized` → `running` → `completed` / `completedWithPending` / `failed`; `requested` → `cancelled` | Reintento idempotente desde `failed`. |
| `bulkContractOperations` | `draft` → `simulated` → `approved` → `running` → `completed` / `partiallyFailed` → `reverted` | Reversión mientras `revertibleUntil` y sin facturación con el cambio. |
| `generationAgreements` | `requested` → `active` → `terminated` | Termina con el suministro. |

## 9. Procesos y flujos

### 9.1 Lanzar un servicio en un tenant (CU-05, CU-CAT-01)

1. Plataforma verifica licencia (T01) y habilita la capacidad (`tenantServices.enablement=enabled`).
2. El administrador crea la versión de configuración 1 en `draft` (desde cero, plantilla o copia).
3. Completa perfil (13 dimensiones), productos, conceptos, planes, categorías, clases, propiedades, estados y mapeos.
4. Solicita a TAR el cuadro tarifario y vincula los planes (`tariffBinding`).
5. El sistema ejecuta validaciones (RN-CAT-005) y simulación de primera factura sin crear deuda (TAR/FAC en modo simulación).
6. Envía a revisión; un aprobador distinto aprueba (RF-CAT-035).
7. Publica con fecha efectiva; `offerStatus=open`; evento `cat.tenantService.published`; landing y PWA muestran la oferta.

### 9.2 Alta de contrato — piloto Internet (CU-PRO-01, CU-SOL-01 en lo que toca al contrato)

1. CRM admite la solicitud de Ana (`crm.request.admitted` con titular, domicilio, plan elegido, aceptación de condiciones) → CAT crea contrato en `requested` (T01) (PA-CAT-01).
2. Como INT exige factibilidad → `feasibility` (T02); TEC evalúa cobertura.
3. Factibilidad aprobada → `pendingInstallation` (T03); TEC agenda la visita (M10).
4. En la visita, el técnico asigna la ONT en comodato (`contractEquipmentAssignments.assigned/delivered`, STK mueve la unidad), instala, prueba, toma conformidad firmada.
5. TEC confirma aprovisionamiento (MikroTik/OLT) → `tec.installation.completed` → CAT activa (T06), registra `effectiveStart`, estado operativo "CONECTADO", genera conceptos por evento (instalación) y publica `cat.contract.activated`.
6. FAC/TAR inician el devengamiento del abono desde la activación con promoción y prorrateo según condiciones (M04/M05).

### 9.3 Suspensión, reactivación y baja (CU-CIC-01 en lo que toca al contrato)

- **Voluntaria:** CRM registra la solicitud; si el perfil la admite, al ejecutarse se envía `suspend{reason:voluntary}`; al vencer `expectedEndAt` el job `cat:fin-suspension-voluntaria` solicita la reactivación.
- **Por mora:** MOR emite `mor.suspension.ordered` → CAT T08 (modo según servicio) → TEC ejecuta si `interrupted`. Pago y orden de MOR → T09/T10 o T11.
- **Baja:** CRM recibe por cualquier canal (incluido botón público) → al ejecutarse, `requestTermination` (T12) → TEC desconecta y retira equipo → T14. La baja no espera la devolución del equipo; el pendiente queda en la bandeja.

### 9.4 Cambio de plan y de categoría

1. Solicitud (CRM o mostrador) con plan destino y fecha deseada.
2. CAT valida compatibilidad, requisitos y operación permitida; calcula (vía TAR) el efecto sobre el período en curso y promociones (PA-CAT-15).
3. Aceptación del socio (evidencia) → nuevo tramo en `agreedConditions` con `validFrom`.
4. Si requiere cambio técnico (velocidad), pedido de reprovisión a TEC; el tramo rige desde la confirmación.
5. Cambio de categoría: según `categoryChangeMode` inmediato, programado o al cerrar OT (V2 2330/2455); proporcional según día límite (V2 2755).

### 9.5 Transferencia de servicio (RN-06 §7)

1. Supervisor elige contrato origen y cuenta/titular destino; el sistema muestra deuda del origen (que no se transfiere), adherentes y equipos.
2. Valida reglas (titular destino activo, contratos dados de baja, conceptos de transferencia).
3. Crea contrato destino (mantener fecha opcional), traslada línea, beneficiarios, vivienda, punto de suministro, propiedades; adherentes según modo.
4. Cierra el origen como `superseded` (o `terminated`), con `supersededByContractId`.
5. Genera conceptos por evento tipo 7; sincroniza integraciones configuradas (ex AION).

### 9.6 Copia de servicio entre tenants (CU-COP-01)

1. Operador autorizado elige origen (TEN-001/INT/v1) y destino (TEN-002); el tenant origen autoriza la lectura (PA-CAT-07).
2. Elige componentes; el sistema arma la lista de dependencias y la clasificación copiar/conservar/mapear.
3. Job `cat:copiar-servicio` crea `tenantService` o versión `draft` en destino; registra procedencia; excluye datos operativos y credenciales.
4. B resuelve pendientes (precios TAR, calendario, área técnica, cuentas, cobertura, marca y lenguaje propios).
5. Simula una contratación y la primera factura sin deuda real.
6. Aprueba y publica (9.1 pasos 6-7). Cambios posteriores en A no afectan a B.

### 9.7 Altas automáticas (RN-06 §3.5)

1. Un evento (`cat.contract.activated`, `per.account.created`, `cat.contract.terminated`, `cat.contract.reactivated`, `cat.contract.categoryChanged`, `tec.workOrder.created`, `cat.contract.addressChanged`) dispara `cat:altas-automaticas`.
2. El job evalúa reglas vigentes del servicio origen y filtros; verifica no duplicado (RN-CAT-036).
3. Modo `propose`: crea tarea para el operador con el contrato propuesto. Modo `create`: crea el contrato destino (`requested` → `active` si no técnico) con grupo de facturación según regla y `origin.autoRuleId`.
4. Para el evento baja, la regla puede proponer la baja de contratos accesorios (`parentContractId`).

### 9.8 Trámites masivos y recategorización

1. Usuario o módulo (TAR para segmentación, MOR para paso a prepago) crea `bulkContractOperations` en `draft` con criterio.
2. Simulación: lista de contratos afectados, excluidos y motivo (marca "No aplica recategorización", bajas > 60 días, validación de desconexión para bajas).
3. Aprobación; job `cat:tramite-masivo` procesa en lotes de 1000 de forma idempotente y reanudable; cada contrato genera historia y nota.
4. Resultado por contrato; reversión disponible según `revertibleUntil`.

### 9.9 Jobs

| Job | Disparador | Descripción | Reintentos / recuperación |
|---|---|---|---|
| JOB-CAT-01 `cat:altas-automaticas` | Evento | Evalúa `autoServiceRules`. | Idempotente por `(eventId, ruleId)`; 5 reintentos exponenciales; DLQ con alerta. |
| JOB-CAT-02 `cat:tramite-masivo` | Aprobación | Ejecuta `bulkContractOperations` por lotes. | Reanudable desde el último lote confirmado. |
| JOB-CAT-03 `cat:copiar-servicio` | Comando | Copia configuración entre tenants. | Idempotente por `idempotencyKey`; transacción por componente; estado `completedWithPending`. |
| JOB-CAT-04 `cat:publicar-version-programada` | Diario 00:05 zona del tenant | Publica versiones `scheduled` cuyo `effectiveFrom` llegó. | Reintento horario. |
| JOB-CAT-05 `cat:vencimiento-provisorios` | Diario | Notifica y propone baja/conversión de provisorios vencidos. | — |
| JOB-CAT-06 `cat:vencimiento-no-facturar` | Diario | Quita la marca "No facturar" vencida y avisa. | — |
| JOB-CAT-07 `cat:mayoria-edad-adherentes` | Diario (V2 3186) | Lista adherentes que cumplen 21 años; envía correo/notificación. | — |
| JOB-CAT-08 `cat:fin-suspension-voluntaria` | Diario | Solicita reactivación al vencer la suspensión voluntaria. | — |
| JOB-CAT-09 `cat:devoluciones-vencidas` | Diario | Marca equipos con devolución vencida y crea tareas de retiro (TEC). | — |
| JOB-CAT-10 `cat:fin-promociones` | Al cierre de ciclo (evento de FAC) | Marca promociones finalizadas y notifica al socio (RF-CAT-052). | — |
| JOB-CAT-11 `cat:carencias` | Diario | Activa coberturas al cumplirse la carencia y notifica. | — |
| JOB-CAT-12 `cat:fin-cuotas-obra` | Evento de FAC (última cuota) | Cierra contratos OBR completados. | — |

## 10. Pantallas

Todas siguen el patrón CNX: AdminShell, `AdminStickyHeader`, `ScreenHelp` (qué/quién/cuándo/dónde/por qué/cómo + caso de uso), `DataTable` con columnas configurables, filtros, exportación XLSX/CSV/PDF, vistas guardadas; modales `sm/md/lg/xl`; `ConfirmDialog` en toda transición; etiquetas por `dict:`; importes en IBM Plex Mono. Ubicación en `siteMapGroups`: cluster "Comercial" → grupo "Catálogo de servicios" y grupo "Contratos"; cluster "Plataforma" → "Capacidades".

| PAN-ID | App | Ruta | Capability | Propósito, layout y contenido | Equivalencia ProCoop (INV) |
|---|---|---|---|---|---|
| PAN-CAT-01 | plataforma | `/platform/cat/capabilities` | `cat.capacidades.ver` | Catálogo global de capacidades. DataTable: código, dominio, estado, madurez, perfiles, tipos de cálculo, tenants que la usan. Acciones: crear, editar ficha de dominio y esquema de atributos (modal xl con editor JSON Schema validado), deprecar. Estado vacío: "Todavía no hay capacidades; cargue la semilla de plataforma". | — (nuevo) |
| PAN-CAT-02 | plataforma | `/platform/cat/enablement` | `cat.habilitacion.ver` | Matriz tenants × capacidades (CU-CAT-01) con estado, fechas, licencia. Acciones: habilitar/deshabilitar (modal md con fecha y motivo; muestra dependencia de licencia). | CNX §4.3 `/suscriptores` (packs) |
| PAN-CAT-03 | admin | `/admin/cat/services` | `cat.servicios.ver` | Servicios del tenant. Columnas: código, nombre, dominio, oferta (abierta/cerrada), operación, versión vigente, versión borrador, contratos activos, principal. Acciones: nuevo (desde cero/plantilla/copia), abrir, publicar, cerrar oferta, retirar (modal lg con alcance y plan de salida). | `abm_Servicio` (listado) |
| PAN-CAT-04 | admin | `/admin/cat/services/:id` | `cat.servicios.configurar` | Ficha de configuración del servicio en pestañas: General (código, nombre, tipo, principal), Prestador y jurisdicción, Titularidad, Unidad y cantidad, Registración y cálculo, Requisitos de alta (cada uno No exigir/Advertir/Exigir), Operación (técnico, OT por evento), Estados por defecto, Miembros (adherentes/beneficiarios), Cambios y salida, Transferencias, Unicidad y controles, Facturación (grupo por defecto, sin consumo, servicio relacionado, división), Documentos y plantillas, Canales, Atención, Mapeos contables, Integraciones, Control. Banner de "versión borrador en edición". Ayuda contextual con caso de uso CU-05. | `abm_Servicio` (ConfigurarForm, Guardar, Propiedades, Categorías, TarAdhe), `abm_Servicio_OT` |
| PAN-CAT-05 | admin | `/admin/cat/services/:id/versions` | `cat.versiones.crear` / `cat.versiones.aprobar` | Versiones: lista con estado y fecha efectiva; detalle con diff lado a lado, validaciones (bloqueantes/advertencias), botón "Simular primera factura" (resultado de TAR/FAC en modo simulación), enviar a revisión, aprobar/rechazar (modal con comentario), programar publicación. | — (nuevo; ProCoop usa `HIS_*` por cuadro) |
| PAN-CAT-06 | admin | `/admin/cat/products` | `cat.productos.ver` | Productos/subservicios y conceptos facturables por servicio (dos pestañas). Columnas concepto: código, nombre, tipo, disparador, unidad, clase fiscal, rubro, interno sí/no, estado. Modal lg de concepto. Importación por `ExcelImportWizard`. | `abm_prod_ser`, `abm_prod_ser_combos` |
| PAN-CAT-07 | admin | `/admin/cat/plans` | `cat.planes.ver` | Planes y versiones: código, producto, estado, versión vigente, contratos por versión. Editor de versión (xl): atributos, periodicidad, categorías admitidas, componentes, promociones (duración y unidad), financiación, equipos, requisitos, vínculo tarifario. Acciones: publicar, discontinuar, preview "celular" de la tarjeta del plan en la PWA. | — (nuevo) |
| PAN-CAT-08 | admin | `/admin/cat/categories` | `cat.categorias.ver` | Categorías y grupos por servicio: código, nombre, grupo, social, prepaga, generador, códigos regulatorios, perfil de red, adherentes. Acciones: crear, clonar categoría, editar, ver contratos. Los precios se editan en TAR (enlace). | `abm_Servicio_Categorias` (parte estructural), `abm_GrpCat` |
| PAN-CAT-09 | admin | `/admin/cat/classes-properties` | `cat.clases.ver` | Clases de servicio (valores 1 y 2) y propiedades del servicio y personalizadas (tipo, lista de valores). | `abm_ClaseSer`, `abm_Servicio_Propiedad`, `abm_propieItems`, `abm_propieitems_valores` |
| PAN-CAT-10 | admin | `/admin/cat/statuses` | `cat.estados.configurar` | Estados operativos por servicio: código, nombre, canónico, implica desconexión, principal, visible al socio. Diagrama de la máquina canónica (solo lectura) con los operativos mapeados. | `abm_EstaSer` |
| PAN-CAT-11 | admin | `/admin/cat/auto-rules` | `cat.reglasAuto.configurar` | Reglas de altas automáticas: evento, servicio origen/destino, categoría destino, filtros, modo propose/create, fundamento, grupo de facturación. Simulador "qué contratos se habrían creado el último mes". | `abm_AltasEau` |
| PAN-CAT-12 | admin | `/admin/cat/event-charges` | `cat.conceptos.editar` | Conceptos por evento y bonificaciones de conexión: tipo de evento, concepto, filtros, una vez, requiere política MOR; pestaña de bonificaciones por cuenta. Acción masiva "modificar precio" redirige a TAR. | `abm_Conexion` |
| PAN-CAT-13 | admin | `/admin/cat/contracts` | `cat.contratos.ver` | Contratos: número, titular (nombre y DNI/CUIT enmascarado según permiso), cuenta, servicio, plan, categoría, estado canónico y operativo, fecha del último estado, matrícula, domicilio del servicio, flags. Filtros: servicio, estado, plan, categoría, zona/ruta, sucursal, flags, fechas. Por defecto solo activos (V2 2321); búsqueda por matrícula aproximada (V2 3108). Selección masiva → PAN-CAT-17. | `frmTitulares` (grilla de servicios), `abm_Socios` |
| PAN-CAT-14 | admin | `/admin/cat/contracts/:id` | `cat.contratos.ver` | Ficha del contrato por bloques (RF-CAT-068): Cabecera, Ubicación (mapa), Servicio, Estado (línea de tiempo de transiciones), Condiciones contratadas (tramos y promociones con fin), Flags, Equipos (PAN-CAT-19), Miembros (PAN-CAT-20), Dominio (atributos según ficha: Internet perfil técnico sin secretos; Telefonía líneas; Gas DDJJ — PAN-CAT-25; ELE GD/GU), Medidor y lecturas (desde MED), Deuda y facturas (desde COB/FAC, solo lectura), Casos CRM y OT vinculados, Documentos, Historia. Acciones según estado y capability (PAN-CAT-16). | `abm_Socios` (NuevoServicio, ModificarServicio, CambiarMedidor, CambioDomicilio, DesconectarServicio, ImprimirContrato, ImprimirFianzaServicio, ImprimirFichaAdherentes, ImprimirDetalleLlamadas), REL capturas 14 y 15 |
| PAN-CAT-15 | admin | `/admin/cat/contracts/new` | `cat.contratos.crear` | Asistente de alta (modal xl, pasos): 1 titular y cuenta (búsqueda PER), 2 servicio y plan (solo ofertas abiertas), 3 domicilio del servicio (calle normalizada, mapa, catastro), 4 requisitos del perfil (errores y advertencias juntos), 5 condiciones y aceptación, 6 resumen (incluye advertencia de deuda en domicilio y conceptos por evento). Al confirmar: contrato `requested` y caso CRM vinculado. | `frmTitulares.btnAltaBajaServicio`, `abm_Socios.NuevoServicio` |
| PAN-CAT-16 | admin | modales en PAN-CAT-14 | según acción | Transiciones: Aprobar, Activar (no técnico), Suspender (motivo, modo, fechas), Reactivar, Solicitar baja (fecha, motivo, consulta de baja administrativa si OT), Baja efectiva, Anular, Desistir baja, Cambiar plan (comparador y efecto en período), Cambiar categoría (modo), Cambiar clase/actividad/referencia, Trasladar domicilio, Transferir (asistente con deuda informativa y modo de adherentes), Marcar No facturar/Provisorio (motivo y vigencia). Cada modal muestra precondiciones incumplidas. | `frmTitulares` (btnModificacionCategoria, btnFacturarNoFac, btnBaja, btnFallecimiento), `frmTranferenciaCapital.Transferir_Servicios`, `frmTransferenciasCuenta` |
| PAN-CAT-17 | admin | `/admin/cat/bulk-operations` | `cat.masivos.ejecutar` | Trámites masivos: elegir operación, criterio o lista (importación Excel), simular, aprobar, seguir progreso, ver resultado por contrato, revertir. | `frmPTramites`, `clsTramites` (RN-06 §4.3), `frmRecategorizacion` (parte de contrato), `frmSegmentacion_Restablecer` |
| PAN-CAT-18 | admin / plataforma | `/admin/cat/copies` | `cat.copias.ejecutar` | Asistente de copia: origen (tenant/servicio/versión autorizados), destino, componentes, dependencias con mapeo, exclusiones fijas (lista visible), confirmar; seguimiento y resultado con pendientes. | — (nuevo) |
| PAN-CAT-19 | admin | `/admin/cat/equipment-loans` | `cat.comodatos.ver` | Equipos en comodato: por contrato y bandeja global de devoluciones pendientes/vencidas (serie, producto, titular, contrato, fecha de entrega, devolución prevista, estado). Acciones: asignar (con stock disponible del depósito), registrar devolución, marcar perdido, reemplazar; constancias. | `abm_Sersoc_Productos` |
| PAN-CAT-20 | admin | `/admin/cat/contracts/:id/members` | `cat.adherentes.ver` | Adherentes y beneficiarios: persona, vínculo, titular, alta/baja, cobertura desde, tarifa de adherente, credencial. Acciones: agregar (con control de repetidos), dar de baja, imprimir ficha/credencial; bandeja de fuera de rango y mayoría de edad. Alcance sensible para SAN/SAL. | `frmTitulares.btnBajaAdherentes`, `abm_Socios.ImprimirFichaAdherentes`, `abm_Vinculos` (catálogo en PER) |
| PAN-CAT-21 | pwa-socio | `/servicios/disponibles` | `cat.oferta.ver` | Oferta del tenant: cards por servicio con planes publicados (anatomía CNX), detalle del plan (características, requisitos, conceptos, promociones vigentes con fin), FAB "+" "Solicitar" abre modal de solicitud CRM. 3 skeleton cards; estado vacío "Tu cooperativa todavía no publicó servicios". | CoopOnline (alta desde portal) |
| PAN-CAT-22 | pwa-socio | `/servicios/mios` | `cat.misServicios.ver` | Mis servicios: cards de contratos propios o representados con estado legible ("Activo", "Rehabilitación en trámite", "Baja solicitada"), plan, promociones y fecha de fin, equipos en comodato, últimas facturas (enlace COB). Acciones según canales del servicio: solicitar baja, suspensión, reactivación, cambio de plan (todas vía CRM). | CoopOnline |
| PAN-CAT-23 | landing | `/:tenantSlug/servicios` | público | Catálogo público de servicios y planes publicados, requisitos, cobertura (consulta por domicilio cuando TEC lo provea), botón "Quiero contratar" (registro simple) y acceso al botón de baja público (CRM). | Sitio web/CMS |
| PAN-CAT-24 | admin | `/admin/cat/dashboard` | `cat.servicios.ver` | Tablero: indicadores de sección 15 con filtros por servicio y período. | — |
| PAN-CAT-25 | admin | pestaña en PAN-CAT-14 (GAS) | `cat.contratos.editar` | Declaración jurada de artefactos: grilla de artefactos con historia, plantilla de trámite DDJJ, carga desde portal si el tenant lo habilita (V2 44). | `abm_Artefactos` |
| PAN-CAT-26 | admin | `/admin/cat/concessions` | `cat.servicios.configurar` | Concesiones y fuentes normativas por servicio con vigencia y verificación. | `CONCESIO` (ABM genérico) |
| PAN-CAT-27 | admin | `/admin/cat/bundles` | `cat.paquetes.ver` | Paquetes de prestaciones: planes incluidos, reglas de baja parcial, vigencia. | — (nuevo) |

## 11. API

| API-ID | Método | Ruta | Capability | Descripción | Idempotente |
|---|---|---|---|---|---|
| API-CAT-01 | GET | `/api/platform/cat/capabilities` | `cat.capacidades.ver` | Listar capacidades. | — |
| API-CAT-02 | POST | `/api/platform/cat/capabilities` | `cat.capacidades.crear` | Crear capacidad. | Sí (`Idempotency-Key`) |
| API-CAT-03 | PATCH | `/api/platform/cat/capabilities/:id` | `cat.capacidades.editar` | Editar ficha/esquema (nueva versión de esquema). | Sí |
| API-CAT-04 | GET | `/api/platform/cat/enablement` | `cat.habilitacion.ver` | Matriz tenants × capacidades. | — |
| API-CAT-05 | POST | `/api/platform/cat/tenants/:tenantId/capabilities/:capabilityId/enable` | `cat.habilitacion.configurar` | Habilitar (valida licencia). | Sí |
| API-CAT-06 | POST | `/api/platform/cat/tenants/:tenantId/capabilities/:capabilityId/disable` | `cat.habilitacion.configurar` | Deshabilitar (valida RN-CAT-003). | Sí |
| API-CAT-07 | GET | `/api/admin/cat/services` | `cat.servicios.ver` | Servicios del tenant. | — |
| API-CAT-08 | GET | `/api/admin/cat/services/:id` | `cat.servicios.ver` | Detalle con perfil vigente y borrador. | — |
| API-CAT-09 | POST | `/api/admin/cat/services` | `cat.servicios.configurar` | Crear servicio (desde cero o plantilla). | Sí |
| API-CAT-10 | POST | `/api/admin/cat/services/:id/versions` | `cat.versiones.crear` | Crear versión borrador. | Sí |
| API-CAT-11 | PATCH | `/api/admin/cat/services/:id/versions/:versionId` | `cat.versiones.crear` | Editar borrador (perfil y componentes). | Sí (`If-Match` versión) |
| API-CAT-12 | POST | `/api/admin/cat/services/:id/versions/:versionId/validate` | `cat.versiones.crear` | Ejecutar validaciones. | Sí |
| API-CAT-13 | POST | `/api/admin/cat/services/:id/versions/:versionId/simulate` | `cat.versiones.crear` | Simular primera factura (TAR/FAC). | Sí |
| API-CAT-14 | POST | `/api/admin/cat/services/:id/versions/:versionId/submit` | `cat.versiones.crear` | Enviar a revisión. | Sí |
| API-CAT-15 | POST | `/api/admin/cat/services/:id/versions/:versionId/approve` | `cat.versiones.aprobar` | Aprobar/rechazar. | Sí |
| API-CAT-16 | POST | `/api/admin/cat/services/:id/versions/:versionId/publish` | `cat.servicios.publicar` | Publicar o programar. | Sí |
| API-CAT-17 | POST | `/api/admin/cat/services/:id/offer` | `cat.servicios.publicar` / `cat.servicios.retirar` | Abrir/cerrar oferta, retirar con alcance. | Sí |
| API-CAT-18 | GET/POST/PATCH | `/api/admin/cat/products` | `cat.productos.*` | Productos y subservicios. | POST/PATCH sí |
| API-CAT-19 | GET/POST/PATCH | `/api/admin/cat/concepts` | `cat.conceptos.*` | Conceptos facturables. | POST/PATCH sí |
| API-CAT-20 | GET/POST/PATCH | `/api/admin/cat/plans` | `cat.planes.*` | Planes. | Sí |
| API-CAT-21 | POST | `/api/admin/cat/plans/:id/versions` | `cat.planes.editar` | Nueva versión de plan. | Sí |
| API-CAT-22 | POST | `/api/admin/cat/plans/:id/discontinue` | `cat.planes.discontinuar` | Discontinuar plan. | Sí |
| API-CAT-23 | GET/POST/PATCH | `/api/admin/cat/bundles` | `cat.paquetes.*` | Paquetes. | Sí |
| API-CAT-24 | GET/POST/PATCH | `/api/admin/cat/categories` | `cat.categorias.*` | Categorías y grupos. | Sí |
| API-CAT-25 | GET/POST/PATCH | `/api/admin/cat/classes` | `cat.clases.*` | Clases de servicio. | Sí |
| API-CAT-26 | GET/POST/PATCH | `/api/admin/cat/properties` | `cat.propiedades.*` | Propiedades. | Sí |
| API-CAT-27 | GET/POST/PATCH | `/api/admin/cat/statuses` | `cat.estados.configurar` | Estados operativos. | Sí |
| API-CAT-28 | GET/POST/PATCH | `/api/admin/cat/event-charges` | `cat.conceptos.editar` | Conceptos por evento y bonificaciones. | Sí |
| API-CAT-29 | GET/POST/PATCH | `/api/admin/cat/auto-rules` | `cat.reglasAuto.configurar` | Reglas automáticas. | Sí |
| API-CAT-30 | POST | `/api/admin/cat/auto-rules/:id/simulate` | `cat.reglasAuto.configurar` | Simular regla. | Sí |
| API-CAT-31 | GET | `/api/admin/cat/contracts` | `cat.contratos.ver` | Buscar contratos (paginado). | — |
| API-CAT-32 | GET | `/api/admin/cat/contracts/:id` | `cat.contratos.ver` | Ficha; `?asOf=&dateKind=effective|recorded`. | — |
| API-CAT-33 | POST | `/api/admin/cat/contracts` | `cat.contratos.crear` | Crear contrato (`requested`); devuelve todos los errores/advertencias. | Sí |
| API-CAT-34 | PATCH | `/api/admin/cat/contracts/:id` | `cat.contratos.editar` | Editar atributos no de estado (observaciones, referencias, atributos de dominio). | Sí (`If-Match`) |
| API-CAT-35 | POST | `/api/admin/cat/contracts/:id/commands/:command` | según comando (`cat.contratos.activar`, `.suspender`, `.reactivar`, `.solicitarBaja`, `.baja`, `.anular`, `.cambiarPlan`, `.cambiarCategoria`, `.transferir`, `.trasladar`, `.marcar`) | Ejecutar transición/cambio (`approve`, `requestFeasibility`, `activate`, `suspend`, `requestReactivation`, `reactivate`, `requestTermination`, `withdrawTermination`, `terminate`, `reopenTermination`, `cancel`, `changePlan`, `changeCategory`, `changeClass`, `changeActivity`, `changeReference`, `relocate`, `transfer`, `setFlag`). | Sí (`commandId`) |
| API-CAT-36 | GET | `/api/admin/cat/contracts/:id/history` | `cat.contratos.ver` | Historia. | — |
| API-CAT-37 | GET/POST | `/api/admin/cat/contracts/:id/equipment` | `cat.comodatos.ver` / `cat.comodatos.asignar` | Equipos del contrato; asignar. | POST sí |
| API-CAT-38 | POST | `/api/admin/cat/equipment-assignments/:id/return` | `cat.comodatos.devolver` | Registrar devolución/pérdida/reemplazo. | Sí |
| API-CAT-39 | GET | `/api/admin/cat/equipment-assignments?status=returnPending` | `cat.comodatos.ver` | Bandeja de devoluciones. | — |
| API-CAT-40 | GET/POST/PATCH | `/api/admin/cat/contracts/:id/members` | `cat.adherentes.*` | Adherentes y beneficiarios. | Sí |
| API-CAT-41 | GET/POST/PATCH | `/api/admin/cat/contracts/:id/appliances` | `cat.contratos.editar` | DDJJ de artefactos. | Sí |
| API-CAT-42 | GET/POST/PATCH | `/api/admin/cat/contracts/:id/generation-agreement` | `cat.contratos.editar` | Vínculo de generación distribuida. | Sí |
| API-CAT-43 | GET/POST | `/api/admin/cat/contracts/:id/special-conditions` | `cat.contratos.editar` + `cat.versiones.aprobar` | Condiciones de grandes usuarios. | Sí |
| API-CAT-44 | POST | `/api/admin/cat/bulk-operations` | `cat.masivos.ejecutar` | Crear trámite masivo. | Sí |
| API-CAT-45 | POST | `/api/admin/cat/bulk-operations/:id/{simulate|approve|run|revert}` | `cat.masivos.ejecutar` | Ciclo del trámite. | Sí |
| API-CAT-46 | POST | `/api/admin/cat/copies` | `cat.copias.ejecutar` | Solicitar copia entre tenants. | Sí |
| API-CAT-47 | POST | `/api/admin/cat/copies/:id/authorize-source` | `cat.copias.autorizarOrigen` | Autorización del tenant origen. | Sí |
| API-CAT-48 | GET | `/api/admin/cat/copies/:id` | `cat.copias.ejecutar` | Estado y pendientes. | — |
| API-CAT-49 | GET | `/api/cat/offers` | `cat.oferta.ver` | Oferta para la PWA. | — |
| API-CAT-50 | GET | `/api/cat/my-contracts` | `cat.misServicios.ver` | Contratos propios/representados. | — |
| API-CAT-51 | GET | `/api/public/:tenantSlug/cat/offers` | público (rate limit) | Oferta pública de la landing. | — |
| API-CAT-52 | GET | `/api/admin/cat/dashboard` | `cat.servicios.ver` | Indicadores. | — |
| API-CAT-53 | GET | `/api/admin/cat/concessions` y POST/PATCH | `cat.servicios.configurar` | Concesiones y fuentes normativas. | Sí |
| API-CAT-54 | GET | `/api/v1/ext/cat/contracts` | token de tercero con alcance `cat.read` | Contratos para APIs de terceros/BI (sin datos sensibles ni secretos). | — |
| API-CAT-55 | GET/POST | `/api/platform/cat/templates` | `cat.plantillas.*` | Plantillas de servicio de plataforma (A validar PA-CAT-08). | Sí |

Errores: RFC 9457 con `requestId`; validaciones de alta devuelven `errors[]` y `warnings[]` con `code` estable (`CAT_REQ_FEASIBILITY`, `CAT_SUPPLYCODE_DUP`, `CAT_SOCIAL_DUP`, `CAT_ADDRESS_DEBT`, `CAT_HOLDER_INACTIVE`, `CAT_BILLING_GROUP`, `CAT_GUARANTOR`, `CAT_TRANSITION_NOT_ALLOWED`…). Validación Zod compartida en `packages/shared/cat`.

## 12. Eventos y jobs

Todos los eventos se publican por outbox en la misma transacción que el cambio (T11 WFL), con `eventId`, `tenantId`, `occurredAt`, `effectiveAt`, `correlationId`, `actor`, `schemaVersion` y sin datos personales más allá de identificadores.

### 12.1 Eventos emitidos

| Evento | Cuándo | Payload mínimo | Consumidores |
|---|---|---|---|
| `cat.tenantService.enabled` / `.disabled` | Habilitación de capacidad | `tenantServiceId`, `capabilityId` | PLA, UXD (menú), POR |
| `cat.tenantService.published` | Oferta abierta | `tenantServiceId`, `configVersionId`, `effectiveFrom` | POR, landing, CRM, TAR |
| `cat.tenantService.withdrawn` | Oferta cerrada / retiro | `tenantServiceId`, `scope` | POR, CRM |
| `cat.configVersion.published` | Versión vigente | `configVersionId`, `diffSummary` | TAR, FAC, MOR, TEC, CRM (caché de perfil) |
| `cat.plan.published` / `.discontinued` | Ciclo del plan | `planId`, `planVersionId` | POR, CRM, TAR |
| `cat.contract.requested` | T01 | `contractId`, `accountId`, `holderId`, `planVersionId`, `requestId` | CRM, TEC (si factibilidad) |
| `cat.contract.feasibilityRequested` | T02 | `contractId`, `serviceAddress` | TEC |
| `cat.contract.installationRequested` | T03/T05 técnico | `contractId`, `requirements`, `equipment` | TEC, STK |
| `cat.contract.activated` | T06 | `contractId`, `effectiveStart`, `planVersionId`, `categoryId`, `billingGroupId`, `eventCharges[]` | FAC, TAR, MED, COB, CRM, PER (estado de socio), INS, CAT (altas automáticas) |
| `cat.contract.suspended` | T08 | `contractId`, `reason`, `mode`, `effectiveAt` | FAC, TEC, MOR, CRM, POR |
| `cat.contract.reactivationRequested` | T09 | `contractId` | TEC |
| `cat.contract.reactivated` | T10/T11 | `contractId`, `effectiveAt`, `startDateRule` | FAC, MOR, CRM |
| `cat.contract.terminationRequested` | T12 | `contractId`, `requestedAt`, `reason` | TEC, CRM |
| `cat.contract.terminationWithdrawn` | Desiste baja | `contractId` | TEC, CRM |
| `cat.contract.terminated` | T14 | `contractId`, `effectiveEnd`, `pendingEquipment[]` | FAC (factura final), MED, COB, PER, INS, CRM, CAT (cascada/altas) |
| `cat.contract.cancelled` | T04/T13 | `contractId`, `reason` | CRM, TEC, STK |
| `cat.contract.transferred` | T15 | `fromContractId`, `toContractId`, `mode` | FAC, COB, PER, MED, integraciones |
| `cat.contract.planChanged` | Cambio de plan | `contractId`, `fromPlanVersionId`, `toPlanVersionId`, `validFrom` | TAR, FAC, TEC (reprovisión), POR |
| `cat.contract.categoryChanged` | Cambio de categoría | `contractId`, `from`, `to`, `validFrom`, `mode` | TAR, FAC, FIS, CAT (altas) |
| `cat.contract.addressChanged` | Traslado | `contractId`, `validFrom` | TEC, MED, FIS (jurisdicción), CAT (altas) |
| `cat.contract.flagChanged` | Marcas No facturar / Provisorio / etc. | `contractId`, `flag`, `value`, `validTo` | FAC, TAR, MED |
| `cat.contract.equipmentAssigned` / `.equipmentReturned` / `.equipmentLost` | Comodato | `assignmentId`, `contractId`, `stockUnitId` | STK, FAC (si cargo), CON (vía STK) |
| `cat.contract.memberAdded` / `.memberRemoved` | Adherentes/beneficiarios | `contractId`, `memberId`, `role` | TAR (cargo adherente), FAC, SOC |
| `cat.bulkOperation.completed` | Fin de trámite masivo | `operationId`, `counts` | Notificación al solicitante, TAR/MOR origen |
| `cat.serviceCopy.completed` | Fin de copia | `copyRunId`, `pendingItems` | Plataforma, tenant destino |

### 12.2 Eventos consumidos

| Evento | Productor | Efecto en CAT |
|---|---|---|
| `crm.request.admitted` | M09 CRM | Crea contrato `requested` (T01) o ejecuta comando (baja, suspensión, cambio) según tipo de solicitud. |
| `crm.request.cancelled` | M09 CRM | Anula contrato no activado (T13) o desiste baja (T12 reversión). |
| `tec.feasibility.resolved` | M10 TEC | T03 / T04. |
| `tec.visit.failed` | M10 TEC | T07 (registro). |
| `tec.installation.completed` / `tec.provisioning.confirmed` | M10 TEC | T06 / T10. |
| `tec.workOrder.closed` | M10 TEC | Según `purpose`: activación, reconexión, desconexión, cambio de domicilio, cambio de categoría diferido. |
| `tec.workOrder.created` | M10 TEC | Dispara reglas automáticas de evento OT. |
| `mor.suspension.ordered` / `mor.reconnection.ordered` / `mor.prepaidConversion.ordered` | M08 MOR | T08 / T09-T11 / trámite de cambio de plan o categoría a prepago. |
| `per.person.deceased` | M01 PER | Marca de fallecido; bloqueo de reconexión (RN-CAT-044); oculta miembros según PRM-CAT-063; tarea de revisión de titularidad. |
| `per.account.created` | M01 PER | Reglas automáticas de evento "alta de cuenta". |
| `per.holder.deactivated` | M01 PER | Advertencia en contratos activos del titular. |
| `stk.unit.returned` / `stk.unit.replaced` | M13 STK | Cierra/actualiza asignación de comodato. |
| `fac.cycle.closed` | M05 FAC | JOB-CAT-10 fin de promociones; JOB-CAT-12 cuotas de obra. |
| `pla.capability.revoked` / `pla.license.expired` | T01 PLA | Cierra oferta; abre plan de salida; no altera contratos sin decisión. |

## 13. Integraciones

| Integración | Dirección | Descripción | Regla |
|---|---|---|---|
| Aprovisionamiento de Internet (MikroTik / OLT / RADIUS) | Salida vía TEC | El plan define el perfil técnico (velocidad, VLAN, pool); TEC aprovisiona y confirma. | Credenciales en bóveda (T06); CAT solo referencia `secretRef`; nunca guarda contraseñas en claro (CTR-CAT-10). |
| Telemedición (prepago energía/agua, integradores tipo Discar) | Salida vía MED/TEC | Alta/baja/corte del medidor inteligente ligado al contrato. | Si falla, la OT no cierra y el contrato no cambia (RN-CAT-041). |
| Centrales de terceros de servicios fúnebres / salud (ex BATCOM) | Bidireccional, configurable | Envío de padrón de contratos y beneficiarios. | Servicio configurable por mapeo; no se fija un código de servicio en código (CTR-CAT-14). |
| Sistemas de gestión de expedientes / municipales (ex SITSA) | Entrada/salida | Tasas por cuenta de terceros y obras. | Mapeo de conceptos por convenio (FIS/TAR). |
| Sincronización de transferencias (ex AION) | Salida | Notificar transferencias de servicio a sistemas externos. | Por evento `cat.contract.transferred`; reintentos T06. |
| Padrones de tarifa social (nacionales/provinciales) | Entrada vía TAR | Importación de beneficiarios (por cuenta o DNI). | CAT marca categoría social; TAR aplica subsidio; trazabilidad de la fuente. |
| Reguladores / ENRE-ERSeP / ENACOM | Salida (reportes) | Códigos regulatorios de categoría y servicio. | CAT provee mapeo; reportes en el módulo regulatorio correspondiente. |
| APIs a terceros / BI | Salida | API-CAT-54 de solo lectura con alcance. | Sin datos sensibles, enmascarado de documentos, auditoría de consultas. |

Todas las integraciones usan el marco T06 (conector, credencial en bóveda, idempotencia, reintentos con backoff, DLQ, panel de salud).

## 14. Parámetros

Ámbitos: `plataforma`, `tenant`, `servicio` (dentro de la versión de configuración), `plan`. Todos los parámetros de ámbito `servicio` se versionan con la configuración (RN-CAT-007).

| PRM-ID | Clave | Tipo | Ámbito | Default | Descripción | Origen V2 |
|---|---|---|---|---|---|---|
| PRM-CAT-001 | `cat.service.exitPlanRequired` | bool | tenant | true | Exige plan de salida aprobado para cerrar operación con contratos vigentes. | — |
| PRM-CAT-002 | `cat.publish.dualApproval` | enum `always/productionOnly/never` | tenant | productionOnly | Aprobación por usuario distinto para publicar. | — |
| PRM-CAT-003 | `cat.publish.requireSimulation` | bool | tenant | true | Exige simulación de primera factura antes de publicar. | — |
| PRM-CAT-010 | `cat.req.activity` / `cat.req.class` / `cat.req.zsr` | enum `none/warn/require` | servicio | warn | Exigencia de actividad, clase y zona/sector/ruta en el alta. | RN-06 §3.2 |
| PRM-CAT-011 | `cat.req.uniqueParcel` | enum `none/warn/require` | servicio | require (medidos) | Unicidad de parcela/nomenclatura catastral por servicio. | 319 |
| PRM-CAT-012 | `cat.req.device` | enum `none/warn/require` | servicio | require (medidos) | Dispositivo (medidor) obligatorio para activar. | RN-06 §3.2 |
| PRM-CAT-013 | `cat.req.feasibility` | bool | servicio | true (INT, ELE, AG, GAS) | Exige factibilidad aprobada. | 2050 |
| PRM-CAT-014 | `cat.req.guarantor` | bool | servicio | false | Exige garante. | RN-06 §3.2 |
| PRM-CAT-015 | `cat.req.installerCertificate` | enum `none/warn/require` | servicio | none (require GAS) | Exige número de certificado de instalador. | 2343 |
| PRM-CAT-016 | `cat.req.installerProfessionalAndDate` | bool | servicio | true | Si hay número de certificado, exige profesional y fecha. | 2529 |
| PRM-CAT-017 | `cat.req.addressDebtCheck` | enum `none/warn/supervisor` | servicio | warn | Control de deuda en el domicilio del servicio (PA-CAT-12). | 2482, 2668 |
| PRM-CAT-018 | `cat.req.addressDebtScope` | enum `sameService/allServices` | servicio | sameService | Universo de deuda consultada. | 2669 |
| PRM-CAT-019 | `cat.req.activeHolder` | bool | tenant | true | Impide alta a titular no activo/dado de baja. | 734, 741 |
| PRM-CAT-020 | `cat.supplyCode.allowDuplicate` | bool | servicio | false | Permite matrícula duplicada (si no es automática). | 2250 |
| PRM-CAT-021 | `cat.contract.allowSameServiceInAccount.metered` | bool | servicio | false | Dos contratos iguales en la misma cuenta (medidos). | 2269 |
| PRM-CAT-022 | `cat.contract.allowSameServiceInAccount.unmetered` | bool | servicio | true | Ídem no medidos (PA-CAT-11). | 2715 |
| PRM-CAT-023 | `cat.contract.supplyCodeAuto` | bool | servicio | true | Matrícula/número de suministro autogenerado por secuencia del servicio. | 213 |
| PRM-CAT-024 | `cat.contract.copyAddressFromAccount` | bool | servicio | true | Propone el domicilio de la cuenta como domicilio del servicio. | 343 |
| PRM-CAT-025 | `cat.contract.billingGroupDefault` | ref | servicio | — | Grupo de facturación por defecto del servicio. | 573, 2329 |
| PRM-CAT-026 | `cat.contract.defaultList.activeOnly` | bool | tenant | true | Listado de contratos muestra solo activos por defecto. | 2321 |
| PRM-CAT-027 | `cat.contract.search.fuzzySupplyCode` | bool | tenant | true | Búsqueda aproximada por matrícula. | 3108 |
| PRM-CAT-030 | `cat.category.socialPriority` | lista ordenada | servicio | `retiree, mainAccount, oldest` | Prioridad cuando hay varias categorías sociales candidatas; además impide dos sociales por persona. | 2740, 2435 |
| PRM-CAT-031 | `cat.recat.excludeTerminatedOlderThanDays` | int | servicio | 60 | Recategorización excluye bajas con antigüedad mayor. | 2825 |
| PRM-CAT-032 | `cat.recat.includeDisconnected` | bool | servicio | false | Recategorización incluye desconectados. | 3155 |
| PRM-CAT-033 | `cat.category.requireRegulatoryCode` | bool | servicio | false (true ELE) | Exige código regulatorio en categorías. | 2461, 2462 |
| PRM-CAT-040 | `cat.billing.billableStates` | lista | servicio | `active, pendingTermination` | Estados canónicos que devengan cargos fijos (suspensión configurable). | RN-06 §4.1 |
| PRM-CAT-041 | `cat.ot.blockCloseOnTelemetryError` | bool | servicio | true | La OT no cierra si falla la telemedición. | 2532 |
| PRM-CAT-042 | `cat.reconnect.keepPreviousStart` | bool | servicio | true (no medidos) | En reconexión restaura la fecha de alta anterior. | 2707 |
| PRM-CAT-043 | `cat.reconnect.allowDeceasedHolder` | bool | tenant | false | Permite reconectar a titular fallecido. | 2301 |
| PRM-CAT-044 | `cat.category.changeMode` | enum `immediate/scheduled/onWorkOrderClose` | servicio | immediate | Momento de aplicación del cambio de categoría. | 2330, 2455 |
| PRM-CAT-045 | `cat.category.changeRequiresWorkOrder` | bool | servicio | false | Cambio de categoría genera OT. | 2455 |
| PRM-CAT-046 | `cat.category.prorateCutoffDay` | int (1-31) | servicio | 15 | Día límite para cobro proporcional. | 2755 |
| PRM-CAT-047 | `cat.termination.reopenWindowDays` | int | servicio | 0 | Días para reabrir una baja sin factura final emitida. | — |
| PRM-CAT-048 | `cat.termination.askAdministrativeOnWorkOrder` | bool | servicio | true | Consultar si generar baja administrativa al crear OT de baja. | 2545 |
| PRM-CAT-049 | `cat.activation.cancelWorkOrderToCancelled` | bool | servicio | true | Eliminar OT de alta pasa el contrato a Anulado. | 2753 |
| PRM-CAT-050 | `cat.autoRules.defaultMode` | enum `propose/create` | tenant | propose | Modo por defecto de reglas automáticas (PA-CAT-04). | 2550, 2571 |
| PRM-CAT-051 | `cat.transfer.keepOriginalStartDate` | bool | servicio | false | Mantiene fecha de alta original en transferencia. | 2541, 422 |
| PRM-CAT-052 | `cat.transfer.membersMode` | enum `all/activeOnly/none` | servicio | activeOnly | Copia de adherentes al transferir. | 2291 |
| PRM-CAT-053 | `cat.transfer.allowTerminated` | bool | servicio | false | Transferencia de contratos dados de baja. | 2599 |
| PRM-CAT-054 | `cat.transfer.markDestinationMain` | bool | tenant | false | Marca la cuenta destino como principal. | 3195 |
| PRM-CAT-055 | `cat.relocation.requiresWorkOrder` | bool | servicio | true (técnicos) | Traslado de domicilio por OT. | RN-06 §8 |
| PRM-CAT-056 | `cat.transfer.chargeConcept` | ref concepto | servicio | — | Concepto por evento de transferencia. | 3194 |
| PRM-CAT-060 | `cat.members.cascadeOnDisconnect` | enum `cascade/ask/none` | servicio | ask | Efecto sobre miembros al dar de baja/desconectar. | 2401 |
| PRM-CAT-061 | `cat.members.adultAgeNotice` | int | servicio | 21 | Edad que dispara aviso de mayoría de edad. | 3186 |
| PRM-CAT-062 | `cat.members.adultAgeEmail` | bool | servicio | false | Aviso por correo además de bandeja. | 3187 |
| PRM-CAT-063 | `cat.members.hideDeceased` | bool | servicio | true | Oculta miembros fallecidos en la ficha. | 3058 |
| PRM-CAT-064 | `cat.members.allowDuplicateInService` | bool | servicio | false | Permite el mismo adherente en dos titulares. | 2400 |
| PRM-CAT-065 | `cat.members.askMoveFromOtherHolder` | bool | servicio | true | Consulta si dar de baja del otro titular. | 2521 |
| PRM-CAT-066 | `cat.members.maxPerContract` | int | plan | 0 (sin límite) | Máximo de adherentes por contrato. | 2522 |
| PRM-CAT-067 | `cat.members.waitingPeriodDays` | int | plan | 0 | Carencia para cobertura. | 2535 |
| PRM-CAT-070 | `cat.flags.noBill.maxDays` | int | servicio | 90 | Vigencia máxima de "No facturar" (obligatoria). | 2303 |
| PRM-CAT-071 | `cat.flags.provisional.maxDays` | int | servicio | 180 | Vigencia de "Provisorio" (PA-CAT-09). | 2710 |
| PRM-CAT-072 | `cat.termination.withPendingInstallments` | enum `allow/supervisor` | servicio | supervisor | Baja con cuotas pendientes de financiación/obra/vivienda. | 2316 |
| PRM-CAT-073 | `cat.flags.readingFactor.enabled` | bool | servicio | false | Habilita lectura con factor (MED aplica). | 2477 |
| PRM-CAT-074 | `cat.flags.portalOrigin.track` | bool | tenant | true | Registra "alta desde CoopOnline/PWA". | 2738 |
| PRM-CAT-080 | `cat.related.readingsFromService` | ref servicio | servicio | — | Servicio relacionado del que se toman lecturas (y si solo no facturadas). | 2701, 3143 |
| PRM-CAT-081 | `cat.billing.splitByService` | bool | servicio | false | Factura separada por servicio. | 2642, 3135 |
| PRM-CAT-082 | `cat.billing.noConsumptionCharge` | bool | servicio | false | Genera cargo fijo sin consumo. | 2465 |
| PRM-CAT-083 | `cat.billing.minimumOnSuspension` | bool | servicio | false | Factura mínimo durante suspensión. | 2797 |
| PRM-CAT-090 | `cat.tel.freeCallsZeroRate` | bool | servicio (TEL) | true | Llamadas gratuitas a costo cero. | 2514 |
| PRM-CAT-091 | `cat.tel.cppConcept` | ref concepto | servicio (TEL) | — | Concepto para llamadas CPP. | 19 |
| PRM-CAT-092 | `cat.tel.internationalConcept` | ref concepto | servicio (TEL) | — | Concepto para llamadas internacionales. | 24 |
| PRM-CAT-093 | `cat.int.equipmentDefaultModality` | enum `loan/sale/rent/own` | servicio (INT) | loan | Modalidad por defecto de equipos (PA-CAT-10). | 2581-2584 |
| PRM-CAT-094 | `cat.int.equipmentReturnDays` | int | servicio | 15 | Plazo de devolución tras la baja. | 2253 |
| PRM-CAT-095 | `cat.tv.decodersPerContract` | int | plan (TV) | 1 | Decodificadores incluidos. | 2708 |
| PRM-CAT-096 | `cat.gas.requireApplianceAffidavit` | bool | servicio (GAS) | true | DDJJ de artefactos obligatoria antes de habilitar. | 44, 75, 109 |
| PRM-CAT-097 | `cat.cem.plotRequired` | bool | servicio (CEM) | true | Parcela/nicho obligatorio. | 3152 |
| PRM-CAT-098 | `cat.voluntarySuspension.enabled` | bool | servicio | false | Admite suspensión voluntaria (PA-CAT-14). | — |
| PRM-CAT-099 | `cat.voluntarySuspension.maxDays` | int | servicio | 90 | Duración máxima. | — |
| PRM-CAT-100 | `cat.plan.changeEffective` | enum `immediate/nextCycle/date` | servicio | nextCycle | Fecha efectiva de cambio de plan (PA-CAT-15). | — |
| PRM-CAT-101 | `cat.plan.minStayMonths` | int | plan | 0 | Permanencia mínima (si la normativa lo permite; nunca bloquea la baja). | — |
| PRM-CAT-102 | `cat.sale.publicCancelButton` | bool | tenant | true | Muestra acceso al botón de baja en landing/PWA (CRM ejecuta). | — |
| PRM-CAT-103 | `cat.copy.requireSourceConsent` | bool | plataforma | true | Copia exige consentimiento del tenant origen (PA-CAT-07). | — |
| PRM-CAT-104 | `cat.bulk.batchSize` | int | plataforma | 1000 | Tamaño de lote de trámites masivos. | — |
| PRM-CAT-105 | `cat.bulk.revertWindowDays` | int | tenant | 7 | Ventana de reversión de trámites masivos. | — |
| PRM-CAT-106 | `cat.categories.maxSocialPerPerson` | int | servicio | 1 | Máximo de contratos con categoría social por persona. | 2435 |
| PRM-CAT-107 | `cat.activation.requireEquipmentAssigned` | bool | servicio | true (INT, TV) | Exige equipo obligatorio asignado para activar. | 2582 |
| PRM-CAT-108 | `cat.services.mainServiceForMembership` | ref servicio | tenant | — | Servicio cuyo contrato activo sostiene la condición de asociado (lo consume PER/SOC). | 206, 2742 |
| PRM-CAT-109 | `cat.contract.observationsMaxLength` | int | tenant | 2000 | Longitud de observaciones (texto libre sin datos sensibles). | 3108 |

Parámetros V2 delegados (no se definen aquí): 340, 337 (PER, titularidad y cuentas); 3112, 3113 (MOR, reconexión automática y cargos); 2464, 2540, 2750, 3148 (MED, lecturas y medidores); 2443, 2787 (FAC/TAR, facturación de conceptos); 2395, 2679 (VEN/STK, venta de productos); 3116, 3170, 3034, 2713, 2264 (INT/T06, integraciones); 2399 (TEC, OT); 413-419 y 2527 (SOC, servicios sociales y donantes, solo filtro administrativo CTR-CAT-20); 73, 2636 (INS, capital social). 2286 se descarta (dependía del borrado físico en transferencias).

## 15. Reportes e indicadores

Corte temporal según AGR-022: toda métrica se calcula "a fecha efectiva" (por defecto) o "a fecha de registro", y se indica en el encabezado.

| ID | Nombre | Fórmula | Universo | Dimensiones |
|---|---|---|---|---|
| REP-CAT-01 | Contratos por estado | `count(contracts)` agrupado por estado canónico y operativo al corte | Contratos del tenant no `cancelled` | Servicio, plan, categoría, zona, sucursal |
| REP-CAT-02 | Altas netas | `activaciones(período) − bajas efectivas(período)` | Eventos T06 y T14 en el período | Servicio, plan, canal |
| REP-CAT-03 | Tasa de baja (churn) | `bajas efectivas(período) / activos al inicio` | Contratos activos al inicio | Servicio, plan, motivo |
| REP-CAT-04 | Tiempo de solicitud a activación | Mediana y p90 de `effectiveStart − requestedAt` | Contratos activados en el período | Servicio, zona, etapa (factibilidad, instalación) |
| REP-CAT-05 | Embudo de alta | `requested → feasibility → pendingInstallation → active` con conversión y anulaciones por etapa | Contratos creados en el período | Servicio, canal |
| REP-CAT-06 | Suspendidos | `count(suspended)` por motivo y antigüedad | Contratos `suspended` al corte | Motivo, modo, servicio |
| REP-CAT-07 | Equipos en comodato | Entregados, pendientes de devolución, vencidos, perdidos | Asignaciones del tenant | Producto, zona, antigüedad |
| REP-CAT-08 | Contratos por plan y versión | `count(active)` por `planVersionId` | Activos al corte | Plan, versión (detecta versiones discontinuadas con contratos) |
| REP-CAT-09 | Promociones por finalizar | Contratos con promoción que termina en los próximos N ciclos | Activos con promoción | Plan, promoción |
| REP-CAT-10 | Adherentes y beneficiarios | Total, altas, bajas, fuera de rango de edad | Miembros vigentes | Servicio, vínculo |
| REP-CAT-11 | Marcas de excepción | Contratos con No facturar / Provisorio / lectura con factor, vencidos y por vencer | Contratos con marca vigente | Marca, servicio, usuario que marcó |
| REP-CAT-12 | Altas automáticas | Propuestas, aceptadas, rechazadas, creadas | Ejecuciones de reglas | Regla, servicio |
| REP-CAT-13 | Socios con varios servicios | Distribución de cantidad de servicios activos por titular | Titulares con contratos activos | Combinación de servicios |
| REP-CAT-14 | Auditoría de configuración | Versiones publicadas, cambios por usuario, aprobaciones | Versiones del período | Servicio, aprobador |
| REP-CAT-15 | Padrón regulatorio por categoría | `count(active)` por código regulatorio | Activos ELE/AG/GAS/TEL | Código regulatorio, jurisdicción |

Las exportaciones respetan enmascarado de documentos y alcances (T02); los reportes con datos de salud (SAN/SAL) requieren capability adicional.

## 16. Casos de uso

| CU | Nombre | Actor | Flujo resumido | Resultado |
|---|---|---|---|---|
| CU-05 (BASE) | Configurar y publicar un servicio | Administrador del tenant | 9.1 | Servicio publicado con versión vigente. |
| CU-CAT-01 (BASE) | Habilitar capacidades a un tenant | Operador de plataforma | PAN-CAT-02: elige tenant, capacidad, fecha; valida licencia; confirma | `tenantService` habilitado sin oferta. |
| CU-COP-01 (BASE) | Copiar un servicio de A a B | Operador + admin B | 9.6 | Borrador en B con pendientes; A intacto. |
| CU-PRO-01 (BASE) | Contratar Internet (piloto) | Ana (socia), comercial, técnico | 9.2 | Contrato activo, comodato registrado, facturación iniciada. |
| CU-SOL-01 (BASE, parte CAT) | Solicitud de alta por portal | Socio | PAN-CAT-21 → CRM → T01 | Contrato `requested` vinculado a la solicitud. |
| CU-CIC-01 (BASE, parte CAT) | Ciclo de vida del contrato | Varios | 9.3 | Transiciones auditadas. |
| CU-MER-01 (BASE, parte CAT) | Ofrecer servicio a un mercado nuevo (no socio) | Comercial | Alta con titular no asociado si el perfil lo admite (`holderRules.requiresMember=false`) | Contrato sin condición de socio. |
| CU-ESP-ELE (BASE) | Alta de suministro eléctrico con medidor y GD | Comercial, técnico | Factibilidad → OT de conexión → medidor (MED) → T06; vínculo GD opcional | Suministro activo con categoría regulatoria. |
| CU-ESP-AG (BASE) | Alta de agua con conexión | Comercial, técnico | Igual ELE, con parcela única | Conexión activa. |
| CU-ESP-GAS (BASE) | Alta de gas con DDJJ de artefactos | Comercial, gasista matriculado, técnico | Certificado de instalador → DDJJ → inspección → T06 | Servicio habilitado con artefactos registrados. |
| CU-ESP-CEM (BASE) | Contratar parcela de cementerio parque | Comercial | Alta con parcela/nicho (PRM-CAT-097), financiación, beneficiarios | Contrato con cuotas (FAC) y beneficiarios. |
| CU-ESP-SAN (BASE) | Adhesión a banco de sangre | Comercial | Alta administrativa con convenio (PA-CAT-06) | Contrato y beneficiarios; sin datos clínicos. |
| CU-CAT-02 | Dar de baja un contrato | Socio / comercial / técnico | Solicitud CRM (botón de baja) → T12 → OT → T14; equipos a devolución | Baja efectiva sin bloqueo por deuda. |
| CU-CAT-03 | Suspender y reactivar por mora | MOR, técnico | `mor.suspension.ordered` → T08; pago → T09 → T10 | Servicio restablecido con regla de fecha. |
| CU-CAT-04 | Cambiar de plan | Socio / comercial | 9.4 | Nuevo tramo de condiciones con fecha efectiva. |
| CU-CAT-05 | Recategorización masiva | Responsable comercial | 9.8 | Contratos recategorizados con historia, reversibles. |
| CU-CAT-06 | Transferir un servicio | Supervisor | 9.5 | Contrato nuevo en destino, original `superseded`. |
| CU-CAT-07 | Registrar y devolver equipo en comodato | Técnico / comercial | PAN-CAT-19 | Equipo trazable en STK y contrato. |
| CU-CAT-08 | Administrar adherentes | Comercial | PAN-CAT-20 | Miembros vigentes con controles. |
| CU-CAT-09 | Configurar alta automática | Administrador | PAN-CAT-11 con simulación | Regla vigente. |
| CU-CAT-10 | Marcar contrato como No facturar | Supervisor | PAN-CAT-16 con motivo y vigencia | Marca con vencimiento; bandeja. |
| CU-CAT-11 | Consultar mis servicios | Socio | PAN-CAT-22 | Visión de contratos, equipos y promociones. |
| CU-CAT-12 | Retirar un servicio de la oferta | Administrador | PAN-CAT-03 con alcance (PA-CAT-03) | Oferta cerrada; contratos vigentes intactos o plan de salida. |

## 17. Criterios de aceptación y escenarios

### 17.1 Escenarios obligatorios (ESC de la guía)

| ESC | Escenario | Dado / Cuando / Entonces |
|---|---|---|
| ESC-01 | Piloto Internet extremo a extremo | Dado TEN-001 con INT publicado y plan "Fibra 100", cuando Ana solicita por la PWA, TEC aprueba factibilidad, instala con ONT en comodato y confirma provisión, entonces el contrato pasa `requested → feasibility → pendingInstallation → active`, existe asignación `delivered`, se emite `cat.contract.activated` una sola vez y FAC inicia el devengamiento. |
| ESC-02 | Copia entre tenants | Dado INT v1 en TEN-001, cuando se copia a TEN-002 con consentimiento, entonces TEN-002 tiene borrador con `copiedFrom`, sin contratos, sin credenciales ni precios de A (pendientes de TAR), y cambiar A después no altera B. |
| ESC-03 | Hermanos en el mismo domicilio | Dados dos titulares (A y B) en DIR-CASA-001, cuando ambos contratan INT, entonces existen dos contratos independientes; la deuda de A no bloquea a B (solo advertencia si PRM-CAT-017=warn) ni se traslada. |
| ESC-04 | Baja sin trabas | Cuando un socio con deuda pide la baja por el botón público, entonces CRM la admite, CAT ejecuta T12 sin cargo ni bloqueo, y la deuda queda en COB. |
| ESC-05 | Reactivación gratuita vs. arancelada | Dado SUS-DEMO-GRATIS (sin cargo) y REACT-DEMO-ARANCEL (deshabilitado por política MOR), cuando se reactiva, entonces solo se genera concepto tipo 4 si la política MOR lo habilita. |

### 17.2 Criterios funcionales

1. Ninguna solicitud del socio activa por sí sola un contrato (T01 siempre crea `requested`); intentar `activate` sin precondiciones devuelve `CAT_TRANSITION_NOT_ALLOWED` con la lista de precondiciones incumplidas.
2. Toda transición genera una fila en `serviceContractHistory` con actor, motivo, `effectiveAt` y `recordedAt`; consulta `asOf` reconstruye el estado al día.
3. Publicar una versión con validaciones bloqueantes devuelve 422; con advertencias exige confirmación explícita y la registra.
4. Cambiar el precio de un plan no se hace en CAT: la pantalla de plan redirige a TAR y la versión del plan solo referencia `tariffBinding`.
5. Un contrato terminado no se reactiva (solo nueva alta o `reopenTermination` en ventana).
6. El alta valida todos los requisitos y devuelve todos los errores y advertencias en una única respuesta.
7. El estado operativo mostrado siempre corresponde a un canónico; no se puede configurar un operativo sin mapeo.
8. Marcas "No facturar" y "Provisorio" no se pueden guardar sin vigencia.
9. Los valores `1901-01-01` no existen: fechas no informadas son `null`.
10. La transferencia nunca borra el contrato origen.

### 17.3 Permisos negativos

| Caso | Resultado esperado |
|---|---|
| Comercial de mostrador intenta `suspend` | 403 `cat.contratos.suspender` requerido. |
| Admin de TEN-002 consulta contrato de TEN-001 por ID | 404 (no revela existencia). |
| Operador de plataforma abre ficha de contrato de un tenant | 403; plataforma solo ve configuración. |
| Socio consulta contrato de otro titular desde PWA | 404; solo propios o representados vigentes. |
| Usuario sin capability de salud abre beneficiarios de SAN | Datos sensibles ocultos; acceso auditado. |
| Mismo usuario crea y aprueba una versión en producción | Rechazado si PRM-CAT-002 lo exige. |
| Responsable comercial intenta editar clase fiscal de concepto | 403 `cat.conceptos.configurarFiscal`. |

### 17.4 Aislamiento de tenant

- Todas las colecciones tienen `tenantId` primero en índices; consultas sin `tenantId` fallan en el repositorio (T01 PLA).
- La copia entre tenants es la única operación que lee configuración de otro tenant y lo hace con autorización registrada; nunca copia contratos, personas, deuda, credenciales ni documentos.
- Eventos llevan `tenantId` y los consumidores rechazan eventos de otro tenant.

### 17.5 Reintentos e idempotencia

- Comandos con `commandId`/`Idempotency-Key`: repetir devuelve el mismo resultado sin duplicar transición ni evento.
- Recibir dos veces `tec.installation.completed` no duplica la activación ni los conceptos por evento (inbox con `eventId`).
- Trámites masivos reanudables; un contrato que falla no aborta el lote.
- Altas automáticas idempotentes por `(eventId, ruleId)`.

### 17.6 No funcionales

- Búsqueda de contratos p95 < 800 ms con 200 000 contratos por tenant.
- Ficha de contrato p95 < 1,5 s incluyendo bloques de otros módulos (carga diferida).
- Trámite masivo de 50 000 contratos < 30 min.
- Accesibilidad WCAG 2.1 AA en PWA y landing; textos por `dict:`.

## 18. Precarga de demostración (datos ficticios)

Todos los datos son inventados; ningún nombre, documento, domicilio ni importe proviene de bases reales. Importes en ARS solo para simulación (los precios reales los define TAR).

| Código | Tipo | Contenido |
|---|---|---|
| TEN-001 "Cooperativa Demo Norte" | Tenant | Capacidades INT, ELE, AG, TEL, TV, SEP, CEM, SAN habilitadas; INT publicado. |
| TEN-002 "Cooperativa Demo Sur" | Tenant | Capacidad INT habilitada, sin oferta (destino de copia). |
| INT | Servicio | Perfil técnico, factibilidad obligatoria, comodato por defecto, canal PWA y mostrador. |
| INT-100 "Fibra 100" | Plan | 100/50 Mbps; abono ficticio ARS 15.000; instalación ARS 20.000 con promoción 50 % por 3 meses; ONT en comodato. |
| INT-300 "Fibra 300" | Plan | 300/100 Mbps; abono ficticio ARS 22.000. |
| ELE-RES | Categoría | Residencial con código regulatorio ficticio R1. |
| ELE-RES-SOC | Categoría | Residencial social (`isSocial=true`). |
| AG-RES | Categoría | Agua residencial. |
| GAS-RES | Categoría | Gas natural residencial (capacidad habilitable para demo de DDJJ). |
| TEL-BAS | Plan | Línea básica con conceptos CPP e internacional. |
| TV-BAS | Plan | Grilla básica, 1 decodificador. |
| SOC-FAM | Plan | Sepelio familiar con adherentes, carencia 90 días. |
| CEM-PAR | Plan | Parcela cementerio parque en 24 cuotas ficticias. |
| SAN-CONV | Plan | Banco de sangre por convenio CONV-SAN-DEMO (solo administrativo). |
| Ana Demo (DNI ficticio 00000001) | Titular | Socia de TEN-001 para ESC-01. |
| Hermano A / Hermano B | Titulares | Contratos INT-H-A-001 e INT-H-B-001 en DIR-CASA-001 (ESC-03); A con deuda ficticia. |
| BAJA-DEMO | Contrato | INT activo con deuda ficticia para ESC-04. |
| SUS-DEMO-GRATIS | Contrato | INT suspendido por mora con reactivación sin cargo. |
| REACT-DEMO-GRATIS / REACT-DEMO-ARANCEL | Política | Reconexión gratuita (activa) / arancelada (deshabilitada) en MOR para ESC-05. |
| COP-DEMO-001 | Copia | Plantilla de corrida de copia TEN-001 → TEN-002. |
| PAR-DEMO-001 | Regla automática | Alta de SEP propuesta al activar ELE (modo `propose`). |
| ONT-DEMO-0001..0010 | Unidades de stock | ONT ficticias en el depósito demo (STK). |

La precarga se ejecuta con `pnpm seed:demo` por tenant y es idempotente por código.

## 19. Migración desde ProCoop

### 19.1 Mapeo de tablas

| Origen ProCoop | Destino GoodApps | Transformación | Conciliación |
|---|---|---|---|
| `SERVICIO`, `SERVICIO_EXTRAS` | `tenantServices` + `serviceConfigVersions` (v1 `published`) | Cada `COD_SER` → servicio; columnas de configuración → dimensiones del perfil (6.B); `capabilityId` por dominio (CTR-CAT-06 para MODEMS/SERVINT). | Conteo de servicios; revisión del perfil por el tenant antes de abrir oferta. |
| `HIS_SERVICIO`, `HIS_SERVICIO_EXTRAS` | `serviceConfigVersions` (`superseded`) | Cada cambio fechado → versión histórica de solo lectura. | Fechas consecutivas sin huecos. |
| `TIP_SERVI` | `serviceCapabilities` (mapeo) / `tenantServices.type` | Tipo → dominio y `measured/technical`. | Todo servicio con capacidad asignada. |
| `CLASESER` | `serviceClasses` | Valores de clase 1/2; tasa hospital → concepto de tercero (CTR-CAT-17). | Conteo por servicio. |
| `CATE_SER`, `CATE_SER_EXTRAS`, `HIS_CATE_SER`, `HIS_CATE_SER_EXTRAS` | `serviceCategories` (estructura) | Atributos estructurales; precios y coeficientes → TAR; `CAT_SOC` → `isSocial` (CTR-CAT-13). | Conteo por servicio; categorías sociales revisadas. |
| `GRP_CAT` | `serviceCategoryGroups` | Directo. | Conteo. |
| `PROPIESER` | `serviceProperties` | Directo con tipo de valor. | Conteo. |
| `PROD_SER`, `HIS_PROD_SER` | `serviceProducts` + `billableConcepts` (estructura) | Producto/concepto; precio → TAR. | Conteo por servicio; conceptos sin uso marcados `inactive`. |
| `ESTASER` | `serviceStatuses` | Asignar `canonicalStatus` e `impliesDisconnection` (CORTADO → `suspended`). | Ningún estado sin mapeo. |
| `SERSOC`, `SERSOC_EXTRAS` | `serviceContracts` | `CONDICION` + fechas + `ESTASER` → estado canónico según 8.1; fechas `1901-01-01` → `null` (CTR-CAT-09); flags (No facturar con vigencia por defecto PRM-CAT-070 y tarea de revisión; Provisorio; Cobrar provisorio; No aplica recategorización; Alta desde CoopOnline; Lectura con factor). | Conteo por `COD_SER × CONDICION` = conteo por servicio × estado canónico; suma de contratos activos igual al último período facturado. |
| `SERSOC_HST` | `serviceContractHistory` | Cada registro → evento histórico con `source=migration`. | Último estado histórico coincide con el actual. |
| `SERSOC_PRODUCTOS` | `contractEquipmentAssignments` | Modalidad comodato/venta; serie → unidad STK (si STK migra antes). | Equipos con serie conciliados con STK; sin serie → tarea. |
| `ALTASEAU` | `autoServiceRules` | Modo `propose` salvo marcados obligatorios con fundamento (CTR-CAT-05). | Revisión del tenant. |
| `CONEXION` | `eventChargeRules` | Tipo de evento 1..7; precio → TAR. | Conteo por evento. |
| `CONE_BONIF` | `eventChargeWaivers` | Directo. | Conteo. |
| `ADHSOC`, `BENSOC` | `contractMembers` | Persona → PER (sin duplicar); vínculo → `VINCULOS` (PER). | Conteo por servicio; repetidos reportados. |
| `ARTEFACTO`, `ARTEFSUMS`, `HIS_ARTEFSUMS` | `applianceTypes`, `contractDeclaredAppliances` | Directo con historia. | Conteo por contrato GAS. |
| `SUMNOFAC` | `serviceContracts.flags.noBill` | Nivel cuenta → por contrato con vigencia. | Contratos marcados. |
| `CONCESIO` | `serviceConcessions` | Directo; `verified=false`. | Revisión legal. |
| `TEL_SERSOC`, `TEL_SERVICIO`, `TEL_MODALIDAD`, `SERTEL`, `TEL_NUMEROS` | `serviceContracts.domainAttributes` (TEL) / planes TEL | Línea, modalidad, número; planta externa (`TEL_CAJAS`, `TEL_REPARTIDOR`, `TEL_PUERTOS_*`, `TEL_DSLAM`, regletas) → TEC. | Líneas activas = contratos TEL activos. |
| `INTERNET` (sin secretos) | `serviceContracts.domainAttributes` (INT) | Usuario, perfil, IP; contraseñas → bóveda o regeneración (CTR-CAT-10). | Contratos INT activos con perfil técnico. |
| `CORREOSINT`, `MIKROTIK` | T06 (bóveda) / TEC | Credenciales nunca en colecciones CAT. | — |
| `TRANSFER` (tipo 2, servicios) | `serviceContractHistory` + `supersededByContractId` | Relación origen-destino. | Pares conciliados. |
| `PLANESVIV`, `VIVIENDAS` | Planes VIV / contratos VIV (parte contractual) | Financiación → FAC. | Conteo. |
| `AMBULANC`, `MEDICOS`, `PROFESIO` | Recursos de SAL (catálogos operativos) → TEC/CFG; `PROFESIO` → PER | Sin datos clínicos. | — |
| `FACTIBIL` | TEC | — | — |
| `SERSOC_DEMANDASXPERIODO`, `SERSOC_REDES` | MED / TEC | — | — |
| `SERVINT`, `MODEMS` | CFG (modelo de interfaz) / T09 (módems GSM de SMS) | No son Internet (CTR-CAT-06). | — |
| `PREPAGA`, `ENGAS_CANTMESES` | TAR / MED | — | — |
| `PROD_SER_RET`, `PROD_SER_UBICACION` | TAR / STK | — | — |
| `OBSESTAD`, `RESESTAD`, `CERESTAD` | MED (observaciones de lectura) | No son estados de servicio. | — |
| `TEMPMODIFBONIF` | Descartado (temporal de proceso) | — | — |

### 19.2 Orden y controles

1. PER (personas, cuentas, domicilios) → STK (unidades) → CAT configuración → TAR (precios) → CAT contratos → MED → FAC/COB.
2. Ensayo en tenant de pruebas; informe de conciliación por servicio × estado, contratos sin titular, contratos sin domicilio, fechas inconsistentes (`FEC_BAJA < FEC_ALTA`), contratos activos sin categoría, estados sin mapeo.
3. Validación del tenant firmada antes del corte; los contratos con anomalías migran con marca `migrationIssue` y bandeja.
4. Reejecución idempotente por `legacyKey` (`COD_SER`, `NRO_SOC`, `NRO_SUM`/secuencia).

## 20. Contraposiciones resueltas

| CTR-ID | Fuentes | Conflicto | Resolución | Regla |
|---|---|---|---|---|
| CTR-CAT-01 | BASE §48 vs. RN-06 §3 | BASE: solicitar no es ejecutar. ProCoop: el alta no técnica queda conectada al grabarse. | Prevalece BASE: toda alta nace `requested` y requiere aprobación (automática configurable solo en no técnicos sin requisitos pendientes). | RN-CAT-064, T01/T05 |
| CTR-CAT-02 | RN-01 §2 / RN-06 §4.1 vs. AGR-003 | Estado derivado de fechas vs. máquina explícita. | Estado explícito con fechas como atributos; mapeo en 8.1. | RN-CAT-017 |
| CTR-CAT-03 | RN-06 §10 vs. AGR-007 / BASE §91 | Cascada automática a adherentes vs. decisión trazable. | Configurable `cascade/ask/none` con historia. | RN-CAT-045, PRM-CAT-060 |
| CTR-CAT-04 | ProCoop paso masivo a prepago vs. BASE §53/§70 | Conversión masiva del moroso vs. límites normativos. | Solo por orden de MOR con política y simulación; CAT ejecuta el trámite. | RN-CAT-049 |
| CTR-CAT-05 | RN-06 §3.5 (`ALTASEAU`) vs. BASE §66/§81 | Encender un servicio no implica contratarlo. | Modo `propose` por defecto; `create` solo con `legalBasis` (PA-CAT-04). | RN-CAT-035 |
| CTR-CAT-06 | DFA M4 vs. CAT §12 | DFA lista `MODEMS`/`SERVINT` como Internet; CAT los describe como módems GSM y modelo de interfaz. | Prevalece CAT (fuente más específica): no pertenecen a INT. | 19.1 |
| CTR-CAT-07 | RN-06 §6 vs. RN-09 (V2 2455) | Semántica del cambio de categoría con OT. | `categoryChangeMode` explícito; [VERIFICAR] con usuarios clave. | RN-CAT-047, PRM-CAT-044/045 |
| CTR-CAT-08 | RN-06 §7 (modo eliminar) vs. AGR-007/AGR-010 | Borrado físico en transferencia. | Siempre clonado; el origen queda `superseded`. | RN-CAT-051 |
| CTR-CAT-09 | RN-01 §2 vs. convenciones de datos (T05 DAT) | Fecha centinela `1901-01-01`. | `null`. | RN-CAT-018 |
| CTR-CAT-10 | CAT §12 (`INTERNET`, `CORREOSINT`, `MIKROTIK`) vs. T02/T06 | Credenciales en claro. | Bóveda; CAT guarda `secretRef`. | Sección 13, RN-CAT-046 |
| CTR-CAT-11 | BASE §92 vs. DEC-007 | Solo seis servicios confirmados vs. todo ProCoop en alcance. | DEC-007: fichas para todos los dominios ProCoop. | 6.C |
| CTR-CAT-12 | BASE §32 vs. DEC-007 | Servicios "candidatos" vs. alcance completo. | Adoptados como capacidades. | RF-CAT-001 |
| CTR-CAT-13 | `Es_Categoria_Social` (descripción "JUBILADOS") vs. BASE §5 | Inferencia por texto. | Flag `isSocial`. | RN-CAT-016 |
| CTR-CAT-14 | Integración BATCOM con `COD_SER=1` fijo vs. BASE §66 | Código fijo. | Integración configurable por servicio. | 13 |
| CTR-CAT-15 | V2 2269/2715 vs. BASE §1/§83 | Prohibir servicios iguales en la cuenta vs. múltiples contrataciones. | Configurable; default permitir no medidos (PA-CAT-11). | RN-CAT-032 |
| CTR-CAT-16 | V2 2482/2668 vs. BASE §1/§89 | Deuda del domicilio bloquea alta vs. la dirección no determina deuda. | Advertencia por defecto (PA-CAT-12); nunca traslado. | RN-CAT-030 |
| CTR-CAT-17 | `CLASESER` tasa hospital vs. dominio TAS | Clase usada como tasa. | Clase = clasificación; tasa = concepto de tercero. | 6.C.15 |
| CTR-CAT-18 | `IMP_CAPITAL` en servicio vs. INS | Capital social cobrado como servicio. | Concepto CAP; libro de capital en INS. | 6.C.16 |
| CTR-CAT-19 | BASE §66 vs. DEC-003 | BASE no decide arquitectura. | DEC-003 monolito modular: CAT es módulo. | 2.3 |
| CTR-CAT-20 | V2 2527 vs. BASE §91 | Edades de donante como regla clínica. | Solo filtro administrativo configurable; sin decisión clínica. | 6.C.12 |

## 21. Preguntas abiertas

### PA-CAT-01 — Momento de creación del contrato

- **Pregunta:** ¿El contrato se crea cuando el socio envía la solicitud, cuando CRM la admite o cuando se aprueba?
- **Contexto:** BASE §48 separa solicitar de ejecutar; ProCoop crea el registro `SERSOC` al grabar el alta. Crear demasiado pronto llena la base de contratos de solicitudes inválidas; crear tarde impide reservar equipo y agendar.
- **Opciones:**
  - A) **(Recomendada)** Al admitir la solicitud en CRM, en estado `requested`, sin efectos de facturación.
  - B) Al enviar la solicitud desde cualquier canal.
  - C) Solo al aprobar (la solicitud vive en CRM hasta entonces).
- **Impacto si no se responde:** se aplica A; ajustar luego obliga a migrar contratos `requested`.
- **Bloquea:** RF-CAT-067, T01, integración CRM–CAT (O3).

### PA-CAT-02 — Quién habilita capacidades y quién publica servicios

- **Pregunta:** ¿Quién habilita una capacidad en un tenant y quién publica la oferta? (BASE §71)
- **Contexto:** la habilitación depende de licencia (T01); la publicación compromete condiciones frente a los socios.
- **Opciones:**
  - A) **(Recomendada)** La plataforma habilita según licencia; el administrador del tenant configura y publica con aprobación por usuario distinto en producción (PRM-CAT-002).
  - B) El tenant habilita y publica sin intervención de plataforma.
  - C) La plataforma habilita y publica a pedido del tenant.
- **Impacto si no se responde:** se aplica A.
- **Bloquea:** RF-CAT-002, RF-CAT-005, PAN-CAT-02.

### PA-CAT-03 — Efecto de apagar una capacidad u oferta con contratos vigentes

- **Pregunta:** ¿Qué pasa con los contratos vigentes si se cierra la oferta o se deshabilita la capacidad? (BASE §71)
- **Contexto:** apagar no debe dejar socios sin servicio ni facturación huérfana.
- **Opciones:**
  - A) **(Recomendada)** Cerrar oferta solo impide nuevas contrataciones; cerrar operación exige plan de salida aprobado (bajas programadas, aviso, migración de plan).
  - B) Deshabilitar da de baja automáticamente todos los contratos.
  - C) No se permite deshabilitar mientras haya contratos.
- **Impacto si no se responde:** se aplica A con PRM-CAT-001=true.
- **Bloquea:** RN-CAT-003, CU-CAT-12.

### PA-CAT-04 — Altas automáticas de servicios opcionales

- **Pregunta:** ¿Puede una regla automática crear contratos de servicios opcionales (ej. sepelio al conectar electricidad)?
- **Contexto:** ProCoop (`ALTASEAU`) los crea; BASE §66/§81 y la normativa de defensa del consumidor exigen consentimiento para servicios no obligatorios.
- **Opciones:**
  - A) **(Recomendada)** `create` solo para servicios obligatorios con fundamento normativo registrado (`legalBasis`); opcionales en modo `propose` con consentimiento del socio.
  - B) Permitir `create` en cualquier servicio, a criterio del tenant.
  - C) Solo `propose` en todos los casos.
- **Impacto si no se responde:** se aplica A; la migración de `ALTASEAU` crea reglas en `propose`.
- **Bloquea:** RF-CAT-086, RN-CAT-035, CTR-CAT-05.

### PA-CAT-05 — Jerarquía definitiva servicio, producto, subservicio y plan

- **Pregunta:** ¿Cuál es la jerarquía definitiva? (BASE §74)
- **Contexto:** ProCoop usa servicio → categoría → producto (`PROD_SER`); BASE §72 habla de productos, planes y subservicios.
- **Opciones:**
  - A) **(Recomendada)** Servicio del tenant → producto (incluye subservicio como producto `addon`) → plan versionado → conceptos facturables; la categoría es eje estructural transversal al plan.
  - B) Servicio → plan → subservicios, sin entidad producto.
  - C) Servicio → categoría → producto (modelo ProCoop).
- **Impacto si no se responde:** se aplica A, que admite migrar el modelo ProCoop.
- **Bloquea:** modelo de datos 7.5–7.10, M04 TAR.

### PA-CAT-06 — Alcance de Banco de sangre

- **Pregunta:** ¿Banco de sangre se limita a cobertura administrativa por convenio? (BASE §91, §95)
- **Contexto:** gestionar información clínica implica régimen de datos de salud y habilitaciones sanitarias.
- **Opciones:**
  - A) **(Recomendada)** Solo administrativo: contrato, beneficiarios, convenio, autorización de cobertura; sin datos clínicos ni decisión de aptitud.
  - B) Incluir registro de donaciones y aptitud.
  - C) No incluirlo en la primera versión.
- **Impacto si no se responde:** se aplica A.
- **Bloquea:** ficha 6.C.12, CU-ESP-SAN.

### PA-CAT-07 — Autorización del tenant origen en copias

- **Pregunta:** ¿Hace falta consentimiento del tenant origen para copiar su configuración a otro?
- **Contexto:** la configuración (planes, condiciones, textos) puede ser información comercial propia de cada cooperativa.
- **Opciones:**
  - A) **(Recomendada)** Sí: autorización explícita del tenant origen más ejecución por operador de plataforma o admin del destino.
  - B) La plataforma copia sin consentimiento (configuración no es dato personal).
  - C) Solo se copian plantillas de plataforma, nunca configuración de tenants.
- **Impacto si no se responde:** se aplica A (PRM-CAT-103).
- **Bloquea:** RF-CAT-104..108, API-CAT-47.

### PA-CAT-08 — Plantillas de plataforma

- **Pregunta:** ¿GoodApps mantiene plantillas de servicio propias (sin tenant origen)?
- **Contexto:** acelera el lanzamiento en cooperativas nuevas; riesgo de sugerir precios o condiciones como oficiales.
- **Opciones:**
  - A) **(Recomendada)** Sí, sin precios ni condiciones reguladas; solo estructura, conceptos, estados y textos de ejemplo.
  - B) Sí, con precios de referencia.
  - C) No; solo copia entre tenants.
- **Impacto si no se responde:** se aplica A.
- **Bloquea:** RF-CAT-109, API-CAT-55.

### PA-CAT-09 — Semántica de "Provisorio" y "Cobrar provisorio"

- **Pregunta:** ¿Qué significan exactamente las marcas de `SERSOC` "Provisorio" y "Cobrar provisorio"?
- **Contexto:** las fuentes no lo describen con precisión ([VERIFICAR]); se usan en filtros de `CONEXION` y trámites masivos.
- **Opciones:**
  - A) **(Recomendada)** Provisorio = suministro transitorio (obra, evento) con vencimiento obligatorio; Cobrar provisorio = se factura durante la condición provisoria con conceptos propios.
  - B) Provisorio = alta pendiente de documentación.
  - C) Eliminar las marcas y reemplazarlas por planes específicos.
- **Impacto si no se responde:** se aplica A con PRM-CAT-071.
- **Bloquea:** RF-CAT-069, RN-CAT-063, migración de flags.

### PA-CAT-10 — Modalidad por defecto de equipos

- **Pregunta:** ¿Los equipos se entregan en comodato, venta o alquiler por defecto, y quién los valoriza? (BASE §74)
- **Opciones:**
  - A) **(Recomendada)** Modalidades configurables por plan; por defecto comodato en INT y TV; valorización y custodia en STK; cargo por no devolución solo si figura en las condiciones aceptadas.
  - B) Siempre venta financiada.
  - C) Siempre comodato sin cargo por pérdida.
- **Impacto si no se responde:** se aplica A (PRM-CAT-093).
- **Bloquea:** RF-CAT-051, RF-CAT-079, RF-CAT-101.

### PA-CAT-11 — Contratos iguales en la misma cuenta

- **Pregunta:** ¿Se permite que una cuenta tenga dos contratos del mismo servicio?
- **Contexto:** V2 2269/2715 lo prohíben; BASE §1/§83 exige múltiples contrataciones independientes.
- **Opciones:**
  - A) **(Recomendada)** Permitir en no medidos; en medidos uno por punto de suministro (con distinto domicilio o medidor se permiten).
  - B) Prohibir siempre.
  - C) Permitir siempre.
- **Impacto si no se responde:** se aplica A (PRM-CAT-021/022).
- **Bloquea:** RN-CAT-032, RF-CAT-078.

### PA-CAT-12 — Deuda en el domicilio del servicio

- **Pregunta:** ¿La deuda de otra cuenta en el mismo domicilio bloquea el alta?
- **Contexto:** ProCoop puede bloquear; BASE §1/§89 dice que la dirección no determina la deuda de otro titular (ESC-03).
- **Opciones:**
  - A) **(Recomendada)** Advertencia por defecto; el tenant puede exigir autorización de supervisor; nunca bloqueo automático ni traslado de deuda.
  - B) Bloqueo configurable.
  - C) Sin control.
- **Impacto si no se responde:** se aplica A (PRM-CAT-017).
- **Bloquea:** RN-CAT-030, RF-CAT-076.

### PA-CAT-13 — Modalidades de gas

- **Pregunta:** ¿Qué modalidades de gas se modelan (red natural, propano por redes, envasado)?
- **Contexto:** BASE §89 distingue condición de prestador/subdistribuidor; ProCoop tiene `CORREGAS`, `PRCAGAS`, `ENGAS_CANTMESES`.
- **Opciones:**
  - A) **(Recomendada)** Variantes de la capacidad GAS (red natural, propano por red, envasado) habilitables por tenant con perfil propio.
  - B) Solo gas natural por red.
  - C) Capacidades separadas por modalidad.
- **Impacto si no se responde:** se aplica A.
- **Bloquea:** ficha 6.C.7.

### PA-CAT-14 — Suspensión voluntaria

- **Pregunta:** ¿La suspensión voluntaria (vacaciones, ausencia) está disponible por defecto?
- **Opciones:**
  - A) **(Recomendada)** Configurable por servicio, deshabilitada por defecto; con duración máxima y efecto sobre cargos definidos en TAR.
  - B) Habilitada por defecto en todos los servicios.
  - C) No se ofrece.
- **Impacto si no se responde:** se aplica A (PRM-CAT-098/099).
- **Bloquea:** T08 motivo `voluntary`, JOB-CAT-08.

### PA-CAT-15 — Fecha efectiva del cambio de plan

- **Pregunta:** ¿Desde cuándo rige un cambio de plan?
- **Opciones:**
  - A) **(Recomendada)** Configurable; por defecto el próximo período de facturación; inmediato con prorrateo (TAR) si el tenant lo habilita; upgrades técnicos desde la confirmación de reprovisión.
  - B) Siempre inmediato con prorrateo.
  - C) Siempre al próximo período.
- **Impacto si no se responde:** se aplica A (PRM-CAT-100).
- **Bloquea:** RF-CAT-081, 9.4.

### PA-CAT-16 — Hito que confirma la activación

- **Pregunta:** ¿Qué hito activa el contrato técnico y qué rol tiene la revisión supervisora? (BASE §74)
- **Contexto:** activar antes de la provisión genera cargos sin servicio; esperar a la revisión retrasa la facturación.
- **Opciones:**
  - A) **(Recomendada)** Activa la confirmación técnica (`tec.installation.completed` con provisión confirmada y conformidad); la revisión supervisora es posterior y, si observa, abre corrección sin revertir automáticamente.
  - B) Activa la aprobación del supervisor tras la instalación.
  - C) Activa el cierre administrativo de la OT.
- **Impacto si no se responde:** se aplica A.
- **Bloquea:** T06, RN-CAT-042, M10 TEC.

## 22. Trazabilidad

### 22.1 Requisitos y secciones BASE asignadas

| Origen | Contenido | Cobertura en este anexo |
|---|---|---|
| BASE §1 Servicios habilitables y alta pública | Servicios por tenant, alta pública | RF-CAT-001..008, RF-CAT-110, PAN-CAT-21/23 |
| BASE §1 Configuración independiente y copia | Configuración por tenant, comunidad | RF-CAT-013, RF-CAT-104..108 |
| BASE §1 Titularidad y particularidades | DNI/CUIT, conexiones múltiples independientes | RF-CAT-067, RN-CAT-030/032, ESC-03, PA-CAT-11/12 |
| BASE §5 Catálogo de prestaciones y planes, CU-05 | Prestaciones, planes, unidades, requisitos, precarga | RF-CAT-031, 036, 041..045, 049, 070; CU-05; 18 |
| BASE §32 Particularidades según servicio | Antecedente de servicios | 6.C, CTR-CAT-12 |
| BASE §39.1 / §39.2 Precarga, servicios, unidades y liquidación | Sugerencias por servicio, unidad, periodicidad | RF-CAT-016, 017, 035; 18 |
| BASE §48 SOL-001, SOL-002, CU-SOL-01 | Solicitud de alta y baja de cualquier servicio (parte que define el servicio) | RF-CAT-025, 063, 072, 088, 111, 112; T01, T12; CU-SOL-01; CTR-CAT-01 |
| BASE §53 CIC-001..004 | Baja, suspensión, reactivación, modalidades con y sin costo | RF-CAT-030, 061, 063, 065, 066, 088; 8.2; RN-CAT-038; ESC-04/05 |
| BASE §54 GOB-004 / indicadores | Gobierno de configuración, indicadores | RF-CAT-006, 113; 15 |
| BASE §66 CAT-001, CAT-002, CAT-003, CU-CAT-01 | Capacidades por tenant, oferta a la comunidad, cementerio parque | RF-CAT-001..008, 110; 6.C.11; CU-CAT-01 |
| BASE §71 Pendientes de catálogo | Quién habilita/publica; efecto de apagar; cementerio parque; registro público; mínimo de pago; afectación cruzada; costos de reactivación; fechas de corte; universos; excepciones batch; contingencia fiscal | PA-CAT-02; PA-CAT-03; 6.C.11; registro público → M01 PER/M18 SOC; mínimo de pago → M08 MOR; afectación cruzada → M08 MOR (CAT expone `suspension.mode` por servicio); costos de reactivación → RN-CAT-038 + M08 MOR; fechas/universos/batch → M05 FAC; contingencia fiscal → M06 FIS |
| BASE §72 PRO-001..004, CU-PRO-01 | Productos, subservicios, bonificación por X meses, financiación | RF-CAT-036..048, 052; RN-CAT-009..014; CU-PRO-01; ESC-01 |
| BASE §74 Pendientes de composición e instalación | Jerarquía; costo interno vs. precio; promociones; financiación; equipos; visitas; firma; hito de activación; prorrateo; encuestas | PA-CAT-05; RF-CAT-037 (concepto interno) + M04 TAR; RN-CAT-013 + M04; M04/M05; PA-CAT-10; M10 TEC (T07 registra visita fallida); M10 TEC; PA-CAT-16; M04 TAR; M09 CRM |
| BASE §80 Pendientes de geografía y compras | Inmueble, dirección, punto de acceso y varios contratos; artículos y servicios | RF-CAT-067, RN-CAT-023; M01 PER; M13 STK / M15 CON |
| BASE §81 COP-001..003, CU-COP-01 | Copia de configuración entre tenants | RF-CAT-104..108; RN-CAT-068/069; 9.6; ESC-02; PA-CAT-07 |
| BASE §84 Núcleo común y perfil | Perfil de configuración por servicio | RF-CAT-013..030; 6.B |
| BASE §85 Autoridades, Córdoba, vigencia | Fuente, jurisdicción, vigencia | RF-CAT-014; `serviceConcessions`; PAN-CAT-26 |
| BASE §86 Internet | Factibilidad, instalación, equipos, perfil técnico, reclamos | 6.C.1; RF-CAT-051, 079, 099..101; 9.2; ESC-01 |
| BASE §87 Electricidad Córdoba, CU-ESP-ELE | Categorías ERSeP, medición, GD, grandes usuarios | 6.C.4; RF-CAT-096, 097; CU-ESP-ELE |
| BASE §88 Agua y saneamiento, CU-ESP-AG | Medido/no medido, inmueble, conexión | 6.C.5, 6.C.6; CU-ESP-AG |
| BASE §89 Gas, CU-ESP-GAS | Prestador/subdistribuidor, artefactos, rehabilitación | 6.C.7; RF-CAT-095; PAN-CAT-25; PA-CAT-13; CU-ESP-GAS |
| BASE §90 Cementerio parque, CU-ESP-CEM | Unidades, derechos, actos | 6.C.11; PRM-CAT-097; CU-ESP-CEM |
| BASE §91 Banco de sangre, CU-ESP-SAN | Convenio, beneficiarios, límites sanitarios | 6.C.12; PA-CAT-06; CTR-CAT-20; CU-ESP-SAN |
| BASE §92 Otros servicios | Extensiones a relevar | RF-CAT-009, 010; 6.C.2, 6.C.3, 6.C.8..6.C.10, 6.C.13..6.C.17; CTR-CAT-11 |
| BASE §93 Reglas transversales, ESP-001..006 | Reglas por servicio; seis dominios; productos/ciclo; auxiliar por servicio; fuente/vigencia; extensiones sin activación indiscriminada | ESP-001 → RF-CAT-013, 6.B; ESP-002 → 6.C.1, 6.C.4, 6.C.5, 6.C.7, 6.C.11, 6.C.12; ESP-003 → 6.C (productos típicos y estados); ESP-004 → RF-CAT-067, ESC-03 (auxiliar en M07 COB); ESP-005 → RF-CAT-014; ESP-006 → RF-CAT-002, RN-CAT-002, PA-CAT-04 |
| BASE §94 Fuentes | Fuentes de la investigación | `serviceConcessions.sources`; 6.C |
| BASE §95 Validación pendiente por servicio | Insumos por dominio; DNI/CUIT; ERSeP; categorías e importes; formularios; límites sanitarios; convertir fichas | 6.C (bloque "Validación pendiente" de cada ficha); M01 PER; 6.C.4 [VERIFICAR]; M04 TAR; 10 y 16; PA-CAT-06; 10–17 |
| BASE §37 Pendientes generales | Piloto, roles, procesos, pantallas, datos, integraciones, migración, criterios | DEC-001 (piloto Internet); 4; 9; 10; 7; 13; 19; 17 |
| BASE §98 Pendientes 0.15 | Rol de plataforma frente a Ley 25.326 | Fuera de alcance (T02); CAT aplica minimización en 17.4 y RN-CAT-068 |
| BASE §101 Pendientes de mercado | Emisión separada por servicio; consumo no registrado | PRM-CAT-081 + M05 FAC; M03 MED |
| BASE §106 Pendientes 0.17 | Servicios en mismo comprobante; periodicidad distinta en grupo | M05 FAC (CAT provee `billingGroupDefault` y periodicidad del plan) |
| BASE MER-001 | Usuario-generador | RF-CAT-096; `generationAgreements`; 6.C.4 |
| BASE MER-003 | Grandes usuarios y contratos especiales | RF-CAT-097; `contractSpecialConditions` |
| BASE MER-017 | Telefonía y red de ISP | RF-CAT-098, 099; 6.C.1, 6.C.2; planta externa → M10 TEC |

### 22.2 Agregados, decisiones y referencias

| Origen | Cobertura |
|---|---|
| DEC-001 (piloto Internet) | 6.C.1, 9.2, ESC-01, 18 |
| DEC-003 (monolito modular) | 2.3, CTR-CAT-19 |
| DEC-007 (todo ProCoop en alcance) | RF-CAT-010, 6.C, CTR-CAT-11/12 |
| AGR-002 (CRM no ejecuta) | RN-CAT-071, 12.2 |
| AGR-003 (máquina de estados explícita, reversión) | RF-CAT-061, 091, 8, CTR-CAT-02 |
| AGR-005 (catálogo de capacidades) | RF-CAT-002, 005 |
| AGR-007 (titularidad y representación) | 4 (alcance socio), CTR-CAT-03/08 |
| AGR-008 / AGR-009 (versionado y aprobación) | RF-CAT-031..035, 106 |
| AGR-010 (historia, sin borrado físico) | RF-CAT-034, 057, CTR-CAT-08 |
| AGR-017 (promociones y beneficios) | RF-CAT-045, RN-CAT-013 |
| AGR-022 (corte temporal) | RN-CAT-066, 15 |
| DFA Módulo 4 (líneas 242-312) | RF-CAT-010, 057, 058, 062, 064, 068, 069, 095, 109; CTR-CAT-06 |
| DFA M25 / servicios TIC, vivienda y salud (1060-1085) | RF-CAT-010, 6.C.1–6.C.3, 6.C.13, 6.C.14 |
| README (administración de servicios, ficha) | RF-CAT-068, PAN-CAT-14 |
| REL (capturas de administración de servicios y flags) | RF-CAT-053, 058, 064, 068, 069, 072 |
| RN-01 §2 tipos de cálculo `TIP_CAL` | RF-CAT-017, 021, 071; RN-CAT-073/074; 6.B |
| RN-01 §9 adherentes | RF-CAT-022, 055, 059, 080 |
| RN-01 §10 telefonía | RN-CAT-075, PRM-CAT-090..092 |
| RN-06 §3.1–§3.6 altas, validaciones, configuración, altas automáticas, conexión | RF-CAT-016..020, 050, 071..078, 086, 102, 103; RN-CAT-020..037 |
| RN-06 §4.1–§4.3 estados, conexión/desconexión, trámites | RF-CAT-063, 087, 090; RN-CAT-019, 039..046; 8.1; 9.8 |
| RN-06 §5 bajas | RF-CAT-088, 089; RN-CAT-065, 072 |
| RN-06 §6 cambios de categoría y clase | RF-CAT-055, 058, 060, 082, 083; RN-CAT-047..050; CTR-CAT-07 |
| RN-06 §7 transferencias | RF-CAT-084; RN-CAT-051..054; 9.5 |
| RN-06 §8 domicilio | RF-CAT-085; RN-CAT-055 |
| RN-06 §10–§11 adherentes y grupos de facturación | RF-CAT-020, 080; RN-CAT-024, 056..060 |
| RN-09 parámetros | 14 (todas las claves V2 listadas y delegadas) |
| CNX §2.4 (un renglón de suscriptores = un producto) | RF-CAT-002; 7.1–7.2 (capacidad licenciada ≠ servicio del tenant) |
| CNX §4.2–§4.3 (layout y patrones) | 10 |

### 22.3 Tablas ProCoop — catálogo §2 (servicios)

| Tabla | Destino |
|---|---|
| `ALTASEAU` | CAT `autoServiceRules` (RF-CAT-086, RN-CAT-035) |
| `ARTEFACTO` | CAT `applianceTypes` (RF-CAT-095) |
| `ARTEFSUMS` | CAT `contractDeclaredAppliances` (RF-CAT-095) |
| `CARGOS_ADICIONALES` | M04 TAR |
| `CATE_SER` | CAT `serviceCategories` estructura (RF-CAT-055); precios → M04 TAR |
| `CATE_SER_COEFICIENTES` | M04 TAR |
| `CATE_SER_EXTRAS` | CAT `serviceCategories` (generador, perfil de red, sociales) (RF-CAT-055, 096, 099) |
| `CATTARIF` | M04 TAR (CAT referencia `tariffBinding`) |
| `CATTMC` | M04 TAR |
| `CLASESER` | CAT `serviceClasses` (RF-CAT-053, CTR-CAT-17) |
| `CONCESIO` | CAT `serviceConcessions` (RF-CAT-014) |
| `CONEXION` | CAT `eventChargeRules` (RF-CAT-050); precio → M04 TAR |
| `CONE_BONIF` | CAT `eventChargeWaivers` (RF-CAT-050) |
| `CON_TASAS` | M06 FIS / M04 TAR (6.C.15) |
| `CORREGAS` | M03 MED / M04 TAR |
| `CUADRI` | M04 TAR |
| `CUADROS` | M04 TAR |
| `DESCPOS` | M04 TAR |
| `ESTASER` | CAT `serviceStatuses` (RF-CAT-062, 8.1) |
| `ESTINM` | M01 PER |
| `FACTOR_CAL` | M03 MED / M04 TAR (flag lectura con factor en CAT, PRM-CAT-073) |
| `FACT_EPEC` | Compras/costos de energía (M15 CON y módulo de compras) |
| `GRP_CAT` | CAT `serviceCategoryGroups` (RF-CAT-056) |
| `HIS_ARTEFSUMS` | CAT historia de `contractDeclaredAppliances` |
| `HIS_CARGOS_ADICIONALES` | M04 TAR |
| `HIS_CATE_SER` | CAT historia de `serviceCategories` (versionado) |
| `HIS_CATE_SER_EXTRAS` | CAT historia de `serviceCategories` |
| `HIS_CATTARIF` | M04 TAR |
| `HIS_IMPUESTO` | M06 FIS |
| `HIS_PROD_SER` | CAT historia de `serviceProducts`/`billableConcepts`; precios → M04 TAR |
| `HIS_SERVICIO` | CAT `serviceConfigVersions` (RF-CAT-034) |
| `HIS_SERVICIO_EXTRAS` | CAT `serviceConfigVersions` (RF-CAT-034) |
| `HIS_TAR_ADHE` | M04 TAR |
| `IMPUESTO` | M06 FIS (CAT asigna clase fiscal al concepto) |
| `IMPUESTOS_X_CAT` | M06 FIS |
| `PRCAGAS` | M03 MED / M04 TAR |
| `PROD_SER` | CAT `serviceProducts` + `billableConcepts` (RF-CAT-037) |
| `PROD_SER_REC_DES` | M04 TAR / M08 MOR |
| `PROPIESER` | CAT `serviceProperties` (RF-CAT-054) |
| `RECARGOS` | M04 TAR |
| `REFEREN` | M01 PER / CFG (CAT referencia en contrato) |
| `SERVICIO` | CAT `tenantServices` + `serviceConfigVersions` (RF-CAT-013..030) |
| `SERVICIO_EXTRAS` | CAT `serviceConfigVersions` (RF-CAT-022..024) |
| `TAR_ADHE` | M04 TAR (CAT define adherentes computables) |
| `TEMPMODIFBONIF` | Descartado (tabla temporal de proceso) |
| `TIPOLOTE` | CFG |
| `TIP_SERVI` | CAT `serviceCapabilities` / `tenantServices.type` (RF-CAT-012) |
| `USOINM` | M01 PER |

### 22.4 Tablas ProCoop — contratos y miembros (§1)

| Tabla | Destino |
|---|---|
| `SERSOC` | CAT `serviceContracts` (RF-CAT-067..103) |
| `SERSOC_EXTRAS` | CAT `serviceContracts` (flags, GD) (RF-CAT-069, 096) |
| `SERSOC_HST` | CAT `serviceContractHistory` |
| `SERSOC_PRODUCTOS` | CAT `contractEquipmentAssignments` (RF-CAT-079) |
| `SERSOC_DEMANDASXPERIODO` | M03 MED |
| `SERSOC_REDES` | M10 TEC |
| `SUMNOFAC` | CAT flag `noBill` (RF-CAT-069) |
| `ADHSOC` | CAT `contractMembers` (RF-CAT-080) |
| `BENSOC` | CAT `contractMembers` (RF-CAT-080) |
| `VINCULOS` | M01 PER (catálogo de vínculos) |
| `FACTIBIL` | M10 TEC |
| `PROFESIO` | M01 PER |
| `PLANESVIV`, `VIVIENDAS` | CAT planes y contratos VIV (6.C.14); financiación → M05 FAC |
| `AMBULANC`, `MEDICOS` | Recursos operativos de SAL → M10 TEC / CFG (6.C.13) |
| `SERVINT` | CFG (modelo de interfaz) (CTR-CAT-06) |
| `MODEMS` | T09 notificaciones (módems GSM de SMS) (CTR-CAT-06) |
| `PREPAGA` | M04 TAR / M03 MED |
| `ENGAS_CANTMESES` | M03 MED |
| `PROD_SER_RET`, `PROD_SER_UBICACION` | M04 TAR / M13 STK |
| `OBSESTAD`, `RESESTAD`, `CERESTAD` | M03 MED (no son estados de servicio) |
| `TRANSFER` (tipo 2) | CAT historia de transferencias (RF-CAT-084) |

### 22.5 Tablas ProCoop — catálogo §12 (servicios TIC)

| Tabla | Destino |
|---|---|
| `INTERNET` | CAT `serviceContracts.domainAttributes` INT (sin secretos) (RF-CAT-099, CTR-CAT-10) |
| `CORREOSINT` | CAT producto correo (RF-CAT-100); credenciales → T06 bóveda |
| `MIKROTIK` | M10 TEC / T06 (bóveda) |
| `SERTEL`, `TEL_SERSOC`, `TEL_SERVICIO`, `TEL_MODALIDAD`, `TEL_NUMEROS` | CAT planes y contratos TEL (RF-CAT-098) |
| `TEL_PREFIJO`, `TARTEL`, `TARCLA`, `TARESP`, `BANDAS`, `BANCLA`, `TIPOBAN`, `CARACTER`, `PLANDES`, `GRATIS`, `INTERNAC`, `OPERADOR` | M04 TAR (tarifación telefónica; CAT define conceptos CPP/internacional, PRM-CAT-090..092) |
| `LLAMADAS`, `LLA_CEL`, `ENTRANTE`, `TIPOLLAM`, `RECHAZOS`, `CLAVES` | M03 MED (registros de llamadas) / M04 TAR |
| `CENTRALT`, `TEL_CENTRAL`, `TEL_PUERTOS_CENTRAL`, `TEL_DSLAM`, `TEL_PUERTOS_DSLAM`, `TEL_CAJAS`, `TEL_REGLETAS_CAJAS`, `TEL_POS_REG_CAJA`, `TEL_REPARTIDOR`, `TEL_GRUPOS_REPARTIDOR`, `TEL_REGLETAS_GRUPOS`, `TEL_POS_REG_GRUPOS`, `TEL_FRACCIONES` | M10 TEC (planta externa e interna) |

### 22.6 Formularios ProCoop (INV)

| Formulario | Pantalla |
|---|---|
| `abm_Servicio`, `abm_Servicio_OT` | PAN-CAT-03, PAN-CAT-04 |
| `abm_Servicio_Categorias`, `abm_GrpCat` | PAN-CAT-08 (precios → TAR) |
| `abm_Servicio_Cattarif`, `abm_Servicio_TarAdhe`, `abm_CateSer_Coeficientes`, `abm_prod_ser_rec_des` | M04 TAR |
| `abm_Servicio_Propiedad`, `abm_propieItems`, `abm_propieitems_valores`, `abm_ClaseSer` | PAN-CAT-09 |
| `abm_prod_ser`, `abm_prod_ser_combos` | PAN-CAT-06 |
| `abm_AltasEau` | PAN-CAT-11 |
| `abm_Propieda` | M01 PER (inmuebles) |
| `abm_Conexion` | PAN-CAT-12 |
| `abm_EstaSer` | PAN-CAT-10 |
| `abm_Sersoc_Productos` | PAN-CAT-19 |
| `abm_Socios`, `frmTitulares` | PAN-CAT-13..16, PAN-CAT-20 (datos de persona → M01 PER) |
| `abm_Artefactos` | PAN-CAT-25 |
| `abm_Profesio`, `abm_Vinculos` | M01 PER |
| `frmTranferenciaCapital` (servicios), `frmTransferenciasCuenta` | PAN-CAT-16 transferir (capital → M17 INS) |
| `frmPTramites`, `frmRecategorizacion`, `frmSegmentacion_Restablecer` | PAN-CAT-17 |
| `frmTarifaSocial_Importar`, `frmTarifaSocial_ImportarPorDni` | M04 TAR (CAT marca `isSocial`) |
| `frmRetroactivos`, `abm_GruposFactura`, `abm_GruposGrafico` | M05 FAC |
| `Datos_Vivienda`, `frmBajaVivienda`, `frmConstruccionVivienda`, `frmConsultaCambioPlanVivienda`, `frmInformesVivienda`, `frmViviendaActividad` | PAN-CAT-14 (dominio VIV) y 6.C.14; financiación → M05 FAC |

### 22.7 Contraposiciones y preguntas

CTR-CAT-01..20 (sección 20) y PA-CAT-01..16 (sección 21) quedan registradas en el índice de decisiones del proyecto al consolidar los anexos.
