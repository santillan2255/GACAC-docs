﻿import re, json, sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo')
from res_lib import Doc
import pan_catalogo as P

d = Doc(r'anexos\T03-UXD-*.md')
ids = set(r['id'] for r in json.load(open(r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo\pan_crudo.json', encoding='utf-8')))

# --- encabezado de las tablas de campos (numeración 7.B.n del anexo) ---
d.rep('### 7.1 Tablas de campos de las colecciones definidas en texto', '#### 7.B.13 Tablas de campos de las colecciones definidas en texto')

# --- Cat. 8: rótulo corto de la tabbar ---
d.rep('| `dict:nav.pws.servicios` (Cuentas y servicios) |',
      '| `dict:nav.pws.servicios` (Cuentas; `short` ≤ 12 caracteres, RN-UXD-006; título de la pantalla: Cuentas y servicios; antes "Cuentas y servicios") |')
d.rep('(socio: Inicio · Cuentas y servicios · + · Gestiones · Comunidad,',
      '(socio: Inicio · Cuentas (antes "Cuentas y servicios"; rótulo corto de RN-UXD-006) · + · Gestiones · Comunidad,')
d.rep('| SM-PWS-002 | Tabbar | Cuentas y servicios | `/servicios` |',
      '| SM-PWS-002 | Tabbar | Cuentas (rótulo corto de la tabbar, RN-UXD-006; pantalla "Cuentas y servicios"; antes "Cuentas y servicios") | `/servicios` |')

# --- Tabbar del empleado: SM-PWE-013, 016 y 018 ---
d.rep('| SM-PWE-013 | Personal | Mis recibos de sueldo | `/trabajo/recibos` | `sue.portal.recibos.ver` (antes `sue.portal.ver`) | O9 | Maestro §7.2; VAR 3122, 3166 |',
      '| SM-PWE-013 | Tabbar | Mis recibos de sueldo | `/trabajo/recibos` | `sue.portal.recibos.ver` (antes `sue.portal.ver`) | O9 | Maestro §7.2; VAR 3122, 3166; slot 2 de la tabbar del empleado (10.1.4; grupo antes Personal) |')
d.rep('| SM-PWE-016 | Perfil | Perfil y preferencias | `/perfil` | `por.perfil.editar` (antes `uxd.preferencias.editar`) | O0 | — |',
      '| SM-PWE-016 | Tabbar | Perfil y preferencias | `/perfil` | `por.perfil.editar` (antes `uxd.preferencias.editar`) | O0 | Slot 4 de la tabbar del empleado (10.1.4; grupo antes Perfil) |')
d.rep('| SM-PWE-018 | Personal | Vacaciones y licencias |', '| SM-PWE-018 | Tabbar | Vacaciones y licencias |')
d.rep('| SUE-42 (POR-72 `/app/empleado/vacaciones`, POR-73) |',
      '| SUE-42 (POR-72 `/app/empleado/vacaciones`, POR-73); slot 3 de la tabbar del empleado "Solicitudes" (10.1.4; grupo antes Personal) |')

# --- iam.directorio.ver ya registrada en T02 ---
d.rep('| `iam.directorio.ver` (pendiente de alta en T02) |', '| `iam.directorio.ver` (registrada en T02 §4.4.2; antes "pendiente de alta en T02") |')
d.rep('| `iam.directorio.ver` | Capability pendiente de alta en el catálogo de T02 |',
      '| `iam.directorio.ver` | Capability registrada en T02 §4.4.2 (antes "pendiente de alta en el catálogo de T02") |')

# --- App de PAN-UXD-08 y PAN-UXD-14 ---
d.rep('| PAN-UXD-08 | admin y PWA |', '| PAN-UXD-08 | PWA socio y admin (menú avatar; antes "admin y PWA") |')
d.rep('| PAN-UXD-14 | PWA | `/instalar` |', '| PAN-UXD-14 | landing (y PWA instalada; antes "PWA") | `/instalar` |')

# --- Capabilities y rutas del mapa: prevalece el anexo dueño (AL-01) ---
d.rep('| `/admin/per/titulares/:holderId?tab=adherentes` | `per.adherentes.ver` |',
      '| `/admin/per/titulares/:holderId?tab=adherentes` | `soc.adherentes.ver` (PAN-PER-10, AL-01; antes `per.adherentes.ver`) |')
d.rep('| SM-ADM-012 | Relaciones | Grupo familiar y adherentes | `/socios/adherentes` | `per.adherentes.ver` |',
      '| SM-ADM-012 | Relaciones | Grupo familiar y adherentes | `/socios/adherentes` | `soc.adherentes.ver` (antes `per.adherentes.ver`) |')
d.rep('| `tec.telefonia.numeracion.configurar` (antes `tec.phone.numbering`) | O10 | TEC-63',
      '| `tec.telefonia.numeracion.ver` (PAN-TEC-63, AL-01; antes `tec.telefonia.numeracion.configurar` y, antes, `tec.phone.numbering`) | O10 | TEC-63')
d.rep('| SM-PWC-003 | TEC-51 | `/app/campo/work-orders/:id` | `tec.ordenes.editar` (antes `tec.workOrder.update`) |',
      '| SM-PWC-003 | TEC-51 | `/app/campo/work-orders/:id` | `tec.campo.ejecutar` (PAN-TEC-51, AL-01; antes `tec.ordenes.editar` y, antes, `tec.workOrder.update`) |')
d.rep('| SM-PWC-006 | TEC-54 | `/app/campo/inspections/:id` | `tec.inspecciones.gestionar` (antes `tec.inspection.manage`) |',
      '| SM-PWC-006 | TEC-54 | `/app/campo/inspections/:id` | `tec.inspecciones.editar` (PAN-TEC-54, AL-01; antes `tec.inspecciones.gestionar` y, antes, `tec.inspection.manage`) |')
d.rep('| SM-PWC-008 | TEC-55 | `/app/campo/work-orders/new` | `tec.ordenes.crear` (antes `tec.workOrder.create`) |',
      '| SM-PWC-008 | TEC-55 | `/app/campo/work-orders/new` | `tec.campo.crearOrden` (PAN-TEC-55, AL-01; antes `tec.ordenes.crear` y, antes, `tec.workOrder.create`) |')
d.rep('| SM-PWC-015 | TEC-56 | `/app/campo/map` | `tec.mapa.ver` (antes `tec.map.read`) |',
      '| SM-PWC-015 | TEC-56 | `/app/campo/map` | `tec.campo.ver` (PAN-TEC-56, AL-01; antes `tec.mapa.ver` y, antes, `tec.map.read`) |')
d.rep('| `/admin/bi/datos-abiertos` | cualquier `bia.*.ver` (AL-08) | O11 | BIA-21 |',
      '| `/admin/bi/datos-abiertos` | `bia.datosAbiertos.publicar` (PAN-BIA-21, AL-01; antes "cualquier bia.*.ver (AL-08)") | O11 | BIA-21 |')
d.rep('| `/admin/cat/services/:id?tab=requisitos` | `cat.servicios.configurar` |',
      '| `/admin/cat/services/:id` (pestaña Requisitos con `?tab=requisitos`; ruta del anexo, AL-01; antes `/admin/cat/services/:id?tab=requisitos`) | `cat.servicios.configurar` |')
d.rep('| `/admin/fis/vat-ledger?libro=ventas` | `fis.libroIva.ver` |',
      '| `/admin/fis/vat-ledger` (filtro `?libro=ventas`; ruta del anexo, AL-01; antes `/admin/fis/vat-ledger?libro=ventas`) | `fis.libroIva.ver` |')
d.rep('| `/admin/com/avisos-corte` (antes `/admin/com/interrupciones`) | `com.outages.ver` (AL-01; antes `com.outages.gestionar`) | O2 | COM-27 (antes COM-23, que en T09 son los mensajes en factura); relacionada: TEC-28 |',
      '| `/admin/com/avisos-corte` | `com.outages.ver` (AL-01; antes `com.outages.gestionar`) | O2 | COM-27 (antes COM-23, que en T09 son los mensajes en factura); relacionada: TEC-28; ruta antes `/admin/com/interrupciones` |')
d.rep('| `/admin/com/preferencias` (antes `/admin/com/consentimientos`) | `com.consents.ver` | O2 | COM-25 (NFR-04; CTR-UXD-23; antes COM-24) |',
      '| `/admin/com/preferencias` | `com.consents.ver` | O2 | COM-25 (NFR-04; CTR-UXD-23; antes COM-24); ruta antes `/admin/com/consentimientos` |')

# --- Rutas que coinciden con la del anexo dueño salvo la sintaxis del parámetro opcional ---
d.rep('| SM-PWS-027 | POR-55 (detalle) | `/app/muro/:id` |', '| SM-PWS-027 | POR-55 (detalle) | `/app/muro(/:id)` (ruta del anexo, AL-01; antes `/app/muro/:id`) |')
d.rep('| SM-PWE-011 | COM-43 (antes COM-35, inexistente en T09) | `/app/encuestas` |',
      '| SM-PWE-011 | COM-43 (antes COM-35, inexistente en T09) | `/app/encuestas(/:id)` (ruta del anexo, AL-01; antes `/app/encuestas`) |')
d.rep('| SM-PWE-012 | COM-44 (antes COM-34, que en T09 es el consumo de mensajería) | `/app/novedades` |',
      '| SM-PWE-012 | COM-44 (antes COM-34, que en T09 es el consumo de mensajería) | `/app/novedades(/:id)` (ruta del anexo, AL-01; antes `/app/novedades`) |')

# --- Pantallas de otra app, transversales y citas anteriores: a 10.9.13 ---
pares = []
for l in open(r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo\res_pan_inc.txt', encoding='utf-8'):
    m = re.match(r'- PAN-([A-Z]{3}-\d+) \(ruta del anexo `([^`]*)`\) figura como PAN principal de (SM-[A-Z]{3}-\d+)', l)
    if m:
        pares.append((m.group(1), m.group(3), m.group(2)))
NO_MOVER = {('POR-55', 'SM-PWS-027'), ('COM-43', 'SM-PWE-011'), ('COM-44', 'SM-PWE-012'),
            ('UXD-08', 'SM-PWS-036'), ('UXD-14', 'SM-LND-019'), ('IAM-07', 'SM-PWS-037')}

lines = d.t.split('\n')
ini = next(i for i, l in enumerate(lines) if l.startswith('#### 10.8'))
fin = next(i for i, l in enumerate(lines) if l.startswith('### 10.10') or l.startswith('## 11'))
registro = []
i = ini
while i < fin:
    l = lines[i]
    if l.startswith('|') and lines[i + 1].startswith('|---'):
        hdr = [P.strip_acc(h).lower() for h in P.split_row(l)]
        cols = [k for k, h in enumerate(hdr) if h in ('pan', 'pan principal', 'pan asociadas / nota')]
        j = i + 2
        while j < fin and lines[j].startswith('|'):
            cells = lines[j].split(' | ')
            sid = cells[0].lstrip('| ').strip()
            if sid.startswith('SM-') and cols:
                quitar = [(p, r) for (p, s, r) in pares if s == sid and (p, s) not in NO_MOVER]
                for k in cols:
                    c = cells[k]
                    last = c.endswith(' |')
                    body = c[:-2] if last else c
                    refs = P.pan_refs(body)
                    malos = [x[4:] for x in refs if x not in ids]
                    objetivo = sorted(set([p for p, _ in quitar] + malos), key=len, reverse=True)
                    nuevo = body
                    for tok in objetivo:
                        pat = re.compile(r'(?<![-\w])(?:PAN-)?' + re.escape(tok) + r'(?!\d)')
                        if not pat.search(nuevo):
                            continue
                        orig = body
                        def sub(mm):
                            pre = nuevo[max(0, mm.start() - 60):mm.start()]
                            if re.search(r'antes[^;)]*$', pre):
                                return 'otra pantalla (cita en 10.9.13)'
                            return 'pantalla relacionada (cita en 10.9.13)'
                        nuevo = pat.sub(sub, nuevo)
                        tipo = 'inexistente en el anexo dueño (AL-11)' if tok in malos else (
                            'cita anterior' if re.search(r'antes[^;)]*' + re.escape(tok), orig) else 'otra app o recurso (AL-10)')
                        ruta = next((r for p, r in quitar if p == tok), '')
                        registro.append((sid, 'PAN-' + tok, tipo, ruta, orig))
                    if nuevo != body:
                        if k == cols[0] and hdr[k] in ('pan principal', 'pan') and not P.pan_refs(nuevo):
                            nuevo = '— (sin pantalla propia en esta app; ' + nuevo + ')'
                        cells[k] = nuevo + (' |' if last else '')
                lines[j] = ' | '.join(cells)
            j += 1
        i = j
        continue
    i += 1
d.t = '\n'.join(lines)
d.n += len(registro)

tabla = ['#### 10.9.13 Pantallas relacionadas de otra app, transversales y citas anteriores (AL-10, AL-11)', '',
         'Corrección del cierre de residuales (05-11-2026; PA-UXD-18, Asumida DEC-072). Las columnas de PAN de 10.8 y 10.9 solo citan pantallas de la misma app y recurso que el ítem. '
         'Las pantallas de otra app (AL-10), las pantallas transversales de T02 y las citas anteriores a pantallas que no existen en el anexo dueño (AL-11) se registran acá, con el texto anterior de la celda. '
         'La fila no es un ítem del mapa: el ítem es el de la primera columna.', '',
         '| Ítem del mapa | Pantalla citada | Tipo de cita | Ruta de la pantalla citada | Texto anterior de la celda |', '|---|---|---|---|---|']
vistos = set()
for sid, pan, tipo, ruta, orig in registro:
    if (sid, pan) in vistos:
        continue
    vistos.add((sid, pan))
    tabla.append('| Ítem %s | %s | %s | %s | %s |' % (sid, pan, tipo, ('`%s`' % ruta) if ruta else '—', orig.replace('|', '/')))
tabla.append('')
d.before_line('## 11. API', tabla)
print('mapa: citas movidas', len(vistos))

# --- Cat. 7: CU-ACC-01 de T03 pasa a CU-UXD-07 (dueño de CU-ACC-01: T02) ---
d.rep('| CU-ACC-01 (parte UX) | Ver solo lo que corresponde |',
      '| CU-UXD-07 (parte UX de CU-ACC-01, dueño T02; antes CU-ACC-01 (parte UX)) | Ver solo lo que corresponde |')
d.rep('16 CU-ACC-01 (parte UX)', '16 CU-UXD-07 (antes CU-ACC-01 (parte UX))')

# --- Cat. 2: referencias ---
d.rep('| `draftOf` | ObjectId | No | Entrada publicada a la que reemplaza |',
      '| `draftOf` | ObjectId | No | Entrada publicada a la que reemplaza; → `tenantDictionaryEntries` |')
d.rep('| `publishedAt`, `publishedBy`, `note` | Date, ObjectId, String | Sí | — |',
      '| `publishedAt` | Date | Sí | Fecha de publicación (antes en la fila conjunta `publishedAt`, `publishedBy`, `note`) |\n'
      '| `publishedBy` | ObjectId | Sí | Quien publicó; → `memberships` |\n'
      '| `note` | String | No | Motivo del release |')

# --- Cat. 5: celdas de capability de §11 ---
for api, cap in {
    'API-UXD-02': '`public: true` (antes "Público")',
    'API-UXD-03': '`public: true` para `login`/`landing`; `iam.sesion.autenticada` para el resto (antes "Público para `login`/`landing`; autenticado para el resto")',
    'API-UXD-04': '`public: true` (antes "Público")',
    'API-UXD-20': '`iam.sesion.autenticada` (antes "Autenticado")',
    'API-UXD-26': '`iam.sesion.autenticada` o `public: true` con muestreo (antes "Autenticado o público con muestreo")',
    'API-UXD-30': '`iam.sesion.autenticada` (antes "Autenticado")',
    'API-UXD-32': '`iam.sesion.autenticada` (antes "Autenticado")',
}.items():
    d.cell('| %s |' % api, 3, cap)

# --- Cat. 1: estados ---
d.before_line('`tenantDictionaryEntries.draftOf` referencia la entrada publicada', [
    '### 8.8 Tabla normalizada de estados iniciales (PA-UXD-18)', '',
    'Explicita el estado de alta de las máquinas de §8.2 y §8.3. `dictionaryReleases` no tiene campo de estado: cada release es un documento inmutable y las filas "Release `n` → `n+1`" de §8.3 describen la secuencia de releases.', '',
    '| Colección | Desde | Hasta | Disparador | Guarda (RN) | Evento |', '|---|---|---|---|---|---|',
    '| `brandAssets.status` | — | `processing` | Carga del recurso por `uxd.marca.editar` | Formato y tamaño admitidos | — |',
    '| `brandAssets.status` | `processing` | `ready` | JOB-UXD-01 valida y genera variantes | — | — |',
    '| `brandAssets.status` | `processing` | `rejected` | JOB-UXD-01 rechaza (formato, tamaño, SVG no saneable) | — | — |',
    '| `tenantDictionaryEntries.state` | — | `draft` | Edición de una clave por `uxd.diccionario.editar` (antes "(sin entrada)") | Clave existente, no protegida, validaciones correctas | — |',
    '| `tenantDictionaryEntries.state` | `draft` | `published` | Publicación del release por `uxd.diccionario.publicar` | Sin errores bloqueantes | `uxd.dictionary.published` |',
    '| `tenantDictionaryEntries.state` | `published` | `deleted` | Borrador de eliminación por `uxd.diccionario.editar` | — | — |',
    ''])

# --- PA-UXD-18 ---
d.before_line('## 22. Trazabilidad de fuentes', '''### PA-UXD-18 — Cierre de residuales del anexo (mapa del sitio, tabbar, estados, API y CU)

- **Pregunta:** ¿cómo se cierran los residuales del anexo detectados por los entregables (mapa de navegación, catálogo de pantallas, contratos y estados)?
- **Contexto:** el mapa citaba pantallas de otra app o recurso y citas anteriores a PAN inexistentes de T09 (PAN-COM-35 a 39); 7 capabilities y 4 rutas diferían del anexo dueño; el rótulo "Cuentas y servicios" supera los 12 caracteres de RN-UXD-006; SM-PWE-013, 016 y 018 son slots de la tabbar del empleado; 7 filas de §11 citaban "Público" o "Autenticado"; `brandAssets` y `tenantDictionaryEntries` no declaraban el estado de alta; el ID CU-ACC-01 es de T02.
- **Opciones:**
  - A) Dejar en las columnas de PAN solo pantallas de la misma app y recurso y registrar las demás en 10.9.13 con el texto anterior; tomar la capability y la ruta del anexo dueño (AL-01); rótulo corto "Cuentas"; grupo Tabbar para SM-PWE-013, 016 y 018; `public: true` o `iam.sesion.autenticada` (T02 PA-IAM-18) en §11; tabla 8.8 con los estados de alta; tablas de campos en 7.B.13; renumerar el CU propio a CU-UXD-07. **(Recomendada)**.
  - B) Mantener las citas y documentar las diferencias en los entregables.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** mapa de navegación, catálogo de pantallas y contratos OpenAPI de T03.
- **Estado:** Asumida (DEC-072): opción A.
'''.split('\n'))
print('T03 cambios', d.save())
