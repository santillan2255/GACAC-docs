import json, io, sys, re, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
W = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion"
t05 = open(os.path.join(W, "anexos", "T05-DAT-modelo-datos.md"), encoding="utf-8").read().split("\n")
sug = [l.split("|") for l in open(os.path.join(W, "_trabajo", "res_t05_sug.txt"), encoding="utf-8").read().splitlines()]
d = {(r["id"], r["field"]): r for r in json.load(open(os.path.join(W, "_trabajo", "res_t05_solo.json"), encoding="utf-8"))}
files = {f[:3]: f for f in os.listdir(os.path.join(W, "anexos")) if re.match(r"[MT]\d\d-", f)}
cache = {}
only = sys.argv[1:] 
for owner, cid, col, field, cand, parsed in sug:
    if only and owner not in only:
        continue
    if not cand:
        continue
    r = d[(cid, field)]
    row = t05[r["line"] - 1].split("|")
    print("== %s %s %s: T05 `%s` vs anexo `%s`" % (owner, cid, col, field, cand))
    print("   T05 refs: %s || únicos: %s" % (row[5].strip()[:300], row[6].strip()[:200]))
    if owner not in cache:
        cache[owner] = open(os.path.join(W, "anexos", files[owner]), encoding="utf-8").read().split("\n")
    L = cache[owner]
    a = r["anchor"] or 1
    for c in cand.split(","):
        hits = [i for i in range(max(0, a - 3), min(len(L), a + 80)) if "`%s" % c in L[i] or "| %s " % c in L[i]]
        for i in hits[:2]:
            print("   A%d: %s" % (i + 1, L[i].strip()[:260]))
