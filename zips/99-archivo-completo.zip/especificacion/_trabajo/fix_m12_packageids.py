import os
os.chdir(os.path.join(os.path.dirname(__file__), '..', 'anexos'))
p = 'M12-CMP-compras-proveedores.md'
b = open(p, 'rb').read(); bom = b.startswith(b'\xef\xbb\xbf'); t = b.decode('utf-8-sig')
o1 = "| `servicePlans` (M02) (paquetes de señales del servicio de TV; antes `[VERIFICAR]`; PA-CMP-16) |"
n1 = "| `serviceProducts` (M02, COL-CAT-05) (paquetes de señales del servicio de TV; antes `servicePlans` (M02), antes `[VERIFICAR]`; PA-CMP-16) |"
o2 = "`packageIds` → `servicePlans` (M02) debe confirmarlo M02;"
n2 = "`packageIds` → `serviceProducts` (M02, COL-CAT-05; antes `servicePlans`, confirmado por M02 PA-CAT-23 el 5-11-2026);"
assert t.count(o1) == 1 and t.count(o2) == 1
t = t.replace(o1, n1).replace(o2, n2)
open(p, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + t.encode('utf-8'))
q = '../_trabajo/residuales-sincronizacion.md'
b = open(q, 'rb').read(); bom2 = b.startswith(b'\xef\xbb\xbf'); s = b.decode('utf-8-sig')
nl2 = '\r\n' if '\r\n' in s else '\n'
s = s.rstrip() + nl2 + "- T05: `signalRightsContracts.packageIds` → `serviceProducts` (antes `servicePlans`) en §7.2.1 y COL-CMP-22 (M02 PA-CAT-23); quitar de §21 la nota de pendientes de M13/T10 (cerrados)." + nl2
open(q, 'wb').write((b'\xef\xbb\xbf' if bom2 else b'') + s.encode('utf-8'))
print('ok', bom)
