﻿import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from res_lib_m12m19 import Doc

d = Doc('M15-CON-contabilidad.md')
PA = 'PA-CON-19'

# Cat 6: eventos de M17 consumidos (M17 PA-INS-13)
ren = [
    ('ins.capital.movement.recorded', 'ins.capitalMovement.recorded', 4),
    ('ins.capital.refund.approved', 'ins.capitalRefund.approved', 1),
    ('ins.capital.refund.paid', 'ins.capitalRefund.paid', 1),
    ('ins.capital.transfer.executed', 'ins.capitalTransfer.executed', 1),
    ('ins.capital.movement.reversed', 'ins.capitalMovement.reversed', 1),
    ('ins.surplus.distribution.approved', 'ins.surplusDistribution.approved', 1),
    ('ins.surplus.distribution.executed', 'ins.surplusDistribution.executed', 1),
]
for old, new, n in ren:
    d.rep('| `%s`' % old, '| `%s` (antes `%s`)' % (new, old), count=n, cat=6)

# Cat 2: referencias
d.rep('| `prmId` | String | No | PRM-ID de T04b (ej. `PRM-CON-P4-015`). | — |',
      '| `prmId` | String | No | PRM-ID de T04b (ej. `PRM-CON-P4-015`). | — (código del catálogo de parámetros de T04b, no es referencia a una colección) |', cat=2)
d.rep('| `rubricatedBookId` / `folio` | ObjectId / Int | No | Transcripción. | `rubricatedBooks` (M15) |',
      '| `rubricatedBookId` | ObjectId | No | Transcripción (antes en una fila conjunta con `folio`, ' + PA + '). | `rubricatedBooks` (M15) |\n'
      '| `folio` | Int | No | Folio del libro rubricado donde se transcribió. | — (número, no es referencia) |', cat=2)
d.rep('| `layoutId` | ObjectId | [VERIFICAR] | — | [VERIFICAR] |',
      '| `fileLayoutId` (antes `layoutId`) | ObjectId | [VERIFICAR] | Layout del archivo (nombre canónico de T05 §7.2; ' + PA + '). | `fileLayouts` (T06) |', cat=4)

# Cat 4: nombres y campos clave de T05
d.rep('| `targetAccountId` | ObjectId | Sí | — | `ledgerAccounts` (M15) |',
      '| `ledgerAccountId` (antes `targetAccountId`) | ObjectId | Sí | Cuenta de resultado destino (nombre canónico de T05 §7.2; ' + PA + '). | `ledgerAccounts` (M15) |', cat=4)
d.rep('| `code`, `name`, `description` | String | Sí | — | — |\n| `usage` | enum `manual`',
      '| `chartId` | ObjectId | Sí | Plan de cuentas de las líneas (clave de T05 COL-CON; ' + PA + '). | `chartOfAccounts` (M15) |\n'
      '| `code`, `name`, `description` | String | Sí | — | — |\n| `usage` | enum `manual`', cat=4)
d.rep('| `batchNumber` | Int | Sí | — | — |',
      '| `number` (antes `batchNumber`) | Int | Sí | Único por tenant (T05; ' + PA + '). | — |', cat=4)
d.rep('| `periodFrom` / `periodTo` | Date | Sí | — | — |\n| `scope` | enum `real`\\|`scenario` | Sí | — | — |',
      '| `number` | Int | Sí | Número de corrida, único por tenant (T05; ' + PA + '). | — |\n'
      '| `distributionModelId` | ObjectId | No | Modelo de distribución principal de la corrida (T05; las reglas pueden usar otros en `rules[].modelId`). | `distributionModels` (M15) |\n'
      '| `periodFrom` / `periodTo` | Date | Sí | — | — |\n| `scope` | enum `real`\\|`scenario` | Sí | — | — |', cat=4)
d.rep('| `targetChartId` | ObjectId | [VERIFICAR] | — | `chartOfAccounts` (M15) |\n| `sourceLineId`',
      '| `chartId` (antes `targetChartId`) | ObjectId | [VERIFICAR] | Plan alternativo o regulatorio (nombre canónico de T05; ' + PA + '). | `chartOfAccounts` (M15) |\n| `sourceLineId`', cat=4)
d.rep('| `seriesId` | ObjectId | [VERIFICAR] | — | `inflationIndexSeries` (M15) |',
      '| `seriesId` | ObjectId | [VERIFICAR] | Serie configurada en PRM-CON-036. | `economicIndexSeries` (T04) (antes `inflationIndexSeries` (M15), reemplazada en §7.29; ' + PA + ') |\n'
      '| `version` | Int | Sí | Versión de la corrida del ejercicio; `{fiscalYearId, version}` único (T05; ' + PA + '). | — |', cat=4)
d.rep('| `kind` | enum `memberReceivables`',
      '| `fiscalYearId` | ObjectId | Sí | Ejercicio conciliado (clave de T05; ' + PA + '). | `fiscalYears` (M15) |\n| `kind` | enum `memberReceivables`', cat=4)
d.rep('| `linesPerSheet` | Int | Sí | `GuardarLineas`. | — |',
      '| `linesPerSheet` | Int | Sí | `GuardarLineas`. | — |\n'
      '| `fiscalYearId` | ObjectId | Sí | Ejercicio del libro; `{bookType, fiscalYearId, volume}` único (T05; ' + PA + '). | `fiscalYears` (M15) |\n'
      '| `volume` | Int | Sí | Número de tomo. | — |\n'
      '| `storedFileId` | ObjectId | No | Archivo del libro digital o del escaneo de la rúbrica. | `storedFiles` (T01) |', cat=4)

# Cat 1: estados
d.rep('### 8.2 Plan de cuentas (`chartOfAccounts.status`)\n\n',
      '### 8.2 Plan de cuentas (`chartOfAccounts.status`)\n\nEstado inicial: `draft` (alta → `draft`; ' + PA + ').\n\n', cat=1)
d.rep('### 8.4 Ejercicio (`fiscalYears.status`)\n\n',
      '### 8.4 Ejercicio (`fiscalYears.status`)\n\nEstado inicial: `planned` (alta → `planned`; ' + PA + ').\n\n', cat=1)
d.rep('### 8.5 Lote de contabilización (`postingBatches.status`)\n\n',
      '### 8.5 Lote de contabilización (`postingBatches.status`)\n\nEstado inicial: `preparing` (alta → `preparing`; ' + PA + ').\n\n', cat=1)
d.rep('### 8.6 Período (`accountingPeriods.status`)\n\n',
      '### 8.6 Período (`accountingPeriods.status`)\n\nEstado inicial: `open` (alta → `open`, al abrir el ejercicio; ' + PA + ').\n\n', cat=1)
d.rep('Distribución: `draft` → `final` → `superseded` (nueva corrida del mismo período). Ajuste por inflación: `preview` → `posted` → `reversed`. Estados contables: `draft` →',
      'Distribución (`costDistributionRuns.status`): `draft` → `final` → `superseded` (nueva corrida del mismo período). Ajuste por inflación (`inflationAdjustmentRuns.status`): `preview` → `posted` → `reversed`. Estados contables (`financialStatementRuns.status`): `draft` →', cat=1)
d.rep('Presupuesto: `draft` → `submitted`', 'Estado inicial de `budgets.status`: `draft` (alta → `draft`; ' + PA + ').\n\nPresupuesto (`budgets.status`): `draft` → `submitted`', cat=1)
d.rep('Compromiso: `open` → `partiallyAccrued`', 'Compromiso (`commitments.status`): `open` → `partiallyAccrued`', cat=1)
d.rep('### 8.10 Conciliación\n\n`running` →',
      '### 8.10 Conciliación (`reconciliationRuns.status`)\n\nEstado inicial: `running` (alta → `running`; ' + PA + ').\n\n`running` →', cat=1)
d.rep('| `inactive` | `active` | Reactivación | — | — |\n\n## 9. Procesos y flujos',
      '| `inactive` | `active` | Reactivación | — | — |\n\n'
      '#### 8.11.9 Renglón de asiento (`journalLines.entryStatus`)\n\n'
      'Copia desnormalizada de `journalEntries.status` (§8.1): el worker la actualiza en todos los renglones cuando cambia el estado del asiento; no hay comando propio sobre el renglón (' + PA + '). Estado inicial: `draft`.\n\n'
      '| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |\n'
      '|---|---|---|---|---|\n'
      '| (alta) | `draft` | Alta del renglón con el asiento | — | — |\n'
      '| `draft` | `pendingApproval` | El asiento pasa a aprobación (§8.1) | — | — |\n'
      '| `draft`, `pendingApproval` | `posted` | Contabilización del asiento (§8.1) | RN-CON-001 | EVT-CON-01 `con.entry.posted` |\n'
      '| `posted` | `voided` | Anulación del asiento (§8.1) | RN-CON-013 | EVT-CON-03 `con.entry.voided` |\n'
      '| `posted` | `reversed` | Contraasiento del asiento (§8.1) | — | EVT-CON-02 `con.entry.reversed` |\n\n'
      '## 9. Procesos y flujos', cat=1)

d.insert_before('## 22. Trazabilidad', '''### PA-CON-19 — Residuales del 05-11-2026 (estados, referencias, nombres de campo y eventos de M17)

- **Pregunta**: ¿Cómo se cierran los residuales de M15 que detectaron los entregables regenerados?
- **Contexto**: el índice de estados marcó sin estado inicial a `chartOfAccounts`, `fiscalYears`, `postingBatches`, `accountingPeriods`, `budgets` y `reconciliationRuns`, mezcló en `costDistributionRuns` los valores del §8.7 de otras dos colecciones y dejó `journalLines.entryStatus` sin transiciones; T05 nombra `ledgerAccountId`, `number`, `chartId`, `fileLayoutId` y otros campos clave que este §7 no tenía o llamaba distinto; M17 renombró sus eventos de capital y excedentes a camelCase (PA-INS-13).
- **Opciones**: A) **(Recomendada)** Declarar el estado inicial de cada máquina; calificar con su colección cada frase del §8.7 y §8.9; tabla de `journalLines.entryStatus` como copia de §8.1; adoptar los nombres de T05 con "antes"; `seriesId` → `economicIndexSeries` (T04); consumir los eventos de M17 con el nombre nuevo (el viejo queda como alias). B) Mantener el texto y resolver en los entregables.
- **Estado**: Asumida la recomendada (DEC-072). Los campos nuevos de `rubricatedBooks` (`fiscalYearId`, `volume`, `storedFileId`) y de `costDistributionRuns` (`number`, `distributionModelId`) siguen a T05; `volume` y la semántica de `distributionModelId` deben validarse con el contador piloto.
- **Impacto si no se responde**: A. **Bloquea**: §7.10, §7.11, §7.14, §7.20, §7.24, §7.31 a §7.33, §7.37, §8, §9.1 (M-105 a M-114).

''', cat=0)
d.save()
