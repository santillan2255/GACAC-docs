import sys, io, glob, os, re, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos"
PRE = "per|cat|med|tar|fac|fis|cob|mor|crm|tec|ven|cmp|stk|tes|con|sue|ins|soc|por|pla|iam|uxd|cfg|dat|int|mig|nfr|com|bia|wfl|srv"
PAT = re.compile(r"(?<![\w./-])(?:%s)\.[A-Za-z][\w-]*\.[A-Za-z][\w-]*(?:\.[A-Za-z][\w-]*)?(?![\w-])" % PRE)
MINE = ["M%02d-*" % i for i in range(1, 20)] + ["T01-*", "T04-*", "T06-*", "T07-*", "T08-*", "T09-*", "T10-*", "T12-*"]
files = []
for p in MINE:
    files += sorted(glob.glob(os.path.join(ROOT, p + ".md")))
cnt = collections.Counter()
where = collections.defaultdict(collections.Counter)
for f in files:
    t = open(f, encoding="utf-8-sig").read()
    for m in PAT.finditer(t):
        s = m.group(0)
        if "-" in s or s.count(".") == 3:
            cnt[s] += 1
            where[s][os.path.basename(f)[:3]] += 1
for s, c in sorted(cnt.items()):
    print(s, c, dict(where[s]))
