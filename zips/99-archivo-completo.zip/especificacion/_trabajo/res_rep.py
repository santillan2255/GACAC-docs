"""Uso: python res_rep.py <PREFIJO_ANEXO> <archivo_pares>
Pares: bloques
<<<
texto viejo (una o más líneas)
>>>
texto nuevo
===
Opcional: primera línea del bloque viejo '#n=K' para K ocurrencias esperadas."""
import sys, io, glob
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
F = glob.glob(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\%s-*" % sys.argv[1])[0]
raw = open(F, "rb").read()
bom = raw.startswith(b"\xef\xbb\xbf")
t = raw[3:].decode("utf-8") if bom else raw.decode("utf-8")
crlf = "\r\n" in t
if crlf:
    t = t.replace("\r\n", "\n")
spec = open(sys.argv[2], encoding="utf-8").read().replace("\r\n", "\n")
ok = 0
for blk in spec.split("\n===\n"):
    if not blk.strip():
        continue
    assert blk.startswith("<<<\n"), blk[:60]
    old, new = blk[4:].split("\n>>>\n")
    new = new.rstrip("\n") if new.endswith("\n") and not old.endswith("\n") else new
    k = 1
    if old.startswith("#n="):
        first, old = old.split("\n", 1)
        k = int(first[3:])
    c = t.count(old)
    if c != k:
        print("FALLA (%d en vez de %d): %s" % (c, k, old[:120]))
        sys.exit(1)
    t = t.replace(old, new)
    ok += 1
if crlf:
    t = t.replace("\n", "\r\n")
open(F, "wb").write((b"\xef\xbb\xbf" if bom else b"") + t.encode("utf-8"))
print("%s: %d reemplazos aplicados" % (F.split("\\")[-1], ok))
