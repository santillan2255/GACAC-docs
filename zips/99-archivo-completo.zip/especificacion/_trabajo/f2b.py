﻿import re,glob
need={'M11':[16,18],'M14':[58,59,64],'M16':[58,64,78],'T01':[20,21,25,26,62,63,64,65,74,75,76,77],'T02':[43,66,67],'T04':[46,64],'T08':[74,75,76,80]}
pa={16:'PA-VEN-08',18:'PA-CFG-P2-06',20:'PA-CFG-P1-03',21:'PA-CAT-02',25:'PA-CAT-07',26:'PA-CAT-08',43:'PA-PER-01',46:'PA-PER-13',58:'PA-SUE-01',59:'PA-TES-16',62:'PA-PLA-01',63:'PA-PLA-02',64:'PA-PLA-14',65:'PA-PLA-08',66:'PA-IAM-01',67:'PA-IAM-02',74:'PA-INT-02',75:'PA-NFR-03',76:'PA-NFR-07',77:'PA-COM-04',78:'PA-WFL-06',80:'PA-WFL-05'}
for m,ds in need.items():
    f=glob.glob(f'anexos/{m}-*.md')
    s=''.join(open(x,encoding='utf-8').read() for x in f)
    print(m,[ (d, s.count(f'DEC-{d:03d}'), s.count(pa[d])) for d in ds])
fb=glob.glob('anexos/T04b-*.md'); s=''.join(open(x,encoding='utf-8').read() for x in fb); print('T04b DEC-064',s.count('DEC-064'), 'legalEnt', s.count('legalEntit'))
L=open('01-registro-decisiones.md',encoding='utf-8').read().split('\n')
for l in L:
    m=re.match(r'\| DEC-0(16|18|20|21|25|26|43|46|58|59|62|63|64|65|66|67|74|75|76|77|80|82|83|84|85|86|87) \|',l)
    if m: print(l[:700])
