import re
from res_m0106_lib import Doc

d = Doc('M05')

# --- Categoría 1: valores de estado de §7 en un solo bloque de código (`a, b, c`) se separan en valores ---
ls = d.t.split('\n')
a, b = d.section(7)
k = 0
for i in range(a, b):
    l = ls[i]
    if l.startswith('| `status` |') or l.startswith('| `commercialStatus` |'):
        nl = re.sub(r'`([A-Za-z]+(?:, [A-Za-z]+)+)`',
                    lambda m: ', '.join('`%s`' % v for v in m.group(1).split(', ')), l)
        if nl != l:
            ls[i] = nl
            k += 1
d.t = '\n'.join(ls)
d.count('1', k)

TAB = '''
### 8.13 Estados iniciales y transiciones completadas (residuales del 05-11-2026)

Ronda de residuales del 05-11-2026 (PA-FAC-23, DEC-072): estado de alta explícito de las máquinas de §8.1 a §8.11 que lo daban por implícito, y transiciones de las colecciones de §7 que solo enumeraban estados (`billingUniverses`, `billingTemplates`, `billedPeriods`, `invoiceDrafts`, `numberSequences`, `massOperationItems`, `paymentSlips`). Los valores de §7 se escriben ahora uno por uno (antes en un solo bloque, p. ej. «`draft, published, inactive`»), lo que también declara `pending`, `billed` y `cancelled` de `billableItems` usados en §8.12. Las cadenas de §8.1 a §8.11 no cambian.

| Entidad | Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |
|---|---|---|---|---|---|
| `billingCycles` | — | `draft` | Alta del ciclo | — | — |
| `billingUniverses` | — | `draft` | Alta del universo | — | — |
| `billingUniverses` | `draft` | `published` | Publicación por el responsable | Criterio o lista válidos | — |
| `billingUniverses` | `published` | `inactive` | Desactivación | Sin ciclos publicados que lo usen | — |
| `billingUniverses` | `inactive` | `published` | Reactivación con nueva vigencia | — | — |
| `billingTemplates` | — | `draft` | Alta o nueva versión de la plantilla | — | — |
| `billingTemplates` | `draft` | `published` | Publicación (§8.1) | Expresiones de fecha y servicios válidos | — |
| `billingTemplates` | `published` | `retired` | Publicación de una versión nueva | — | — |
| `billingRuns` | — | `draft` | Alta por el responsable o JOB-FAC-17 (§8.2) | Ciclo y plantilla publicados | — |
| `billingExceptions` | — | `open` | Validación bloqueante o rechazo durante el lote | — | `fac.billingException.opened` |
| `invoices.commercialStatus` | — | `issued` | Emisión (antes «(borrador)» en §8.5: el borrador vive en `invoiceDrafts`) | Validaciones y numeración | `fac.invoice.issued` |
| `invoiceAnnulmentRequests` | — | `draft` | Alta de la solicitud | — | — |
| `billingGroups` | — | `draft` | Alta del grupo | — | — |
| `massOperations` | — | `draft` | Alta de la operación | — | — |
| `billingImports` | — | `uploaded` | Carga del archivo | — | — |
| `distributionRuns` | — | `draft` | Alta de la corrida de distribución | — | — |
| `invoiceDeliveries` | — | `pending` | Comprobante incluido en una corrida de distribución | — | — |
| `billedPeriods` | — | `active` | Emisión del comprobante del período | Índice único parcial por contrato, servicio y período | `fac.invoice.issued` |
| `billedPeriods` | `active` | `released` | NC total o anulación (`releasedByInvoiceId`) | — | `fac.invoice.reversed` / `fac.invoice.annulled` |
| `invoiceDrafts` | — | `editing` | Alta de factura manual, réplica o refacturación | — | — |
| `invoiceDrafts` | `editing` | `validated` | Validación previa a la emisión | — | — |
| `invoiceDrafts` | `validated` | `editing` | Modificación después de validar | — | — |
| `invoiceDrafts` | `validated` | `issued` | Emisión del comprobante | Numeración disponible | `fac.invoice.issued` |
| `invoiceDrafts` | `editing`/`validated` | `discarded` | Descarte por el operador | — | — |
| `numberSequences` | — | `active` | Alta del talonario | — | — |
| `numberSequences` | `active` | `blocked` | Bloqueo (CAI vencido, punto de venta suspendido o inconsistencia de numeración) | — | — |
| `numberSequences` | `blocked` | `active` | Regularización | Numeración conciliada | — |
| `massOperationItems` | — | `proposed` | Vista previa de la operación masiva | — | — |
| `massOperationItems` | `proposed` | `applied`/`skipped`/`failed` | Aplicación de la operación (§8.8) | — | — |
| `paymentSlips` | — | `active` | Emisión del talón o cupón | — | — |
| `paymentSlips` | `active` | `superseded` | Reemplazo por un talón nuevo (`supersededById`) | — | — |
| `paymentSlips` | `active` | `cancelled` | Anulación de los comprobantes que agrupa | — | — |
| `paymentSlips` | `active` | `paid` | Cobro informado por M07 | — | — |
'''
d.insert_before('\n## 9. ', TAB, '1')

d.rep("cada transición crea `invoiceBlockHistory`. Precondición:",
      "cada transición crea `invoiceBlockHistory` (colección absorbida: hoy `documentHolds` de M08, COL-FAC-16 → COL-MOR-12; la máquina de estados es la de M08). Precondición:", '1')

# --- Categoría 2: referencias ---
d.rep("| `targetAccounts` | Array ObjectId | No | Ex `FACTMES_CTAS`. Referencia: `accounts` (M01). |",
      "| `targetAccounts` | Array ObjectId | No | Ex `FACTMES_CTAS`. Referencia: → `accounts` (M01). |", '2')
d.rep("| `templateId` / `templateVersion` | ObjectId / Int | Sí | Congelados. |",
      "| `templateId` / `templateVersion` | ObjectId / Int | Sí | Congelados. Referencia: `templateId` → `billingTemplates` (M05); `templateVersion` es número de versión, no es referencia. |", '2')
d.rep("| `billingGroupId` / `groupVersion` | ObjectId / Int | No | — |",
      "| `billingGroupId` / `groupVersion` | ObjectId / Int | No | Referencia: `billingGroupId` → `billingGroups` (M05); `groupVersion` es número de versión, no es referencia. |", '2')
d.rep("| `ownerRole` / `assigneeId` | String / ObjectId | Sí / No | Responsable. Referencia: `roles` (T02) [VERIFICAR]. |",
      "| `ownerRole` / `assigneeId` | String / ObjectId | Sí / No | Responsable. Referencia: `ownerRole` → `roles` (T02), por clave del rol; `assigneeId` → `memberships` (T02). Confirmado en PA-FAC-23 (DEC-072; antes «`roles` (T02) [VERIFICAR]»). |", '2')
d.rep("| `serviceBlockId` | ObjectId | [VERIFICAR] | — | subdocumento `invoices.serviceBlocks` (M05) |",
      "| `serviceBlockId` | ObjectId | Sí | Bloque del servicio facturado (PA-FAC-23; antes [VERIFICAR]) | → `invoices.serviceBlocks` (subdocumento, M05) |", '2')
d.rep("| `affectedServiceBlockIds[]` | ObjectId[] | [VERIFICAR] | — | subdocumento `invoices.serviceBlocks` (M05) |",
      "| `affectedServiceBlockIds[]` | ObjectId[] | No | Vacío = todos los bloques (PA-FAC-23; antes [VERIFICAR]) | → `invoices.serviceBlocks` (subdocumento, M05) |", '2')
d.rep("| `sharesNumberingWithId` | ObjectId | No | Ex `RELACION`. Referencia: `voucherTypes` (M05). |",
      "| `sharesNumberingWithId` | ObjectId | No | Ex `RELACION`. Referencia: → `voucherTypes` (M05). |", '2')
d.rep("| `pointOfSaleId` / `numberingMode` | ObjectId / Enum `general, own` | No / Sí | Talonario propio o general. |",
      "| `pointOfSaleId` / `numberingMode` | ObjectId / Enum `general, own` | No / Sí | Talonario propio o general. Referencia: `pointOfSaleId` → `pointsOfSale` (M05); `numberingMode` no es referencia. |", '2')
d.rep("| `voucherTypeOverrideId` | ObjectId | No | Ex `GRUPOS_FACTURA.COD_TPFC`. Referencia: `voucherTypes` (M05). |",
      "| `voucherTypeOverrideId` | ObjectId | No | Ex `GRUPOS_FACTURA.COD_TPFC`. Referencia: → `voucherTypes` (M05). |", '2')
d.rep("| `groupVersion` | Int | Sí | — |",
      "| `groupVersion` | Int | Sí | Número de versión; no es referencia. |", '2')
d.rep("| `templateVersion` | int | Sí | — | — |",
      "| `templateVersion` | int | Sí | Número de versión; no es referencia. | — |", '2', cnt=2)
d.rep("| `fallbackFormatId` | ObjectId | No | Formato extendido ante desborde. |",
      "| `fallbackFormatId` | ObjectId | No | Formato extendido ante desborde. Referencia: → `barcodeFormats` (M05). |", '2')
d.rep("| `closureVersion` / `previousClosureId` | Int / ObjectId | Sí / No | Reapertura. |",
      "| `closureVersion` / `previousClosureId` | Int / ObjectId | Sí / No | Reapertura. Referencia: `previousClosureId` → `billingCycleClosures` (M05); `closureVersion` no es referencia. |", '2')

d.anchor_field_tables('3')

# --- Categoría 5: API reemplazada cita la API destino por ID ---
d.rep("Causas de bloqueo. **Reemplazado por** `holdReasons` de M08 (CTR-DAT-36).",
      "Causas de bloqueo. **Reemplazado por** API-MOR-25 (`/api/admin/mor/hold-reasons[/:id]`, `mor.causas.configurar`) sobre `holdReasons` de M08 (CTR-DAT-36).", '5')

PA = '''
### PA-FAC-23 — Residuales de estados, referencias y API reemplazada (ronda del 05-11-2026)
- **Pregunta:** ¿Se confirman los estados de alta y las transiciones agregadas en §8.13, los destinos y la obligatoriedad de las referencias marcadas y la API destino de API-FAC-023?
- **Contexto:** al regenerar los entregables, 06a §7 marcó 11 máquinas de M05 sin estado inicial, 6 colecciones con `status` sin valores legibles (escritos en un solo bloque), `paymentSlips` sin transiciones y `billableItems` con valores de §8.12 no declarados; 03-er marcó referencias sin destino; API-FAC-023 decía «Reemplazado» sin API destino.
- **Opciones:**
  - A) **(Recomendada)** Escribir los valores de §7 uno por uno; declarar en §8.13 los estados de alta y las transiciones; `ownerRole` → `roles` y `assigneeId` → `memberships` (T02); `serviceBlockId` obligatorio y `affectedServiceBlockIds` opcional (vacío = todos); los números de versión no son referencias; API-FAC-023 reemplazada por API-MOR-25.
  - B) Mantener API-FAC-023 como fachada de M08 con capability propia.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** 06 (estados), 03 (ER), 05 (contratos de API), T02 (capability `fac.bloqueosCausas.configurar`).
- **Estado:** Asumida (DEC-072): opción A. Aplicado en §7, §8.7, §8.13 y §11. T02 debe marcar `fac.bloqueosCausas.configurar` como reemplazada por `mor.causas.configurar` (API-MOR-25).
'''
d.insert_before('\n## 22. ', PA, 'PA')
d.save()
