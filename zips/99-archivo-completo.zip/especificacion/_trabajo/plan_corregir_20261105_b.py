"""Segunda parte de las correcciones del 05-11-2026: §1, §16, §17, §18, §21.5 y encabezado del plan."""
import os, re, json

ESPEC = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
PLAN = os.path.join(ESPEC, '03-plan-de-olas-y-prompts.md')
raw = open(PLAN, 'rb').read()
bom = raw.startswith(b'\xef\xbb\xbf')
T = raw.decode('utf-8-sig')
NOTA = 'corrección 05-11-2026'
d = json.load(open(os.path.join(ESPEC, '_trabajo', 'plan_recuento.json'), encoding='utf-8'))
OL = ['O%d' % i for i in range(12)]
rf = {o: d['ola'][o]['rf'] for o in OL}
rnf = {o: d['ola'][o]['rnf'] for o in OL}
pr = {o: d['ola'][o]['prompts'] for o in OL}
assert sum(rf.values()) == 4203 and sum(rnf.values()) == 292 and sum(pr.values()) == 172


def rep(old, new, count=1):
    global T
    n = T.count(old)
    assert n == count, (n, old[:140])
    T = T.replace(old, new)


def mil(n):
    return '{:,}'.format(n).replace(',', '.')


# ---------------------------------------------------------------- encabezado
rep('incorpora los 83 RF nuevos de las fases 1 a 3 de huecos, DEC-082 a DEC-087 y los cambios de ola de los anexos; ver §21) |',
    'incorpora los 83 RF nuevos de las fases 1 a 3 de huecos, DEC-082 a DEC-087 y los cambios de ola de los anexos; ver §21). Corregida el 05-11-2026 con las inconsistencias detectadas por los entregables de análisis y diseño (ver §21.5) |')

# ---------------------------------------------------------------- §1
rep('| Pago online imputado, rendido y asentado | O4 | 14 | 468 | 13 |',
    '| Pago online imputado, rendido y asentado | O4 | 14 | %d | %d |' % (rf['O5'], rnf['O5']))
rep('| Corte comercial y luego corte administrativo de ProCoop en una cooperativa | O0–O10 | 10 | 90 | 7 |',
    '| Corte comercial y luego corte administrativo de ProCoop en una cooperativa | O0–O10 | 10 | %d | %d |' % (rf['O11'], rnf['O11']))
rep('*Reemplazado (versión 1.0): RF por ola O0 299, O1 457, O2 607, O3 315, O4 419, O5 463, O6 241, O7 256, O8 454, O9 161, O10 360, O11 88; total 4.120. Los 83 RF nuevos y los cambios de ola están en §21.*',
    '*Reemplazado (versión 1.0): RF por ola O0 299, O1 457, O2 607, O3 315, O4 419, O5 463, O6 241, O7 256, O8 454, O9 161, O10 360, O11 88; total 4.120. Los 83 RF nuevos y los cambios de ola están en §21.*\r\n\r\n'
    '*Reemplazado (%s): O5 468 y O11 90 RF. RF-CON-160 (celda del anexo `O11 (O5 para saldos de apertura)`) empieza en O5 por la regla §0.1 y queda como extensión en O11. Las demás olas no cambian. Recuento por script (`_trabajo/plan_recuento.py`) leyendo las tablas de RF y RNF de los anexos y la línea `IMPLEMENTAR` de cada prompt (las líneas `EXTENSIONES` no cuentan): %s RF y %d RNF, cada uno en exactamente un prompt. Ver §21.5.*' % (NOTA, mil(sum(rf.values())), sum(rnf.values())))

# ---------------------------------------------------------------- §16
rep('| M15 CON | — | — | — | 1 | — | 84 | 1 | — | 64 | 3 | 7 | 2 | 162 |',
    '| M15 CON | — | — | — | 1 | — | 85 | 1 | — | 64 | 3 | 7 | 1 | 162 |')
rep('| **Total RF** | **305** | **458** | **613** | **319** | **424** | **468** | **244** | **274** | **462** | **163** | **383** | **90** | **4.203** |',
    '| **Total RF** | ' + ' | '.join('**%s**' % mil(rf[o]) for o in OL) + ' | **%s** |' % mil(sum(rf.values())))
rep('*Reemplazado (versión 1.0): fila Total RF 299, 457, 607, 315, 419, 463, 241, 256, 454, 161, 360, 88; total 4.120.* La matriz de v1.1 se recalculó por script leyendo las tablas de RF de los anexos y las líneas IMPLEMENTAR de este plan.',
    '*Reemplazado (versión 1.0): fila Total RF 299, 457, 607, 315, 419, 463, 241, 256, 454, 161, 360, 88; total 4.120.* La matriz de v1.1 se recalculó por script leyendo las tablas de RF de los anexos y las líneas IMPLEMENTAR de este plan. '
    '*Reemplazado (%s): M15 CON O5 84 y O11 2; Total RF O5 468 y O11 90 (RF-CON-160 pasa a O5, §18).* Recalculada con `_trabajo/plan_recuento.py`; las filas RNF y Prompts no cambian.' % NOTA)

# ---------------------------------------------------------------- §17
rep('| M15 CON | 162 | 162 | 0 | 2 (RF-CON-150, 151; el anexo ya los pone en O5). RF-CON-025 y 075 dejan de estar reasignados en v1.1 (vuelven a O10 como dice el anexo) |',
    '| M15 CON | 162 | 162 | 0 | 3 (RF-CON-150, 151; el anexo ya los pone en O5; RF-CON-160 a O5 por la regla §0.1, %s). RF-CON-025 y 075 dejan de estar reasignados en v1.1 (vuelven a O10 como dice el anexo) |' % NOTA)
rep('| **Total** | **4.203** | **4.203** | **0** | **15** |',
    '| **Total** | **4.203** | **4.203** | **0** | **16** (*reemplazado, %s:* antes 15) |' % NOTA)
rep('Un RNF reasignado: RNF-NFR-100 no tenía ola y va a O2 (§18).',
    'Un RNF reasignado: RNF-NFR-100 no tenía ola y va a O2 (§18). Recuento del 05-11-2026 por script: los 292 RNF tienen ola en su anexo y cada uno está en la línea `IMPLEMENTAR` de un solo prompt de esa ola (la cita de RNF-NFR-016 en PRO-O11-07 es extensión y pasó a la línea `EXTENSIONES`).')
rep('Si un anexo agrega RF después de este plan, el script los informa como faltantes y se asignan con PRO-GEN-03 en la ola correspondiente.',
    'Si un anexo agrega RF después de este plan, el script los informa como faltantes y se asignan con PRO-GEN-03 en la ola correspondiente. Mientras no exista `trace:check`, el mismo control se hace con `docs/especificacion/_trabajo/plan_recuento.py` (solo lectura): recuento por ola, por prompt y por anexo, faltantes, duplicados, IDs inexistentes, RF sin ola válida y RF cuyo prompt no está en la primera ola de la celda del anexo.')

# ---------------------------------------------------------------- §18
rep('| RF-CON-151 | O10 | O5 | PRO-O5-12 | Ídem |\r\n',
    '| RF-CON-151 | O10 | O5 | PRO-O5-12 | Ídem |\r\n'
    '| RF-CON-160 | `O11 (O5 para saldos de apertura)` | O5 (+O11) | PRO-O5-11 | *Nuevo (%s).* Regla §0.1: la celda lista dos olas y el RF empieza en la más temprana (saldos de apertura contables en O5, que se necesitan junto con los saldos y cuentas corrientes migrados en PRO-O5-07); la migración repetible completa es extensión en PRO-O11-06. *Reemplazado:* antes se contaba en PRO-O11-06 y O5 lo tenía como extensión |\r\n' % NOTA)
rep('Además, sin ser RF, se agrega un requisito explícito:',
    '**Aclaraciones del 05-11-2026 (sin reasignación).** Los entregables de análisis y diseño (`23-estimacion-esfuerzo.md` §7 y `20-casos-prueba.md` §7) informaron 8 RF "sin ola" y 6 "con ola distinta". Verificación contra los anexos vigentes:\r\n\r\n'
    '| ID | Celda de ola en el anexo | Prompt | Situación |\r\n'
    '|---|---|---|---|\r\n'
    '| RF-CAT-010, RF-COM-180, RF-CRM-254, RF-MIG-060, RF-VEN-106 | Sin ola válida | Ver la tabla anterior | Ya reasignados en esta sección |\r\n'
    '| RF-TEC-062 | O3 | PRO-O3-05 | La ola es válida. La celda de requisito contiene `<antes\\|luego>` con la barra vertical sin escapar dentro de código, y un lector automático corre las columnas (lee "Núcleo" como ola). Lo corrige el dueño de M10 (escapar `\\|`) |\r\n'
    '| RF-TEC-157 | O7 | PRO-O7-08 | La ola es válida. La celda usa `\\|` escapado (correcto en Markdown); el lector de los entregables no reconoce el escape |\r\n'
    '| RF-UXD-026 | O0 | PRO-O0-14 | La ola es válida. La celda contiene `{socio\\|empleado\\|campo}` con barras sin escapar dentro de código. Lo corrige el dueño de T03 |\r\n'
    '| RF-CON-025, RF-CON-075 | O10 | PRO-O10-02 | Coinciden con el anexo. El desvío informado venía de la cita "extensión O5 de …" dentro de `IMPLEMENTAR` de PRO-O5-10 y PRO-O5-11, que un lector automático contaba como primera implementación. Desde el %s las extensiones van en la línea `EXTENSIONES` (§0.6) |\r\n'
    '| RF-CON-160 | `O11 (O5 para saldos de apertura)` | PRO-O5-11 | Reasignado a la ola más temprana de la celda (tabla anterior) |\r\n'
    '| RF-CRM-260 | `O7 (GAS, ELE); O3 resto` | PRO-O3-11 (+PRO-O7-09) | Celda con dos olas por servicio: empieza en O3 (regla §0.1) y la parte GAS y ELE es extensión en O7. Un lector que toma la primera ola escrita (O7) informa desvío; no lo hay |\r\n'
    '| RF-TEC-231 | `O7 (GAS, ELE); O3 para el resto de los servicios con red` | PRO-O3-01 (+PRO-O7-08) | Ídem: empieza en O3; GAS y ELE en O7 |\r\n'
    '| RF-MOR-222 | `O10 (TEL, TV) / O7 (AG, CLO)` | PRO-O7-09 (+PRO-O10-09) | Ídem: empieza en O7; TEL y TV en O10 |\r\n'
    '| RF-UXD-163 | `O9+ (cuando haya bot)` | PRO-O6-09 | Reasignado (tabla anterior): la condición del anexo ("cuando haya bot") se cumple en O6 por DEC-056. El dueño de T03 debería escribir `O6 (DEC-056)` en la celda |\r\n\r\n'
    'Además, sin ser RF, se agrega un requisito explícito:' % NOTA)

# ---------------------------------------------------------------- §21.5
filas = '\r\n'.join('| %s | %d | %s | %d |' % (o, pr[o], mil(rf[o]), rnf[o]) for o in OL)
V10 = '| RF v1.0 (reemplazado) | 299 | 457 | 607 | 315 | 419 | 463 | 241 | 256 | 454 | 161 | 360 | 88 | 4.120 |\r\n'
rep(V10 + '| RNF | 144 | 72 | 15 | 9 | 23 | 13 | 2 | 0 | 1 | 0 | 6 | 7 | 292 |',
    V10 + '| RNF | 144 | 72 | 15 | 9 | 23 | 13 | 2 | 0 | 1 | 0 | 6 | 7 | 292 |\r\n\r\n'
    '*Reemplazado (%s): RF v1.1 O5 468 y O11 90. Valores vigentes en §21.5.*\r\n\r\n'
    '### 21.5 Correcciones del 05-11-2026 (inconsistencias detectadas por los entregables)\r\n\r\n'
    'Insumo: `docs/entregables-analisis-diseno/23-estimacion-esfuerzo.md` §7, `20-casos-prueba.md` §7 y `_trabajo/inconsistencias-especificacion.md`. Recuento con `_trabajo/plan_recuento.py` (lee las tablas de RF y RNF de los anexos y las líneas `IMPLEMENTAR`; no estima). Correcciones aplicadas con `_trabajo/plan_corregir_20261105.py` y `_trabajo/plan_corregir_20261105_b.py`.\r\n\r\n'
    '| Ítem | Inconsistencia | Corrección |\r\n'
    '|---|---|---|\r\n'
    '| a | La columna RF de la tabla de secuencia no coincidía con los RF contados en `IMPLEMENTAR` en PRO-O5-10 (30 frente a 31), PRO-O5-11 (56 frente a 57) y PRO-O10-02 (29 frente a 27) | La causa eran las citas "extensión O5 de RF-CON-025" y "extensión O5 de RF-CON-075" dentro de `IMPLEMENTAR`. En los 24 prompts que tenían extensiones dentro de `IMPLEMENTAR` se pasaron a una línea `EXTENSIONES` (texto conservado; §0.6). PRO-O5-10 queda en 30 y PRO-O10-02 en 29; PRO-O5-11 pasa a 57 por RF-CON-160 (ítem c) |\r\n'
    '| b | Totales por ola que no cerraban: O5 470 y O10 381 contados frente a 468 y 383; RNF de O11 8 frente a 7 | Con las extensiones fuera de `IMPLEMENTAR`, cualquier lector cuenta O10 383 y O11 7 RNF. O5 queda en 469 y O11 en 89 por RF-CON-160. §1, §9.4, §9.10, §15.4, §15.10, §16, §17 y los prompts de integración PRO-O5-14 y PRO-O11-10 actualizados con el valor anterior marcado como reemplazado |\r\n'
    '| c | 8 RF sin ola y 6 con ola distinta de la del anexo | Ver §18 (aclaraciones): 5 ya estaban reasignados; 3 tienen ola válida y el problema es de formato de la celda del anexo (RF-TEC-062, RF-TEC-157, RF-UXD-026); RF-CON-025 y 075 coinciden con el anexo (O10); RF-CRM-260, RF-TEC-231 y RF-MOR-222 siguen la regla §0.1; RF-UXD-163 sigue reasignado por DEC-056; RF-CON-160 se reasigna de O11 a O5 (PRO-O5-11) por la regla §0.1, con extensión en PRO-O11-06 |\r\n'
    '| d | Rangos de PAN del alcance por anexo distintos de los definidos en los anexos (PAN-COB hasta 42, PAN-MOR hasta 46, PAN-INS hasta 35, PAN-CMP hasta 24, PAN-SOC hasta 33) | Se alinearon a los IDs definidos en cada anexo (filas de tabla o encabezados), con el rango anterior marcado como reemplazado: PAN-COB-01..36, PAN-MOR-01..42, PAN-INS-01..33, PAN-CMP-01..26, PAN-SOC-01..35, PAN-CFG-01..35, PAN-COM-01..34 y 40..53, PAN-POR-01..104, PAN-TEC-01..64, PAN-FAC-01..47. Con el mismo control se alinearon los rangos de API, EVT y JOB del alcance por anexo que tampoco coincidían (29 rangos; los de JOB-CMP se toman del catálogo de T11, porque M12 no los tabula) |\r\n'
    '| e | Barra inferior (tabbar) del portal del socio distinta entre la maestra §9.2 y T03 | Se corrige en la maestra §9.2 (no en este plan) |\r\n\r\n'
    'Totales vigentes por ola (cada RF y RNF en exactamente un prompt; sin faltantes, sin duplicados y sin IDs inexistentes):\r\n\r\n'
    '| Ola | Prompts | RF | RNF |\r\n'
    '|---|---|---|---|\r\n'
    '%s\r\n'
    '| **Total** | **%d** | **%s** | **%d** |\r\n\r\n'
    'RF reasignados respecto de la versión 1.1 del 05-11-2026: solo RF-CON-160 (de PRO-O11-06 a PRO-O5-11). Prompts sin cambio de cantidad: todos salvo PRO-O5-11 (56 a 57) y PRO-O11-06 (19 a 18).'
    % (NOTA, filas, sum(pr.values()), mil(sum(rf.values())), sum(rnf.values())))

# O5: párrafo de reasignados
rep('RF-CON-025 y 075 siguen en O10 en el anexo y vuelven a PRO-O10-02 (en O5 quedan como extensión). Ver §18 y §21.',
    'RF-CON-025 y 075 siguen en O10 en el anexo y vuelven a PRO-O10-02 (en O5 quedan como extensión). Ver §18 y §21. *%s:* RF-CON-160 empieza en esta ola (PRO-O5-11, saldos de apertura) por la regla §0.1; ver §18 y §21.5.' % NOTA.capitalize())

open(PLAN, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + T.encode('utf-8'))
print('ok', rf, rnf)
