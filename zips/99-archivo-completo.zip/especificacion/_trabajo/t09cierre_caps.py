﻿import re
T2=open('anexos/T02-IAM-identidad-roles-auditoria.md',encoding='utf-8').read().split('\n')
defs=set();alias=set();non={}
for i,l in enumerate(T2[220:2462],start=221):
    m=re.match(r'\| `([^`]+)` \|',l)
    if m:
        (alias if 794<=i<820 else defs).add(m.group(1))
    m=re.match(r'\| [^|]+ \| `([^`]+)` \| ([^|]+) \|',l)
    if m and i>=2269: non[m.group(1)]=m.group(2)
T9=open('anexos/T09-COM-comunidad-comunicaciones.md',encoding='utf-8').read()
caps=set(re.findall(r'`((?:com|pla|iam|por|cfg|wfl|crm|int|bia|nfr|sue|fac|mor|cob|tec|per|ins|uxd|cat|med)\.[A-Za-z]+\.[A-Za-z.*]+)`',T9))
for c in sorted(caps):
    st='DEF' if c in defs else ('ALIAS' if c in alias else ('NONCANON->'+non[c] if c in non else '??'))
    if st!='DEF': print(st,c)
