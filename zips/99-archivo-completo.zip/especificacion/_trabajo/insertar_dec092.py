from pathlib import Path

raiz = Path(__file__).resolve().parents[1]

FILA_01 = ("| DEC-092 | 05-11-2026 | Cierre de brechas del modelo de amenazas (resuelto por el solicitante por delegación; "
           "OBS-TM-02, 03, 04, 05, 07, 09, 10, 11, 12, 13 y 14 del entregable 28) | "
           "Se completan requisitos existentes sin crear identificadores nuevos: (1) render de PDF aislado, sin red de salida ni JavaScript, "
           "con recursos inyectados y límites de tiempo y memoria (RNF-NFR-199); (2) certificados del agente local emitidos por una CA privada "
           "con emisor por tenant, vigencia 90 días, renovación automática desde 30 días antes y revocación efectiva en menos de 5 minutos "
           "(RNF-NFR-258); (3) el tenant de un webhook entrante sale de la conexión dueña del `endpointKey`; slug distinto = 404 auditado "
           "(RF-INT-053); (4) la extracción de ProCoop sale de la red de la cooperativa solo por conexión saliente cifrada o backup cifrado con "
           "URL prefirmada de un solo uso (RF-MIG-010); (5) las credenciales heredadas se regeneran, nunca se reingresan (RN-MIG-013 alineada con "
           "RF-INT-023); (6) categorías de DEK `salud`, `laboral`, `judicial`, `financiero` y `secreto` (RNF-NFR-056 alineado con T05); "
           "(7) lista blanca de colecciones globales unificada entre RF-PLA-023 y T05 §7.1.3; (8) contraseña mínima 12 para personal y 10 para "
           "socios, máximo 128 (RNF-NFR-061 alineado con RF-IAM-040); (9) retiro de dominios propios con control diario de CNAME colgantes (T01); "
           "(10) prueba de penetración antes de la primera salida con datos reales y antes del corte comercial de LAG; (11) semilla mínima de "
           "TEN-001 y TEN-002 desde O0 para la suite de aislamiento (RF-PLA-054). No cambia olas ni conteos | "
           "T08 (RNF-NFR-056, 061, 095, 199, 258), T06 (RF-INT-053), T07 (RF-MIG-010, RN-MIG-013), T01 (RF-PLA-023, 054, DNS/TLS), T05 §7.1.3 | Vigente |")

FILA_00 = ("| DEC-092 | Cierre de brechas del modelo de amenazas | PDF con render aislado; CA privada para certificados del agente (90 días, "
           "renovación automática); tenant de webhooks por `endpointKey`; extracción ProCoop solo saliente y cifrada; credenciales heredadas "
           "regeneradas; DEK y colecciones globales alineadas con T05; contraseña socio 10 / personal 12, máximo 128; retiro de dominios propios; "
           "momento del pentest; semilla de tenants de prueba desde O0 | T08, T06, T07, T01, T05 |")


def editar(nombre, funcion):
    p = next(raiz.glob(nombre))
    crudo = p.read_bytes()
    bom = crudo.startswith(b'\xef\xbb\xbf')
    texto = crudo.decode('utf-8-sig')
    nl = '\r\n' if '\r\n' in texto else '\n'
    lineas = texto.split(nl)
    funcion(lineas)
    p.write_bytes((b'\xef\xbb\xbf' if bom else b'') + nl.join(lineas).encode('utf-8'))
    print('OK', p.name)


def insertar_tras_091(fila):
    def f(lineas):
        assert not any(l.startswith('| DEC-092 |') for l in lineas), 'DEC-092 ya existe'
        i = next(i for i, l in enumerate(lineas) if l.startswith('| DEC-091 |'))
        lineas.insert(i + 1, fila)
    return f


def maestra(lineas):
    insertar_tras_091(FILA_00)(lineas)
    n = 0
    for i, l in enumerate(lineas):
        if 'DEC-011 a DEC-091' in l:
            lineas[i] = l.replace('DEC-011 a DEC-091', 'DEC-011 a DEC-092')
            n += 1
    assert n == 2, n


editar('01-registro-decisiones.md', insertar_tras_091(FILA_01))
editar('00-*.md', maestra)
