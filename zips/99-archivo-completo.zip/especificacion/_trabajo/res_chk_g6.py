import glob, os, re, sys
d = os.path.join(os.environ['TEMP'], 'g6chk', 'docs', 'x')
mods = ('M12', 'M13', 'M14', 'M15', 'M16', 'M17', 'M18', 'M19')
for f in sorted(glob.glob(os.path.join(d, '06*-estados-*.md'))):
    mod, cur = '', ''
    for l in open(f, encoding='utf-8'):
        m = re.match(r'^## .*?\b([MT]\d{2})\b', l)
        if m:
            mod = m.group(1)
        if l.startswith('###'):
            cur = l.strip()
        if 'estado inicial no explícito' in l and mod in mods and '[*]' in l:
            print(mod, cur)
idx = os.path.join(d, '06a-indice-cobertura-secuencias-estados.md')
for l in open(idx, encoding='utf-8'):
    if re.search(r'\b(M1[2-9])\b', l) and re.search(r'fuera de convenci|guion|cuatro segmentos|solo estados', l, re.I):
        print('IDX', l.strip()[:300])
