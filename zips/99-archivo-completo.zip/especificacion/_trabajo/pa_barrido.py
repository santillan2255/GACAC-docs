import re, os, json, glob
os.chdir(os.path.join(os.path.dirname(__file__), '..'))
t02 = open('02-preguntas-abiertas.md', encoding='utf-8-sig').read()
en02 = {}
for l in t02.split('\n'):
    m = re.match(r'\|\s*(PA-[A-Z0-9-]+?-\d+)\s*\|', l)
    if m:
        en02.setdefault(m.group(1), []).append(l)
dups = [k for k, v in en02.items() if len(v) > 1]
print('02: filas PA', sum(len(v) for v in en02.values()), 'ids', len(en02), 'dups', dups)
defs = {}
pat_h = re.compile(r'^#{2,6}\s*\**\s*(PA-[A-Z][A-Z0-9]*(?:-P\d)?-\d+)\b\s*\**\s*[—:\-–.]?\s*(.*)$')
pat_t = re.compile(r'^\|\s*\**\s*(PA-[A-Z][A-Z0-9]*(?:-P\d)?-\d+)\s*\**\s*\|(.*)$')
pat_b = re.compile(r'^\s*[-*]?\s*\*\*(PA-[A-Z][A-Z0-9]*(?:-P\d)?-\d+)\*\*\s*[—:\-–.]?\s*(.*)$')
for f in sorted(glob.glob('anexos/*.md')):
    L = open(f, encoding='utf-8-sig').read().split('\n')
    for i, l in enumerate(L):
        for p, kind in ((pat_h, 'h'), (pat_t, 't'), (pat_b, 'b')):
            m = p.match(l)
            if m:
                ctx = '\n'.join(L[i:i + 12]) if kind != 't' else l
                defs.setdefault(m.group(1), []).append({'f': os.path.basename(f), 'line': i + 1, 'kind': kind, 'txt': ctx})
                break
falt = sorted(k for k in defs if k not in en02)
print('definidas en anexos', len(defs), 'faltan en 02', len(falt))
print(falt)
json.dump({k: defs[k] for k in falt}, open('_trabajo/pa_faltantes.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump(defs, open('_trabajo/pa_defs.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
# en 02 pero sin definicion encontrada
print('en 02 sin def detectada', len([k for k in en02 if k not in defs]))
