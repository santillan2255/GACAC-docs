#!/usr/bin/env python3
"""Barrido Connectia → GoodApps en 03-plan (PRO-O, §2.3–§2.5, criterios O0)."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PLAN = ROOT / "03-plan-de-olas-y-prompts.md"

NORMA_LINE = (
    "NORMA: 03-norma-ejecucion-goodapps.md §3–§4 (stack GoodApps; barrido 19-11-2026).\n"
)

# Order: longer / specific first
REPLACEMENTS: list[tuple[str, str]] = [
    ("goodapps-coop", "solución CoopApps (.NET 10 + React 19)"),
    ("npm workspaces", "solución .NET monolito modular + frontend React (Vite)"),
    ("npm ci &&", "dotnet restore &&"),
    ("npm ci", "dotnet restore"),
    (
        "npm run lint && npm run check:structure && npm test && npm run test:isolation && npm run trace:check",
        "dotnet build && dotnet test && dotnet test --filter Category=Isolation && python docs/especificacion/_trabajo/plan_recuento.py",
    ),
    (
        "npm run lint, npm run check:structure, npm test, npm run test:isolation, npm run test:e2e",
        "dotnet build, dotnet test, dotnet test --filter Category=Isolation, playwright test",
    ),
    ("npm run test:isolation", "dotnet test --filter Category=Isolation"),
    ("npm run trace:check", "python docs/especificacion/_trabajo/plan_recuento.py"),
    ("npm run seed:demo", "dotnet run --project tools/SeedDemo"),
    ("npm run check:structure", "dotnet run --project tools/CheckStructure"),
    ("npm run lint", "dotnet build"),
    ("npm run test:e2e -- --grep", "playwright test --grep"),
    ("npm run test:e2e", "playwright test"),
    ("npm test -w apps/worker", "dotnet test --filter FullyQualifiedName~Worker"),
    ("npm test -w apps/api", "dotnet test --filter FullyQualifiedName~Api"),
    ("npm test -w packages/", "dotnet test --filter FullyQualifiedName~"),
    ("npm test -w packages/ui", "dotnet test --filter FullyQualifiedName~Ui && playwright test"),
    ("npm test -w packages/connectors", "dotnet test --filter FullyQualifiedName~Connectors"),
    ("npm test -w packages/shared", "dotnet test --filter FullyQualifiedName~Shared"),
    ("npm test &&", "dotnet test &&"),
    ("npm test", "dotnet test"),
    ("apps/api/src/modules/", "src/Api/Modules/"),
    ("apps/api/src/core/", "src/Api/Core/"),
    ("manifest.js e index.js", "registro DI + endpoints (minimal API o controllers)"),
    ("apps/worker", "src/Worker"),
    ("apps/api", "src/Api"),
    ("apps/admin", "frontend/admin (React)"),
    ("apps/pwa", "frontend/pwa (React)"),
    ("packages/shared/schemas", "src/Contracts (Shared)"),
    ("packages/shared/", "src/Shared/"),
    ("packages/connectors", "src/Infrastructure/Connectors"),
    ("plugin Mongoose", "filtros globales EF Core y interceptores"),
    ("Mongoose", "EF Core"),
    ("BullMQ", "Azure Queue Storage"),
    ("outboxEvents", "pla.OutboxEvents (SQL)"),
    ("colección auditLogs", "tabla pla.AuditLogs"),
    ("colección legalEntities", "tabla cfg.LegalEntities"),
    ("colección branches", "tabla cfg.Branches"),
    ("colecciones identities", "tablas iam.* (identities, memberships, users, sessions)"),
    ("colecciones ", "tablas SQL "),
    ("colección ", "tabla "),
    ("Zod", "FluentValidation y contratos Shared"),
    ("node --test", "dotnet test --filter Category=Unit"),
    ("Vitest", "Vitest/Playwright (React)"),
    ("Supertest", "WebApplicationFactory (integración)"),
    ("Mongo replica set", "Azure SQL"),
    ("Mongo y Redis", "Azure SQL y Azure Queue"),
    ("Mongo", "Azure SQL"),
    ("Redis", "Azure Queue Storage o Redis en Azure si aplica"),
    ("decimal.js, Decimal128", "decimal .NET y SQL DECIMAL(19,4)"),
    ("Decimal128", "DECIMAL(19,4)"),
    ("almacenamiento S3 compatible", "Azure Blob"),
    ("MinIO", "Azurite (dev) / Azure Blob (prod)"),
    ("infra/docker/compose.yml con mongo replica set, redis, minio", "docker compose local (API, Worker, SQL, Azurite, frontends)"),
    ("docker compose -f infra/docker/compose.yml", "docker compose -f deploy/docker-compose.dev.yml"),
    ("S3 y MinIO", "Azure Blob"),
    ("ESLint", "analyzers .NET + ESLint frontend"),
    ("templates Vue", "componentes React"),
    ("curl localhost:<puerto-api>/health/live", "curl https://localhost:<puerto>/health/live"),
    ("scripts npm de §2.5", "comandos de §2.5 GoodApps"),
    ("npm run lighthouse -w apps/web-pwa", "npx lighthouse frontend/pwa"),
    (
        "En PRO-O0-02 se crea `npm run trace:check`",
        "En PRO-O0-02 se crea el control de trazabilidad en CI (`trace:check` .NET o",
    ),
    ("Mientras no exista `trace:check`, el mismo control", "Mientras no exista el script en CI, el mismo control",
    ),
    ("Vue", "React"),
    ("Pinia", "estado React"),
]

SECTION_25 = """### 2.5 Scripts y comandos estándar (GoodApps; detalle en `03-norma-ejecucion-goodapps.md` §4)

| Objetivo | Comando / artefacto |
|---|---|
| Compilar | `dotnet build` |
| Unitarias | `dotnet test --filter Category=Unit` |
| Integración API + SQL | `dotnet test --filter Category=Integration` |
| Aislamiento multitenant | `dotnet test --filter Category=Isolation` |
| E2E ola | `playwright test --grep @Ox` |
| Trazabilidad RF ↔ pruebas | `python docs/especificacion/_trabajo/plan_recuento.py` (+ script CI acordado, PRO-O0-02) |
| Seeds demo | Herramienta `SeedDemo` idempotente; bloqueada en producción |
| Migración esquema | EF Core migrations + paridad con `07-ddl` en CI |
| Entorno local | `deploy/docker-compose.dev.yml` (API, Worker, SQL, storage emulado, React) |

*Reemplaza (Connectia 04-11-2026): scripts `npm run *` del monorepo Node — conservados solo como histórico en prompts no barridos.*

"""

R11_GOODAPPS = (
    "| R11 | **Convenciones obligatorias** (maestro §13, guía §5, **DEC-111**): inglés camelCase en código y datos; "
    "UI con `dict:<clave>`; entidades con `TenantId`, auditoría y versión optimista; `LegalEntityId` en documentos económicos "
    "(DEC-064); dinero en **SQL DECIMAL(19,4)** y `decimal` en .NET (prohibido `double` para importes); fechas UTC y zona del tenant; "
    "capabilities `modulo.recurso.accion`; errores **ProblemDetails** RFC 9457 con `requestId`; `Idempotency-Key` en operaciones "
    "económicas e integraciones; eventos por **outbox SQL** en la misma transacción; procesos masivos en **worker** y colas Azure. |"
)

R12_GOODAPPS = (
    "| R12 | **Arquitectura** (ARQ-01..08): un módulo solo escribe sus **tablas** del esquema dueño; usa servicios públicos o eventos "
    "de otros módulos; integraciones solo por conectores T06 con secretos en la bóveda; la IA solo propone. |"
)

R15_GOODAPPS = (
    "| R15 | **Pruebas mínimas por prompt**: unitarias (xUnit); integración con **Azure SQL** de diseño o Testcontainers "
    "(WebApplicationFactory); permisos 403 por capability; aislamiento tenant (403/404); idempotencia; reintentos de jobs; "
    "e2e Playwright en React. Cada prueba cita el ID en el nombre. |"
)

R16_GOODAPPS = (
    "| R16 | **DoD común (GoodApps).** (1) RF con prueba automatizada citando ID. (2) Permisos y aislamiento verdes. "
    "(3) Sin textos fijos en UI. (4) Auditoría y eventos en cambios persistentes. (5) Contratos/OpenAPI y validación actualizados. "
    "(6) Seeds idempotentes; demo bloqueado en prod. (7) `dotnet build`, `dotnet test`, aislamiento y e2e del prompt en verde. "
    "(8) Matriz (R19). (9) PR plantilla R18 + **PRO-GEN-04**. |"
)

R19_SNIPPET = "`python docs/especificacion/_trabajo/plan_recuento.py`"


def in_prompt_zone(text: str, pos: int) -> bool:
    """True if position is inside a ```text block after first PRO-O0."""
    start = text.find("#### PRO-O0-01")
    if start < 0 or pos < start:
        return False
    before = text[:pos]
    fences = before.count("```")
    return fences % 2 == 1


def apply_line_replacements(line: str) -> str:
    if line.strip().startswith("LEER:"):
        return line
    if "*Reemplazado" in line or line.strip().startswith(">"):
        return line
    out = line
    for old, new in REPLACEMENTS:
        if old in out:
            out = out.replace(old, new)
    return out


def barrido_prompt_blocks(text: str) -> str:
    def repl(m: re.Match[str]) -> str:
        body = m.group(1)
        lines = body.splitlines(keepends=True)
        if lines and (
            lines[0].startswith("PRO-O") or re.match(r"PRO-GEN-\d+", lines[0])
        ):
            if not any("NORMA: 03-norma" in ln for ln in lines[:5]):
                lines.insert(1, NORMA_LINE)
        new_body = "".join(apply_line_replacements(ln) for ln in lines)
        return f"```text\n{new_body}```"

    return re.sub(r"```text\n(.*?)```", repl, text, flags=re.DOTALL)


def replace_section_25(text: str) -> str:
    pattern = r"### 2\.5 Scripts estándar del monorepo \(los crea O0\)\s*\n\n\| Script.*?\n\n---"
    if not re.search(pattern, text, re.DOTALL):
        pattern = r"### 2\.5 Scripts.*?\n\n---"
    return re.sub(pattern, SECTION_25.rstrip() + "\n\n---", text, count=1, flags=re.DOTALL)


def patch_rules_table(text: str) -> str:
    text = re.sub(
        r"\| R11 \| \*\*Convenciones obligatorias\*\*.*?\|",
        R11_GOODAPPS,
        text,
        count=1,
    )
    text = re.sub(
        r"\| R12 \| \*\*Arquitectura\*\*.*?\|",
        R12_GOODAPPS,
        text,
        count=1,
    )
    text = re.sub(
        r"\| R15 \| \*\*Pruebas mínimas por prompt\*\*:.*?\|",
        R15_GOODAPPS,
        text,
        count=1,
    )
    text = re.sub(
        r"\| R16 \| \*\*Definición de terminado común \(DoD\)\.\*\*.*?\|",
        R16_GOODAPPS,
        text,
        count=1,
    )
    text = text.replace(
        "Además corre `npm run trace:check`",
        f"Además corre {R19_SNIPPET}",
    )
    text = text.replace(
        "trace:check (creado en PRO-O0-02)",
        "trazabilidad en CI (creada en PRO-O0-02)",
    )
    return text


def patch_o0_criteria(text: str) -> str:
    old = (
        "1. `docker compose up` levanta api, worker, admin, pwa, landing, Mongo replica set, Redis, almacenamiento S3 compatible y renderer PDF."
    )
    new = (
        "1. `docker compose` (o entorno local acordado) levanta API .NET, worker, shells React (admin/PWA/landing), Azure SQL (o contenedor), cola Azure emulada y almacenamiento Blob emulado + renderer PDF."
    )
    text = text.replace(old, new)
    old2 = (
        "4. Un cambio de prueba genera auditoría encadenada, evento en `outboxEvents` y job procesado una sola vez aunque se reintente."
    )
    new2 = (
        "4. Un cambio de prueba genera auditoría encadenada, evento en `pla.OutboxEvents` y job procesado una sola vez aunque se reintente."
    )
    return text.replace(old2, new2)


def patch_pro_gen_historical(text: str) -> str:
    for gen in ("01", "02", "03"):
        marker = f"### PRO-GEN-{gen} —"
        idx = text.find(marker)
        if idx < 0 or "Build GoodApps" in text[idx : idx + 280]:
            continue
        line_end = text.find("\n", idx)
        note = (
            f"\n\n> **Build GoodApps:** [`03-norma-ejecucion-goodapps.md`](03-norma-ejecucion-goodapps.md) "
            f"§6 PRO-GEN-{gen}. Bloque ```text Connectia **histórico** (barrido 19-11-2026).\n"
        )
        text = text[: line_end + 1] + note + text[line_end + 1 :]
    return text


def patch_172_counts(text: str) -> str:
    subs = [
        (
            "Los 172 prompts no incluyen los tres PRO-GEN de §3.",
            "Los **174** bloques `PRO-O*` incluyen dos reemplazados no ejecutables (PRO-O11-07/08); **172 ejecutables**. Los PRO-GEN están en `03-norma` (4) y §3.",
        ),
        (
            "no cuentan en los 172 prompts (O11 queda con 8 prompts efectivos)",
            "no se ejecutan (O11 queda con **8 prompts efectivos**; plan tiene **174** bloques PRO-O)",
        ),
        (
            "Los totales generales no cambian (172 prompts, 4.204 RF, 292 RNF)",
            "Los totales generales no cambian (174 bloques PRO-O, 4.213 RF, 293 RNF; recuento 19-11-2026)",
        ),
    ]
    for a, b in subs:
        text = text.replace(a, b)
    return text


def fix_barrido_artifacts(text: str) -> str:
    text = re.sub(
        r"(?:frontend/)+packages/ui(?: \(React\))+(?: \(React\))*",
        "frontend/packages/ui (React)",
        text,
    )
    fixes = [
        ("tokens CNX §", "tokens T03 §"),
        ("CNX §", "T03 §"),
        (
            "adaptador de almacenamiento (S3 y Azurite (dev) / Azure Blob (prod) local)",
            "adaptador de almacenamiento (Azure Blob; Azurite en dev)",
        ),
        ("tenants/<tenantId>/", "tenants/{tenantId}/"),
    ]
    for old, new in fixes:
        text = text.replace(old, new)
    return text


def main() -> None:
    text = PLAN.read_text(encoding="utf-8")
    text = replace_section_25(text)
    text = patch_rules_table(text)
    text = patch_o0_criteria(text)
    text = patch_pro_gen_historical(text)
    text = patch_172_counts(text)
    text = barrido_prompt_blocks(text)
    text = fix_barrido_artifacts(text)
    PLAN.write_text(text, encoding="utf-8")
    # Stats
    remaining = sum(
        1
        for pat in ("npm run", "Mongoose", "BullMQ", "goodapps-coop", "apps/api/src")
        if pat in text
    )
    print(f"Barrido OK: {PLAN.name}")
    print(f"Patrones Connectia residuales (líneas con token): grep manual recomendado")


if __name__ == "__main__":
    main()