﻿import re
s=open('03-plan-de-olas-y-prompts.md',encoding='utf-8').read().split('\n')
for i,l in enumerate(s,1):
    if 'DEC-064' in l or 'legalEntit' in l or 'branches' in l: print('03',i,l[:600])
m=open('04-matriz-trazabilidad.md',encoding='utf-8').read().split('\n')
for i,l in enumerate(m,1):
    if l.startswith('#'): print('04',i,l)
