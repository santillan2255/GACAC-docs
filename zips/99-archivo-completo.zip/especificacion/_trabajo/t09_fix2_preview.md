## 7. Modelo de datos

### 7.0 Convenciones del módulo

- Todas las colecciones llevan `tenantId` (ObjectId, obligatorio, primer campo de todo índice compuesto), `createdAt`, `updatedAt`, `createdBy`, `updatedBy`, `version` (control optimista) y, salvo indicación, `deletedAt` (borrado lógico). Las colecciones de evidencia (`communications`, `communicationAttempts`, `communicationEvents`, `consentRecords`, `moderationCases`, `contentReports`, `communitySanctions`) **no admiten borrado lógico ni físico** fuera del job de retención (JOB-COM-19) y de la anonimización aprobada (AGR-033).
- Los medios se guardan como **referencia a objeto privado** (`{ objectKey, mime, sizeBytes, width?, height?, durationSec?, alt? }`) y se sirven con URL firmada (CNX §10 V-01); nunca URL pública persistida.
- Los textos visibles se guardan como contenido del tenant; las etiquetas de UI son `dict:`.
- Las fechas se guardan en UTC; vigencias y programaciones se interpretan en la zona del tenant (`America/Argentina/Cordoba` por defecto).
- Los importes (costo de mensajería, beneficios de monto fijo) son `Decimal128` con `currency`.
- El tenant `PLATFORM` usa las mismas colecciones para los avisos de plataforma (`platformNotices`).

#### Subesquema compartido `AudienceDefinition` (motor único, §5.7)

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `mode` | enum `all`, `restricted`, `users`, `import`, `segment`, `none` | Sí | Modo (RF-COM-110). |
| `unit` | enum `person`, `account`, `serviceContract` | Sí (default `person`) | Unidad de destino y deduplicación (RF-COM-112). |
| `purpose` | enum de finalidad (§3) | Sí | Determina dimensiones permitidas (RF-COM-119) y reglas de opt-out. |
| `include.recipientTypes[]` | enum `member`, `holder`, `adherent`, `authorizedUser`, `employee`, `councilor`, `supplier`, `guest` | No | Tipo de destinatario. |
| `include.branchIds[]`, `zoneIds[]`, `sectorIds[]`, `routeIds[]`, `localityIds[]`, `neighborhoodIds[]`, `streetIds[]` | ObjectId[] | No | Geografía y organización (T04, M01). |
| `include.serviceIds[]`, `serviceStatuses[]`, `tariffCategoryIds[]`, `planIds[]`, `billingGroupIds[]` | ObjectId[] / enum[] | No | Servicio y comercial (M02, M04). `serviceStatuses`: `requested`, `active`, `suspended`, `disconnected`, `terminated`. |
| `include.debtStatus` | { `kinds[]`: `none`, `notDue`, `overdue`; `minDaysOverdue`, `maxDaysOverdue`: Int; `moraStageIds[]`; `inAgreement`: Bool } | No | Estado de deuda (M07/M08). |
| `include.invoiceDeliveryModes[]` | enum `digital`, `paper` | No | Modalidad de factura (M05). |
| `include.hasChannels[]` | enum de canal | No | Tiene contacto utilizable para el canal. |
| `include.roleIds[]`, `profileIds[]`, `crewIds[]` | ObjectId[] | No | Empleados (T02, M10, M16). |
| `include.networkNodeIds[]` | ObjectId[] | No | Ramal, transformador, nodo, OLT, celda (M10). |
| `include.customAttributes[]` | [{ `key`, `op` (`eq`,`neq`,`in`,`gt`,`lt`,`exists`), `value` }] | No | Atributos de M01 (`PERSONAS_EXTRAS`). |
| `include.memberSince` | { `from`, `to` } | No | Antigüedad como asociado (M17). |
| `include.birthdayToday` | Bool | No | Saludos. |
| `include.inactiveDays` | Int | No | Sin ingreso a la app N días (RF-COM-192). |
| `personIds[]` | ObjectId[] | No | Modo `users` o agregado en `restricted`. |
| `importListIds[]` | ObjectId[] → `audienceImportLists` | No | Modo `import`. |
| `segmentId` | ObjectId → `audienceSegments` | No | Modo `segment`. |
| `exclude` | { `personIds[]`, `importListIds[]`, `segmentIds[]` } | No | Exclusiones explícitas. |
| `clamp` | { `grantHash`, `clampedAt`, `removedDimensions[]`, `changed`: Bool } | Sistema | Resultado de `clampAudienceToGrant`. |
| `hash` | String (SHA-256 de la definición normalizada) | Sistema | Identifica la definición en snapshots. |

### 7.1 Muro editorial

**`posts`** — publicaciones (CNX §5.2 `Post` adaptado). Origen ProCoop: `WEB_NOVEDADES`, `NOTI_COOP` (parcial).

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `title` | String ≤200 | Sí | Título. |
| `body` | String (HTML sanitizado de lista blanca) | No | Cuerpo enriquecido. |
| `bodyText` | String | Sistema | Texto plano para búsqueda y detección de datos personales. |
| `type` | enum `noticia`, `aviso`, `corte_programado`, `asamblea`, `beneficio`, `evento`, `institucional`, `celebracion`, `general` | Sí | RF-COM-005. |
| `categoryId` | ObjectId → `postCategories` | No | Categoría. |
| `section` | String ≤80 | No | Hashtag/sección. |
| `cover`, `gallery[]`, `video`, `audio` | Media | No | Medios privados. |
| `layout` | enum `vertical`, `horizontal`, `banner` | Sí (default `vertical`) | |
| `channels[]` | enum `landing`, `members`, `employees` | Sí (≥1) | Canal de publicación. |
| `origin` | enum `admin`, `supervisor`, `system` | Sí | Nunca `member` (DEC-008, CTR-COM-01). |
| `authorUserId`, `authorDisplay` | ObjectId; { `kind`: `institution`/`person`, `name` } | Sí | Autor real y autor visible. |
| `status` | enum `draft`, `pending_review`, `scheduled`, `published`, `rejected`, `archived` | Sí | §8.1. |
| `scheduledAt`, `publishedAt`, `archivedAt`, `expiresAt` | Date | No | |
| `pinned`, `pinnedUntil` | Bool, Date | No | Fijado con vencimiento. |
| `priority` | Int 0–100 | No (default 50) | Orden en feed y boletín. |
| `approval` | { `required`, `requestedAt`, `requestedBy`, `wflRequestId`, `decision` (`approved`/`rejected`), `decidedBy`, `decidedAt`, `note` } | No | RF-COM-007. |
| `audience` | AudienceDefinition | Sí | Para `landing` siempre `all` (RN-COM-010). |
| `audienceSnapshotId` | ObjectId | Sistema | Al publicar. |
| `notify` | { `inApp`, `push`, `email`: Bool; `communicationTypeCode` } | No | RF-COM-009. |
| `reactionsEnabled`, `commentsEnabled` | Bool | Sí (default según PRM-COM-001/005) | |
| `commentModerationMode` | enum `inherit`, `pre`, `ai_assisted`, `post` | Sí (default `inherit`) | RF-COM-040. |
| `commentsClosedAt`, `autoCloseCommentsDays` | Date, Int | No | RF-COM-036. |
| `linkedSurveyId`, `linkedEventId`, `linkedBenefitId`, `linkedOutageNoticeId` | ObjectId | No | Vinculaciones. |
| `kb` | { `articleId`, `promotedAt`, `promotedBy` } | No | RF-COM-022. |
| `greeting` | { `ruleId`, `eventType`, `forPersonIds[]`, `runKey` } | No | RF-COM-020. |
| `ai` | { `draftUsed`, `provider`, `model`, `confirmedBy`, `confirmedAt` } | No | RF-COM-021. |
| `piiWarnings[]` | [{ `kind` (`dni`,`cuit`,`email`,`phone`,`account`,`cbu`), `excerpt`, `acknowledgedBy`, `acknowledgedAt` }] | Sistema | RF-COM-024. |
| `counters` | { `impressions`, `views`, `reactions` (mapa clave→Int), `comments`, `shares`, `saves`, `hides` } | Sistema | Desnormalizados, recalculables. |
| `copiedFromPostId` | ObjectId | No | RF-COM-025. |

Índices: `{tenantId, status, pinned, priority, publishedAt}`; `{tenantId, status, scheduledAt}`; `{tenantId, channels, status, publishedAt}`; `{tenantId, type, publishedAt}`; `{tenantId, authorUserId, createdAt}`; único parcial `{tenantId, greeting.runKey}`; texto `{tenantId, title, bodyText}`.

**`postCategories`** (COL-COM-02)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `code` | String | Sí | único por tenant (antes `key`; nombre según T05) | — |
| `name` | String | Sí | — | — |
| `slug` | String | No | — | — |
| `icon` | String | No | — | — |
| `color` | String | No | — | — |
| `parentId` | ObjectId | No | — | `postCategories` (COL-COM-02, T09) |
| `order` | Int | No | — | — |
| `active` | Bool | No | — | — |
| `system` | Bool | No | Bool, no borrable | — |

Índice único `{tenantId, code}`. Índices con los nombres de T05 (antes `key` → `code`).

**`postTemplates`** (COL-COM-03)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `name` | String | Sí | — | — |
| `type` | enum | No | — | — |
| `title` | String | Sí | — | — |
| `body` | String | No | — | — |
| `layout` | enum | No | — | — |
| `section` | String | No | — | — |
| `cover` | Media | No | — | — |
| `pinned` | Bool | No | — | — |
| `defaultAudience` | AudienceDefinition | No | — | — |
| `defaultChannels[]` | enum[] `landing`, `members`, `employees` | No | — | — |
| `active` | Bool | No | — | — |
| `code` | String | Sí | Código único por tenant (según T05). | — |

**`postReactions`** (COL-COM-04)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `postId` | ObjectId | Sí | — | `posts` (COL-COM-01, T09) |
| `membershipId` | ObjectId | Sí | (antes `userId`; nombre según T05) | `memberships` (COL-IAM-04, T02) |
| `reaction` | String (clave) | No | clave del catálogo PRM-COM-005 | — |
| `reactedAt` | Date | No | — | — |

Único `{tenantId, postId, membershipId}` (RN-COM-003). Reemplaza el mapa `reactors` embebido de CNX para soportar volumen. Índices con los nombres de T05 (antes `userId` → `membershipId`).

**`postViews`** (COL-COM-05)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `postId` | ObjectId | Sí | — | `posts` (COL-COM-01, T09) |
| `userId` | ObjectId | Sí | — | `memberships` (COL-IAM-04, T02) |
| `kind` | enum `impression`/`detail` | Sí | — | — |
| `channel` | enum `pwa`/`landing`/`email` | Sí | — | — |
| `dayKey` | String (`yyyymmdd`) | Sí | `yyyymmdd` en zona del tenant | — |

Único `{tenantId, postId, userId, kind, dayKey}`; TTL de detalle a 400 días con agregados diarios persistidos en `postDailyStats`.

**`postDailyStats`** (COL-COM-06)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `postId` | ObjectId | Sí | — | `posts` (COL-COM-01, T09) |
| `date` | String (`yyyymmdd`) | Sí | (antes `dayKey`; nombre según T05) | — |
| `impressions` | Int | Sistema | — | — |
| `views` | Int | Sistema | — | — |
| `uniqueViewers` | Int | Sistema | — | — |
| `reactionsByKey` | String | Sistema | — | — |
| `comments` | Int | Sistema | — | — |
| `shares` | Int | Sistema | — | — |

Único `{tenantId, postId, date}`. Índices con los nombres de T05 (antes `dayKey` → `date`).

**`postUserStates`** (COL-COM-07)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `postId` | ObjectId | Sí | — | `posts` (COL-COM-01, T09) |
| `membershipId` | ObjectId | Sí | (antes `userId`; nombre según T05) | `memberships` (COL-IAM-04, T02) |
| `kind` | enum `saved`/`hidden` | Sí | — | — |
| `at` | Date | No | — | — |

Único `{tenantId, postId, membershipId, kind}`. Reemplaza `SavedPost`/`HiddenPost` de CNX. Índices con los nombres de T05 (antes `userId` → `membershipId`).

**`greetingRules`** (COL-COM-08)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `name` | String | Sí | — | — |
| `eventType` | enum `birthday`, `memberAnniversary`, `employeeAnniversary` | No | — | — |
| `audience` | AudienceDefinition | No | — | — |
| `postTemplateId` | ObjectId | No | — | `postTemplates` (COL-COM-03, T09) |
| `channels[]` | enum[] `landing`, `members`, `employees` | No | — | — |
| `sendTime` | String (HH:mm) | No | — | — |
| `active` | Bool | No | — | — |
| `lastRunKey` | String | Sistema | — | — |
| `code` | String | Sí | Código único por tenant (según T05). | — |

### 7.2 Comentarios, moderación y sanciones

**`comments`**

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `postId` | ObjectId | Sí | |
| `parentId` | ObjectId | No | Solo un nivel: si el padre ya tiene `parentId`, se rechaza. |
| `authorUserId`, `authorPersonId` | ObjectId | Sí / No | |
| `text` | String ≤ PRM-COM-016 (4000) | Sí (o media) | Texto original (evidencia). |
| `textDisplayed` | String | Sistema | Texto mostrado (con enmascarado por regla `mask`). |
| `media` | Media (`image`/`gif`) | No | Si el tenant lo habilita. |
| `mentions[]` | ObjectId[] (userId) | No | ≤10 (RN-COM-011). |
| `status` | enum `pending_review`, `visible`, `hidden`, `rejected`, `deleted_by_author`, `removed` | Sí | §8.2. |
| `moderation` | { `modeApplied`, `ruleHits[]` [{ `ruleId`, `ruleVersion`, `action` }], `ai` { `status` (`pending`,`done`,`error`,`skipped`), `provider`, `model`, `risk` (`low`,`medium`,`high`), `score`, `categories[]`, `policyFlags[]`, `reasons[]`, `suggestedAction`, `summary`, `analyzedAt`, `error` }, `imageAi` (ídem), `crmCaseId` } | Sistema | RF-COM-042. |
| `adminReply` | { `text`, `userId`, `at` } | No | RF-COM-033. |
| `editHistory[]` | [{ `text`, `media`, `at` }] | Sistema | Conserva versiones (RF-COM-031). |
| `reportsCount` | Int | Sistema | |
| `guidelinesVersion` | String | Sí | Versión de reglas aceptada al comentar. |
| `clientMutationId` | String | No | Idempotencia offline. |

Índices: `{tenantId, postId, status, createdAt}`; `{tenantId, authorUserId, createdAt}`; `{tenantId, status, moderation.ai.risk}`; único parcial `{tenantId, authorUserId, clientMutationId}`.

**`moderationPolicies`** — una por tenant (`scope: tenant`) y opcionales por categoría (`scope: category`, `categoryId`) (COL-COM-10)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `commentsEnabled` | Bool | No | — | — |
| `defaultMode` | enum `pre`, `ai_assisted`, `post` | No | — | — |
| `aiEnabled` | Bool | No | — | — |
| `aiConnectorId` | ObjectId | No | T06 | `integrationConnections` (COL-INT-02, T06) |
| `riskThresholds` | Objeto | No | { `medium`, `high` } (0–1) | — |
| `categoryActions` | Objeto (mapa) | No | mapa categoría de política → `block`/`review`/`mask`/`allow` | — |
| `reportThreshold` | Int | No | — | — |
| `maxCommentsPerHour` | Int | No | — | — |
| `linkPolicy` | enum `allow`/`review`/`block` | No | — | — |
| `maxLength` | Int | No | — | — |
| `imageCommentsEnabled` | Bool | No | — | — |
| `gifEnabled` | Bool | No | — | — |
| `autoCloseDays` | Int | No | — | — |
| `sanctionLadder[]` | Objeto[] | No | [{ `offenseNumber`, `kind`, `durationDays` }] | — |
| `reincidenceWindowDays` | Int | No | — | — |
| `evidenceRetentionDays` | Int | No | — | — |
| `slaMinutes` | Objeto | No | { `high`, `medium`, `low` } | — |
| `currentGuidelinesId` | ObjectId | No | — | `communityGuidelines` (COL-COM-15, T09) |
| `version` | String | No | — | — |
| `publishedAt` | Date | No | — | — |
| `code` | String | Sí | Código único por tenant (según T05). La política de tenant usa `tenant`. | — |

Versionada: cada cambio crea versión nueva (T04 configuración versionada).

**`moderationRules`** (COL-COM-11)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `name` | String | Sí | — | — |
| `kind` | enum `term_list`, `pii_pattern`, `link`, `length`, `rate`, `caps`, `repetition`, `custom_regex` | Sí | — | — |
| `config` | Objeto | No | términos con modo `exact`/`stem`, patrón, umbral | — |
| `action` | enum `block`, `review`, `mask`, `allow` | No | — | — |
| `appliesTo` | enum `comments`, `comment_images`, `post_landing_check` | No | — | — |
| `categoryIds[]` | ObjectId[] | No | — | `postCategories` (COL-COM-02, T09) [VERIFICAR: el ER infiere `serviceCategories` de M02; por el contexto son categorías de publicación] |
| `priority` | Int | No | — | — |
| `active` | Bool | No | — | — |
| `ruleVersion` | Int | No | — | — |
| `code` | String | Sí | Código único por tenant (según T05). | — |
| `policyId` | ObjectId | Sí | Política a la que pertenece la regla (según T05). | `moderationPolicies` (COL-COM-10, T09) |

Índice `{tenantId, active, priority}`.

**`moderationCases`**

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `subjectType` | enum `comment`, `comment_image` | Sí | |
| `subjectId`, `postId`, `authorUserId` | ObjectId | Sí | |
| `origin` | enum `ai`, `rule`, `report`, `manual`, `ai_error` | Sí | |
| `priority` | enum `low`, `medium`, `high` | Sí | Alta si reportes ≥ umbral o riesgo `high`. |
| `riskSnapshot` | copia de `moderation.ai` al abrir | No | |
| `ruleHits[]`, `reportIds[]` | | No | |
| `status` | enum `open`, `assigned`, `decided`, `escalated`, `appealed`, `closed` | Sí | §8.3. |
| `assignedTo`, `slaDueAt` | ObjectId, Date | No | |
| `decision` | { `action` (`approve`, `hide`, `hide_and_reply`, `derive_crm`, `accept_ai`, `ignore_ai`, `escalate`, `request_evidence_removal`), `reasonCode`, `note`, `by`, `at`, `aiSuggestion`, `matchedAi`: Bool } | No | RF-COM-045. |
| `crmCaseId`, `sanctionId`, `evidenceRemovalWflId` | ObjectId | No | |
| `history[]` | [{ `at`, `by`, `action`, `from`, `to`, `note` }] | Sistema | Bitácora (además de auditoría T02). |

Índices: `{tenantId, status, priority, slaDueAt}`; `{tenantId, subjectType, subjectId}` único parcial con `status ≠ closed`; `{tenantId, assignedTo, status}`.

**`contentReports`** (COL-COM-13)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `targetRef` | Objeto { `type` (`comment`), `id` } | Sí | Comentario reportado (antes `commentId`; nombre según T05). | `comments` (COL-COM-09, T09) |
| `postId` | ObjectId | No | — | `posts` (COL-COM-01, T09) |
| `reporterUserId` | ObjectId | Sí | — | `memberships` (COL-IAM-04, T02) |
| `reasonCode` | enum `insult`, `hate`, `threat`, `sexual`, `spam`, `personal_data`, `misinformation`, `service_claim`, `other` | No | — | — |
| `text` | String | No | ≤500 | — |
| `status` | enum `open`, `upheld`, `dismissed` | Sí | — | — |
| `crmCaseId` | ObjectId | No | — | `crmCases` (COL-CRM-01, M09) |
| `resolvedAt` | Date | No | — | — |
| `reporterNotifiedAt` | Date | No | — | — |

Único `{tenantId, targetRef, reporterUserId}`. Índices con los nombres de T05 (antes `commentId` → `targetRef`).

**`communitySanctions`** (COL-COM-14)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `membershipId` | ObjectId | Sí | (antes `userId`; nombre según T05) | `memberships` (COL-IAM-04, T02) |
| `personId` | ObjectId | No | — | `persons` (COL-PER-01, M01) |
| `kind` | enum `warning`, `mute`, `comment_ban`, `permanent_ban` | Sí | — | — |
| `reasonCode` | String | No | — | — |
| `caseIds[]` | ObjectId[] | No | — | `moderationCases` (COL-COM-12, T09) |
| `offenseNumber` | Int | No | — | — |
| `startsAt` | Date | No | — | — |
| `endsAt` | Date | No | null en permanente y advertencia | — |
| `status` | enum `active`, `expired`, `revoked`, `appeal_pending`, `appeal_upheld`, `appeal_revoked` | Sí | — | — |
| `suggestedBySystem` | Bool | No | — | — |
| `appliedBy` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `revokedBy` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `revokeReason` | String | No | — | — |
| `appeal` | Objeto | No | { `submittedAt`, `text`, `reviewerId`, `decision` (`upheld`/`revoked`/`reduced`), `decidedAt`, `note` } | — |
| `notifiedAt` | Date | No | — | — |

Índices `{tenantId, membershipId, status, endsAt}`. Índices con los nombres de T05 (antes `userId` → `membershipId`).

**`communityGuidelines`** (COL-COM-15)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `version` | String | No | semver | — |
| `title` | String | Sí | — | — |
| `body` | String | No | — | — |
| `status` | enum `draft`, `published`, `retired` | Sí | — | — |
| `publishedAt` | Date | No | — | — |

**`guidelineAcceptances`** (COL-COM-16)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `membershipId` | ObjectId | Sí | (antes `userId`; nombre según T05) | `memberships` (COL-IAM-04, T02) |
| `guidelinesVersion` | String | Sí | — | — |
| `acceptedAt` | Date | No | — | — |
| `device` | Objeto | No | — | — |
| `ipHash` | String | No | — | — |

Único `{tenantId, membershipId, guidelinesVersion}`. Índices con los nombres de T05 (antes `userId` → `membershipId`).

### 7.3 Boletines

**`newsletterRules`** (CNX §6.1) (COL-COM-17)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `name` | String | Sí | — | — |
| `scheduleMode` | enum `interval`/`calendar` | No | — | — |
| `intervalHours` | Int | No | — | — |
| `calendarWeekdays[]` | Int[] (1–7) | No | — | — |
| `calendarTime` | String (HH:mm) | No | — | — |
| `timezone` | String (zona IANA) | No | — | — |
| `format` | enum `corto`, `digest`, `revista` | No | — | — |
| `greetingTemplate` | String | No | — | — |
| `requireReview` | Bool | No | — | — |
| `postCount` | Int | No | — | — |
| `selectMode` | enum `latest`, `pinned_first`, `priority_first`, `oldest_first` | No | — | — |
| `types[]` | enum[] (tipos de publicación, RF-COM-005) | No | — | — |
| `maxAgeHours` | Int | No | — | — |
| `avoidRepeats` | Bool | No | — | — |
| `audience` | AudienceDefinition | No | — | — |
| `channels[]` | enum[] `email`, `in_app` | No | `email`, `in_app` | — |
| `enabled` | Bool | No | — | — |
| `lastRunAt` | Date | Sistema | — | — |
| `nextRunAt` | Date | Sistema | — | — |
| `lastRunKey` | String | Sistema | — | — |
| `code` | String | Sí | Código único por tenant (según T05). | — |

**`newsletters`** (COL-COM-18)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `ruleId` | ObjectId | Sí | — | `newsletterRules` (COL-COM-17, T09) |
| `subject` | String | No | — | — |
| `status` | enum `pending_review`, `approved`, `sending`, `sent`, `rejected`, `cancelled` | Sí | — | — |
| `format` | String | No | — | — |
| `posts[]` | Objeto[] | No | snapshot inmutable: `postId`, `title`, `type`, `excerpt`, `cover` | — |
| `featuredPostId` | ObjectId | No | — | `posts` (COL-COM-01, T09) |
| `lede` | String | No | — | — |
| `ledeAi` | Bool | No | — | — |
| `greetingTemplate` | String | No | — | — |
| `visibleInApp` | Bool | No | — | — |
| `variants[]` | Objeto[] | No | [{ `fingerprint`, `postIds[]`, `summary`, `recipientCount`, `emailableCount` }] | — |
| `totals` | Objeto | Sistema | { `recipients`, `included`, `emailable`, `sent`, `delivered`, `opened`, `failed` } | — |
| `actors` | Objeto | No | { `createdBy`, `reviewedBy`, `approvedBy`, `rejectedBy`, `sentBy`, `cancelledBy` con `at` y `note` } | — |
| `audienceSnapshotId` | ObjectId | No | — | `audienceSnapshots` (COL-COM-33, T09) |
| `runKey` | String | No | único | — |
| `number` | String | Sistema | Número correlativo del boletín por tenant (según T05; numeración de T11). | — |

Índices `{tenantId, status, createdAt}`, único `{tenantId, runKey}`.

**`newsletterRecipients`** (COL-COM-19)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `newsletterId` | ObjectId | Sí | — | `newsletters` (COL-COM-18, T09) |
| `personId` | ObjectId | Sí | — | `persons` (COL-PER-01, M01) |
| `userId` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `fingerprint` | String | No | — | — |
| `postIds[]` | ObjectId[] | No | — | `posts` (COL-COM-01, T09) |
| `included` | Bool | No | — | — |
| `isExternal` | Bool | No | — | — |
| `canEmail` | Bool | No | — | — |
| `communicationIds[]` | ObjectId[] | No | — | `communications` (COL-COM-39, T09) |
| `deliveryStatus` | enum (estados de `communications`, §8.10) | No | — | — |
| `sentAt` | Date | No | — | — |
| `error` | String | No | — | — |

Único `{tenantId, newsletterId, personId}`. Separado de `newsletters` (CNX embebe) para soportar padrones de decenas de miles.

### 7.4 Encuestas, votaciones y consultas

**`surveys`** (CNX §7.3 `Survey` + extensiones de la cooperativa)

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `kind` | enum `survey`, `poll`, `consultation`, `field_form` | Sí | RF-COM-088, 089, 092. |
| `internalName`, `title`, `description`, `instructions`, `welcomeMessage`, `thanksMessage`, `aiContext` | String | `title` Sí | |
| `cover`, `gallery[]`, `video` | Media | No | |
| `status` | enum `draft`, `published`, `paused`, `closed`, `archived` | Sí | §8.5. |
| `purpose` | enum `satisfaction`, `quality`, `census`, `post_claim`, `post_installation`, `post_attention`, `consultation`, `poll`, `field`, `other` | Sí | |
| `trigger` | { `eventName` (ej. `tec.installation.activationConfirmed`), `serviceIds[]`, `operationTypeIds[]`, `delayMinutes`, `channelOrder[]`, `expiresAfterDays` } | No | Encuestas disparadas (RF-COM-084). |
| `questions[]` | ver subesquema CNX §7.3 (31 tipos, `required`, `options[]`, `optionItems[]`, `sensitive`, `locales`, `group`, `pageId`, `help`, `example`, `placeholder`, `allowOther`, `allowNA`, `allowPreferNot`, `scaleMin`, `scaleMax`, `likertPreset`, `validations`, `visibleIf`, `finishIf`, `askExplainIf`, `askFileIf`, `scoreMap`, `points`, `criticalAlert` { `enabled`, `op`, `value`, `message`, `action` (`none`,`crm_case`,`task`) }, `prefillFrom` (`email`,`phone`,`firstName`,`lastName`,`documentId`,`address`,`accountNumber`), `defaultValue`, `matrixRows[]`, `matrixColumns[]`, `formula`, `shuffleOptions`) | Sí (≥1 salvo `info`) | RF-COM-071–073. |
| `pages[]` | [{ `id`, `title`, `description` }] | No | |
| `surveyVersion` | Int | Sí | Incrementa al editar publicada (nueva versión, respuestas previas conservan la suya). |
| `versionHistory[]` | máx. 20 [{ `version`, `savedAt`, `authorName`, `questions`, `pages` }] | Sistema | RF-COM-080. |
| `audience` | AudienceDefinition | Sí | |
| `audienceSnapshotId` | ObjectId | Sistema | |
| `startsAt`, `endsAt`, `timezone` | Date, String | `startsAt` Sí al publicar | |
| `presentation` | { `questionFlow` (`all`,`one_by_one`,`pages`), `showProgress`, `allowBack`, `requireReview`, `allowEditAfterSubmit`, `allowMultiple`, `periodDays` } | Sí | |
| `anonymous` | Bool | Sí | RN-COM-049. |
| `voterUnit` | enum `person`, `member`, `account`, `user` | Sí para `poll`/`consultation` | PRM-COM-043. |
| `resultVisibility` | enum `on_vote`, `on_close`, `never` | Para `poll`/`consultation` | |
| `nonBindingNotice` | Bool (siempre `true` en `consultation`) | Sistema | RF-COM-089. |
| `consent` | { `enabled`, `text`, `version` } | No | |
| `scoring` | { `enabled`, `mode`, `showToRespondent`, `passThreshold`, `bands[]` } ; `thanksByBand[]` | No | |
| `reminders` | { `enabled`, `maxCount`, `intervalHours`, `excludeResponded`, `sentCount`, `lastSentAt`, `nextAt` } | No | |
| `reportSchedule` | { `enabled`, `everyDays`, `recipientUserIds[]`, `lastSentAt`, `nextAt` } | No | Destinatarios internos por usuario (no emails libres). |
| `periodic` | { `enabled`, `everyDays`, `nextOpenAt` } | No | |
| `sampling` | { `probabilityPct`, `mandatory`, `repeatable`, `repeatIntervalDays` } | No | RF-COM-093 (`ENCUESTAS.PROBABILIDAD/OBLIGATORIA/REPETIBLE/INTERVALO_REPITE`). |
| `external` | { `enabled`, `tokenKid`, `expiresAt`, `rateLimitPerIp`, `captchaAfter` } | No | RF-COM-081. |
| `printQr` | Bool | No | QR en factura (RF-COM-195). |
| `languages[]`, `defaultLanguage`, `webhookConnectorId`, `templateId`, `categoryId`, `tags[]`, `estimatedMinutes` | | No | |
| `exportAudit[]` | [{ `at`, `userId`, `format`, `includeRespondents` }] | Sistema | |
| `aiCache` | { `analysis`, `provider`, `model`, `basedOnAnswered`, `at` } | Sistema | Capa B (RF-COM-090). |
| `externalId` | String | No | Migración (`ENCUESTAS.ID_ENCUESTA`). |

Índices: `{tenantId, status, startsAt, endsAt}`; `{tenantId, kind, status}`; `{tenantId, trigger.eventName, status}`.

**`surveyResponses`** (CNX `SurveyResponse`) (COL-COM-21)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `surveyId` | ObjectId | Sí | — | `surveys` (COL-COM-20, T09) |
| `surveyVersion` | Int | No | — | — |
| `invitationId` | ObjectId | No | — | `surveyInvitations` (COL-COM-22, T09) |
| `fieldAssignmentId` | ObjectId | No | — | `tasks` (COL-WFL-28, T11) [VERIFICAR: asignación de formulario de campo; T05 no la declara] |
| `userId` | ObjectId | No | null si anónima o externa | `memberships` (COL-IAM-04, T02) |
| `personId` | ObjectId | No | null si anónima | `persons` (COL-PER-01, M01) |
| `respondentKey` | String | No | (anónima: HMAC(sal de encuesta, unidad de elector)) (antes `respondentHash`; nombre según T05) | — |
| `guestKey` | String | No | — | — |
| `guestLabel` | String | No | — | — |
| `answers[]` | Objeto[] | No | [{ `questionId`, `value`, `fileRefs[]` }] | — |
| `status` | enum `draft`, `submitted`, `invalidated` | Sí | — | — |
| `startedAt` | Date | No | — | — |
| `lastSavedAt` | Date | No | — | — |
| `submittedAt` | Date | No | — | — |
| `channel` | enum `pwa`, `landing_external`, `email_link`, `sms_link`, `whatsapp_link`, `qr_invoice`, `field` | Sí | — | — |
| `device` | Objeto | No | — | — |
| `attemptNumber` | Int | Sistema | — | — |
| `invalidReason` | String | No | — | — |
| `scoreTotal` | Int | Sistema | — | — |
| `scoreByGroup` | Objeto | Sistema | — | — |
| `scoreBand` | String | Sistema | — | — |
| `consentAcceptedAt` | Date | No | — | — |
| `consentVersion` | String | No | — | — |
| `alerts[]` | Objeto[] | No | [{ `questionId`, `message`, `action`, `crmCaseId` }] | — |
| `context` | Objeto | No | { `workOrderId`, `visitId`, `crmCaseId`, `contractId`, `serviceId`, `zoneId`, `branchId` } (para cruces de inteligencia) | — |
| `clientMutationId` | String | No | — | — |

Únicos: 1 borrador por (encuesta, usuario); 1 enviada por (encuesta, usuario | `respondentKey`) salvo `allowMultiple`; 1 por `guestKey`; 1 por `fieldAssignmentId`; parcial por `clientMutationId`. Índices con los nombres de T05 (antes `respondentHash` → `respondentKey`).

**`surveyInvitations`** (COL-COM-22)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `surveyId` | ObjectId | Sí | — | `surveys` (COL-COM-20, T09) |
| `personId` | ObjectId | No | — | `persons` (COL-PER-01, M01) |
| `userId` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `sourceEventId` | ObjectId | No | evento disparador | evento del outbox (`eventTypes`, COL-WFL-01, T11; id del evento) |
| `idempotencyKey` | String | Sí | = encuesta + evento + persona | — |
| `status` | enum `created`, `delivered`, `opened`, `responded`, `expired`, `cancelled` | Sí | — | — |
| `channels[]` | enum[] de canal (`email`, `sms`, `whatsapp`, `push`, `in_app`, …) | No | — | — |
| `communicationIds[]` | ObjectId[] | No | — | `communications` (COL-COM-39, T09) |
| `sampledIn` | Bool | No | Bool, semilla RN-COM-051 | — |
| `expiresAt` | Date | No | — | — |
| `remindersSent` | Int | Sistema | — | — |

Único `{tenantId, idempotencyKey}`.

**`surveyTemplates`** (CNX `SurveyTenantTemplate`) (COL-COM-23)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `name` | String | Sí | — | — |
| `kind` | enum | Sí | — | — |
| `purpose` | enum (valores de `surveys.purpose`) | No | — | — |
| `questions` | Objeto[] (subesquema de `surveys.questions`) | No | — | — |
| `pages` | Objeto[] | No | — | — |
| `scoring` | Objeto | No | — | — |
| `consent` | Objeto | No | — | — |
| `serviceIds[]` | ObjectId[] | No | — | `tenantServices` (COL-CAT-02, M02) |
| `platformTemplateId` | ObjectId | No | heredada | `surveyTemplates` (COL-COM-23, T09; fila del tenant `PLATFORM`) |
| `active` | Bool | No | — | — |
| `code` | String | Sí | Código único por tenant (según T05). | — |

**`surveyCategories`** (COL-COM-24)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `code` | String | Sí | (antes `key`; nombre según T05) | — |
| `name` | String | Sí | — | — |
| `color` | String | No | — | — |
| `order` | Int | No | — | — |
| `active` | Bool | No | — | — |

### 7.5 Eventos y beneficios

**`events`** (COL-COM-25)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `title` | String | Sí | — | — |
| `description` | String | No | — | — |
| `type` | enum `talk`, `training`, `institutional_act`, `assembly_info`, `street_closure`, `community_day`, `other` | No | — | — |
| `startsAt` | Date | No | — | — |
| `endsAt` | Date | No | — | — |
| `timezone` | String (zona IANA) | No | — | — |
| `location` | Objeto | No | { `mode` (`in_person`,`virtual`,`hybrid`), `addressId`, `addressText`, `geo`, `url` } | — |
| `capacity` | Int | No | — | — |
| `registrationMode` | enum `open`, `approval`, `none` | No | — | — |
| `maxCompanions` | Int | No | — | — |
| `waitlistEnabled` | Bool | No | — | — |
| `audience` | AudienceDefinition | No | — | — |
| `cover` | Media | No | — | — |
| `status` | enum `draft`, `published`, `cancelled`, `finished` | Sí | — | — |
| `reminders[]` | Objeto[] | No | [{ `offsetMinutes` }] | — |
| `postId` | ObjectId | No | — | `posts` (COL-COM-01, T09) |
| `changeLog[]` | Objeto[] | No | [{ `at`, `field`, `from`, `to` }] | — |
| `counters` | Objeto | Sistema | { `registered`, `waitlisted`, `checkedIn` } | — |
| `code` | String | Sí | Código único por tenant (según T05). | — |

Índices `{tenantId, status, startsAt}`.

**`eventRegistrations`** (COL-COM-26)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `eventId` | ObjectId | Sí | — | `events` (COL-COM-25, T09) |
| `personId` | ObjectId | Sí | — | `persons` (COL-PER-01, M01) |
| `userId` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `companions` | Int | No | — | — |
| `status` | enum `registered`, `pending_approval`, `waitlisted`, `cancelled`, `rejected`, `checked_in`, `no_show` | Sí | — | — |
| `waitlistPosition` | Int | Sistema | — | — |
| `qrToken` | String | No | firmado | — |
| `checkedInAt` | Date | No | — | — |
| `checkedInBy` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `clientMutationId` | String | No | — | — |

Único `{tenantId, eventId, personId}`.

**`benefitPartners`** (COL-COM-27)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `name` | String | Sí | — | — |
| `taxId` | String | No | opcional (No es referencia: CUIT del comercio (texto).) | — |
| `contact` | Objeto | No | — | — |
| `addressText` | String | No | — | — |
| `validatorUserIds[]` | ObjectId[] | No | — | `memberships` (COL-IAM-04, T02) |
| `validationLinkEnabled` | Bool | No | — | — |
| `active` | Bool | No | — | — |
| `code` | String | Sí | Código único por tenant (según T05). | — |

**`benefits`** (COL-COM-28)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `title` | String | Sí | — | — |
| `description` | String | No | — | — |
| `benefitPartnerId` | ObjectId | No | (antes `partnerId`; nombre según T05) | `benefitPartners` (COL-COM-27, T09) |
| `kind` | enum `percent_discount`, `fixed_discount`, `two_for_one`, `service`, `raffle`, `other` | Sí | — | — |
| `value` | Decimal128 | No | Decimal128, según tipo | — |
| `currency` | String (ISO 4217) | No | — | — |
| `conditions` | String | No | — | — |
| `validFrom` | Date | No | — | — |
| `validTo` | Date | No | — | — |
| `audience` | AudienceDefinition | No | elegibilidad; ej. `debtStatus.kinds=[none, notDue]` | — |
| `totalQuota` | Int | No | — | — |
| `perPersonQuota` | Int | No | — | — |
| `redemptionMode` | enum `unique_code`, `qr`, `generic_coupon` | No | — | — |
| `genericCode` | String | No | — | — |
| `cover` | Media | No | — | — |
| `status` | enum `draft`, `published`, `paused`, `expired`, `cancelled` | Sí | — | — |
| `counters` | Objeto | Sistema | { `issued`, `redeemed` } | — |
| `postId` | ObjectId | No | — | `posts` (COL-COM-01, T09) |
| `code` | String | Sí | Código único por tenant (según T05). | — |

Índices `{tenantId, status, validTo}`.

**`benefitRedemptions`** (COL-COM-29)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `benefitId` | ObjectId | Sí | — | `benefits` (COL-COM-28, T09) |
| `personId` | ObjectId | No | — | `persons` (COL-PER-01, M01) |
| `userId` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `code` | String | Sí | único por tenant, alfanumérico 8–10, sin caracteres ambiguos | — |
| `qrToken` | String | No | — | — |
| `status` | enum `issued`, `redeemed`, `expired`, `cancelled` | Sí | — | — |
| `issuedAt` | Date | No | — | — |
| `expiresAt` | Date | No | — | — |
| `redeemedAt` | Date | No | — | — |
| `redeemedBy` | ObjectId | No | usuario validador o `partner_link` | `memberships` (COL-IAM-04, T02) |
| `partnerId` | ObjectId | No | — | `benefitPartners` (COL-COM-27, T09) |

Únicos `{tenantId, code}`, `{tenantId, benefitId, personId, status}` parcial según cupo por persona.

### 7.6 Audiencias

**`audienceSegments`** (COL-COM-30)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `name` | String | Sí | — | — |
| `description` | String | No | — | — |
| `ownerUserId` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `visibility` | enum `private`, `shared` | No | — | — |
| `definition` | AudienceDefinition | No | AudienceDefinition sin `segmentId` recursivo | — |
| `evaluation` | enum `dynamic`, `snapshot` | No | — | — |
| `lastSnapshotId` | ObjectId | Sistema | — | `audienceSnapshots` (COL-COM-33, T09) |
| `lastCount` | Int | Sistema | — | — |
| `lastEvaluatedAt` | Date | Sistema | — | — |
| `active` | Bool | No | — | — |
| `code` | String | Sí | Código único por tenant (según T05). | — |

**`audienceImportLists`** (COL-COM-31)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `name` | String | Sí | — | — |
| `fileObjectKey` | String | No | — | — |
| `matchBy` | enum | No | `documentId`, `cuit`, `accountNumber`, `memberNumber`, `email`, `phone` (no es referencia; el ER la dibuja como FK a `memberships` por error) | — |
| `rowsTotal` | Int | Sistema | — | — |
| `rowsMatched` | Int | Sistema | — | — |
| `rowsUnmatched` | Int | Sistema | — | — |
| `status` | enum `uploaded`, `validated`, `confirmed`, `discarded` | Sí | — | — |
| `importedBy` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `confirmedAt` | Date | No | — | — |

**`audienceImportRows`** (COL-COM-32)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `listId` | ObjectId | Sí | — | `audienceImportLists` (COL-COM-31, T09) |
| `rowNumber` | Int | No | — | — |
| `raw` | Objeto | No | hash + campos de cruce | — |
| `personId` | ObjectId | No | — | `persons` (COL-PER-01, M01) |
| `accountId` | ObjectId | No | — | `accounts` (COL-PER-05, M01) |
| `matchStatus` | enum `matched`, `unmatched`, `ambiguous`, `duplicate` | No | — | — |
| `error` | String | No | — | — |

Índice `{tenantId, listId, matchStatus}`.

**`audienceSnapshots`** (COL-COM-33)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `ownerType` | enum `post`, `survey`, `newsletter`, `campaign`, `event`, `benefit`, `outageNotice`, `segment` | No | — | — |
| `ownerId` | ObjectId | No | — | referencia polimórfica según `ownerType` (`posts`, `surveys`, `newsletters`, `campaigns`, `events`, `benefits`, `outageNotices`, `audienceSegments`; T09) |
| `definitionHash` | String | No | — | — |
| `definition` | AudienceDefinition | No | copia | — |
| `grantHash` | String | No | — | — |
| `capturedAt` | Date | No | — | — |
| `counts` | Objeto | Sistema | { `persons`, `accounts`, `serviceContracts`, `byChannel` { canal → Int }, `excludedByReason` { `no_contact`, `opt_out`, `suppressed`, `quiet_hours`, `sanction`, `outside_grant`, `sensitive_filter`, `deduplicated` → Int } } | — |
| `estimatedCost` | Objeto[] | Sistema | [{ `channel`, `amount` (Decimal128), `currency` }] | — |
| `segmentId` | ObjectId | No | Segmento evaluado cuando `ownerType = segment` o la audiencia usa `mode = segment` (según T05). | `audienceSegments` (COL-COM-30, T09) |

**`audienceSnapshotMembers`** (COL-COM-34)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `snapshotId` | ObjectId | Sí | — | `audienceSnapshots` (COL-COM-33, T09) |
| `personId` | ObjectId | No | — | `persons` (COL-PER-01, M01) |
| `accountId` | ObjectId | No | — | `accounts` (COL-PER-05, M01) |
| `contractId` | ObjectId | No | — | `serviceContracts` (COL-CAT-18, M02) |
| `userId` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `resolvedChannels[]` | enum[] de canal (`email`, `sms`, `whatsapp`, `push`, `in_app`, …) | No | — | — |
| `excludedReason` | enum | No | — | — |

Índice `{tenantId, snapshotId, personId}` único por unidad.

### 7.7 Motor de comunicaciones

**`communicationTypes`** (catálogo, RF-COM-131; filas de plataforma con `tenantId = PLATFORM` heredadas y sobrescribibles)

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `code` | String (`<modulo>.<entidad>.<hecho>`; ej. `fac.invoice.issued`) | Sí | Único por tenant. |
| `name`, `description` | `dict:` | Sí | |
| `module` | String (`fac`, `cob`, …) | Sí | Emisor. |
| `triggerEvents[]` | String[] (EVT-ID y nombre) | No | Vacío = solo por comando. |
| `purpose` | enum `security`, `regulatory`, `transactional`, `operational`, `service_outage`, `community`, `marketing` | Sí | |
| `audienceKind` | enum `member`, `employee`, `supplier`, `platform_admin`, `public` | Sí | |
| `allowedChannels[]`, `defaultChannels[]`, `fallbackOrder[]` | enum de canal | Sí | |
| `optOut` | enum `never`, `channel_only` (al menos uno activo), `full` | Sí | RF-COM-171. |
| `quietHoursExempt` | Bool | Sí | RN-COM-054. |
| `priority` | enum `critical`, `high`, `normal`, `low` | Sí | Cola BullMQ por prioridad. |
| `sendWindow` | { `notBefore`, `notAfter`, `businessDaysOnly` } | No | |
| `ttlHours` | Int | No | Pasado el TTL → `expired`. |
| `requiredMilestone` | enum `accepted`, `delivered`, `read`, `physical_ack`, `none` | Sí | RF-COM-182. |
| `evidenceRequired` | Bool | Sí | Genera constancia PDF. |
| `notifKind` | String | Sí | §5.13. |
| `deepLink` | plantilla de ruta (`/app/facturas/{{factura.id}}`) | No | |
| `recipientRule` | enum `account_contact`, `person_contact`, `portal_contact`, `all_mobiles`, `internal_role`, `explicit` | Sí | RF-COM-139 (V2 2824, 3121). |
| `grouping` | enum `none`, `byAccount`, `byHolder`, `byHolderAndPhone` | No | RF-COM-147. |
| `templateIds` | mapa canal → `messageTemplates._id` | Sí por canal por defecto | |
| `status` | enum `active`, `inactive` | Sí | `inactive` solo si `optOut ≠ never` y la finalidad no es `security`/`regulatory`. |
| `platformTypeId`, `overridden` | ObjectId, Bool | No | Herencia. |

Índice único `{tenantId, code}`.

**`messageTemplates`** (cabecera) (COL-COM-36)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `communicationTypeId` | ObjectId | Sí | Tipo de comunicación. Las plantillas de campaña o de texto libre, que antes usaban los valores `campaign`/`free` en este campo, quedan sin tipo y se distinguen por `channel` y por su uso en `campaigns` [VERIFICAR] (antes `communicationTypeCode`; nombre según T05) | `communicationTypes` (COL-COM-35, T09) |
| `channel` | enum | Sí | — | — |
| `locale` | String | Sí | `es-AR` default | — |
| `name` | String | Sí | — | — |
| `currentVersionId` | ObjectId | No | — | `messageTemplateVersions` (COL-COM-37, T09) |
| `status` | enum `active`, `retired` | Sí | — | — |
| `platformTemplateId` | ObjectId | No | — | `messageTemplates` (COL-COM-36, T09; fila del tenant `PLATFORM`) |
| `whatsapp` | Objeto | No | { `providerTemplateName`, `category` (`utility`, `marketing`, `authentication`), `language`, `approvalStatus` (`draft`, `submitted`, `approved`, `rejected`, `paused`, `disabled`), `syncedAt`, `positionalMap[]` [{ `position`, `variablePath` }] } | — |
| `code` | String | Sí | Código único por tenant (según T05). | — |

Único `{tenantId, communicationTypeId, channel, locale}`. Origen: `PLANTILLA`, `PLANTILLA_WSP`, `VARIABLES_PLANTILLA_WSP`, `MailTemplates`, `CIRCULAR` (texto), `CIRCUPRO`. Índices con los nombres de T05 (antes `communicationTypeCode` → `communicationTypeId`).

**`messageTemplateVersions`** (COL-COM-37)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `templateId` | ObjectId | Sí | — | `messageTemplates` (COL-COM-36, T09) |
| `versionNumber` | Int | Sí | — | — |
| `status` | enum `draft`, `published`, `retired` | Sí | — | — |
| `subject` | String | No | email | — |
| `preheader` | String | No | — | — |
| `bodyHtml` | String (bloques) | No | email; bloques | — |
| `bodyText` | String | No | SMS/WhatsApp/push/in-app/texto alternativo del email | — |
| `title` | String | No | push/in-app | — |
| `imageRef` | String (objeto privado) | No | — | — |
| `attachments[]` | Objeto[] | No | [{ `kind` (`invoice_pdf`, `receipt_pdf`, `notice_pdf`, `static_file`), `source` (módulo dueño), `mode` (`attach`, `signed_link`) }] | — |
| `variablesUsed[]` | String[] | Sistema | validadas contra `templateVariables` | — |
| `themeVersion` | String (versión de tema T03) | No | T03 | — |
| `dictionaryVersion` | String | No | — | — |
| `smsStats` | Objeto | Sistema | { `encoding` (`GSM7`/`UCS2`), `chars`, `segments` } | — |
| `publishedAt` | Date | No | — | — |
| `publishedBy` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `changeNote` | String | No | — | — |

Único `{tenantId, templateId, versionNumber}`. Inmutable una vez publicada.

**`templateVariables`** (registro tipado, RF-COM-134; base de plataforma + extensiones del tenant) (COL-COM-38)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `key` | String (ruta de la variable) | Sí | ej. `factura.vencimiento1` (antes `path`; nombre según T05) | — |
| `label` | String (`dict:`) | No | — | — |
| `type` | enum `text`, `money`, `date`, `datetime`, `link`, `list`, `number`, `boolean` | No | — | — |
| `format` | String (patrón; ej. `money:ARS:2`, `date:dd-mm-yyyy`) | No | — | — |
| `providerModule` | String (código de módulo) | No | — | — |
| `example` | String | No | — | — |
| `nullPolicy` | enum `empty`, `default`, `omit_line`, `block_send` | No | — | — |
| `defaultValue` | String | No | — | — |
| `sensitive` | Bool | No | Bool: nunca en SMS/WhatsApp/push | — |
| `communicationTypeCodes[]` | String[] | No | en qué tipos está disponible | — |
| `legacy` | Objeto | No | subdocumento de T05 §19.1: `table` = `VARIABLEPLANT` o `VARIABLES_PLANTILLA_WSP`, `key` = código de la variable, `displayKey` = nombre; antes `{ vplCode, vplName }`, CTR-DAT-32 | — |
| `wspPosition` | Int | No | posición del parámetro en la plantilla WhatsApp de origen | — |

Único `{tenantId, key}`. Origen: `VARIABLEPLANT`, `VARIABLES_PLANTILLA_WSP`. Índices con los nombres de T05 (antes `path` → `key`).

**`communications`** — un envío por destinatario y canal (la constancia)

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `communicationTypeCode` | String | Sí | |
| `purpose` | enum | Sí | Copia del tipo al crear. |
| `origin` | { `kind` (`event`, `command`, `campaign`, `newsletter`, `manual`, `survey`, `system`), `eventId`, `eventName`, `module`, `businessRef` { `type`, `id` } (ej. `invoice`, `noticeId`), `campaignId`, `requestedBy` } | Sí | |
| `recipient` | { `personId`, `accountId`, `userId`, `supplierId`, `contactPointId`, `address` (email/E.164 enmascarable), `displayName` } | Sí | |
| `channel` | enum de canal | Sí | |
| `templateVersionId`, `templateVersionNumber` | ObjectId, Int | Sí (salvo texto libre) | |
| `render` | { `subject`, `title`, `bodyText`, `bodyHtmlRef` (objeto privado), `variablesHash`, `variablesSnapshotRef` (objeto privado cifrado), `contentHash` (SHA-256), `dictionaryVersion`, `segments` } | Sí | RN-COM-060. |
| `attachments[]` | [{ `objectKey`, `sha256`, `mode` }] | No | |
| `status` | enum §8.10 | Sí | |
| `statusHistory[]` | [{ `status`, `at`, `source` (`system`, `provider`, `user`), `detail` }] | Sistema | |
| `failureClass` | enum `hard`, `soft`, `blocked`, `invalid`, `policy` | No | |
| `providerConnectorId`, `providerMessageId` | | No | |
| `priority`, `scheduledFor`, `expiresAt` | | Sí | |
| `attemptCount` | Int | Sistema | |
| `fallback` | { `fromCommunicationId`, `toCommunicationId`, `reason` } | No | Alternativa de canal. |
| `milestone` | { `required`, `reachedAt`, `notifiedAt` } | Sistema | |
| `idempotencyKey` | String | Sí | RF-COM-145. |
| `costEstimate`, `costActual` | Decimal128 + `currency` | No | |
| `proofDocumentRef` | objeto privado (PDF de constancia) | No | |
| `environment` | enum `production`, `sandbox` | Sí | RN-COM-061. |
| `legalHold` | Bool | No | Bloquea purga (caso judicial). |

Índices: único `{tenantId, idempotencyKey}`; `{tenantId, recipient.personId, createdAt}`; `{tenantId, recipient.accountId, createdAt}`; `{tenantId, origin.businessRef.type, origin.businessRef.id}`; `{tenantId, origin.campaignId, status}`; `{tenantId, status, scheduledFor}`; `{tenantId, providerMessageId}`. Origen: `AUDIT_MAIL`, `MENSAJES`, `SENDMAIL`, `PROMAIL` (no internos).

**`communicationAttempts`** (COL-COM-40)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `communicationId` | ObjectId | Sí | — | `communications` (COL-COM-39, T09) |
| `attemptNumber` | Int | Sistema | — | — |
| `connectorId` | ObjectId | No | — | `integrationConnections` (COL-INT-02, T06) |
| `startedAt` | Date | No | — | — |
| `finishedAt` | Date | No | — | — |
| `result` | enum `accepted`, `rejected`, `timeout`, `error` | No | — | — |
| `providerCode` | String | No | — | — |
| `providerMessage` | String | No | — | — |
| `retryable` | Bool | No | — | — |
| `nextRetryAt` | Date | No | — | — |
| `intOperationId` | ObjectId | No | T06 | `integrationOperations` (COL-INT-06, T06) |

Índice `{tenantId, communicationId, attemptNumber}` único. Origen: `ENVIOS`, `RESULTADOS`.

**`communicationEvents`** (COL-COM-41)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `communicationId` | ObjectId | Sí | — | `communications` (COL-COM-39, T09) |
| `providerMessageId` | String | No | (identificador externo del proveedor, no es referencia) | — |
| `kind` | enum `accepted`, `delivered`, `read`, `opened`, `clicked`, `bounced_hard`, `bounced_soft`, `complained`, `unsubscribed`, `failed` | Sí | — | — |
| `occurredAt` | Date | No | — | — |
| `receivedAt` | Date | Sistema | — | — |
| `providerEventId` | String | Sí | deduplicación (identificador externo del proveedor, no es referencia) | — |
| `payloadRef` | String (objeto privado) | No | — | — |
| `linkId` | ObjectId | No | — | `trackedLinks` (COL-COM-42, T09) |
| `provider` | String | Sí | Proveedor que emitió el evento (`ses`, `meta_cloud`, `trii`, …); forma con `providerEventId` el único de T05. | — |

Único `{tenantId, providerEventId}`.

**`trackedLinks`** (COL-COM-42)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `communicationId` | ObjectId | Sí | — | `communications` (COL-COM-39, T09) |
| `campaignId` | ObjectId | No | — | `campaigns` (COL-COM-47, T09) |
| `code` | String | Sí | acortador propio, único global por dominio corto (antes `slug`; nombre según T05) | — |
| `targetUrl` | String (URL) | No | lista blanca de dominios del tenant y de la plataforma | — |
| `clicks` | Int | Sistema | — | — |
| `firstClickAt` | Date | Sistema | — | — |

Índice único `{code}` (colección técnica con `tenantId`). Índices con los nombres de T05 (antes `slug` → `code`).

**`senderIdentities`** (RN-COM-020; reemplaza `CORREOS_INTERNOS`) (COL-COM-43)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `channel` | enum `email`, `sms`, `whatsapp` | Sí | — | — |
| `name` | String | Sí | — | — |
| `module` / `purpose` | String (código de módulo) | No | asignación | — |
| `fromName` | String | No | V2 709 / PRM-COM-P1-001 | — |
| `fromAddress` / `senderId` | String | No | (SMS alfanumérico ≤11, V2 2812 / PRM-COM-P1-003) o `phoneNumberId` (WhatsApp) | — |
| `replyTo` | String (email) | No | — | — |
| `connectorId` | ObjectId | No | T06; las credenciales viven en bóveda | `integrationConnections` (COL-INT-02, T06) |
| `verificationStatus` | enum `pending`, `verified`, `failed` | No | — | — |
| `default` | Bool | No | Bool por canal | — |
| `address` | String | Sí | Dirección o remitente normalizado del canal (email, alfanumérico SMS o número WhatsApp); forma el único `{channel, address}` de T05. Agrupa `fromAddress`/`senderId`. | — |
| `credentialRef` | String (ref. bóveda) | No | Credencial propia del remitente cuando no la aporta la conexión (según T05). | `integrationSecrets` (COL-INT-03, T06) |

Índice `{tenantId, channel, module}`.

**`channelSettings`** — una por tenant y canal (COL-COM-44)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `enabled` | Bool | No | V2 2693 / PRM-COM-P1-004 para SMS | — |
| `connectionId` | ObjectId | No | (antes `connectorId`; nombre según T05) | `integrationConnections` (COL-INT-02, T06) |
| `providerKind` | enum (por canal) | No | email: `ses`, `smtp`; SMS: `sns`, `gateway_api`; WhatsApp: `meta_cloud`, `trii`; push: `webpush` | — |
| `throttle` | Objeto | No | { `perSecond`, `batchSize`, `batchPauseSec` } | — |
| `maxAttempts` | Int | No | — | — |
| `ttlHours` | Int | No | — | — |
| `circuitBreaker` | Objeto | No | { `errorThreshold`, `windowSec`, `cooldownSec` } | — |
| `quietHours` | Objeto | No | { `from`, `to`, `days[]`, `holidays` } | — |
| `dailyCapPerRecipient` | Int | No | — | — |
| `monthlyBudget` | Decimal128 | No | Decimal128 | — |
| `bccForBulk[]` | String[] (email) | No | V2 2904 | — |
| `allowEditTemplateOnSingleSend` | Bool | No | V2 2884 | — |
| `smsMaxChars` | Int | No | V2 2745 | — |
| `whatsappSessionOnlyFromCrm` | Bool | No | — | — |
| `health` | Objeto | Sistema | { `status`, `lastCheckAt`, `lastError` } | — |
| `channel` | enum `email`, `sms`, `whatsapp`, `push`, `ivr_export` | Sí | Canal; único por tenant (según T05). | — |

Único `{tenantId, channel}`. Origen: `CORREOS_INTERNOS`, `MODEMS` (desactivación por errores → circuit breaker), V2 2047–2049, 404, 461, 2626, 2872.

**`messagingUsage`** (COL-COM-45)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `period` | String (`yyyymm`) | No | — | — |
| `dayKey` | String (`yyyymmdd`) | Sí | — | — |
| `channel` | enum | Sí | — | — |
| `purpose` | enum de finalidad (§3) | Sí | — | — |
| `module` | String (código de módulo) | No | — | — |
| `communicationTypeCode` | String | Sí | — | — |
| `count` | Int | Sistema | — | — |
| `segments` | Int | Sistema | SMS | — |
| `conversations` | Int | Sistema | WhatsApp por categoría | — |
| `costAmount` | Decimal128 | Sistema | Decimal128 | — |
| `currency` | String (ISO 4217) | No | — | — |

Único `{tenantId, dayKey, channel, purpose, communicationTypeCode}`. Consumido por T01 (licencias/consumo).

**`internalNotificationRules`** (RF-COM-183; reemplaza `RESPONSA_NOTIFICA`) (COL-COM-46)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `name` | String | Sí | — | — |
| `communicationTypeCode` | String | No | — | — |
| `filters` | Objeto | No | { `serviceIds[]`, `operationTypeIds[]`, `workOrderTypeIds[]`, `operationIds[]`, `branchIds[]`, `zoneIds[]` } | — |
| `moment` | enum `on_create`, `on_dispatch`, `on_close`, `on_status` | No | — | — |
| `recipients` | Objeto | No | { `userIds[]`, `roleIds[]`, `crewIds[]`, `areaIds[]` } | `memberships` (COL-IAM-04, T02), `roles` (COL-IAM-05, T02), cuadrillas (M10), áreas (T04) |
| `channels[]` | enum[] de canal (`email`, `sms`, `whatsapp`, `push`, `in_app`, …) | No | — | — |
| `schedule` | Objeto | No | { `weekdays[]`, `from`, `to`, `includeHolidays` } | — |
| `active` | Bool | No | — | — |
| `code` | String | Sí | Código único por tenant (según T05). | — |

Índice `{tenantId, communicationTypeCode, active}`.

### 7.8 Campañas y mensajes en factura

**`campaigns`**

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `name`, `description` | String | Sí | |
| `purpose` | enum `community`, `marketing`, `operational`, `service_outage` | Sí | |
| `audience` | AudienceDefinition | Sí | |
| `channels[]` | [{ `channel`, `order`, `templateVersionId` o `adhocContentVersion` }] | Sí | |
| `adhocContent` | { `versions[]` [{ `n`, `subject`, `title`, `bodyText`, `bodyHtmlRef`, `createdAt` }] } | No | Contenido versionado propio. |
| `abTest` | { `enabled`, `variants[]` [{ `key`, `subject` }], `testPct`, `winnerMetric` (`open_rate`), `decideAfterMinutes`, `winnerKey` } | No | RF-COM-194. |
| `link` | { `targetType` (`screen`, `post`, `survey`, `event`, `benefit`, `document`, `url`), `targetId`, `url` } | No | |
| `schedule` | { `mode` (`now`, `at`, `recurring`), `at`, `rrule`, `timezone`, `window` { `from`, `to` } } | Sí | |
| `throttleOverride` | { `perSecond`, `batchSize` } | No | ≤ límites del canal. |
| `costCap` | Decimal128 + `currency` | No | Detiene al alcanzar. |
| `testRecipients[]` | userIds internos | No | |
| `status` | enum §8.11 | Sí | |
| `approval` | { `required`, `reasons[]` (`purpose`, `size`, `cost`), `wflRequestId`, `decidedBy`, `decidedAt`, `note` } | No | |
| `audienceSnapshotId` | ObjectId | Sistema | |
| `metrics` | { `snapshot`, `excludedByReason`, `queued`, `sent`, `accepted`, `delivered`, `opened`, `uniqueClicks`, `totalClicks`, `bouncedHard`, `bouncedSoft`, `complaints`, `unsubscribes`, `failed`, `costActual` } por canal y total | Sistema | RF-COM-193. |
| `runs[]` | [{ `runKey`, `startedAt`, `finishedAt`, `status` }] | Sistema | Recurrentes. |

Índices `{tenantId, status, schedule.at}`, `{tenantId, purpose, createdAt}`.

**`invoiceMessages`** (canal `print_invoice`, RF-COM-195) (COL-COM-48)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `campaignId` | ObjectId | No | opcional | `campaigns` (COL-COM-47, T09) |
| `text` | String | No | ≤ PRM-COM-047 caracteres | — |
| `area` | enum `header`, `body`, `footer`, `back` | No | — | — |
| `priority` | Int | No | — | — |
| `audience` | AudienceDefinition | No | — | — |
| `serviceIds[]` | ObjectId[] | No | — | `tenantServices` (COL-CAT-02, M02) |
| `billingPeriods[]` / `validFrom` / `validTo` | String[] (`yyyymm`) / Date / Date | No | — | — |
| `qr` | Objeto | No | { `targetType`, `targetId` } | — |
| `status` | enum `draft`, `approved`, `active`, `expired`, `cancelled` | Sí | — | — |
| `approvedBy` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `code` | String | Sí | Código único por tenant (según T05). | — |
| `segmentId` | ObjectId | No | Segmento guardado usado como audiencia (alternativa a `audience`, según T05). | `audienceSegments` (COL-COM-30, T09) |

Índice `{tenantId, status, validFrom, validTo}`. M05 consulta `GET /api/internal/com/invoice-messages/resolve` por comprobante. Origen: leyendas de `CIRCULAR`.

### 7.9 Preferencias, consentimientos y supresión

**`communicationPreferences`** (COL-COM-49)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `personId` | ObjectId | Sí | — | `persons` (COL-PER-01, M01) |
| `userId` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `byPurpose` | Objeto | No | { finalidad → { `channels` { canal → Bool }, `preferredChannel` } } | — |
| `byType` | Objeto | No | excepciones por `communicationTypeCode` | — |
| `locale` | String | No | — | — |
| `quietHours` | Objeto | No | { `from`, `to` } | — |
| `newsletterMaxPerWeek` | Int | No | — | — |
| `invoiceDigital` | Objeto | No | { `enabled`, `channels[]`, `since` } (RF-COM-174) | — |
| `updatedVia` | enum `pwa`, `admin`, `import`, `keyword`, `unsubscribe_link` | No | — | — |

Único `{tenantId, personId}`.

**`consentRecords`** — **Reemplazado por `consentRecords` de T08 (CTR-DAT-18 de T05; COL-COM-50 absorbida en COL-NFR-04).** T09 no crea la colección: registra cada alta o baja de consentimiento por el servicio de privacidad de T08, que debe admitir los campos de canal y finalidad descritos a continuación, y lee de allí las preferencias vigentes. Esquema que T09 necesita (inmutable, RF-COM-172): `personId`, `contactPointId`, `address` (hash + enmascarado), `channel`, `purpose`, `action` (`opt_in`, `opt_out`), `source` (`portal`, `counter`, `import`, `keyword_stop`, `unsubscribe_link`, `migration`, `admin`), `textShown`, `textVersion`, `ipHash`, `userAgent`, `actorUserId`, `occurredAt`, `evidenceRef`. Índice `{tenantId, personId, channel, purpose, occurredAt}`.

**`suppressionEntries`** (COL-COM-51)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `channel` | enum | Sí | — | — |
| `addressHmac` | String | Sí | (antes `addressHash`; nombre según T05) | — |
| `addressMasked` | String | No | — | — |
| `reason` | enum `hard_bounce`, `invalid_number`, `complaint`, `unsubscribe_all`, `court_order`, `manual`, `carrier_block` | No | — | — |
| `sourceCommunicationId` | ObjectId | No | — | `communications` (COL-COM-39, T09) |
| `since` | Date | No | — | — |
| `until` | Date | No | null = indefinido | — |
| `status` | enum `active`, `lifted` | Sí | — | — |
| `liftedBy` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `liftEvidenceRef` | String (objeto privado) | No | — | — |

Único `{tenantId, channel, addressHmac, status:active}`. Índices con los nombres de T05 (antes `addressHash` → `addressHmac`).

### 7.10 Bandeja in-app, push y avisos de plataforma

**`appNotifications`** (CNX `AppNotification`, RF-COM-138) (COL-COM-52)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `membershipId` | ObjectId | Sí | (antes `userId`; nombre según T05) | `memberships` (COL-IAM-04, T02) |
| `personId` | ObjectId | No | — | `persons` (COL-PER-01, M01) |
| `kind` | enum | Sí | clave de `notifKinds` | — |
| `title` | String | Sí | — | — |
| `body` | String | No | — | — |
| `link` | String | No | ruta interna | — |
| `image` | Media | No | — | — |
| `refType` | String | No | — | — |
| `refId` | ObjectId | No | — | referencia polimórfica según `refType` (objeto del módulo emisor) |
| `senderUserId` | ObjectId | No | — | `memberships` (COL-IAM-04, T02) |
| `senderDisplay` | String | No | — | — |
| `communicationId` | ObjectId | No | — | `communications` (COL-COM-39, T09) |
| `readAt` | Date | No | — | — |
| `dismissedAt` | Date | No | — | — |
| `actionPending` | Bool | No | — | — |
| `validUntil` | Date | No | — | — |
| `dedupeKey` | String | No | — | — |

Índices `{tenantId, membershipId, dismissedAt, createdAt}`, `{tenantId, membershipId, readAt}`, único parcial `{tenantId, membershipId, dedupeKey}`, TTL sobre `purgeAt`. Origen: `NOTI_COOP`, `PROMAIL` tipo notificación. Índices con los nombres de T05 (antes `userId` → `membershipId`).

**`pushSubscriptions`** (COL-COM-53)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `membershipId` | ObjectId | Sí | (antes `userId`; nombre según T05) | `memberships` (COL-IAM-04, T02) |
| `endpointHash` | String (hash) | Sí | hash único (antes `endpoint`; nombre según T05) | — |
| `keys` | Objeto (cifrado) | No | cifradas | — |
| `device` | Objeto | No | { `ua`, `platform` } | — |
| `createdAt` | Date | No | — | — |
| `lastSuccessAt` | Date | Sistema | — | — |
| `failures` | Int | Sistema | — | — |
| `status` | enum `active`, `expired` | Sí | — | — |
| `endpoint` | String (cifrado) | Sí | URL del servicio push, cifrada; necesaria para enviar. | — |

Único `{tenantId, endpointHash}`. Reemplaza `User.pushSubscriptions[]` de CNX.

**`platformNotices`** (tenant `PLATFORM`; RF-COM-204) (COL-COM-54)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `kind` | enum `maintenance`, `release`, `product_news`, `survey`, `incident` | Sí | — | — |
| `title` | String | Sí | — | — |
| `body` | String | No | — | — |
| `targetTenants` | String (`all`) u ObjectId[] | No | `all` o lista, por plan | — |
| `targetRoles[]` | String[] (códigos de rol T02) | No | — | — |
| `permanence` | enum `pinned_1d`, `normal_5d`, `long_20d` | No | — | — |
| `startsAt` | Date | No | — | — |
| `endsAt` | Date | No | — | — |
| `surveyId` | ObjectId | No | — | `surveys` (COL-COM-20, T09) |
| `status` | enum | Sí | — | — |

**`platformNoticeReads`** (COL-COM-55)

| Campo | Tipo | Oblig. | Descripción | Referencia |
|---|---|---|---|---|
| `noticeId` | ObjectId | Sí | — | `platformNotices` (COL-COM-54, T09) |
| `tenantId` | ObjectId | Sí | (tenant lector; la colección es de plataforma) | `tenants` (COL-PLA-01, T01) |
| `membershipId` | ObjectId | No | (antes `userId`; nombre según T05) | `memberships` (COL-IAM-04, T02) |
| `readAt` | Date | No | — | — |

Origen: `RSSFEED`, `clsRss`, panel de noticias de `Inicio_ProCoop`, `ENCUESTAS`/`RESPUESTAS` (proveedor → cooperativa).

### 7.11 Avisos de interrupción

**`outageNotices`** (RF-COM-160)

| Campo | Tipo | Oblig. | Descripción |
|---|---|---|---|
| `kind` | enum `scheduled`, `unscheduled` | Sí | |
| `serviceIds[]` | ObjectId[] | Sí | |
| `reason` | String + `reasonCode` | Sí | |
| `area` | { `zoneIds[]`, `localityIds[]`, `streetSegments[]` [{ `streetId`, `fromNumber`, `toNumber` }], `networkNodeIds[]`, `polygon` (GeoJSON) } | Sí (≥1) | |
| `window` | { `startsAt`, `estimatedEndAt`, `actualStartAt`, `restoredAt` } | Sí | |
| `status` | enum `draft`, `published`, `in_progress`, `restored`, `cancelled`, `rescheduled` | Sí | §8.12. |
| `source` | { `kind` (`manual`, `tec_outage_plan`, `crm_incident`, `tec_device_down`), `refId` } | Sí | |
| `publishOn` | { `wall`, `landing`, `strip` } | Sí | |
| `postId`, `audienceSnapshotId` | ObjectId | Sistema | |
| `notifyChannels[]` | enum de canal | Sí | |
| `affected` | { `persons`, `accounts`, `serviceContracts`, `criticalCount` } | Sistema | `criticalCount`: electrodependientes, solo número (RF-COM-163). |
| `minNoticeHoursApplied`, `lateNoticeAcknowledgedBy` | Int, ObjectId | No | RF-COM-162. |
| `updates[]` | [{ `at`, `text`, `notified` }] | No | |
| `rescheduledFromId` | ObjectId | No | |

Índices `{tenantId, status, window.startsAt}`, `{tenantId, source.kind, source.refId}` único parcial.

### 7.12 Mapeo de tablas ProCoop (CAT §31 y relacionadas) a colecciones

| Tabla ProCoop | Colección destino | Observación |
|---|---|---|
| `AUDIT_MAIL` | `communications` (+ `communicationAttempts`) | Cola y auditoría de mails; estados 1/2/3/4 → §8.10 (RN-COM-014). |
| `CIRCUPRO` | `messageTemplates` (tipo `cmp.supplier.circular`) | Circulares a proveedores. |
| `CORREOS_INTERNOS` | `senderIdentities` + bóveda T06 | `PASS` no se migra en claro (RN-COM-019). |
| `ENCUESTAS` | `surveys` (y `platformNotices` si el origen es el proveedor) | `PROBABILIDAD`, `OBLIGATORIA`, `REPETIBLE`, `INTERVALO_REPITE` → `sampling`. |
| `ENVIOS` | `communicationAttempts` | |
| `IVR` | `channelSettings` (canal `ivr_export`) | Intentos, franja, día de aviso como parámetros de exportación. |
| `MENSAJES` | `communications` (canal `sms`/`whatsapp`) | `CATEGO`, `PLANTILLA`, lote → `origin`. |
| `MODEMS` | — (`Reemplazado por` circuit breaker de `channelSettings`) | PA-CFG-P4-01 (A: sin módem). |
| `NOTI_COOP` | `appNotifications` | Vigencia `FEC_FIN`. |
| `PLANTILLA` | `messageTemplates` + `messageTemplateVersions` | `TIPO`/`MODULO`/`DESTINO` → tipo de comunicación y canal; `REPORTE` → adjunto. |
| `PLANTILLA_WSP` | `messageTemplates.whatsapp` | |
| `PROMAIL` | `appNotifications` (tipos 1–3) / descartado el correo libre interno | RF-COM-205. |
| `RESPUESTAS` | `surveyResponses` | |
| `RESULTADOS` | catálogo de `failureClass` + `communicationAttempts.providerCode` | |
| `SENDMAIL` | `communications` | |
| `TELEFON` | — (`Reemplazado por` M01 contactos / proveedores M12) | Agenda telefónica: no es dato de COM; se migra a M01/M12 si corresponde. |
| `VARIABLEPLANT` | `templateVariables` | `COD_VPL_CALCULO`/`TIPOCALCULO` → variables calculadas por el módulo proveedor. |
| `VARIABLES_PLANTILLA_WSP` | `messageTemplates.whatsapp.positionalMap` | |
| `CIRCULAR` (M08) | Modelos de aviso de M08 que referencian `messageTemplates`; leyendas → `invoiceMessages` | |
| `RESPONSA_NOTIFICA` | `internalNotificationRules` | |
| `TRANSAC.ENVIO_SMS`, `COD_PLA_ALTA`, `COD_PLA_CONFIRM` | Configuración de operación en M10 + `communicationTypes` `tec.workOrder.*` | RF-COM-184. |
| `RUB_REC.EMAIL` | `internalNotificationRules` (destinatarios por rubro de reclamo, M09) | |
| `VIAINGTE` | M01/M19 (validación de contacto) | COM solo envía el código. |
| `ADHSOC` | `communicationPreferences.invoiceDigital` | Adhesiones. |
| `SU_NOTIFICACIONES` | `communicationTypes` `sue.*` + `communications` | |
| `ACT_AREAS`/`ACT_TIPOS`/`ACTIV` | `internalNotificationRules` (destinatarios extra del área) | Actividades de M09. |
| `TICKETS_ESTADOS.ENVIARMAIL` | `communicationTypes` `crm.case.statusChanged` / `pla.supportCase.updated` con filtro por estado | |
| `RSSFEED`, `WEB_NOVEDADES` | `platformNotices`, `posts` | |
| `WS_USERS` | — (referencia; usuarios del portal en T02/M19) | |
