# Mapeo screenId → casos de uso (núcleo export). Ampliar al regenerar inventario.
CU_M01: dict[str, str] = {
    "PAN-PER-01": "CU-03; CU-TIT-01",
    "PAN-PER-02": "CU-PER-01..05; CU-04",
    "PAN-PER-03": "CU-03; CU-PER-06; CU-PER-13",
    "PAN-PER-04": "CU-03; CU-REG-01 (M19)",
    "PAN-PER-05": "CU-04; CU-TIT-01",
    "PAN-PER-06": "CU-GEO-01",
    "PAN-PER-07": "CU-PER-10",
    "PAN-PER-14": "CU-PER-11; CU-TIT-01",
    "PAN-PER-15": "CU-PER-11",
    "PAN-PER-16": "CU-PER-03",
    "PAN-PER-17": "CU-PER-12",
    "PAN-PER-18": "CU-PER-06",
    "PAN-PER-23": "CU-PER-13",
}
CU_T02: dict[str, str] = {
    "PAN-IAM-01": "CU-IAM-11; CU-29",
    "PAN-IAM-02": "CU-REG-01 (M19)",
    "PAN-IAM-03": "CU-IAM-11",
    "PAN-IAM-04": "CU-IAM-01; CU-IAM-02",
    "PAN-IAM-09": "CU-29; CU-GOB-01",
    "PAN-IAM-10": "CU-GOB-01; CU-IAM-02",
    "PAN-IAM-11": "CU-ACC-01",
    "PAN-IAM-12": "CU-ACC-01; CU-IAM-09",
    "PAN-IAM-14": "CU-ACC-01",
    "PAN-IAM-15": "CU-IAM-04",
    "PAN-IAM-17": "CU-GOB-01",
    "PAN-IAM-27": "CU-IAM-05",
}
NUCLEO_M01 = frozenset(CU_M01)
NUCLEO_T02 = frozenset(CU_T02)