import os
os.chdir(os.path.join(os.path.dirname(__file__), '..', 'anexos'))


def edit(p, pairs):
    b = open(p, 'rb').read(); bom = b.startswith(b'\xef\xbb\xbf'); t = b.decode('utf-8-sig')
    for o, n in pairs:
        assert t.count(o) == 1, (p, o)
        t = t.replace(o, n)
    open(p, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + t.encode('utf-8'))


edit('T05-DAT-modelo-datos.md', [
    ("| `servicePlans` (M02) (5-11-2026, sincronización; Asumida DEC-072, PA-DAT-05) | M02 |",
     "| `serviceProducts` (COL-CAT-05, M02) (antes `servicePlans`; M02 PA-CAT-23 confirma que el paquete de TV es un producto de servicio) (5-11-2026, sincronización; Asumida DEC-072, PA-DAT-05) | M02 |"),
    ("`packageIds[]` (→ `servicePlans`, M02) (5-11-2026, sincronización: M12 §7.13.21, PA-CMP-16;",
     "`packageIds[]` (→ `serviceProducts`, M02; antes → `servicePlans`, corregido por M02 PA-CAT-23) (5-11-2026, sincronización: M12 §7.13.21, PA-CMP-16;"),
    ("  - Quedan para los dueños: M13 §7.37.15",
     "  - Cerrado el 5-11-2026 (M13 PA-STK-11, T10 PA-BIA-17, M02 PA-CAT-23; `packageIds` → `serviceProducts`). Antes decía: Quedan para los dueños: M13 §7.37.15"),
])

edit('M18-SOC-servicios-sociales-flota.md', [
    ("| `vatRateId` | ObjectId (antes Enum) | [VERIFICAR] | Antes `vatRate` (Enum);",
     "| `vatRateId` | ObjectId (antes Enum) | Sí (antes [VERIFICAR]; todo combustible liquida IVA, T05 PA-DAT-05) | Antes `vatRate` (Enum);"),
])
print('ok')
