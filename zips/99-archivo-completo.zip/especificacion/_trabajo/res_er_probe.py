import sys, os, json, re, glob, io, contextlib
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo')
import generar_er_completo as G

buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    rows, by_id, by_name, model, vol, ttl, alt = G.build()

# colecciones sin tabla de campos según los esquemas de 18-openapi
OA = r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\18-openapi'
falt = {}
for f in sorted(glob.glob(os.path.join(OA, '*esquemas*.yaml'))):
    t = open(f, encoding='utf-8').read()
    for b in re.split(r'\n    (?=[A-Za-z_]+:\n)', t):
        if 'additionalProperties: true' in b:
            cid = re.search(r'COL-[A-Z]{3}-\d+', b)
            if cid:
                falt[cid.group(0)] = os.path.basename(f)
out = {}
for owner, mo in model.items():
    for n, ent in mo['ents'].items():
        cid = by_name.get(n, {}).get('id') if isinstance(by_name.get(n), dict) else None
        out[n] = {'owner': owner, 'id': cid, 'line': ent.get('line'), 'anchor': list(ent['anchor']) if ent.get('anchor') else None,
                  'fields': {k: {kk: vv for kk, vv in v.items() if kk in ('type', 'oblig', 'desc', 'src', 'fk', 'fkhow', 'note')} for k, v in ent['fields'].items()},
                  'falta_tabla': cid in falt}
json.dump(out, open(r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo\res_er_model.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
mine = ('T01', 'T02', 'T03', 'T04', 'T06', 'T07', 'T08', 'T10')
for n, e in out.items():
    if e['owner'] in mine and e['falta_tabla']:
        print(e['owner'], e['id'], n, e['line'], e['anchor'], len(e['fields']))
