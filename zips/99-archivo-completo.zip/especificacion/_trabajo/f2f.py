﻿import re,glob
ids={'M10':r'PAN-TEC-6[1-4]|API-TEC-5[1-4]','M12':r'PAN-CMP-2[56]|API-CMP-12[1-4]','M15':r'PAN-CON-\d+|API-CON-\d+','M02':r'API-CAT-35|RF-CAT-114','M05':r'revisionPrevia','M19':r'planObra'}
t2=open(glob.glob('anexos/T02-*')[0],encoding='utf-8').read()
caps=set()
for m,rx in ids.items():
    s=open(glob.glob(f'anexos/{m}-*')[0],encoding='utf-8').read()
    for l in s.split('\n'):
        if re.search(rx,l) and l.startswith('|'):
            for c in re.findall(r'`([a-z]{3}\.[a-zA-Z]+\.[a-zA-Z]+)`',l):
                caps.add((m,c))
for m,c in sorted(caps):
    print(m,c,'EN T02' if c in t2 else 'FALTA')
