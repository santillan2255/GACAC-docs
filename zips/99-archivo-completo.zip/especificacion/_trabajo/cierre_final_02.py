"""Cierre de la corrección de inconsistencias: consolida en 02 las PA nuevas de los anexos (05-11-2026)."""
import os, re
os.chdir(os.path.join(os.path.dirname(__file__), '..'))
F = '02-preguntas-abiertas.md'
raw = open(F, 'rb').read()
bom = raw.startswith(b'\xef\xbb\xbf')
t = raw.decode('utf-8-sig')
NL = '\r\n' if '\r\n' in t else '\n'
assert '| PA-COM-17 |' not in t, 'ya aplicado'

A = 'Asumida (DEC-072)'
nuevas = [
    ('PA-PER-17', 'M01', 'Destino de `accounts.accountingGroupId` y `personIdentifierIndex.exceptionId`', '`accountingGroupId` → grupos contables (reemplazado por `collectionAccountingGroups` de M07, PA-COB-20); `exceptionId` → excepción de unicidad aprobada (reemplazado por `approvalRequests` de T11, PA-PER-18)'),
    ('PA-PER-18', 'M01', 'Destino de `exceptionId` y estados de `premises`', '`exceptionId` → `approvalRequests` de T11, sin colección propia en M01; estados de `premises` `active`, `merged`, `archived` según §7 y §8.14'),
    ('PA-CAT-20', 'M02', 'Dueño de los CU compartidos CU-MER-01, CU-PRO-01, CU-CIC-01, CU-ESP-CEM y CU-ESP-SAN', 'CU-MER-01 → M03 y el CU de M02 pasa a CU-CAT-13; CU-PRO-01 → M02; CU-CIC-01 → M08 (PA-MOR-21; antes M09); CU-ESP-CEM y CU-ESP-SAN → M18; los demás anexos citan su parte'),
    ('PA-CAT-21', 'M02', 'Destino de referencias de `billableConcepts`, `serviceContracts` y `serviceConcessions`, y estados propuestos del §8', '`fiscalClassId` → `fiscalClasses` de M06; `thirdPartyId` y `authorityIds` → terceros y autoridades de M01; `activityId` según PA-CAT-22; se aceptan los estados propuestos'),
    ('PA-CAT-22', 'M02', 'Destino de `externalClientId`, `bundleSubscriptionId` y `activityId`', '`externalClientId` → `persons` (M01); `bundleSubscriptionId` → colección nueva `bundleSubscriptions` (M02 §7.29); `activityId` → `normativeTables` de M06 (`code = arcaActivities`)'),
    ('PA-MED-14', 'M03', 'Estados de `meteringSystems`', '`active` e `inactive` (inicial `active`); la salud técnica sigue aparte en `health.status`'),
    ('PA-TAR-20', 'M04', 'Destino de `taxRateIds`, `adjustmentRequestIds` y `m02ChangeIds`, y estados propuestos del §8', 'Alícuotas de M06; pedidos de ajuste de M05 (`invoiceAnnulmentRequests`, PA-FAC-22); versiones de contrato de M02; se aceptan los estados, incluido `failed` en `calculationRuns.status`'),
    ('PA-FAC-21', 'M05', 'Destino de `invoices.sellerId` y estados propuestos del §8', 'Vendedor como usuario del tenant (`memberships` de T02) según el canal de venta de M11; se aceptan los estados propuestos'),
    ('PA-FAC-22', 'M05', 'Destino de `adjustmentRequestIds` de M04', '`invoiceAnnulmentRequests` (COL-FAC-17) con `mode` `partialCredit` o `debitAdjustment`; sin colección nueva'),
    ('PA-FIS-19', 'M06', 'Capability de exportación de reportes fiscales', '`fis.reportes.exportar`, única para todos los reportes, además de la `fis.<recurso>.ver` del dominio'),
    ('PA-FIS-20', 'M06', 'Destino de `normativeAdoptions.simulationId` y `gatewayDocuments.externalSystemId`', 'Simulaciones de M04 y `apiClients` de T02'),
    ('PA-FIS-21', 'M06', 'Colección `fiscalClasses`, catálogo de actividades y estados de `provincialValidationCodes`', 'M06 declara `fiscalClasses` (§7.38); `activityId` → `normativeTables` (`arcaActivities`); estados `active` y `expired`'),
    ('PA-COB-19', 'M07', 'Estados de colecciones sin máquina de estados', 'Una máquina por colección en el anexo dueño: M07 §8.17, M08 §8.14 (`agreementInstallments`), M09 §8.13 (`crmCalendarEvents`), M10 (`technicalProcedures`, PA-TEC-22) y M13 (`fixedAssetValueChanges`, `mrpRuns`, PA-STK-10)'),
    ('PA-COB-20', 'M07', 'Colección `collectionAccountingGroups`', 'M07 la declara (`code`, `name`, `status` `active`/`inactive`) en O5, sin cuentas; las cuentas van en `entityAccountAssignments` de M15 (`entityType = collectionAccountingGroup`)'),
    ('PA-MOR-21', 'M08', 'Anexo dueño de CU-CIC-01 (suspensión temporal y reactivación)', 'M08 es dueño; M02, M09 y M19 citan su parte (para este CU reemplaza la opción de PA-CAT-20, que decía M09)'),
    ('PA-CRM-19', 'M09', 'Anexo dueño de CU-SOL-01 (alta de Internet y baja de TV)', 'M09 es dueño; M02 cita su parte de contrato'),
    ('PA-TEC-21', 'M10', 'Vocabulario de capabilities de M10', 'Renombrar al español con la canónica de T02 (`tec.ordenes.*`, `tec.servicioTecnico.*`, `tec.redes.*`, `tec.agenda.*`…) y conservar el nombre anterior como alias "antes `x`"'),
    ('PA-TEC-22', 'M10', 'Estados de `technicalProcedures`', 'Máquina propia `open`, `inReview`, `observed`, `approved`, `rejected`, `cancelled` (§8.15), dirigida por la resolución de cada etapa'),
    ('PA-STK-10', 'M13', 'Estados de `fixedAssetValueChanges` y `mrpRuns`', '`fixedAssetValueChanges` `draft` → `posted` → `voided`; `mrpRuns` `calculated` → `confirmed` / `discarded`, o `failed` (§8.13)'),
    ('PA-TES-18', 'M14', 'Estados de `cashFlowScenarios`', '`draft` → `active` → `archived` (§8.16.10); un escenario archivado se copia para reutilizarlo'),
    ('PA-CON-18', 'M15', 'Colección del modelo de centro de costo (`costCenterModelId`)', 'M15 declara la colección `costCenterModels` (§7.19.1), con reparto fijo o delegado en un modelo de distribución'),
    ('PA-SUE-16', 'M16', 'Dueño de las pantallas del empleado', 'M16 es dueño del contenido, las reglas y las API (PAN-SUE-41 a 46, API-SUE-78 a 81); M19 es dueño de la ruta publicada en la PWA y las incrusta'),
    ('PA-SUE-17', 'M16', 'Estados de `payslipNotifications`, `performanceReviews` y `objectives`', 'Se confirman los valores y transiciones de §8.12.8 a §8.12.10'),
    ('PA-INS-12', 'M17', 'Nombre del campo que apunta al padrón de asociados', '`associateMembershipId` (antes `membershipId`) en M17, T05 y los consumidores de `ins.membership.*`'),
    ('PA-SOC-16', 'M18', 'Referencia al artículo de stock en vivienda', '`inventoryItemId` de M13 (antes `productId`)'),
    ('PA-SOC-17', 'M18', 'API-SOC-006: endpoint HTTP o servicio interno', 'Endpoint HTTP `GET /api/admin/soc/contracts/:id/billing-inputs` que consume M04, con `soc.adherentes.ver`'),
    ('PA-SOC-18', 'M18', 'Estados de `providerAgreements`, `donationCampaigns` y `housingPlans`', 'Se confirman §8.1.6 y §8.1.7 y se agrega §8.1.8 (`draft`, `active`, `closed`) para planes de vivienda'),
    ('PA-POR-20', 'M19', 'Tabbar del socio y pantalla Comunidad', 'Inicio · Cuentas y servicios · (+) · Gestiones · Comunidad, con Perfil desde el avatar y FAB = Pagar (maestra §9.2 y T03); nueva PAN-POR-105 `/app/comunidad` (RF-POR-180)'),
    ('PA-POR-21', 'M19', 'Versiones de formularios del portal', '`formVersions` de T11: `portalForms` guarda `formVersionId`; presentaciones y borradores guardan la versión usada'),
    ('PA-CFG-14', 'T04', 'Cambio de CUIT o de entidad emisora con documentos emitidos', 'El CUIT no se edita (un CUIT nuevo es una entidad nueva); el cambio de emisora de un servicio tiene fecha efectiva y los saldos anteriores quedan en la entidad original (RN-CFG-052)'),
    ('PA-DAT-03', 'T05', 'Errores de unicidad y de campos en el catálogo de T09', 'Corregir T05 según las fichas de T09 (COL-COM-15, 16, 22, 37, 45 y 56)'),
    ('PA-INT-26', 'T06', 'Estados de `aiUsageLogs`', '`ok`, `error` y `blocked`'),
    ('PA-MIG-20', 'T07', 'Dónde se guarda el acta de aceptación de la migración', '`documents` de T11 con tipo documental `acta`'),
    ('PA-NFR-22', 'T08', 'Factor de simultaneidad del pico de plataforma', '0,6 en todas las filas de simultaneidad de §7.1, con prueba de carga antes de O4'),
    ('PA-NFR-23', 'T08', 'Copias anuales de 10 años', 'Sin copias anuales: datos en línea los 10 años y detalle de más de 36 meses en archivo en frío (DEC-087)'),
    ('PA-COM-17', 'T09', 'Estados de los avisos de plataforma (`platformNotices`)', '`draft` → `published` → `expired`, con `withdrawn` desde `draft` o `published`'),
    ('PA-COM-18', 'T09', 'Tipo de comunicación en plantillas de campaña y de texto libre', 'Obligatorio, con el tipo genérico "Campaña" (`com.campaign.generic`) precargado por plataforma'),
    ('PA-WFL-22', 'T11', 'Destino de `responsibleAreaId`', '`crmAreas` de M09'),
]

cambios_estado = {
    'PA-IAM-12': 'Respondida (DEC-043; antes Asumida (DEC-072))',
    'PA-CFG-02': 'Respondida (DEC-046; antes Asumida (DEC-072))',
    'PA-CFG-04': 'Respondida (DEC-020; antes Asumida (DEC-072))',
    'PA-MOR-20': 'Respondida (DEC-052; antes Asumida (DEC-072))',
    'PA-POR-04': 'Respondida (DEC-067; antes Asumida (DEC-072))',
    'PA-CFG-P1-02': 'Asumida (DEC-072); respondida en parte por DEC-064 (datos legales en `legalEntities` de T04; CUIT no editable, PA-CFG-14)',
}
L = t.split(NL)
for i, l in enumerate(L):
    m = re.match(r'\| (PA-[A-Z0-9-]+?-\d+) \|', l)
    if m and m.group(1) in cambios_estado:
        cel = l.rstrip().rsplit('|', 2)
        assert cel[1].strip() == A, (m.group(1), cel[1])
        L[i] = cel[0] + '| ' + cambios_estado[m.group(1)] + ' |'
        cambios_estado[m.group(1)] = None
assert all(v is None for v in cambios_estado.values()), cambios_estado

ult = max(i for i, l in enumerate(L) if l.startswith('| PA-'))
assert L[ult].startswith('| PA-DAT-02 |')
filas = ['| %s | %s | %s | %s | %s |' % (a, b, c, d, A) for a, b, c, d in nuevas]
L[ult + 1:ult + 1] = filas

idx = next(i for i, l in enumerate(L) if l.startswith('**Cierre del cuestionario (04-11-2026):**'))
nota = ('**Actualización por el cierre de la corrección de inconsistencias (05-11-2026):** 555 preguntas registradas '
        '(antes 516 en el cierre del 04-11-2026; 517 filas con PA-DAT-02); 98 respondidas por el solicitante (antes 93), '
        '456 asumidas con la opción recomendada (DEC-072; antes 423) y 1 reemplazada. Se agregaron al final de la tabla las 38 PA '
        'que los anexos registraron en su §21 durante la corrección: PA-PER-17, 18; PA-CAT-20, 21, 22; PA-MED-14; PA-TAR-20; '
        'PA-FAC-21, 22; PA-FIS-19, 20, 21; PA-COB-19, 20; PA-MOR-21; PA-CRM-19; PA-TEC-21, 22; PA-STK-10; PA-TES-18; PA-CON-18; '
        'PA-SUE-16, 17; PA-INS-12; PA-SOC-16, 17, 18; PA-POR-20, 21; PA-CFG-14; PA-DAT-03; PA-INT-26; PA-MIG-20; PA-NFR-22, 23; '
        'PA-COM-17, 18; PA-WFL-22. Pasan a respondidas, porque su anexo ya aplica la DEC: PA-IAM-12 (DEC-043), PA-CFG-02 (DEC-046), '
        'PA-CFG-04 (DEC-020), PA-MOR-20 (DEC-052) y PA-POR-04 (DEC-067); PA-CFG-P1-02 sigue asumida y anota la respuesta parcial de DEC-064.')
L[idx + 1:idx + 1] = ['', nota]
out = NL.join(L)
open(F, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + out.encode('utf-8'))
print('ok', len(filas))
