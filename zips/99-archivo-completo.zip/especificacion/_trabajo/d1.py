from repl import *
p = fpath('M16'); s = read(p)
import re
def line_starting(prefix):
    m = [l for l in s.split('\n') if l.startswith(prefix)]
    assert len(m) == 1, (prefix, len(m))
    return m[0]
rf105 = line_starting('| RF-SUE-105 |')
c = rf105.split(' | ')
c[1] = 'Firma del empleador y firma o conformidad del empleado **delegadas en T11**: al emitir, SUE pide la firma a T11 (API-WFL-75) con el perfil SIG-SUE-EMPLEADOR (firma digital con proveedor licenciado vía T06, RF-WFL-198) y luego SIG-SUE-EMPLEADO (firma electrónica con OTP, RF-WFL-197); SUE arma los lotes, proyecta en el recibo el estado que publica T11 y registra la no conformidad con observación (RF-WFL-202). SUE no integra proveedores ni guarda evidencias de firma.'
c[5] = 'Adoptado (DEC-078)'
rf105n = ' | '.join(c)
apply('M16', [
 (rf105, rf105n),
 ('| Firma digital/electrónica con proveedor | T06 INT (FIC 15) | Plugin de firma; SUE gestiona estados de firma por recibo. |',
  '| Firma de recibos (digital y electrónica), interfaz de firma, OTP, evidencias y conector con el proveedor | T11 WFL (RF-WFL-195 a RF-WFL-202; perfiles SIG-SUE-EMPLEADOR y SIG-SUE-EMPLEADO de T11 §18.5), con T06 INT como conector del proveedor licenciado (DEC-078) | SUE pide la firma por API-WFL-75 y proyecta en el recibo el estado que publica T11 (EVT-WFL-041 a EVT-WFL-043). |'),
 ('notificación y recordatorios de recibos pendientes de firma. |', 'notificación y recordatorios de recibos pendientes de firma (los envía T11 con JOB-WFL-09, según PRM-SUE-024/049). |'),
 ('| Portal del empleado: lista de recibos, descarga, firma/conformidad;', '| Portal del empleado: lista de recibos, descarga, firma/conformidad en la interfaz de firma de T11 (PAN-WFL-27);'),
 ('| `payslipSigner` | `{ userId, position, signatureProviderRef }` | No | Responsable de firma del empleador. |',
  '| `payslipSigner` | `{ userId, position, signatureProfileCode }` | No | Responsable de firma del empleador; debe estar habilitado como firmante en el perfil de T11 (PAN-WFL-19). |'),
 ('| `signature` | `{ employerStatus, employerSignedAt, employeeStatus (pending, signed, signedWithDisagreement, rejectedTechnical), employeeSignedAt, disagreementNote, evidence { ip, device, otpChannel, hash, timestamp }, batchId, providerRef }` | Sí | RF-SUE-105. |',
  '| `signature` | `{ signatureRequestId, employerStatus, employerSignedAt, employeeStatus (pending, signed, signedWithDisagreement, rejectedTechnical), employeeSignedAt, disagreementNote, batchId }` | Sí | RF-SUE-105. Proyección del estado de la solicitud de firma de T11; la evidencia (OTP, hash, sello de tiempo, certificado) la guarda T11. |'),
 ('`JOB-SUE-04` (firma del empleador)', '`JOB-SUE-04` (pide a T11 la firma del empleador)'),
 ('| Lote de firma del empleador |', '| Lote de firma del empleador (crea las solicitudes en T11 por API-WFL-75) |'),
 ('| `/api/sue/me/payslips/:id/sign` · `/disagree` · `/viewed` | `sue.portal.recibos.firmar` | Firma, disconformidad, visto |',
  '| `/api/sue/me/payslips/:id/viewed` | `sue.portal.recibos.ver` | Constancia de visto; la firma, la firma en disconformidad y el rechazo se hacen en T11 (API-WFL-77 a API-WFL-79, PAN-WFL-27) |'),
 ('| `int.signature.completed` / `failed` | T06 (FIC 15) | Estado de firma del recibo |',
  '| `wfl.signature.requested` / `.participantSigned` (EVT-WFL-041), `wfl.signature.completed` (EVT-WFL-042), `wfl.signature.rejected` / `.expired` / `.cancelled` (EVT-WFL-043) | T11 | Estado de firma del recibo; con la firma del empleado publica EVT-SUE-15 |'),
 ('| JOB-SUE-04 | `sue:firmar-recibos-empleador` | Al emitir | Envía lote al proveedor de firma (FIC 15) o firma interna. |',
  '| JOB-SUE-04 | `sue:firmar-recibos-empleador` | Al emitir | Arma el lote y pide a T11 la firma del empleador con el perfil SIG-SUE-EMPLEADOR (API-WFL-75); no llama al proveedor. Ver JOB-WFL-17 (dueño). |'),
 ('| JOB-SUE-06 | `sue:consultar-estado-firma` | Cada 15 min mientras haya lotes abiertos | Estado de firma con el proveedor. |',
  '| JOB-SUE-06 | `sue:consultar-estado-firma` | — | **Retirado.** T11 consulta al proveedor y el estado llega por EVT-WFL-042/043. Ver JOB-WFL-18 (dueño). |'),
 ('| JOB-SUE-19 | `sue:recordatorios-firma` | Diario 09:00 | Recibos pendientes de firma (PRM-SUE-024/049). |',
  '| JOB-SUE-19 | `sue:recordatorios-firma` | — | **Retirado.** T11 envía los recordatorios de firma pendiente según PRM-SUE-024/049. Ver JOB-WFL-09 (dueño). |'),
 ('| Firma digital / electrónica | FIC 15 | Bidireccional | API del proveedor | Envío, estado, descarga del firmado; firma del empleador y del empleado (PA-SUE-04). |',
  '| Firma digital / electrónica | T11 WFL (conector del proveedor en T06, FIC 15) | Solicitud a T11 y eventos de vuelta | API-WFL-75; EVT-WFL-041 a EVT-WFL-043 | SUE no integra el proveedor: pide la firma a T11 y recibe el estado. Perfiles SIG-SUE-EMPLEADOR y SIG-SUE-EMPLEADO (DEC-078). |'),
 ('| PRM-SUE-039 | `sue.payslip.signatureMode` | enum `none`, `employeeConsent`, `electronic`, `digitalProvider` | empresa | `employeeConsent` | Modo de firma (A validar PA-SUE-04). |',
  '| PRM-SUE-039 | `sue.payslip.signatureMode` | enum `none`, `employeeConsent`, `electronic`, `digitalProvider` | empresa | `digitalProvider` | Modo de firma del recibo por empresa; se traduce a los perfiles de T11 (SIG-SUE-EMPLEADOR, SIG-SUE-EMPLEADO; PRM-WFL-048). Por defecto, firma digital del empleador con proveedor licenciado y firma electrónica con OTP del empleado (DEC-078). |'),
 ('2) Firma con OTP; queda la evidencia.', '2) Firma con OTP en la interfaz de firma de T11 (PAN-WFL-27); T11 guarda la evidencia.'),
 ('| Conformidad con evidencia por defecto; firma digital con proveedor como opción por empresa. A validar PA-SUE-04. |',
  '| Firma digital con proveedor licenciado para el empleador y firma electrónica con OTP para el empleado, ambas resueltas por T11 (DEC-078). |'),
 ('### PA-SUE-04 — Firma de recibos\n', '### PA-SUE-04 — Firma de recibos\n- **Estado:** Resuelta por DEC-078: firma digital con proveedor licenciado para recibos de sueldo, con la interfaz y los perfiles de firma de T11.\n'),
 ('| RF-SUE-105; JOB-SUE-04/06; PA-SUE-04 |', '| RF-SUE-105; JOB-SUE-04; T11 RF-WFL-198, JOB-WFL-17/18; DEC-078 |'),
 ('| RF-SUE-105; JOB-SUE-04/06 |', '| RF-SUE-105; reemplazado por T11 (RF-WFL-197/198, JOB-WFL-17/18) |'),
], tag='firma')
