# Revisión global de la especificación (criterios 1 a 7). Solo lectura: genera un informe.
import re, sys, json, collections, pathlib

BASE = pathlib.Path(__file__).resolve().parent.parent
OUT = BASE / '_trabajo' / 'revision-global-informe.txt'

CODES = {'M01':'PER','M02':'CAT','M03':'MED','M04':'TAR','M05':'FAC','M06':'FIS','M07':'COB','M08':'MOR',
         'M09':'CRM','M10':'TEC','M11':'VEN','M12':'CMP','M13':'STK','M14':'TES','M15':'CON','M16':'SUE',
         'M17':'INS','M18':'SOC','M19':'POR','T01':'PLA','T02':'IAM','T03':'UXD','T04':'CFG','T04b':'CFG',
         'T05':'DAT','T06':'INT','T07':'MIG','T08':'NFR','T09':'COM','T10':'BIA','T11':'WFL','T12':'SRV'}
CODE2ANN = collections.defaultdict(set)
for k, v in CODES.items():
    CODE2ANN[v].add(k)

def files():
    for p in sorted(BASE.rglob('*.md')):
        rel = p.relative_to(BASE).as_posix()
        if rel.startswith('_trabajo/') or rel.startswith('04-'):
            continue
        yield p, rel

def annex_of(rel):
    m = re.match(r'anexos/(T04b|[MT]\d\d)-', rel)
    return m.group(1) if m else None

ID_RE = r'(?:RNF|RF|RN|PRM|API|EVT|JOB|PA|CTR|COL|ESC|CU|PAN|TPL|FI|CNC)-[A-Z]{2,4}(?:-P\d)?-\d+[a-z]?|DEC-\d+|HUE(?:CO)?-[A-Z0-9]+-\d+'
DEF_ROW = re.compile(r'^\|\s*\**(' + ID_RE + r')\**\s*\|')
DEF_HEAD = re.compile(r'^#{2,6}\s+\**(' + ID_RE + r')\**(?:\s|$|\s*[—:-])')
OLD = ['tenantServiceId', 'holderPersonId', 'serviceContractId', 'propertyId', 'pwa.planObra.ver', 'vaultSecrets',
       'preloadedCharges', 'intakeChannels', 'paymentOrderSigners', 'gasProratedConsumptions', 'legacyRefs',
       'legacyRef', 'legacyCode']
ALLOW = re.compile(r'antes|alias|reemplaz|Reemplaz|~~|[Tt]exto anterior|\bex[ -]|no se crea|absorb|retirad|Retirad|'
                   r'rechazad|no usa|no se usan?|ya no|en lugar de|renombr|Renombr|era |nombre viejo|nombres viejos|'
                   r'CTR-DAT|Corregido|corregido|deprecad|prohibid|lista negra|no existe|no deben?', re.I)
MOJI = re.compile(r'Ã[\x80-\xBF¡-ÿ]|Â[ -¿]|â€|├|┬|ÔÇ|\uFFFD')

report = collections.defaultdict(list)
defs = collections.defaultdict(list)
stats = {}

for p, rel in files():
    b = p.read_bytes()
    bom = b.startswith(b'\xef\xbb\xbf')
    try:
        t = b.decode('utf-8-sig')
    except UnicodeDecodeError as e:
        report['7-utf8'].append(f'{rel}: no es UTF-8 válido ({e})')
        continue
    crlf = t.count('\r\n'); lf = t.count('\n')
    stats[rel] = {'bom': bom, 'eol': 'CRLF' if crlf == lf and lf else ('LF' if crlf == 0 else 'MIXTO')}
    if stats[rel]['eol'] == 'MIXTO':
        report['7-eol'].append(f'{rel}: saltos de línea mixtos ({crlf} CRLF de {lf})')
    lines = t.splitlines()
    heads = collections.Counter()
    in_code = False
    ann = annex_of(rel)
    for i, line in enumerate(lines, 1):
        if line.startswith('```'):
            in_code = not in_code
        if in_code:
            continue
        m = re.match(r'^(#{1,6})\s+(.*?)\s*$', line)
        if m:
            heads[(m.group(1), m.group(2))] += 1
        if '<!-- SIGUE' in line:
            report['2-sigue'].append(f'{rel}:{i}')
        if '[REF-PENDIENTE' in line:
            report['6-refpend'].append(f'{rel}:{i}: {line[:160]}')
        for mm in MOJI.finditer(line):
            report['7-mojibake'].append(f'{rel}:{i}: …{line[max(0,mm.start()-30):mm.end()+30]}…')
        d = DEF_ROW.match(line) or DEF_HEAD.match(line)
        if d:
            defs[d.group(1)].append((rel, i))
        for name in OLD:
            for mm in re.finditer(r'(?<![A-Za-z])' + re.escape(name) + r'(?![A-Za-z])', line):
                ctx = line[max(0, mm.start()-140):mm.end()+60]
                if not ALLOW.search(ctx):
                    report['5-old'].append(f'{rel}:{i}: {name}: …{ctx}…')
        # 4a: "Mxx YYY" con código que no corresponde
        for mm in re.finditer(r'\b(M\d\d|T\d\db?)\s+([A-Z]{3})\b', line):
            a, c = mm.group(1), mm.group(2)
            if a in CODES and c in CODE2ANN and CODES[a] != c:
                report['4-codigo'].append(f'{rel}:{i}: "{mm.group(0)}" (debería ser {a} {CODES[a]})')
        # 4b: ID de código XXX seguido de "de/del/(" anexo de otro código
        for mm in re.finditer(r'\b(?:RNF|RF|RN|PRM|API|EVT|JOB|PA|CTR)-([A-Z]{3})-\d+\s*(?:\(|de |del anexo )(M\d\d|T\d\d)\b', line):
            c, a = mm.group(1), mm.group(2)
            if c in CODE2ANN and a in CODES and CODES[a] != c:
                report['4-cita'].append(f'{rel}:{i}: "{mm.group(0)}" ({c} es de {"/".join(sorted(CODE2ANN[c]))})')
    for (lvl, h), n in heads.items():
        if n > 1:
            report['1-headdup'].append(f'{rel}: "{lvl} {h}" ×{n}')

CONSOL = {'EVT': 'anexos/T11', 'JOB': 'anexos/T11', 'DEC': '01-', 'PA': '02-', 'HUE': '05-', 'COL': 'anexos/T05'}
for idv, locs in sorted(defs.items()):
    pref = idv.split('-')[0][:3] if idv.startswith('HUE') else idv.split('-')[0]
    code = idv.split('-')[1] if idv.count('-') >= 2 and not idv.startswith('HUE') else None
    owners = [l for l in locs if not l[0].startswith(CONSOL.get(pref, '\x00'))]
    # consolidadores: T11 (EVT/JOB), 01 (DEC), 02 (PA), 05 (HUECO), T05 (COL), maestra y plan (03) citan
    owners = [l for l in owners if not l[0].startswith(('00-', '03-', '01-', '02-', '05-'))] or owners
    if len({l for l in owners}) > 1:
        report['3-dupdef'].append(f'{idv}: ' + '; '.join(f'{r}:{n}' for r, n in owners))
    if code and code in CODE2ANN and pref in ('RF', 'RN', 'RNF', 'PRM', 'API', 'EVT', 'JOB', 'PA', 'CTR', 'ESC', 'PAN', 'CU'):
        for r, n in owners:
            a = annex_of(r)
            if a and a not in CODE2ANN[code] and not (a == 'T11' and pref in ('EVT', 'JOB')) \
                    and not (a == 'T12' ) and not (a == 'T05' and pref == 'CTR'):
                report['4-defajena'].append(f'{idv} definido en {r}:{n} (anexo {a} {CODES.get(a)})')

with OUT.open('w', encoding='utf-8', newline='\n') as f:
    for k in sorted(report):
        f.write(f'== {k}: {len(report[k])}\n')
        for x in report[k]:
            f.write('  ' + x + '\n')
    f.write('== codificación\n')
    for r, s in stats.items():
        f.write(f'  {r}: BOM={s["bom"]} EOL={s["eol"]}\n')
print({k: len(v) for k, v in sorted(report.items())})
