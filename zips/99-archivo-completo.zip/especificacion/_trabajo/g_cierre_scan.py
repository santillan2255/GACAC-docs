﻿import re,glob
t02=open('anexos/T02-IAM-identidad-roles-auditoria.md',encoding='utf-8-sig').read()
sec=t02[t02.index('#### 4.4.3'):t02.index('### 4.5 ')]
rows=[]
for l in sec.splitlines():
    c=[x.strip() for x in l.split('|')]
    if len(c)>6 and c[2].startswith('`'):
        rows.append((c[2].strip('`'),c[3],c[5]))
files=[f for p in ['T01','T03','T04','T06','T07','T08','T10','T12'] for f in glob.glob(f'anexos/{p}-*')]
for f in files:
    s=open(f,encoding='utf-8-sig').read()
    for n,can,an in rows:
        k=len(re.findall(r'(?<![\w.])'+re.escape(n)+r'(?![\w])',s))
        if k: print(f[7:20],n,k,'->',can,'|',an)
