"""Tercera consolidación (sincronización posterior a los residuales, 05-11-2026): PA nuevas en 02, §18 de la matriz y totales de la maestra."""
import os, re, sys, glob, collections
sys.path.insert(0, os.path.dirname(__file__))
import plan_recuento as pr  # noqa
ESPEC = pr.ESPEC
os.chdir(ESPEC)
A = 'Asumida (DEC-072)'
S = 'Sincronización posterior a la ronda de residuales: '
nuevas = [
    ('PA-IAM-19', 'T02', S + 'capabilities reemplazadas, servicios internos y comando de OT', '`fac.bloqueosCausas.configurar` reemplazada y alias total de `mor.causas.configurar`; filas `fis.service.*` como servicios internos de M06 §11.1; `tec.workOrder.create` queda solo como alias de capability'),
    ('PA-UXD-19', 'T03', S + 'mapa del portal y rótulo corto', 'Correspondencia de PAN-POR-19, 52, 55 y 91 con los ítems del mapa (misma app y recurso como principal); rótulo corto "Cuentas" también en CTR-UXD-12'),
    ('PA-DAT-05', 'T05', S + 'catálogo de colecciones', 'Prevalece el anexo dueño: el catálogo toma los nombres del §7 del dueño y registra destinos y valores nuevos en §7.2.1 y §8.1 (`indicatorId` + `indicatorCode`, `kpiAlertRuleId`, `migrationIssues.ruleId` + `ruleCode`, `apiUsageDaily.date`)'),
    ('PA-WFL-24', 'T11', S + 'alias de M13 y comando de OT en EVT-CRM-13', 'Fila de alias en §12.4, nombre anterior citado en EVT-STK-12, comando en el campo `command` de EVT-CRM-13 (no es tipo de evento) y §12.10 actualizado'),
]


def leer(f):
    raw = open(f, 'rb').read()
    return raw.startswith(b'\xef\xbb\xbf'), raw.decode('utf-8-sig')


def escribir(f, bom, t):
    open(f, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + t.encode('utf-8'))


# 02
F = '02-preguntas-abiertas.md'
bom, t = leer(F)
NL = '\r\n' if '\r\n' in t else '\n'
assert '| PA-DAT-05 |' not in t, 'ya aplicado'
L = t.split(NL)
ult = max(i for i, l in enumerate(L) if l.startswith('| PA-'))
assert L[ult].startswith('| PA-WFL-23 |')
L[ult + 1:ult + 1] = ['| %s | %s | %s | %s | %s |' % (a, b, c, d, A) for a, b, c, d in nuevas]
c = collections.Counter()
for l in L:
    if re.match(r'\| PA-[A-Z0-9-]+?-\d+ \|', l):
        c[l.rstrip().rsplit('|', 2)[-2].strip().split(' ')[0]] += 1
tot = sum(c.values())
idx = next(i for i, l in enumerate(L) if l.startswith('**Actualización por la ronda de residuales (05-11-2026):**'))
L[idx + 1:idx + 1] = ['', ('**Actualización por la sincronización posterior a los residuales (05-11-2026):** %d preguntas registradas (antes 585); '
                           '%d respondidas (sin cambios), %d asumidas (DEC-072; antes 486) y %d reemplazada. Se agregaron al final de la tabla: %s.')
                      % (tot, c['Respondida'], c['Asumida'], c['Reemplazada'], ', '.join(x[0] for x in nuevas))]
escribir(F, bom, NL.join(L))
print(c, tot)

# maestra
M = '00-ESPECIFICACION-MAESTRA.md'
bom, t = leer(M)
a = 'se agregan las 30 PA de cierre de residuales de los anexos.'
assert t.count(a) == 1
t = t.replace(a, a + (' Actualización por la sincronización posterior (05-11-2026): %d preguntas (antes 585), %d asumidas (antes 486); '
                      'se agregan PA-IAM-19, PA-UXD-19, PA-DAT-05 y PA-WFL-24.') % (tot, c['Asumida']))
a = 'catálogo de eventos `eventTypes` (658 IDs EVT, T11 §12.10; con alias)'
assert t.count(a) == 1
t = t.replace(a, 'catálogo de eventos `eventTypes` (668 IDs EVT, antes 658, T11 §12.10; con alias)')
escribir(M, bom, t)

# matriz §18
F = '04-matriz-trazabilidad.md'
bom, t = leer(F)
NL = '\r\n' if '\r\n' in t else '\n'
textos = {}
for f in sorted(glob.glob(os.path.join('anexos', '*.md'))):
    b = os.path.basename(f)
    textos.setdefault(b[:3] if not b.startswith('T04b') else 'T04b', []).append(open(f, encoding='utf-8-sig').read())
rf_prompt = {}
for p in pr.leer_prompts():
    for r in p['rf']:
        rf_prompt.setdefault(r, p['id'])
filas = []
for pa, dueno, tema, _ in nuevas:
    menc = sum(x.count(pa) for x in textos[dueno])
    otros = sorted(k for k, v in textos.items() if k != dueno and any(pa in x for x in v))
    rfs = collections.defaultdict(list)
    for v in textos.values():
        for x in v:
            for l in x.split('\n'):
                m = re.match(r'^\|\s*\**(RF-[A-Z]+-\d{3})\**\s*\|', l)
                if m and re.search(re.escape(pa) + r'(?!\d)', l) and m.group(1) in rf_prompt:
                    rfs[rf_prompt[m.group(1)]].append(m.group(1))
    rfc = '; '.join('%s: %s' % (k, ', '.join(sorted(set(v)))) for k, v in sorted(rfs.items())) or '—'
    res = 'Trazada (dueño la registra)' if rfs else 'Trazada en el dueño; ningún RF la cita (solo PA, RN, PRM o §21)'
    if menc == 0:
        res = 'Falta en el dueño'
    filas.append('| %s | %s | %s | %s | — (sincronización posterior a los residuales) | %d | %s | %s | %s |' % (pa, dueno, tema, A, menc, ', '.join(otros) or '—', rfc, res))
ancla = '| PA-WFL-23 | T11 |'
i = t.index(ancla)
j = t.index(NL, i)
t = t[:j] + NL + NL.join(filas) + t[j:]
a = 'y después las 30 PA de la ronda de residuales del mismo día.'
assert t.count(a) == 1
t = t.replace(a, 'y después las 30 PA de la ronda de residuales y las 4 de la sincronización posterior del mismo día.')
a = '| 18 | 78 PA (10 de los huecos, 38 de la corrección y 30 de la ronda de residuales) | 48 |'
assert t.count(a) == 1
t = t.replace(a, a + NL + '| 18 (sincronización posterior) | 82 PA (se agregan PA-IAM-19, PA-UXD-19, PA-DAT-05 y PA-WFL-24) | 78 |')
escribir(F, bom, t)
print('ok', filas)
