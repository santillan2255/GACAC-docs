import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from repl import apply

P = []
# cita mal numerada
P.append(("RN-09 §14 TESORERÍA (33 parámetros)", "RN-09 §6.4 grupo TESORERÍA (33 parámetros)"))
# nombres de campo: banco primero, luego sucursal del tenant
P.append(("| `institutionId`, `branchId` | ObjectId | Cond. | Obligatorios en cuentas bancarias. |",
          "| `institutionId`, `bankBranchId` | ObjectId | Cond. | Obligatorios en cuentas bancarias; `bankBranchId` → `bankBranches` (§7.2), antes `branchId`, renombrado para no confundir con `branches` de T04. |"))
P.append(("Campos: `institutionId`, `branchId`, `accountNumber`, `holderName`",
          "Campos: `institutionId`, `bankBranchId`, `accountNumber`, `holderName`"))
P.append(("| `institutionId`, `branchId`, `accountNumber`, `checkNumber` |",
          "| `institutionId`, `bankBranchId`, `accountNumber`, `checkNumber` |"))
P.append(("`{tenantId, institutionId, branchId, accountNumber, checkNumber}`",
          "`{tenantId, institutionId, bankBranchId, accountNumber, checkNumber}`"))
P.append(("| `branchOfficeId` | ObjectId (sucursal del tenant) | No | — |",
          "| `branchId` | ObjectId → `branches` (T04, sucursal del tenant) | No | Antes `branchOfficeId` (nombre canónico de T05 §7.2). |\n"
          "| `legalEntityId` | ObjectId → `legalEntities` (T04) | Sí | Entidad jurídica titular de la cuenta (DEC-064). Una cuenta pertenece a una sola entidad; los movimientos heredan su entidad. |"))
P.append(("branchOfficeId", "branchId", 0))

# treasuryMovements: legalEntityId
P.append(("| `operationId` | ObjectId | Sí | — |\n| `accountId` | ObjectId | Sí | — |\n| `book` |",
          "| `operationId` | ObjectId | Sí | — |\n| `accountId` | ObjectId | Sí | — |\n| `legalEntityId` | ObjectId → `legalEntities` (T04) | Sí | Copia de la entidad de la cuenta (DEC-064); una operación entre cuentas de distintas entidades genera un movimiento por entidad con contrapartida en cuentas de tránsito. |\n| `book` |"))

# cardPlans
P.append(("### 7.27 `cardPlans`\n\nCampos:",
          "### 7.27 `cardPlans`\n\n> **Reemplazado por `cardPlans` de M07 (COL-COB-15, CTR-DAT-08).** M07 es dueño del plan (lo usa el cobro en caja con sus recargos); M14 solo lo lee para cupones, presentaciones y liquidaciones. Los campos siguientes quedan como requisitos que M14 necesita del plan de M07.\n\nCampos:"))
P.append(("| `TARJETAS`, `TARJETAS_RECARGO` | `cardPlans` | — | — |",
          "| `TARJETAS`, `TARJETAS_RECARGO` | `cardPlans` de M07 (CTR-DAT-08; M14 solo lee) | — | — |"))
P.append(("| `TARJETAS`, `TARJETAS_RECARGO` | §7.27 `cardPlans` |",
          "| `TARJETAS`, `TARJETAS_RECARGO` | §7.27 `cardPlans` (dueño M07, CTR-DAT-08) |"))
P.append(("`checkbooks`, `ownChecks`, `cardPlans`, `cardVouchers`",
          "`checkbooks`, `ownChecks`, `cardVouchers`"))

# cardSettlements bankAccountId
P.append(("RET_IBR`), `bankAccountId`, `expenseDocumentRef` (M12)",
          "RET_IBR`), `treasuryAccountId` (antes `bankAccountId`, T05 §7.2), `expenseDocumentRef` (M12)"))

# cashRemittances treasuryHandoverId
P.append(("| `cashSessionId` | ObjectId (M07) | Sí | Único: una rendición por caja (`CAJAS.ID_CAJ`). |",
          "| `cashSessionId` | ObjectId (M07) | Sí | Único: una rendición por caja (`CAJAS.ID_CAJ`). |\n"
          "| `treasuryHandoverId` | ObjectId → `treasuryHandovers` (M07) | Sí | Entrega de caja de M07 que esta rendición recibe: M07 registra la entrega y M14 la recepción (CTR-DAT-64). |"))
P.append(("2. TES consume el evento y crea `cashRemittances` en `pendingReception` (clave `cashSessionId`; un reenvío no crea otra).",
          "2. TES consume el evento y crea `cashRemittances` en `pendingReception` (clave `cashSessionId`; un reenvío no crea otra), vinculada a la entrega `treasuryHandoverId` de M07 (CTR-DAT-64)."))
P.append(("`cashRemittances 1─1 cob.cashSessions`",
          "`cashRemittances 1─1 cob.cashSessions` y `1─1 cob.treasuryHandovers` (CTR-DAT-64)"))

# DEC-058 / DEC-059 / DEC-064
P.append(("| BASE §104 SUE-009; RN-08 §11.5 (ProCoop crea factura de compra y OP) | Estándar | O9 | A validar (PA-TES-07) |",
          "| BASE §104 SUE-009; RN-08 §11.5 (ProCoop crea factura de compra y OP); DEC-058 (en O8 el lote llega desde la importación de la liquidación externa de M16, CU-28; en O9 desde la liquidación propia) | Estándar | O9 | A validar (PA-TES-07) |"))
P.append(("- **Bloquea:** asignación de olas de §5 (O5/O8).\n",
          "- **Bloquea:** asignación de olas de §5 (O5/O8).\n- **Estado:** Respondida (DEC-059): en O5 cuentas, rendición, depósitos, extractos y conciliación; en O8 valores, cupones de tarjeta, retenciones e Interbanking (opción A).\n"))
P.append(("anticipo o ND) según PA-TES-13 (RN-TES-045). | 1 (DEC-003) |\n",
          "anticipo o ND) según PA-TES-13 (RN-TES-045). | 1 (DEC-003) |\n"
          "| CTR-TES-24 | Este anexo (`cardPlans` §7.27, `branchId` bancario, `branchOfficeId`, `bankAccountId`) vs T05 (CTR-DAT-08, §7.2) y DEC-064 | Colección duplicada con M07 y nombres de campo no canónicos; cuentas sin entidad jurídica. | `cardPlans` es de M07; `bankBranchId` para la sucursal bancaria, `branchId` para la sucursal del tenant (T04), `treasuryAccountId` en liquidaciones de tarjeta; `legalEntityId` obligatorio en `treasuryAccounts` y `treasuryMovements`. | T05 (modelo canónico); DEC-064 |\n"
          "| CTR-TES-25 | `cashRemittances` (M14) vs `treasuryHandovers` (M07), ambos con origen `CAJAS` | Dos registros del mismo traspaso. | Se conservan los dos: entrega (M07) y recepción (M14), vinculados por `treasuryHandoverId`. | CTR-DAT-64 |\n"))
apply('M14', P, 'f2-g6-m14')
