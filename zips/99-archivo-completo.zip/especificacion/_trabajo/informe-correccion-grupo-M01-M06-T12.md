# Informe de corrección de inconsistencias: M01 a M06 y T12 (05-11-2026)

Archivos modificados: M01, M02, M03, M04, M05, M06 y T12 parte 1. T12 parte 2 se revisó y no necesitó cambios.

## Puntos específicos del grupo

- **(a) Escenarios de M06:** pasan a `ESC-FIS-nn` y cada uno conserva el número viejo como nota ("antes escenario n"). El escenario que cita AC-06 de la estrategia de pruebas ("Escenario 32") es ahora `ESC-FIS-32`.
- **(b) Primer comprobante del piloto Internet:** el valor correcto según las reglas de M04 es ARS 30.000,00 (5.000 − 2.500 + 15.000 − 7.500 + 20.000). ESC-SRV-INT-01 (T12) quedó alineado con ESC-TAR-03 (M04).
- **(c) Rutas:** se aplicó la convención de la maestra §13 (endpoints en inglés, kebab-case). Se normalizaron 269 rutas (M01 72, M04 67, M05 126, M06 4) y cada fila conserva su ruta anterior. Las rutas de pantallas PAN no se cambiaron, porque la maestra no fija su idioma.
- **(d) Nombres de T05:** se hicieron 31 renombres a T05, por ejemplo `premisesId` → `premiseId`, siempre con la nota "antes `x`". Hay además 13 notas de nombre en tablas nuevas. Las diferencias en las que T05 parece estar mal no se cambiaron; están en la sección "Para T05".

## Conteo por categoría

| Cat. | Encontradas | Corregidas | No corregibles |
|---|---|---|---|
| 1 Capabilities | 85 filas API/PAN | 83 | 2: la exportación de API-FIS-80 (PA-FIS-19) y el comodín de PAN-FIS-40, que se conserva por la regla AL-08 de T03 y queda anotado |
| 2 Tablas de campos | 105 colecciones | 105 | — (campos no deducibles marcados `[VERIFICAR]`) |
| 3 Referencias | 240 | 240 declaradas | Las de destino desconocido quedan `[VERIFICAR]` (PA-PER-17, PA-CAT-21, PA-TAR-20, PA-FAC-21, PA-FIS-20) |
| 4 Nombres de T05 | 44 | 31 renombres y 13 notas | 9 diferencias en las que T05 parece estar mal (sección "Para T05") |
| 5 Estados | 6 anexos | Se declararon valores faltantes, se agregaron tablas de transiciones en M01 a M06, se agregó la transición `executed → reverted` en M01, el estado `failed` en `calculationRuns` de M04 y la alineación de subestados en M05 | Los valores propuestos quedan `[VERIFICAR]` (en las PA de cada anexo) |
| 6 Criterios de aceptación | 7 RF de M04 | 7 | — |
| 7 Eventos | 29 | 27 payloads con campos nombrados y 2 consumidores agregados al §12 | — |
| 8 PAN | 5 | PAN-FIS-41 (capability), PAN-FIS-40 (nota AL-08) y 18 capabilities expandidas | PAN-FAC-47, PAN-CAT-04 y PAN-FIS-29 ya coinciden con T03 (AL-09); no hubo cambios |
| 9 API | 10 servicios internos y 4 filas con tabla rota | 10 movidos a §11.1 de M04 y M06, con la fila marcada "Reemplazado por servicio interno"; se escaparon los `\|` que rompían columnas (API-CAT-45, API-MED-68, RN-TAR-029/121/163, M03 control de días) | No hay duplicados ni parámetros con nombres distintos. El estilo `:id` (M01 a M04) frente a `{id}` (M05, M06) no lo fija la maestra |
| 10 CU | 17 CU en varios anexos | 12 citas agregadas (M01: REG-01→M19, GEO-01→T04; M02: SOL-01→M09; M03: ESP-ELE/AG/GAS→M02; M04: ESP-*→M02, MER-01→M03; M06: CU-10 y LOT-01→M05, MER-01→M03) | CU-MER-01, CU-PRO-01, CU-CIC-01, CU-ESP-CEM y CU-ESP-SAN tienen definiciones distintas; elegir dueño es una decisión (PA-CAT-20) |

## Capabilities nuevas para el catálogo de T02

`per.documentacion.registrar` y `per.documentacion.validar` salen de expandir `per.documentacion.ver/registrar/validar` (PAN-PER-13). Las demás capabilities usadas, incluidas `public.ofertas.ver`, `public.facturas.consultar`, las `ext.*` y `por.facturas.ver`, ya existen en T02. Los comodines `x.*` de las filas API se reemplazaron por `x.ver` / `x.editar`.

Servicios internos nuevos (no son capabilities):

- **M06:** `fis.service.resolveDocumentClass`, `checkRegistryCoverage`, `confirmWithholdings`, `cancelWithholdings`, `calculateTaxes` y `calculateWithholdings`.
- **M04:** los servicios ya existentes (`tar.calculate`, `tar.rateCalls`, `tar.quote` y `tar.getRatedCalls`) se movieron a §11.1.

## Consumidores de eventos para agregar en T11

- M02 consume EVT-CRM-11.
- M03 consume EVT-STK-04.

## PA propuestas

- **PA-PER-17:** destino de `accounts.accountingGroupId` y `personIdentifierIndex.exceptionId`.
- **PA-CAT-20:** dueño de los CU compartidos con definiciones distintas.
- **PA-CAT-21:** referencias de M02 y valores de estado propuestos.
- **PA-TAR-20:** `taxRateIds`, `adjustmentRequestIds`, `m02ChangeIds` y estados propuestos.
- **PA-FAC-21:** `invoices.sellerId` y estados propuestos.
- **PA-FIS-19:** capability de exportación de reportes fiscales.
- **PA-FIS-20:** `normativeAdoptions.simulationId` y `gatewayDocuments.externalSystemId`.

## Para T05 (no se cambió T05)

- **M02 `contractEquipmentAssignments`:** T05 dice `serviceProductId` y el anexo usa `inventoryItemId` (CTR-DAT-30).
- **M05 `numberSequences`:** T05 usa `voucherTypeId` en un lugar y `numberingVoucherTypeId` en otro.
- **M05 `invoiceTemplates`:** falta `templateVersionId`.
- **M01:**
  - `premises`: `cadastralKey` y `cadastralDistrictId`.
  - `relationships`: from/to.
  - `documentSubmissions`.
  - `transfers`: titular from/to.
  - `perRevisions.subjectRef`.
- **M03 `meterInstallations`:** `workOrderId`.
- **M06:**
  - `ledgerAccountIds` en `vatRates` y `taxDefinitions`.
  - `storedFileIds` en `regimeFilings`.

## Para otros anexos (citas pendientes; no son archivos de este grupo)

- **CU-07:** M13 debe citar a M03.
- **CU-LOT-01:** T11 debe citar a M05.
- **CU-FIS-01:** M12, M14 y M15 deben citar a M06.
- **CU-COP-01:** T04 ya cita a M02.
- **CU-GEO-01:** M10 debe citar a T04.
- **T03 SM-ADM-394:** la nota "M05 declara `/admin/facturacion/revision-previa`" quedó desactualizada; M05 ya usa `/admin/fac/revision-previa`.

## Verificación final

En los 8 archivos:

- Los IDs están definidos una sola vez.
- Los encabezados son únicos.
- No hay `<!-- SIGUE -->` ni mojibake.
- Las columnas de todas las tablas son coherentes.
- M01 conserva su BOM y CRLF; los demás siguen sin BOM y con LF.
