from res_lib import Doc

d = Doc(r'anexos\T08-NFR-*.md')

DSR = ['recibida', 'enVerificacion', 'verificada', 'rechazada', 'enAnalisis', 'pendienteAprobacion', 'aprobada', 'enEjecucion', 'respondida', 'cerrada']
INC = ['detectado', 'confirmado', 'descartado', 'contenido', 'notificado', 'erradicado', 'recuperado', 'postmortem', 'cerrado']
q = lambda xs: ', '.join('`%s`' % x for x in xs)

# --- Cat. 1: valores en §15.1 ---
d.rep('`status` (sección 15.2), `assignedTo`', '`status` (%s; sección 15.2; antes sin valores), `assignedTo`' % q(DSR))
d.rep('`status` (15.2), `detectedAt`', '`status` (%s; sección 15.2; antes sin valores), `detectedAt`' % q(INC))
d.rep('| `status` | enum | Sí | — | sección 15.2 |', '| `status` | enum | Sí | — | %s; inicial `recibida` (§15.2) |' % q(DSR))
d.rep('| `status` | enum | Sí | — | 15.2 |', '| `status` | enum | Sí | — | %s; inicial `detectado` (§15.2) |' % q(INC))
d.rep('| `status` | enum | Sí | — | `programado`, `enCurso`, `resuelto`, `cancelado` `programado`, `enCurso`, `resuelto`, `cancelado` |',
      '| `status` | enum | Sí | — | `programado`, `enCurso`, `resuelto`, `cancelado`; inicial `programado` (§15.2) |')

# --- Cat. 1: filas de alta y transiciones en la tabla normalizada de §15.2 ---
T = []
def r(c, a, b, disp, g='—', e='—'):
    T.append('| `%s` | %s | `%s` | %s | %s | %s |' % (c, a if a == '—' else ', '.join('`%s`' % x for x in a.split(',')), b, disp, g, e))

r('consentRecords', '—', 'otorgado', 'Otorgamiento (cada otorgamiento crea un registro nuevo)')
r('consentRecords', 'otorgado', 'revocado', 'Revocación por el titular, en un paso')
r('consentRecords', 'otorgado', 'vencido', 'Vencimiento (sistema)')
r('legalHolds', '—', 'propuesto', 'Alta del bloqueo')
r('legalHolds', 'propuesto', 'activo', 'Aprobación', 'Segundo usuario distinto de quien propuso')
r('legalHolds', 'activo', 'liberado', 'Liberación', 'Motivo')
r('retentionRuns', '—', 'preparada', 'Preparación de la corrida (vista previa o ejecución)')
r('retentionRuns', 'preparada', 'pendienteAprobacion', 'Primera ejecución de la política o más de 1.000 registros')
r('retentionRuns', 'preparada', 'aprobada', 'Sin aprobación requerida')
r('retentionRuns', 'pendienteAprobacion', 'aprobada', 'Aprobación')
r('retentionRuns', 'aprobada', 'enCurso', 'Inicio de JOB-NFR-04')
r('retentionRuns', 'enCurso', 'completada', 'Fin sin errores')
r('retentionRuns', 'enCurso', 'fallida', 'Error')
r('retentionRuns', 'fallida', 'enCurso', 'Reanudación desde `checkpoint`')
r('retentionRuns', 'preparada,pendienteAprobacion', 'cancelada', 'Cancelación')
r('encryptionKeys', '—', 'activa', 'Generación de la DEK')
r('encryptionKeys', 'activa', 'soloDescifrado', 'Rotación')
r('encryptionKeys', 'soloDescifrado', 'retirada', 'No quedan datos ni backups que la usen')
r('encryptionKeys', 'activa,soloDescifrado,retirada', 'comprometida', 'Rotación de emergencia y re-cifrado')
r('securityIncidents', '—', 'detectado', 'Detección o reporte')
for a, b, t in [('detectado', 'confirmado', 'Confirmación'), ('detectado', 'descartado', 'Descarte (exige motivo)'),
                ('confirmado', 'contenido', 'Contención'), ('confirmado', 'notificado', 'Vence el plazo de aviso antes de contener'),
                ('contenido', 'notificado', 'Hay tenants afectados'), ('contenido', 'erradicado', 'Sin tenants afectados'),
                ('notificado', 'contenido', 'Contención tras el aviso'), ('notificado', 'erradicado', 'Erradicación'),
                ('erradicado', 'recuperado', 'Recuperación'), ('recuperado', 'postmortem', 'Análisis posterior'),
                ('postmortem', 'cerrado', 'Cierre')]:
    r('securityIncidents', a, b, t, 'Registro por tenant en `notifications`' if b == 'notificado' else '—')
r('statusNotices', '—', 'programado', 'Alta del aviso (mantenimiento o incidente)')
r('statusNotices', 'programado', 'enCurso', 'Llega `scheduledFrom` o se declara el incidente')
r('statusNotices', 'enCurso', 'resuelto', 'Resolución')
r('statusNotices', 'programado', 'cancelado', 'Cancelación')

d.after_line('| `legalHolds` | `propuesto` | `anulado` | Se desiste antes de aprobar | Motivo | — |', T)
d.rep("`retentionPolicies.status` y `subprocessors.status` no tenían valores en §15.1:",
      "Filas de alta agregadas en el cierre de residuales (05-11-2026; PA-NFR-24): `consentRecords`, `legalHolds`, `retentionRuns`, `encryptionKeys`, `securityIncidents` y `statusNotices` (las máquinas en texto de arriba siguen vigentes). `dataSubjectRequests` ya tenía su alta en la tabla de arriba y §15.1 lista ahora sus valores. La máquina de `alerts` de arriba usa nombres en castellano; la colección es de T01 (COL-PLA-15), cuyo §8 prevalece (`open` inicial). `retentionPolicies.status` y `subprocessors.status` no tenían valores en §15.1:")

# --- Cat. 2: destinos en el texto de §15.1 ---
for f, dest in (('`purposesCovered` ([ObjectId]', 'processingActivities'),):
    pass
import re
m = re.search(r'`purposesCovered` \(\[ObjectId\][^)]*\)', d.t)
old = m.group(0)
d.rep(old, old[:-1] + '; → `processingActivities`)')
d.rep('`noticeId` + `noticeVersion`', '`noticeId` (→ `privacyNotices`) + `noticeVersion`')

# --- Cat. 5: capabilities ---
d.cell('| API-NFR-27 |', 4, '`public: true` (antes "pública")')
d.cell('| API-NFR-28 |', 4, '`public: true` (con antiautomatización; antes "pública + antiautomatización")')
d.cell('| API-NFR-29 |', 4, '`public: true` (requiere token de documento; antes "pública con token de documento")')
d.cell('| API-NFR-30 |', 4, '`public: true` (limitada por tasa; antes "pública (limitada)")')
d.cell('| API-NFR-31 |', 4, '`public: true` (antes "pública")')
d.cell('| API-NFR-32 |', 4, '`public: true` (antes "pública")')
d.cell('| API-NFR-44 |', 4, '`pla.salud.sondear` (identidad técnica del orquestador, solo red privada, sin sesión; antes "Infraestructura: solo red privada del orquestador, sin sesión")')

# --- Cat. 7: CU-ARQ-01 es de T11 ---
d.rep('| CU-ARQ-01 (BASE §58) |', '| CU-ARQ-01 (BASE §58; dueño T11; la parte de plataforma de T01 es CU-PLA-15; aquí solo se citan los RNF) |')
d.rep('| BASE §58 | CU-ARQ-01 (reintentos', '| BASE §58 | CU-ARQ-01 de T11 (reintentos')

pa = '''### PA-NFR-24 — Cierre de residuales del anexo (estados, referencias, tablas de campos y API)

- **Pregunta:** ¿cómo se cierran los residuales del anexo detectados por los entregables de análisis?
- **Contexto:** varias máquinas de §15.2 estaban solo en texto sin estado de alta en tabla; `dataSubjectRequests` y `securityIncidents` no listaban valores en §15.1; 2 referencias no tenían destino en la definición del campo; 17 colecciones no tenían tabla de campos; 7 filas de §15.4 citaban reglas de acceso en lugar de una capability; CU-ARQ-01 se usaba como propio y es de T11.
- **Opciones:**
  - A) Agregar las filas de alta y transiciones en la tabla de §15.2; listar valores en §15.1; declarar destinos (`purposesCovered` → `processingActivities`, `noticeId` → `privacyNotices`); agregar §15.1.1 con tablas derivadas del texto y de T05 (obligatoriedad por regla: clave única, `status`, `code`, `name` y referencias de T05 = Sí); usar `public: true` (con la condición) y `pla.salud.sondear` (registrada en T02 §4.4.2); citar CU-ARQ-01 como de T11. **(Recomendada)**.
  - B) Dejar las máquinas solo en texto.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** diagramas de estados, contratos y ER de T08.
- **Estado:** Asumida (DEC-072): opción A.
'''
d.before_line('## 22. Trazabilidad de fuentes', pa.split('\n'))
print('T08 cambios', d.save(), 'filas', len(T))
