import re, sys
# uso: python res_grep.py archivo patron [desde] [hasta] [ancho]
f, pat = sys.argv[1], sys.argv[2]
a = int(sys.argv[3]) if len(sys.argv) > 3 else 1
b = int(sys.argv[4]) if len(sys.argv) > 4 else 10**9
w = int(sys.argv[5]) if len(sys.argv) > 5 else 220
for n, l in enumerate(open(f, encoding='utf-8-sig').read().split('\n'), 1):
    if a <= n <= b and re.search(pat, l):
        print(n, l.rstrip()[:w])
