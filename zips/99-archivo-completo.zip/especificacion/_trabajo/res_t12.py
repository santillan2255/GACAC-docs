import glob, os
from res_lib import Doc

for f in glob.glob(r'..\anexos\T12-*.md'):
    t = open(f, encoding='utf-8-sig').read()
    reps = [(o, n) for o, n in [('`int.cdr.batch-received`', '`int.cdr.batchReceived` (antes `int.cdr.batch-received`)'),
                                ('`int.network.provisioning-result`', '`int.network.provisioningResult` (antes `int.network.provisioning-result`)')] if o in t]
    if not reps:
        continue
    d = Doc(r'anexos\\' + os.path.basename(f))
    for o, n in reps:
        d.t = d.t.replace(o, n)
        d.n += 1
    print(os.path.basename(f), d.save())
