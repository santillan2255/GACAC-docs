﻿import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from res_lib_m12m19 import Doc

d = Doc('M16-SUE-personal-sueldos.md')
PA = 'PA-SUE-18'


def _idx(after, field):
    ls = d.t.split('\n')
    st = [i for i, l in enumerate(ls) if after in l]
    assert st, ('ancla', after)
    for j in range(st[0], len(ls)):
        if ls[j].startswith('| `%s` |' % field):
            return ls, j
    raise AssertionError(('fila', after, field))


def add_after(after, field, rows, cat=4):
    ls, j = _idx(after, field)
    ls[j + 1:j + 1] = rows
    d.t = '\n'.join(ls)
    d.n += 1
    d.cats[cat] = d.cats.get(cat, 0) + len(rows)


def set_ref(after, field, ref, desc=None, cat=2):
    ls, j = _idx(after, field)
    cells = ls[j].split(' | ')
    cells[-1] = ref + ' |'
    if desc is not None:
        cells[-2] = desc
    ls[j] = ' | '.join(cells)
    d.t = '\n'.join(ls)
    d.n += 1
    d.cats[cat] = d.cats.get(cat, 0) + 1


def code_row(txt='Código único por tenant (clave de T05; %s).' % PA):
    return ['| `code` | String | Sí | %s | — |' % txt]


# Cat 2: referencias
set_ref('Campos de `employmentStatusPeriods`', 'sourceRef',
        'Polimórfica según `source`: `leaveRequests` (M16), `workAccidents` (M16), `disciplinaryActions` (M16) o `terminations` (M16); `manual` y `hire` sin referencia (antes `[VERIFICAR]`)')
set_ref('### 7.26. `novelties`', 'sourceRef', '— (clave idempotente del origen, texto; no es referencia)')
set_ref('Campos de `timePunches`', 'deviceId',
        '— (identificador del dispositivo embebido en `localAgents.devices[]` (T06); no es ObjectId de colección, T05 §7.2)',
        desc='Identificador del lector de fichadas (antes "[VERIFICAR] si existe colección de dispositivos"; T05 §7.2, PA-DAT-04).')
set_ref('Campos de `extraTasks`', 'sourceRef', '`workOrders` (M10) (antes `[VERIFICAR]`; ' + PA + ')',
        desc='Orden de trabajo que originó la tarea; T05 la nombra `workOrderId` (clave de COL-SUE) y este anexo conserva `sourceRef` como alias.')
set_ref('### 7.33. `payrollRuns`', 'comparisonRef', '— (clave del comparativo calculado por el job; no es referencia)')
set_ref('### 7.34. `payslips`', 'pdfRef`, `pdfHash', '`storedFiles` (T01) (solo `pdfRef`; `pdfHash` es texto)')
set_ref('Campos de `statutoryFilings`', 'vepRef', '`paymentExecutions` (M14) (pago del VEP; antes "M14, colección [VERIFICAR]"; ' + PA + ')')
set_ref('**`administrativeInquiries`** — campos', 'resultingActionIds', '`disciplinaryActions` (M16) (antes `[VERIFICAR]`)')

# Cat 4: campos clave de T05
add_after('Campos de `employeeCostAllocations`', 'allocations',
          ['| `costCenterId` | ObjectId | — | Clave de T05: es `allocations[].costCenterId`, no un campo de primer nivel (' + PA + '). | `costCenters` (M15) |'])
add_after('Campos de `employeeDocuments`', 'fileRefs',
          ['| `documentRefId` | ObjectId | [VERIFICAR] | Expediente del documento en T11 (clave de T05; ' + PA + '). | `documents` (T11) |'])
for anchor, first in [('**`extraGroups`**', 'name'), ('**`extraItems`**', 'name'), ('**`unions`**', 'name'),
                      ('**`payrollAccountingRules`**', 'name'), ('**`performanceTemplates`**', 'name'),
                      ('**`performanceCycles`**', 'name'), ('**`reportGroups`**', 'name'), ('**`externalPayrollLayouts`**', 'name')]:
    try:
        add_after(anchor, first, code_row())
    except AssertionError:
        alt = anchor.replace('**`', 'Campos de `').replace('`**', '`')
        add_after(alt, first, code_row())
add_after('**`payrollAccountingRules`**' if '**`payrollAccountingRules`**' in d.t else 'Campos de `payrollAccountingRules`', 'name',
          ['| `payrollConceptId` | ObjectId | [VERIFICAR] | Concepto de liquidación al que aplica la regla (clave de T05; ' + PA + '). | `payrollConcepts` (M16) |'])
add_after('**`salaryScales`**' if '**`salaryScales`**' in d.t else 'Campos de `salaryScales`', 'laborAgreementId',
          ['| `salaryCategoryId` | ObjectId | Sí | Categoría de la escala; `{salaryCategoryId, validFrom}` único (T05; ' + PA + '). | `salaryCategories` (M16) |'])
set_ref('Campos de `noveltyImportBatches`', 'fileRef', '`storedFiles` (T01)',
        desc='T05 lo nombra `storedFileId` (clave de COL-SUE; ' + PA + '); `fileRef` queda como alias.', cat=4)
set_ref('Campos de `statutoryFilings`', 'fileRef', '`storedFiles` (T01)',
        desc='T05 lo nombra `storedFileId` (' + PA + '); `fileRef` queda como alias.', cat=4)
set_ref('Campos de `employmentCertificates`', 'fileRef', '`storedFiles` (T01)',
        desc='T05 lo nombra `storedFileId` (' + PA + '); `fileRef` queda como alias.', cat=4)
add_after('Campos de `payslipNotifications`', 'payslipId',
          ['| `signatureRequestId` | ObjectId | Cond. | Solicitud de firma del recibo (clave de T05; ' + PA + '). | `signatureRequests` (T11) |'])
add_after('**`administrativeInquiries`** — campos', 'employeeIds',
          ['| `number` | String | Sí | Número del sumario, único por tenant (T05; ' + PA + '). | — |'])
add_after('**`workAccidents`** — campos', 'employeeId',
          ['| `number` | String | Sí | Número de la denuncia interna, único por tenant (T05; ' + PA + '). | — |'])
add_after('**`laborLawsuits`** — campos', 'employeeId',
          ['| `number` | String | Sí | Número interno del juicio, único por tenant (T05; ' + PA + '). | — |',
           '| `dossierId` | ObjectId | [VERIFICAR] | Expediente documental del juicio (clave de T05; ' + PA + '). | `documents` (T11) |'])
add_after('**`salaryIncreaseBatches`** — campos', 'target',
          ['| `number` | String | Sí | Número del lote, único por tenant (T05; ' + PA + '). | — |',
           '| `salaryScaleIds` | [ObjectId] | [VERIFICAR] | Escalas afectadas (clave de T05; ' + PA + '). | `salaryScales` (M16) |'])
add_after('**`externalPayrollLayouts`**' if '**`externalPayrollLayouts`**' in d.t else 'Campos de `externalPayrollLayouts`', 'format',
          ['| `fileLayoutId` | ObjectId | [VERIFICAR] | Layout declarativo del motor de T06 (clave de T05; ' + PA + '). | `fileLayouts` (T06) |'])
add_after('Campos de `extraTasks`', 'workers',
          ['| `employeeId` | ObjectId | — | Clave de T05: es `workers[].employeeId`, no un campo de primer nivel (' + PA + '). | `employees` (M16) |'])

# Cat 1: valores de estado faltantes
set_ref('Campos de `shifts`', 'status', '—', desc='`active`, `inactive` (convención de maestros del §7; §8.12.11; antes sin valores, ' + PA + ').', cat=1)
set_ref('Campos de `extraTasks`', 'status', '—', desc='`draft`, `confirmed`, `voided` (§8.12.12; antes sin valores, ' + PA + ').', cat=1)

# Cat 1: estado inicial
d.rep('### 8.2. Escala salarial y versión de configuración\n', '### 8.2. Escala salarial y versión de configuración (`payrollConfigVersions.status`)\n\nEstado inicial: `draft` (alta → `draft`; ' + PA + ').\n', cat=1)
for h, st in [('### 8.6. Recibo (`payslips.status`)', 'calculated'),
              ('### 8.7. Solicitud de pago (`payrollPaymentRequests.status`)', 'draft'),
              ('### 8.8. Presentación (`statutoryFilings.status`)', 'generated'),
              ('### 8.9. Egreso (`terminations.status`)', 'draft'),
              ('### 8.10. Liquidación externa (`externalPayrollImports.status`)', 'uploaded')]:
    d.rep(h + '\n\n', h + '\n\nEstado inicial: `%s` (alta → `%s`; %s).\n\n' % (st, st, PA), cat=1)
for old, col, st in [('- Sanción: ', 'disciplinaryActions', 'draft'), ('- Sumario: ', 'administrativeInquiries', 'open'),
                     ('- Accidente: ', 'workAccidents', 'reported'), ('- Juicio: ', 'laborLawsuits', 'active'),
                     ('- Ciclo de evaluación: ', 'performanceCycles', 'planned')]:
    lab = old[2:-2]
    d.rep(old, '- Estado inicial de `%s.status`: `%s` (alta → `%s`; %s).\n- %s (`%s.status`): ' % (col, st, st, PA, lab, col), cat=1)

d.insert_before('## 9. ', '''#### 8.12.11. Turno (`shifts.status`)

Estado inicial: `active` (corrección del 05-11-2026, %s).

| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |
|---|---|---|---|---|
| (alta) | `active` | Alta del turno | — | — |
| `active` | `inactive` | Baja lógica (sin asignaciones vigentes en `employeeShiftAssignments`) | — | — |
| `inactive` | `active` | Reactivación | — | — |

#### 8.12.12. Tarea extra (`extraTasks.status`)

Estado inicial: `draft`.

| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |
|---|---|---|---|---|
| (alta) | `draft` | Registro de la tarea (manual o desde la OT) | — | — |
| `draft` | `confirmed` | Confirmación: genera las novedades de `noveltyIds` | — | — |
| `draft` | `voided` | Descarte | — | — |
| `confirmed` | `voided` | Anulación; anula las novedades no liquidadas | Novedades sin liquidar | — |

#### 8.12.13. Lote de importación de novedades (`noveltyImportBatches.status`)

Estado inicial: `uploaded`.

| Desde | Hacia | Disparador | Guarda (RN) | Evento (EVT) |
|---|---|---|---|---|
| (alta) | `uploaded` | Carga del archivo o recepción del origen | `fileHash` no repetido | — |
| `uploaded` | `validated` | Validación de filas (`accepted`, `rejected`, `errors[]`) | — | — |
| `validated` | `confirmed` | Confirmación: crea las novedades aceptadas | Período abierto | — |
| `uploaded`, `validated` | `failed` | Error del job o rechazo total | — | — |

''' % PA, cat=1)

d.insert_before('## 22. Trazabilidad de fuentes', '''### PA-SUE-18 - Residuales del 05-11-2026 (estados, referencias y nombres de campo)
- **Pregunta:** ¿Cómo se cierran los residuales de M16 que detectaron los entregables regenerados?
- **Contexto:** el índice de estados marcó máquinas sin estado inicial (§8.2, §8.6 a §8.11), `noveltyImportBatches` con valores sin transiciones y `shifts` y `extraTasks` con `status` sin valores; el modelo entidad-relación dejó referencias sin destino; T05 declara campos clave (`code`, `number`, `storedFileId`, `signatureRequestId`, `salaryCategoryId`, `fileLayoutId`, `dossierId`) que este §7 no tenía.
- **Opciones:**
  - A) Estado inicial explícito; §8.12.11 a §8.12.13; `shifts` como maestro (`active`, `inactive`) y `extraTasks` con `draft`, `confirmed`, `voided`; destinos o "no es referencia" en cada campo; filas nuevas con los nombres de T05 y alias para los nombres de este anexo (`fileRef` = `storedFileId`, `sourceRef` = `workOrderId`) **(Recomendada)**.
  - B) Mantener el texto y resolver en los entregables.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** §7, §8.
- **Estado:** Asumida la recomendada (DEC-072). `vepRef` → `paymentExecutions` (M14) debe confirmarlo M14; los valores de `extraTasks.status` deben validarse con el liquidador piloto.

''', cat=0)
d.save()
