from res_lib import Doc

d = Doc(r'anexos\T02-IAM-*.md')


def add_row_in_block(label, row):
    """Agrega una fila al final de la tabla que sigue a la etiqueta en negrita `label`."""
    i = d.t.index(label)
    j = d.t.index('|---|---|---|---|---|\n', i) + len('|---|---|---|---|---|\n')
    k = d.t.index('\n\n', j)
    d.t = d.t[:k] + '\n' + row + d.t[k:]
    d.n += 1


# --- Cat. 5: scopes erp.* en §4.4.3 ---
d.after_line('| datasets | `datasets:read` |', [
    '| erp | `erp.catalog:read` | `stk.articulos.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X). Para `/suppliers` (API-BIA-107) se exige además `cmp.proveedores.ver` | T10 | API-BIA-105, API-BIA-106, API-BIA-107 |',
    '| erp | `erp.finance:read` | `tes.posicion.ver` | Scope de API externa (T10) con formato `recurso:acción`; se mapea a la capability y se declara como scope `apiExposable` (marca X). Para `/purchases` (API-BIA-109) se exige además `cmp.ordenes.ver` | T10 | API-BIA-108, API-BIA-109 |',
])

# --- Cat. 5: capabilities implícitas o técnicas que faltaban (PA-IAM-18) ---
d.after_line('| `pla.uso.ver` | Uso por tenant y dimensión |', [
    '| `pla.archivos.ver` | Descargar un archivo de `storedFiles`; implícita, no asignable: el control efectivo lo delega `canAccessFile` en la capability `ver` del módulo dueño (`storedFiles.moduleCode`, antes citado como capability) (PA-IAM-18) | — | Todos | según módulo dueño | API-PLA-62 |',
    '| `pla.archivos.subir` | Subir un archivo a `storedFiles`; implícita, no asignable: el control efectivo es la capability de alta o edición del módulo dueño (PA-IAM-18) | — | Todos | según módulo dueño | API-PLA-63 |',
    '| `pla.misProcesos.ver` | Ver los procesos propios (`jobRuns.requestedBy` = usuario, antes citado como capability); implícita, no asignable (PA-IAM-18) | — | Todos | self | API-PLA-67 |',
    '| `pla.salud.sondear` | Sondas de salud del orquestador (`/health/*`), solo red privada; identidad técnica S-SYS (PA-IAM-18) | — | S-SYS | global | API-PLA-66, API-NFR-44 |',
])
d.after_line('| `iam.rolesPlantilla.editar` | Canónica propuesta para rolesPlantilla.editar.', [
    '| `iam.sesion.autenticada` | Operar con una sesión válida sobre la propia sesión (ámbitos, contexto operativo, cierre, `me`, presencia, preferencias); implícita, no asignable: la tiene todo usuario autenticado del contexto (antes "sesión" en la celda de capability) (PA-IAM-18) | — | Todos | self | API-IAM-05, API-IAM-07, API-IAM-08, API-IAM-10, API-IAM-22, API-IAM-23, API-IAM-62 |',
    '| `iam.ia.decisiones.registrar` | Registrar la decisión humana sobre una sugerencia de IA (`auditAi.decision`); implícita: la otorga la capability de la función de IA que generó la sugerencia (PA-IAM-18) | — | Quien tenga la capability de la función de IA | según capability | API-IAM-60 |',
])
d.after_line('| `mig.valores.editar` | Mapas de valores del tenant |', [
    '| `mig.clavesHeredadas.resolver` | Resolver claves heredadas de ProCoop a IDs nuevos (servicio que consume M07); identidad técnica S-SYS (PA-IAM-18) | — | S-SYS | tenant | API-MIG-34 |',
    '| `mig.miHistorial.ver` | Ver el historial migrado propio en el portal; implícita, no asignable (C-SOC, alcance self) (PA-IAM-18) | — | C-SOC | self | API-MIG-36 |',
])

# --- Cat. 5: celdas de capability de §11 ---
pub = {
    'API-IAM-01': '`public: true` (rate limit; antes "pública (rate limit)")',
    'API-IAM-02': '`public: true` (antes "pública")',
    'API-IAM-03': '`public: true` (requiere transacción de autenticación; antes "transacción")',
    'API-IAM-04': '`public: true` (requiere transacción de autenticación; antes "transacción")',
    'API-IAM-05': '`iam.sesion.autenticada` o transacción de autenticación (antes "transacción o sesión")',
    'API-IAM-06': '`public: true` (requiere transacción de autenticación; antes "transacción")',
    'API-IAM-07': '`iam.sesion.autenticada` (antes "sesión")',
    'API-IAM-08': '`iam.sesion.autenticada` (contexto staff; antes "sesión staff")',
    'API-IAM-09': '`public: true` (requiere cookie de refresh; antes "cookie refresh")',
    'API-IAM-10': '`iam.sesion.autenticada` (antes "sesión")',
    'API-IAM-11': '`iam.miCuenta.gestionar` + step-up (antes "sesión + step-up")',
    'API-IAM-12': '`public: true` (antes "pública")',
    'API-IAM-13': '`public: true` (requiere token de acción; antes "token")',
    'API-IAM-14': '`iam.miCuenta.gestionar` + contraseña o factor (antes "sesión + contraseña/factor")',
    'API-IAM-15': '`public: true` (antes "pública")',
    'API-IAM-16': '`public: true` (antes "pública")',
    'API-IAM-17': '`public: true` (antes "pública")',
    'API-IAM-18': '`public: true` (antes "pública")',
    'API-IAM-19': '`public: true` (requiere token de invitación; antes "token")',
    'API-IAM-20': '`public: true` (antes "pública")',
    'API-IAM-21': '`public: true` (requiere token de verificación; antes "token")',
    'API-IAM-22': '`iam.sesion.autenticada` (antes "sesión")',
    'API-IAM-23': '`iam.sesion.autenticada` (antes "sesión")',
    'API-IAM-25': '`iam.miCuenta.gestionar` + step-up (antes "step-up")',
    'API-IAM-28': '`iam.miCuenta.gestionar` + step-up (antes "step-up")',
    'API-IAM-47': '`iam.apiClientes.ver` / `iam.apiClientes.gestionar` + step-up (antes `iam.apiClientes.*`)',
    'API-IAM-48': '`public: true` (requiere credencial del cliente API, OAuth `client_credentials`; antes "credencial cliente")',
    'API-IAM-50': '`iam.autorizaciones.solicitar` + credenciales del supervisor en el cuerpo (antes "credenciales del supervisor en body")',
    'API-IAM-52': '`iam.autorizaciones.bandeja` + capability requerida por la solicitud + step-up (antes "capability requerida + step-up")',
    'API-IAM-60': '`iam.ia.decisiones.registrar` (antes "capability de la función de IA")',
    'API-IAM-62': '`iam.sesion.autenticada` (contexto staff; antes "sesión staff")',
    'API-IAM-63': '`iam.portal.usuarios.ver` / `iam.portal.usuarios.gestionar` (antes `iam.portal.usuarios.*`)',
    'API-IAM-66': '`iam.plataforma.usuarios.gestionar` / `iam.plataforma.rolesPlantilla.editar` (antes `iam.plataforma.*`)',
}
for api, cap in pub.items():
    d.cell('| %s |' % api, 3, cap)

# --- Cat. 7: CU-SEG-01 de T02 pasa a CU-IAM-11 (dueño de CU-SEG-01: T08) ---
d.rep('### CU-SEG-01 — MFA y recuperación del administrador (BASE §60)',
      '### CU-IAM-11 — MFA y recuperación del administrador (BASE §60) (antes CU-SEG-01; el ID CU-SEG-01 es de T08)')
d.rep('caso de uso (CU-29, CU-ACC-01, CU-SEG-01, CU-GOB-01 según corresponda)',
      'caso de uso (CU-29, CU-ACC-01, CU-IAM-11 (antes CU-SEG-01), CU-GOB-01 según corresponda)')
d.rep('| MFA requerido (CU-SEG-01) |', '| MFA requerido (CU-IAM-11, antes CU-SEG-01) |')
d.rep('protección transversal (transporte, cifrado, archivos, pruebas, incidentes) → T08; CU-SEG-01 |',
      'protección transversal (transporte, cifrado, archivos, pruebas, incidentes) → T08; CU-IAM-11 (antes CU-SEG-01; CU-SEG-01 es de T08) |')

# --- Cat. 2 y 4: destinos y nombres canónicos en §7 ---
d.rep('| `mfa` | `{ enrolled: bool, defaultFactorId: ObjectId }` | Sí | |',
      '| `mfa` | `{ enrolled: bool, defaultFactorId: ObjectId }` | Sí | `defaultFactorId` → `authFactors` |')
d.rep('| `idpConfigId` | ObjectId | No | Para `oidcTenant`/`cidi` |',
      '| `idpConfigId` | ObjectId | No | Para `oidcTenant`/`cidi`; → `identityProviderConfigs` |')
d.rep('| `familyId` | string | Sí | |',
      '| `refreshFamilyId` | string | Sí | Familia de rotación del refresh (identificador técnico, no referencia); nombre canónico de T05 (antes `familyId`) |')
d.rep('| `supportGrantId` | ObjectId | No | Sesiones de soporte |',
      '| `supportGrantId` | ObjectId | No | Sesiones de soporte; → `supportAccessGrants` |')
d.rep('| `revokedAt`, `revokedReason` | | No | `logout`, `logoutAll`, `reuseDetected`, `admin`, `passwordChanged`, `membershipRevoked` |',
      '| `revokedAt`, `revokedReason` | | No | `logout`, `logoutAll`, `reuseDetected`, `admin`, `passwordChanged`, `membershipRevoked` |\n'
      '| `status` | enum | Sí | `active`, `rotated`, `revoked`, `expired` (§8.4; antes implícito en el texto del §8) |')
d.rep('| `expiresAt`, `consumedAt`, `consumedRequestId` | | Sí/No | |',
      '| `expiresAt`, `consumedAt`, `consumedRequestId` | | Sí/No | `consumedRequestId`: `requestId` de la acción que consumió la autorización; su entrada de auditoría está en → `auditLogs` |')
d.rep('`modelVersion`, `promptTemplateId`, `promptTemplateVersion`',
      '`modelVersion`, `promptTemplateCode` (código de la plantilla de prompt versionada en código, no colección; antes `promptTemplateId`), `promptTemplateVersion`')
d.rep('`tenantId`, `membershipId`, `profileId`, `validFrom`, `validTo`, `status`, `grantedBy`, `grantedAt`. Índice',
      '`tenantId`, `membershipId`, `screenProfileId` (→ `screenProfiles`; antes `profileId`), `validFrom`, `validTo`, `status` (`active`, `expired`, `revoked`), `grantedBy`, `grantedAt`. Índice')
d.rep("`enforcement` (`block`, `warn`), `descriptionKey`, `status`.",
      "`enforcement` (`block`, `warn`), `descriptionKey`, `status` (`active`, `inactive`).")
d.rep('`revokedAt`, `rotatedFromId`.',
      '`revokedAt`, `rotatedFromId` (→ `apiCredentials`), `status` (`active`, `rotating`, `expired`, `revoked`; §8.8).')

# filas de las tablas nuevas del §7.20
pa = d.t.index('**`profileAssignments`**')
blk_end = d.t.index('\n\n**`', pa + 10)
blk = d.t[pa:blk_end]
blk2 = blk.replace('| `status` | enum | Sí | — | Según la definición en texto del §7 |',
                   '| `status` | enum | Sí | — | `active`, `expired`, `revoked` (§8.11) |')
assert blk2 != blk
d.t = d.t[:pa] + blk2 + d.t[blk_end:]
sr = d.t.index('**`sodRules`**')
blk_end = d.t.index('\n\n**`', sr + 10)
blk = d.t[sr:blk_end]
blk2 = blk.replace('| `status` | enum | Sí | — | Según la definición en texto del §7 |',
                   '| `status` | enum | Sí | — | `active`, `inactive` (§8.11) |')
assert blk2 != blk
d.t = d.t[:sr] + blk2 + d.t[blk_end:]
add_row_in_block('**`apiCredentials`**', '| `status` | enum | Sí | — | `active`, `rotating`, `expired`, `revoked` (§8.8) |')

# --- Cat. 1: tabla normalizada de estados ---
est = '''### 8.11 Tabla normalizada de estados iniciales y transiciones

Completa las §8.1–8.10 con una fila por transición, el estado inicial explícito (`—` = alta) y las máquinas que solo listaban estados en el §7 (PA-IAM-18, Asumida DEC-072). Prevalece el texto de §8.1–8.10 si hay diferencia; `*` de §8.1 y §8.3 se explicita por estado de origen.

| Colección | Desde | Hasta | Disparador | Guarda | Evento |
|---|---|---|---|---|---|
| `identities.status` | — | `pendingActivation` | Invitación, registro de socio o migración | Correo válido | — |
| `identities.status` | `pendingActivation` | `active` | Titular verifica y define acceso | — | `iam.identity.activated` |
| `identities.status` | `active` | `locked` | Sistema por fallos (`PRM-IAM-011`) | — | — |
| `identities.status` | `locked` | `active` | Vencimiento, recuperación o desbloqueo T-ADM | — | — |
| `identities.status` | `active` | `suspended` | P-SEC por incidente | — | — |
| `identities.status` | `suspended` | `active` | P-SEC reactiva con step-up del titular | — | — |
| `identities.status` | `pendingActivation` | `disabled` | Supresión (T08) o vencimiento sin pertenencias | Sin obligaciones que impidan (T08) | — |
| `identities.status` | `active` | `disabled` | Titular (supresión) / P-SEC | Sin obligaciones que impidan (T08) | — |
| `identities.status` | `locked` | `disabled` | Titular (supresión) / P-SEC | Sin obligaciones que impidan (T08) | — |
| `identities.status` | `suspended` | `disabled` | Titular (supresión) / P-SEC | Sin obligaciones que impidan (T08) | — |
| `authFactors.status` | — | `pending` | Titular inicia el enrolamiento | — | — |
| `authFactors.status` | `pending` | `active` | Verificación con código o attestation | — | — |
| `authFactors.status` | `pending` | `revoked` | Titular cancela o vence el enrolamiento | — | — |
| `authFactors.status` | `active` | `revoked` | Titular con step-up, T-ADM (recuperación asistida) o sistema (compromiso) | No quitar el último factor con MFA obligatorio salvo recuperación asistida | — |
| `federatedLinks.status` | — | `active` | Titular vincula Google, CiDi o IdP del tenant (API-IAM-28) | Step-up | — |
| `federatedLinks.status` | `active` | `revoked` | Titular desvincula (API-IAM-28) o P-SEC | Queda otro método de ingreso | — |
| `memberships.status` | — | `invited` | T-ADM/T-USR invita (staff) | `iam.usuarios.invitar` | — |
| `memberships.status` | `invited` | `active` | Invitado acepta | Vigencia; MFA si corresponde | `iam.membership.activated` |
| `memberships.status` | — | `active` | Registro verificado de socio o visitante (portal) | — | `iam.membership.activated` |
| `memberships.status` | `active` | `suspended` | T-ADM/T-USR o sistema (inactividad, recertificación vencida) | Motivo | — |
| `memberships.status` | `suspended` | `active` | T-ADM/T-USR | — | — |
| `memberships.status` | `active` | `revoked` | T-ADM/T-USR o `sue.employee.terminated` | Motivo | — |
| `memberships.status` | `suspended` | `revoked` | T-ADM/T-USR o `sue.employee.terminated` | Motivo | — |
| `memberships.portal.status` | — | `registered` | Registro del socio o visitante (API-IAM-20) | Correo verificado | — |
| `memberships.portal.status` | `registered` | `linked` | Vinculación de cuenta con prueba (API-IAM-29) | Prueba válida | — |
| `memberships.portal.status` | `registered` | `blocked` | T-ADM/T-USR bloquea (API-IAM-63) | Motivo | — |
| `memberships.portal.status` | `linked` | `blocked` | T-ADM/T-USR bloquea (API-IAM-63) | Motivo | — |
| `memberships.portal.status` | `blocked` | `registered` | T-ADM/T-USR desbloquea (API-IAM-63) | Sin cuenta vinculada | — |
| `memberships.portal.status` | `blocked` | `linked` | T-ADM/T-USR desbloquea (API-IAM-63) | Con cuenta vinculada | — |
| `memberships.portal.status` | `linked` | `registered` | T-ADM/T-USR desvincula (API-IAM-63, `unlink`) | — | — |
| `roleAssignments.status` | — | `active` | T-ADM/T-USR asigna | `iam.roles.asignar`; SoD | `iam.role.assigned` |
| `roleAssignments.status` | `active` | `suspended` | T-ADM/T-USR o recertificación vencida | — | — |
| `roleAssignments.status` | `suspended` | `active` | T-ADM/T-USR o recertificación aprobada | — | — |
| `roleAssignments.status` | `active` | `expired` | Sistema al llegar `validTo` | — | — |
| `roleAssignments.status` | `active` | `revoked` | T-ADM/T-USR u offboarding | — | `iam.role.unassigned` |
| `roleAssignments.status` | `suspended` | `revoked` | T-ADM/T-USR u offboarding | — | `iam.role.unassigned` |
| `profileAssignments.status` | — | `active` | T-ADM/T-USR asigna el perfil (API-IAM-39) | `iam.perfiles.asignar` | — |
| `profileAssignments.status` | `active` | `expired` | Sistema al llegar `validTo` | — | — |
| `profileAssignments.status` | `active` | `revoked` | T-ADM/T-USR quita el perfil (API-IAM-39) u offboarding | — | — |
| `sodRules.status` | — | `active` | T-ADM configura la regla (API-IAM-42) o set por defecto de `PLATFORM` | `iam.sod.configurar` | — |
| `sodRules.status` | `active` | `inactive` | T-ADM desactiva la regla (API-IAM-42) | `iam.sod.configurar`; las reglas de `PLATFORM` no se desactivan | — |
| `sodRules.status` | `inactive` | `active` | T-ADM reactiva la regla (API-IAM-42) | `iam.sod.configurar` | — |
| `sodExceptions.status` | — | `requested` | T-ADM/T-USR pide la excepción (API-IAM-43) | Justificación y control compensatorio | — |
| `sodExceptions.status` | `requested` | `approved` | Aprobador (API-IAM-43) | `iam.sod.excepcionAprobar`; aprobador ≠ solicitante | — |
| `sodExceptions.status` | `requested` | `rejected` | Aprobador (API-IAM-43) | Motivo | — |
| `sodExceptions.status` | `approved` | `expired` | Sistema al llegar `validTo` | — | — |
| `sodExceptions.status` | `approved` | `revoked` | T-ADM o recertificación | — | — |
| `sessions.status` | — | `active` | Login o selección de ámbito (API-IAM-06) | — | — |
| `sessions.status` | `active` | `rotated` | Refresh (API-IAM-09); mismo documento | — | — |
| `sessions.status` | `rotated` | `active` | Refresh vigente dentro de la gracia | — | — |
| `sessions.status` | `active` | `revoked` | `logout`, `logoutAll`, `reuseDetected`, `admin`, `passwordChanged`, `membershipRevoked`, `idleAbsolute` | — | — |
| `sessions.status` | `rotated` | `revoked` | Reutilización detectada (`reuseDetected`) | — | — |
| `sessions.status` | `active` | `expired` | `expiresAt` o `absoluteExpiresAt` | — | — |
| `actionTokens.status` | — | `issued` | Invitación, recuperación o verificación | — | — |
| `actionTokens.status` | `issued` | `consumed` | Uso válido del token | Vigente | — |
| `actionTokens.status` | `issued` | `expired` | Vencimiento | — | — |
| `actionTokens.status` | `issued` | `revoked` | Reenvío (se emite un token nuevo) | — | — |
| `authorizationRequests.status` | — | `pending` | Solicitante (API-IAM-49) | Acción U denegada; motivo | `iam.authorization.requested` |
| `authorizationRequests.status` | `pending` | `approved` | Aprobador (API-IAM-50, API-IAM-52) | Capability, alcance y límite; ≠ solicitante; step-up | `iam.authorization.granted` |
| `authorizationRequests.status` | `pending` | `rejected` | Aprobador (API-IAM-52) | Motivo obligatorio | — |
| `authorizationRequests.status` | `pending` | `cancelled` | Solicitante (API-IAM-52) | — | — |
| `authorizationRequests.status` | `pending` | `expired` | Sistema por `expiresAt` | — | — |
| `authorizationRequests.status` | `approved` | `consumed` | Solicitante o sistema ejecuta la acción | Mismo `actionHash`, vigente | — |
| `authorizationRequests.status` | `approved` | `expired` | Sistema por vigencia de consumo | — | — |
| `supportAccessGrants.status` | — | `requested` | P-SUP solicita (API-IAM-65) | — | — |
| `supportAccessGrants.status` | — | `active` | P-SUP por emergencia (`approvalType = emergency`) | Revisión posterior en 72 h | — |
| `supportAccessGrants.status` | `requested` | `approved` | T-ADM aprueba (API-IAM-64) | — | — |
| `supportAccessGrants.status` | `requested` | `rejected` | T-ADM rechaza (API-IAM-64) | — | — |
| `supportAccessGrants.status` | `approved` | `active` | Inicio (`startsAt`, API-IAM-65 `start`) | — | — |
| `supportAccessGrants.status` | `active` | `expired` | `expiresAt` | — | — |
| `supportAccessGrants.status` | `active` | `revoked` | T-ADM, P-SUP o P-SEC (API-IAM-64 `revoke`) | — | — |
| `identityProviderConfigs.status` | — | `draft` | T-ADM crea el IdP (API-IAM-46) | `iam.idp.configurar` | — |
| `identityProviderConfigs.status` | `draft` | `active` | T-ADM habilita tras prueba exitosa (API-IAM-46 `test`) | `lastTestResult` correcto | — |
| `identityProviderConfigs.status` | `active` | `disabled` | T-ADM deshabilita (API-IAM-46) | Queda otro método de ingreso para los usuarios | — |
| `identityProviderConfigs.status` | `disabled` | `active` | T-ADM rehabilita (API-IAM-46) | Prueba exitosa | — |
| `apiClients.status` | — | `active` | T-ADM crea el cliente (API-IAM-47) | `iam.apiClientes.gestionar` + step-up | — |
| `apiClients.status` | `active` | `suspended` | T-ADM o P-SEC suspende (API-IAM-47) | Motivo | — |
| `apiClients.status` | `suspended` | `active` | T-ADM reactiva (API-IAM-47) | — | — |
| `apiClients.status` | `active` | `revoked` | T-ADM o P-SEC revoca (API-IAM-47 `revoke`) | — | — |
| `apiClients.status` | `suspended` | `revoked` | T-ADM o P-SEC revoca (API-IAM-47 `revoke`) | — | — |
| `apiCredentials.status` | — | `active` | Alta del cliente o rotación (API-IAM-47) | — | — |
| `apiCredentials.status` | `active` | `rotating` | Rotación (API-IAM-47 `rotate`) | Dos secretos durante `PRM-IAM-074` horas | — |
| `apiCredentials.status` | `rotating` | `revoked` | Fin de la ventana de rotación (credencial anterior) | — | — |
| `apiCredentials.status` | `active` | `expired` | `expiresAt` | — | — |
| `apiCredentials.status` | `active` | `revoked` | T-ADM o P-SEC | — | — |
| `auditMessages.status` | — | `queued` | T09 encola el mensaje | — | — |
| `auditMessages.status` | `queued` | `sent` | Proveedor acepta el envío | — | — |
| `auditMessages.status` | `queued` | `rejected` | Proveedor rechaza el envío | — | — |
| `auditMessages.status` | `sent` | `delivered` | Acuse de entrega del proveedor | — | — |
| `auditMessages.status` | `sent` | `bounced` | Rebote informado por el proveedor | — | — |
| `auditMessages.status` | `sent` | `failed` | Error definitivo del proveedor | — | — |
| `auditMessages.status` | `delivered` | `opened` | Apertura informada por el proveedor | — | — |
| `auditAi.decision.status` | — | `pending` | Se registra la sugerencia de IA | — | — |
| `auditAi.decision.status` | `pending` | `accepted` | Usuario acepta (API-IAM-60) | `iam.ia.decisiones.registrar` | — |
| `auditAi.decision.status` | `pending` | `edited` | Usuario acepta con cambios (API-IAM-60) | `iam.ia.decisiones.registrar` | — |
| `auditAi.decision.status` | `pending` | `rejected` | Usuario descarta (API-IAM-60) | `iam.ia.decisiones.registrar` | — |
| `auditAi.decision.status` | `pending` | `expired` | Sistema: sin decisión dentro de la vigencia | — | — |
| `accessReviews.status` | — | `open` | Apertura del período de recertificación | — | — |
| `accessReviews.status` | `open` | `completed` | Revisor decide todos los ítems (API-IAM-68) | `iam.recertificacion.ejecutar` | — |
| `accessReviews.status` | `open` | `overdue` | Sistema al pasar `dueAt` | — | — |
| `accessReviews.status` | `overdue` | `completed` | Revisor completa fuera de término (API-IAM-68) | `iam.recertificacion.ejecutar` | — |
| `securityAlerts.status` | — | `open` | Detección de la regla de seguridad | Deduplicación por `dedupKey` | — |
| `securityAlerts.status` | `open` | `acknowledged` | P-SEC o T-ADM toma la alerta (API-IAM-67) | — | — |
| `securityAlerts.status` | `acknowledged` | `resolved` | P-SEC o T-ADM resuelve (API-IAM-67) | `resolution` obligatoria | — |
| `securityAlerts.status` | `acknowledged` | `falsePositive` | P-SEC o T-ADM descarta (API-IAM-67) | `resolution` obligatoria | — |

'''
d.before_line('## 9. ', est.split('\n'))

# --- PA-IAM-18 ---
pa = '''### PA-IAM-18 — Cierre de residuales del anexo (capabilities, estados, referencias y CU)

- **Pregunta:** ¿cómo se cierran los residuales del anexo detectados por los entregables de análisis: celdas de capability sin capability, scopes `erp.*` no registrados, estados sin estado inicial o sin transiciones, referencias sin destino, colecciones sin tabla de campos y el CU-SEG-01 duplicado con T08?
- **Contexto:** 33 filas de §11 citaban "pública", "sesión", "token", "step-up" o comodines; T10 usa `erp.catalog:read` y `erp.finance:read` sin registro; 12 colecciones no declaraban estado inicial y 6 solo listaban estados; 20 colecciones del §7 no tenían tabla de campos; el ID CU-SEG-01 es de T08.
- **Opciones:**
  - A) Usar `public: true` (con la condición entre paréntesis) en las rutas sin sesión; registrar capabilities implícitas no asignables (`iam.sesion.autenticada`, `iam.ia.decisiones.registrar`, `pla.archivos.ver`, `pla.archivos.subir`, `pla.misProcesos.ver`) y técnicas (`pla.salud.sondear`, `mig.clavesHeredadas.resolver`) más `mig.miHistorial.ver`; mapear `erp.catalog:read` → `stk.articulos.ver` y `erp.finance:read` → `tes.posicion.ver` en §4.4.3; agregar la tabla normalizada §8.11 con valores para `profileAssignments` (`active`, `expired`, `revoked`), `sodRules` (`active`, `inactive`), `sessions` y `apiCredentials`; declarar destinos y nombres canónicos de T05 (`refreshFamilyId`, `screenProfileId`; `promptTemplateCode` porque las plantillas de prompt viven en código); agregar las tablas de campos del §7.20 derivadas del texto y de T05 (obligatoriedad por regla); renumerar el CU propio a CU-IAM-11. **(Recomendada)**.
  - B) Mantener el texto y documentar las excepciones en los entregables.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** contratos OpenAPI (seguridad por operación), diagramas de estados y ER de T02.
- **Estado:** Asumida (DEC-072): opción A.

'''
d.before_line('## 22. Trazabilidad de fuentes', pa.split('\n'))
print('T02 cambios', d.save())
