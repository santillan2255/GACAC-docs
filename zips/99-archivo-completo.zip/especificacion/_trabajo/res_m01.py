from res_m0106_lib import Doc

d = Doc('M01')

# --- Categoría 1: máquinas sobre colecciones absorbidas (INC-06-04) y estado inicial ---
d.rep("`received` → `inProgress` (identidad verificada) → `resolved` (con evidencia) o `rejected` (con fundamento). Aviso por vencimiento de plazo.",
      "— → `received` (alta de la solicitud; estado inicial) → `inProgress` (identidad verificada) → `resolved` (con evidencia) o `rejected` (con fundamento). Aviso por vencimiento de plazo.\n\n"
      "> Colección absorbida (T05: COL-PER-20 A→COL-NFR-05): la solicitud se guarda en `dataSubjectRequests` de T08, que es el dueño de la máquina; esta subsección queda como referencia del circuito que inicia M01 (PA-PER-19).", '1')
d.rep("### 8.13 Vínculo usuario–persona (`personUserLinks.status`)\n",
      "### 8.13 Vínculo usuario–persona (`personUserLinks.status`)\n\n"
      "> Colección absorbida (T05: COL-PER-21 A→COL-IAM-04): el vínculo se persiste en `memberships` de T02, dueño del estado; la tabla describe el circuito de verificación que ejecuta M01 y se conserva como referencia (PA-PER-19).\n", '1')

# --- Categoría 2: referencias ---
d.rep("Solicitud de alta de calle pendiente (RF-PER-084). Referencia: `streetProposals` (T04). |",
      "Solicitud de alta de calle pendiente (RF-PER-084). Referencia: → `streetProposals` (T04, COL-CFG-14). |", '2')

# --- Categoría 3: tablas de campos asociadas a su colección ---
d.anchor_field_tables('3')
d.rep("\n`documentSubmissions` (equivalente a `PTRAMITES`):\n",
      "\n**`documentSubmissions`** (equivalente a `PTRAMITES`):\n", '3')

# --- Categoría 4: nombres de T05 ---
d.rep("> **Alineación con T05 (05-11-2026):** T05 usa `fromPersonId`/`toPersonId`; la ficha modela `subjectPersonId` (persona que actúa) y `target` (destino tipado, que puede ser persona, titular o cuenta). No es un renombre 1 a 1: se informa a T05.",
      "> **Alineación con T05 (05-11-2026):** T05 usa `fromPersonId`/`toPersonId`; la ficha modela `subjectPersonId` (persona que actúa) y `target` (destino tipado, que puede ser persona, titular o cuenta). No es un renombre 1 a 1: se informa a T05.\n>\n"
      "> **Actualización (ronda de residuales del 05-11-2026, PA-PER-19):** T05 COL-PER-10 ya unificó los nombres de esta ficha: `subjectPersonId` y `target` (`{type, id}`) en claves y en el único `{subjectPersonId, target.type, target.id, relationshipTypeId, validFrom}` (antes `fromPersonId`/`toPersonId`). M01 no cambia; el payload de EVT-PER-18 usa los mismos nombres.", '4')

PA = '''
### PA-PER-19 - Residuales de estados, referencias y nombres (ronda del 05-11-2026)
- **Pregunta:** ¿Cómo se tratan las máquinas de §8 que describen colecciones absorbidas por otro dueño, la referencia `streetRequestId` sin destino legible y la diferencia de nombres de `relationships` con T05?
- **Contexto:** al regenerar los entregables, 06a §6 marcó `dataSubjectRequests` (§8.12, sin estado inicial) y `personUserLinks` (§8.13) como máquinas sobre colecciones que T05 absorbe en T08 y T02; 03-er marcó `addresses.streetRequestId` sin destino; 03 §29 punto 7 citó `fromPersonId`/`toPersonId` para `relationships`, pero T05 COL-PER-10 ya usa `subjectPersonId` y `target` (el generador leyó el texto «antes»).
- **Opciones:**
  - A) **(Recomendada)** Mantener las subsecciones como referencia del circuito que inicia M01 con nota de colección absorbida y dueño del estado (T08, T02), explicitar el estado inicial `received`; declarar `streetRequestId` → `streetProposals` (T04); confirmar `subjectPersonId`/`target` como nombres canónicos (sin cambios en M01).
  - B) Marcar las subsecciones como reemplazadas y mover el texto a T08 y T02.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** 06 (estados), 03 (ER), T05 §7.2.1.
- **Estado:** Asumida (DEC-072): opción A. Aplicado en §7.5 (`streetRequestId`), §7.9 (nota de alineación), §7.1 y §7.13 (tablas asociadas a `personIdentifierIndex` y `documentSubmissions`), §8.12 y §8.13. T05 no necesita cambio en `relationships`; el destino de `premises.units` (`unitId`) es el subdocumento de `premises` y T05 §7.2.1 puede cerrar su [VERIFICAR].
'''
d.insert_before('\n## 22. ', PA, 'PA')
d.save()
