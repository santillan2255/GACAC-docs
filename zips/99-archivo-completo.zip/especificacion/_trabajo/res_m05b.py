import re
from res_m0106_lib import Doc

d = Doc('M05')

for f in ('authorizationPhase', 'distributionPhase'):
    d.rep_line('| `%s` | Enum `' % f,
               lambda l: re.sub(r'`([A-Za-z]+(?:, [A-Za-z]+)+)`',
                                lambda m: ', '.join('`%s`' % v for v in m.group(1).split(', ')), l), '1')

ROWS = '''
| `billingRuns.authorizationPhase` | — | `notRequired`/`pending` | Emisión del lote (`issuing`): `notRequired` si no hay comprobantes a autorizar | — | — |
| `billingRuns.authorizationPhase` | `pending` | `inProgress` | Envío de comprobantes a M06 | — | — |
| `billingRuns.authorizationPhase` | `inProgress` | `completed`/`completedWithIssues` | Respuestas de M06 recibidas | — | — |
| `billingRuns.distributionPhase` | — | `notStarted` | Emisión del lote (`issuing`) | — | — |
| `billingRuns.distributionPhase` | `notStarted` | `inProgress` | Inicio de la distribución (§8.9) | — | — |
| `billingRuns.distributionPhase` | `inProgress` | `completed`/`completedWithIssues` | Fin de la distribución | — | — |
| `invoices.fiscal.status` | — | `notRequired`/`pending` | Emisión: `notRequired` para comprobante interno, CAI o manual; `pending` si requiere autorización de ARCA | — | `fac.invoice.issued` |'''
d.insert_after("| `paymentSlips` | `active` | `paid` | Cobro informado por M07 | — | — |", ROWS, '1')
d.save()
