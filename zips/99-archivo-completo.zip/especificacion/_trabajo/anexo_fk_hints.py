#!/usr/bin/env python3
"""Referencias FK deducidas de tablas §7 (columna Referencia / tipo ObjectId)."""
from __future__ import annotations

import re
from collections import defaultdict
from pathlib import Path

from ddl_type_map import mongo_field_to_sql
from generate_07_catalog_from_t05 import parse_t05

ESPEC = Path(__file__).resolve().parents[1]
ANEXOS = ESPEC / "anexos"

COLL_NAME = r"[a-z][a-zA-Z0-9_]*"
HEADER_RE = re.compile(rf"^#{{3,4}}\s+.*?[`']({COLL_NAME})[`']")
BOLD_HDR = re.compile(rf"\*\*[`']({COLL_NAME})[`']\*\*")
COLLECTION_BT = re.compile(rf"[`']({COLL_NAME})[`']")
SUBSEC_HDR = re.compile(rf"^####\s+[`']({COLL_NAME})[`']")
CAMPO_DE = re.compile(rf"Campos de\s+[`']({COLL_NAME})[`']", re.I)
FIELD_HDR = re.compile(r"^\|\s*Campo\s*\|\s*Tipo\s*\|")
FIELD_ROW = re.compile(r"^\|\s*`([^`]+)`\s*\|\s*([^|]+)")

REF_ARROW = re.compile(rf"→\s*`({COLL_NAME})`")
REF_BACKTICK = re.compile(rf"`({COLL_NAME})`")
TYPE_OBJECTID_ARROW = re.compile(
    rf"ObjectId\s*→\s*(?:M\d+|T\d+[^`]*)?\s*`({COLL_NAME})`", re.I
)
OBJECTID = re.compile(r"\bObjectId\b", re.I)


def valid_collections() -> set[str]:
    return {
        r["collection"]
        for r in parse_t05()
        if "A→" not in r["est"]
    }


def pick_target_collection(ref_cell: str, typ_cell: str, valid: set[str]) -> str | None:
    ref_cell = (ref_cell or "").strip()
    typ_cell = (typ_cell or "").strip()
    if ref_cell in ("—", "-", ""):
        ref_cell = ""
    for regex in (REF_ARROW, TYPE_OBJECTID_ARROW):
        for m in regex.finditer(ref_cell + " " + typ_cell):
            c = m.group(1)
            if c in valid:
                return c
    for m in REF_BACKTICK.finditer(ref_cell):
        c = m.group(1)
        if c in valid and not c.isupper():
            return c
    return None


def parse_path_refs(path: Path, valid: set[str]) -> dict[str, list[tuple[str, str, str]]]:
    """collection -> [(field, typ, target_collection)]"""
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    out: dict[str, list] = defaultdict(list)
    current: str | None = None
    in_table = False
    ref_idx: int | None = None

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("####") and "subdocumento" in line.lower():
            current = None
            in_table = False
            ref_idx = None
            continue
        bm = BOLD_HDR.search(line)
        if bm and (
            stripped.startswith("**`")
            or "—" in line
            or "(COL-" in line
        ):
            current = BOLD_HDR.findall(line)[0]
            in_table = False
            ref_idx = None
            continue
        m = HEADER_RE.match(line)
        if m and re.search(r"\b7\.", line):
            found = COLLECTION_BT.findall(line)
            if found:
                current = found[0]
                in_table = False
                ref_idx = None
                continue
        if CAMPO_DE.search(line):
            current = CAMPO_DE.search(line).group(1)
            in_table = False
            ref_idx = None
            continue
        sm = SUBSEC_HDR.match(line)
        if sm:
            current = sm.group(1)
            in_table = False
            ref_idx = None
            continue
        if current and FIELD_HDR.match(line):
            headers = [h.strip().lower() for h in line.split("|")]
            ref_idx = next(
                (i for i, h in enumerate(headers) if "referencia" in h), None
            )
            in_table = True
            continue
        if not in_table or not current:
            continue
        if not line.startswith("|") or line.startswith("|---"):
            if line.strip() == "":
                in_table = False
            continue
        fm = FIELD_ROW.match(line)
        if not fm:
            continue
        field_cell, typ = fm.group(1), fm.group(2).strip()
        fields = re.findall(r"`([^`]+)`", field_cell) or [field_cell.strip()]
        parts = [p.strip() for p in line.split("|")]
        ref_cell = parts[ref_idx] if ref_idx is not None and len(parts) > ref_idx else ""
        if ref_idx is None and len(parts) >= 5:
            ref_cell = parts[4]
        target = pick_target_collection(ref_cell, typ, valid)
        if not target:
            continue
        for field in fields:
            field = field.replace("[]", "").strip()
            if not field or field in ("_id", "tenantId"):
                continue
            if not OBJECTID.search(typ) and not field.endswith("Id"):
                continue
            out[current].append((field, typ, target))
    return out


def load_mega_fk_hints() -> dict[str, list[tuple[str, str, str]]]:
    valid = valid_collections()
    merged: dict[str, list] = {}
    for path in sorted(ANEXOS.glob("[MT]*.md")):
        if "backup-sync" in path.parts:
            continue
        parsed = parse_path_refs(path, valid)
        for coll, rows in parsed.items():
            if coll not in merged or len(rows) > len(merged[coll]):
                merged[coll] = rows
    return merged