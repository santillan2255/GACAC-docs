import re, sys
sys.stdout.reconfigure(encoding='utf-8')
P = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T09-COM-comunidad-comunicaciones.md'
L = open(P, encoding='utf-8').read().split('\n')
for i, l in enumerate(L):
    if re.match(r'^\| RF-COM-\d+', l):
        c = [x.strip() for x in l.strip().strip('|').split('|')]
        if c[-1] in ('—', '-', ''):
            print(i + 1, c[0], '|', c[1][:400], '|', c[2][:80])
