$ErrorActionPreference = 'Stop'
$base = 'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
$files = 'M07-COB-cuenta-corriente-cobranza.md','M08-MOR-mora-financiacion.md','M12-CMP-compras-proveedores.md','M15-CON-contabilidad.md'
$strict = New-Object System.Text.UTF8Encoding($false, $true)
foreach ($f in $files) {
  $path = Join-Path $base $f
  $bytes = [System.IO.File]::ReadAllBytes($path)
  try { $text = $strict.GetString($bytes); $utf = 'ok' } catch { $utf = 'INVALID'; $text = [System.Text.Encoding]::UTF8.GetString($bytes) }
  $lines = $text -split "`r?`n"
  $ids = @{}
  foreach ($l in $lines) {
    if ($l -match '^\| ((?:RF|RN|EVT|JOB|API|PAN|PRM|ESC|CTR|REP|M)-[A-Z0-9]*-?[A-Z]?\d+) \|') {
      $id = $Matches[1]
      if ($ids.ContainsKey($id)) { $ids[$id]++ } else { $ids[$id] = 1 }
    }
  }
  $dups = $ids.GetEnumerator() | Where-Object { $_.Value -gt 1 } | ForEach-Object { "$($_.Key)x$($_.Value)" }
  $heads = $lines | Where-Object { $_ -match '^#{2,4} ' } | Group-Object | Where-Object { $_.Count -gt 1 } | ForEach-Object { $_.Name }
  $sigue = ($lines | Where-Object { $_ -match '<!-- SIGUE' }).Count
  $repl = ([regex]::Matches($text, [string][char]0xFFFD)).Count
  Write-Output "$f utf8=$utf fffd=$repl sigue=$sigue"
  Write-Output "  dupIDs: $($dups -join ', ')"
  Write-Output "  dupHeadings: $($heads -join ' | ')"
}
