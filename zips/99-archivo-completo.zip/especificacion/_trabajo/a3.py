﻿from conc_lib import *
d = json.load(open('occ.json',encoding='utf-8'))
fm = {os.path.basename(f).split('-')[0]: f for f in files()}
cache = {}
seen = set()
with open('ctx.txt','w',encoding='utf-8') as o:
    for n, occ in d['occ'].items():
        for oc in occ:
            code, ln = oc.split(':'); ln = int(ln)
            if code in ('M08','M17','M18','M19'): continue
            if (code, ln) in seen: continue
            seen.add((code, ln))
            if code not in cache: cache[code] = read(fm[code]).split('\n')
            l = cache[code][ln-1]
            o.write('== %s:%d  %s\n' % (code, ln, l[:600]))
