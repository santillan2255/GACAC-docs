#!/usr/bin/env python3
"""Genera scripts capa C para esquema pla desde especificación consolidada (07 §2.0)."""
from __future__ import annotations

from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "07-ddl" / "sql" / "pla"

# (ordinal, table_name, global_no_tenant, columns, indexes, fks)
# columns: list of (name, sql_type, nullable, default_sql or None)
# indexes: list of (name, columns, unique, where_clause or None)
# fks: list of (name, col, ref_table, ref_col)

AUDIT = [
    ("CreatedAt", "DATETIME2(7)", False, "SYSUTCDATETIME()"),
    ("CreatedBy", "UNIQUEIDENTIFIER", True, None),
    ("UpdatedAt", "DATETIME2(7)", False, "SYSUTCDATETIME()"),
    ("UpdatedBy", "UNIQUEIDENTIFIER", True, None),
]


def tenant_id_col(nullable: bool = False) -> tuple:
    return ("TenantId", "UNIQUEIDENTIFIER", nullable, None)


TABLES: list[dict] = [
    {
        "ord": 1,
        "name": "Tenants",
        "global": True,
        "cols": [
            ("TenantId", "UNIQUEIDENTIFIER", False, None),
            ("Code", "VARCHAR(30)", False, None),
            ("Kind", "VARCHAR(16)", False, None),
            ("LegalName", "NVARCHAR(256)", False, None),
            ("ShortName", "NVARCHAR(256)", False, None),
            ("Cuit", "CHAR(11)", True, None),
            ("LegalForm", "VARCHAR(32)", False, None),
            ("InaesRegistration", "NVARCHAR(64)", True, None),
            ("FiscalAddressJson", "NVARCHAR(MAX)", False, None),
            ("ContactsJson", "NVARCHAR(MAX)", False, None),
            ("Status", "VARCHAR(32)", False, None),
            ("StatusHistoryJson", "NVARCHAR(MAX)", False, None),
            ("SuspensionJson", "NVARCHAR(MAX)", True, None),
            ("ClosingJson", "NVARCHAR(MAX)", True, None),
            ("Timezone", "VARCHAR(64)", False, "N'America/Argentina/Cordoba'"),
            ("Locale", "VARCHAR(16)", False, "N'es-AR'"),
            ("Currency", "CHAR(3)", False, "N'ARS'"),
            ("DataRegion", "VARCHAR(32)", False, None),
            ("DomainsJson", "NVARCHAR(MAX)", False, None),
            ("ReleaseRing", "VARCHAR(16)", False, "N'general'"),
            ("EnvironmentKind", "VARCHAR(16)", False, None),
            ("ProductionTenantRefJson", "NVARCHAR(MAX)", True, None),
            ("SandboxesJson", "NVARCHAR(MAX)", True, None),
            ("SaasContractId", "UNIQUEIDENTIFIER", True, None),
            ("ModulesVersion", "INT", False, "0"),
            ("OnboardingJson", "NVARCHAR(MAX)", True, None),
            ("BrandingRefId", "UNIQUEIDENTIFIER", True, None),
            ("IsDemo", "BIT", False, "0"),
            *AUDIT,
            ("RowVersion", "ROWVERSION", False, None),
        ],
        "pk": "TenantId",
        "idx": [
            ("UX_pla_Tenants_Code", ["Code"], True, None),
            ("IX_pla_Tenants_Status", ["Status"], False, None),
        ],
        "fks": [],
        "checks": [
            ("CK_pla_Tenants_Kind", "[Kind] IN (N'platform', N'cooperative', N'demo', N'sandbox')"),
        ],
    },
    {
        "ord": 2,
        "name": "ModuleCatalog",
        "global": True,
        "cols": [
            ("ModuleCatalogId", "UNIQUEIDENTIFIER", False, None),
            ("Code", "VARCHAR(64)", False, None),
            ("Kind", "VARCHAR(32)", False, None),
            ("LabelKey", "VARCHAR(128)", False, None),
            ("DescriptionKey", "VARCHAR(128)", False, None),
            ("ModuleGroup", "VARCHAR(32)", False, None),
            ("DependsOnJson", "NVARCHAR(MAX)", True, None),
            ("CapabilityPrefixesJson", "NVARCHAR(MAX)", True, None),
            ("MinWave", "VARCHAR(4)", False, None),
            ("Status", "VARCHAR(16)", False, None),
            ("Sellable", "BIT", False, "1"),
            *AUDIT,
        ],
        "pk": "ModuleCatalogId",
        "idx": [("UX_pla_ModuleCatalog_Code", ["Code"], True, None)],
        "fks": [],
        "checks": [],
    },
    {
        "ord": 3,
        "name": "PlatformPlans",
        "global": True,
        "cols": [
            ("PlatformPlanId", "UNIQUEIDENTIFIER", False, None),
            ("Code", "VARCHAR(64)", False, None),
            ("LabelKey", "VARCHAR(128)", False, None),
            ("ModulesJson", "NVARCHAR(MAX)", False, None),
            ("DefaultQuotasJson", "NVARCHAR(MAX)", True, None),
            ("TargetSize", "VARCHAR(16)", False, None),
            ("Status", "VARCHAR(16)", False, None),
            ("ValidFrom", "DATE", True, None),
            ("ValidTo", "DATE", True, None),
            *AUDIT,
        ],
        "pk": "PlatformPlanId",
        "idx": [("UX_pla_PlatformPlans_Code", ["Code"], True, None)],
        "fks": [],
        "checks": [],
    },
    {
        "ord": 4,
        "name": "TenantLicenses",
        "global": False,
        "cols": [
            ("TenantLicenseId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("ModuleCode", "VARCHAR(64)", False, None),
            ("Source", "VARCHAR(32)", False, None),
            ("SaasContractId", "UNIQUEIDENTIFIER", True, None),
            ("ValidFrom", "DATE", False, None),
            ("ValidTo", "DATE", True, None),
            ("QuotaOverridesJson", "NVARCHAR(MAX)", True, None),
            ("Status", "VARCHAR(16)", False, None),
            ("ApprovedByMembershipId", "UNIQUEIDENTIFIER", True, None),
            ("ApprovedAt", "DATETIME2(7)", True, None),
            *AUDIT,
        ],
        "pk": "TenantLicenseId",
        "idx": [
            ("IX_pla_TenantLicenses_Tenant_Module", ["TenantId", "ModuleCode", "ValidFrom"], False, None),
        ],
        "fks": [("FK_pla_TenantLicenses_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 5,
        "name": "TenantModuleActivations",
        "global": False,
        "cols": [
            ("TenantModuleActivationId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("ModuleCode", "VARCHAR(64)", False, None),
            ("Mode", "VARCHAR(32)", False, None),
            ("NewSalesBlocked", "BIT", False, "0"),
            ("Status", "VARCHAR(16)", False, None),
            ("ChecklistSnapshotId", "UNIQUEIDENTIFIER", True, None),
            ("ActivatedAt", "DATETIME2(7)", True, None),
            ("ActivatedByMembershipId", "UNIQUEIDENTIFIER", True, None),
            ("HistoryJson", "NVARCHAR(MAX)", True, None),
            *AUDIT,
        ],
        "pk": "TenantModuleActivationId",
        "idx": [("UX_pla_TenantModuleActivations", ["TenantId", "ModuleCode"], True, None)],
        "fks": [("FK_pla_TenantModuleActivations_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 6,
        "name": "TenantChecklists",
        "global": False,
        "cols": [
            ("TenantChecklistId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("CapabilityCode", "VARCHAR(64)", False, None),
            ("ItemsJson", "NVARCHAR(MAX)", False, None),
            ("OverallStatus", "VARCHAR(32)", False, None),
            ("SnapshotsJson", "NVARCHAR(MAX)", True, None),
            ("EvaluatedAt", "DATETIME2(7)", True, None),
            *AUDIT,
        ],
        "pk": "TenantChecklistId",
        "idx": [("UX_pla_TenantChecklists", ["TenantId", "CapabilityCode"], True, None)],
        "fks": [("FK_pla_TenantChecklists_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 7,
        "name": "OnboardingDrafts",
        "global": False,
        "cols": [
            ("OnboardingDraftId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(True),
            ("Step", "VARCHAR(32)", False, None),
            ("DataJson", "NVARCHAR(MAX)", True, None),
            ("AiProposalJson", "NVARCHAR(MAX)", True, None),
            ("AcceptedProposalJson", "NVARCHAR(MAX)", True, None),
            ("Status", "VARCHAR(16)", False, None),
            ("ExpiresAt", "DATETIME2(7)", True, None),
            *AUDIT,
        ],
        "pk": "OnboardingDraftId",
        "idx": [("IX_pla_OnboardingDrafts_Tenant_Status", ["TenantId", "Status"], False, None)],
        "fks": [],
        "checks": [],
    },
    {
        "ord": 8,
        "name": "SaasContracts",
        "global": False,
        "cols": [
            ("SaasContractId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Number", "VARCHAR(32)", False, None),
            ("PlanCode", "VARCHAR(64)", False, None),
            ("AddonsJson", "NVARCHAR(MAX)", True, None),
            ("QuotasJson", "NVARCHAR(MAX)", False, None),
            ("ValidFrom", "DATE", False, None),
            ("ValidTo", "DATE", True, None),
            ("AutoRenew", "BIT", False, "0"),
            ("BillingJson", "NVARCHAR(MAX)", True, None),
            ("ServiceLevelsJson", "NVARCHAR(MAX)", True, None),
            ("DataRegion", "VARCHAR(32)", False, None),
            ("ExitTermsJson", "NVARCHAR(MAX)", False, None),
            ("Status", "VARCHAR(16)", False, None),
            ("VersionsJson", "NVARCHAR(MAX)", False, None),
            ("SignedDocumentStoredFileId", "UNIQUEIDENTIFIER", True, None),
            *AUDIT,
        ],
        "pk": "SaasContractId",
        "idx": [
            ("UX_pla_SaasContracts_Number", ["Number"], True, None),
            ("IX_pla_SaasContracts_Tenant_Status", ["TenantId", "Status"], False, None),
        ],
        "fks": [("FK_pla_SaasContracts_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 9,
        "name": "UsageSnapshots",
        "global": False,
        "cols": [
            ("UsageSnapshotId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Day", "DATE", False, None),
            ("Dimension", "VARCHAR(64)", False, None),
            ("Value", "DECIMAL(18,4)", False, None),
            ("QuotaSoft", "DECIMAL(18,4)", True, None),
            ("QuotaHard", "DECIMAL(18,4)", True, None),
            ("Pct", "DECIMAL(9,4)", True, None),
            *AUDIT,
        ],
        "pk": "UsageSnapshotId",
        "idx": [("UX_pla_UsageSnapshots", ["TenantId", "Dimension", "Day"], True, None)],
        "fks": [("FK_pla_UsageSnapshots_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 10,
        "name": "SupportCases",
        "global": False,
        "cols": [
            ("SupportCaseId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Number", "VARCHAR(32)", False, None),
            ("Title", "NVARCHAR(512)", False, None),
            ("ModuleCode", "VARCHAR(64)", True, None),
            ("Impact", "VARCHAR(16)", False, None),
            ("Priority", "VARCHAR(8)", False, None),
            ("Status", "VARCHAR(32)", False, None),
            ("Channel", "VARCHAR(16)", False, None),
            ("ReportedByMembershipId", "UNIQUEIDENTIFIER", True, None),
            ("AssigneeMembershipId", "UNIQUEIDENTIFIER", True, None),
            ("Queue", "VARCHAR(16)", True, None),
            ("ContextJson", "NVARCHAR(MAX)", True, None),
            ("EvidenceFileIdsJson", "NVARCHAR(MAX)", True, None),
            ("IncidentId", "UNIQUEIDENTIFIER", True, None),
            ("SlaJson", "NVARCHAR(MAX)", True, None),
            ("SatisfactionJson", "NVARCHAR(MAX)", True, None),
            ("TagsJson", "NVARCHAR(MAX)", True, None),
            *AUDIT,
        ],
        "pk": "SupportCaseId",
        "idx": [
            ("UX_pla_SupportCases_Number", ["TenantId", "Number"], True, None),
            ("IX_pla_SupportCases_Status", ["TenantId", "Status", "Priority"], False, None),
        ],
        "fks": [("FK_pla_SupportCases_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 11,
        "name": "SupportCaseMessages",
        "global": False,
        "cols": [
            ("SupportCaseMessageId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("SupportCaseId", "UNIQUEIDENTIFIER", False, None),
            ("AuthorType", "VARCHAR(32)", False, None),
            ("AuthorId", "UNIQUEIDENTIFIER", True, None),
            ("Body", "NVARCHAR(MAX)", False, None),
            ("Visibility", "VARCHAR(16)", False, None),
            ("AttachmentFileIdsJson", "NVARCHAR(MAX)", True, None),
            *AUDIT,
        ],
        "pk": "SupportCaseMessageId",
        "idx": [
            ("IX_pla_SupportCaseMessages", ["TenantId", "SupportCaseId", "CreatedAt"], False, None),
        ],
        "fks": [
            ("FK_pla_SupportCaseMessages_Tenants", "TenantId", "Tenants", "TenantId"),
            ("FK_pla_SupportCaseMessages_Cases", "SupportCaseId", "SupportCases", "SupportCaseId"),
        ],
        "checks": [],
    },
    {
        "ord": 12,
        "name": "SupportSessions",
        "global": False,
        "cols": [
            ("SupportSessionId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("SupportAccessGrantId", "UNIQUEIDENTIFIER", False, None),
            ("AgentMembershipId", "UNIQUEIDENTIFIER", False, None),
            ("TokenJti", "VARCHAR(64)", False, None),
            ("StartedAt", "DATETIME2(7)", False, None),
            ("EndedAt", "DATETIME2(7)", True, None),
            ("EndReason", "VARCHAR(32)", True, None),
            ("IpAddress", "VARCHAR(45)", True, None),
            ("UserAgent", "NVARCHAR(512)", True, None),
            *AUDIT,
        ],
        "pk": "SupportSessionId",
        "idx": [("IX_pla_SupportSessions", ["TenantId", "SupportAccessGrantId"], False, None)],
        "fks": [("FK_pla_SupportSessions_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 13,
        "name": "PlatformIncidents",
        "global": False,
        "cols": [
            ("PlatformIncidentId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Number", "VARCHAR(32)", False, None),
            ("Title", "NVARCHAR(512)", False, None),
            ("Severity", "VARCHAR(8)", False, None),
            ("Status", "VARCHAR(32)", False, None),
            ("AffectedTenantIdsJson", "NVARCHAR(MAX)", True, None),
            ("AffectedModulesJson", "NVARCHAR(MAX)", True, None),
            ("TimelineJson", "NVARCHAR(MAX)", True, None),
            ("PublicMessage", "NVARCHAR(MAX)", True, None),
            ("PostmortemStoredFileId", "UNIQUEIDENTIFIER", True, None),
            *AUDIT,
        ],
        "pk": "PlatformIncidentId",
        "idx": [("IX_pla_PlatformIncidents", ["TenantId", "Status", "CreatedAt"], False, None)],
        "fks": [("FK_pla_PlatformIncidents_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 14,
        "name": "AlertRules",
        "global": False,
        "cols": [
            ("AlertRuleId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Code", "VARCHAR(64)", False, None),
            ("Scope", "VARCHAR(16)", False, None),
            ("OwnerModule", "VARCHAR(16)", True, None),
            ("ConditionType", "VARCHAR(32)", False, None),
            ("ParamsJson", "NVARCHAR(MAX)", False, None),
            ("Severity", "VARCHAR(16)", False, None),
            ("RecipientsJson", "NVARCHAR(MAX)", True, None),
            ("ChannelsJson", "NVARCHAR(MAX)", True, None),
            ("CooldownMinutes", "INT", True, None),
            ("Enabled", "BIT", False, "1"),
            *AUDIT,
        ],
        "pk": "AlertRuleId",
        "idx": [("UX_pla_AlertRules", ["TenantId", "Code"], True, None)],
        "fks": [("FK_pla_AlertRules_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 15,
        "name": "Alerts",
        "global": False,
        "cols": [
            ("AlertId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("RuleCode", "VARCHAR(64)", False, None),
            ("DedupeKey", "VARCHAR(128)", False, None),
            ("Severity", "VARCHAR(16)", False, None),
            ("Status", "VARCHAR(16)", False, None),
            ("Count", "INT", False, "1"),
            ("FirstAt", "DATETIME2(7)", False, None),
            ("LastAt", "DATETIME2(7)", False, None),
            ("Title", "NVARCHAR(512)", True, None),
            ("ObjectRefJson", "NVARCHAR(MAX)", True, None),
            ("AckByMembershipId", "UNIQUEIDENTIFIER", True, None),
            ("AckAt", "DATETIME2(7)", True, None),
            ("ResolvedByMembershipId", "UNIQUEIDENTIFIER", True, None),
            ("ResolvedAt", "DATETIME2(7)", True, None),
            ("Resolution", "NVARCHAR(MAX)", True, None),
            ("SilencedUntil", "DATETIME2(7)", True, None),
            *AUDIT,
        ],
        "pk": "AlertId",
        "idx": [
            ("IX_pla_Alerts_Tenant_Status", ["TenantId", "Status", "Severity"], False, None),
            (
                "UX_pla_Alerts_Dedupe_Open",
                ["TenantId", "DedupeKey"],
                True,
                "[Status] IN (N'open', N'acknowledged')",
            ),
        ],
        "fks": [("FK_pla_Alerts_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 16,
        "name": "BackupPolicies",
        "global": True,
        "cols": [
            ("BackupPolicyId", "UNIQUEIDENTIFIER", False, None),
            ("Code", "VARCHAR(64)", False, None),
            ("Type", "VARCHAR(32)", False, None),
            ("FrequencyCron", "VARCHAR(64)", False, None),
            ("RetentionJson", "NVARCHAR(MAX)", False, None),
            ("EncryptionKeyRef", "VARCHAR(128)", True, None),
            ("TargetLocation", "VARCHAR(128)", False, None),
            ("AppliesToJson", "NVARCHAR(MAX)", True, None),
            ("Enabled", "BIT", False, "1"),
            *AUDIT,
        ],
        "pk": "BackupPolicyId",
        "idx": [("UX_pla_BackupPolicies_Code", ["Code"], True, None)],
        "fks": [],
        "checks": [],
    },
    {
        "ord": 17,
        "name": "BackupRuns",
        "global": True,
        "cols": [
            ("BackupRunId", "UNIQUEIDENTIFIER", False, None),
            ("PolicyCode", "VARCHAR(64)", False, None),
            ("Type", "VARCHAR(32)", False, None),
            ("ScopeTenantId", "UNIQUEIDENTIFIER", True, None),
            ("StartedAt", "DATETIME2(7)", False, None),
            ("FinishedAt", "DATETIME2(7)", True, None),
            ("Status", "VARCHAR(16)", False, None),
            ("SizeBytes", "BIGINT", True, None),
            ("ObjectCount", "INT", True, None),
            ("Checksum", "CHAR(64)", True, None),
            ("LocationRef", "VARCHAR(256)", True, None),
            ("RetentionUntil", "DATETIME2(7)", True, None),
            ("ErrorMessage", "NVARCHAR(512)", True, None),
            *AUDIT,
        ],
        "pk": "BackupRunId",
        "idx": [
            ("IX_pla_BackupRuns_Scope", ["ScopeTenantId", "Type", "StartedAt"], False, None),
        ],
        "fks": [],
        "checks": [],
    },
    {
        "ord": 18,
        "name": "RestoreRequests",
        "global": False,
        "cols": [
            ("RestoreRequestId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Number", "VARCHAR(32)", False, None),
            ("Mode", "VARCHAR(32)", False, None),
            ("TargetPointInTime", "DATETIME2(7)", False, None),
            ("ScopeJson", "NVARCHAR(MAX)", True, None),
            ("Reason", "NVARCHAR(512)", False, None),
            ("ApprovalsJson", "NVARCHAR(MAX)", False, None),
            ("Status", "VARCHAR(32)", False, None),
            ("StagingRef", "VARCHAR(128)", True, None),
            ("DiffSummaryJson", "NVARCHAR(MAX)", True, None),
            ("ReconciliationJson", "NVARCHAR(MAX)", True, None),
            ("StartedAt", "DATETIME2(7)", True, None),
            ("FinishedAt", "DATETIME2(7)", True, None),
            ("RtoActualMinutes", "INT", True, None),
            *AUDIT,
        ],
        "pk": "RestoreRequestId",
        "idx": [("UX_pla_RestoreRequests_Number", ["TenantId", "Number"], True, None)],
        "fks": [("FK_pla_RestoreRequests_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 19,
        "name": "RestoreTests",
        "global": False,
        "cols": [
            ("RestoreTestId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("ScheduledAt", "DATETIME2(7)", False, None),
            ("ExecutedAt", "DATETIME2(7)", True, None),
            ("PointInTime", "DATETIME2(7)", False, None),
            ("Result", "VARCHAR(16)", True, None),
            ("ChecksJson", "NVARCHAR(MAX)", True, None),
            ("RtoActualMinutes", "INT", True, None),
            ("ReportStoredFileId", "UNIQUEIDENTIFIER", True, None),
            *AUDIT,
        ],
        "pk": "RestoreTestId",
        "idx": [("IX_pla_RestoreTests_Tenant", ["TenantId", "ScheduledAt"], False, None)],
        "fks": [("FK_pla_RestoreTests_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 20,
        "name": "TenantExports",
        "global": False,
        "cols": [
            ("TenantExportId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Purpose", "VARCHAR(32)", False, None),
            ("ScopeJson", "NVARCHAR(MAX)", True, None),
            ("Format", "VARCHAR(32)", False, None),
            ("Status", "VARCHAR(16)", False, None),
            ("JobRunId", "UNIQUEIDENTIFIER", True, None),
            ("FilesJson", "NVARCHAR(MAX)", True, None),
            ("ManifestStoredFileId", "UNIQUEIDENTIFIER", True, None),
            ("ExpiresAt", "DATETIME2(7)", True, None),
            ("DownloadsJson", "NVARCHAR(MAX)", True, None),
            *AUDIT,
        ],
        "pk": "TenantExportId",
        "idx": [("IX_pla_TenantExports", ["TenantId", "Status", "CreatedAt"], False, None)],
        "fks": [("FK_pla_TenantExports_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 21,
        "name": "Releases",
        "global": True,
        "cols": [
            ("ReleaseId", "UNIQUEIDENTIFIER", False, None),
            ("Version", "VARCHAR(32)", False, None),
            ("GitSha", "VARCHAR(64)", False, None),
            ("ImageDigestsJson", "NVARCHAR(MAX)", False, None),
            ("MigrationIdsJson", "NVARCHAR(MAX)", True, None),
            ("NotesJson", "NVARCHAR(MAX)", True, None),
            ("DeploymentsJson", "NVARCHAR(MAX)", True, None),
            ("Status", "VARCHAR(16)", False, None),
            *AUDIT,
        ],
        "pk": "ReleaseId",
        "idx": [("UX_pla_Releases_Version", ["Version"], True, None)],
        "fks": [],
        "checks": [],
    },
    {
        "ord": 22,
        "name": "FeatureFlags",
        "global": False,
        "cols": [
            ("FeatureFlagId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("FlagKey", "VARCHAR(128)", False, None),
            ("Description", "NVARCHAR(512)", True, None),
            ("OwnerModule", "VARCHAR(16)", True, None),
            ("DefaultEnabled", "BIT", False, "0"),
            ("RulesJson", "NVARCHAR(MAX)", True, None),
            ("ExpiresAt", "DATETIME2(7)", True, None),
            ("Status", "VARCHAR(16)", False, None),
            *AUDIT,
        ],
        "pk": "FeatureFlagId",
        "idx": [("UX_pla_FeatureFlags", ["TenantId", "FlagKey"], True, None)],
        "fks": [("FK_pla_FeatureFlags_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 24,
        "name": "OutboxEvents",
        "global": False,
        "cols": [
            ("OutboxEventId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("EventType", "VARCHAR(128)", False, None),
            ("SchemaVersion", "INT", False, "1"),
            ("AggregateType", "VARCHAR(64)", False, None),
            ("AggregateId", "UNIQUEIDENTIFIER", False, None),
            ("PayloadJson", "NVARCHAR(MAX)", False, None),
            ("OccurredAt", "DATETIME2(7)", False, None),
            ("CorrelationId", "VARCHAR(64)", True, None),
            ("CausationId", "VARCHAR(64)", True, None),
            ("ActorType", "VARCHAR(32)", True, None),
            ("ActorId", "UNIQUEIDENTIFIER", True, None),
            ("Status", "VARCHAR(16)", False, None),
            ("Attempts", "INT", False, "0"),
            ("NextAttemptAt", "DATETIME2(7)", True, None),
            ("PublishedAt", "DATETIME2(7)", True, None),
            ("LastError", "NVARCHAR(512)", True, None),
            ("CreatedAt", "DATETIME2(7)", False, "SYSUTCDATETIME()"),
        ],
        "pk": "OutboxEventId",
        "idx": [
            ("IX_pla_OutboxEvents_Dispatch", ["Status", "NextAttemptAt"], False, "[Status] IN (N'pending', N'failed')"),
            ("IX_pla_OutboxEvents_Aggregate", ["TenantId", "AggregateType", "AggregateId", "OccurredAt"], False, None),
        ],
        "fks": [("FK_pla_OutboxEvents_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [("CK_pla_OutboxEvents_Status", "[Status] IN (N'pending', N'published', N'failed')")],
    },
    {
        "ord": 25,
        "name": "InboxReceipts",
        "global": False,
        "cols": [
            ("InboxReceiptId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Consumer", "VARCHAR(128)", False, None),
            ("EventId", "UNIQUEIDENTIFIER", False, None),
            ("ProcessedAt", "DATETIME2(7)", False, None),
        ],
        "pk": "InboxReceiptId",
        "idx": [("UX_pla_InboxReceipts", ["TenantId", "Consumer", "EventId"], True, None)],
        "fks": [("FK_pla_InboxReceipts_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 26,
        "name": "DeadLetters",
        "global": False,
        "cols": [
            ("DeadLetterId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Kind", "VARCHAR(16)", False, None),
            ("Ref", "VARCHAR(256)", False, None),
            ("Consumer", "VARCHAR(128)", True, None),
            ("Attempts", "INT", False, "0"),
            ("LastError", "NVARCHAR(512)", True, None),
            ("PayloadSummary", "NVARCHAR(MAX)", True, None),
            ("Status", "VARCHAR(16)", False, None),
            ("ResolvedByMembershipId", "UNIQUEIDENTIFIER", True, None),
            ("Resolution", "NVARCHAR(MAX)", True, None),
            ("BusinessImpact", "BIT", False, "0"),
            *AUDIT,
        ],
        "pk": "DeadLetterId",
        "idx": [("IX_pla_DeadLetters_Tenant_Status", ["TenantId", "Status"], False, None)],
        "fks": [("FK_pla_DeadLetters_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 27,
        "name": "JobRuns",
        "global": False,
        "cols": [
            ("JobRunId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("JobName", "VARCHAR(128)", False, None),
            ("JobKey", "VARCHAR(256)", False, None),
            ("ExternalJobId", "VARCHAR(64)", True, None),
            ("Queue", "VARCHAR(32)", True, None),
            ("Status", "VARCHAR(16)", False, None),
            ("ProgressJson", "NVARCHAR(MAX)", True, None),
            ("CursorJson", "NVARCHAR(MAX)", True, None),
            ("CancelRequested", "BIT", False, "0"),
            ("RequestedByMembershipId", "UNIQUEIDENTIFIER", True, None),
            ("StartedAt", "DATETIME2(7)", True, None),
            ("FinishedAt", "DATETIME2(7)", True, None),
            ("SummaryJson", "NVARCHAR(MAX)", True, None),
            ("ErrorJson", "NVARCHAR(MAX)", True, None),
            ("MigrationName", "VARCHAR(128)", True, None),
            *AUDIT,
        ],
        "pk": "JobRunId",
        "idx": [
            ("IX_pla_JobRuns_Tenant", ["TenantId", "JobName", "CreatedAt"], False, None),
            (
                "UX_pla_JobRuns_ActiveKey",
                ["TenantId", "JobKey"],
                True,
                "[Status] NOT IN (N'succeeded', N'failed', N'cancelled')",
            ),
        ],
        "fks": [("FK_pla_JobRuns_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 28,
        "name": "IdempotencyKeys",
        "global": False,
        "cols": [
            ("IdempotencyKeyId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Scope", "VARCHAR(256)", False, None),
            ("IdempotencyKey", "VARCHAR(128)", False, None),
            ("RequestHash", "CHAR(64)", False, None),
            ("Status", "VARCHAR(16)", False, None),
            ("ResponseStatus", "INT", True, None),
            ("ResponseBodySummary", "NVARCHAR(MAX)", True, None),
            ("ExpiresAt", "DATETIME2(7)", False, None),
        ],
        "pk": "IdempotencyKeyId",
        "idx": [("UX_pla_IdempotencyKeys", ["TenantId", "Scope", "IdempotencyKey"], True, None)],
        "fks": [("FK_pla_IdempotencyKeys_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 29,
        "name": "StoredFiles",
        "global": False,
        "cols": [
            ("StoredFileId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("StorageKey", "VARCHAR(512)", False, None),
            ("BucketAlias", "VARCHAR(64)", False, None),
            ("ModuleCode", "VARCHAR(64)", True, None),
            ("OwnerType", "VARCHAR(32)", True, None),
            ("OwnerId", "UNIQUEIDENTIFIER", True, None),
            ("Classification", "VARCHAR(32)", False, None),
            ("OriginalName", "NVARCHAR(512)", False, None),
            ("MimeType", "VARCHAR(128)", False, None),
            ("SizeBytes", "BIGINT", False, None),
            ("Sha256", "CHAR(64)", False, None),
            ("ScanStatus", "VARCHAR(16)", False, None),
            ("RetentionUntil", "DATETIME2(7)", True, None),
            ("LegalHold", "BIT", False, "0"),
            ("UploadedByMembershipId", "UNIQUEIDENTIFIER", True, None),
            ("DeletedAt", "DATETIME2(7)", True, None),
            *AUDIT,
        ],
        "pk": "StoredFileId",
        "idx": [
            ("IX_pla_StoredFiles_Owner", ["TenantId", "OwnerType", "OwnerId"], False, None),
            ("IX_pla_StoredFiles_Sha", ["TenantId", "Sha256"], False, None),
        ],
        "fks": [("FK_pla_StoredFiles_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 30,
        "name": "AiUsage",
        "global": False,
        "cols": [
            ("AiUsageId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("Feature", "VARCHAR(64)", False, None),
            ("ModuleCode", "VARCHAR(64)", True, None),
            ("Provider", "VARCHAR(64)", True, None),
            ("Model", "VARCHAR(64)", True, None),
            ("InputTokens", "INT", True, None),
            ("OutputTokens", "INT", True, None),
            ("CostRef", "VARCHAR(64)", True, None),
            ("RequestId", "VARCHAR(64)", True, None),
            ("UserMembershipId", "UNIQUEIDENTIFIER", True, None),
            ("Outcome", "VARCHAR(32)", False, None),
            ("CreatedAt", "DATETIME2(7)", False, "SYSUTCDATETIME()"),
        ],
        "pk": "AiUsageId",
        "idx": [
            ("IX_pla_AiUsage_Tenant", ["TenantId", "CreatedAt"], False, None),
            ("IX_pla_AiUsage_Feature", ["TenantId", "Feature", "CreatedAt"], False, None),
        ],
        "fks": [("FK_pla_AiUsage_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 31,
        "name": "HealthSnapshots",
        "global": False,
        "cols": [
            ("HealthSnapshotId", "UNIQUEIDENTIFIER", False, None),
            tenant_id_col(),
            ("CapturedAt", "DATETIME2(7)", False, None),
            ("Component", "VARCHAR(64)", False, None),
            ("Status", "VARCHAR(16)", False, None),
            ("MetricsJson", "NVARCHAR(MAX)", True, None),
        ],
        "pk": "HealthSnapshotId",
        "idx": [("IX_pla_HealthSnapshots", ["TenantId", "Component", "CapturedAt"], False, None)],
        "fks": [("FK_pla_HealthSnapshots_Tenants", "TenantId", "Tenants", "TenantId")],
        "checks": [],
    },
    {
        "ord": 32,
        "name": "SchemaMigrations",
        "global": True,
        "cols": [
            ("SchemaMigrationId", "UNIQUEIDENTIFIER", False, None),
            ("Name", "VARCHAR(128)", False, None),
            ("ModuleCode", "VARCHAR(16)", False, None),
            ("Phase", "VARCHAR(16)", False, None),
            ("CollectionsJson", "NVARCHAR(MAX)", False, None),
            ("Checksum", "CHAR(64)", False, None),
            ("ReleaseId", "UNIQUEIDENTIFIER", False, None),
            ("AppliedAt", "DATETIME2(7)", False, None),
            ("DurationMs", "INT", False, None),
            ("Status", "VARCHAR(16)", False, None),
            ("BackfillJobKeysJson", "NVARCHAR(MAX)", True, None),
            ("Error", "NVARCHAR(512)", True, None),
        ],
        "pk": "SchemaMigrationId",
        "idx": [
            ("UX_pla_SchemaMigrations_Name", ["Name"], True, None),
            ("IX_pla_SchemaMigrations_Release", ["ReleaseId", "AppliedAt"], False, None),
        ],
        "fks": [("FK_pla_SchemaMigrations_Releases", "ReleaseId", "Releases", "ReleaseId")],
        "checks": [],
    },
]


def col_line(table: str, name: str, sql_type: str, nullable: bool, default) -> str:
    null = " NULL" if nullable else " NOT NULL"
    if sql_type == "ROWVERSION":
        return f"        [{name}] {sql_type} NOT NULL"
    line = f"        [{name}] {sql_type}{null}"
    if default is not None and sql_type != "ROWVERSION":
        df = f"DF_pla_{table}_{name}"
        line += f"\n            CONSTRAINT [{df}] DEFAULT ({default})"
    return line


def render_table(t: dict) -> str:
    name = t["name"]
    pk = t["pk"]
    lines = [
        f"-- pla.{name} — generado por generate_pla_sql.py (07 §2.0)",
        "",
        f"IF OBJECT_ID(N'pla.{name}', N'U') IS NULL",
        "BEGIN",
        f"    CREATE TABLE [pla].[{name}] (",
    ]
    col_parts = []
    for c in t["cols"]:
        col_parts.append(col_line(name, c[0], c[1], c[2], c[3]))
    col_parts.append(
        f"        CONSTRAINT [PK_pla_{name}] PRIMARY KEY ([{pk}])"
    )
    for ck_name, expr in t.get("checks", []):
        col_parts.append(f"        CONSTRAINT [{ck_name}] CHECK ({expr})")
    for fk_name, col, ref_t, ref_c in t.get("fks", []):
        col_parts.append(
            f"        CONSTRAINT [{fk_name}] FOREIGN KEY ([{col}]) "
            f"REFERENCES [pla].[{ref_t}] ([{ref_c}])"
        )
    lines.append(",\n".join(col_parts))
    lines.append("    );")
    lines.append("")
    for idx in t.get("idx", []):
        iname, cols, unique, where = idx
        u = "UNIQUE " if unique else ""
        w = f"\n        WHERE {where}" if where else ""
        cols_s = ", ".join(f"[{c}]" for c in cols)
        desc = ""
        if cols and cols[-1] == "OccurredAt":
            desc = " DESC"
        elif cols and cols[-1] == "ValidFrom":
            desc = " DESC"
        elif cols and cols[-1] == "CreatedAt":
            desc = " DESC"
        elif cols and cols[-1] == "StartedAt":
            desc = " DESC"
        lines.append(f"    CREATE {u}INDEX [{iname}]")
        lines.append(f"        ON [pla].[{name}] ({cols_s}{desc}){w};")
    lines.append("END;")
    lines.append("GO")
    return "\n".join(lines)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    written = 0
    for t in sorted(TABLES, key=lambda x: x["ord"]):
        fname = f"{t['ord']:03d}-pla.{t['name']}.sql"
        path = OUT / fname
        path.write_text(render_table(t) + "\n", encoding="utf-8")
        written += 1
        print(f"Wrote {path.name}")
    # deploy-all order
    all_sql = OUT / "deploy-all.sql"
    parts = [
        "-- Ejecutar en orden: schema + tablas pla",
        ":r 000-create-schema.sql",
    ]
    for t in sorted(TABLES, key=lambda x: x["ord"]):
        parts.append(f":r {t['ord']:03d}-pla.{t['name']}.sql")
    parts.append(":r 099-pla.deferred-foreign-keys.sql")
    all_sql.write_text("\n".join(parts) + "\n", encoding="utf-8")
    print(f"Wrote deploy-all.sql ({written} tables)")


if __name__ == "__main__":
    main()