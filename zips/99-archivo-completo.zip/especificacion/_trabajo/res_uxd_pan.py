from res_lib import Doc

d = Doc(r'anexos\T03-UXD-*.md')
d.rep('| Asistente IA de la PWA (ítems SM-PWS-041 y SM-PWE-017) |',
      '| Asistente IA de la PWA (ítems SM-PWS-041 y SM-PWE-017). RF-UXD-064 (asistente IA opcional del `AppShell`); ola O0 (PRO-O0-15) oculta por flag, habilitable en O11 |')
d.rep('| Directorio interno (ítem SM-PWE-015) |',
      '| Directorio interno (ítem SM-PWE-015). RF-UXD-063 (espacio del empleado de la PWA); ola O0 (PRO-O0-15) con la vista, datos de M16 desde O2 (SM-PWE-015) |')
d.rep('| Alertas activas (ítem SM-ADM-003) |',
      '| Alertas activas (ítem SM-ADM-003). RF-UXD-055 (centro de alertas); ola O0 (PRO-O0-15); las alertas de cada módulo llegan con su ola |')
d.rep('el ID CU-ACC-01 es de T02.', 'el ID CU-ACC-01 es de T02; PAN-UXD-15, 16 y 17 no tenían RF ni ola.')
d.rep('renumerar el CU propio a CU-UXD-07. **(Recomendada)**.',
      'renumerar el CU propio a CU-UXD-07; asignar a PAN-UXD-15, 16 y 17 los RF existentes RF-UXD-064, 063 y 055 (ola O0, PRO-O0-15), sin crear RF nuevos. **(Recomendada)**.')
print('T03', d.save())

p = Doc(r'03-plan-de-olas-y-prompts.md')
p.rep('siteMapGroups declarativo con estructura de clusters del maestro §9 (vacío de ítems de dominio; cada ola agrega los suyos, RF-UXD-171).',
      'siteMapGroups declarativo con estructura de clusters del maestro §9 (vacío de ítems de dominio; cada ola agrega los suyos, RF-UXD-171); pantallas PAN-UXD-15 (asistente IA de la PWA, RF-UXD-064, oculta por el flag `pwa.asistente` hasta O11), PAN-UXD-16 (directorio del empleado, RF-UXD-063, `iam.directorio.ver`; datos de M16 desde O2) y PAN-UXD-17 (alertas activas del admin, RF-UXD-055) (agregado en el cierre de residuales del 05-11-2026; antes no figuraban en ningún prompt).')
print('plan', p.save())
