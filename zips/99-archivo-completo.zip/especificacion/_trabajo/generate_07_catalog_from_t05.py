#!/usr/bin/env python3
"""Genera 07-catalogo-tablas-sql.md desde el catálogo COL-* de T05."""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import date
from pathlib import Path

ESPEC = Path(__file__).resolve().parents[1]
T05 = ESPEC / "anexos" / "T05-DAT-modelo-datos.md"
OUT = ESPEC / "07-catalogo-tablas-sql.md"
DDL_ROOT = ESPEC / "07-ddl" / "sql"

PREFIX_SCHEMA = {
    "PLA": "pla",
    "IAM": "iam",
    "UXD": "uxd",
    "CFG": "cfg",
    "INT": "int",
    "MIG": "mig",
    "NFR": "nfr",
    "COM": "com",
    "BIA": "bia",
    "WFL": "wfl",
    "DAT": "dat",
    "PER": "per",
    "CAT": "cat",
    "MED": "med",
    "TAR": "tar",
    "FAC": "fac",
    "FIS": "fis",
    "COB": "cob",
    "MOR": "mor",
    "CRM": "crm",
    "TEC": "tec",
    "VEN": "ven",
    "CMP": "cmp",
    "STK": "stk",
    "TES": "tes",
    "CON": "con",
    "SUE": "sue",
    "INS": "ins",
    "SOC": "soc",
    "POR": "por",
}

ROW_RE = re.compile(
    r"^\| (COL-[A-Z0-9]+-\d+) \| `([^`]+)` \| ([^|]+) \| ([^|]+) \|"
)

PLA_DETAILED = {
    f"pla.{t}"
    for t in [
        "Tenants",
        "ModuleCatalog",
        "PlatformPlans",
        "TenantLicenses",
        "TenantModuleActivations",
        "TenantChecklists",
        "OnboardingDrafts",
        "SaasContracts",
        "UsageSnapshots",
        "SupportCases",
        "SupportCaseMessages",
        "SupportSessions",
        "PlatformIncidents",
        "AlertRules",
        "Alerts",
        "BackupPolicies",
        "BackupRuns",
        "RestoreRequests",
        "RestoreTests",
        "TenantExports",
        "Releases",
        "FeatureFlags",
        "OutboxEvents",
        "InboxReceipts",
        "DeadLetters",
        "JobRuns",
        "IdempotencyKeys",
        "StoredFiles",
        "AiUsage",
        "HealthSnapshots",
        "SchemaMigrations",
    ]
}

DETAILED_IN_07 = set(PLA_DETAILED) | {
    # per — tablas con columnas en 07-modelo-relacional-azure-sql.md §2.1
    "per.Persons",
    "per.PersonIdentifiers",
    "per.Holders",
    "per.Accounts",
    "per.Addresses",
    "per.AddressGeoEvents",
    "per.Premises",
    "per.ServicePoints",
    "per.Relationships",
    "per.RelationshipScopeActions",
    "per.Transfers",
    "per.DuplicateCases",
    "per.Notes",
    "per.NoteRevisions",
    "per.Blocks",
    "per.BlockEffects",
    "per.DocumentRequirementTypes",
    "per.DocumentRequirementAppliesTo",
    "per.DocumentRequirementItems",
    "per.DocumentSubmissions",
    "per.PerRevisions",
    "iam.Identities",
    "iam.Memberships",
    "iam.Roles",
    "iam.ScreenProfiles",
    "iam.ScreenProfileScreens",
    "iam.RoleAssignments",
    "iam.AssignmentScopeDimensions",
    "iam.ProfileAssignments",
    "iam.Sessions",
}


def sql_script_paths(schema: str, table: str) -> list[str]:
    """Rutas relativas a docs/especificacion/ de scripts *.sql existentes."""
    folder = DDL_ROOT / schema
    if not folder.is_dir():
        return []
    pattern = f"*-{schema}.{table}.sql"
    hits = sorted(folder.glob(pattern))
    if not hits:
        return []
    return [
        f"`07-ddl/sql/{schema}/{p.name}`"
        for p in hits
    ]


SCHEMA_INTRO = {
    "pla": (
        "DDL columnas (capa B): **`07-modelo-relacional-azure-sql.md` §2.0**. "
        "Scripts T-SQL (capa C): carpeta **`07-ddl/sql/pla/`**."
    ),
}


def collection_to_table(name: str) -> str:
    """serviceContracts -> ServiceContracts (PascalCase plural)."""
    if not name:
        return name
    return name[0].upper() + name[1:]


def pk_name(table: str) -> str:
    """ServiceContracts -> ServiceContractId; Persons -> PersonId."""
    if table.endswith("ies"):
        singular = table[:-3] + "y"
    elif table.endswith("ses"):
        singular = table[:-2]
    elif table.endswith("s"):
        singular = table[:-1]
    else:
        singular = table
    return f"{singular}Id"


def tenant_column(alc: str) -> str:
    a = alc.strip()
    if a.startswith("T"):
        return "Sí (`TenantId`)"
    if a.startswith("G"):
        return "No (global)"
    if a.startswith("P"):
        return "Plataforma / `PLATFORM`"
    if "T" in a:
        return "Sí (`TenantId`)"
    return "Revisar alcance T05"


def parse_t05() -> list[dict]:
    text = T05.read_text(encoding="utf-8")
    rows = []
    for line in text.splitlines():
        m = ROW_RE.match(line)
        if not m:
            continue
        col_id, coll, owner, purpose = m.groups()
        parts = [p.strip() for p in line.split("|")]
        # ID, coll, owner, purpose, refs, unique, alc, clas, ola, origen, est
        est = parts[11].strip() if len(parts) > 11 else "C"
        alc = parts[7].strip() if len(parts) > 7 else "T"
        ola = parts[9].strip() if len(parts) > 9 else ""
        prefix = col_id.split("-")[1]
        schema = PREFIX_SCHEMA.get(prefix, prefix.lower())
        table = collection_to_table(coll)
        fq = f"{schema}.{table}"
        rows.append(
            {
                "col_id": col_id,
                "collection": coll,
                "owner": owner.strip(),
                "purpose": purpose.strip()[:120],
                "schema": schema,
                "table": table,
                "fq": fq,
                "alc": alc,
                "tenant": tenant_column(alc),
                "ola": ola,
                "est": est,
            }
        )
    return rows


def main() -> None:
    rows = parse_t05()
    by_schema: dict[str, list[dict]] = defaultdict(list)
    stats = {"total": 0, "create": 0, "absorbed": 0, "detailed": 0}
    for r in rows:
        stats["total"] += 1
        if r["est"].startswith("A→") or "A→" in r["est"]:
            stats["absorbed"] += 1
        else:
            stats["create"] += 1
        if r["fq"] in DETAILED_IN_07 or r["fq"].replace(
            r["table"], r["table"]
        ) in DETAILED_IN_07:
            pass
        by_schema[r["schema"]].append(r)

    lines: list[str] = [
        "# 07b — Catálogo de tablas SQL (trazado desde T05)",
        "",
        "| Campo | Valor |",
        "|---|---|",
        f"| Versión | 1.0 |",
        f"| Fecha | {date.today().strftime('%d-%m-%Y')} |",
        "| Estado | Capa **A** inventario; tipos/CREATE en capas B y C (ver abajo) |",
        "| Regenerar | `python docs/especificacion/_trabajo/generate_07_catalog_from_t05.py` |",
        "",
        "> **Lectura (tres capas, DEC-117).** Este archivo es solo **inventario** (esquema, nombre, PK sugerida, tenant, dueño). "
        "**No incluye tipos ni `CREATE TABLE`** — serían más de 100k líneas si se repiten 1.058 veces.",
        "",
        "| Capa | Dónde |",
        "|---|---|",
        "| **A** | Este catálogo |",
        "| **B** — tipos, FK, índices (legible) | [`07-modelo-relacional-azure-sql.md`](07-modelo-relacional-azure-sql.md) §2.x |",
        "| **C** — SQL ejecutable | [`07-ddl/README.md`](07-ddl/README.md) → `07-ddl/sql/<esquema>/` |",
        "",
        f"| Métrica | Valor |",
        "|---|---|",
        f"| Filas COL-* en T05 | {stats['total']} |",
        f"| Tablas a crear (no `A→`) | {stats['create']} |",
        f"| Absorbidas (`A→`, no tabla propia) | {stats['absorbed']} |",
        f"| Con capa B (columnas en `07` §2) | {len(DETAILED_IN_07)} |",
        f"| Con capa C (script `.sql`) | (ver columna por tabla) |",
        "",
        "## Convención de nombres",
        "",
        "| Lógico (T05) | SQL |",
        "|---|---|",
        "| `camelCase` plural | `Esquema.NombrePascal` (mismo término en inglés) |",
        "| PK | `{EntitySingular}Id` `uniqueidentifier` salvo excepción en anexo |",
        "| Multitenancy | `TenantId` cuando alcance T05 = `T` o `T+P` |",
        "",
        "## Índice por esquema",
        "",
        "| Esquema | Tablas |",
        "|---|---|",
    ]
    for schema in sorted(by_schema.keys()):
        lines.append(f"| `{schema}` | {len(by_schema[schema])} |")

    lines.extend(["", "---", ""])

    schema_order = sorted(by_schema.keys(), key=lambda s: (s != "pla", s != "iam", s != "per", s))
    for schema in schema_order:
        group = sorted(by_schema[schema], key=lambda x: x["col_id"])
        lines.append(f"## Esquema `{schema}`")
        lines.append("")
        if schema in SCHEMA_INTRO:
            lines.append(SCHEMA_INTRO[schema])
            lines.append("")
        for r in group:
            absorbed = "A→" in r["est"]
            det = r["fq"] in DETAILED_IN_07
            scripts = sql_script_paths(r["schema"], r["table"])
            if det:
                detail_link = "**Capa B:** [`07` §2](07-modelo-relacional-azure-sql.md)"
            else:
                detail_link = f"**Capa B:** pendiente — anexo {r['owner']} §7"
            if scripts:
                capa_c = "**Capa C:** " + ", ".join(scripts)
            else:
                capa_c = "**Capa C:** pendiente"
            if absorbed:
                lines.append(f"### ~~`{r['fq']}`~~ — absorbida")
            else:
                lines.append(f"### `{r['fq']}`")
            lines.append("")
            lines.append("| Campo | Valor |")
            lines.append("|---|---|")
            lines.append(f"| ID T05 | {r['col_id']} |")
            lines.append(f"| Colección lógica | `{r['collection']}` |")
            lines.append(f"| Dueño | {r['owner']} |")
            lines.append(f"| Propósito (resumen) | {r['purpose']} |")
            lines.append(f"| `TenantId` | {r['tenant']} |")
            lines.append(f"| Ola contenido | {r['ola']} |")
            lines.append(f"| Estado T05 | {r['est']} |")
            if absorbed:
                lines.append(f"| SQL | No crear; ver `{r['est']}` |")
            else:
                lines.append(f"| PK sugerida | `{pk_name(r['table'])}` (convención; confirmar en anexo) |")
            lines.append(f"| {detail_link} | |")
            lines.append(f"| {capa_c} | |")
            lines.append("")

    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUT} ({stats['total']} rows, {len(by_schema)} schemas)")


if __name__ == "__main__":
    main()