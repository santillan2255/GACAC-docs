import sys, io, glob, re, os
from collections import Counter
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
BK = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo\backup-residuales-T05T09T11-202611051600"

def cells(l):
    out, cur, tick, i = [], "", False, 0
    while i < len(l):
        ch = l[i]
        if ch == "`":
            tick = not tick
        if ch == "\\" and i + 1 < len(l) and l[i + 1] == "|":
            cur += "\\|"; i += 2; continue
        if ch == "|" and not tick:
            out.append(cur); cur = ""
        else:
            cur += ch
        i += 1
    out.append(cur)
    return out[1:-1]

for pref in ("T05", "T09", "T11"):
    f = glob.glob(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\%s-*" % pref)[0]
    raw = open(f, "rb").read()
    b = [x for x in glob.glob(os.path.join(BK, pref + "-*"))][0]
    rb = open(b, "rb").read()
    bom, bom0 = raw.startswith(b"\xef\xbb\xbf"), rb.startswith(b"\xef\xbb\xbf")
    t = raw.decode("utf-8-sig")
    crlf, crlf0 = "\r\n" in t, "\r\n" in rb.decode("utf-8-sig")
    mixed = crlf and ("\n" in t.replace("\r\n", ""))
    L = t.replace("\r\n", "\n").split("\n")
    print("==", pref, "BOM", bom, "(antes", bom0, ") CRLF", crlf, "(antes", crlf0, ") mixto", mixed, "líneas", len(L), "antes", len(rb.decode("utf-8-sig").replace("\r\n", "\n").split("\n")))
    moj = [i + 1 for i, l in enumerate(L) if re.search("Ã|Â|\ufffd|â€", l)]
    print("  mojibake:", moj[:10])
    print("  SIGUE:", [i + 1 for i, l in enumerate(L) if "<!-- SIGUE" in l])
    # IDs definidos al inicio de fila o como encabezado
    defs = Counter()
    for l in L:
        m = re.match(r"^\| ((?:COL|EVT|API|CU|PA|RN|RF|CTR|PAN|JOB|CNC|PRM)-[A-Z]+-[\w.]+|CU-\d+)(?: \(| \|)", l)
        if m:
            defs[m.group(1)] += 1
        m = re.match(r"^#{2,4} (PA-[A-Z]+-\d+)", l)
        if m:
            defs[m.group(1)] += 1
    print("  IDs duplicados:", [k for k, v in defs.items() if v > 1][:20])
    # columnas
    bad = []
    hdr = None
    for i, l in enumerate(L):
        if l.startswith("|"):
            n = len(cells(l))
            if hdr is None:
                hdr = n
            elif n != hdr:
                bad.append((i + 1, n, hdr))
        else:
            hdr = None
    print("  filas con columnas distintas al encabezado:", len(bad), bad[:15])
