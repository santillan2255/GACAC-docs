﻿import json,re
from conc_lib import *
for l in open('repl-log.jsonl',encoding='utf-8'):
    d=json.loads(l)
    if d.get('tag') in ('job','jobs'):
        for p in d.get('pairs',[]):
            new=p[1] if isinstance(p,list) else str(p)
            m=re.findall(r'JOB-[A-Z]{3}-\d+',new)
            print(d.get('code'), sorted(set(m))[:6], new[:150].replace('\n',' '))
print(json.loads(open('repl-log.jsonl',encoding='utf-8').readline()).keys())
L=read(T11).split('\n')
for n in (1462,1550,1551,1552,1553): print(n,L[n-1])
for n,l in enumerate(L,1):
    if 'JOB-CAT-10' in l or 'JOB-TAR-11' in l: print(n,l[:250])
