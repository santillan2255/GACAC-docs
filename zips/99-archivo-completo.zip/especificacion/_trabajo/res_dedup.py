import re
from res_lib import Doc


def quitar_generada(d, coll):
    ls = d.t.split('\n')
    i = next(k for k, l in enumerate(ls) if l.startswith('**`%s`** — ' % coll) and 'definición en texto en §' in l)
    j = i + 1
    while j < len(ls) and not ls[j].startswith('**`') and not re.match(r'#{2,4} ', ls[j]):
        j += 1
    del ls[i:j]
    d.t = '\n'.join(ls)
    d.n += 1


# T07: migrationMappingRules y parallelComparisons ya tenían tabla en §7.3 y §7.9
d = Doc(r'anexos\T07-MIG-*.md')
quitar_generada(d, 'migrationMappingRules')
quitar_generada(d, 'parallelComparisons')
d.rep('\n`migrationMappingRules`:\n', '\n**`migrationMappingRules`**:\n')
d.rep('\n`parallelComparisons`:\n', '\n**`parallelComparisons`**:\n')
d.rep('| `parallelRunId` | ObjectId | |', '| `parallelRunId` | ObjectId | → `parallelRuns`. |')
d.rep('| `accountId`, `contractId`, `billingGroupId` | ObjectId | |',
      '| `accountId`, `contractId`, `billingGroupId` | ObjectId | → `accounts` (M01), `serviceContracts` (M02), `billingGroups` (M05). |')
d.rep('| `goodappsSimDocId` | ObjectId | |', '| `goodappsSimDocId` | ObjectId | → `documents` (T11). |')
d.rep('| `explanation`, `responsibleId`, `ticketRef` | | |',
      '| `explanation`, `responsibleId`, `ticketRef` | | `responsibleId` → `memberships` (T02). |\n| `itemKey` | string | Clave del ítem comparado, única por corrida paralela (campo citado por T05; agregado en el cierre de residuales). |')
d.rep('para las colecciones de este anexo que solo tenían la definición en texto.',
      'para las colecciones de este anexo que solo tenían la definición en texto (`migrationMappingRules` y `parallelComparisons` ya tenían tabla en §7.3 y §7.9).')
d.rep('11 colecciones no tenían tabla de campos', '9 colecciones no tenían tabla de campos')
print('T07', d.save())

# T08: dataCatalogEntries ya tenía tabla en §15.1
d = Doc(r'anexos\T08-NFR-*.md')
quitar_generada(d, 'dataCatalogEntries')
d.rep('| `retentionPolicyId` | ObjectId | Sí | Política aplicable. |', '| `retentionPolicyId` | ObjectId | Sí | Política aplicable; → `retentionPolicies`. |')
d.rep('17 colecciones no tenían tabla de campos', '16 colecciones no tenían tabla de campos')
print('T08', d.save())

# T10: apiUsageDaily ya tenía tabla en §7.20
d = Doc(r'anexos\T10-BIA-*.md')
quitar_generada(d, 'apiUsageDaily')
d.rep('Campos de `apiUsageDaily` (corrección del 05-11-2026; antes solo descripción):',
      '**`apiUsageDaily`** — campos (corrección del 05-11-2026; antes solo descripción):')
d.rep('| `day` | Date (día en zona del tenant) | Sí | Día agregado. | — |',
      '| `date` | Date (día en zona del tenant) | Sí | Día agregado (antes `day`; nombre canónico de T05). | — |')
d.rep('| `status` | Int | Sí | Código HTTP agregado. | — |',
      '| `status` | Int | Sí | Código HTTP agregado (`200` a `599`); no es un estado de ciclo de vida. | — |')
d.rep('Índice único `{ tenantId, apiClientId, day, route, status }`.', 'Índice único `{ tenantId, apiClientId, date, route, status }` (antes con `day`).')
print('T10', d.save())
