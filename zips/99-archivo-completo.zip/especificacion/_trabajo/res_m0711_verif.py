import sys, re, glob, os, collections
sys.stdout.reconfigure(encoding='utf-8')
A = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
B = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo\backup-residuales-M07M11-20261105'
for mod in ('M07', 'M08', 'M09', 'M10', 'M11'):
    p = glob.glob(os.path.join(A, mod + '-*.md'))[0]
    bk = os.path.join(B, os.path.basename(p))
    raw = open(p, 'rb').read()
    braw = open(bk, 'rb').read()
    txt = raw.decode('utf-8')
    print('=====', mod, 'BOM', raw.startswith(b'\xef\xbb\xbf'), '/', braw.startswith(b'\xef\xbb\xbf'),
          'CRLF', b'\r\n' in raw, '/', b'\r\n' in braw,
          'LF sueltos', len(re.findall(rb'(?<!\r)\n', raw)) if b'\r\n' in braw else '-')
    lines = txt.replace('\r\n', '\n').split('\n')
    blines = braw.decode('utf-8-sig').replace('\r\n', '\n').split('\n')
    print('lineas', len(blines), '->', len(lines))
    for pat in ('Ã', 'Â', '\ufffd', '<!-- SIGUE -->'):
        n = txt.count(pat) - braw.decode('utf-8-sig').count(pat)
        if txt.count(pat):
            print('  patron', repr(pat), txt.count(pat), 'nuevos', n)
    ids = collections.Counter(re.match(r'^### (PA-[A-Z]+-\d+)', l).group(1) for l in lines if re.match(r'^### PA-[A-Z]+-\d+', l))
    print('  PA duplicados', [k for k, v in ids.items() if v > 1], 'ultimo', sorted(ids)[-1])
    hs = collections.Counter(re.match(r'^(#{2,4} \d+(\.\d+)*)[ .]', l).group(1) for l in lines if re.match(r'^#{2,4} \d+(\.\d+)*[ .]', l))
    print('  secciones duplicadas', [k for k, v in hs.items() if v > 1])
    # tablas: columnas coherentes
    i = 0
    bad = 0
    while i < len(lines):
        if lines[i].startswith('|') and i + 1 < len(lines) and re.match(r'^\|[-| :]+\|\s*$', lines[i + 1]):
            def nc(l):
                return len(re.split(r'(?<!\\)\|', l.strip())) - 2
            n = nc(lines[i])
            j = i + 2
            while j < len(lines) and lines[j].startswith('|'):
                if nc(lines[j]) != n and lines[j] not in blines:
                    bad += 1
                    print('  COLS', j + 1, n, nc(lines[j]), lines[j][:140])
                j += 1
            i = j
        else:
            i += 1
    print('  filas nuevas con columnas incoherentes', bad)
    print('  [VERIFICAR] destino no deducible restantes', txt.count('[VERIFICAR] destino no deducible') - sum(l.count('antes "[VERIFICAR] destino no deducible') for l in lines))
