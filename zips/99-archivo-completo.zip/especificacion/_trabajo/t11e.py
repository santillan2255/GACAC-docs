import re, json
from conc_lib import *

s = read(T11)
L = s.split('\n')
log = []

def idx(pred, desc):
    m = [i for i, l in enumerate(L) if pred(l)]
    assert len(m) == 1, (desc, len(m))
    return m[0]

def row(prefix):
    return idx(lambda l: l.startswith(prefix), prefix)

def cells(i):
    return L[i].split('|')[1:-1]

def setcells(i, ch):
    c = cells(i)
    for k, v in ch.items():
        c[k] = ' ' + v + ' '
    L[i] = '|' + '|'.join(c) + '|'

def repl_line(i, old, new):
    assert L[i].count(old) == 1, (i, old)
    L[i] = L[i].replace(old, new)

# --- 12.1 convención de IDs
i = row('- **ID:** se conserva el que declaró cada anexo.')
repl_line(i, 'A los eventos que su anexo publicó sin ID (solo M02), T11 les asigna un ID provisional con el sufijo "(prov.)", que el anexo dueño debe adoptar (CTR-WFL-04).',
          'M02, que publicaba sus eventos sin ID, adoptó EVT-CAT-01..25 en el orden de su §12.1 y agregó EVT-CAT-26/27 (CTR-WFL-04 resuelto).')

# --- 12.3 bloque M02
i = row('#### M02 CAT — productor M02 (IDs provisionales asignados por T11)')
L[i] = '#### M02 CAT — productor M02'
n = 0
for k, l in enumerate(L):
    if re.match(r'\| EVT-CAT-\d\d \(prov\.\) \|', l):
        L[k] = l.replace(' (prov.)', '', 1); n += 1
assert n == 25, n
assert '(prov.)' not in '\n'.join(L).replace('"(prov.)"', '')

def insert_after(prefix, rows):
    i = row(prefix)
    for r in reversed(rows):
        L.insert(i + 1, r)

insert_after('| EVT-CAT-25 |', [
 '| EVT-CAT-26 | `cat.serviceCopy.prepared` | `copyRunId`, `sourceTenantId`, `targetTenantId`, `components[]` | T04 (tenant destino) |',
 '| EVT-CAT-27 | `cat.command.rejected` | `commandRequestId`, `command`, `contractId`, `errorCode`, `errors[]` | M09 |'])
insert_after('| EVT-FAC-20 |', [
 '| EVT-FAC-21 | `fac.billingRun.discarded` | `runId`, `cycleId`, `reason`, `discardedBy` | M04, T10 |'])
insert_after('| EVT-FIS-21 |', [
 '| EVT-FIS-22 | `fis.misComprobantes.reconciled` | período, CUIT del proveedor, conciliados, con diferencia | M12 |',
 '| EVT-FIS-23 | `fis.withholdingComputation.updated` | orden o ejecución de pago, retenciones por régimen, base, importe | M14 |'])
insert_after('| EVT-COB-23 |', [
 '| EVT-COB-24 | `cob.payment.informed` | operación informada, cuenta, importe, canal, evidencia | M08, M19 |',
 '| EVT-COB-25 | `cob.cashSession.reopened` | sesión, motivo, autorizante | M14 |',
 '| EVT-COB-26 | `cob.unidentified.resolved` | cobro no identificado, cuenta, operación de cobro | M14 |',
 '| EVT-COB-27 | `cob.refund.approved` | reintegro, cuenta, importe, medio de pago | M14, T06 |'])
insert_after('| EVT-TEC-31 |', [
 '| EVT-TEC-32 | `tec.crewTimesheet.approved` | `timesheetId`, `crewId`, `workOrderIds`, horas normales, extra y guardias | M16 |',
 '| EVT-TEC-33 | `tec.provisioning.requested` | `commandId`, `contractId`, `action`, `systemId`, `profile` | T06 |',
 '| EVT-TEC-34 | `tec.work.completed` | `workId`, `completedAt`, `costTotal`, destino | M15, M13 |'])
insert_after('| EVT-VEN-14 |', [
 '| EVT-VEN-15 | `ven.salesOrder.invoiced` | `salesOrderId`, `invoiceId` | M13, T10 |'])
insert_after('| EVT-CMP-14 |', [
 '| EVT-CMP-15 | `cmp.paymentOrder.prepared` | `paymentOrderId`, `supplierId`, `items`, `amount` | M06 |'])
insert_after('| EVT-STK-22 |', [
 '| EVT-STK-23 | `stk.reservation.failed` | `reservationRequestId`, `sourceRef`, `itemId`, `missingQty` | M10, M11 |',
 '| EVT-STK-24 | `stk.goods.rejected` | `receiptId`, `items`, `reason` | M12 |'])
insert_after('| EVT-TES-22 |', [
 '| EVT-TES-23 | `tes.advance.paid` | `advanceId`, `employeeId`, `amount`, `paidAt` | M16 |'])
insert_after('| EVT-SUE-26 |', [
 '| EVT-SUE-27 | `sue.paymentRequest.cancelled` | `paymentRequestId`, `reason` | M14 |'])
insert_after('| EVT-PLA-20 |', [
 '| EVT-PLA-21 | `pla.branch.created` / `.updated` | `branchId`, `code`, `name`, `status` | T03, T04 |',
 '| EVT-PLA-22 | `pla.tenantProfile.updated` | `tenantId`, `changedFields` | T03, T11, M06 |'])
i = row('| EVT-TAR-012 |'); setcells(i, {3: 'T09, M19, M02 (JOB-CAT-10)'})
i = row('| EVT-STK-07 |'); setcells(i, {3: 'M09, T09, M02 (JOB-CAT-09)'})

# --- 12.4 brechas
def brow(prefix, c2=None, c3=None, add2=None):
    i = row(prefix); ch = {}
    if c2: ch[2] = c2
    if add2: ch[2] = cells(i)[2].strip() + add2
    if c3: ch[3] = c3
    setcells(i, ch)
brow('| `fac.batch.discarded` |', '`fac.billingRun.discarded` (EVT-FAC-21)', 'Brecha resuelta: M05 lo declara; M04 consume el canónico')
brow('| `fis.withholdingComputation.updated`, ', '`fis.withholdingComputation.updated` (EVT-FIS-23), `fis.misComprobantes.reconciled` (EVT-FIS-22)', 'Brecha resuelta: M06 los declara')
brow('| `cat.serviceCopy.prepared` |', '`cat.serviceCopy.prepared` (EVT-CAT-26)', 'Brecha resuelta: M02 lo declara')
brow('| `tec.crewTimesheet.approved` |', '`tec.crewTimesheet.approved` (EVT-TEC-32)', 'Brecha resuelta: M10 lo declara')
brow('| `cob.payment.informed` |', '`cob.payment.informed` (EVT-COB-24)', 'Brecha resuelta: M07 lo declara')
brow('| `cob.cashSession.reopened`, ', 'EVT-COB-25, EVT-COB-26, EVT-COB-27', 'Brecha resuelta: M07 los declara (`cob.refund.approved` deriva de `wfl.operation.approved` con `typeCode = cob.refund.execute`)')
brow('| `stk.movement.confirmed` / `.rejected` / `.posted` |', None, 'Alias; brecha de `rejected` cerrada con EVT-STK-24 (M13)', '; `.rejected` → `stk.goods.rejected` (EVT-STK-24)')
brow('| `stk.reservation.failed`, `inv.reservation.failed` |', '`stk.reservation.failed` (EVT-STK-23)', 'Brecha resuelta: M13 lo declara; `inv.reservation.failed` es alias')
brow('| `cmp.paymentOrder.prepared` |', '`cmp.paymentOrder.prepared` (EVT-CMP-15)', 'Brecha resuelta: M12 lo declara')
brow('| `tes.paymentRequest.accepted` /', None, 'Alias; brecha de `advance.paid` cerrada con EVT-TES-23 (M14)', '; `tes.advance.paid` (EVT-TES-23)')
brow('| `sue.payroll.closed`, ', None, 'Alias; brecha de `cancelled` cerrada con EVT-SUE-27 (M16)', '; `.cancelled` → `sue.paymentRequest.cancelled` (EVT-SUE-27)')
assert not any(re.search(r'\*\*Brecha\*\*|es \*\*brecha\*\*', l) for l in L[row('### 12.4 '):row('#### 12.4.1')]), 'quedan brechas'
i = row('Consolidar las secciones 12 mostró que varios consumidores')
L.insert(i + 1, '')
L.insert(i + 2, 'Estado de la conciliación (4/11/2026): las 12 brechas tienen productor declarado y los consumidores usan el nombre canónico con su EVT-ID. La tabla se conserva como registro de `eventTypes.aliases` hasta su vencimiento (cierre de O2).')

# --- 12.4.1
def evname():
    d = {}
    for l in L[row('### 12.2 '):row('### 12.4 ')]:
        m = re.match(r'\| (EVT-[A-Z]{3}-\d+) \| (`[^`]+`)', l)
        if m: d[m.group(1)] = m.group(2)
    return d
EV = evname()
def fmt(v):
    if re.fullmatch(r'EVT-[A-Z]{3}-\d+', v): return f'{EV[v]} ({v})'
    return v
conc = {1:'`iam.membership.suspended` / `.revoked` (EVT-IAM-03)', 2:'`cfg.configVersion.published` (EVT-CFG-05)', 3:'`tar.schedule.published` (EVT-TAR-004)',
 4:'`int.credential.expiring` / `.rotated` (EVT-INT-05)', 5:'`int.circuit.opened` / `.closed` (EVT-INT-04)', 6:'`int.connection.activated` (EVT-INT-01)',
 8:'EVT-PLA-08', 9:'EVT-PLA-06, EVT-PLA-07', 10:'`iam.role.changed` (EVT-IAM-05)', 11:'EVT-IAM-04', 12:'`iam.profile.changed` (EVT-IAM-05)',
 16:'EVT-FAC-03', 18:'EVT-COB-04', 19:'`fac.billingRun.prebilled` (EVT-FAC-02)', 20:'EVT-IAM-07', 21:'`iam.securityAlert.raised` (EVT-IAM-14)',
 22:'EVT-IAM-11', 23:'EVT-INS-14', 24:'EVT-CRM-09', 25:'`tec.outage.notified` (EVT-TEC-23)', 49:'EVT-TEC-23, EVT-COM-25',
 83:'EVT-COB-01, EVT-COB-04, EVT-COB-05, EVT-COB-06', 84:'EVT-FAC-06', 85:'EVT-COB-12', 86:'EVT-MOR-07', 87:'EVT-MED-07',
 88:'`iam.role.unassigned` (EVT-IAM-04)', 89:'EVT-IAM-04, EVT-IAM-05', 90:'EVT-CFG-05', 91:'`crm.case.statusChanged` (EVT-CRM-05)',
 100:'`tes.cashRemittance.accepted` (EVT-TES-08)', 104:'`crm.queueTicket.called` (EVT-CRM-20)', 110:'EVT-CAT-08', 111:'EVT-CAT-18', 112:'EVT-CAT-13',
 114:'EVT-STK-02', 115:'EVT-CMP-08', 116:'EVT-CMP-08 con `kind = creditNote`', 117:'`stk.valuation.changed` (EVT-STK-14)',
 118:'`stk.fixedAsset.registered` (EVT-STK-17)', 119:'`stk.fixedAsset.valueChanged` (EVT-STK-17)', 120:'`stk.fixedAsset.valueChanged` (EVT-STK-17)',
 121:'`stk.manufacturing.inProcess` (EVT-STK-20)', 127:'EVT-PER-18'}
tipo = {26:'EVT-COB-04', 27:'EVT-VEN-07', 28:'EVT-COM-14', 50:'EVT-TEC-22', 65:'EVT-COM-22', 66:'EVT-IAM-08', 67:'EVT-POR-06', 68:'EVT-POR-07',
 69:'EVT-POR-08', 70:'EVT-CRM-24', 71:'EVT-COM-20', 72:'EVT-COM-30', 73:'EVT-TEC-16', 74:'EVT-VEN-06', 75:'EVT-TAR-001', 76:'EVT-COB-20',
 77:'EVT-COB-22', 78:'EVT-MOR-11', 79:'EVT-MOR-14', 80:'EVT-CMP-03', 81:'EVT-CMP-14', 82:'EVT-SUE-08'}
brecha = {13:'EVT-PLA-21', 14:'EVT-PLA-21', 15:'EVT-PLA-22', 17:'EVT-TEC-33', 101:'EVT-CAT-27', 113:'EVT-VEN-15', 122:'EVT-TEC-34'}
retirado = list(range(29, 49)) + list(range(51, 65))
desc = {7:'ejemplo de RF-UXD-103', 92:'plantilla de correo; el evento es EVT-BIA-12', 93:'clave PRM-BIA-070', 99:'código de error de M03',
 102:'clave PRM-CRM-011', 103:'clave PRM-CRM-050'}
for k in range(94, 99): desc[k] = 'métrica de la capa semántica de T10'
for k in range(105, 110): desc[k] = 'código de error de M10'
for k in range(123, 127): desc[k] = 'código de error de M17'
for k in range(128, 131): desc[k] = 'código de error de M18'
allk = set(conc) | set(tipo) | set(brecha) | set(retirado) | set(desc)
assert allk == set(range(1, 131)), sorted(set(range(1, 131)) - allk)
assert sum(map(len, (conc, tipo, brecha, retirado, desc))) == 130
def ids(v): return ', '.join(fmt(x.strip()) for x in v.split(', ')) if re.fullmatch(r'(EVT-[A-Z]{3}-\d+(, )?)+', v) else v
for k in range(1, 131):
    i = row(f'| CNC-WFL-{k:03d} |')
    if k in conc: st = 'Conciliado: ' + ids(conc[k])
    elif k in tipo: st = f'Conciliado: tipo de comunicación de T09 disparado por {fmt(tipo[k])}'
    elif k in brecha: st = f'Brecha resuelta: {fmt(brecha[k])}'
    elif k in retirado: st = 'Retirado: el consumidor ya no lo usa'
    else: st = f'Descartado: no es evento ({desc[k]})'
    setcells(i, {4: st})
i = row('| ID | Nombre usado por el consumidor | Anexos que lo consumen o mencionan | Candidato sugerido (a confirmar) | Tratamiento propuesto |')
L[i] = '| ID | Nombre usado por el consumidor | Anexos que lo consumen o mencionan | Candidato sugerido (a confirmar) | Estado (4/11/2026) |'
i = row('#### 12.4.1 Nombres consumidos pendientes de conciliación')
L[i] = '#### 12.4.1 Nombres consumidos sin productor declarado: estado de conciliación'
i = row('Además de la tabla anterior, el cruce automático')
L.insert(i + 1, '')
L.insert(i + 2, f'Resultado de la conciliación: {len(conc)+len(tipo)} filas conciliadas ({len(tipo)} son códigos de tipo de comunicación de T09 que dispara un evento canónico), {len(brecha)} brechas resueltas con un evento nuevo del productor, {len(retirado)} retiradas porque ningún anexo las usa ya y {len(desc)} descartadas porque no son eventos (códigos de error, claves PRM, plantillas o métricas).')

# --- 12.8 y 12.9
i = row('| JOB-INT-23 | `int:importar-cdr` |')
setcells(i, {1: '`int:recibir-cdr`', 3: '`integration` (recibe y publica EVT-INT-16; M10 parsea con JOB-TEC-09; §12.9)'})
i = row('| JOB-SUE-04 | `sue:firmar-recibos-empleador` |')
setcells(i, {3: '`integration` (solo pide la firma a T11; ejecuta JOB-WFL-17; CTR-WFL-12)'})
i = row('| JOB-SUE-06 | `sue:consultar-estado-firma` |')
setcells(i, {2: '—', 3: '`integration` — Retirado. Ver JOB-WFL-18 (dueño)'})
i = row('| JOB-SUE-19 | `sue:recordatorios-firma` |')
setcells(i, {2: '—', 3: '`notifications` — Retirado. Ver JOB-WFL-09 (dueño)'})
ret = {'JOB-PER-05':'Reemplazado por JOB-SOC-01', 'JOB-CAT-07':'Reemplazado por JOB-SOC-01', 'JOB-PER-10':'Retirado. Ver JOB-CFG-08 (dueño)',
 'JOB-FIS-08':'Retirado. Ver JOB-CFG-08 (dueño)', 'JOB-CRM-18':'Retirado. Ver JOB-COM-14 (dueño)', 'JOB-TEC-08':'Retirado. Ver JOB-COM-13 (dueño)',
 'JOB-TES-14':'Retirado. Ver `deadLetters` de T01', 'JOB-NFR-05':'Retirado. Ver JOB-IAM-05 (dueño)', 'JOB-NFR-12':'Retirado. Ver JOB-PLA-21 (dueño)',
 'JOB-NFR-19':'Retirado. Ver JOB-PLA-12 (dueño)'}
def app3(i, t):
    setcells(i, {3: cells(i)[3].strip() + ' — ' + t})
for j, t in ret.items():
    app3(row(f'| {j} |'), t)
reac = {'JOB-CAT-09':'Reacción a EVT-STK-07. Ver JOB-STK-05 (dueño)', 'JOB-CAT-10':'Reacción a EVT-TAR-012. Ver JOB-TAR-11 (dueño)',
 'JOB-CAT-08':'Dueño del fin de suspensión voluntaria; publica EVT-CAT-12',
 'JOB-PER-02':'Reacción a EVT-CFG-15. Ver JOB-CFG-09 (dueño)', 'JOB-TEC-10':'Reacción a EVT-CFG-15. Ver JOB-CFG-09 (dueño)',
 'JOB-FIS-17':'Reacción a EVT-INT-06. Ver JOB-INT-18 (dueño)', 'JOB-CRM-01':'Reacción a EVT-WFL-020/021. Ver JOB-WFL-04 (dueño)',
 'JOB-NFR-21':'Reacción a EVT-PLA-10. Ver JOB-PLA-05 (dueño)', 'JOB-PLA-04':'Reacción a EVT-IAM-11. Ver JOB-IAM-02 (dueño)'}
for j, t in reac.items():
    app3(row(f'| {j} |'), t)
i = row('| JOB-CAT-10 |'); setcells(i, {2: 'Evento EVT-TAR-012'})
i = row('| JOB-CAT-09 |'); setcells(i, {2: 'Evento EVT-STK-07'})

t9 = {'Vencer accesos de soporte':'Aplicado: JOB-PLA-04 reacciona a EVT-IAM-11 y emite EVT-PLA-12 `expired`',
 'Mayoría de edad de adherentes':'Aplicado: JOB-PER-05 y JOB-CAT-07 marcados "Reemplazado por JOB-SOC-01"',
 'Fin de suspensión voluntaria':'Aplicado: JOB-CAT-08 vence y publica EVT-CAT-12; JOB-MOR-08 es consumidor',
 'Devoluciones de equipos vencidas':'Aplicado: JOB-CAT-09 reacciona a EVT-STK-07',
 'Parámetros de ARCA':'Aplicado: JOB-FIS-17 reacciona a EVT-INT-06',
 'Padrones fiscales':'Aplicado: JOB-FIS-08 y JOB-PER-10 retirados; JOB-INT-25/26 quedan como transporte',
 'Importación de CDR':'Aplicado: JOB-INT-23 renombrado `int:recibir-cdr` (recibe); M10 parsea y atribuye',
 'Vencer intenciones de pago':'Aplicado: JOB-INT-27 solo limpia su bitácora técnica',
 'Geocodificación':'Aplicado: JOB-PER-02 y JOB-TEC-10 reaccionan a EVT-CFG-15',
 'Recategorización':'Aplicado: JOB-FAC-10 limitado a la simulación',
 'Posiciones GPS':'JOB-SOC-08 pasa a consumidor de EVT-INT-17 (pendiente en M18)',
 'Antivirus':'Aplicado: JOB-NFR-12 retirado',
 'Firma de recibos':'Aplicado (DEC-078): JOB-SUE-04 solo pide la firma a T11; JOB-SUE-06 y JOB-SUE-19 retirados (CTR-WFL-12)',
 'SLA':'Aplicado: JOB-CRM-01 reacciona a EVT-WFL-020/021 (PA-WFL-12)',
 'Recordatorios de agenda':'Aplicado: JOB-CRM-15 solo marca ausencias; JOB-TEC-08 retirado',
 'Plantillas de WhatsApp':'Aplicado: JOB-CRM-18 retirado',
 'Conciliación tras restauración':'Aplicado: JOB-NFR-19 retirado',
 'Medición de uso':'Aplicado: JOB-NFR-21 reacciona a EVT-PLA-10',
 'Integridad de auditoría':'Aplicado: JOB-NFR-05 retirado',
 'Reintento de eventos consumidos':'Aplicado: JOB-TES-14 retirado'}
a9 = row('### 12.9 ')
def row9(p):
    return idx(lambda l, _p=p: l.startswith(_p) and L.index(l) > a9 and L.index(l) < a9 + 40, p)
for f, t in t9.items():
    i = row9(f'| {f} |'); setcells(i, {3: t})
i = row9('| Importación de CDR |'); setcells(i, {2: 'T06 recibe (JOB-INT-23 `int:recibir-cdr`, EVT-INT-16); M10 parsea y atribuye (JOB-TEC-09)'})
i = row9('| Recategorización |')
L[i+1:i+1] = ['| Fin de promociones | JOB-TAR-11, JOB-CAT-10 | M04 (JOB-TAR-11; publica EVT-TAR-012) | Aplicado: JOB-CAT-10 reacciona a EVT-TAR-012 |']

# --- 18.5, flujo de firma, CTR, PA
i = row('| SIG-SUE-EMPLEADOR |')
setcells(i, {1: '`digital` (proveedor licenciado por conector T06)', 3: 'Recibos de sueldo (DEC-078; O8)'})
i = row('| SIG-ACTA-INSTITUCIONAL |')
setcells(i, {1: '`digital` (proveedor licenciado por conector T06)', 3: 'Actas de asamblea y de consejo (DEC-078; O8/O9)'})
i = row('1. M16 emite los recibos (`sue:emitir-recibos-pdf` usa el render de T11)')
L[i] = '1. M16 emite los recibos (`sue:emitir-recibos-pdf` usa el render de T11) y pide a T11 la firma del empleador (JOB-SUE-04 llama a API-WFL-75; T11 la ejecuta con JOB-WFL-17). El perfil `SIG-SUE-EMPLEADOR` es firma digital con proveedor licenciado por T06 (DEC-078).'
i = row('5. `wfl:consultar-estado-firma` sondea los proveedores')
repl_line(i, 'JOB-SUE-06 y JOB-SUE-19 de M16 pasan a usar estos jobs (CTR-WFL-12).', 'JOB-SUE-06 y JOB-SUE-19 de M16 se retiraron en favor de estos jobs (CTR-WFL-12).')
i = row('| CTR-WFL-12 |')
setcells(i, {3: 'Resuelto por DEC-078: T11 centraliza la firma en tres niveles (`simple`, `electronic`, `digital`) con perfiles (§18.5). Electrónica con OTP por defecto; digital con proveedor licenciado (conector T06) solo para recibos de sueldo y actas, en O8/O9. M16 no tiene lógica de firma: JOB-SUE-04 solo pide la firma a T11 (JOB-WFL-17); JOB-SUE-06 y JOB-SUE-19 se retiraron en favor de JOB-WFL-18 y JOB-WFL-09.'})
i = row('| CTR-WFL-04 |')
setcells(i, {3: 'Resuelto: M02 adoptó EVT-CAT-01..25 en el mismo orden y con los mismos nombres, y agregó EVT-CAT-26/27.'})
i = row('### PA-WFL-06 — Proveedor y nivel de firma por documento')
j = idx(lambda l: l.startswith('- **Bloquea:** RF-WFL-198, PRM-WFL-048, perfiles de §18.5, JOB-SUE-04; O8.'), 'bloquea pa06')
assert j > i and j - i < 10
if not L[j + 1].startswith('- **Estado:**'):
    L.insert(j + 1, '- **Estado:** Resuelta por DEC-078 (opción A).')

# --- 12.10 totales
txt = '\n'.join(L)
sec = txt[txt.index('### 12.3 '):txt.index('### 12.4 ')]
ids3 = re.findall(r'^\| (EVT-([A-Z]{3})-\d+) \|', sec, re.M)
from collections import Counter
cnt = Counter(m for _, m in ids3)
T = ['PLA', 'IAM', 'UXD', 'CFG', 'INT', 'MIG', 'NFR', 'COM', 'BIA']
mods = sum(v for k, v in cnt.items() if k not in T)
tr = sum(cnt[k] for k in T)
wfl = len(re.findall(r'^\| EVT-WFL-\d+ \|', txt[txt.index('### 12.2 '):txt.index('### 12.3 ')], re.M))
print('mods', mods, 'trans', tr, 'wfl', wfl, {k: cnt[k] for k in T})
i = row('| IDs de eventos de M01–M19 |'); setcells(i, {1: f'{mods}'})
i = row('| IDs de eventos de T01, T02, T03, T04, T06, T07, T08, T09, T10 |')
setcells(i, {1: f'{tr} (' + ', '.join(f'{k} {cnt[k]}' for k in T) + ')'})
i = row('| IDs de eventos propios de T11 |'); setcells(i, {1: f'{wfl}'})
i = row('| **Total de IDs EVT** |'); setcells(i, {1: f'**{mods+tr+wfl}**'})
i = row('| Filas de conciliación en §12.4 |'); setcells(i, {1: '83; las 12 brechas tienen productor declarado'})

write(T11, '\n'.join(L))
print('ok T11')
