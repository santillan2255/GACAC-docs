#!/usr/bin/env python3
"""Revisión estática del DDL capa C (sin SQL Server)."""
from __future__ import annotations

import re
import sys
from collections import defaultdict
from pathlib import Path

ESPEC = Path(__file__).resolve().parents[1]
DDL = ESPEC / "07-ddl" / "sql"
OUT = ESPEC / "07-ddl" / "QUALITY-REPORT.md"

sys.path.insert(0, str(Path(__file__).resolve().parent))
from generate_07_catalog_from_t05 import parse_t05  # noqa: E402

CREATE_RE = re.compile(
    r"CREATE TABLE\s+\[(\w+)\]\.\[(\w+)\]\s*\((.*)\)\s*;",
    re.S | re.I,
)
COL_RE = re.compile(r"\[([^\]]+)\]\s+(\w+(?:\([^)]*\))?)", re.I)


def parse_global_alc() -> dict[str, str]:
    """fq table -> alc (G/P/T/...)"""
    out = {}
    for r in parse_t05():
        if "A→" in r["est"]:
            continue
        out[f"{r['schema']}.{r['table']}"] = r["alc"].strip().split()[0]
    return out


def scan_file(path: Path, global_alc: dict) -> list[str]:
    issues = []
    text = path.read_text(encoding="utf-8", errors="replace")
    m = CREATE_RE.search(text)
    if not m:
        issues.append("no CREATE TABLE encontrado")
        return issues
    schema, table, body = m.groups()
    fq = f"{schema}.{table}"
    cols = []
    for line in body.splitlines():
        ls = line.strip()
        if ls.startswith("CONSTRAINT"):
            continue
        cm = re.match(r"\[([^\]]+)\]\s+(\w+(?:\([^)]*\))?)", ls)
        if cm:
            cols.append((cm.group(1), cm.group(2)))
    names = [c[0] for c in cols]
    dupes = {n for n in names if names.count(n) > 1}
    if dupes:
        issues.append(f"columnas duplicadas: {', '.join(sorted(dupes))}")
    for mname in re.finditer(r"CONSTRAINT\s+\[([^\]]+)\]", text, re.I):
        if len(mname.group(1)) > 128:
            issues.append(f"nombre constraint >128: {mname.group(1)[:40]}…")
    alc = global_alc.get(fq, "")
    has_tenant = "TenantId" in names
    if alc == "G" and has_tenant and not (schema == "pla" and table == "Tenants"):
        issues.append("TenantId en tabla alcance global (G)")
    if alc == "G" and "FK_" in text and "Tenants" in text:
        issues.append("FK a Tenants en tabla global (G)")
    for n, typ in cols:
        if n.endswith("At") and typ.upper() == "DATE":
            issues.append(f"{n} debería ser DATETIME2, no DATE")
    if "SpecificationNote" in names:
        issues.append("fallback (SpecificationNote)")
    return issues


def main() -> int:
    global_alc = parse_global_alc()
    by_kind: dict[str, list] = defaultdict(list)
    files = sorted(DDL.rglob("*.sql"))
    files = [
        f
        for f in files
        if f.name not in ("deploy-all.sql", "000-all-schemas.sql", "000-create-schema.sql")
        and not f.name.startswith("099-")
    ]
    for path in files:
        issues = scan_file(path, global_alc)
        for iss in issues:
            by_kind[iss.split("(")[0].split(":")[0].strip()].append((path.relative_to(DDL), iss))

    from datetime import date

    lines = [
        f"# Informe calidad DDL — {date.today().isoformat()}",
        "",
        f"Archivos revisados: **{len(files)}**",
        "",
    ]
    err_count = 0
    for kind, items in sorted(by_kind.items(), key=lambda x: -len(x[1])):
        lines.append(f"## {kind} ({len(items)})")
        lines.append("")
        show = items[:30]
        for rel, iss in show:
            lines.append(f"- `{rel}`: {iss}")
        if len(items) > 30:
            lines.append(f"- … y {len(items) - 30} más")
        lines.append("")
        if not kind.startswith("fallback"):
            err_count += len(items)

    fallback_n = sum(len(v) for k, v in by_kind.items() if k.startswith("fallback"))
    summary = [
        "| Métrica | Valor |",
        "|---|---|",
        f"| Problemas duros (excl. fallback) | {err_count} |",
        f"| Fallback (SpecificationNote) | {fallback_n} |",
        "",
    ]
    lines = lines[:3] + summary + lines[3:]
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUT.relative_to(ESPEC)}")
    print(f"fallback={fallback_n} hard_issues={err_count}")
    return 1 if err_count else 0


if __name__ == "__main__":
    raise SystemExit(main())