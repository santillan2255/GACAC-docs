# -*- coding: utf-8 -*-
"""Verificación: encabezados únicos, IDs definidos una vez, sin SIGUE, sin mojibake, tablas consistentes."""
import re, sys, collections
sys.stdout.reconfigure(encoding='utf-8')
for P in sys.argv[1:]:
    raw = open(P, 'rb').read()
    print('==', P.split('\\')[-1], 'BOM' if raw.startswith(b'\xef\xbb\xbf') else 'sin BOM', 'CRLF' if b'\r\n' in raw else 'LF')
    t = raw.decode('utf-8')
    L = t.split('\n')
    h = collections.Counter(l.strip() for l in L if l.startswith('#'))
    print(' encabezados repetidos:', [k for k, v in h.items() if v > 1])
    print(' SIGUE:', t.count('<!-- SIGUE -->'))
    moj = [i + 1 for i, l in enumerate(L) if re.search('Ã.|Â.|â€|�', l)]
    print(' mojibake:', moj[:10])
    ids = collections.Counter()
    for l in L:
        m = re.match(r'^\| ((?:RF|RN|API|PAN|EVT|JOB|PRM|CU|ESC|CTR|INT)-[A-Z0-9]+-[A-Z0-9-]+) \|', l)
        if m:
            ids[m.group(1)] += 1
        m = re.match(r'^#+ ((?:PA|CU)-[A-Z]+-\d+)\b', l)
        if m:
            ids[m.group(1)] += 1
    print(' IDs de fila repetidos:', [k for k, v in ids.items() if v > 1])
    # tablas
    bad = []
    i = 0
    while i < len(L):
        if L[i].startswith('|') and i + 1 < len(L) and re.match(r'^\|[-: |]+\|$', L[i + 1]):
            def n(s):
                s = re.sub(r'`[^`]*`', 'X', s.replace('\\|', 'X'))
                return s.count('|') - 1
            k = n(L[i]); j = i + 2
            while j < len(L) and L[j].startswith('|'):
                if n(L[j]) != k:
                    bad.append(j + 1)
                j += 1
            i = j
        else:
            i += 1
    print(' filas con columnas distintas al encabezado:', bad[:20], len(bad))
