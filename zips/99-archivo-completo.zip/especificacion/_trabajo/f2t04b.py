import sys, re, os
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from conc_lib import ANX, read, write

def path(n):
    return os.path.join(ANX, 'T04b-CFG-catalogo-parametros-procoop-parte%d.md' % n)

# Parte 1: filas 518-527 y PA-CFG-P1-02
p = path(1)
s = read(p)
L = s.split('\n')
n = 0
dest = {'526': '`legalEntities.fiscal.iibbNumber`', '527': '`legalEntities.fiscal.ivaConditionCode`',
        '518': '`legalEntities.legalName`', '519': '`legalEntities.fiscal.cuit`'}
for i, l in enumerate(L):
    m = re.match(r'^\| (518|519|52[0-7]) \| VAR \|', l)
    if m and l.rstrip().endswith('|') and 'DEC-064' not in l:
        code = m.group(1)
        tgt = dest.get(code, '`legalEntities.address` / `contact`')
        L[i] = l.rstrip()[:-1].rstrip() + ' → T04 %s de la entidad por defecto (RF-CFG-134/135, DEC-064) |' % tgt
        n += 1
assert n == 10, n
s = '\n'.join(L)
old = "- **Bloquea:** PRM-PLA-P1 (perfil del tenant), T01 (O1), M05/M06 (leyendas fiscales).\n"
assert s.count(old) == 1
s = s.replace(old, old + "- **Estado:** Respondida en parte por DEC-064: los datos legales y fiscales básicos viven en `legalEntities` de T04 (RF-CFG-134), no en el perfil del tenant de T01. Para quién edita se asume la opción A (DEC-072) salvo respuesta del solicitante, con la regla de T04 RN-CFG-052: el CUIT no se edita una vez que la entidad tiene documentos; un CUIT distinto es una entidad nueva (PA-CFG-14).\n")
write(p, s)
print('parte1', n)

# Partes 2-4: alias tenantParameters
for k in (2, 3, 4):
    p = path(k)
    s = read(p)
    c = s.count('(`tenantParameters`, versionado')
    assert c == 1, (k, c)
    s = s.replace('(`tenantParameters`, versionado', '(`tenantParameters`, alias de `parameterValues` según CTR-CFG-14 y CTR-DAT-49; versionado')
    if k == 3:
        old = '| `tenantParameters` (T04) con semántica en el anexo destino |'
        assert s.count(old) == 1
        s = s.replace(old, '| `tenantParameters` (alias de `parameterValues`, T04; CTR-DAT-49) con semántica en el anexo destino |')
    write(p, s)
    print('parte', k)
