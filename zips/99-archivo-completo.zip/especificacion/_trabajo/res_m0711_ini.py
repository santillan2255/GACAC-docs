import sys, re, glob, os
sys.stdout.reconfigure(encoding='utf-8')
B = r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno'
MODS = ('COB', 'MOR', 'CRM', 'TEC', 'VEN')
for f in ['06d-estados-m05-m07.md', '06e-estados-m07-m09.md', '06f-estados-m09-m12.md']:
    lines = open(os.path.join(B, f), encoding='utf-8').read().split('\n')
    cur = None
    for i, l in enumerate(lines):
        m = re.match(r'^#{2,4}\s+(EST-([A-Z]+)-\d+)\s*(.*)$', l)
        if m:
            cur = (m.group(1), m.group(2), m.group(3))
            continue
        if cur and cur[1] in MODS and 'inicial no expl' in l:
            print(f, cur[0], cur[2][:90])
            cur = (cur[0], 'X', cur[2])
