from res_m0711_lib import *

PAS = {'M07': 'PA-COB-21', 'M08': 'PA-MOR-22', 'M09': 'PA-CRM-20', 'M10': 'PA-TEC-23'}


def fix(d, heading, field, ref, cat=2, newfield=None):
    k = d.row_idx(heading, field)
    cells = [c.strip() for c in d.lines[k].strip().strip('|').split(' | ')]
    old = cells[-1]
    assert 'VERIFICAR] destino' in old or 'VERIFICAR] pol' in old, (d.mod, field, old)
    if newfield:
        cells[0] = '`%s`' % newfield
    cells[-1] = '%s (%s; antes "%s")' % (ref, PAS[d.mod], old)
    d.lines[k] = '| ' + ' | '.join(cells) + ' |'
    d.count(cat)


d = Doc('M07')
fix(d, '#### 7.35.30 ', 'connectionId', '→ T06 `integrationConnections` (T05 §7.2.1)')
fix(d, '#### 7.35.40 ', 'productId', '→ M02 `serviceProducts` (T05 §7.2.1)')
fix(d, '#### 7.35.43 ', 'taxIds', '→ M06 `taxDefinitions` (T05 §7.2.1)')
d.save()

d = Doc('M08')
fix(d, '#### 7.37.4 ', 'tableId', '→ M08 `interestIndexTables`')
fix(d, '#### 7.37.4 ', 'importBatchId', '→ T04 `masterImportJobs` (importación de índices desde planilla; T05 §7.2.1)')
fix(d, '#### 7.37.8 ', 'pendingChargeId', '→ M05 `billableItems`. Nombre canónico de T05 §7.2.1 `billableItemId` (antes `pendingChargeId`)', newfield='billableItemId')
d.count(4)
fix(d, '#### 7.37.9 ', 'jobId', '→ T01 `jobRuns` (ejecución del job)')
fix(d, '#### 7.37.15 ', 'jobId', '→ T01 `jobRuns` (ejecución del job)')
fix(d, '#### 7.37.19 ', 'templateId', 'No es referencia: clave natural `code` de la fila de plataforma de la misma colección (T05 §7.2.1)')
fix(d, '#### 7.37.22 ', 'parentCaseId', '→ M08 `interruptionCases` (caso padre)')
fix(d, '#### 7.37.28 ', 'pendingChargeId', '→ M05 `billableItems`. Nombre canónico de T05 §7.2.1 `billableItemId` (antes `pendingChargeId`)', newfield='billableItemId')
d.count(4)
for k, l in enumerate(d.lines):
    if '`pendingChargeId`' in l and 'T05 §7.2.1, `pendingChargeId`' not in l and 'antes `pendingChargeId`' not in l:
        d.lines[k] = l.replace('`pendingChargeId`', '`billableItemId` (antes `pendingChargeId`)')
        d.count(4)
d.save()

d = Doc('M09')
fix(d, '#### 7.44.11 ', 'memberId', '→ M17 `associateMemberships`. Nombre canónico de T05 §7.2.1 `associateMembershipId` (antes `memberId`)', newfield='associateMembershipId')
d.count(4)
d.replace_in_line('| `memberId`, `accountId`, `contractId`, `personId` |', '| `memberId`, `accountId`, `contractId`, `personId` |',
                  '| `associateMembershipId` (antes `memberId`), `accountId`, `contractId`, `personId` |', 4)
fix(d, '#### 7.44.14 ', 'ownerUserId', '→ T02 `memberships`')
fix(d, '#### 7.44.15 ', 'providerConnectionId', '→ T06 `integrationConnections` (T05 §7.2.1)')
fix(d, '#### 7.44.33 ', 'printDocumentId', '→ T11 `documents`')
fix(d, '#### 7.44.33 ', 'labelsDocumentId', '→ T11 `documents`')
d.save()

d = Doc('M10')
fix(d, '#### 7.22.2 ', 'templateId', '→ T11 `documentTemplates` (T05 §7.2.1)')
fix(d, '#### 7.22.3 ', 'entityId', 'Polimórfica según `entityType`: → M10 `feasibilityRequests` · `workOrders` · `works` · `inspectionCases` · `networkElements`')
fix(d, '#### 7.22.6 ', 'debitAccountId', '→ M15 `ledgerAccounts` (T05 §7.2)')
fix(d, '#### 7.22.6 ', 'creditAccountId', '→ M15 `ledgerAccounts` (T05 §7.2)')
fix(d, '#### 7.22.7 ', 'serviceId', '→ M02 `tenantServices`')
fix(d, '#### 7.22.8 ', 'serviceId', '→ M02 `tenantServices`')
fix(d, '#### 7.22.32 ', 'deviceId', '→ M10 `fieldDevices` (por su `deviceId` UUID; T05 §7.2.1)')
fix(d, '#### 7.22.32 ', 'entityId', 'Polimórfica según `domain`: → M10 `workOrders` · `visits` · `workOrderMaterials` · `fieldEvidence` · `serviceConformities` · `inspectionCases` · `networkElements` (las de `reading` y `collection` se derivan a M03 y M07)')
fix(d, '#### 7.22.36 ', 'serviceIds', '→ M02 `tenantServices`')
fix(d, '#### 7.22.41 ', 'ancestorIds', '→ M10 `networkElements` (ancestros materializados)')
fix(d, '#### 7.22.43 ', 'serviceId', '→ M02 `tenantServices`')
fix(d, '#### 7.22.51 ', 'debitAccountId', '→ M15 `ledgerAccounts` (T05 §7.2)')
fix(d, '#### 7.22.51 ', 'creditAccountId', '→ M15 `ledgerAccounts` (T05 §7.2)')
fix(d, '#### 7.22.72 ', 'serviceId', '→ M02 `tenantServices`')
fix(d, '#### 7.22.75 ', 'supersedesSampleResultId', '→ M10 `waterSamples` (muestra reemplazada)')
d.save()
report()
