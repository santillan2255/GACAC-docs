import re, sys, collections
for P in sys.argv[1:]:
    raw = open(P, 'rb').read()
    t = raw.decode('utf-8')
    L = t.split('\n')
    print('==', P, 'BOM', raw.startswith(b'\xef\xbb\xbf'), 'CRLF', raw.count(b'\r\n'))
    defs = collections.defaultdict(list)
    for i, l in enumerate(L):
        m = re.match(r'\| ((?:RF|RN|PAN|API|EVT|JOB|PRM|CU|ESC|CTR|COL|P|RNF|DSH)-[A-Z0-9]+-[A-Z0-9\-]+) \|', l)
        if m:
            defs[m.group(1)].append(i + 1)
        m = re.match(r'#{2,4} ((?:PA|CU|P)-[A-Z0-9]+-\d+)\b', l)
        if m:
            defs['H:' + m.group(1)].append(i + 1)
    d = {k: v for k, v in defs.items() if len(v) > 1}
    print('IDs repetidos como fila/encabezado:', len(d), list(d.items())[:15])
    bad = []
    for i, l in enumerate(L):
        if l.startswith('|') and i > 0 and not L[i - 1].startswith('|'):
            n = len(re.findall(r'(?<!\\)\|', l))
            j = i
            while j < len(L) and L[j].startswith('|'):
                if len(re.findall(r'(?<!\\)\|', L[j])) != n:
                    bad.append((j + 1, L[j][:60]))
                j += 1
    print('filas con columnas distintas', len(bad), bad[:10])
    print('SIGUE', t.count('<!-- SIGUE -->'), 'mojibake', len(re.findall('Ã|Â|â€|\ufffd', t)))
