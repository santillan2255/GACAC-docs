import re, sys, os
sys.stdout.reconfigure(encoding='utf-8')
BASE = r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno'
f, desde, pat = sys.argv[1], sys.argv[2], sys.argv[3]
L = open(os.path.join(BASE, f), encoding='utf-8-sig').read().split('\n')
st = None
for i, l in enumerate(L):
    if st is None and re.match(desde, l):
        st = i
    if st is None:
        continue
    if l.startswith('#'):
        print(i + 1, l)
    elif re.search(pat, l):
        print(i + 1, l[:900])
