"""Mueve '(antes `x`...)' de la celda Campo a la celda Descripción (o Referencia) en tablas del §7."""
import os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from res_lib_m12m19 import Doc

ANTES = re.compile(r'\s*\((antes [^()]*(?:\([^()]*\)[^()]*)*)\)')

for name in sys.argv[1:]:
    d = Doc(name)
    ls = d.t.split('\n')
    i7 = next(i for i, l in enumerate(ls) if l.startswith('## 7.'))
    i8 = next(i for i, l in enumerate(ls) if l.startswith('## 8.'))
    header = None
    moved = 0
    for i in range(i7, i8):
        l = ls[i]
        if not l.startswith('|'):
            header = None
            continue
        cells = l.split(' | ')
        if header is None:
            h = [c.strip(' |').lower() for c in cells]
            header = h if h and h[0] == 'campo' else []
            continue
        if not header or set(l) <= set('|-: '):
            continue
        c0 = cells[0]
        m = ANTES.search(c0)
        if not m or '`' not in m.group(1):
            continue
        nota = m.group(1)
        cells[0] = c0[:m.start()] + c0[m.end():]
        tgt = None
        for k, hh in enumerate(header):
            if hh.startswith('descrip'):
                tgt = k
        if tgt is None:
            tgt = len(header) - 1
        if tgt >= len(cells):
            continue
        txt = cells[tgt]
        end = txt.endswith(' |')
        core = txt[:-2] if end else txt
        core = (nota[0].upper() + nota[1:]) + '.' + ('' if core.strip() in ('', '—') else ' ' + core)
        cells[tgt] = core + (' |' if end else '')
        ls[i] = ' | '.join(cells)
        moved += 1
    d.t = '\n'.join(ls)
    d.n = moved
    d.cats = {4: moved}
    d.save()
