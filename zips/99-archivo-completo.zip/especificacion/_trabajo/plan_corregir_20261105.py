"""Correcciones del 05-11-2026 al plan de olas (03-plan-de-olas-y-prompts.md).

Uso: python plan_corregir_20261105.py
Conserva codificacion (UTF-8 sin BOM) y saltos CRLF. Cada reemplazo exige una ocurrencia exacta.
"""
import os, re, glob, collections

ESPEC = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
PLAN = os.path.join(ESPEC, '03-plan-de-olas-y-prompts.md')

raw = open(PLAN, 'rb').read()
bom = raw.startswith(b'\xef\xbb\xbf')
txt = raw.decode('utf-8-sig')
assert '\r\n' in txt
L = txt.split('\r\n')
NOTA = 'corrección 05-11-2026'


def rep(old, new, count=1):
    global L
    t = '\r\n'.join(L)
    n = t.count(old)
    assert n == count, (n, old[:120])
    t = t.replace(old, new)
    L = t.split('\r\n')


# ---------------------------------------------------------------- 1. EXTENSIONES fuera de IMPLEMENTAR
def split_top(s):
    out, cur, d = [], '', 0
    for ch in s:
        if ch in '([':
            d += 1
        elif ch in ')]':
            d -= 1
        if ch == ';' and d == 0:
            out.append(cur)
            cur = ''
        else:
            cur += ch
    out.append(cur)
    return out


prompt_ola = None
movidos = []
nuevas = []
for i, l in enumerate(L):
    m = re.match(r'^PRO-(O\d+)-\d+ — ', l)
    if m:
        prompt_ola = m.group(1)
        prompt_id = l.split(' — ')[0]
    if not l.startswith('IMPLEMENTAR: '):
        nuevas.append(l)
        continue
    cuerpo = l[len('IMPLEMENTAR: '):]
    fin = ''
    if cuerpo.endswith('.'):
        cuerpo, fin = cuerpo[:-1], '.'
    segs = split_top(cuerpo)
    quedan, ext = [], []
    for s in segs:
        st = s.strip()
        mp = re.match(r'parte (O\d+) de ', st)
        if re.match(r'extensi[oó]n', st, re.I) or (mp and mp.group(1) != prompt_ola):
            ext.append(st)
        else:
            quedan.append(st)
    if not ext:
        nuevas.append(l)
        continue
    movidos.append((prompt_id, ext))
    if not quedan:
        quedan = ['ningún RF nuevo']
    if quedan == ['ningún RF nuevo']:
        imp = 'IMPLEMENTAR: ningún RF nuevo (%s: las extensiones pasan a la línea EXTENSIONES).' % NOTA
    else:
        imp = 'IMPLEMENTAR: ' + '; '.join(quedan) + ' (%s: las extensiones pasan a la línea EXTENSIONES y no se cuentan en este prompt).' % NOTA
    nuevas.append(imp)
    nuevas.append('EXTENSIONES: ' + '; '.join(ext) + fin)
L = nuevas

# ---------------------------------------------------------------- 2. RF-CON-160 pasa a O5 (regla §0.1)
rep('§5.16 (153..157, 159); anexos/M06-FIS-fiscal-impuestos.md RF-FIS-157;',
    '§5.16 (153..157, 159, 160); anexos/M06-FIS-fiscal-impuestos.md RF-FIS-157;')
rep('IMPLEMENTAR: RF-CON-035..040, 042..045, 048, 050..067, 092..094, 100..102, 112, 114, 115, 121, 124..126, 139..141, 153..157, 159; RF-FIS-157; RF-BIA-015, 092, 093, 095 (',
    'IMPLEMENTAR: RF-CON-035..040, 042..045, 048, 050..067, 092..094, 100..102, 112, 114, 115, 121, 124..126, 139..141, 153..157, 159; RF-FIS-157; RF-BIA-015, 092, 093, 095; además (%s): RF-CON-160 (parte O5: saldos de apertura contables como asiento de apertura importado; la celda del anexo es `O11 (O5 para saldos de apertura)` y por la regla §0.1 el RF empieza en O5; la migración repetible completa es extensión en PRO-O11-06, ver §18) (' % NOTA)
rep('IMPLEMENTAR: RF-MIG-006, 060 [REASIGNADO "por dominio", ver §18], 061, 063, 064; RF-CFG-132; RF-TAR-101, 102; RF-CON-160; RF-COB-155;',
    'IMPLEMENTAR: RF-MIG-006, 060 [REASIGNADO "por dominio", ver §18], 061, 063, 064; RF-CFG-132; RF-TAR-101, 102; RF-COB-155;')
rep('EXTENSIONES: extensiones de RF-CAT-113, RF-MOR-218, RF-STK-136, RF-COM-090.',
    'EXTENSIONES: extensiones de RF-CAT-113, RF-MOR-218, RF-STK-136, RF-COM-090; extensión O11 de RF-CON-160 (migración repetible completa de plan, rubros, ejercicios, asientos, centros, reglas y parámetros-cuenta; *reemplazado (%s):* antes RF-CON-160 se implementaba aquí; empieza en PRO-O5-11 con los saldos de apertura, ver §18).' % NOTA)
rep('ENTREGABLES: mapeos de todos los dominios; archives de solo lectura con búsqueda; saldos de apertura contables (RF-CON-160) conciliados.',
    'ENTREGABLES: mapeos de todos los dominios; archives de solo lectura con búsqueda; migración repetible contable completa (extensión de RF-CON-160, cuyos saldos de apertura se construyen en PRO-O5-11) conciliada.')

# ---------------------------------------------------------------- 3. Tablas de secuencia y totales de ola
rep('| PRO-O5-11 | Asientos manuales y automáticos, conciliaciones e informes base | 56 |',
    '| PRO-O5-11 | Asientos manuales y automáticos, conciliaciones e informes base | 57 (*reemplazado, %s:* antes 56; se agrega RF-CON-160) |' % NOTA)
rep('| PRO-O5-14 | Integración de O5: pago online imputado, rendido y asentado | 0 (verifica 468) |',
    '| PRO-O5-14 | Integración de O5: pago online imputado, rendido y asentado | 0 (verifica 469; *reemplazado, %s:* antes 468) |' % NOTA)
rep('IMPLEMENTAR: ningún RF nuevo. Verificar los 468 RF de O5 (versión 1.0: 463).',
    'IMPLEMENTAR: ningún RF nuevo. Verificar los 469 RF de O5 (versión 1.0: 463; *reemplazado, %s:* antes 468, se agrega RF-CON-160).' % NOTA)
rep('| PRO-O11-06 | Migración por dominio: históricos y equivalencias | 19 |',
    '| PRO-O11-06 | Migración por dominio: históricos y equivalencias | 18 (*reemplazado, %s:* antes 19; RF-CON-160 pasa a PRO-O5-11 y queda como extensión) |' % NOTA)
rep('| PRO-O11-10 | Ensayo de corte administrativo y cierre del plan | 0 (verifica 90 y 4.203) |',
    '| PRO-O11-10 | Ensayo de corte administrativo y cierre del plan | 0 (verifica 89 y 4.203; *reemplazado, %s:* antes 90) |' % NOTA)
rep('IMPLEMENTAR: ningún RF nuevo. Verificar los 90 RF de O11 (versión 1.0: 88) y que la matriz no tenga RF sin estado.',
    'IMPLEMENTAR: ningún RF nuevo. Verificar los 89 RF de O11 (versión 1.0: 88; *reemplazado, %s:* antes 90, RF-CON-160 pasa a O5) y que la matriz no tenga RF sin estado.' % NOTA)

# alcance por anexo O5 y O11
rep('| M15 CON | 84 | RF-CON-001..007, 009..013, 015, 017, 022, 023, 025, 027..033, 035..040, 042..045, 048, 050..067, 075, 081, 083, 084, 086, 087, 091..094, 100..102, 112, 114, 115, 121, 124..126, 139..141, 150, 151, 153..157, 159 (v1.1: se agregan RF-CON-098, 162) (v1.1: sale RF-CON-025, 075 por cambio de ola del anexo; reemplazado) |',
    '| M15 CON | 85 (*reemplazado, %s:* antes 84) | RF-CON-001..007, 009..013, 015, 017, 022, 023, 025, 027..033, 035..040, 042..045, 048, 050..067, 075, 081, 083, 084, 086, 087, 091..094, 100..102, 112, 114, 115, 121, 124..126, 139..141, 150, 151, 153..157, 159 (v1.1: se agregan RF-CON-098, 162) (v1.1: sale RF-CON-025, 075 por cambio de ola del anexo; reemplazado) (%s: se agrega RF-CON-160, parte O5 de saldos de apertura, §18) |' % (NOTA, NOTA))
rep('| **Total** | **468** | | | |',
    '| **Total** | **469** (*reemplazado, %s:* antes 468) | | | |' % NOTA)
rep('parte de RF-CON-160 (saldos de apertura, cuya implementación completa es O11).',
    'parte de RF-CON-160 (saldos de apertura, cuya implementación completa es O11). *Reemplazado (%s):* RF-CON-160 deja de ser extensión en O5: empieza aquí (PRO-O5-11, regla §0.1) y la migración repetible completa es extensión en O11.' % NOTA)
rep('| M15 CON | 2 | RF-CON-158, 160 | — | — |',
    '| M15 CON | 1 (*reemplazado, %s:* antes 2) | RF-CON-158 (antes RF-CON-158, 160; RF-CON-160 empieza en O5, §18) | — | — |' % NOTA)
rep('| **Total** | **90** | | | |',
    '| **Total** | **89** (*reemplazado, %s:* antes 90) | | | |' % NOTA)
rep('Extensiones: RF-UXD-096 (salas BI); RF-INT-023; RF-COM-090; RF-CAT-113; RF-MOR-218; RF-CON-123; RF-STK-136; RNF-NFR-016;',
    'Extensiones: RF-UXD-096 (salas BI); RF-INT-023; RF-COM-090; RF-CAT-113; RF-MOR-218; RF-CON-123; RF-CON-160 (migración repetible completa, %s); RF-STK-136; RNF-NFR-016;' % NOTA)
rep('Extensiones: RF-BIA-101; RF-CAT-008, 098; RF-TAR-049; RF-CON-065, 025, 075, 150, 151 (capital completo); RF-STK-024.',
    'Extensiones: RF-BIA-101; RF-CAT-008, 098; RF-TAR-049; RF-CON-065, 025, 075, 150, 151 (capital completo); RF-STK-024. *Reemplazado (%s):* RF-CON-025 y 075 no son extensión en O10: empiezan en O10 (PRO-O10-02), como dice el anexo M15; las extensiones de capital en O10 son RF-CON-065, 150 y 151.' % NOTA)

# ---------------------------------------------------------------- 4. Rangos de PAN, API, EVT y JOB del alcance por anexo
own = collections.defaultdict(list)
for f in glob.glob(os.path.join(ESPEC, 'anexos', '*.md')):
    b = os.path.basename(f)
    if 'T04b' in b:
        continue
    own[b.split('-')[1]].append(f)
T11 = [f for f in own['WFL']][0]


def definidos(tipo, cod):
    d = set()
    for f in own.get(cod, []):
        s = open(f, encoding='utf-8-sig').read()
        for mm in re.finditer(r'^(?:\|\s*\**|#{2,5}\s*)(' + tipo + '-' + cod + r'-(\d{2,3}))\b', s, re.M):
            d.add(int(mm.group(2)))
    fuente = ''
    if not d and tipo in ('EVT', 'JOB'):
        s = open(T11, encoding='utf-8-sig').read()
        for mm in re.finditer(r'^\|\s*\**(' + tipo + '-' + cod + r'-(\d{2,3}))\b', s, re.M):
            d.add(int(mm.group(2)))
        fuente = 'T11'
    return d, fuente


def compacta(nums):
    nums = sorted(nums)
    tramos, ini, prev = [], None, None
    for n in nums:
        if ini is None:
            ini = prev = n
        elif n == prev + 1:
            prev = n
        else:
            tramos.append((ini, prev))
            ini = prev = n
    tramos.append((ini, prev))
    return ', '.join('%02d' % a if a == b else '%02d..%02d' % (a, b) for a, b in tramos)


cambios_rango = []
inicio_alcance = [i for i, l in enumerate(L) if re.match(r'^### \d+\.4 Alcance por anexo', l)]
for i, l in enumerate(L):
    if not l.startswith('| ') or not any(a < i < a + 40 for a in inicio_alcance):
        continue

    def sub(m):
        tipo, cod, a, b = m.group(1), m.group(2), int(m.group(3)), int(m.group(4))
        d, fuente = definidos(tipo, cod)
        if not d:
            return m.group(0)
        if a == min(d) and b == max(d) and len(d) == b - a + 1:
            return m.group(0)
        nuevo = '%s-%s-%s' % (tipo, cod, compacta(d))
        cambios_rango.append((i + 1, m.group(0), nuevo, len(d), fuente))
        return '%s (*reemplazado, %s:* antes %s; %d definidos en el anexo%s)' % (
            nuevo, NOTA, m.group(0), len(d), ' y en el catálogo de T11' if fuente else '')
    L[i] = re.sub(r'\b(PAN|API|EVT|JOB)-([A-Z]{3})-(\d{2,3})\.\.(\d{2,3})\b', sub, l)

# ---------------------------------------------------------------- 5. §0.6 regla de la línea EXTENSIONES
rep('6. **Conteos.** Los conteos de RF de este plan se obtuvieron recorriendo las tablas de RF de todos los anexos. Un RF cuenta una sola vez, en la ola donde empieza.',
    '6. **Conteos.** Los conteos de RF de este plan se obtuvieron recorriendo las tablas de RF de todos los anexos. Un RF cuenta una sola vez, en la ola donde empieza. Desde la %s, cada prompt lista en `IMPLEMENTAR` solo los RF que empiezan en él y en una línea aparte `EXTENSIONES` los RF de prompts anteriores (o la parte anticipada de un RF posterior) que amplía; lo de `EXTENSIONES` no se cuenta ni lo toma `trace:check` como implementación. El recuento se hace con `_trabajo/plan_recuento.py`.' % NOTA)

open(PLAN, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + '\r\n'.join(L).encode('utf-8'))
print('prompts con extensiones movidas:', len(movidos))
for p, e in movidos:
    print(' ', p, '|', ' ;; '.join(e)[:200])
print('rangos corregidos:', len(cambios_rango))
for c in cambios_rango:
    print(' ', c)
