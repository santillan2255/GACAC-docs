import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from g_cierre_lib import Doc

d = Doc('T03-UXD-experiencia-marca-diccionario.md')

CAP = ("`por.portal.ver` y, por pestaña, la capability de T09 (`com.wall.ver` para muro y novedades, "
       "con alias `com.muro.ver` según T02 §4.4.1; `com.surveys.responder` para encuestas)")

d.rep("el destino Comunidad abre la pantalla Comunidad de M19 (PA-POR asumida), agregador de muro, encuestas y novedades; campo:",
      "el destino Comunidad abre PAN-POR-105 `/app/comunidad` de M19 (PA-POR-20; antes \"la pantalla Comunidad de M19 (PA-POR asumida)\"), agregador de muro, encuestas y novedades; empleado: Inicio · Recibos · + · Solicitudes · Perfil y registrado sin cuenta: Inicio · Contratar · + · Gestiones · Perfil, conforme a M19 §10.1 (M19 dueño del portal); campo:")

d.rep("`dict:nav.pws.comunidad` (Comunidad: pantalla Comunidad de M19 (PA-POR asumida), SM-PWS-026) | Avatar en topbar |",
      "`dict:nav.pws.comunidad` (Comunidad: PAN-POR-105 de M19, PA-POR-20, SM-PWS-026; antes \"pantalla Comunidad de M19 (PA-POR asumida)\") | Avatar en topbar |\n"
      "| Registrado sin cuenta | `dict:nav.pws.inicio` (Inicio, PAN-POR-25 en su variante registrado) | `dict:nav.pws.contratar` (Contratar, PAN-POR-31) | Según pantalla (`useCreateAction`): Contratar en Contratar; Nueva gestión en Gestiones; Vincular cuenta en Inicio | `dict:nav.pws.gestiones` (Gestiones, PAN-POR-50) | `dict:nav.pws.perfil` (Perfil, PAN-POR-59) | Slot 4 de la tabbar (M19 §10.1) |")

d.rep("| Empleado | `dict:nav.pwe.inicio` (Inicio) | `dict:nav.pwe.bandeja` (Bandeja) | Nueva tarea / publicación / aprobación según pantalla | `dict:nav.pwe.agenda` (Agenda) | `dict:nav.pwe.avisos` (Avisos) | Avatar en topbar |",
      "| Empleado | `dict:nav.pwe.inicio` (Inicio, PAN-POR-69) | `dict:nav.pwe.recibos` (Recibos, PAN-POR-70; antes `dict:nav.pwe.bandeja` (Bandeja)) | Según pantalla (`useCreateAction`): Solicitar en Vacaciones y Licencias; nueva tarea, publicación o aprobación en Bandeja y Muro | `dict:nav.pwe.solicitudes` (Solicitudes: vacaciones y licencias, PAN-POR-72 y PAN-POR-73; antes `dict:nav.pwe.agenda` (Agenda)) | `dict:nav.pwe.perfil` (Perfil, PAN-POR-59; antes `dict:nav.pwe.avisos` (Avisos)) | Slot 4 de la tabbar (M19 §10.1; antes avatar en topbar). Bandeja, Agenda y Avisos se abren desde el menú |")

d.rep("| SM-PWS-026 | Tabbar | Comunidad | `/comunidad` | `com.muro.ver` | O2 | BASE §46 NOT-002 |",
      "| SM-PWS-026 | Tabbar | Comunidad | `/comunidad` | " + CAP + " (antes `com.muro.ver`) | O2 | BASE §46 NOT-002 |")

for code, name in (("002", "Bandeja"), ("005", "Agenda"), ("006", "Avisos")):
    d.rep(f"| SM-PWE-{code} | Tabbar | {name} |",
          f"| SM-PWE-{code} | Menú (antes Tabbar; la tabbar del empleado es la de M19 §10.1) | {name} |")

d.rep("| SM-PWS-026 | Pantalla Comunidad de M19 (PA-POR asumida; PA 16: agregador de muro, encuestas y novedades; antes POR-55) | `/app/comunidad` (AL-04 sobre `/comunidad` de 10.8.2; la ruta definitiva la fija M19; antes `/app/muro`) | `com.wall.ver` |",
      "| SM-PWS-026 | POR-105 (M19, PA-POR-20: agregador de muro, encuestas y novedades; antes \"Pantalla Comunidad de M19 (PA-POR asumida)\" y, antes, POR-55) | `/app/comunidad` (ruta de M19, AL-04; antes `/app/muro`) | " + CAP + " (antes `com.wall.ver`) |")

d.rep("Excepción para las pantallas del empleado (PA 17 asumida, DEC-072): PAN-SUE-41 a PAN-SUE-46 son de M16, que define pantalla, ruta (normalizada a `/app/empleado/…`) y capability; M19 las incrusta en su shell y PAN-POR-70 a PAN-POR-74 quedan como incrustación o alias de ruta.",
      "Pantallas del empleado (PA-SUE-16 de M16; antes \"PA 17 asumida\"): PAN-SUE-41 a PAN-SUE-46 son de M16, dueño del contenido y de la capability; M19 las incrusta en su shell con PAN-POR-69 a PAN-POR-74 y publica la ruta `/app/empleado/…` (la regla general de ruta de M19 se mantiene; antes \"M16 define pantalla, ruta (normalizada a `/app/empleado/…`) y capability\").")

d.rep("dueño M16, PA 17", "dueño M16, PA-SUE-16", n=3)

d.rep("| `/app/empleado/datos` (AL-04 sobre `/empleado/datos` de M16; `/app/empleado/legajo` de POR-74 queda como alias; antes `/app/empleado/legajo`) |",
      "| `/app/empleado/legajo` (ruta de M19, PAN-POR-74, AL-04; `/empleado/datos` es la ruta de referencia de M16; antes `/app/empleado/datos`) |")

d.rep("como principales con dueño M16 y ruta `/app/empleado/…`, incrustadas por M19 (PA 17 asumida;",
      "como principales con dueño M16 (contenido y capability), incrustadas por M19 con su ruta `/app/empleado/…` (PA-SUE-16 de M16; antes \"PA 17 asumida\";")

d.save()
