import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from g_cierre_lib import Doc

d = Doc('T03-UXD-experiencia-marca-diccionario.md')

# Actores de plataforma: prefijo plt.uxd.* -> forma canónica de T02
d.rep("| Administrador de plataforma | `plt.uxd.tokens.ver`, `plt.uxd.tokens.editar`, `plt.uxd.diccionarioBase.ver`, `plt.uxd.diccionarioBase.editar`, `plt.uxd.diccionarioBase.publicar`, `plt.uxd.flags.configurar`, `plt.uxd.ayudaBase.editar`, `plt.uxd.marca.ver` (marca de cualquier tenant, solo lectura), `plt.uxd.marca.asistir` (paso de marca en el alta asistida) |",
      "| Administrador de plataforma | `uxd.plataforma.tokens.ver`, `uxd.plataforma.tokens.editar`, `uxd.plataforma.diccionarioBase.ver`, `uxd.plataforma.diccionarioBase.editar`, `uxd.plataforma.diccionarioBase.publicar`, `uxd.plataforma.flags.configurar`, `uxd.plataforma.ayudaBase.editar`, `uxd.plataforma.marca.ver` (marca de cualquier tenant, solo lectura), `uxd.plataforma.marca.asistir` (paso de marca en el alta asistida), todas con alcance `global` (antes con prefijo `plt.uxd.*`, que no es código de módulo; forma canónica `uxd.plataforma.<recurso>.<accion>` de T02 §4.4 y §4.4.1) |")
d.renames += 9

# RF-UXD-026: barra vertical escapada dentro de la celda
d.rep("`/api/public/{tenantSlug}/pwa/manifest.webmanifest?app={socio|empleado|campo}`",
      "`/api/public/{tenantSlug}/pwa/manifest.webmanifest?app={socio\\|empleado\\|campo}`")

# RF-UXD-163: ola en el formato del plan (DEC-056 adelanta el bot a O6)
d.rep("| Núcleo | O9+ (cuando haya bot) | Informado |",
      "| Núcleo | O6 (DEC-056; antes O9+ cuando haya bot) | Informado |")

# RF-UXD-066 y 10.1.4: destino Comunidad = pantalla Comunidad de M19 (PA 16)
d.rep("(socio: Inicio · Cuentas y servicios · + · Gestiones · Comunidad, con Perfil en la topbar, conforme al maestro §9.2;",
      "(socio: Inicio · Cuentas y servicios · + · Gestiones · Comunidad, con Perfil en la topbar, conforme al maestro §9.2; esta es la versión que rige para el portal y el destino Comunidad abre la pantalla Comunidad de M19 (PA-POR asumida), agregador de muro, encuestas y novedades;")
d.rep("| `dict:nav.pws.gestiones` (Gestiones) | `dict:nav.pws.comunidad` (Comunidad) | Avatar en topbar |",
      "| `dict:nav.pws.gestiones` (Gestiones) | `dict:nav.pws.comunidad` (Comunidad: pantalla Comunidad de M19 (PA-POR asumida), SM-PWS-026) | Avatar en topbar |")

# Flags: plataforma con la capability canónica
d.rep("`enabled` ↔ `disabled` por actor con `uxd.flags.configurar` (tenant) o `plt.uxd.flags.configurar` (plataforma)",
      "`enabled` ↔ `disabled` por actor con `uxd.flags.configurar` (tenant) o `uxd.plataforma.flags.configurar` (plataforma; antes `plt.uxd.flags.configurar`, T02 §4.4.1)")
d.renames += 1

# Bootstrap: referencia a API-POR-01 (dueño M19, :tenantSlug)
d.rep("2. `GET /api/public/{slug}/bootstrap?app={admin|pwa|landing}` (API-POR-01 de M19, que unifica API-UXD-01 y API-PLA-64)",
      "2. `GET /api/public/{tenantSlug}/bootstrap?app={admin|pwa|landing}` (antes `{slug}`; API-POR-01 de M19, dueño del endpoint, que unifica API-UXD-01 y API-PLA-64; el parámetro `app` queda pendiente de alta en API-POR-01)")
d.rep("| API-UXD-01 | GET | `/api/public/{slug}/bootstrap?app=` (antes `{tenantSlug}`) | Pública | **Reemplazada por API-POR-01** (M19), mismo endpoint:",
      "| API-UXD-01 | GET | `/api/public/{tenantSlug}/bootstrap?app=` (ruta de API-POR-01; antes `{slug}`) | Pública | **Referencia a API-POR-01** (dueño M19; no es un endpoint propio de T03; antes \"Reemplazada por API-POR-01\"), mismo endpoint:")

# AL-04 y AL-08
d.rep("las de M16 `/empleado/…` pasan a `/app/empleado/…` (CTR-UXD-20). |",
      "las de M16 `/empleado/…` pasan a `/app/empleado/…` (CTR-UXD-20). Excepción para las pantallas del empleado (PA 17 asumida, DEC-072): PAN-SUE-41 a PAN-SUE-46 son de M16, que define pantalla, ruta (normalizada a `/app/empleado/…`) y capability; M19 las incrusta en su shell y PAN-POR-70 a PAN-POR-74 quedan como incrustación o alias de ruta. |")
d.rep("| AL-08 Visibilidad con capability comodín | Si el anexo declara `mod.*.ver` (MOR-37, FIS-40), el ítem es visible con cualquier capability `ver` del módulo. Si declara `mod.recurso.*` (MOR-19, MOR-23, MOR-33 a MOR-35), el ítem es visible con cualquier capability de ese recurso.",
      "| AL-08 Visibilidad con capability comodín | Si el anexo declara `mod.*.ver` (FIS-40; antes también MOR-37), el ítem es visible con cualquier capability `ver` del módulo. Si declara `mod.recurso.*`, el ítem es visible con cualquier capability de ese recurso (antes MOR-19, MOR-23 y MOR-33 a MOR-35; M08 ahora declara capabilities concretas y sus ítems usan la de `ver`, AL-01).")

# PAN-MOR-19, 23, 33, 34, 35 y 37 alineadas a M08 (AL-01)
d.rep("| SM-ADM-073 | MOR-19 | `/admin/mor/tratamiento` | `mor.tratamiento.*` (AL-08; antes `mor.tratamiento.ver`) |",
      "| SM-ADM-073 | MOR-19 | `/admin/mor/tratamiento` | `mor.tratamiento.ver` (acciones con `mor.tratamiento.ejecutar`; AL-01, M08; antes `mor.tratamiento.*` por AL-08 y, antes, `mor.tratamiento.ver`) |")
d.rep("| SM-ADM-077 | MOR-23 | `/admin/mor/excepciones` | `mor.excepciones.*` (AL-08; antes `mor.excepciones.ver`) |",
      "| SM-ADM-077 | MOR-23 | `/admin/mor/excepciones` | `mor.excepciones.ver` (acciones con `mor.excepciones.editar` y `mor.excepciones.aprobar`; AL-01, M08; antes `mor.excepciones.*` por AL-08) |")
d.rep("| SM-ADM-081 | MOR-33 | `/admin/mor/garantias` | `mor.garantias.*` (AL-08; antes `mor.garantias.ver`) |",
      "| SM-ADM-081 | MOR-33 | `/admin/mor/garantias` | `mor.garantias.ver` (acciones con `mor.garantias.editar`; AL-01, M08; antes `mor.garantias.*` por AL-08) |")
d.rep("| SM-ADM-082 | MOR-35 | `/admin/mor/incobrables` | `mor.incobrables.*` (AL-08; antes `mor.incobrables.ver`) |",
      "| SM-ADM-082 | MOR-35 | `/admin/mor/incobrables` | `mor.incobrables.ver` (acciones con `mor.incobrables.proponer` y `mor.incobrables.aprobar`; AL-01, M08; antes `mor.incobrables.*` por AL-08) |")
d.rep("| SM-ADM-083 | MOR-34 | `/admin/mor/gestion-externa` | `mor.gestionExterna.*` (AL-08; antes `mor.gestionExterna.ver`) |",
      "| SM-ADM-083 | MOR-34 | `/admin/mor/gestion-externa` | `mor.gestionExterna.ver` (acciones con `mor.gestionExterna.editar` y `mor.gestionExterna.registrarAvance`; AL-01, M08; antes `mor.gestionExterna.*` por AL-08) |")
d.rep("| SM-ADM-084 | MOR-37 | `/admin/mor/informes` | `mor.*.ver` (AL-08) |",
      "| SM-ADM-084 | MOR-37 | `/admin/mor/informes` | `mor.informes.ver` (exportar con `mor.informes.exportar`; AL-01, M08; antes `mor.*.ver` por AL-08) |")

# SM-ADM-394: ruta de PAN-FAC-47 ya corregida en M05
d.rep("FAC-47 (HUE-ELE-02; M05 declara `/admin/facturacion/revision-previa`, que se acepta como alias; las acciones piden `fac.revisionPrevia.aprobar`) |",
      "FAC-47 (HUE-ELE-02; M05 declara `/admin/fac/revision-previa`, la misma ruta canónica, y conserva `/admin/facturacion/revision-previa` como ruta anterior; las acciones piden `fac.revisionPrevia.aprobar`; antes \"M05 declara `/admin/facturacion/revision-previa`, que se acepta como alias\") |")

# PWA socio: tab Comunidad (PA 16)
d.rep("| SM-PWS-026 | POR-55 (M19 declara `/app/muro(/:id)`, AL-09) | `/app/muro` | `com.wall.ver` | COM-40, COM-51 (CTR-UXD-24; antes COM-30) |",
      "| SM-PWS-026 | Pantalla Comunidad de M19 (PA-POR asumida; PA 16: agregador de muro, encuestas y novedades; antes POR-55) | `/app/comunidad` (AL-04 sobre `/comunidad` de 10.8.2; la ruta definitiva la fija M19; antes `/app/muro`) | `com.wall.ver` | POR-55 (muro, `/app/muro(/:id)`, AL-09), COM-40, COM-51 (CTR-UXD-24; antes COM-30); enlaza a novedades (SM-PWS-029) y encuestas (SM-PWS-030) |")

# PWA empleado: dueño M16, M19 incrusta (PA 17)
d.rep("| SM-PWE-013 | SUE-41 | `/app/empleado/recibos` | `sue.portal.recibos.ver` | POR-70 (CTR-UXD-23) |",
      "| SM-PWE-013 | SUE-41 (dueño M16, PA 17) | `/app/empleado/recibos` | `sue.portal.recibos.ver` | POR-70 (M19 la incrusta; CTR-UXD-23) |")
d.rep("| SM-PWE-014 | POR-71 | `/app/empleado/recibos/:id` | `sue.portal.recibos.ver` | WFL-27 (firma) |",
      "| SM-PWE-014 | SUE-41 (detalle del recibo; dueño M16, PA 17; antes POR-71) | `/app/empleado/recibos/:id` | `sue.portal.recibos.ver` (capability de M16, que M19 usa en PAN-POR-71) | POR-71 (M19 la incrusta), WFL-27 (firma) |")
d.rep("| SM-PWE-019 | Personal | Mis datos y documentos | `/app/empleado/legajo` | `sue.portal.datos.ver` | O9 | SUE-43 (POR-74; ruta de M19, AL-04; M16 declara `/empleado/datos`) |",
      "| SM-PWE-019 | Personal | Mis datos y documentos | `/app/empleado/datos` (AL-04 sobre `/empleado/datos` de M16; `/app/empleado/legajo` de POR-74 queda como alias; antes `/app/empleado/legajo`) | `sue.portal.datos.ver` | O9 | SUE-43 (dueño M16, PA 17; POR-74 la incrusta en el shell de M19; antes \"POR-74; ruta de M19, AL-04; M16 declara `/empleado/datos`\") |")

# Landing: SM-LND-014 apunta a la ruta de POR-19
d.rep("| `/turnos` redirige a `/ingresar?next=/app/turnos` | Público | relacionada (PWA socio, AL-10): POR-52 (SM-PWS-022);",
      "| `/ingresar?next=/app/turnos` (ruta de POR-19 con destino, AL-09; `/turnos` queda como alias que redirige; antes \"`/turnos` redirige a `/ingresar?next=/app/turnos`\") | Público | relacionada (PWA socio, AL-10): POR-52 (SM-PWS-022);")

# Tótem: acceso con la capability de dispositivo de M19
d.rep("| SM-DSP-001 | Tótem de autoservicio y turnos | `/totem` | Credencial de dispositivo | O5 |",
      "| SM-DSP-001 | Tótem de autoservicio y turnos | `/totem` | `por.totem.operar` (identidad del dispositivo, M19 PAN-POR-78; antes \"Credencial de dispositivo\") | O5 |")

# CTR-UXD-23: pantallas del empleado con dueño M16
d.rep("SUE-41 a SUE-43 con rutas M19,",
      "SUE-41 a SUE-46 como principales con dueño M16 y ruta `/app/empleado/…`, incrustadas por M19 (PA 17 asumida; antes \"SUE-41 a SUE-43 con rutas M19\"),")

# API-UXD-33: comodín explicitado
d.rep("| API-UXD-33 | GET/PUT/POST | `/api/platform/uxd/dictionary-keys` (+ `/publish`, `/templates`) | `plt.uxd.diccionarioBase.*` |",
      "| API-UXD-33 | GET/PUT/POST | `/api/platform/uxd/dictionary-keys` (+ `/publish`, `/templates`) | `uxd.plataforma.diccionarioBase.ver` (GET), `uxd.plataforma.diccionarioBase.editar` (PUT/POST), `uxd.plataforma.diccionarioBase.publicar` (`/publish`) (antes `plt.uxd.diccionarioBase.*`, comodín; T02 §4.4.3) |")
d.renames += 1

# CU-MAR-01: dueño T03
d.rep("| Cola vacía |\n\n## 17. Criterios de aceptación y escenarios",
      "| Cola vacía |\n\nCU-MAR-01 es de T03 (anexo dueño): rige la carga, revisión y publicación de la marca. M19 §16.1 lo cita como caso original de BASE §43 (alta de tenant con marca y landing) y solo es dueño de los pasos de landing y app del socio.\n\n## 17. Criterios de aceptación y escenarios")

# Renombres de T02 §4.4.3
ren = [
    ('cob.caja.abrir', 'cob.cajas.abrir'),
    ('tec.cdr.import', 'tec.cdr.importar'),
    ('tec.config.manage', 'tec.config.gestionar'),
    ('tec.crew.manage', 'tec.cuadrillas.gestionar'),
    ('tec.dispatch.manage', 'tec.despacho.gestionar'),
    ('tec.feasibility.read', 'tec.factibilidad.ver'),
    ('tec.fieldForm.manage', 'tec.formulariosCampo.gestionar'),
    ('tec.inspection.manage', 'tec.inspecciones.gestionar'),
    ('tec.installation.read', 'tec.instalaciones.ver'),
    ('tec.maintenance.manage', 'tec.mantenimiento.gestionar'),
    ('tec.map.read', 'tec.mapa.ver'),
    ('tec.network.manage', 'tec.redes.gestionar'),
    ('tec.networkDevice.manage', 'tec.equiposRed.gestionar'),
    ('tec.phone.plant', 'tec.telefonia.redFisica.ver'),
    ('tec.phone.numbering', 'tec.telefonia.numeracion.configurar'),
    ('tec.syncConflict.resolve', 'tec.conflictos.resolver'),
    ('tec.onCall.manage', 'tec.guardias.gestionar'),
    ('tec.waterQuality.manage', 'tec.calidadAgua.gestionar'),
    ('tec.outage.manage', 'tec.cortes.gestionar'),
    ('tec.provisioning.configure', 'tec.aprovisionamiento.configurar'),
    ('tec.report.read', 'tec.reportes.ver'),
    ('tec.schedule.manage', 'tec.agenda.gestionar'),
    ('tec.work.manage', 'tec.obras.gestionar'),
    ('tec.workOrder.create', 'tec.ordenes.crear'),
    ('tec.workOrder.read', 'tec.ordenes.ver'),
    ('tec.workOrder.update', 'tec.ordenes.editar'),
    ('plt.uxd.tokens.ver', 'uxd.plataforma.tokens.ver'),
    ('plt.uxd.diccionarioBase.ver', 'uxd.plataforma.diccionarioBase.ver'),
    ('plt.uxd.diccionarioBase.editar', 'uxd.plataforma.diccionarioBase.editar'),
    ('plt.uxd.flags.configurar', 'uxd.plataforma.flags.configurar'),
    ('plt.uxd.marca.ver', 'uxd.plataforma.marca.ver'),
    ('plt.uxd.marca.asistir', 'uxd.plataforma.marca.asistir'),
]
for o, n in ren:
    k = d.rename(o, n)
    print('  ', o, k)
d.save()
