# Inconsistencias de la especificación detectadas al redactar los entregables

Pendientes de corregir en los anexos (no se tocaron durante la redacción de `docs/entregables-analisis-diseno/`).

## Desde 02-arquitectura-c4 (deuda técnica §11)
1. Colas BullMQ: T01 y T08 no coinciden.
2. Endpoints de health definidos de forma distinta entre anexos.
3. Ambientes: T01 define 7 (incluye `dev` y `sandbox`); RNF-NFR-170 enumera 5.
4. Colección `users` de T01 no coincide con la maestra.
5. Se menciona Leaflet; DEC-046 elige Google Maps.
6. Se nombra Twilio; PA-INT-06 (proveedor SMS) sigue abierta.
7. Tests: se nombran Vitest y `node --test`.
8. Nombres de eventos con guiones, contra la convención `<mod>.<entidad>.<pasado>`.
9. DEC-062 cita DEC-008 en lugar de DEC-004.
10. Workers de PDF sin imagen ni cola asignadas.

## Desde 07-estrategia-pruebas / 08-plan-puesta-en-marcha
11. Montos del primer comprobante del piloto: ESC-SRV-INT-01 (25.000 / 30.000 / 10 % / 60.000) vs ESC-TAR-03 (15.000 / 20.000 / 50 % / 30.000); HUE-SRV-05 unificó M02, M04, M19 pero T12 parte 1 conserva los anteriores.
12. Datos ficticios: T08 usa `isFictitious` y `@ejemplo.test`; el plan 03 usa `isDemo` y `@example.com`.
13. T07 §9.6 remite a "§17.6" para el criterio de aprobación del paralelo; está en §17.4.
14. Plan 03 §9.8 describe ESC-SRV-INT-02/03 como "pago online y presencial"; en T12 son falla de aprovisionamiento y reconexión tras pago.
15. Sueldos en la etapa E3: DEC-068 y T07 §9.7 no coinciden.

## Desde 05-wireframes
16. Ruta de vinculación: M01 `/app/vincular` vs T03/M19 `/app/cuentas/vincular`.
17. T03 pide `por.gestiones.crear` también para ver el listado de gestiones.
