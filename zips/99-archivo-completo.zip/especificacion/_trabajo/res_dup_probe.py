import re, glob
for f in sorted(glob.glob(r'..\anexos\T*.md')):
    t = open(f, encoding='utf-8-sig').read()
    ls = t.split('\n')
    for i, l in enumerate(ls):
        m = re.match(r'\*\*`(\w+)`\*\* — .*definición en texto en §([\d.]+)\)', l)
        if not m:
            continue
        coll, sec = m.groups()
        # localizar la subsección original
        start = None
        for j, h in enumerate(ls):
            if re.match(r'#{2,4} %s\b' % re.escape(sec), h) or re.match(r'#{2,4} %s ' % re.escape(sec), h):
                start = j
                break
        if start is None:
            continue
        end = start + 1
        while end < len(ls) and not re.match(r'#{2,4} ', ls[end]):
            end += 1
        cur = None
        hits = []
        for k in range(start, end):
            s = ls[k]
            if ('`%s`' % coll) in s and not s.startswith('|'):
                cur = k
            if s.startswith('| Campo') and cur is not None and ('`%s`' % coll) in ls[cur] and k - cur < 6:
                hits.append(k + 1)
        if hits:
            print(f[-45:], coll, sec, 'tabla previa en líneas', hits, '| generada en', i + 1)
