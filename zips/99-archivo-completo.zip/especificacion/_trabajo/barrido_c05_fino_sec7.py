# -*- coding: utf-8 -*-
"""C-05 fino: tipos SQL en bloque ## 7.* (preserva tablas stack histórico T01/T05)."""
from __future__ import annotations

import re
from pathlib import Path

ESPEC = Path(__file__).resolve().parents[1]
ANEXOS = ESPEC / "anexos"

H2_7_START = re.compile(r"^## 7[\.\s]", re.M)
H2_71_START = re.compile(r"^## 7\.1\b", re.M)
H2_NEXT_MAJOR = re.compile(r"^## (8\.|[1-9]\d*\.|1[89]\.)", re.M)

NOTE_SNIP = "Las tablas y tipos que citan MongoDB"
NOTE_NEW = (
    "> **Barrido C-05 (DEC-111).** En las tablas de este capítulo los tipos objetivo son **Azure SQL** "
    "(columnas `uniqueidentifier`, `DECIMAL`, `DATETIME2`, etc.; ver `07-ddl`). Menciones puntuales de "
    "Mongo/Mongoose/BullMQ sin tipo de columna = **comparativa histórica** Connectia, sin efecto en build."
)

TYPE_ONLY = [
    (re.compile(r"\bDecimal128\b"), "DECIMAL(18,4)"),
    (re.compile(r"\bObjectId\b"), "uniqueidentifier"),
    (re.compile(r"`tenantId`"), "`TenantId`"),
    (re.compile(r"\btenantId\b(?=\s*\(uniqueidentifier)"), "TenantId"),
    (re.compile(r"\|\s*_id\s*\|"), "| Id |"),
]

STACK_WORDS = [
    (re.compile(r"\bMongoose\b"), "EF Core"),
    (re.compile(r"\bBullMQ\b"), "Azure Queue Storage"),
    (re.compile(r"\bMongoDB 7\b"), "Azure SQL"),
    (re.compile(r"\breplica set\b", re.I), "base compartida multitenant"),
]

HISTORIC_LINE = re.compile(
    r"histórico|Histórico|Connectia|DEC-001|\|\s*Node\s|Vue 3|Express|CNX §|§7\.0|7\.1\. Stack",
    re.I,
)


def ensure_t12_header(content: str) -> str:
    if "## 7. Datos y referencias (T12)" in content:
        return content
    m = H2_71_START.search(content)
    if not m:
        return content
    insert = (
        "## 7. Datos y referencias (T12)\n\n"
        "> **Barrido C-05 (DEC-111).** T12 no es dueño de colecciones; el modelo físico vive "
        "en los anexos de servicio (M02, M04, M05, …) y en `07-*`.\n\n"
    )
    return content[: m.start()] + insert + content[m.start() :]


def section7_span(content: str) -> tuple[int, int] | None:
    m = H2_7_START.search(content)
    if not m:
        return None
    start = m.start()
    rest = content[m.end() :]
    m_end = H2_NEXT_MAJOR.search(rest)
    end = m.end() + (m_end.start() if m_end else len(rest))
    return start, end


def transform_line(line: str, allow_stack: bool) -> str:
    for pat, repl in TYPE_ONLY:
        line = pat.sub(repl, line)
    if allow_stack and not HISTORIC_LINE.search(line):
        for pat, repl in STACK_WORDS:
            line = pat.sub(repl, line)
        if "Azure SQL" not in line:
            line = re.sub(r"\bMongoDB\b", "Azure SQL", line)
    return line


def fino_block(block: str, prefix: str) -> str:
    if NOTE_SNIP in block:
        idx = block.find("> **Barrido C-05")
        if idx >= 0:
            endq = block.find("\n\n", idx)
            if endq > idx:
                block = block[:idx] + NOTE_NEW + block[endq:]
    allow_stack = prefix not in ("T01", "T05")
    lines = block.splitlines(keepends=True)
    return "".join(transform_line(ln, allow_stack) for ln in lines)


def main() -> None:
    changed = 0
    for path in sorted(ANEXOS.glob("*.md")):
        if "backup" in path.name.lower():
            continue
        raw = path.read_text(encoding="utf-8")
        pre = re.match(r"^(M\d+|T\d+)", path.name)
        prefix = pre.group(1) if pre else ""
        if path.name.startswith("T12"):
            new_raw = ensure_t12_header(raw)
            if new_raw != raw:
                raw = new_raw
        span = section7_span(raw)
        if span is None:
            if raw != path.read_text(encoding="utf-8"):
                path.write_text(raw, encoding="utf-8", newline="\n")
                changed += 1
            continue
        start, end = span
        new_block = fino_block(raw[start:end], prefix)
        new_raw = raw[:start] + new_block + raw[end:]
        if new_raw != raw:
            path.write_text(new_raw, encoding="utf-8", newline="\n")
            changed += 1
            print(path.name)
    print(f"Done. {changed} files.")


if __name__ == "__main__":
    main()