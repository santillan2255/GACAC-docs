#!/usr/bin/env python3
"""Auditoría C-10: residuos stack pre-GoodApps en entregables-analisis-diseno."""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import date
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
ENT = REPO / "docs" / "entregables-analisis-diseno"
OUT = REPO / "docs" / "especificacion" / "13-auditoria-impacto-entregables.md"

PATTERNS = {
    "mongo": re.compile(r"\b(MongoDB|Mongoose|ObjectId|replica set|BullMQ)\b", re.I),
    "node_vue": re.compile(r"\b(Node\.js|Express\b|Vue 3|Pinia)\b", re.I),
    "dec001": re.compile(r"\bDEC-001\b", re.I),
    "azure_ok": re.compile(r"Azure SQL", re.I),
}

NORM_MARKERS = (
    "Norma de implementación (impacto stack",
    "Norma stack CoopApps (C-10",
    "Norma stack en casos de prueba (C-10",
    "C-10 — Cierre de alineación stack",
)


def iter_md() -> list[Path]:
    return sorted(
        p for p in ENT.rglob("*.md") if "_descartados" not in p.parts and "OLD" not in p.parts
    )


def main() -> None:
    hits: dict[str, list[tuple[str, int, str]]] = defaultdict(list)
    files = iter_md()
    with_norm = 0
    azure_files: list[str] = []

    for path in files:
        rel = path.relative_to(REPO).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        if any(m in text for m in NORM_MARKERS):
            with_norm += 1
        if PATTERNS["azure_ok"].search(text):
            azure_files.append(rel)
        for i, line in enumerate(text.splitlines(), 1):
            for key in ("mongo", "node_vue", "dec001"):
                if PATTERNS[key].search(line):
                    hits[key].append((rel, i, line.strip()[:100]))

    today = date.today().strftime("%d-%m-%Y")
    lines = [
        "# 13b — Auditoría impacto stack — entregables (C-10)",
        "",
        f"Generado **{today}** por `_trabajo/audit_entregables_stack.py`.",
        f"Carpeta: `docs/entregables-analisis-diseno/` ({len(files)} archivos `.md`).",
        "",
        "## Resumen",
        "",
        "| Métrica | Valor |",
        "|---|---|",
        f"| Archivos revisados | {len(files)} |",
        f"| Con norma impacto en texto | {with_norm} (índice, OpenAPI, pruebas, C4, STRIDE, CP maestro; ver §12.3 en `06`) |",
        f"| Mencionan Azure SQL | {len(azure_files)} |",
        f"| Líneas Mongo (revisar) | {len(hits['mongo'])} |",
        f"| Líneas Node/Vue (revisar) | {len(hits['node_vue'])} |",
        f"| Líneas DEC-001 (revisar) | {len(hits['dec001'])} |",
        "",
        "### Interpretación (C-10)",
        "",
        "- **C-10 cerrado (19-11-2026):** política §12.3 + `entregables/00-C10-CIERRE-STACK.md`; norma en índice, OpenAPI, C4, pruebas, ER índice.",
        "- Las métricas Mongo/Node abajo son **residuos históricos inventariados** (CP, diagramas ER, figuras C4); no bloquean export ni contradicen DEC-111.",
        "- Barrido de wording CP/C4 por ola = mejora opcional; C-05 aplica a **anexos** `docs/especificacion/`.",
        "",
    ]
    for key, title in (
        ("mongo", "Mongo / Mongoose / ObjectId"),
        ("node_vue", "Node / Vue"),
        ("dec001", "DEC-001 citada"),
    ):
        lines.append(f"## {title} ({len(hits[key])} líneas)")
        lines.append("")
        if not hits[key]:
            lines.append("_Ninguna._")
        else:
            for rel, ln, snip in hits[key][:80]:
                lines.append(f"- `{rel}` L{ln}: {snip}")
            if len(hits[key]) > 80:
                lines.append(f"- _… y {len(hits[key]) - 80} más._")
        lines.append("")

    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()