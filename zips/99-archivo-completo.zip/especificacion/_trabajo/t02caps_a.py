"""Relevamiento de capabilities usadas en API y PAN que faltan en T02 §4.4 (solo lectura)."""
import sys, os, re, json
from collections import defaultdict, Counter
sys.stdout.reconfigure(encoding='utf-8')
AQUI = os.path.dirname(os.path.abspath(__file__))
TRAB = os.path.normpath(os.path.join(AQUI, '..', '..', 'entregables-analisis-diseno', '_trabajo'))
sys.path.insert(0, TRAB)
import contratos_lib as cl

caps_t02, alias_t02 = cl.leer_capabilities_t02()


def caps_de_celda(celda):
    caps, prev = [], None
    for b in cl.backticks(celda):
        b = b.strip()
        if b.startswith('.') and prev:
            b = prev.rsplit('.', 1)[0] + b
        if re.fullmatch(r'[a-z][A-Za-z0-9]*(\.[A-Za-z0-9*<>]+)+', b) or re.fullmatch(r'[a-z]+:[a-z]+', b):
            caps.append(b)
            prev = b
    return caps


usos = defaultdict(lambda: dict(api=[], pan=[]))
for f in cl.leer_apis():
    for c in caps_de_celda(f['capability'] or ''):
        usos[c]['api'].append(dict(id=f['id'], anexo=f['anexo'], metodo=f['metodo'], ruta=cl.sin_md(f['ruta'] or ''),
                                   desc=cl.sin_md(f['descripcion'] or '')))

pan = json.load(open(os.path.join(TRAB, 'pan_catalogo.json'), encoding='utf-8'))
for p in pan['paneles']:
    cs = set(p.get('caps_anexo') or [])
    for k in ('cap', 'cap_anexo', 'cap_t03'):
        if p.get(k):
            cs.add(p[k])
    for c in cs:
        for b in caps_de_celda('`%s`' % c.strip('`')):
            usos[b]['pan'].append(dict(id=p['id'], anexo=p['anexo'][:3], nombre=p.get('nombre', ''),
                                       ruta=p.get('ruta', ''), portal=p.get('portal', [])))

falt = {c: u for c, u in usos.items() if c not in caps_t02 and c not in alias_t02}
print('usadas', len(usos), 'faltantes', len(falt),
      'solo api', sum(1 for u in falt.values() if u['api'] and not u['pan']),
      'solo pan', sum(1 for u in falt.values() if u['pan'] and not u['api']))
print('filas API con faltantes', len({a['id'] for u in falt.values() for a in u['api']}))
pref = Counter(c.split('.')[0].split(':')[0] for c in falt)
print(pref.most_common())
json.dump(dict(faltantes=falt, caps_t02=sorted(caps_t02), alias=alias_t02),
          open(os.path.join(AQUI, 't02caps_a.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
