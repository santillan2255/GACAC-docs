# Borradores ScreenHelp — núcleo M01 + T02 (export GoodApps)

Formato T03: **qué / quién / cuándo / dónde / por qué / cómo** + **CU**. Volcar a `screenHelpArticles` con `screenId` = PAN-*.

Inventario: `inventario-screenhelp-m01-t02.md`. Estado export: **Borrador núcleo** (revisión copy `dict:` pendiente).

---

## M01 PER

### PAN-PER-01 — Búsqueda de titulares y cuentas
- **Qué:** Búsqueda unificada de titulares y cuentas.
- **Quién:** `per.titulares.ver`.
- **Cuándo:** Antes de abrir ficha, facturar o transferir.
- **Dónde:** Socios y cuentas → Titulares.
- **Por qué:** Acceso rápido sin duplicar personas (CU-03).
- **Cómo:** Filtros por documento, nombre, número; Enter abre el primero.
- **CU:** CU-03; CU-TIT-01

### PAN-PER-02 — Ficha 360 del titular
- **Qué:** Vista integral titular, cuentas, contratos y alertas.
- **Quién:** `per.titulares.ver` (+ permisos por pestaña).
- **Cuándo:** Atención, cobranza, trámites, auditoría de cliente.
- **Dónde:** Desde búsqueda o menú Titulares.
- **Por qué:** Un solo punto para todo lo del titular (BASE §3).
- **Cómo:** Use pestañas; acciones en cabecera según permiso.
- **CU:** CU-PER-01..05; CU-04

### PAN-PER-03 — Personas
- **Qué:** Lista y ficha de personas físicas/jurídicas.
- **Quién:** `per.personas.ver`.
- **Cuándo:** Alta, corrección, fusión, privacidad, documento pendiente.
- **Dónde:** Socios y cuentas → Personas.
- **Por qué:** Identidad única por tenant (CU-03).
- **Cómo:** Filtro «documento pendiente» para migración; fusionar desde duplicados.
- **CU:** CU-03; CU-PER-06; CU-PER-13

### PAN-PER-04 — Alta y edición de persona
- **Qué:** Alta/édición con anti-duplicado y verificación.
- **Quién:** `per.personas.crear` / `editar`; modo embebido desde otros módulos.
- **Cuándo:** Nuevo titular, proveedor, empleado o socio.
- **Dónde:** Modal desde PER u otros maestros (DEC-097).
- **Por qué:** Una persona, muchos roles (AGR-006).
- **Cómo:** Revise candidatos antes de crear; ARCA si aplica.
- **CU:** CU-03; CU-REG-01 (M19)

### PAN-PER-05 — Cuenta
- **Qué:** Ficha de cuenta de servicios del titular.
- **Quién:** `per.cuentas.ver`.
- **Cuándo:** Configurar postal, fiscal, grupos y contratos.
- **Dónde:** Desde ficha titular o ruta directa.
- **Por qué:** SUMSOC normalizado (ProCoop).
- **Cómo:** Revise cuenta principal, entrega de factura y árbol contratos.
- **CU:** CU-04; CU-TIT-01

### PAN-PER-06 — Editor de domicilio
- **Qué:** Domicilio normalizado con mapa y geocodificación.
- **Quién:** Capability de edición de la entidad dueña.
- **Cuándo:** Alta persona/cuenta/inmueble o corrección.
- **Dónde:** Modal embebido en formularios PER.
- **Por qué:** Un domicilio reutilizable (CU-GEO-01).
- **Cómo:** Catálogo T04 + confirmar pin en mapa si aplica.
- **CU:** CU-GEO-01

### PAN-PER-07 — Inmuebles
- **Qué:** Catastro, unidades funcionales y relaciones.
- **Quién:** `per.inmuebles.ver`.
- **Cuándo:** Contratos en PH, obras, propiedad horizontal.
- **Dónde:** Socios y cuentas → Inmuebles.
- **Por qué:** PROPIEDA sin duplicar persona.
- **Cómo:** Filtros por nomenclatura/partida; contratos desde M02.
- **CU:** CU-PER-10

### PAN-PER-08 — Puntos de prestación
- **Qué:** Lista y ficha de puntos donde se presta el servicio.
- **Quién:** `per.puntosPrestacion.ver`.
- **Cuándo:** Alta de contrato, obra o cambio de ubicación física.
- **Dónde:** Socios y cuentas → Puntos de prestación.
- **Por qué:** Ubicación del servicio separada del inmueble (CU-04).
- **Cómo:** Vincule inmueble o domicilio; valide en mapa si aplica.
- **CU:** CU-04

### PAN-PER-09 — Relaciones y representaciones
- **Qué:** Vínculos legales y comerciales entre personas.
- **Quién:** `per.relaciones.ver` / `crear`.
- **Cuándo:** Garantes, apoderados, representantes.
- **Dónde:** Pestaña en ficha persona/titular.
- **Por qué:** Quién puede actuar por el titular (CU-PER-04, CU-PER-05).
- **Cómo:** Elija tipo de vínculo y vigencia; adjunte constancia si exige RN.
- **CU:** CU-PER-04; CU-PER-05

### PAN-PER-10 — Adherentes y beneficiarios
- **Qué:** Vista de adherentes del contrato (solo lectura en PER).
- **Quién:** `soc.adherentes.ver`.
- **Cuándo:** Consulta desde ficha de cuenta/contrato.
- **Dónde:** Pestaña contrato en ficha titular.
- **Por qué:** El alta/baja se gestiona en servicios sociales (M18).
- **Cómo:** Use el enlace a la pantalla de gestión para modificar.
- **CU:** CU-04

### PAN-PER-11 — Notas
- **Qué:** Notas operativas sobre titular, cuenta o persona.
- **Quién:** `per.notas.ver` / `crear`.
- **Cuándo:** Observaciones para caja, facturación o técnica.
- **Dónde:** Pestaña Notas en ficha.
- **Por qué:** Avisos visibles sin alterar datos maestros.
- **Cómo:** Indique alcance y fecha de vigencia si aplica.
- **CU:** CU-04

### PAN-PER-12 — Bloqueos
- **Qué:** Bloqueos de cobro o mensajes en ventanilla.
- **Quién:** `per.bloqueos.ver` / `aplicar` / `levantar`.
- **Cuándo:** Mora, fraude, acuerdo interno o decisión judicial.
- **Dónde:** Pestaña Bloqueos.
- **Por qué:** Impide cobros indebidos (CU-PER-07).
- **Cómo:** Motivo obligatorio; revise impacto en caja al levantar.
- **CU:** CU-PER-07

### PAN-PER-13 — Documentación y requisitos
- **Qué:** Trámites, documentos solicitados y validación.
- **Quién:** `per.documentacion.ver` / `registrar` / `validar`.
- **Cuándo:** Alta de servicio, transferencia, reclamo.
- **Dónde:** Pestaña o menú Documentación.
- **Por qué:** Checklist antes de operaciones sensibles.
- **Cómo:** Cargue escaneo y marque estado validado/rechazado.
- **CU:** CU-PER-11; CU-TIT-01

### PAN-PER-14 — Asistente de transferencia
- **Qué:** Wizard de transferencia de titularidad/cuenta.
- **Quién:** `per.transferencias.crear`.
- **Cuándo:** Venta, sucesión, mudanza, cambio responsable pago.
- **Dónde:** Transferencias → Nueva.
- **Por qué:** Historial conservado (BASE §4).
- **Cómo:** Simulación antes de confirmar; adjunte documentación.
- **CU:** CU-PER-11; CU-TIT-01

### PAN-PER-15 — Transferencias (detalle/lista)
- **Qué:** Seguimiento de transferencias iniciadas.
- **Quién:** `per.transferencias.ver`.
- **Cuándo:** Auditoría o reverso autorizado.
- **Dónde:** Socios y cuentas → Transferencias.
- **Por qué:** Trazabilidad de cambios de titular.
- **Cómo:** Revise pasos y constancia; revertir solo con permiso.
- **CU:** CU-PER-11

### PAN-PER-16 — Registrar fallecimiento
- **Qué:** Registro de fallecimiento con evidencia.
- **Quién:** `per.personas.registrarFallecimiento`.
- **Cuándo:** Comunicación de fallecimiento de titular.
- **Dónde:** Acción en ficha titular.
- **Por qué:** Efectos en contratos y cobranza (CU-PER-03).
- **Cómo:** Adjunte acta/evidencia; revise bloqueos automáticos.
- **CU:** CU-PER-03

### PAN-PER-17 — Baja y reactivación de titular
- **Qué:** Baja o reactivación de titular comercial.
- **Quién:** `per.titulares.baja` / `reactivar`.
- **Cuándo:** Cierre comercial del vínculo.
- **Dónde:** Ficha titular → más acciones.
- **Por qué:** Estado distinto de persona y de socio (M17).
- **Cómo:** Indique causa; conserve número si política lo permite.
- **CU:** CU-PER-12

### PAN-PER-18 — Duplicados y fusión
- **Qué:** Bandeja de posibles duplicados y fusión.
- **Quién:** `per.duplicados.ver`, `per.personas.unificar`.
- **Cuándo:** Alertas de coincidencia o migración.
- **Dónde:** Socios y cuentas → Duplicados.
- **Por qué:** Una persona por tenant (CU-PER-06).
- **Cómo:** Compare y decida fusionar o descartar caso.
- **CU:** CU-PER-06

### PAN-PER-19 — Historial
- **Qué:** Línea de tiempo de cambios en persona, titular o cuenta.
- **Quién:** `per.historial.ver`.
- **Cuándo:** Auditoría, disputa o consulta de estado anterior.
- **Dónde:** Pestaña Historia o comparador modal.
- **Por qué:** Explicar qué cambió y cuándo (GOB).
- **Cómo:** Filtre por entidad y período; compare versiones lado a lado.
- **CU:** CU-GOB-01

### PAN-PER-20 — Padrón de titulares
- **Qué:** Informe parametrizable del padrón de titulares.
- **Quién:** `per.padron.ver` / `exportar`.
- **Cuándo:** Secretaría, regulatorio o campañas.
- **Dónde:** Socios y cuentas → Padrón.
- **Por qué:** Reemplaza listados ProCoop con columnas guardadas.
- **Cómo:** Configure filtros y columnas; exporte a Excel si tiene permiso.
- **CU:** CU-04

### PAN-PER-21 — Operaciones especiales
- **Qué:** Cambios excepcionales con aprobación (no borrado directo).
- **Quién:** `per.operacionesEspeciales.ejecutar`.
- **Cuándo:** Corrección masiva o caso autorizado por directorio.
- **Dónde:** Socios y cuentas → Operaciones especiales.
- **Por qué:** Sustituye módulos especiales ProCoop con traza.
- **Cómo:** Complete formulario; espere autorización si la política lo exige.
- **CU:** CU-PER-11

### PAN-PER-22 — Configuración del módulo
- **Qué:** Maestros auxiliares de personas y titulares.
- **Quién:** `per.configuracion.configurar`.
- **Cuándo:** Parametrización inicial o cambio normativo.
- **Dónde:** Configuración → Socios y cuentas.
- **Por qué:** Catálogos que gobiernan formularios del módulo.
- **Cómo:** Publique cambios vía motor T04 cuando corresponda.
- **CU:** CU-04

### PAN-PER-23 — Privacidad y derechos
- **Qué:** Bandeja Ley 25.326 (acceso, rectificación, supresión).
- **Quién:** `per.privacidad.gestionar`.
- **Cuándo:** Solicitud del titular o auditoría.
- **Dónde:** Cumplimiento → Privacidad PER.
- **Por qué:** Derechos del titular (T08).
- **Cómo:** Vincule persona y plazo; no exportar datos sensibles sin permiso.
- **CU:** CU-PER-13

### PAN-PER-24 — Importación
- **Qué:** Carga masiva desde Excel con validación por fila.
- **Quién:** `per.importaciones.crear`.
- **Cuándo:** Migración auxiliar o actualización masiva acotada.
- **Dónde:** Socios y cuentas → Importar.
- **Por qué:** Reduce carga manual con preview de errores.
- **Cómo:** Descargue plantilla; corrija filas rechazadas antes de confirmar.
- **CU:** CU-03

### PAN-PER-25 — PWA Mis datos
- **Qué:** El socio consulta y actualiza sus datos de contacto.
- **Quién:** `per.me.ver` / `editarContactos`.
- **Cuándo:** Autogestión desde la app.
- **Dónde:** App → Mis datos.
- **Por qué:** Menos llamados por datos desactualizados (M19).
- **Cómo:** Cambios sensibles pueden requerir verificación.
- **CU:** CU-REG-01 (M19)

### PAN-PER-26 — PWA Vincular cuenta
- **Qué:** El socio vincula su usuario a una cuenta de suministro.
- **Quién:** `per.me.vincular`.
- **Cuándo:** Primer ingreso o nueva cuenta en el hogar.
- **Dónde:** App → Vincular cuenta.
- **Por qué:** Acceso a facturas y pagos propios (T02).
- **Cómo:** Pruebe identidad con dato de factura o código enviado.
- **CU:** CU-REG-01 (M19)

### PAN-PER-27 — PWA Autorizados
- **Qué:** El titular gestiona quién puede ver o pagar por él.
- **Quién:** `per.me.autorizados.gestionar`.
- **Cuándo:** Familiar autorizado a pagar o consultar.
- **Dónde:** App → Autorizados.
- **Por qué:** CU-PER-05 sin pasar por caja.
- **Cómo:** Defina alcance view/pay y vigencia; puede revocar en cualquier momento.
- **CU:** CU-PER-05

### PAN-PER-28 — Mapa de domicilios y puntos
- **Qué:** Mapa con capas de domicilios y puntos de prestación.
- **Quién:** `per.puntosPrestacion.ver`.
- **Cuándo:** Planificación, campo o atención territorial.
- **Dónde:** Socios y cuentas → Mapa.
- **Por qué:** Vista geográfica del padrón (CU-GEO-01).
- **Cómo:** Active capas y haga zoom; enlace a ficha desde marcador.
- **CU:** CU-GEO-01

---

## T02 IAM

### PAN-IAM-01 — Login staff
- **Qué:** Pre-login por cooperativa e ingreso staff.
- **Quién:** Público hasta autenticar.
- **Cuándo:** Inicio de jornada.
- **Dónde:** `/login`.
- **Por qué:** Tenant explícito y MFA (CU-IAM-11).
- **Cómo:** Código de cooperativa si no hay subdominio; ayuda de formato bajo campos.
- **CU:** CU-IAM-11; CU-29

### PAN-IAM-02 — Login socio
- **Qué:** Ingreso portal/PWA del socio.
- **Quién:** Público / visitante registrado.
- **Cuándo:** Autogestión.
- **Dónde:** Landing o PWA login.
- **Por qué:** Canal digital (M19).
- **Cómo:** DNI/CUIT sin puntos; Google/CiDi si habilitados.
- **CU:** CU-REG-01 (M19)

### PAN-IAM-03 — MFA
- **Qué:** Segundo factor en login o step-up.
- **Quién:** Usuario en flujo de autenticación.
- **Cuándo:** Política MFA o acción sensible.
- **Dónde:** `/login/mfa`.
- **Por qué:** ASVS / DEC políticas seguridad.
- **Cómo:** TOTP, recuperación o dispositivo confiable según política.
- **CU:** CU-IAM-11

### PAN-IAM-04 — Selección de ámbito
- **Qué:** Elegir cooperativa, contexto y sucursal/PV/caja.
- **Quién:** Sesión autenticada multi-ámbito.
- **Cuándo:** Tras login o cambio de contexto.
- **Dónde:** Selector en login o topbar.
- **Por qué:** Una identidad, varias pertenencias (CU-IAM-01).
- **Cómo:** Confirme antes de cambiar si hay cambios sin guardar.
- **CU:** CU-IAM-01; CU-IAM-02

### PAN-IAM-05 — Recuperar contraseña
- **Qué:** Solicitar y completar restablecimiento de contraseña.
- **Quién:** Público con correo o canal habilitado.
- **Cuándo:** Olvido de clave o rotación forzada.
- **Dónde:** «Olvidé mi contraseña» en login.
- **Por qué:** Autoservicio sin mesa de ayuda.
- **Cómo:** La respuesta es genérica aunque el mail no exista; cumpla política al elegir clave nueva.
- **CU:** CU-IAM-11

### PAN-IAM-06 — Invitación y verificación
- **Qué:** Aceptar invitación de usuario o verificar correo.
- **Quién:** Token público de un solo uso.
- **Cuándo:** Alta de staff invitado.
- **Dónde:** Enlace del correo de invitación.
- **Por qué:** Identidad creada sin contraseña compartida.
- **Cómo:** Cree contraseña y complete MFA si el rol lo exige.
- **CU:** CU-29

### PAN-IAM-07 — Mi seguridad
- **Qué:** Autogestión de factores, sesiones y cuentas vinculadas.
- **Quién:** `iam.miCuenta.gestionar`.
- **Cuándo:** Cambio de dispositivo o endurecimiento personal.
- **Dónde:** Perfil → Seguridad.
- **Por qué:** El usuario controla su superficie de ataque.
- **Cómo:** Regenerar recuperación requiere step-up.
- **CU:** CU-IAM-11

### PAN-IAM-08 — Bloqueo por inactividad
- **Qué:** Desbloqueo tras tiempo sin actividad.
- **Quién:** Sesión staff activa bloqueada.
- **Cuándo:** Política de inactividad de la cooperativa.
- **Dónde:** Overlay en pantalla actual.
- **Por qué:** Protege terminal compartida en caja.
- **Cómo:** Ingrese contraseña o factor; o cambie de usuario.
- **CU:** CU-IAM-11

### PAN-IAM-09 — Usuarios staff
- **Qué:** ABM e invitación de usuarios internos.
- **Quién:** `iam.usuarios.ver` (+ invitar según rol).
- **Cuándo:** Alta cooperativa, rotaciones, auditoría MFA.
- **Dónde:** IAM → Usuarios.
- **Por qué:** Mínimo privilegio y trazabilidad.
- **Cómo:** Invitar → asignar rol y perfil → verificar MFA.
- **CU:** CU-29; CU-GOB-01

### PAN-IAM-10 — Ficha de usuario
- **Qué:** Roles, perfiles, permisos efectivos y sesiones.
- **Quién:** `iam.usuarios.ver`.
- **Cuándo:** Diagnóstico de acceso o recertificación.
- **Dónde:** Desde lista usuarios.
- **Por qué:** Explicar por qué algo está habilitado (AGR-008).
- **Cómo:** Pestaña Permisos efectivos con traza.
- **CU:** CU-GOB-01; CU-IAM-02

### PAN-IAM-11 — Roles
- **Qué:** Definición de capabilities por rol.
- **Quién:** `iam.roles.ver` / `editar`.
- **Cuándo:** Diseño de seguridad del tenant.
- **Dónde:** IAM → Roles.
- **Por qué:** Modelo `modulo.recurso.accion` (CU-ACC-01).
- **Cómo:** Use plantillas plataforma; marque S/D según impacto.
- **CU:** CU-ACC-01

### PAN-IAM-12 — Perfiles de pantallas
- **Qué:** Qué menús y pantallas ve cada usuario.
- **Quién:** `iam.perfiles.ver` / `editar`.
- **Cuándo:** Onboarding de áreas o restricción horaria.
- **Dónde:** IAM → Perfiles.
- **Por qué:** Capa 3 del licenciamiento (BASE §45).
- **Cómo:** Árbol de pantallas; pruebe vista previa de menú.
- **CU:** CU-ACC-01; CU-IAM-09

### PAN-IAM-13 — Segregación de funciones (SoD)
- **Qué:** Reglas de conflictos, excepciones y recertificación.
- **Quién:** `iam.sod.configurar`.
- **Cuándo:** Diseño de controles internos.
- **Dónde:** IAM → SoD.
- **Por qué:** Evita combinaciones de permisos peligrosas.
- **Cómo:** Revise conflictos abiertos antes de aprobar excepciones.
- **CU:** CU-ACC-01

### PAN-IAM-14 — Explicador de permisos
- **Qué:** Simula por qué un usuario tiene o no acceso.
- **Quién:** `iam.permisos.explicar`.
- **Cuándo:** Soporte y capacitación.
- **Dónde:** IAM → Explicar.
- **Por qué:** Transparencia sin suplantar (AGR-008).
- **Cómo:** Elija usuario + pantalla/capability; lea traza de 11 pasos.
- **CU:** CU-ACC-01

### PAN-IAM-15 — Bandeja autorizaciones
- **Qué:** Aprobar/rechazar acciones que requieren supervisor.
- **Quién:** `iam.autorizaciones.bandeja`.
- **Cuándo:** Límites, SoD o fuera de alcance.
- **Dónde:** Autorizaciones.
- **Por qué:** Reemplazo ValidarPermiso ProCoop.
- **Cómo:** Step-up al aprobar; comentario obligatorio.
- **CU:** CU-IAM-04

### PAN-IAM-16 — Autorización de supervisor
- **Qué:** Validación presencial o diferida de acción sensible.
- **Quién:** Supervisor con capability o bandeja.
- **Cuándo:** La operación exige segundo par de ojos.
- **Dónde:** Modal contextual.
- **Por qué:** Reemplazo ValidarPermiso ProCoop.
- **Cómo:** Supervisor presente ingresa credenciales; si no, solicite aprobación diferida.
- **CU:** CU-IAM-04

### PAN-IAM-17 — Auditoría de cambios
- **Qué:** Consulta del registro inmutable de cambios.
- **Quién:** `iam.auditoria.cambios.ver`.
- **Cuándo:** Investigación o control interno.
- **Dónde:** Auditoría → Cambios.
- **Por qué:** GOB / CU-GOB-01.
- **Cómo:** Filtre por módulo y fecha; exportar con permiso.
- **CU:** CU-GOB-01

### PAN-IAM-18 — Auditoría de accesos
- **Qué:** Consulta de inicios de sesión y resultados.
- **Quién:** `iam.auditoria.accesos.ver`.
- **Cuándo:** Investigación de acceso indebido.
- **Dónde:** Auditoría → Accesos.
- **Por qué:** Trazabilidad de autenticación.
- **Cómo:** Filtre por usuario, IP o rango de fechas.
- **CU:** CU-GOB-01

### PAN-IAM-19 — Auditoría de lecturas
- **Qué:** Registro de consultas a datos sensibles y exportaciones.
- **Quién:** `iam.auditoria.lecturas.ver`.
- **Cuándo:** Control de acceso a información clasificada.
- **Dónde:** Auditoría → Lecturas.
- **Por qué:** Ley 25.326 y políticas internas.
- **Cómo:** Revise informe o exportación con hash registrado.
- **CU:** CU-GOB-01

### PAN-IAM-20 — Auditoría de mensajes
- **Qué:** Trazabilidad de correos, SMS y notificaciones.
- **Quién:** `iam.auditoria.mensajes.ver`.
- **Cuándo:** El socio dice no haber recibido aviso.
- **Dónde:** Auditoría → Mensajes.
- **Por qué:** Prueba de entrega al canal.
- **Cómo:** Destinatario parcialmente enmascarado; enlace a detalle T09 si aplica.
- **CU:** CU-GOB-01

### PAN-IAM-21 — Auditoría de IA
- **Qué:** Invocaciones de IA con decisión humana y costo.
- **Quién:** `iam.auditoria.ia.ver`.
- **Cuándo:** Revisión de uso de asistente.
- **Dónde:** Auditoría → IA.
- **Por qué:** IA propone, no ejecuta sola (P6).
- **Cómo:** Abra detalle para ver entrada minimizada y salida.
- **CU:** CU-GOB-01

### PAN-IAM-22 — Políticas de seguridad
- **Qué:** MFA, contraseña, sesión y login socio del tenant.
- **Quién:** `iam.politicas.ver` / `configurar`.
- **Cuándo:** Endurecer seguridad o habilitar canales.
- **Dónde:** IAM → Políticas.
- **Por qué:** Centraliza parámetros de T02 publicados vía T04.
- **Cómo:** Simule impacto en roles antes de publicar.
- **CU:** CU-IAM-11

### PAN-IAM-23 — SSO e identidad federada
- **Qué:** Proveedores OIDC, Google, CiDi y prueba de conexión.
- **Quién:** `iam.idp.configurar`.
- **Cuándo:** Habilitar login corporativo o CiDi.
- **Dónde:** IAM → SSO.
- **Por qué:** Menos contraseñas locales; mapeo de atributos.
- **Cómo:** Secreto en bóveda; pruebe antes de activar en producción.
- **CU:** CU-IAM-11

### PAN-IAM-24 — Clientes API
- **Qué:** Alta de clientes API, scopes y rotación de secreto.
- **Quién:** `iam.apiClientes.ver` / `gestionar`.
- **Cuándo:** Integración con terceros.
- **Dónde:** IAM → API clientes.
- **Por qué:** Acceso máquina con trazabilidad de uso.
- **Cómo:** Copie secreto una sola vez; rote ante compromiso.
- **CU:** CU-ACC-01

### PAN-IAM-25 — Usuarios del portal
- **Qué:** Accesos de socios al portal (sin ver contraseñas).
- **Quién:** `iam.portal.usuarios.ver`.
- **Cuándo:** Soporte o bloqueo de acceso abusivo.
- **Dónde:** IAM → Usuarios portal.
- **Por qué:** M01 relaciones; IAM solo acceso digital.
- **Cómo:** Desvincular cuenta requiere motivo auditado.
- **CU:** CU-29

### PAN-IAM-26 — IAM plataforma
- **Qué:** Usuarios y plantillas de rol de plataforma GoodApps.
- **Quién:** Roles `iam.plataforma.*`.
- **Cuándo:** Onboarding de cooperativa o actualización plantilla.
- **Dónde:** Consola plataforma.
- **Por qué:** Roles semilla sin mezclar datos de tenant.
- **Cómo:** Publique versión; cada tenant adopta cuando quiera.
- **CU:** CU-IAM-05

### PAN-IAM-27 — Soporte temporal
- **Qué:** Aprobar o revocar acceso de soporte GoodApps al tenant.
- **Quién:** Admin tenant y rol plataforma según flujo.
- **Cuándo:** Incidente o configuración asistida.
- **Dónde:** IAM soporte / plataforma.
- **Por qué:** AGR-034 consentimiento auditado.
- **Cómo:** Ventana acotada; revise actuaciones al cierre.
- **CU:** CU-IAM-05

### PAN-IAM-28 — Seguridad plataforma
- **Qué:** Auditoría cross-tenant, alertas e integridad de cadenas.
- **Quién:** `iam.plataforma.auditoria.ver`.
- **Cuándo:** Operación GoodApps o incidente grave.
- **Dónde:** Plataforma → Seguridad.
- **Por qué:** DEC-116 solo rol plataforma en BI/seguridad global.
- **Cómo:** Reconozca alerta y documente resolución.
- **CU:** CU-IAM-05

### PAN-IAM-29 — Sesiones activas
- **Qué:** Listado y cierre de sesiones del tenant.
- **Quién:** `iam.sesiones.ver`.
- **Cuándo:** Robo de sesión sospechado o fin de jornada compartida.
- **Dónde:** IAM → Sesiones.
- **Por qué:** Equivalente a conexiones abiertas ProCoop.
- **Cómo:** Cierre una sesión o todas las de un usuario.
- **CU:** CU-GOB-01

### PAN-IAM-30 — Conflicto de edición
- **Qué:** Aviso de edición simultánea y resolución de conflicto.
- **Quién:** Sesión en formulario con optimistic lock.
- **Cuándo:** Dos usuarios guardan el mismo registro.
- **Dónde:** Banner o modal 409.
- **Por qué:** Evita pérdida silenciosa de cambios.
- **Cómo:** Compare diff; recargue o reaplique cambios no conflictivos.
- **CU:** CU-IAM-02

### PAN-IAM-31 — Importar usuarios
- **Qué:** Carga masiva de usuarios staff desde Excel.
- **Quién:** `iam.usuarios.importar`.
- **Cuándo:** Apertura de sucursal o migración de legajos.
- **Dónde:** Wizard desde lista de usuarios.
- **Por qué:** Onboarding rápido con validación por fila.
- **Cómo:** Use plantilla; corrija errores antes de confirmar.
- **CU:** CU-29

### PAN-IAM-32 — Vincular cuenta (portal)
- **Qué:** Flujo de vinculación DNI/cuenta con prueba de titularidad.
- **Quién:** `por.cuentas.vincular`.
- **Cuándo:** Socio agrega suministro en portal.
- **Dónde:** `/vincular-cuenta`.
- **Por qué:** Paridad con PAN-PER-26 en contexto portal.
- **Cómo:** Textos personalizables por tenant; no comparta códigos por teléfono inseguro.
- **CU:** CU-REG-01 (M19)

---

**Canónico generado:** `anexos/T03-UXD-screenhelp-base-m01-t02.md` (regenerar con `generate_t03_screenhelp_annex.py`). Inventario: sincronizar con `sync_inventario_screenhelp.py`.

_Próximo paso:_ revisión copy `dict:` y publicar paquete (`status=published`) en O1.