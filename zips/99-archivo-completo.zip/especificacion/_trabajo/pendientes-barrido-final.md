# Pendientes para el barrido final (verificar si la fase 2 ya los cubrió)

## De T05 (CTR-DAT nuevas)
- CTR-DAT-75: `FACT_EPEC` → M12 `supplierInvoices.wholesaleSupply` (T07 ya aplicado por G5; falta M06 si lo cita).
- CTR-DAT-76: M04 no debe leer `BENSOC` como tarifa social.
- CTR-DAT-77: `intakeChannels` de M10 duplica `crmChannels` de M09 (marcar reemplazado en M10).

## De G5 fase 2
- M02: `contractEquipmentAssignments` cubre los campos de la ex §7.17 de M13 (equipo, serie, modalidad comodato/venta DEC-013, fechas de entrega y devolución).
- T11: claves de M17 en `numberingSequences` (certificados, actas, otras).
- M15: definir `entityAccountAssignments` con `entityType: capitalRubric`; consumo de EVT-SOC-04/05.
- M04: `tar.quote` (API-TAR-064) con M13 como consumidor.
- T04: `identityDocumentTypes` (además de `legalEntities`, `branches`).
- T05: COL-PER-13 `CAUBLOQ` → `holdReasons` de M08; confirmar `documentTypeId` vs `identityDocumentTypes`.
- M08: evento de cobertura social con consumidor RF-SOC-032; `guarantees` incluye el depósito ortopédico.

## De G1 fase 2
- Renombre global en M02 `tenantServiceId` → `serviceId` (CTR-DAT-30): barrer todos los anexos (T11 EVT-CAT-01/02/03/28, M04 y cualquier otro) y aplicar el mismo nombre.
- M10 EVT-TEC-25: `propertyId` del inmueble → `premiseId` (clave de JOB-CAT-13); T11 igual.
- T02: capabilities `fac.revisionPrevia.ver/aprobar`, `pwa.planObra.ver`, `cat.contratos.cambiarRegimenMedicion`; DEC-043 y RF-POR-179 en el flujo de vinculación (G6 lo tiene asignado).
- M01: envío del código al contacto verificado del titular (RF-POR-179, DEC-043).
- M05: ruta PAN-FAC-47 `/admin/fac/revision-previa`; entidad jurídica desde `tenantServices.legalEntityId` (DEC-064).
- M08: PRM-MOR-200 cita `serviceProducts.tvMinimumLineup` y RN-CAT-079.
- M12: RF-CMP-155 y JOB-CMP-09 citan RF-CAT-116 y API-CAT-56.
- M18: `contractRegistrations` valida contra `tenantServices.registrations`; `serviceContractId` → `contractId` (T05 §7.2).
- T05: `legalEntityId` en `tenantServices` (obligatorio) y `serviceContracts` (opcional).

## De G4 fase 2
- M08: EVT-MOR-12 lleva `serviceMode` y perfil de restricción; aceptar `mode` en `tec.disconnection.executed`.
- M19: API-POR-122 consume API-TEC-55 y contempla consulta diferida (DEC-087).
- M12: RF-CMP-149/152 citan FI-INT-33 y FI-INT-115; RF-CMP-152 compara el factor de corrección con M04 (DEC-085), no con M03.
- M13: movimientos de stock por OT `bottledGasDelivery` (envases llenos y vacíos, `serialUnits`) (DEC-082).
- M04: `phoneRates`/`phoneRatePlans` (CTR-DAT-70); control de cupo del pack SMS (DEC-084).
- T08: `consentRecords` soporta los campos que usa T09.
- T02: propiedad de `apiClients`/`apiCredentials`; capabilities `tec.onCall.manage`, `tec.waterQuality.manage`.
- T11: EVT-TEC-25 con `premiseId` y `holderId`; EVT-TEC-35 con `crmCaseId`; `tec.disconnection.executed` con `mode`.
- T05: marcar aplicados en M09/M10/T06/T09/T10 los CTR-DAT 03, 15, 18, 28, 30, 32, 50, 67, 70, 71, 72; decidir `legacyRef` en T10 y `serviceCode` en la API externa (se recomienda mantener `serviceCode` como código público y extender CTR-DAT-32 a T10).

## De G2 fase 2
- T11: registrar EVT-FIS-24 `fis.thirdPartyAgreement.published` (M06 → M08); EVT-FAC-07 con `legalEntityId`; plantillas de factura en `documentTemplates`/`templateVersions`.
- T05: CTR-DAT-42 `DEUDARED` (deuda publicada a la red vs saldo de redondeo RN-01 §15) queda [VERIFICAR] en el legado.
- T07: `dependentTariffs` → `adherentRates`; `CAUBLOQ`/`HISBLOQ`/`SUMNOFAC` a M08/M01; `CLASIFICACION_ITEMS` → M13 `itemClassifications`.
- M07: emitir `paymentCoupons` sin mezclar entidades jurídicas; recibir `itemClass` y `legalEntityId`; `guaranteeDeposit` pasivo reintegrable; `DEUDARED` según CTR-DAT-42.
- M08: consumir EVT-FIS-24 (`allowServiceCut`); definir `dueDateSurchargeSchemes`, `holdReasons`, `documentHolds` para M05.
- M15: roles por `itemClass` (`guaranteesHeld`, `socialSubsidyFund`, derecho de sepultura).
- M12: RF-CMP-152: el factor lo aplica M04; `gasCorrectionCoefficient` de M03 es solo el coeficiente del punto.
- M18: originar ítems de depósito y aporte al fondo con `itemClass`. M13: definir `lotTypes` e `itemClassifications`.
- M19: API-POR-122 combina API-TAR-067 (M04) y API-TEC-55 (M10).

## De G3 fase 2
- T11: EVT-MOR-21 ya registrado (verificar payload con `legalEntityId`); M15 consume EVT-COB-04 (M-136); payloads EVT-CON-07 (`period`, `sequence`, `legalEntityId`) y EVT-COB-04 (`legalEntityId` por recibo).
- M06: `moraPolicy.allowServiceCut` (G2 ya lo agregó; verificar que M08 lo cite).
- M05: numeración por entidad para recibos de M07.
- M14: rendición de caja por entidad; `financialInstitutions` absorbe `ENTFIN`; `PPAGOS_FIRMAS` = firmas de órdenes de pago (G6).
- M17: `capitalItems` sin cuentas contables (ahora en `entityAccountAssignments` de M15).
- T04: `economicIndexSeries` recibe `INFLACIO`/`TABINFL` (G6).
- M13: `UNIDADES_GASTOS` → `expenseUnits`; M18: `COMBUSTIBLES` → `fuelTypes`.
- T07: discriminador de `PPAGOS`; `legalEntityId` desde `EMPRESAS`; `AUDIT_IA` → `legacyAuditRecords`; `ENTFIN`, `INFLACIO`, `TABINFL`, `RUBCAPI` con destinos nuevos.
- T05/T08: archivo de 36 meses para el detalle de cobranzas.
- Residual: `imageFileId`, `evidenceFileIds`, `declarationFileId` (derivados de `fileId`).

## De G6 fase 2
- T11: EVT-CFG-19 `cfg.legalEntity.created/.updated/.deactivated` (T04 → M06, M05, M15, M14, M16, T03, T10); EVT-CFG-20 `cfg.branch.*` (T04 → T02, T03, M06, M07, M09, M13); EVT-PLA-21 reemplazado por EVT-CFG-20; EVT-PLA-01 payload ampliado y consumidor `cfg`.
- T05: campos de COL-CFG-41..43 según T04 §7.14–7.16; `bankBranchId` en §7.2 con alias `branchOfficeId`; `PPAGOS_FIRMANTES` (`signatureParticipants` de T11 vs `treasuryAccountSigners` de M14): decidir uno.
- T03: `dataTableViews` absorbe `savedViews`; `brandingVariantKey` se resuelve en `tenantBrandings`; DEC-080 en plantillas.
- M06: puntos de venta y perfiles fiscales por `legalEntityId`; validación fiscal completa en O4 (RF-CFG-138); absorber PA-CFG-05.
- M05, M07, M15: `legalEntityId` obligatorio (RF-CFG-136) — verificar.
- M07: dueño de `cardPlans`; vínculo `treasuryHandoverId` con M14.
- M18: `tripSettlements` con `source.kind = salesDocument` desde M11.
- M05: `billableItems` con origen PRCAGAS.
- T07: EMPRESAS/SU_EMPRESAS → T04; PRCAGAS → M05; COMP_VEN_RENDICION.
- 03: REQ-DEC-064 con los nombres de T05 (`fiscal.*`).
- Capability `pwa.planObra.ver`: renombrar con prefijo de módulo dueño (recomendado `por.planObra.ver`, M19) en M19, T02, T03, M04.
- 04: DEC-074/075/076/080 ya citadas en T01 y T08 (se refleja al regenerar la matriz).
- T01: DEC-025 y DEC-026 sin RF propio (copias entre tenants, plantillas de plataforma): crear RF en T01.

## Posteriores a la fase 2
- Plan de olas: asignar a prompts los RF nuevos creados por los huecos (fase 1 y 2).
- Matriz: regenerar (§14 de 04).
- Revisión global: sin secciones duplicadas, sin `<!-- SIGUE -->`, sin IDs repetidos en ningún archivo.
