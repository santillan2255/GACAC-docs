import re, os

BASE = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
LOG = {}


class Doc:
    def __init__(self, name):
        self.name = name
        self.path = os.path.join(BASE, name)
        raw = open(self.path, 'rb').read()
        self.bom = raw.startswith(b'\xef\xbb\xbf')
        if self.bom:
            raw = raw[3:]
        self.crlf = b'\r\n' in raw
        self.t = raw.decode('utf-8')
        self.renames = 0
        self.changes = 0

    def rep(self, old, new, n=1):
        k = self.t.count(old)
        if k != n:
            raise SystemExit(f'{self.name}: se esperaban {n} y hay {k}: {old[:120]!r}')
        self.t = self.t.replace(old, new)
        self.changes += n

    def rename(self, old, new, extra=''):
        pat = re.compile(r'(?<!antes )`' + re.escape(old) + r'`(?! \(antes)')
        k = len(pat.findall(self.t))
        self.t = pat.sub('`' + new + '` (antes `' + old + '`' + extra + ')', self.t)
        self.renames += k
        return k

    def save(self):
        if '<!-- SIGUE -->' in self.t:
            raise SystemExit(self.name + ': marcador SIGUE')
        data = self.t.encode('utf-8')
        if self.bom:
            data = b'\xef\xbb\xbf' + data
        open(self.path, 'wb').write(data)
        LOG[self.name] = (self.changes, self.renames)
        print(self.name, 'cambios', self.changes, 'renombres', self.renames)
