"""Segunda consolidación (ronda de residuales, 05-11-2026): CU renumerados, PA nuevas en §18 y PAN-UXD-15..17 en 04-matriz."""
import os, re, sys, glob, collections
sys.path.insert(0, os.path.dirname(__file__))
import plan_recuento as pr  # noqa

ESPEC = pr.ESPEC
F = os.path.join(ESPEC, '04-matriz-trazabilidad.md')
raw = open(F, 'rb').read()
bom = raw.startswith(b'\xef\xbb\xbf')
t = raw.decode('utf-8-sig')
NL = '\r\n' if '\r\n' in t else '\n'
assert '### 21.5 Ronda de residuales' not in t, 'ya aplicado'
C = 'ronda de residuales 05-11-2026'


def rep(a, b, n=1):
    global t
    c = t.count(a)
    assert c == n, (a[:90], c)
    t = t.replace(a, b)


rep('| › Caso de uso de ejemplo — CU-13 (§13) (L723) | M07, M14, T06 | M07: RF-COB-141, RF-COB-147, RF-COB-159 … · M14: encab., §1, RF-TES-043 … ·',
    '| › Caso de uso de ejemplo — CU-13 (§13) (L723) | M07, M14, T06 | M07: RF-COB-141, RF-COB-147, RF-COB-159 … · M14: encab., §1, RF-TES-043 … (§16 CU-TES-17, antes CU-13, ' + C + ') ·')
rep('| › Caso de uso — CU-ACC-01 (§45) (L2545) | T02, T03 | T02: encab., §4.4, §10 … · T03: encab., RN-UXD-023, RN-UXD-024 … |',
    '| › Caso de uso — CU-ACC-01 (§45) (L2545) | T02, T03 | T02: encab., §4.4, §10 … · T03: encab., RN-UXD-023, RN-UXD-024 … (§16 CU-UXD-07, antes CU-ACC-01 parte UX; dueño T02, ' + C + ') |')
rep('| › Caso de uso — CU-SEG-01 (§60) (L3268) | T02, T08 | T02: encab., §10, §16 … ·',
    '| › Caso de uso — CU-SEG-01 (§60) (L3268) | T02, T08 | T02: encab., §10, §16 (CU-IAM-11, antes CU-SEG-01; dueño T08, ' + C + ') … ·')
rep('| §58 Revisión expresa de arquitectura: gestión de cooperativas, ERP y CRM (L3126) | M09, T01, T02, T08, T10, T11 | M09: §22: §2 límite; resuelto por DEC del maest... · T01: RF-PLA-004, RF-PLA-035, RF-PLA-148 … ·',
    '| §58 Revisión expresa de arquitectura: gestión de cooperativas, ERP y CRM (L3126) | M09, T01, T02, T08, T10, T11 | M09: §22: §2 límite; resuelto por DEC del maest... · T01: RF-PLA-004, RF-PLA-035, RF-PLA-148 … (§16 CU-PLA-15, antes CU-ARQ-01; dueño de CU-ARQ-01 T11, ' + C + ') ·')

NUEVAS = ['PA-PER-19', 'PA-CAT-23', 'PA-MED-15', 'PA-TAR-21', 'PA-FAC-23', 'PA-FIS-22', 'PA-COB-21', 'PA-MOR-22', 'PA-CRM-20',
          'PA-TEC-23', 'PA-VEN-12', 'PA-CMP-16', 'PA-STK-11', 'PA-TES-19', 'PA-CON-19', 'PA-SUE-18', 'PA-INS-13', 'PA-SOC-19',
          'PA-POR-22', 'PA-PLA-15', 'PA-IAM-18', 'PA-UXD-18', 'PA-CFG-15', 'PA-DAT-04', 'PA-INT-27', 'PA-MIG-21', 'PA-NFR-24',
          'PA-COM-19', 'PA-BIA-17', 'PA-WFL-23']
t02 = open(os.path.join(ESPEC, '02-preguntas-abiertas.md'), encoding='utf-8-sig').read()
fila02 = {}
for l in t02.split('\n'):
    m = re.match(r'\| (PA-[A-Z0-9-]+?-\d+) \| ([^|]+) \| ([^|]+) \|', l)
    if m:
        fila02[m.group(1)] = (m.group(2).strip(), m.group(3).strip(), l.rstrip().rsplit('|', 2)[-2].strip())
extra = sorted(k for k in fila02 if k not in NUEVAS and ('| %s |' % k) not in t and k > 'PA-')
textos = {}
for f in sorted(glob.glob(os.path.join(ESPEC, 'anexos', '*.md'))):
    b = os.path.basename(f)
    cod = b[:3] if not b.startswith('T04b') else 'T04b'
    textos.setdefault(cod, []).append(open(f, encoding='utf-8-sig').read())
prompts = {p['id']: p for p in pr.leer_prompts()}
rf_prompt = {}
for p in prompts.values():
    for r in p['rf']:
        rf_prompt.setdefault(r, p['id'])
filas = []
for pa in NUEVAS:
    dueno, tema, est = fila02[pa]
    menc = sum(x.count(pa) for x in textos[dueno])
    otros = sorted(k for k, v in textos.items() if k != dueno and any(pa in x for x in v))
    rfs = collections.defaultdict(list)
    for v in textos.values():
        for x in v:
            for l in x.split('\n'):
                m = re.match(r'^\|\s*\**(RF-[A-Z]+-\d{3})\**\s*\|', l)
                if m and re.search(re.escape(pa) + r'(?!\d)', l) and m.group(1) in rf_prompt:
                    rfs[rf_prompt[m.group(1)]].append(m.group(1))
    if rfs:
        rfc = '; '.join('%s: %s' % (k, ', '.join(sorted(set(v)))) for k, v in sorted(rfs.items()))
        res = 'Trazada (dueño la registra)'
    else:
        rfc = '—'
        res = 'Trazada en el dueño; ningún RF la cita (solo PA, RN, PRM o §21)'
    if menc == 0:
        res = 'Falta en el dueño'
    filas.append('| %s | %s | %s | %s | — (ronda de residuales) | %d | %s | %s | %s |' % (
        pa, dueno, tema, est, menc, ', '.join(otros) or '—', rfc, res))
ancla = '| PA-WFL-22 | T11 | Destino de `responsibleAreaId` |'
i = t.index(ancla)
j = t.index(NL, i)
t = t[:j] + NL + NL.join(filas) + t[j:]
rep('Desde el cierre 05-11-2026 se agregan al final las 38 PA que los anexos registraron durante la corrección de inconsistencias (todas `Asumida (DEC-072)`).',
    'Desde el cierre 05-11-2026 se agregan al final las 38 PA que los anexos registraron durante la corrección de inconsistencias (todas `Asumida (DEC-072)`), '
    'y después las 30 PA de la ronda de residuales del mismo día.')

# PAN-UXD-15..17
T03 = open(os.path.join(ESPEC, 'anexos', 'T03-UXD-experiencia-marca-diccionario.md'), encoding='utf-8-sig').read()
pan = {}
for l in T03.split('\n'):
    m = re.match(r'^\| (PAN-UXD-1[567]) \| ([^|]+) \| ([^|]+) \|', l)
    if m:
        rf = re.findall(r'RF-UXD-\d{3}', l)
        pan[m.group(1)] = (m.group(2).strip(), m.group(3).strip(), rf)
assert len(pan) == 3, pan
pf = []
for k in sorted(pan):
    app, ruta, rf = pan[k]
    rf = sorted(set(rf))
    pr_ = sorted(set(rf_prompt.get(r, '—') for r in rf))
    pf.append('| %s | %s | %s | %s | %s | Trazada: la PAN cita el RF y el RF está en un solo prompt |' % (k, app, ruta, ', '.join(rf), ', '.join(pr_)))

sec = [
    '',
    '### 21.5 Ronda de residuales (05-11-2026)',
    '',
    'Recuento con `_trabajo/plan_recuento.py` (4.204 RF y 292 RNF, 0 faltantes y 0 duplicados) y verificación prompt → RF de 15.7 con `_trabajo/matriz_verif_157.py` (172 prompts, 0 diferencias). §18 con `_trabajo/cierre_final2_matriz.py`.',
    '',
    '| CU vigente | Anexo | Antes | Dueño del ID anterior | Fundamento | Efecto en esta matriz |',
    '|---|---|---|---|---|---|',
    '| CU-TES-17 | M14 §16 | CU-13 (de M14, parte tesorería) | BASE §13 (M07 y T06 citan su parte) | PA-TES-19 | Fila BASE §13 "CU-13": M14 sigue citando BASE §13; se anota el ID nuevo |',
    '| CU-PLA-15 | T01 §16 | CU-ARQ-01 (parte PLA) | T11 | PA-PLA-15 | Fila BASE §58: T01 sigue citando BASE §58; se anota el ID nuevo |',
    '| CU-IAM-11 | T02 §16 | CU-SEG-01 | T08 | PA-IAM-18 | Fila BASE §60 "CU-SEG-01": se anota el ID nuevo |',
    '| CU-UXD-07 | T03 §16 | CU-ACC-01 (parte UX) | T02 | PA-UXD-18 | Fila BASE §45 "CU-ACC-01": se anota el ID nuevo |',
    '',
    'Pantallas de T03 asignadas a RF existentes (PA-UXD-18; sin RF nuevos):',
    '',
    '| PAN | App | Ruta | RF | Prompt | Estado |',
    '|---|---|---|---|---|---|',
] + pf + [
    '',
    '| Sección | Valor vigente | Valor anterior (reemplazado) |',
    '|---|---|---|',
    '| 18 | 78 PA (10 de los huecos, 38 de la corrección y 30 de la ronda de residuales) | 48 |',
]
fin = NL if t.endswith(NL) else ''
t = t.rstrip('\r\n') + NL + NL.join(sec) + fin
open(F, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + t.encode('utf-8'))
print('ok', len(filas), 'extra PA de 02 sin fila en §18 (anteriores, no se agregan):', len(extra))
print('\n'.join(pf))
for f in filas:
    if 'Falta' in f:
        print('FALTA', f[:80])
