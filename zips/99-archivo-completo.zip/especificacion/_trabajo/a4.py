﻿from conc_lib import *
L = read(T11).split('\n')
s = next(i for i,l in enumerate(L) if l.startswith('### 12.2 '))
e = next(i for i,l in enumerate(L) if l.startswith('### 12.4 '))
with open('catcompact.txt','w',encoding='utf-8') as o:
    for i in range(s,e):
        m = re.match(r'^\|\s*(EVT-[A-Z]{3}-\d+[^|]*)\|([^|]*)\|', L[i])
        if m: o.write('%s|%s\n' % (m.group(1).strip(), ' '.join(expand(m.group(2)))))
