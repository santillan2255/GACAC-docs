# Residuales informados en la fase 3 (para el cierre)

## G1 (M02, M19, T03)
- RF nuevos: RF-CAT-114/115 (O7), RF-CAT-116 (O10), RF-POR-174/179 (O2), RF-POR-176 (O7), RF-POR-175/177/178 (O10), RF-UXD-179 (O2).
- T11: EVT-CAT-01/02/03/28 con `serviceId`; EVT-CAT-22 con `inventoryItemId`/`serialUnitId`; M02 consumidor de EVT-TEC-25 (JOB-CAT-13, clave `workId`+`premiseId`).
- M04: API-TAR-067 acepta períodos archivados o delega la consulta diferida (DEC-087); capability `por.planObra.ver` en API-TAR-066.
- M13: ex §7.17 reemplazada por `contractEquipmentAssignments` de M02; consumir EVT-CAT-22 con `serialUnitId`.
- T04: `brandingVariantKey` validado contra `tenantBrandings.variants[].variantKey`.
- T05: `screenCode` (COL-UXD-10) vs `tableId` (T03): elegir uno.

## G6 (M11, M14, M16, T01, T02, T04, T04b, T08)
- RF nuevos: RF-CFG-134..138, 140 (O0); RF-CFG-141 (O1); RF-CFG-139, 143 (O9); RF-CFG-142 (O11); RF-PLA-164, 165 (O2).
- T11: EVT-CFG-19, EVT-CFG-20 nuevos; EVT-PLA-21 reemplazado por EVT-CFG-20; EVT-PLA-01 payload ampliado + consumidor `cfg`.
- T05: `PPAGOS_FIRMANTES` (M14 `treasuryAccountSigners` vs T11 `signatureParticipants`).
- M14 RN-TES-086: diferencia de arqueo multi-entidad imputada a la entidad de mayor importe (default propuesto; validar con contador) → registrar como PA asumida.
- T04: origen ProCoop de sucursales y puestos [VERIFICAR].

## G2 (M03, M04, M05, M06)
- RF nuevos: O3 RF-TAR-115; O4 RF-FAC-177, 179, RF-FIS-161, 167, 168; O6 RF-FIS-164, 166; O7 RF-MED-128, RF-TAR-116, 119, 121, RF-FAC-174, 175, 178; O8 RF-MED-129; O10 RF-TAR-117, 118, 120, 122, RF-FAC-176, RF-FIS-162, 165; O11 RF-FIS-163.
- T11: EVT-FIS-24 `fis.thirdPartyAgreement.published` (M06→M08, M05, M15) nuevo; EVT-FAC-07 + `legalEntityId`, `obligations[].itemClass`; JOB-TAR-14 `tar:crear-planes-obra` nuevo; JOB-FAC-01 (CLO tras AG); suscripciones: M06←EVT-CFG-19/20; M04, M05←EVT-CAT-28; M03←EVT-CMP-16; M04←EVT-STK-07/08, EVT-SOC-06/07, EVT-TEC-25.
- T07 línea ~1097: `PRCAGAS` → `billableItems` de M05 (no `gasProratedConsumptions`).
- T05: CTR-DAT-42 `DEUDARED` [VERIFICAR].
- T06/M10: contrato de consumo de correo/SMS hacia M04 (RN-TAR-251).
- M08: citar `allowServiceCut` (RN-MOR-141/142). M07: `fac.service.nextNumber` para recibos. M10, M11, M13, M18: cargos vía `fac.service.upsertBillableItem` (no `preloadedCharges`).
- 05: HUECO-CAP-04 → Corregido (parámetro, requiere validación legal). HUECO-TAS-03 sigue parcial: dato heredado `IMPUESTO.ORIGEN`/`CON_TASAS` (T07/relevamiento).
- 02: PA-FIS-18 agregada; PA-CFG-05 reemplazada (hecho).

## Cierre T11/T12/05 (hecho)
- 05: 71 corregidos (8 con parámetro que requiere validación legal), 6 Decisión, 0 parciales, 0 abiertos. T11: 656 eventos.
- Aplicado por mí: T03 `cfg.branch.*`, M18 consumidores EVT-SOC-06. Pendiente en agente cruzado: M10 EVT-TEC-07 envases, M14 EVT-TES-08, T05 COL-SOC-53 [VERIFICAR] vehículo.

## G3 (M07, M08, M12, M15)
- RF nuevos: RF-COB-190 (O10), RF-COB-191..194 (O5), RF-MOR-221 (O7), RF-MOR-222 (O10 TEL/TV; O7 AG/CLO), RF-MOR-223 (O6/O7), RF-MOR-224 (O10), RF-CMP-149..153 (O8), RF-CMP-154/155 (O10), RF-CON-161 (O10), RF-CON-162 (O5).
- T11: EVT-MOR-12 + `serviceMode`, `restrictionProfile`; EVT-COB-04 `itemClass` por imputación + `legalEntityId`; EVT-COB-13 + `treasuryHandoverId`, `legalEntityId`; EVT-CON-07 `period`, `sequence`, `legalEntityId`; consumidores M08←EVT-FIS-24, M07←EVT-CFG-20, M15←EVT-CFG-19, EVT-COB-04.
- 05: HUECO-SEP-01 (PRM-MOR-204), HUE-TEL-04 (PRM-MOR-199), HUE-TV-03 (PRM-MOR-200), HUE-AG-02 (PRM-MOR-201), HUE-ELE-05 (PRM-MOR-206) → Corregido en anexo (parámetro con default propuesto; requiere validación legal).
- M14: `cardPlans` §7.27 → `settlementTreasuryAccountId`; EVT-TES-08 + `treasuryHandoverId`.
- M05: verificar llamada a servicio M08 de bloqueos/Vto2-4 e `itemClass` en obligaciones.
- T04: RF-CFG-136 vs `chartOfAccounts` compartido (M15: entidad dueña + `sharedWithLegalEntityIds`).

## G5 (M01, M13, M17, M18, T07) — primera corrida
- RF nuevos: RF-PER-173 (O2), RF-STK-139 (O8), RF-SOC-146..149 (O10), RF-MIG-099 (O10).
- T11: EVT-SOC-07 + `characteristicCode`, `memberStatus`, `originalTripId`; EVT-SOC-04/05 consumidor M15; EVT-PER-23 `contractId`; `tec.workOrder.closed` detalle envases (consumidor M13); consumidor M18 del evento de cobertura social de M08.
- 05: HUECO-SEP-01 (PRM-SOC-052 + PRM-MOR-204), HUECO-OTR-05, HUECO-VIV-03, HUECO-TAS-03, HUECO-OTR-01 → Corregido en anexo.
- M06 §19 y T05 COL-TAR-11: `CON_TASAS` → Compras (`purchaseConcepts` M12).
- M10: payload cierre OT gas envasado.
- T05: COL-SOC-53 `serviceContractId` → `contractId`.
- Reanudado para pendientes extra (M13 §7.17, `upsertBillableItem`, `PPAGOS_FIRMANTES` según CTR-DAT-78).

## T05
- Totales: 1.104 filas, 1.053 a crear, 80 CTR-DAT (73 aplicadas). Maestra §12 actualizada (hecho).
- T11: CTR-DAT-62 (`EXPEDIENTES` → no `dossiers`); CTR-DAT-78 quitar `PPAGOS_FIRMANTES` de `signatureParticipants`.
- T07: CTR-DAT-78 (`PPAGOS_FIRMANTES` → `treasuryAccountSigners` M14; descartar `paymentOrderSigners`); CTR-DAT-42 split `DEUDARED_TIPO`.
- T01: declarar `schemaMigrations` (COL-PLA-32).
- T05 resolvió `screenCode`/`tableId`? → no informado; revisar en cierre.

## G4 (M09, M10, T06, T09, T10)
- RF nuevos: RF-CRM-258 (O3), RF-CRM-259 (O7), RF-CRM-260 (O7 GAS/ELE; O3 resto), RF-TEC-231 (O7 GAS/ELE; O3 resto), RF-TEC-232/233 (O7), RF-TEC-234 (O10), RF-TEC-235/236 (O7), RF-TEC-237 (O10), RF-TEC-238 (O7 AG; O10 TEL/TV), RF-TEC-239 (O8).
- T11: EVT-TEC-18 `mode` + `restrictionProfile?`; EVT-TEC-25 `premiseId`/`holderId`; EVT-TEC-35 `crmCaseId`; CNC-WFL-093 clave → `bia.api.legacyKeyExposed`.
- T05: CTR-DAT-32 "Aplicar en" + T09, T10; CTR-DAT-77 aplicado.
- 05: HUE-INT-03 y HUE-GAS-05 → Corregido en anexo (parámetro con default propuesto; requiere validación legal): PRM-CRM-135, PRM-CRM-133, PRM-TEC-152.
