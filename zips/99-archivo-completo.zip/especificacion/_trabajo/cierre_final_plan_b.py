"""Cierre de la corrección de inconsistencias: §18 y §21.6 del plan (05-11-2026)."""
import os
os.chdir(os.path.join(os.path.dirname(__file__), '..'))
F = '03-plan-de-olas-y-prompts.md'
raw = open(F, 'rb').read()
t = raw.decode('utf-8')
NL = '\r\n'
assert '### 21.6' not in t
a = 'se cumple en O6 por DEC-056. El dueño de T03 debería escribir `O6 (DEC-056)` en la celda |'
assert t.count(a) == 1
t = t.replace(a, 'se cumple en O6 por DEC-056. El dueño de T03 debería escribir `O6 (DEC-056)` en la celda '
              '(hecho en el cierre de la corrección de inconsistencias del 05-11-2026: la celda dice `O6 (DEC-056; antes O9+ cuando haya bot)`, y el recuento ya no informa desvío) |')
a = '| Índice | ' if False else '21. Cambios de la versión 1.1 (RF nuevos de huecos, DEC-082 a DEC-087 y cambios de ola)' + NL + NL + '---'
assert t.count(a) == 1
seccion = NL.join([
    '',
    '### 21.6 Cierre de la corrección de inconsistencias (05-11-2026)',
    '',
    'Insumo: `_trabajo/correccion-inconsistencias-pendientes-cierre.md` y `_trabajo/cierre-correccion-instrucciones.md`. Recuento con `_trabajo/plan_recuento.py`, que lee solo `anexos/*.md` (los respaldos `_trabajo/backup-*` no cuentan).',
    '',
    '| Ítem | Cambio | Dónde |',
    '|---|---|---|',
    '| a | RF-POR-180 nuevo en M19 (Comunidad en la tabbar del socio, PAN-POR-105 `/app/comunidad`, PA-POR-20), ola O2. El recuento lo informaba como faltante | Se agrega a `IMPLEMENTAR` de PRO-O2-17 (64 → 65 RF); §1, §6.4 (fila M19 POR 96 → 97, PAN-POR-01..105, total 613 → 614), tabla de secuencia de O2, PRO-O2-19, PRO-O11-10, §16 y §17 |',
    '| b | RF-UXD-163: T03 ya escribe `O6 (DEC-056)` en su celda | Sin cambio de prompt (sigue en PRO-O6-09); nota en §18 y en §17 |',
    '',
    'Totales vigentes por ola (cada RF y RNF en exactamente un prompt; sin faltantes, sin duplicados y sin IDs inexistentes):',
    '',
    '| Ola | Prompts | RF | RNF |',
    '|---|---|---|---|',
    '| O0 | 21 | 305 | 144 |',
    '| O1 | 20 | 458 | 72 |',
    '| O2 | 19 | 614 (antes 613) | 15 |',
    '| O3 | 13 | 319 | 9 |',
    '| O4 | 16 | 424 | 23 |',
    '| O5 | 14 | 469 | 13 |',
    '| O6 | 11 | 244 | 2 |',
    '| O7 | 10 | 274 | 0 |',
    '| O8 | 15 | 462 | 1 |',
    '| O9 | 9 | 163 | 0 |',
    '| O10 | 14 | 383 | 6 |',
    '| O11 | 10 | 89 | 7 |',
    '| **Total** | **172** | **4.204** (antes 4.203) | **292** |',
    '',
    'Avisos del recuento que no cambian la asignación (formato de celda en el anexo, ya explicados en §18): RF-CAT-010 (`según ficha`), RF-COM-180 (`por emisor`), RF-CRM-254 y RF-VEN-106 (`—`), RF-MIG-060 (`por dominio`), RF-TEC-157 y RF-UXD-026 (barra vertical sin escapar en la celda); RF-CRM-260, RF-TEC-231 y RF-MOR-222 siguen la regla §0.1.',
])
fin = NL if t.endswith(NL) else ''
t = t.rstrip('\r\n') + NL + seccion + fin
t = t.replace('21. Cambios de la versión 1.1 (RF nuevos de huecos, DEC-082 a DEC-087 y cambios de ola)' + NL + NL + '---',
              '21. Cambios de la versión 1.1 (RF nuevos de huecos, DEC-082 a DEC-087 y cambios de ola; §21.6 cierre de la corrección de inconsistencias)' + NL + NL + '---', 1)
open(F, 'wb').write(t.encode('utf-8'))
print('ok')
