import sys
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from g_cierre_lib import Doc

d = Doc('T01-PLA-plataforma-saas.md')

d.rep("consume `GET /api/public/<slug>/bootstrap` (API-POR-01)",
      "consume `GET /api/public/<tenantSlug>/bootstrap` (API-POR-01, dueño M19; antes `<slug>`)")
d.rep("| API-PLA-64 | GET | `/api/public/:slug/bootstrap` (antes `:tenantSlug`) | pública | **Reemplazada por API-POR-01** (M19), mismo endpoint:",
      "| API-PLA-64 | GET | `/api/public/:tenantSlug/bootstrap` (ruta de API-POR-01; antes `:slug`) | pública | **Referencia a API-POR-01** (dueño M19; no es un endpoint propio de T01; antes \"Reemplazada por API-POR-01\"), mismo endpoint:")
d.rep("| API-PLA-67 | GET | `/api/me/job-runs/:id` | Sesión; solo el usuario que lanzó el job (`jobRuns.requestedBy`) (antes \"dueño del job\") |",
      "| API-PLA-67 | GET | `/api/me/job-runs/:id` | Sesión con alcance `self`: solo el usuario que lanzó el job (condición sobre `jobRuns.requestedBy`, que no es una capability; T02 §4.4.3) (antes \"dueño del job\") |")
d.rep("| EVT-PLA-04 | `pla.tenant.reactivated` | — |",
      "| EVT-PLA-04 | `pla.tenant.reactivated` | tenantId, previousReasonCode, suspendedSince, skippedJobsCount (los de T11 EVT-PLA-04; antes \"—\") |")

ren = [
    ('pla.accesos.solicitar', 'pla.soporte.accesos.solicitar'),
    ('pla.accesos.aprobar', 'pla.soporte.accesos.aprobar'),
    ('pla.accesos.revocar', 'pla.soporte.accesos.revocar'),
    ('pla.accesos.ver', 'pla.soporte.accesos.ver'),
    ('pla.accesosSoporte.aprobar', 'pla.soporte.accesos.aprobar'),
    ('pla.accesosSoporte.revocar', 'pla.soporte.accesos.revocar'),
    ('pla.accesosSoporte.ver', 'pla.soporte.accesos.ver'),
]
for o, n in ren:
    print('  ', o, d.rename(o, n))
d.save()
