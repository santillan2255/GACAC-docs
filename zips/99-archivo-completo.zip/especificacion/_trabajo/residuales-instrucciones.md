# Ronda de residuales (5-11-2026)

Corrige en la especificación los residuales que detectaron los entregables al regenerarse. Mismas reglas que `cierre-correccion-instrucciones.md`: editar solo los archivos del grupo, no borrar (marcar "antes `x`" o "Reemplazado por …"), conservar BOM y finales de línea, sin mojibake, datos ficticios, decisiones como **Asumida (DEC-072)** con la opción recomendada registradas en la §21 del anexo (siguiente `PA-<MOD>-nn` libre; una PA por anexo puede agrupar varios puntos). No editar `02`, ni archivos de otros grupos.

## Fuentes de los residuales (leer las filas que tocan a tus archivos)
- `_trabajo/correccion-inconsistencias-pendientes-cierre.md`, sección "Residuales detectados al regenerar entregables" y siguientes.
- Estados: `docs/entregables-analisis-diseno/06a-indice-cobertura-secuencias-estados.md` §7 (INC-06-01 sin valores, 02 sin transiciones, 03 §7 vs §8, 04/05 dueño o colección, 08 sin estado inicial, 09 servicios sin invocador, 11 tipos de evento).
- Referencias sin destino y campos solo en T05: archivos `docs/entregables-analisis-diseno/03-er/*.md` (secciones de referencias sin destino / inconsistencias) y `03-modelo-entidad-relacion.md` §28–29.
- API: `docs/entregables-analisis-diseno/18-openapi/_inconsistencias.md` y la sección de inconsistencias de `18-contratos-api.md` (celdas de capability con rol o texto, métodos vs rutas, reemplazadas sin destino, colecciones sin tabla de campos).
- Eventos: sección de inconsistencias de `19-catalogo-eventos.md`.
- Pantallas/navegación: inconsistencias de `17-catalogo-pantallas/` y `22-mapa-navegacion*`.
- Casos de uso: inconsistencias de `21-casos-de-uso*`.

## Qué corregir en tus archivos
1. **Estados:** toda colección con campo de estado debe tener valores, estado inicial y tabla de transiciones (con evento si aplica) en su §8; §7 y §8 deben coincidir. Los valores que propongas quedan asumidos en la PA del anexo.
2. **Referencias sin destino:** cada campo `…Id`/`…Ids` debe indicar su colección destino (columna Referencia o nota). Usá la colección de T05 que corresponda; si no existe, decidí la opción recomendada y registrala.
3. **Colecciones sin tabla de campos en su §7:** agregá la tabla de campos (nombre, tipo, obligatorio, referencia, descripción) tomando los campos de T05 y del texto del anexo.
4. **Nombres de campo:** usar los canónicos de T05 §7.2 (p. ej. `associateMembershipId`, `inventoryItemId`, `delinquencyBatchId`).
5. **API:** la celda de capability debe tener una capability de T02 (no un rol ni texto); en M10 una ruta por grupo de método; filas reemplazadas deben citar la API destino por ID.
6. **Tipos de evento fuera de convención `<mod>.<agregado>.<hecho>`:** regla única para todos los grupos: guiones → camelCase (`int.debt-publication.created` → `int.debtPublication.created`); cuatro segmentos → unir el 2.º y 3.º en camelCase (`ins.capital.movement.recorded` → `ins.capitalMovement.recorded`). Dejar el nombre anterior como alias ("antes `x`"). T11 registra los alias en §12.4.
7. **Casos de uso con el mismo ID y distinto objeto:** dueños fijados por el coordinador:
   - CU-13: dueño M07; M14 renumera el suyo (siguiente CU libre de M14) con "antes CU-13".
   - CU-ACC-01: dueño T02; T03 renumera el suyo.
   - CU-ARQ-01: dueño T11; T01 renumera el suyo.
   - CU-SEG-01: dueño T08; T02 renumera el suyo.
8. **Rótulo corto de la barra del socio:** "Cuentas" para "Cuentas y servicios" (RN-UXD-006, máximo 12 caracteres).

## Informe final
Cambios por archivo con cantidades por categoría (1–8), PA registradas (ID, tema), IDs nuevos (CU, colecciones, eventos renombrados con su alias), lo que no se pudo cerrar y por qué, y lo que T05 o T11 deben reflejar.
