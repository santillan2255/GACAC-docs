﻿from conc_lib import *
cat = t11_catalog()
print(len(cat))
json.dump(cat, open('cat.json','w',encoding='utf-8'), ensure_ascii=False, indent=0)
# non-canonical names per file
res = {}
for f in files():
    b = os.path.basename(f)[:3]
    if b == 'T11': continue
    for ln, l in enumerate(read(f).split('\n'), 1):
        for n in expand(l):
            if n in cat: continue
            res.setdefault(n, {}).setdefault(os.path.basename(f).split('-')[0], []).append(ln)
print(len(res))
with open('noncanon.txt','w',encoding='utf-8') as o:
    for n in sorted(res):
        o.write(n + '  ' + '; '.join('%s:%s' % (k, ','.join(map(str, v[:8]))) for k, v in res[n].items()) + '\n')
