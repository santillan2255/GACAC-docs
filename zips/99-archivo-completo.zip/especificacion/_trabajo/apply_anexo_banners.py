#!/usr/bin/env python3
"""Inserta banner DEC-111 en anexos M/T que aún no lo tienen."""
from pathlib import Path

ESPEC = Path(__file__).resolve().parents[1]
ANEXOS = ESPEC / "anexos"

BANNER = """> **Norma de implementación (DEC-111, DEC-112, DEC-110, DEC-113).** Construcción GoodApps: **.NET 10**, **ASP.NET Core**, **EF Core**, **Azure SQL** (base compartida, `TenantId` en tablas de negocio), front **React 19**, **Microsoft Azure** (Container Apps, Blob, Queue, Key Vault, Application Insights), identidad **OpenIddict**. Modelo físico: `07-modelo-relacional-azure-sql.md` y `07-catalogo-tablas-sql.md`. Checklist e impacto: `06-impacto-adaptacion-stack-goodapps.md` (**DIR-13**).
>
> **Lectura:** «colección» en este anexo = **entidad lógica**; tablas, columnas y FK en `07-*`. RF/RN/CU del anexo **no cambian** por el stack.
"""

MARKER = "Norma de implementación (DEC-111"


def insert_after_metadata_table(content: str) -> str | None:
    if MARKER in content:
        return None
    lines = content.splitlines(keepends=True)
    # Find first table row after header | Campo |
    start = None
    for i, line in enumerate(lines):
        if line.startswith("| Campo |"):
            start = i
            break
    if start is None:
        return None
    # End of table: first blank line after a line starting with |
    j = start
    while j < len(lines) and (lines[j].startswith("|") or lines[j].strip() == ""):
        j += 1
    # Skip optional blockquote lines (M01) before ---
    k = j
    while k < len(lines) and (
        lines[k].strip() == ""
        or lines[k].startswith(">")
        or lines[k].startswith("| Fuentes")
        or (lines[k].startswith("|") and "Fuentes" in lines[k])
    ):
        # M01 has banner inside table — handle: if we see | Fuentes, consume until blank after table
        if lines[k].startswith("| Fuentes"):
            while k < len(lines) and (lines[k].startswith("|") or lines[k].strip() == ""):
                k += 1
            break
        if lines[k].startswith(">"):
            k += 1
            continue
        if lines[k].strip() == "":
            k += 1
            continue
        break
    insert_at = k
    # If next is ---, insert before ---
    if insert_at < len(lines) and lines[insert_at].strip() == "---":
        block = "\n" + BANNER + "\n"
        return "".join(lines[:insert_at]) + block + "".join(lines[insert_at:])
    block = "\n" + BANNER + "\n\n"
    return "".join(lines[:insert_at]) + block + "".join(lines[insert_at:])


def main() -> None:
    changed = 0
    for path in sorted(ANEXOS.glob("*.md")):
        text = path.read_text(encoding="utf-8")
        new = insert_after_metadata_table(text)
        if new is not None:
            path.write_text(new, encoding="utf-8")
            changed += 1
            print(f"Updated {path.name}")
    print(f"Done. {changed} files updated.")


if __name__ == "__main__":
    main()