# Fase 2 de consolidación: referencias cruzadas, CTR-DAT de T05 y DEC faltantes

Rigen las mismas reglas de `_trabajo/huecos-reglas-comunes.md` (solo tus archivos; no borrar; IDs con numeración propia; nombres canónicos; dueños del maestro §12; datos ficticios; sin secretos). Los informes de la fase 1 de todos los grupos están en `_trabajo/huecos-informes-fase1.md`.

Decisiones nuevas a respetar (`01-registro-decisiones.md`): DEC-082 gas envasado en alcance; DEC-083 conceptos de terceros siempre cuelgan de contrato propio (perfil "convenio de terceros" accesorio); DEC-084 correo y pack SMS como servicios M02; DEC-085 la corrección de volumen de gas la aplica M04 (M03 entrega volumen medido; CTR-MED-06 reemplazada por RN-TAR-035); DEC-086 `BENSOC` → único destino `serviceBeneficiaries` (M18), no es tarifa social; DEC-087 una cuenta corriente por titular y entidad jurídica, recibo por entidad; histórico > 36 meses en consulta diferida.

Tareas comunes a todos los grupos (además de su lista):
- **A. CTR-DAT de T05**: aplicá en tus anexos todas las contraposiciones de `anexos/T05-DAT-modelo-datos.md` §20 cuyo anexo de aplicación sea uno de los tuyos (nombres de colecciones y campos canónicos de T05: p. ej. `holderId`, `servicePointId`, `serialUnits`, `voucherTypeId`, `auditLogs`, `integrationSecrets` de T06 para la bóveda, subdocumento `legacy`, períodos según la convención de T05). Si una CTR-DAT contradice una decisión DEC-0xx o un hueco ya corregido, prevalece la DEC y lo informás.
- **B. DEC sin reflejo**: en `04-matriz-trazabilidad.md` §5.3 están las DEC que faltan en anexos declarados. Para cada DEC que falte en uno de tus anexos, agregá la referencia (ID de la DEC) donde el contenido la refleja; si el contenido la contradice, corregilo. Prioridad: DEC-064 (varias personas jurídicas por tenant, `legalEntities`/`legalEntityId`) y DEC-043 (verificación del vínculo usuario-titular).
- **C. Citas mal numeradas**: `04-matriz-trazabilidad.md` §4.3 lista citas a fuentes que no existen (p. ej. "RN-09 §14" en M13, "CNX §25" en M19, DFA §30–34 en T07). Corregí las de tus anexos.
- **D. Informe**: por ítem, archivo e IDs; y aparte, lo que otro anexo deba hacer.

## G1 — M02, M19, T03
- M19: PAN-POR-46 y PAN-POR-37 citan los componentes PAN-MOR-39/40/41; PAN-POR-33/34/35 montan PAN-TEC-57/58/59; PAN-POR-47/48/49, 38/39 y 12 citan PAN-MED-31..33 y PAN-FAC-43..45; PAN-POR-30 compone PAN-STK-40 y el bloque de plan de obra con API-TAR-066 (verificá que esté).
- M02: servicio/informe de abonados activos por paquete a una fecha de corte (para JOB-CMP-09 de M12); paquete de grilla mínima de TV usado por PRM-MOR-200; aclarar en §18 que PROMO-INT-50x3 aplica al abono (primer comprobante del ejemplo ARS 30.000,00 en M04).
- M02 §19.1: `BENSOC` → `serviceBeneficiaries` (M18, DEC-086); `CLASESER` tasa hospital según la regla de clasificación RF-FIS-163/RN-FIS-126 de M06 y RN-MIG-051 de T07; `ARTEFSUMS` queda en M02.
- M02: la ficha del servicio declara si admite beneficiarios y qué tipos de registración acepta (RF-SOC-148, `contractRegistrations`); §6.C.17 apunta a RF-SOC-147; §6.C.15 aplica DEC-083 (perfil "convenio de terceros"); gas envasado según DEC-082; correo/SMS según DEC-084. PA-CAT-17/18/19: Estado "Respondida (DEC-082/083/084)".
- T03: verificar que las claves `dict:crm.claimType.clo.desborde`, `.clo.obstruccion`, `.alu.luminariaApagada` existan con ese nombre exacto (G4 las usa); capabilities nuevas `fac.revisionPrevia.ver`, `fac.revisionPrevia.aprobar`, `pwa.planObra.ver` en el catálogo de pantallas/capabilities si T03 lo lleva (si es T02, informalo).
- M19: DEC-043 (verificación del vínculo usuario-titular) referenciada en el alta/vinculación de cuenta.

## G2 — M03, M04, M05, M06
- DEC-085: M04 RN-TAR-035 aplica la corrección; M03 CTR-MED-06 y su RN marcadas "Reemplazado por RN-TAR-035 (DEC-085)".
- M03 y M05 consumen EVT-CAT-28 `cat.contract.meteringRegimeChanged` (M05 si afecta la facturación del período).
- M03: consumir EVT-CMP-16 `cmp.supplyBalance.approved` en RF-MED-101 (pérdidas) y exponer la medición propia por punto `purchase`/`boundary` (RF-MED-129/API-MED-78 ya creados: verificá).
- M04: validación recíproca de ALU con RN-CAT-076 (citala por ID) y base de cálculo según régimen de medición (EVT-CAT-28); API de tasación/lectura de llamadas para API-POR-122 de M19 (crear API-TAR si no existe); `FACT_EPEC` → M12 `supplierInvoices.wholesaleSupply` (RF-CMP-149), marcar `energyPurchaseBills` de M04 como reemplazado; no recibe filas de `BENSOC` (DEC-086); el nombre de la tarifa de adherente (`adherentRates` vs `dependentTariffs` de T07): quedate con el que defina T05 y anotalo.
- M05: clases de ítem facturable "depósito en garantía", "aporte al fondo de subsidio" y "derecho de sepultura" (con referencia a RN-CON-123, RN-CON-122, RN-CON-124 y RF-FIS-162).
- M06: marca del convenio de terceros que autoriza inclusión en saldo elegible, recargos y corte (`thirdPartyAgreements.moraPolicy`, ya creado: verificá que cubra corte, coherente con RN-MOR-141/142 de M08); clase fiscal del depósito en garantía (fuera de base, no gravado); citar REP-BIA-015..024 de T10 en RF-FIS-139 y 144..150.
- DEC-064 en M05 y M06 (punto de venta y CUIT por entidad jurídica; comprobantes por `legalEntityId`). DEC-087 en M05 (recibo/factura por entidad).

## G3 — M07, M08, M12, M15
- M08: quitar EVT-TEC-25 de sus eventos consumidos (lo consumen M02, M04 y T09); RN-MOR-143 define el canal hacia M18 para "cobertura suspendida por mora": evento nuevo de M08 (p. ej. EVT-MOR-xx `mor.socialCoverage.suspended` / `.restored`) con consumidor M18 RF-SOC-032; RF-MOR-068 cita RN-FIS-127 / `thirdPartyAgreements.moraPolicy` de M06.
- M12: consumir API-MED-78 / RF-MED-129 de M03 en el control de la factura del mayorista (RF-CMP-149..153).
- M07: DEC-087 / PA-DAT-01: una cuenta corriente por titular y entidad jurídica; un cobro de caja puede cubrir varias entidades y se emite un recibo por entidad (RF nuevos o ajustes). DEC-064.
- M15: DEC-064 (asientos y libros por entidad jurídica si corresponde); el asiento del aporte de capital va a capital social (RN-FIS-124 de M06); M15 como consumidor de EVT-SOC-04 y EVT-SOC-05.

## G4 — M09, M10, T06, T09, T10
- M10: API de lectura de llamadas atribuidas por contrato y período (para API-POR-122 de M19); OT de reducción de caudal para el modo `restricted` de AG (RN-MOR-139 de M08).
- M09: los subtipos de reclamo usan `dict:crm.claimType.*` de T03 (verificá nombres exactos en T03 §10.9.12).
- T06: FI-INT-33 apunta a RF-CMP-149 (M12); agregar o extender la integración con la distribuidora de gas para la factura de compra (además de FI-INT-114 de formularios).
- T09: glosario "Beneficio", RF-COM-106, CTR-COM-18 y trazabilidad: `BENSOC` no es tarifa social; destino `serviceBeneficiaries` de M18 (DEC-086).
- T10: si existe `bia_runResults_<tenant>` (una colección por tenant), reemplazar por colección única con `tenantId` (DEC-002).

## G5 — M01, M13, M17, M18, T07
- M18: PAN-SOC-30..33 marcadas como embebidas en PAN-POR-98..101; API-SOC-061 consumida por PAN-POR-104; M15 consumidor de EVT-SOC-04 y EVT-SOC-05; el depósito del préstamo ortopédico se registra como garantía de M08 (RF-MOR-179, RN-CON-123); EVT-SOC-07 suma `characteristicCode`, `memberStatus` y `originalTripId` al payload (RN-TAR-249); RF-SOC-032 consume el evento de M08 de cobertura suspendida (G3 lo crea: citalo como "evento de cobertura social de M08 (RN-MOR-143)").
- M17: PAN-INS-30 embebida en PAN-POR-102; nota de que RF-COB-176 es solo conciliación de cierre (HUECO-CAP-02).
- M13: puede usar API-TAR-064 `tar.quote` para el importe del cargo por equipo no devuelto (RN-TAR-246).
- T07: `FACT_EPEC` → M12 (`supplierInvoices.wholesaleSupply`); `FACTOR_CAL` → M04; `ARTEFSUMS` → M02; `BENSOC` → `serviceBeneficiaries` (DEC-086); `CON_TASAS`/`IMPUESTO` con RN-FIS-126/RF-FIS-163 de M06; `legalEntities` es de T04 (no T01); `tenantParameters` según T05.

## G6 — M11, M14, M16, T01, T02, T04 (y T04b partes 1–4), T08
- Aplicar CTR-DAT de T05 en estos anexos; entre otras: M11 `freightSettlements` vs `tripSettlements` de M18; M14 `cardPlans` duplicada con M07 y `PPAGOS`/`PPITEMS`/`PPAGOS_FIRMANTES` como órdenes de pago a proveedores (dueño M14 si T05 así lo resuelve); M16 `employers` vs `legalEntities` de T04 y tablas legales de §7.45 que deben estar en T04; T01 `brandingRef`, `tenantParameters`, y citas a `configPackages`, `masterTables`, `branches`, `pointsOfSale` sin definición; T04 duplica tablas fiscales de M06, `sequences`, `savedViews`, `featureFlags`, y **no define `legalEntities` ni `branches`** (DEC-064 los exige desde O0: definirlos en T04 con RF propio, colección, campos mínimos, ola O0, y REQ-DEC-064 del plan de olas); T08 duplica `tenantUsageSnapshots`, `processedEvents`, `restoreDrills`, `idempotencyKeys` y usa `auditEvents` en lugar de `auditLogs`.
- T02: DEC-043 (verificación del vínculo usuario-titular) referenciada en el flujo de vinculación; capabilities nuevas `fac.revisionPrevia.ver`, `fac.revisionPrevia.aprobar`, `pwa.planObra.ver`, `cat.contratos.cambiarRegimenMedicion` y las de M10/M12/M15 nuevas de la fase 1 (ver informes) en el catálogo de capabilities si T02 lo lleva.
- M16: DEC-064 (empleador = entidad jurídica).
