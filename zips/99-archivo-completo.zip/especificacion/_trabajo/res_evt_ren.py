import sys, io, glob, os, re, json
REN = [
 ("EVT-INS-08", "ins.capital.movement.recorded", "ins.capitalMovement.recorded"),
 ("EVT-INS-09", "ins.capital.movement.reversed", "ins.capitalMovement.reversed"),
 ("EVT-INS-10", "ins.capital.transfer.executed", "ins.capitalTransfer.executed"),
 ("EVT-INS-11", "ins.capital.refund.approved", "ins.capitalRefund.approved"),
 ("EVT-INS-12", "ins.capital.refund.paid", "ins.capitalRefund.paid"),
 ("EVT-INS-13", "ins.surplus.distribution.approved", "ins.surplusDistribution.approved"),
 ("EVT-INS-13", "ins.surplus.distribution.executed", "ins.surplusDistribution.executed"),
 ("EVT-INS-21", "ins.inaes.report.submitted", "ins.inaesReport.submitted"),
 ("EVT-INT-01", "int.connection.mode-changed", "int.connection.modeChanged"),
 ("EVT-INT-03", "int.operation.manually-resolved", "int.operation.manuallyResolved"),
 ("EVT-INT-06", "int.arca.cae-obtained", "int.arca.caeObtained"),
 ("EVT-INT-06", "int.arca.cae-rejected", "int.arca.caeRejected"),
 ("EVT-INT-06", "int.arca.caea-obtained", "int.arca.caeaObtained"),
 ("EVT-INT-06", "int.arca.caea-informed", "int.arca.caeaInformed"),
 ("EVT-INT-06", "int.arca.params-synced", "int.arca.paramsSynced"),
 ("EVT-INT-07", "int.padron.persona-retrieved", "int.padron.personaRetrieved"),
 ("EVT-INT-08", "int.payment-intent.created", "int.paymentIntent.created"),
 ("EVT-INT-09", "int.debt-publication.acknowledged", "int.debtPublication.acknowledged"),
 ("EVT-INT-09", "int.debt-publication.rejected", "int.debtPublication.rejected"),
 ("EVT-INT-10", "int.remittance.line-received", "int.remittance.lineReceived"),
 ("EVT-INT-10", "int.remittance.file-applied", "int.remittance.fileApplied"),
 ("EVT-INT-11", "int.direct-debit.adhesion-updated", "int.directDebit.adhesionUpdated"),
 ("EVT-INT-11", "int.direct-debit.result-received", "int.directDebit.resultReceived"),
 ("EVT-INT-12", "int.bank.movements-received", "int.bank.movementsReceived"),
 ("EVT-INT-12", "int.bank.balances-received", "int.bank.balancesReceived"),
 ("EVT-INT-13", "int.message.inbound-received", "int.message.inboundReceived"),
 ("EVT-INT-14", "int.meter.reading-received", "int.meter.readingReceived"),
 ("EVT-INT-14", "int.meter.command-result", "int.meter.commandResult"),
 ("EVT-INT-14", "int.prepaid.credit-issued", "int.prepaid.creditIssued"),
 ("EVT-INT-15", "int.network.provisioning-result", "int.network.provisioningResult"),
 ("EVT-INT-16", "int.cdr.batch-received", "int.cdr.batchReceived"),
 ("EVT-INT-17", "int.fleet.positions-received", "int.fleet.positionsReceived"),
 ("EVT-INT-20", "int.reconciliation.differences-found", "int.reconciliation.differencesFound"),
 ("EVT-INT-22", "int.agent.command-result", "int.agent.commandResult"),
 ("EVT-INT-23", "int.ai.completion-ready", "int.ai.completionReady"),
]
if __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    files = sorted(glob.glob(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\*.md"))
    for evt, old, new in REN:
        hits = []
        for f in files:
            t = open(f, encoding="utf-8-sig").read()
            c = t.count(old)
            if c:
                hits.append("%s:%d" % (os.path.basename(f)[:3], c))
        print(evt, old, "->", new, " | ", ", ".join(hits))
