from res_lib import Doc

d = Doc(r'anexos\T01-PLA-*.md')
d.cell('| API-PLA-64 |', 3, '`public: true` (antes "pública")')
print('T01', d.save())
d = Doc(r'anexos\T03-UXD-*.md')
d.cell('| API-UXD-01 |', 3, '`public: true` (antes "Pública")')
print('T03', d.save())
