$ErrorActionPreference = 'Stop'
$dir = 'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
$map = [ordered]@{
  'M07-COB-cuenta-corriente-cobranza.md' = @('evidenceFileIds','evidenceFileId','imageFileId','controlFileId','iconFileId')
  'M08-MOR-mora-financiacion.md'         = @('documentFileId')
  'M12-CMP-compras-proveedores.md'       = @('specFileIds','dossierCoverFileId','sourceFileId','declarationFileId')
}
$utf8 = New-Object System.Text.UTF8Encoding($false)
$utf8Bom = New-Object System.Text.UTF8Encoding($true)
foreach ($name in $map.Keys) {
  $path = Join-Path $dir $name
  $bytes = [IO.File]::ReadAllBytes($path)
  $hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
  $text = [IO.File]::ReadAllText($path, $utf8)
  foreach ($old in $map[$name]) {
    if ($old.EndsWith('FileIds')) { $new = $old.Substring(0, $old.Length - 7) + 'StoredFileIds' }
    else { $new = $old.Substring(0, $old.Length - 6) + 'StoredFileId' }
    $pattern = '`' + $old + '`'
    $count = ([regex]::Matches($text, [regex]::Escape($pattern))).Count
    $text = $text.Replace($pattern, '`' + $new + '` (antes `' + $old + '`)')
    $pattern2 = '\b' + $old + '\b'
    $count2 = ([regex]::Matches($text, $pattern2)).Count - $count
    $text = [regex]::Replace($text, '(?<![`])\b' + $old + '\b(?![`])', $new)
    Write-Output "$name : $old -> $new (con backticks: $count, sin backticks: $count2)"
  }
  if ($hasBom) { [IO.File]::WriteAllText($path, $text, $utf8Bom) } else { [IO.File]::WriteAllText($path, $text, $utf8) }
}
