#!/usr/bin/env python3
"""Corrige mezclas empresa (GoodApps) vs producto (CoopApps)."""
from pathlib import Path

REPO = Path(__file__).resolve().parents[2].parent
TARGETS = list((REPO / "docs" / "especificacion").rglob("*.md"))
TARGETS += list((REPO / "docs" / "presentacion-stakeholders").rglob("*.md"))

REPLACEMENTS = [
    ("Operador de plataforma (CoopApps)", "Operador de plataforma (GoodApps)"),
    ("Equipo operador de CoopApps", "Equipo operador de GoodApps"),
    ("equipo CoopApps", "equipo GoodApps"),
    ("Equipo de CoopApps", "Equipo de GoodApps"),
    ("El equipo de CoopApps", "El equipo de GoodApps"),
    ("CoopApps los trata", "GoodApps los trata"),
    ("Contrato SaaS CoopApps–cooperativa", "Contrato SaaS GoodApps–cooperativa"),
    ("docs/alcance-funcional/CoopApps-Cooperativas-Alcance-Funcional.md", "docs/alcance-funcional/GoodApps-Cooperativas-Alcance-Funcional.md"),
    ("`CoopApps-Cooperativas-Alcance-Funcional.md`", "`GoodApps-Cooperativas-Alcance-Funcional.md`"),
]

for path in TARGETS:
    rel = path.as_posix()
    if "/OLD/" in rel or "/_trabajo/" in rel or "backup-" in rel:
        continue
    text = path.read_text(encoding="utf-8")
    new = text
    for a, b in REPLACEMENTS:
        new = new.replace(a, b)
    if new != text:
        path.write_text(new, encoding="utf-8", newline="\n")

print("ok")