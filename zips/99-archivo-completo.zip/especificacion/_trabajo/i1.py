﻿import re
from conc_lib import *
s=read(T11); L=s.split('\n')
print('prov', s.count('(prov.)'), 'lines', len(L))
for i,l in enumerate(L,1):
    if re.search(r'[Bb]recha|provisional',l) or re.match(r'\| (IDs|\*\*Total|Total)',l) or re.match(r'\| EVT-(FAC-2\d|FIS-2\d|COB-2\d|TEC-3\d|VEN-1[4-9]|CMP-1[4-9]|STK-2\d|TES-2\d|SUE-2[6-9]|PLA-2\d|CAT-2[5-9]) ',l) or l.startswith('#'):
        if l.startswith('#') and not re.match(r'#+ (12|18)',l): continue
        print(i, l[:230])
