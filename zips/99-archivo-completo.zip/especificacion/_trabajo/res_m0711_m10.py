from res_m0711_lib import *

d = Doc('M10')
PA = 'PA-TEC-23'
H = lambda n: '#### 7.22.%s ' % n


def set_last(heading, field, ref, cat=2, desc=None):
    k = d.row_idx(heading, field)
    l = d.lines[k]
    cells = l.strip().strip('|').split(' | ')
    old = cells[-1].strip()
    cells = [c.strip() for c in cells]
    if desc is not None:
        cells[-2] = desc
    cells[-1] = '%s (%s; antes "%s")' % (ref, PA, old)
    d.lines[k] = '| ' + ' | '.join(cells) + ' |'
    d.count(cat)


# ---- categoría 2: referencias en las fichas originales
d.replace_in_line('| `personId` / `prospect` |', 'Persona existente o datos de prospecto (`COD_PER`). |',
                  'Persona existente (→ M01 `persons`) o datos de prospecto (`COD_PER`); `prospect` es un objeto embebido, no es referencia (%s). |' % PA, 2)
d.replace_in_line('| `estimateId` / `quoteRef` |', 'Estimación y presupuesto M11. |',
                  'Estimación (→ M10 `connectionEstimates`) y presupuesto M11 (`quoteRef.id` → M11 `salesQuotes`; %s). |' % PA, 2)
d.replace_in_line('`cancelledBy`, `cancelReason` | Date/ObjectId/string', '| según estado | — |',
                  '| según estado | `closedBy` y `cancelledBy` → T02 `memberships`; `cancelReason` es texto libre, no es referencia (%s). |' % PA, 2)
d.replace_in_line('| `resultingServiceStatusId` |', 'ObjectId → estado de servicio', 'ObjectId → M02 `serviceStatuses` (antes "ObjectId → estado de servicio"; %s)' % PA, 2)
d.replace_in_line('| `defaultWorkTypeId`, `defaultResolutionIds[]`, `requiredTaskIds[]`', '| ObjectId | no | — |',
                  '| ObjectId | no | En ese orden: → M10 `workTypes`, `resolutionCodes`, `taskCatalog`, `fieldForms`, `visitTypes` (%s). |' % PA, 2)
d.replace_in_line('| `entityType` / `entityId` |', 'OT, visita, inspección, elemento de red, factibilidad. |',
                  'OT, visita, inspección, elemento de red, factibilidad. `entityType` no es referencia: discriminador de `entityId`, polimórfica (→ M10 `workOrders` · `visits` · `inspectionCases` · `networkElements` · `feasibilityRequests`); T05 lo nombra `entityRef` (%s). |' % PA, 2)
d.replace_in_line('| `assignedCrewId` / `assignedResourceIds[]` |', '| ObjectId | no | — |',
                  '| ObjectId | no | → M10 `crews` / → M10 `fieldResources`; T05 nombra `crewId` a `assignedCrewId` (%s). |' % PA, 2)
d.add_rows_after('### 7.9 ', 'signatureEvidenceId', ['| `signatureRequestId` | ObjectId → T11 `signatureRequests` | si digitalSignature | Pedido de firma digital del receptor. Declarado en T05 (COL-TEC-15); no figuraba en el anexo (%s). |' % PA], 2)

# ---- §7.22: tablas de dos columnas a tres
d.table_to3(H(1), {'prospect': 'object', 'quoteRef': 'object', 'cancelReason': 'string'})
set_last(H(1), 'prospect', 'No es referencia: datos embebidos del prospecto')
set_last(H(1), 'quoteRef', '→ M11 `salesQuotes` (`quoteRef.id`)')
set_last(H(1), 'cancelReason', 'No es referencia: motivo en texto libre')
d.table_to3(H(4), {'defaultResolutionIds': 'ObjectId[]', 'requiredTaskIds': 'ObjectId[]', 'checklistFormIds': 'ObjectId[]'})
set_last(H(4), 'resultingServiceStatusId', '→ M02 `serviceStatuses` (`ESTASER`)')
set_last(H(4), 'defaultResolutionIds', '→ M10 `resolutionCodes`')
set_last(H(4), 'requiredTaskIds', '→ M10 `taskCatalog`')
d.table_to3(H(14), {'entityType': 'enum', 'clientMutationId': 'UUID'})
set_last(H(14), 'entityType', 'No es referencia: discriminador de `entityId`')
set_last(H(14), 'entityId', 'Polimórfica según `entityType`: → M10 `workOrders` · `visits` · `inspectionCases` · `networkElements` · `feasibilityRequests`')
d.table_to3(H(23), {'assignedResourceIds': 'ObjectId[]'})
set_last(H(23), 'assignedResourceIds', '→ M10 `fieldResources`')
d.table_to3(H(31), {'deviceId': 'UUID'})
set_last(H(31), 'deviceId', 'No es referencia: UUID del dispositivo móvil (no es un equipo de red)')
d.add_rows_end_of_table(H(31), ['| `userId` | ObjectId | → T02 `memberships`. T05 lo nombra `membershipId` (COL-TEC-28); se conserva `userId` (%s). |' % PA], 2)
# tablas de cinco columnas
set_last(H(11), 'sourceOperationTypeId', '→ M10 `workOrderOperationTypes`')
set_last(H(11), 'targetIntakeChannelId', '→ M09 `crmChannels` (vía de ingreso `VIAINGTE`, CTR-DAT-77)')
set_last(H(24), 'leaderId', '→ M10 `fieldResources` (jefe de cuadrilla)')
set_last(H(39), 'parentTypeId', '→ M10 `networkComponentTypes`')
set_last(H(39), 'childTypeId', '→ M10 `networkComponentTypes`')
set_last(H(45), 'serviceIds', '→ M02 `tenantServices`')
set_last(H(45), 'connectorId', '→ T06 `integrationConnections` (conexión del conector, COL-INT-02)')
set_last(H(45), 'connectionId', 'Mismo dato que `connectorId` (nombre de T05); → T06 `integrationConnections`. Se usa `connectorId`')
set_last(H(46), 'casPackageIds', 'No es referencia: códigos de paquete del sistema de acceso condicional externo')
set_last(H(48), 'compensatesCommandId', '→ M10 `provisioningCommands` (comando que compensa)')
set_last(H(56), 'ownerId', 'Polimórfica según `ownerType`: → M10 `phoneExchanges` · `dslams`')
set_last(H(56), 'linkedDslamPortId', '→ M10 `phonePorts` (puerto del DSLAM vinculado)')
set_last(H(59), 'ownerId', 'Polimórfica según `ownerType`: → M10 `phoneFrameGroups` · `phoneBoxes`')
set_last(H(60), 'previousPositionId', '→ M10 `phoneStripPositions` (posición anterior)')
set_last(H(60), 'groupPositionId', '→ M10 `phoneStripPositions` (posición del grupo)')
set_last(H(60), 'contractId', '→ M02 `serviceContracts` (servicio conectado)')

# ---- categoría 1: valores de estado en §7.22
S = '(§8.16; %s); antes "%s"'
def st(heading, field, vals, req='Sí'):
    k = d.row_idx(heading, field)
    cells = [c.strip() for c in d.lines[k].strip().strip('|').split(' | ')]
    old = cells[3]
    d.lines[k] = '| `%s` | enum | %s | Valores: %s %s | — |' % (field, req, ', '.join('`%s`' % v for v in vals), S % (PA, old.replace('"', "'")))
    d.count(1)

st(H(16), 'status', ['open', 'inReview', 'approved', 'rejected', 'paid'])
st(H(28), 'status', ['planned', 'active', 'closed'])
st(H(30), 'status', ['draft', 'published', 'retired'])
st(H(33), 'status', ['open', 'inReview', 'resolved', 'dismissed'])
st(H(35), 'status', ['draft', 'approved', 'notified', 'inProgress', 'completed', 'cancelled'])
st(H(41), 'status', ['planned', 'available', 'used', 'damaged', 'notApplicable', 'retired'])
st(H(42), 'status', ['connected', 'disconnected'])
st(H(45), 'status', ['active', 'disabled'])
st(H(47), 'provisioningStatus', ['notProvisioned', 'active', 'suspended', 'deactivated', 'error'])
st(H(48), 'status', ['queued', 'sending', 'retrying', 'confirmed', 'failed', 'manualPending', 'manualDone', 'cancelled', 'compensated', 'unknown'])
st(H(49), 'status', ['active', 'suspended', 'deleted'])
st(H(50), 'status', ['draft', 'budgeted', 'approved', 'inProgress', 'finished', 'levyProposed', 'levyApproved', 'billing', 'closed', 'cancelled'])
st(H(53), 'status', ['suspected', 'inspectionOrdered', 'inspected', 'noIrregularity', 'irregularityConfirmed', 'userNotified', 'defenseReceived', 'defenseExpired', 'recoveryProposed', 'recoveryApproved', 'recoveryRejected', 'billed', 'regularized', 'closed', 'annulled'])
st(H(54), 'status', ['available', 'assigned', 'placed', 'removed', 'broken', 'voided'])
st(H(56), 'status', ['available', 'unavailable', 'inactive'])
st(H(60), 'status', ['available', 'reserved', 'connected', 'damaged'])
st(H(64), 'status', ['available', 'reserved', 'assigned', 'quarantine', 'retired'])
st(H(70), 'status', ['uploaded', 'parsing', 'parsed', 'withErrors', 'attributed', 'sentToRating', 'rated', 'grouped', 'rolledBack'])
st(H(71), 'attributionStatus', ['attributed', 'originNotFound', 'destinationNotFound', 'duplicate', 'manual'])
k = d.row_idx(H(72), 'status')
d.lines[k] = '| `status` | enum | Sí | Valores: `received`, `parsed`, `withErrors`, `attributed`, `applied`, `rolledBack` (§8.16; %s). Antes la celda tenía, fuera de lugar, el texto de los campos de `kind = ticQuota` (`connectionId`, `sourceMessageId`, `importedBy`), que siguen descritos en §7.20. | — |' % PA
d.count(1)
st(H(73), 'status', ['requested', 'submitted', 'accepted', 'rejected', 'scheduled', 'executed', 'cancelled', 'received', 'validated'])
st(H(75), 'status', ['taken', 'inLab', 'resulted', 'actionPending', 'closed'])
d.replace_in_line('| `status` | enum `draft\\|submitted\\|accepted\\|rejected\\|expired` | sí | Refleja el presupuesto M11. |',
                  'enum `draft\\|submitted\\|accepted\\|rejected\\|expired`', 'enum: `draft`, `submitted`, `accepted`, `rejected`, `expired` (§8.16; %s)' % PA, 1)

# ---- punto específico: API-TEC con menos grupos de método que rutas
def api(idn, old, new, extra_old=None, extra_new=None):
    pre = '| %s | %s |' % (idn, old)
    k = [i for i, l in enumerate(d.lines) if l.startswith(pre)]
    assert len(k) == 1, idn
    l = d.lines[k[0]].replace(pre, '| %s | %s |' % (idn, new), 1)
    cells = l.split(' | ')
    cells[-2] = cells[-2] + ' Grupos de método alineados a las rutas, uno por ruta en el mismo orden (antes `%s`; %s).' % (old, PA)
    l = ' | '.join(cells)
    if extra_old:
        l = l.replace(extra_old, extra_new, 1)
    d.lines[k[0]] = l
    d.count(5)

api('API-TEC-26', 'CRUD · POST', 'CRUD · CRUD · POST')
api('API-TEC-29', 'CRUD · POST · GET', 'CRUD · POST · GET · GET')
api('API-TEC-39', 'POST · GET · POST', 'POST · GET · POST · POST')
api('API-TEC-40', 'GET · POST', 'GET · POST · POST')
api('API-TEC-47', 'GET · POST', 'GET · PATCH · POST', 'Sí (POST con `Idempotency-Key`) |', 'Sí (POST con `Idempotency-Key`; PATCH con `If-Match`/`version`) |')

# ---- comando de OT y evento de T06
A = '`tec.workOrder.request` (antes `tec.workOrder.create`, que es alias de la capability `tec.ordenes.crear` en T02)'
d.replace_in_line('(EVT-CRM-13, comando `tec.workOrder.create`)', '`tec.workOrder.create`', A, 5)
d.replace_in_line('RF-TEC-233', 'comando `tec.workOrder.create` con prioridad', 'comando %s con prioridad' % A, 5)
d.replace_in_line('M09 registra un reclamo con subtipo `urgentSafety`', '`tec.workOrder.create`', A, 5)
d.replace_in_line('(EVT-CRM-13; comando `tec.workOrder.create`) |', '`tec.workOrder.create`', A, 5)
d.replace_in_line('(EVT-CRM-13; comando `tec.workOrder.create` con `priority=critical`', '`tec.workOrder.create`', A, 5)
d.replace_in_line('| JOB-TEC-09 |', '`int.cdr.batch-received`', '`int.cdr.batchReceived` (antes `int.cdr.batch-received`)', 6)

# ---- §7.23 resumen
d.insert_before_heading('## 8. Estados y transiciones', [
    '### 7.23 Residuales del 5-11-2026: referencias, nombres de T05 y valores de estado (%s)' % PA,
    '',
    'Ronda de residuales detectados al regenerar los entregables (categorías 1 y 2 de `_trabajo/residuales-instrucciones.md`). Las filas de §7.1 a §7.12 y de §7.22 quedaron corregidas en su lugar con "antes"; las de estado de §7.22 reemplazan la lista separada por barras (que los entregables no leían como valores) por valores explícitos. Resumen de referencias:',
    '',
    '| Colección | Campo | Tipo | Referencia | Antes |',
    '|---|---|---|---|---|',
    '| `feasibilityRequests` | `prospect` / `cancelReason` | object / string | No es referencia | sin destino |',
    '| `feasibilityRequests` | `quoteRef` | object | → M11 `salesQuotes` (`quoteRef.id`) | sin destino |',
    '| `workOrderOperationTypes` | `resultingServiceStatusId` | ObjectId | → M02 `serviceStatuses` | "estado de servicio" |',
    '| `workOrderOperationTypes` | `defaultResolutionIds` / `requiredTaskIds` | ObjectId[] | → M10 `resolutionCodes` / `taskCatalog` | sin destino |',
    '| `chainedOrderRules` | `sourceOperationTypeId` | ObjectId | → M10 `workOrderOperationTypes` | sin destino |',
    '| `chainedOrderRules` | `targetIntakeChannelId` | ObjectId | → M09 `crmChannels` | sin destino |',
    '| `fieldEvidence` | `entityType` / `entityId` | enum / ObjectId | Discriminador / polimórfica | sin destino |',
    '| `serviceConformities` | `signatureRequestId` | ObjectId | → T11 `signatureRequests` | solo en T05 |',
    '| `visits` | `assignedResourceIds` | ObjectId[] | → M10 `fieldResources` | sin destino |',
    '| `crews` | `leaderId` | ObjectId | → M10 `fieldResources` | sin destino |',
    '| `fieldDevices` | `deviceId` | UUID | No es referencia | `networkDevices` (erróneo) |',
    '| `networkComponentRelations` | `parentTypeId` / `childTypeId` | ObjectId | → M10 `networkComponentTypes` | sin destino |',
    '| `provisioningSystems` | `serviceIds` | ObjectId[] | → M02 `tenantServices` | sin destino |',
    '| `provisioningSystems` | `connectorId` (T05: `connectionId`) | ObjectId | → T06 `integrationConnections` | sin destino / `serviceNetworkConnections` |',
    '| `provisioningProfiles` | `casPackageIds` | string[] | No es referencia (códigos del CAS externo) | sin destino |',
    '| `provisioningCommands` | `compensatesCommandId` | ObjectId | → M10 `provisioningCommands` | implícita |',
    '| `phonePorts` | `ownerId` / `linkedDslamPortId` | ObjectId | Polimórfica (`phoneExchanges` · `dslams`) / → M10 `phonePorts` | sin destino / implícita |',
    '| `phoneStrips` | `ownerId` | ObjectId | Polimórfica (`phoneFrameGroups` · `phoneBoxes`) | sin destino |',
    '| `phoneStripPositions` | `previousPositionId` / `groupPositionId` / `contractId` | ObjectId | → M10 `phoneStripPositions` / → M02 `serviceContracts` | implícita / sin destino |',
    '',
    'Campos que T05 cita con otro nombre (prevalece el anexo; T05 debe reflejarlo): `workOrders.crewId` = `assignment.crewId`; `visits.crewId` = `assignedCrewId`; `resourceCalendars.crewId` = `resourceId` con `resourceType` = `crew`, y `calendarId` no existe (las excepciones se cargan en `exceptions[]`), por lo que T05 debe quitarlo; `visitBookings.workOrderId` = `targetRef.workOrderId`; `fieldEvidence.entityRef` = `entityType` + `entityId`; `fieldDevices.membershipId` = `userId`; `provisioningSystems.connectionId` = `connectorId`.',
])

# ---- §8.16
rows = []
def r(c, f, t, trig, g='—', e='—'):
    rows.append('| `%s` | %s | %s | %s | %s | %s |' % (c, f, t, trig, g, e))
N = '(nuevo)'
r('feasibilityRequests', N, '`draft`', 'Operador, socio (portal) o CRM inicia la factibilidad', '—', '—')
r('workOrders', N, '`pending`', 'Alta por administración, CRM (comando `tec.workOrder.request`), mora, campo, regla o plan', 'RF-TEC-027/028', '`tec.workOrder.created`')
r('connectionEstimates', N, '`draft`', 'Evaluador arma el cómputo')
r('connectionEstimates', '`draft`', '`submitted`', 'Envío del presupuesto a M11')
r('connectionEstimates', '`submitted`', '`accepted` · `rejected` · `expired`', 'Respuesta o vencimiento del presupuesto de M11', 'Refleja el estado del presupuesto')
r('workOrderMaterials', N, '`requested`', 'Técnico o supervisor pide material para la OT')
r('workOrderMaterials', '`requested`', '`authorized`', 'Supervisor autoriza', 'Cantidad autorizada menor o igual a la solicitada')
r('workOrderMaterials', '`authorized`', '`reserved`', 'Reserva en M13')
r('workOrderMaterials', '`reserved`', '`withdrawn`', 'Vale o entrega a custodia')
r('workOrderMaterials', '`withdrawn`', '`used`', 'Aplicación en sitio', 'Descuenta de custodia')
r('workOrderMaterials', '`withdrawn` · `used`', '`returned`', 'Devolución parcial o total del no usado')
r('workOrderMaterials', '`requested` · `authorized` · `reserved`', '`cancelled`', 'Cancelación', 'Libera la reserva')
r('damageAssessments', N, '`open`', 'Alta del reclamo por daños')
r('damageAssessments', '`open`', '`inReview`', 'Evaluación técnica o inspección')
r('damageAssessments', '`inReview`', '`approved`', 'Resolución favorable', 'Responsable con permiso')
r('damageAssessments', '`inReview`', '`rejected`', 'Resolución desfavorable', 'Motivo obligatorio')
r('damageAssessments', '`approved`', '`paid`', 'Registro del pago o crédito al socio')
r('onCallShifts', N, '`planned`', 'Alta del turno de guardia')
r('onCallShifts', '`planned`', '`active`', 'Inicio del turno')
r('onCallShifts', '`planned` · `active`', '`closed`', 'Fin o cancelación del turno', 'Cambios registrados en `changes[]`')
r('fieldForms', N, '`draft`', 'Alta del formulario')
r('fieldForms', '`draft`', '`published`', 'Publicación', 'La versión publicada no se edita')
r('fieldForms', '`published`', '`retired`', 'Publicación de la versión sucesora o retiro')
r('fieldDevices', N, '`active`', 'Enrolamiento del dispositivo del técnico')
r('fieldDevices', '`active`', '`revoked`', 'Revocación por el supervisor', 'Registra `revokedAt` y `revokedBy`; las mutaciones posteriores se rechazan')
r('syncMutations.result', N, '`received`', 'Llega la mutación del lote offline')
r('syncMutations.result', '`received`', '`applied`', 'Aplicación sin conflicto')
r('syncMutations.result', '`received`', '`duplicate`', 'Mismo `clientMutationId`', 'Devuelve el resultado original')
r('syncMutations.result', '`received`', '`conflict`', 'Versión base desactualizada con impacto', 'Crea `syncConflicts`')
r('syncMutations.result', '`received`', '`rejected`', 'Permiso o validación dura')
r('syncMutations.result', '`received`', '`deferred`', 'Dependencia aún no recibida en el lote')
r('syncMutations.result', '`deferred`', '`applied` · `conflict` · `rejected`', 'Reintento en el mismo lote')
r('syncConflicts', N, '`open`', 'Mutación en conflicto')
r('syncConflicts', '`open`', '`inReview`', 'Asignación al supervisor')
r('syncConflicts', '`inReview`', '`resolved`', 'Resolución (`acceptField`, `acceptServer`, `merge`, `compensate`, `newWorkOrder`)', 'Nunca se borra la evidencia')
r('syncConflicts', '`open` · `inReview`', '`dismissed`', 'Descarte sin impacto')
r('outagePlans', N, '`draft`', 'Alta de la interrupción planificada')
r('outagePlans', '`draft`', '`approved`', 'Aprobación del responsable')
r('outagePlans', '`approved`', '`notified`', 'Aviso masivo con constancia')
r('outagePlans', '`notified`', '`inProgress`', 'Inicio real')
r('outagePlans', '`inProgress`', '`completed`', 'Fin real con informe')
r('outagePlans', '`draft` · `approved` · `notified`', '`cancelled`', 'Cancelación', 'Aviso de cancelación si ya estaba notificada')
r('networkElements', N, '`planned`', 'Alta del elemento proyectado')
r('networkElements', N, '`notApplicable`', 'Alta de un elemento sin disponibilidad propia (tipo sin conexiones de servicio)')
r('networkElements', '`planned`', '`available`', 'Habilitación del elemento')
r('networkElements', '`available`', '`used`', 'Primera conexión vigente')
r('networkElements', '`used`', '`available`', 'Baja de la última conexión')
r('networkElements', '`available` · `used`', '`damaged`', 'Registro de daño')
r('networkElements', '`damaged`', '`available`', 'Reparación')
r('networkElements', '`available` · `damaged` · `notApplicable`', '`retired`', 'Retiro', 'Sin conexiones vigentes ni hijos activos')
r('serviceNetworkConnections', N, '`connected`', 'Conexión del servicio a la red')
r('serviceNetworkConnections', '`connected`', '`disconnected`', 'Desconexión con fecha', 'La reconexión crea una conexión nueva (historial)')
r('provisioningSystems', N, '`active`', 'Alta del sistema de aprovisionamiento')
r('provisioningSystems', '`active`', '`disabled`', 'Deshabilitación', 'Sin comandos en `queued` o `sending`')
r('provisioningSystems', '`disabled`', '`active`', 'Rehabilitación', 'Prueba del conector exitosa (T06)')
r('serviceTechnicalProfiles.provisioningStatus', N, '`notProvisioned`', 'Alta del perfil técnico del servicio')
r('serviceTechnicalProfiles.provisioningStatus', '`notProvisioned` · `suspended` · `error`', '`active`', 'Comando de alta o reconexión confirmado', '—', '`tec.provisioning.confirmed`')
r('serviceTechnicalProfiles.provisioningStatus', '`active`', '`suspended`', 'Comando de suspensión confirmado', '—', '`tec.provisioning.confirmed`')
r('serviceTechnicalProfiles.provisioningStatus', '`active` · `suspended`', '`deactivated`', 'Comando de baja confirmado', '—', '`tec.provisioning.confirmed`')
r('serviceTechnicalProfiles.provisioningStatus', '`notProvisioned` · `active` · `suspended`', '`error`', 'Comando fallido', '—', '`tec.provisioning.failed`')
r('providedMailboxes', N, '`active`', 'Alta de la casilla con el servicio')
r('providedMailboxes', '`active`', '`suspended`', 'Suspensión (por ejemplo, orden de M08)')
r('providedMailboxes', '`suspended`', '`active`', 'Reconexión')
r('providedMailboxes', '`active` · `suspended`', '`deleted`', 'Baja del servicio', 'Las credenciales no se conservan')
r('works', N, '`draft`', 'Alta de la obra')
r('works', '`draft`', '`budgeted`', 'Presupuesto cargado')
r('works', '`budgeted`', '`approved`', 'Aprobación', 'Base de aprobación cargada')
r('works', '`approved`', '`inProgress`', 'Inicio de la obra')
r('works', '`inProgress`', '`finished`', 'Fin de la obra')
r('works', '`inProgress` · `finished`', '`levyProposed`', 'Propuesta de contribución por mejoras', 'Obra con contribución')
r('works', '`levyProposed`', '`levyApproved`', 'Aprobación de la contribución')
r('works', '`levyApproved`', '`billing`', 'Envío a facturación (M05/M08)')
r('works', '`billing` · `finished`', '`closed`', 'Cierre', 'Con contribución, facturación terminada')
r('works', '`draft` · `budgeted`', '`cancelled`', 'Cancelación')
r('inspectionCases', N, '`suspected`', 'Alta del caso por sospecha')
r('inspectionCases', '`suspected`', '`inspectionOrdered`', 'OT de inspección')
r('inspectionCases', '`inspectionOrdered`', '`inspected`', 'Cierre de la OT de inspección')
r('inspectionCases', '`inspected`', '`noIrregularity`', 'Sin irregularidad')
r('inspectionCases', '`noIrregularity`', '`closed`', 'Cierre')
r('inspectionCases', '`inspected`', '`irregularityConfirmed`', 'Irregularidad confirmada')
r('inspectionCases', '`irregularityConfirmed`', '`userNotified`', 'Notificación al usuario')
r('inspectionCases', '`userNotified`', '`defenseReceived` · `defenseExpired`', 'Descargo recibido o plazo vencido')
r('inspectionCases', '`defenseReceived` · `defenseExpired`', '`recoveryProposed`', 'Propuesta de recupero')
r('inspectionCases', '`recoveryProposed`', '`recoveryApproved` · `recoveryRejected`', 'Decisión sobre el recupero')
r('inspectionCases', '`recoveryApproved`', '`billed`', 'Facturación del recupero')
r('inspectionCases', '`billed`', '`regularized`', 'Regularización')
r('inspectionCases', '`regularized` · `recoveryRejected`', '`closed`', 'Cierre')
r('inspectionCases', 'cualquiera no final', '`annulled`', 'Anulación', 'Motivo y aprobación')
r('seals', N, '`available`', 'Alta del lote de precintos')
r('seals', '`available`', '`assigned`', 'Entrega al inspector (`assignedTo`)')
r('seals', '`assigned`', '`placed`', 'Colocación (`placement`)')
r('seals', '`placed`', '`removed`', 'Retiro con motivo (`removal`)')
r('seals', '`placed`', '`broken`', 'Hallado violado en inspección')
r('seals', '`available` · `assigned`', '`voided`', 'Anulación o extravío', 'Motivo obligatorio')
r('phonePorts', N, '`available`', 'Alta del puerto')
r('phonePorts', '`available`', '`unavailable`', 'Conexión del puerto')
r('phonePorts', '`unavailable`', '`available`', 'Liberación del puerto')
r('phonePorts', '`available` · `unavailable`', '`inactive`', 'Baja (`INACTIVO`)')
r('phonePorts', '`inactive`', '`available`', 'Rehabilitación')
r('phoneStripPositions', N, '`available`', 'Alta de la posición')
r('phoneStripPositions', '`available`', '`reserved`', 'OT de instalación')
r('phoneStripPositions', '`reserved`', '`connected`', 'Cierre de la OT', 'Registra `contractId`')
r('phoneStripPositions', '`reserved`', '`available`', 'OT cancelada')
r('phoneStripPositions', '`connected`', '`available`', 'Desconexión o traslado', 'La posición nueva guarda `previousPositionId`')
r('phoneStripPositions', '`available` · `connected`', '`damaged`', 'Registro de daño')
r('phoneStripPositions', '`damaged`', '`available`', 'Reparación')
r('phoneNumbers', N, '`available`', 'Alta del número en la numeración')
r('phoneNumbers', '`available`', '`reserved`', 'OT')
r('phoneNumbers', '`reserved`', '`assigned`', 'Asignación a una línea')
r('phoneNumbers', '`assigned`', '`quarantine`', 'Baja de la línea', 'Plazo configurable')
r('phoneNumbers', '`quarantine`', '`available`', 'Fin de la cuarentena')
r('phoneNumbers', '`available`', '`retired`', 'Retiro')
r('phoneLines', N, '`active`', 'Alta de la línea')
r('phoneLines', '`active`', '`closed`', 'Baja de la línea')
r('cdrImports', N, '`uploaded`', 'Subida del archivo o `int.cdr.batchReceived` (EVT-INT-16)', '`fileHash` no repetido')
r('cdrImports', '`uploaded`', '`parsing`', 'Inicio de JOB-TEC-09')
r('cdrImports', '`parsing`', '`parsed` · `withErrors`', 'Fin del parseo', 'Con fila de error se aborta el archivo')
r('cdrImports', '`parsed`', '`attributed`', 'Atribución de llamadas')
r('cdrImports', '`attributed`', '`sentToRating`', 'Pedido de tasación')
r('cdrImports', '`sentToRating`', '`rated`', 'Tasación terminada')
r('cdrImports', '`rated`', '`grouped`', 'Agrupación por M05')
r('cdrImports', '`parsed` · `attributed` · `rated`', '`rolledBack`', 'Reversión', 'Ninguna llamada agrupada')
r('callRecords.attributionStatus', N, '`attributed` · `originNotFound` · `destinationNotFound` · `duplicate`', 'Atribución en la importación')
r('callRecords.attributionStatus', '`originNotFound` · `destinationNotFound`', '`attributed`', 'Reintento de atribución tras dar de alta el número')
r('callRecords.attributionStatus', '`originNotFound` · `destinationNotFound`', '`manual`', 'Atribución manual por el operador')
r('mobileUsageImports', N, '`received`', 'Carga manual (`importedBy`) o EVT-INT-24 de T06 (`kind = ticQuota`)')
r('mobileUsageImports', '`received`', '`parsed` · `withErrors`', 'Fin del parseo')
r('mobileUsageImports', '`parsed`', '`attributed`', 'Atribución de líneas a contratos')
r('mobileUsageImports', '`attributed`', '`applied`', 'Consumos enviados a M04/M05')
r('mobileUsageImports', '`parsed` · `attributed`', '`rolledBack`', 'Reversión', 'Sin consumos aplicados')
r('numberPortings', N, '`requested`', 'Portación entrante pedida por el socio', 'Dirección entrante')
r('numberPortings', '`requested`', '`submitted`', 'Envío al operador donante')
r('numberPortings', '`submitted`', '`accepted` · `rejected`', 'Respuesta del operador donante', '`rejectionReason` si se rechaza')
r('numberPortings', '`accepted`', '`scheduled`', 'Ventana acordada (`scheduledWindow`)')
r('numberPortings', '`scheduled`', '`executed`', 'Portación ejecutada (`executedAt`)')
r('numberPortings', '`requested` · `submitted` · `accepted` · `scheduled`', '`cancelled`', 'Cancelación', 'Dirección entrante')
r('numberPortings', N, '`received`', 'Pedido de portación saliente del operador receptor', 'Dirección saliente')
r('numberPortings', '`received`', '`validated`', 'Validación del titular y la línea')
r('numberPortings', '`received` · `validated`', '`rejected`', 'Validación fallida', '`rejectionReason`')
r('numberPortings', '`validated`', '`accepted`', 'Aceptación')
r('numberPortings', '`accepted`', '`executed`', 'Portación ejecutada', 'Dirección saliente')
r('waterSamples', N, '`taken`', 'Toma de la muestra')
r('waterSamples', '`taken`', '`inLab`', 'Ingreso al laboratorio')
r('waterSamples', '`inLab`', '`resulted`', 'Carga del resultado')
r('waterSamples', '`resulted`', '`actionPending`', 'Resultado fuera de límite', '`outOfLimit` = true')
r('waterSamples', '`resulted`', '`closed`', 'Resultado dentro de límite')
r('waterSamples', '`actionPending`', '`closed`', 'Acciones correctivas hechas', 'Todas las `correctiveActions` con `doneAt`')
d.insert_before_heading('## 9. Procesos y flujos', [
    '### 8.16 Máquinas completadas y altas explícitas (residuales del 5-11-2026, %s)' % PA,
    '',
    'Completa las colecciones que los entregables excluyeron por no tener valores legibles en §7.22 (INC-06-01), las que tenían estados sin transiciones (INC-06-02) y las máquinas que daban el estado inicial solo en texto (INC-06-08). Traslada a tabla, sin cambiar su contenido, las máquinas en texto de §8.6 a §8.8 y §8.10 a §8.14. Las filas `(nuevo)` fijan el estado inicial. Valores asumidos en %s (DEC-072); coinciden con §7.22. Prevalece esta tabla sobre el texto de las secciones citadas cuando difieran.' % PA,
    '',
    '| Colección | Desde | Hacia | Disparador | Guarda | Evento |',
    '|---|---|---|---|---|---|',
] + rows)
d.count(1, len(rows))

d.insert_before_heading('## 22. Trazabilidad de fuentes', [
    '### %s — Residuales de los entregables: referencias, estados, rutas de API, comando de OT y alias (5-11-2026)' % PA,
    '- **Pregunta**: ¿Qué destino tienen las referencias que los entregables marcaron sin colección en M10 (§7.23), qué valores y transiciones tienen las colecciones excluidas o sin estado inicial explícito, cómo se alinean los grupos de método de API-TEC-26, 29, 39, 40 y 47 con sus rutas, qué nombre tiene el comando con que M09 pide una OT y cómo se nombra el evento `int.cdr.batch-received`?',
    '- **Contexto**: residuales de `docs/entregables-analisis-diseno/03-er/M10-TEC-tecnica-campo-redes-parte2.md` §7, de `06a-indice-cobertura-secuencias-estados.md` §7 (INC-06-01, 02, 08, 11) y de `18-openapi/_inconsistencias.md` (grupos de método). El comando `tec.workOrder.create` coincidía con un alias de la capability `tec.ordenes.crear` de T02.',
    '- **Opciones**: A) **(Recomendada)** Destinos de §7.23, máquinas de §8.16, un grupo de método por ruta en el mismo orden, comando `tec.workOrder.request` (el que M09 ya emite y paralelo a `tec.feasibility.request`) y evento `int.cdr.batchReceived` (regla de guiones a camelCase; alias `int.cdr.batch-received`). B) Mantener `[VERIFICAR]`, los grupos de método anteriores y `tec.workOrder.create`.',
    '- **Impacto si no se responde**: A.',
    '- **Bloquea**: diagrama ER, diagramas de estados y contrato OpenAPI de M10; T05 COL-TEC-12, 14, 15, 20, 21, 22, 28 y 42 y §7.2.1; alias de T11 §12.4.',
    '- **Estado**: Asumida (DEC-072): opción A. Aplicado en §2, §5 (RF-TEC-233), §7.1 a §7.12, §7.22, §7.23, §8.16, §9.11.1, §11 y §12. T05 debe reflejar las equivalencias de §7.23 y en §7.2.1 `prospect`, `cancelReason`, `entityType`, `casPackageIds` y `fieldDevices.deviceId` como "no es referencia". T11 debe registrar el alias `int.cdr.batch-received` → `int.cdr.batchReceived` en §12.4 y el comando `tec.workOrder.request` en el payload de EVT-CRM-13.',
    '',
])
d.count(9, 1)
d.save()
report()
