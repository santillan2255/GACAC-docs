﻿import os, sys
sys.path.insert(0, os.path.dirname(__file__))
from res_lib_m12m19 import Doc

d = Doc('M17-INS-institucional.md')
A = '(antes `%s`)'

# ---- Categoría 6: tipos de evento
d.rep('| EVT-INS-13 | `ins.surplus.distribution.approved` / `.executed` |',
      '| EVT-INS-13 | `ins.surplusDistribution.approved` / `.executed` (antes `ins.surplus.distribution.approved` / `.executed`) |', cat=6)
ren = [('ins.capital.movement.recorded', 'ins.capitalMovement.recorded'),
       ('ins.capital.movement.reversed', 'ins.capitalMovement.reversed'),
       ('ins.capital.transfer.executed', 'ins.capitalTransfer.executed'),
       ('ins.capital.refund.approved', 'ins.capitalRefund.approved'),
       ('ins.capital.refund.paid', 'ins.capitalRefund.paid'),
       ('ins.surplus.distribution.approved', 'ins.surplusDistribution.approved'),
       ('ins.surplus.distribution.executed', 'ins.surplusDistribution.executed'),
       ('ins.inaes.report.submitted', 'ins.inaesReport.submitted')]
for old, new in ren:
    k = d.t.count('`%s`' % old) - d.t.count('(antes `%s`' % old)
    d.t = d.t.replace('(antes `%s`' % old, '\x00ANTES%s\x00' % old)
    d.t = d.t.replace('`%s`' % old, '`%s` (antes `%s`)' % (new, old))
    d.t = d.t.replace('\x00ANTES%s\x00' % old, '(antes `%s`' % old)
    d.n += 1
    print(old, k)
d.insert_after('Los identificadores `ins.capital.closed`, `ins.refund.annualLimitReached`, `ins.meeting.reserved` e `ins.vote.closed` son **códigos de error RFC 9457** de §11, no tipos de evento; las entradas CNC-WFL-123 a CNC-WFL-126 de T11 §12.4.1 no requieren alias ni evento nuevo.',
               '\n\nTipos de evento renombrados a la convención `<mod>.<agregado>.<hecho>` (residuales del 05-11-2026, PA-INS-13): los de cuatro segmentos unen el 2.º y el 3.º en camelCase. `ins.capitalMovement.recorded` / `.reversed` (EVT-INS-08/09), `ins.capitalTransfer.executed` (EVT-INS-10), `ins.capitalRefund.approved` / `.paid` (EVT-INS-11/12), `ins.surplusDistribution.approved` / `.executed` (EVT-INS-13) e `ins.inaesReport.submitted` (EVT-INS-21); los nombres anteriores (`ins.capital.movement.*`, `ins.capital.transfer.executed`, `ins.capital.refund.*`, `ins.surplus.distribution.*`, `ins.inaes.report.submitted`) quedan como alias en T11 §12.4 y no se usan en suscripciones nuevas.', cat=6)

# ---- Categoría 4: nombres de campo (capitalTransfers, proxies, reingreso, archivos)
d.rep('Campos: `fromMembershipId`, `toMembershipId`, `amount`',
      'Campos: `fromAssociateMembershipId` (antes `fromMembershipId`), `toAssociateMembershipId` (antes `toMembershipId`), `amount`', cat=4)
d.rep('| `fromMembershipId` | ObjectId | Sí | Asociado cedente; no es `memberships` de T02. |',
      '| `fromAssociateMembershipId` | ObjectId | Sí | Asociado cedente; no es `memberships` de T02. Antes `fromMembershipId` (T05 §7.2, PA-INS-12). |', cat=4)
d.rep('| `toMembershipId` | ObjectId | Sí | Asociado cesionario; no es `memberships` de T02. |',
      '| `toAssociateMembershipId` | ObjectId | Sí | Asociado cesionario; no es `memberships` de T02. Antes `toMembershipId` (T05 §7.2, PA-INS-12). |', cat=4)
d.rep('Campos: `meetingId`, `grantorMembershipId`, `proxyMembershipId`, `documentId`, `status` (`submitted`, `validated`, `rejected`, `revoked`), `validatedBy`, `rejectionReason`. Índice `{tenantId, meetingId, grantorMembershipId}` único parcial (no revocados).',
      'Campos: `meetingId`, `grantorAssociateMembershipId` (antes `grantorMembershipId`), `proxyAssociateMembershipId` (antes `proxyMembershipId`), `documentId`, `status` (`submitted`, `validated`, `rejected`, `revoked`), `validatedBy`, `rejectionReason`. Índice `{tenantId, meetingId, grantorAssociateMembershipId}` único parcial (no revocados; antes `grantorMembershipId`).', cat=4)
d.rep('| `grantorMembershipId` | ObjectId | Sí | Asociado que otorga el poder; no es `memberships` de T02. |',
      '| `grantorAssociateMembershipId` | ObjectId | Sí | Asociado que otorga el poder; no es `memberships` de T02. Antes `grantorMembershipId` (T05 §7.2, PA-INS-12). |', cat=4)
d.rep('| `proxyMembershipId` | ObjectId | Sí | Asociado apoderado; no es `memberships` de T02. |',
      '| `proxyAssociateMembershipId` | ObjectId | Sí | Asociado apoderado; no es `memberships` de T02. Antes `proxyMembershipId` (T05 §7.2, PA-INS-12). |', cat=4)
d.rep('| `reentryOfMembershipId` | ObjectId | No | Membresía anterior en reingresos. |',
      '| `reentryOfAssociateMembershipId` | ObjectId | No | Membresía anterior en reingresos. Antes `reentryOfMembershipId` (PA-INS-12, PA-INS-13). |', cat=4)
# egreso: fila conjunta separada para que cada campo tenga su referencia
d.rep('| `exitDate`, `exitCause`, `exitCauseDetail`, `exitMinuteId` | Date / Enum / String / ObjectId | Cond. | Egreso. `exitCause`: `resignation`, `exclusion`, `death`, `dissolution`, `transferOfAllShares`, `other`. | `minutes` (M17) |',
      '| `exitDate` | Date | Cond. | Egreso (antes en una fila conjunta con `exitCause`, `exitCauseDetail` y `exitMinuteId`). | — |\n'
      '| `exitCause` | Enum | Cond. | `resignation`, `exclusion`, `death`, `dissolution`, `transferOfAllShares`, `other`. | — (valor enumerado, no es referencia) |\n'
      '| `exitCauseDetail` | String | Cond. | Detalle libre de la causa. | — (texto, no es referencia) |\n'
      '| `exitMinuteId` | ObjectId | Cond. | Acta que resolvió el egreso. | `minutes` (M17) |', cat=2)
# capitalMovements.legalEntityId (T05)
d.rep('| `journalEntryRef` | ObjectId → M15 | No | — | `journalEntries` (M15) |\n| `legacy` | { `codCap`, `codCapRes` } | No | — | — |',
      '| `journalEntryRef` | ObjectId → M15 | No | — | `journalEntries` (M15) |\n| `legalEntityId` | ObjectId | Sí | Entidad jurídica del movimiento (T05 §7.2 y regla de `legalEntityId` obligatorio en `capitalMovements`; agregado en PA-INS-13). | `legalEntities` (T04) |\n| `legacy` | { `codCap`, `codCapRes` } | No | — | — |', cat=4)
# archivos -> storedFileId
d.rep('| `replacesCertificateId` | ObjectId | [VERIFICAR] | — | `shareCertificates` (M17) |\n| `pdfObjectKey` | String | [VERIFICAR] | — | — |',
      '| `replacesCertificateId` | ObjectId | [VERIFICAR] | — | `shareCertificates` (M17) |\n| `storedFileId` | ObjectId | No | PDF del título. Antes `pdfObjectKey` (T05 §7.2, PA-INS-13). | `storedFiles` (T01) |', cat=4)
d.rep('| `pdfObjectKey` | String | [VERIFICAR] | `CONTENIDO_PDF` se migra a almacenamiento de objetos. | — |',
      '| `storedFileId` | ObjectId | No | PDF del acta; `CONTENIDO_PDF` se migra a almacenamiento de objetos. Antes `pdfObjectKey` (T05 §7.2, PA-INS-13). | `storedFiles` (T01) |', cat=4)
d.rep('| `folioTo` | Date | [VERIFICAR] | — | — |\n| `pdfObjectKey` | String | [VERIFICAR] | — | — |',
      '| `folioTo` | Date | [VERIFICAR] | — | — |\n| `storedFileId` | ObjectId | No | PDF de la edición. Antes `pdfObjectKey` (T05 §7.2, PA-INS-13). | `storedFiles` (T01) |', cat=4)
d.rep('| `files` | [Object] | [VERIFICAR] | Lista; subcampos: `objectKey`, `hash`. | — |',
      '| `files` | [Object] | [VERIFICAR] | Lista; subcampos: `objectKey`, `hash`. El archivo se referencia por `storedFileIds` (antes `files[].objectKey`); `hash` se conserva para control. | — |\n| `storedFileIds` | [ObjectId] | No | Archivos del lote presentado (T05 §7.2, PA-INS-13). | `storedFiles` (T01) |', cat=4)

# ---- Categoría 2: referencias sin destino
d.rep("| `productGroupIds` | [ObjectId] → M02 rubros | No | `COD_RUB`; cada rubro de producto aparece en un solo `capitalItem` (RN-INS-012). | [VERIFICAR] |",
      "| `productGroupIds` | [ObjectId] → M02 rubros | No | `COD_RUB`; cada rubro de producto aparece en un solo `capitalItem` (RN-INS-012). | `accountRubrics` (M15): el mismo rubro que `billableConcepts.accountingRubricId` de M02 (ex `COD_RUB`); antes `[VERIFICAR]` (PA-INS-13) |", cat=2)
d.rep("| `documentRef` | Object | [VERIFICAR] | Subcampos: `typeId` (PRM-INS-022), `pointOfSale`, `number`. | — |",
      "| `documentRef` | Object | [VERIFICAR] | Subcampos: `typeId` (PRM-INS-022), `pointOfSale`, `number`. | No es referencia: número del comprobante; `typeId` → `voucherTypes` (M05) |", cat=2)
d.rep("| `receiptRef` | Object | [VERIFICAR] | Subcampos: `pointOfSale`, `number`. | — |",
      "| `receiptRef` | Object | [VERIFICAR] | Subcampos: `pointOfSale`, `number`. | No es referencia: número del recibo de M07 |", cat=2)
d.rep("| `documentRef` | { `typeId`, `number` } | Cond. | Comprobante de rescate (PRM-INS-025). | — |",
      "| `documentRef` | { `typeId`, `number` } | Cond. | Comprobante de rescate (PRM-INS-025). | No es referencia: número del comprobante; `typeId` → `voucherTypes` (M05) |", cat=2)
d.rep("| `creditRef` | ObjectId | [VERIFICAR] | — | [VERIFICAR] crédito en cuenta corriente (M07) |",
      "| `creditRef` | ObjectId | [VERIFICAR] | Crédito en cuenta corriente cuando la forma es `accountCredit`. | `creditBalances` (M07); antes `[VERIFICAR]` (PA-INS-13) |", cat=2)
d.rep("| `savedFilterSetId` | ObjectId | [VERIFICAR] | — | [VERIFICAR] filtro guardado (T03) |",
      "| `savedFilterSetId` | ObjectId | [VERIFICAR] | Conjunto de filtros guardado del padrón (PRM-INS-049). | `dataTableViews` (T03), vista compartida de la grilla del padrón; antes `[VERIFICAR] filtro guardado (T03)` (PA-INS-13) |", cat=2)
d.rep("| `withholdingRef` | ObjectId | [VERIFICAR] | M06. | M06, colección [VERIFICAR] |",
      "| `withholdingRef` | ObjectId | [VERIFICAR] | M06. | `withholdingsApplied` (M06); antes \"M06, colección [VERIFICAR]\" (PA-INS-13) |", cat=2)
d.rep("| `paymentOrderRef` | ObjectId | [VERIFICAR] | M14. | `paymentOrders` (M12) [VERIFICAR] (el anexo cita M14) |",
      "| `paymentOrderRef` | ObjectId | [VERIFICAR] | M14. | `paymentOrders` (M12); M14 ejecuta el pago (antes `[VERIFICAR] (el anexo cita M14)`, PA-INS-13) |", cat=2)
d.rep("| `templateId` | ObjectId | [VERIFICAR] | `Credencial_Tipo`. | [VERIFICAR] plantilla de credencial (`Credencial_Tipo`) |",
      "| `templateId` | ObjectId | [VERIFICAR] | `Credencial_Tipo`. | `documentTemplates` (T11), según T05 §7.2.1; antes `[VERIFICAR] plantilla de credencial` (PA-INS-13) |", cat=2)

# ---- Categoría 1: estados
d.rep('| `fromStatus` / `toStatus` | Enum | No | — | — |',
      '| `fromStatus` / `toStatus` | Enum | No | Valores de `associateMemberships.status` (§7.1); registran la transición de §8.1, sin máquina propia (PA-INS-13). | — |', cat=1)
d.rep('### 8.1 Membresía\n\n|', '### 8.1 Membresía (`associateMemberships.status`)\n\nEstado inicial: `applicant` (PRM-INS-005 define si al aprobar pasa a `active` o queda en `pendingApproval`; PA-INS-13).\n\n|', cat=1)
ini = [('### 8.2 Movimiento de capital\n\n', 'capitalMovements.status', 'pending'),
       ('### 8.4 Transferencia de capital\n\n', 'capitalTransfers.status', 'draft'),
       ('### 8.5 Distribución de excedentes\n\n', 'surplusDistributions.status', 'draft'),
       ('### 8.6 Reunión\n\n', 'meetings.status', 'draft'),
       ('### 8.7 Acta\n\n', 'minutes.signatureStatus', 'draft'),
       ('### 8.9 Votación\n\n', 'votingSessions.status', 'open'),
       ('### 8.11 Honorario liquidado\n\n', 'institutionalFeeSettlements.status', 'draft'),
       ('### 8.12 Informe INAES\n\n', 'inaesReports.status', 'draft')]
for anchor, fld, st in ini:
    d.insert_after(anchor, 'Estado inicial de `%s`: `%s` (alta → `%s`; PA-INS-13).\n\n' % (fld, st, st), cat=1)

# ---- servicio sin invocador (falso positivo: es un parámetro)
d.rep('| PRM-INS-006 | `ins.service.requiresActiveMembership` | Bool | servicio | false | El servicio solo se contrata con membresía activa. | 734 |',
      '| PRM-INS-006 | `ins.service.requiresActiveMembership` | Bool | servicio | false | El servicio solo se contrata con membresía activa. Es un parámetro, no un servicio interno: lo consulta M02 al dar de alta el contrato (RF-INS-009, PA-INS-13). | 734 |', cat=1)

# ---- PA
d.insert_before('## 22. Trazabilidad', '''### PA-INS-13 — Residuales del 05-11-2026 (estados, referencias, nombres de campo y tipos de evento)

**Pregunta:** ¿Cómo se cierran los residuales que detectaron los entregables regenerados (estados, referencias sin destino, nombres de T05 y tipos de evento fuera de convención)?
**Contexto:** el índice de secuencias y estados, el modelo entidad-relación y el catálogo de eventos marcaron en M17 máquinas sin estado inicial, `associateMemberships` sin transiciones (el §8.1 no nombraba la colección), referencias sin destino, nombres que difieren de T05 §7.2 y ocho tipos de evento de cuatro segmentos.
**Opciones:**
- A) **(Recomendada)** Explicitar el estado inicial de cada máquina; titular el §8.1 con `associateMemberships.status`; declarar destinos (`productGroupIds` → `accountRubrics` de M15, como `billableConcepts.accountingRubricId` de M02; `creditRef` → `creditBalances` de M07; `withholdingRef` → `withholdingsApplied` de M06; `savedFilterSetId` → `dataTableViews` de T03; `templateId` → `documentTemplates` de T11; `documentRef`/`receiptRef` no son referencias); adoptar los nombres de T05 (`fromAssociateMembershipId`, `toAssociateMembershipId`, `grantorAssociateMembershipId`, `proxyAssociateMembershipId`, `reentryOfAssociateMembershipId`, `storedFileId`/`storedFileIds` en lugar de `pdfObjectKey`/`files[].objectKey`, `legalEntityId` en `capitalMovements`); renombrar los eventos a `ins.capitalMovement.*`, `ins.capitalTransfer.executed`, `ins.capitalRefund.*`, `ins.surplusDistribution.*` e `ins.inaesReport.submitted`, con el nombre anterior como alias.
- B) Mantener los nombres actuales y documentar las diferencias en T05 y T11.
**Impacto si no se responde:** se aplica A.
**Bloquea:** §7, §8, §12.1; consumidores de EVT-INS-08 a 13 (M01, M05, M07, M14, M15, M19, T09) y de EVT-INS-21 (T11).
**Estado:** Asumida la recomendada (DEC-072). `fromStatus`/`toStatus` de `membershipEvents` toman los valores de `associateMemberships.status`. PRM-INS-006 es un parámetro que consulta M02, no un servicio interno. T05 debe reflejar `reentryOfAssociateMembershipId`, `storedFileId` en `shareCertificates`, `minutes` y `associateRegisterEditions`, y los destinos nuevos; T11 debe registrar los alias de evento en §12.4.

''', cat=0)
d.save()
