"""Genera las tablas de campos del §7 para colecciones que solo tienen definición en texto.

Uso: python res_tablas.py preview|apply
Fuente: el texto del anexo y T05 (a través del modelo del generador del ER).
"""
import sys, os, re, json, io, contextlib, glob, difflib
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo')
import generar_er_completo as G

ROOT = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
OA = r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\18-openapi'
MINE = {'T01': 'PA-PLA-15', 'T02': 'PA-IAM-18', 'T03': 'PA-UXD-18', 'T04': 'PA-CFG-15',
        'T06': 'PA-INT-27', 'T07': 'PA-MIG-21', 'T08': 'PA-NFR-24', 'T10': 'PA-BIA-17'}

buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    rows, by_id, by_name, model, vol, ttl, alt = G.build()

falt = set()
for f in sorted(glob.glob(os.path.join(OA, '*esquemas*.yaml'))):
    t = open(f, encoding='utf-8').read()
    for b in re.split(r'\n    (?=[A-Za-z_]+:\n)', t):
        if 'additionalProperties: true' in b:
            m = re.search(r'COL-[A-Z]{3}-\d+', b)
            if m:
                falt.add(m.group(0))

TYPE_MAP = {'any': 'string', 'array': 'array', 'enum': 'enum', 'object': 'object', 'Period': 'string (período `AAAA-MM`)'}


def clean_desc(d, typ_raw):
    d = (d or '').strip()
    if typ_raw and d.endswith(typ_raw):
        d = d[: -len(typ_raw)].strip()
    d = d.replace('|', '/').replace('\n', ' ')
    d = re.sub(r'\s+', ' ', d).strip(' ,;')
    return d


RENAME = {('supportSessions', 'grantId'): 'supportAccessGrantId', ('jobRuns', 'bullJobId'): 'jobId',
          ('sessions', 'familyId'): 'refreshFamilyId', ('auditAi', 'promptTemplateId'): 'promptTemplateCode',
          ('aiQuestions', 'catalogQuestionId'): 'catalogQuestionCode', ('migrationMappingRules', 'ruleId'): 'ruleCode',
          ('integrationFileExchanges', 'externalTransactionId'): 'externalTransactionNumber'}
FKOVR = {('tenantModuleActivations', 'checklistSnapshotId'): 'tenantChecklists', ('supportCases', 'grantIds'): 'supportAccessGrants',
         ('supportSessions', 'supportAccessGrantId'): 'supportAccessGrants', ('platformIncidents', 'linkedCaseIds'): 'supportCases',
         ('integrationConnections', 'fallbackConnectionIds'): 'integrationConnections',
         ('integrationContingencies', 'closingReconciliationId'): 'integrationReconciliations',
         ('migrationProjects', 'acceptanceActId'): 'documents', ('legacySnapshots', 'baseSnapshotId'): 'legacySnapshots',
         ('migrationMappingSets', 'baseSetId'): 'migrationMappingSets', ('parallelRuns', 'goodappsBatchId'): 'billingRuns',
         ('cutoverPlans', 'finalSnapshotId'): 'legacySnapshots', ('privacyNotices', 'purposesCovered'): 'processingActivities',
         ('consentRecords', 'noticeId'): 'privacyNotices', ('indicatorSnapshots', 'scenarioId'): 'simulationScenarios',
         ('kpiAlertRules', 'indicatorId'): 'indicatorDefinitions', ('customReports', 'templateOriginId'): 'customReports',
         ('authorizationRequests', 'consumedRequestId'): 'auditLogs', ('federatedLinks', 'idpConfigId'): 'identityProviderConfigs',
         ('sessions', 'supportGrantId'): 'supportAccessGrants', ('tenantDictionaryEntries', 'draftOf'): 'tenantDictionaryEntries'}
NUM = re.compile(r'(Count|Bytes|Seconds|Minutes|Hours|Days|Failures|Attempts|Ms|Size|Order|Retries|Number)$')
DEC = re.compile(r'(amount|price|rate|cost|total|balance|quantity|value|percent|factor|tolerance|limit|numerator|denominator)', re.I)


def tipo(f, name):
    t = f.get('type') or 'any'
    d = (f.get('desc') or '').strip()
    enum_like = re.fullmatch(r'(`[^`]+`\s*(\\?[/|,]|\\\|)\s*)+`[^`]+`', d.replace('\\/', '/'))
    if name in G.NON_FK and 'ObjectId' in t:
        t = 'string'
    if (NUM.search(name) or name in ('count', 'order', 'attempts', 'priority', 'tokensIn', 'tokensOut', 'latencyMs')) and t in ('string', 'array', 'any'):
        t = 'int'
    if t == 'Decimal128' and not DEC.search(name) and not d.lower().startswith(('decimal', 'money')):
        t = 'object' if '{' in d else 'string'
    if t == 'GeoJSON' and not re.search(r'geo|location|geometry|shape|point', name, re.I):
        t = 'enum' if enum_like else 'string'
    if enum_like and t in ('string', 'any', 'array'):
        t = 'enum'
    t = TYPE_MAP.get(t, t)
    if t.endswith('[]') and t not in ('ObjectId[]',):
        base = TYPE_MAP.get(t[:-2], t[:-2])
        t = 'array de ' + base
    if t == 'ObjectId[]':
        t = 'array de ObjectId'
    return t


def oblig(name, f, ent):
    o = (f.get('oblig') or '').strip()
    if o:
        o2 = G.strip_accents(o.lower())
        if o2.startswith('si'):
            return 'Sí'
        if o2.startswith('no'):
            return 'No'
    uniq = {x for fs, _ in ent.get('uniques', []) for x in fs}
    if name in uniq or name in ('status', 'code', 'name') or f.get('src') == 'T05':
        return 'Sí'
    return 'No'


def fila(name, f, ent, coll=None):
    fk = FKOVR.get((coll, name)) or f.get('fk')
    ref = '—'
    d = clean_desc(f.get('desc'), '')
    if f.get('antes'):
        d = (d + '; ' if d else '') + 'antes `%s` en el texto del §7 (nombre canónico de T05)' % f['antes']
    if fk:
        own = by_name.get(fk, {}).get('owner', '')
        ref = '`%s`%s' % (fk, (' (%s)' % own) if own else '')
        if '`%s`' % fk not in d:
            d = (d + '; ' if d else '') + 'destino → `%s`' % fk
    elif f.get('fkhow') in ('poly',):
        ref = 'polimórfica'
    if not d:
        d = 'Según la definición en texto del §7' if f.get('src') == 'anexo' else 'Campo citado por T05 (referencias o clave única)'
    return '| `%s` | %s | %s | %s | %s |' % (name, tipo(f, name), oblig(name, f, ent), ref, d)


def bloques(owner):
    mo = model[owner]
    out = []
    for n, ent in mo['ents'].items():
        r = ent['row']
        if r['id'] not in falt or not ent['fields']:
            continue
        sec = ent.get('subsection') or ent.get('section')
        secref = ''
        if sec:
            m = re.match(r'^([\d.]+)', sec[1])
            secref = '§' + m.group(1).rstrip('.') if m else ''
        lines = ['**`%s`** — %s (%s; definición en texto en %s)' % (
            n, (r.get('desc') or r.get('purpose') or 'campos').replace('`', ''), r['id'], secref or '§7'), '',
            '| Campo | Tipo | Obligatorio | Referencia | Descripción |', '|---|---|---|---|---|']
        campos = []
        for fn_, f in ent['fields'].items():
            f = dict(f)
            if '_' in fn_ and not n.startswith('bi_'):
                if fn_.endswith('_String'):
                    fn_ = fn_[:-7]
                    f['type'] = 'string[]'
                    f['desc'] = ''
                else:
                    fn_ = fn_.replace('_', '.')
                    f['desc'] = ''
            if n.startswith('bi_') and f.get('type') == 'array':
                f['type'] = 'string'
            if (n, fn_) in RENAME:
                f['antes'] = fn_
                fn_ = RENAME[(n, fn_)]
            campos.append([fn_, f])
        anexo_c = [c for c in campos if c[1].get('src') == 'anexo']
        final = []
        for c in campos:
            nm, f = c
            if f.get('src') == 'T05':
                if any(a[0] == nm for a in final):
                    continue
                par = None
                tgt = f.get('fk') or f.get('t05target')
                for a in anexo_c:
                    if a[1].get('antes') or a[1].get('merged'):
                        continue
                    if tgt and a[1].get('fk') == tgt and re.search(r'Ids?$', a[0]) and re.search(r'Ids?$', nm):
                        par = a
                        break
                    an, bn = a[0].lower(), nm.lower()
                    if (bn.startswith(an) and len(an) >= 4) or difflib.SequenceMatcher(None, an, bn).ratio() >= 0.85:
                        par = a
                        break
                if par:
                    par[1]['antes'] = par[0]
                    par[1]['merged'] = True
                    par[1]['oblig'] = 'Sí'
                    if not par[1].get('fk') and f.get('fk'):
                        par[1]['fk'] = f['fk']
                    par[0] = nm
                    continue
            final.append(c)
        for fn_, f in final:
            lines.append(fila(fn_, f, ent, n))
        lines.append('')
        out.append((n, r['id'], lines))
    return out


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'preview'
    resumen = {}
    for owner, pa in MINE.items():
        bl = bloques(owner)
        resumen[owner] = [b[1] + ' ' + b[0] for b in bl]
        if mode == 'preview':
            print('=====', owner, len(bl))
            for n, cid, lines in bl[:int(sys.argv[2]) if len(sys.argv) > 2 else 2]:
                print('\n'.join(lines))
            continue
        path = glob.glob(os.path.join(ROOT, owner + '-*.md'))
        path = [p for p in path if re.match(r'^T\d\d-', os.path.basename(p))][0]
        raw = open(path, 'rb').read()
        bom = raw.startswith(b'\xef\xbb\xbf')
        txt = raw.decode('utf-8-sig')
        lines = txt.split('\n')
        if owner == 'T08':
            i8 = next(i for i, l in enumerate(lines) if l.startswith('### 15.2'))
            i7 = next(i for i, l in enumerate(lines) if l.startswith('### 15.1'))
            nums = [int(m.group(1)) for l in lines[i7:i8] for m in [re.match(r'^#### 15\.1\.(\d+)\b', l)] if m]
            titulo = '#### 15.1.%d' % ((max(nums) + 1) if nums else 1)
        else:
            i8 = next(i for i, l in enumerate(lines) if re.match(r'^## 8\.', l))
            i7 = next(i for i, l in enumerate(lines) if re.match(r'^## 7\.', l))
            nums = [int(m.group(1)) for l in lines[i7:i8] for m in [re.match(r'^### 7\.(\d+)\b', l)] if m]
            titulo = '### 7.%d' % ((max(nums) + 1) if nums else 1)
        nxt = titulo
        ins = ['%s Tablas de campos de las colecciones definidas en texto' % titulo, '',
               'Tabla agregada en el cierre de residuales (05-11-2026) para las colecciones de este anexo que solo tenían la definición en texto. '
               'Los campos salen del texto del §7 y de las referencias y claves únicas de T05; la definición en texto sigue vigente y prevalece si hay diferencia. '
               'Los campos comunes (`_id`, `tenantId`, auditoría, `version`) no se repiten. La obligatoriedad se asume por regla (clave única, `status`, `code`, `name` y referencias de T05 = Sí; resto = No) y queda como %s (Asumida, DEC-072).' % pa, '']
        for n, cid, bl_lines in bl:
            ins += bl_lines
        # insertar antes del separador o encabezado del §8
        k = i8
        while k > i7 and lines[k - 1].strip() in ('', '---'):
            k -= 1
        lines[k:k] = [''] + ins
        new = '\n'.join(lines)
        open(path, 'wb').write((b'\xef\xbb\xbf' if bom else b'') + new.encode('utf-8'))
        print(owner, os.path.basename(path), 'insertadas', len(bl), nxt)
    json.dump(resumen, open(os.path.join(os.path.dirname(__file__), 'res_tablas_resumen.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


main()
