import sys, json
sys.stdout.reconfigure(encoding='utf-8')
d = json.load(open(r'c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo\gen06_data.json', encoding='utf-8'))
MODS = ('M07', 'M08', 'M09', 'M10', 'M11')
print('== cover_states (no transiciones del §8)')
for r in d['cover_states']:
    if r[0] in MODS and 'transiciones del' not in r[4]:
        print(r)
for k in ('mismatches', 'svc_nocaller', 'nonconv_types', 'unresolved', 'extras'):
    print('==', k)
    v = d[k]
    items = v if isinstance(v, list) else list(v.items())
    for r in items:
        s = json.dumps(r, ensure_ascii=False)
        if any(m in s for m in MODS) or k == 'svc_nocaller':
            print(s[:400])
print('== stats keys', list(d['stats'].keys()) if isinstance(d['stats'], dict) else '')
