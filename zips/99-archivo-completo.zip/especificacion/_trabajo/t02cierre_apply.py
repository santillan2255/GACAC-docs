# Pasada de cierre T02 (05-11-2026). Conserva UTF-8 sin BOM y LF.
import re, sys

P = 'anexos/T02-IAM-identidad-roles-auditoria.md'
raw = open(P, 'rb').read()
assert not raw.startswith(b'\xef\xbb\xbf') and b'\r\n' not in raw
t = raw.decode('utf-8')

def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count:
        sys.exit(f'ERROR: {n} ocurrencias de: {old[:120]}')
    t = t.replace(old, new)

def cap_of(row):
    m = re.match(r'\| `([^`]+)`', row)
    return m.group(1) if m else ''

def add_rows(header, rows):
    """Inserta filas en la tabla que sigue a `header`, en orden alfabético por capability."""
    global t
    lines = t.split('\n')
    hi = lines.index(header)
    i = hi + 1
    while not lines[i].startswith('|'):
        i += 1
    start = i + 2  # saltear encabezado y separador
    end = start
    while end < len(lines) and lines[end].startswith('|'):
        end += 1
    body = lines[start:end]
    existing = {cap_of(r) for r in body}
    for r in rows:
        c = cap_of(r)
        if c in existing:
            sys.exit(f'ERROR: ya existe {c}')
        pos = len(body)
        for k, b in enumerate(body):
            if cap_of(b) and cap_of(b) > c:
                pos = k
                break
        body.insert(pos, r)
    lines[start:end] = body
    t = '\n'.join(lines)

PA47 = 'PA 4/7 del cierre, DEC-072'

# ---------------------------------------------------------------- 4.4 tablas base
rep('| `uxd.plataforma.diccionarioBase.editar` | Diccionario base de plataforma | S | P-ADM, P-SUP | global |',
    '| `uxd.plataforma.diccionarioBase.editar` | Diccionario base de plataforma: alta, renombre y deprecación de claves (T03 CU-DIC-05, API-UXD-33). Forma canónica de las capabilities de plataforma de T03: `uxd.plataforma.<recurso>.<accion>`; T03 usaba `plt.uxd.diccionarioBase.editar` (alias en 4.4.1) | S | P-ADM, P-SUP | global |')

rep('| `tec.phone.numbering` | Numeración telefónica: prefijos, plan de numeración y portabilidad (M10 PAN-TEC-43; HUE-TEL-05) | S | T-STE | srv |',
    f'| `tec.telefonia.numeracion.configurar` | Numeración telefónica: prefijos, plan de numeración y portabilidad (M10 PAN-TEC-43; HUE-TEL-05). Antes `tec.phone.numbering` (alias en 4.4.1; {PA47}); la asignación de números a líneas es `tec.telefonia.numeracion.editar` (4.4.2) | S | T-STE | srv |')
rep('| `tec.onCall.manage` | Turnos de guardia y escalamiento de emergencias (M10 PAN-TEC-61, API-TEC-51; HUE-GAS-05) | — | T-STE (jefe de guardia) | srv / zona |',
    f'| `tec.guardias.gestionar` | Turnos de guardia y escalamiento de emergencias (M10 PAN-TEC-61, API-TEC-51; HUE-GAS-05). Antes `tec.onCall.manage` (alias en 4.4.1; {PA47}) | — | T-STE (jefe de guardia) | srv / zona |')
rep('| `tec.waterQuality.manage` | Calidad del agua: puntos de muestreo, muestras y resultados (M10 PAN-TEC-64, API-TEC-54; PA-TEC-20) | — | T-STE (responsable de calidad del agua) | srv |',
    f'| `tec.calidadAgua.gestionar` | Calidad del agua: puntos de muestreo, muestras y resultados (M10 PAN-TEC-64, API-TEC-54; PA-TEC-20). Antes `tec.waterQuality.manage` (alias en 4.4.1; {PA47}) | — | T-STE (responsable de calidad del agua) | srv |')

# ---------------------------------------------------------------- 4.4.1 alias
alias_rows = [
    ('plt.uxd.tokens.ver', 'uxd.plataforma.tokens.ver', 'T03 §4, PAN-UXD-10, SM-PLT-019'),
    ('plt.uxd.tokens.editar', 'uxd.plataforma.tokens.editar', 'T03 §4'),
    ('plt.uxd.diccionarioBase.ver', 'uxd.plataforma.diccionarioBase.ver', 'T03 §4, PAN-UXD-09, API-UXD-34, SM-PLT-018'),
    ('plt.uxd.diccionarioBase.editar', 'uxd.plataforma.diccionarioBase.editar', 'T03 §4, CU-DIC-05'),
    ('plt.uxd.diccionarioBase.publicar', 'uxd.plataforma.diccionarioBase.publicar', 'T03 §4'),
    ('plt.uxd.flags.configurar', 'uxd.plataforma.flags.configurar', 'T03 §4, §8 flags, PAN-UXD-11, API-UXD-35, SM-PLT-020'),
    ('plt.uxd.ayudaBase.editar', 'uxd.plataforma.ayudaBase.editar', 'T03 §4'),
    ('plt.uxd.marca.ver', 'uxd.plataforma.marca.ver', 'T03 §4, API-UXD-36'),
    ('plt.uxd.marca.asistir', 'uxd.plataforma.marca.asistir', 'T03 §4, API-UXD-37'),
]
lines_alias = []
for old, new, by in alias_rows:
    lines_alias.append(f'| `{old}` | `{new}` | Total | {by} | Pasada de cierre: forma canónica de T02 para capabilities de plataforma (`<modulo>.plataforma.<recurso>.<accion>`) |')
for old, new in [('uxd.diccionarioBase.ver', 'uxd.plataforma.diccionarioBase.ver'),
                 ('uxd.marca.asistir', 'uxd.plataforma.marca.asistir'),
                 ('uxd.tokens.ver', 'uxd.plataforma.tokens.ver')]:
    lines_alias.append(f'| `{old}` | `{new}` | Total | §4.4.2 T03 (canónica propuesta anterior para `plt.uxd.*`) | Pasada de cierre (uxd.plataforma) |')
for old, new, by in [
    ('int.operaciones.resolver-manual', 'int.operaciones.resolverManual', 'T06 §4 (antes de la corrección del 05-11-2026)'),
    ('int.bitacora.ver-payload', 'int.bitacora.verPayload', 'T06 §4 (antes de la corrección del 05-11-2026)'),
    ('bia.datos_abiertos.publicar', 'bia.datosAbiertos.publicar', 'T10 §4, API-BIA-52, API-BIA-53 (versión anterior)'),
    ('bia.datos_sensibles.ver', 'bia.datosSensibles.ver', 'T10 §4, RF-BIA-014 (versión anterior)'),
    ('bia.reportes.programar_externos', 'bia.reportes.programarExternos', 'T10 §4, PA-BIA-04 (versión anterior)'),
]:
    lines_alias.append(f'| `{old}` | `{new}` | Total | {by} | Renombre a camelCase (guía §62) |')

m10_alias = [
    # nombre usado en M10 -> canónica en español
    ('tec.cdr.import', 'tec.cdr.importar'), ('tec.config.manage', 'tec.config.gestionar'),
    ('tec.crew.manage', 'tec.cuadrillas.gestionar'), ('tec.device.manage', 'tec.dispositivos.gestionar'),
    ('tec.dispatch.manage', 'tec.despacho.gestionar'), ('tec.estimate.manage', 'tec.estimaciones.gestionar'),
    ('tec.feasibility.cancel', 'tec.factibilidad.cancelar'), ('tec.feasibility.create', 'tec.factibilidad.crear'),
    ('tec.feasibility.evaluate', 'tec.factibilidad.evaluar'), ('tec.feasibility.read', 'tec.factibilidad.ver'),
    ('tec.feasibility.reopen', 'tec.factibilidad.reabrir'), ('tec.feasibility.update', 'tec.factibilidad.editar'),
    ('tec.fieldForm.manage', 'tec.formulariosCampo.gestionar'), ('tec.geo.review', 'tec.geo.revisar'),
    ('tec.inspection.approve', 'tec.inspecciones.aprobar'), ('tec.inspection.manage', 'tec.inspecciones.gestionar'),
    ('tec.installation.read', 'tec.instalaciones.ver'), ('tec.installation.review', 'tec.instalaciones.revisar'),
    ('tec.levy.manage', 'tec.contribucionesObra.gestionar'), ('tec.maintenance.manage', 'tec.mantenimiento.gestionar'),
    ('tec.map.read', 'tec.mapa.ver'), ('tec.mobile.import', 'tec.mobile.importar'),
    ('tec.network.configure', 'tec.redes.configurar'), ('tec.network.export', 'tec.redes.exportar'),
    ('tec.network.manage', 'tec.redes.gestionar'), ('tec.network.read', 'tec.redes.ver'),
    ('tec.networkDevice.manage', 'tec.equiposRed.gestionar'), ('tec.outage.manage', 'tec.cortes.gestionar'),
    ('tec.provisioning.configure', 'tec.aprovisionamiento.configurar'), ('tec.provisioning.operate', 'tec.aprovisionamiento.operar'),
    ('tec.report.read', 'tec.reportes.ver'), ('tec.schedule.configure', 'tec.agenda.configurar'),
    ('tec.schedule.manage', 'tec.agenda.gestionar'), ('tec.schedule.read', 'tec.agenda.ver'),
    ('tec.serviceTechnical.read', 'tec.servicioTecnico.ver'), ('tec.serviceTechnical.update', 'tec.servicioTecnico.editar'),
    ('tec.work.manage', 'tec.obras.gestionar'), ('tec.workOrder.bulkClose', 'tec.ordenes.cerrarMasivo'),
    ('tec.workOrder.bulkCreate', 'tec.ordenes.crearMasivo'), ('tec.workOrder.cancel', 'tec.ordenes.cancelar'),
    ('tec.workOrder.close', 'tec.ordenes.cerrar'), ('tec.workOrder.create', 'tec.ordenes.crear'),
    ('tec.workOrder.execute', 'tec.ordenes.ejecutar'), ('tec.workOrder.print', 'tec.ordenes.imprimir'),
    ('tec.workOrder.read', 'tec.ordenes.ver'), ('tec.workOrder.reopen', 'tec.ordenes.reabrir'),
    ('tec.workOrder.update', 'tec.ordenes.editar'),
    ('tec.material.authorize', 'tec.materiales.autorizar'), ('tec.material.request', 'tec.materiales.solicitar'),
    ('tec.syncConflict.resolve', 'tec.conflictos.resolver'), ('tec.ext.workOrder', 'tec.ext.ordenes.crear'),
    ('tec.phone.lines', 'tec.telefonia.lineas.ver'), ('tec.phone.plant', 'tec.telefonia.redFisica.ver'),
    ('tec.phone.numbering', 'tec.telefonia.numeracion.configurar'), ('tec.onCall.manage', 'tec.guardias.gestionar'),
    ('tec.waterQuality.manage', 'tec.calidadAgua.gestionar'),
    ('tec.crew.gestionar', 'tec.cuadrillas.gestionar'), ('tec.device.gestionar', 'tec.dispositivos.gestionar'),
    ('tec.dispatch.gestionar', 'tec.despacho.gestionar'), ('tec.estimate.gestionar', 'tec.estimaciones.gestionar'),
    ('tec.fieldForm.gestionar', 'tec.formulariosCampo.gestionar'), ('tec.levy.gestionar', 'tec.contribucionesObra.gestionar'),
    ('tec.networkDevice.gestionar', 'tec.equiposRed.gestionar'), ('tec.serviceTechnical.ver', 'tec.servicioTecnico.ver'),
    ('tec.serviceTechnical.editar', 'tec.servicioTecnico.editar'),
    ('tec.ot.ver', 'tec.ordenes.ver'), ('tec.ot.crear', 'tec.ordenes.crear'), ('tec.ot.editar', 'tec.ordenes.editar'),
    ('tec.ot.asignar', 'tec.ordenes.asignar'), ('tec.ot.cerrar', 'tec.ordenes.cerrar'),
    ('tec.ot.anular', 'tec.ordenes.cancelar'), ('tec.ot.reabrir', 'tec.ordenes.reabrir'),
    ('tec.ot.cierreMasivo', 'tec.ordenes.cerrarMasivo'), ('tec.ot.crearDerivada', 'tec.ordenes.crearDerivada'),
]
for old, new in m10_alias:
    if old.startswith('tec.ot.'):
        by = 'M10 §4 (vocabulario `ot` de la PA 7)'
    elif old.split('.')[-1] in ('gestionar', 'ver', 'editar'):
        by = '§4.4.2 M10 (canónica propuesta anterior con recurso en inglés)'
    else:
        by = 'M10 (§4, §10, §11)'
    lines_alias.append(f'| `{old}` | `{new}` | Total | {by} | {PA47}: capabilities de M10 en español con alias |')

anchor = '| `com.comunicaciones.historial.ver` | `com.communications.ver` | Total | §4.4 T09 (versión anterior de esta tabla) | CTR-COM-09 |'
rep(anchor, anchor + '\n' + '\n'.join(lines_alias))

# ---------------------------------------------------------------- 4.4.2 T02
add_rows('##### T02 IAM — Identidad, roles y auditoría (capabilities de los anexos)', [
    '| `iam.directorio.ver` | Directorio interno del espacio del empleado: nombre, puesto, sector, sucursal y contacto interno, sin datos personales sensibles (vista de T03 sobre datos de T02, M16 y `branches` de T04) | — | Todos staff, C-EMP | tenant | PAN-UXD-16, SM-PWE-015 |',
])

# ---------------------------------------------------------------- 4.4.2 T03
rep('| `uxd.diccionarioBase.ver` | Canónica propuesta para plt.uxd.diccionarioBase.ver. Faltantes de todos los tenants (sin datos personales) | — | P-SUP, P-ADM, P-SEC | global | API-UXD-34, PAN-UXD-09 |',
    '| `uxd.plataforma.diccionarioBase.ver` | Catálogo de claves del producto y faltantes de todos los tenants (sin datos personales). Antes `uxd.diccionarioBase.ver` (canónica propuesta para `plt.uxd.diccionarioBase.ver`); ambos quedan como alias en 4.4.1 | — | P-SUP, P-ADM, P-SEC | global | API-UXD-34, PAN-UXD-09 |')
rep('| `uxd.flags.configurar` | Canónica propuesta para plt.uxd.flags.configurar. Flags globales | S | P-SUP, P-ADM, T-ADM | global / tenant | API-UXD-35, PAN-UXD-11, API-UXD-28, PAN-UXD-07 |',
    '| `uxd.flags.configurar` | Flags del tenant (T03 §8). Antes cubría también los flags globales (P-SUP, P-ADM, alcance global; API-UXD-35, PAN-UXD-11), que pasan a `uxd.plataforma.flags.configurar` | S | T-ADM | tenant | API-UXD-28, PAN-UXD-07 |')
rep('| `uxd.marca.asistir` | Canónica propuesta para plt.uxd.marca.asistir. Propuesta de marca en el alta asistida (queda en borrador del tenant) | — | P-SUP, P-ADM | global | API-UXD-37 |',
    '| `uxd.plataforma.marca.asistir` | Propuesta de marca en el alta asistida (queda en borrador del tenant). Antes `uxd.marca.asistir` (canónica propuesta para `plt.uxd.marca.asistir`); ambos alias en 4.4.1 | — | P-SUP, P-ADM | global | API-UXD-37 |')
rep('| `uxd.tokens.ver` | Canónica propuesta para plt.uxd.tokens.ver. Catálogo vivo de componentes y tokens | — | P-SUP, P-ADM, P-SEC | global | PAN-UXD-10 |',
    '| `uxd.plataforma.tokens.ver` | Catálogo vivo de componentes y tokens. Antes `uxd.tokens.ver` (canónica propuesta para `plt.uxd.tokens.ver`); ambos alias en 4.4.1 | — | P-SUP, P-ADM, P-SEC | global | PAN-UXD-10 |')
# re-ordenar las filas renombradas y agregar las nuevas
add_rows('##### T03 UXD — Experiencia, marca y diccionario (capabilities de los anexos)', [
    '| `uxd.plataforma.ayudaBase.editar` | Ayuda contextual base del producto (`ScreenHelp` de plataforma) que heredan los tenants (antes `plt.uxd.ayudaBase.editar`) | S | P-SUP, P-ADM | global | T03 §4 |',
    '| `uxd.plataforma.diccionarioBase.publicar` | Publicar el catálogo base y las plantillas de diccionario (JOB-UXD-05, EVT-UXD-08; antes `plt.uxd.diccionarioBase.publicar`) | S D | P-SUP, P-ADM | global | API-UXD-33, T03 §4 |',
    '| `uxd.plataforma.flags.configurar` | Flags globales; `disabled` en plataforma bloquea el encendido en el tenant (antes `plt.uxd.flags.configurar` y parte de `uxd.flags.configurar`) | S | P-SUP, P-ADM | global | API-UXD-35, PAN-UXD-11 |',
    '| `uxd.plataforma.marca.ver` | Ver la marca de cualquier tenant, solo lectura (antes `plt.uxd.marca.ver`; 4.4.3 proponía `uxd.marca.ver`, que es la capability del tenant) | — | P-SUP, P-ADM, P-SEC | global | API-UXD-36 |',
    '| `uxd.plataforma.tokens.editar` | Editar tokens y componentes del design system (antes `plt.uxd.tokens.editar`) | S | P-SUP, P-ADM | global | T03 §4 |',
])
# ordenar la tabla T03 completa (las renombradas quedaron fuera de orden)
lines = t.split('\n')
hi = lines.index('##### T03 UXD — Experiencia, marca y diccionario (capabilities de los anexos)')
s = hi + 4
e = s
while lines[e].startswith('|'):
    e += 1
lines[s:e] = sorted(lines[s:e], key=lambda r: cap_of(r))
t = '\n'.join(lines)

# ---------------------------------------------------------------- 4.4.2 T07 (descripciones genéricas)
for cap, old_d, new_d in [
    ('mig.actaAceptacion.firmar', 'Cambiar estado (§8.1)', 'Firmar el acta de aceptación de la migración (documento de tipo "acta" en `documents` de T11; PA 15 del cierre)'),
    ('mig.bypass.aprobar', 'Cambiar estado (§8.1)', 'Aprobar la activación del by-pass ProCoop (transición del proyecto, §8.1 de T07)'),
    ('mig.corte.aprobar', 'Cambiar estado (§8.1)', 'Aprobar el corte (decisión go/no-go, §8.1 de T07)'),
    ('mig.paralelo.aprobar', 'Cambiar estado (§8.1)', 'Aprobar el cierre de la corrida en paralelo (§8.1 de T07)'),
]:
    pat = f'| `{cap}` | {old_d} |'
    rep(pat, f'| `{cap}` | {new_d}; antes descripción "{old_d}" |')
rep('| `mig.proyectos.configurar` | Detalle / actualizar estrategia |',
    '| `mig.proyectos.configurar` | Configurar el proyecto de migración y su estrategia (antes descripción "Detalle / actualizar estrategia") |')

# ---------------------------------------------------------------- 4.4.2 T10
add_rows('##### T10 BIA — Reportes, BI y APIs (capabilities de los anexos)', [
    '| `bia.datosSensibles.ver` | Ver datos personales sin enmascarar en reportes y exportaciones; registra `unmask` en `reportAccessLogs` (T10 RF-BIA-014, RN-BIA-016; antes `bia.datos_sensibles.ver`) | S | T-ADM, T-CON (fiscales), T-SIN | tenant | T10 §4, RF-BIA-014, ESC-BIA-38 |',
    '| `bia.reportes.programarExternos` | Agregar destinatarios externos al tenant en programaciones de reportes (PA-BIA-04; antes `bia.reportes.programar_externos`) | S | T-ADM, T-GER | tenant | T10 §4, PAN-BIA-05 |',
])

# ---------------------------------------------------------------- 4.4.2 M01
add_rows('##### M01 PER — Personas, titulares, cuentas, inmuebles (capabilities de los anexos)', [
    '| `per.documentacion.registrar` | Registrar la presentación de un requisito documental (atención) | — | T-ATE, T-SAT, T-FAC | suc | M01 §4, PAN-PER-13 |',
    '| `per.documentacion.validar` | Validar o rechazar una presentación documental (`presented` → `validated`/`rejected`) | D | T-SAT | suc | M01 §4, §8, PAN-PER-13 |',
])

# ---------------------------------------------------------------- 4.4.2 M08
add_rows('##### M08 MOR — Mora y financiación (capabilities de los anexos)', [
    '| `mor.bloqueos.ver` | Ver documentos con bloqueo activo e historial (reemplaza la lectura del comodín `mor.bloqueos.*`) | — | T-ADM, T-GER, T-CAJ, T-TES, T-ATE, T-SAT, T-SIN; T-CBR (P) | suc | PAN-MOR-09 |',
])

# ---------------------------------------------------------------- 4.4.2 M10 (PA 4/7)
m10_ren = [
    ('tec.crew.gestionar', 'tec.cuadrillas.gestionar', 'tec.crew.manage'),
    ('tec.device.gestionar', 'tec.dispositivos.gestionar', 'tec.device.manage'),
    ('tec.dispatch.gestionar', 'tec.despacho.gestionar', 'tec.dispatch.manage'),
    ('tec.estimate.gestionar', 'tec.estimaciones.gestionar', 'tec.estimate.manage'),
    ('tec.fieldForm.gestionar', 'tec.formulariosCampo.gestionar', 'tec.fieldForm.manage'),
    ('tec.levy.gestionar', 'tec.contribucionesObra.gestionar', 'tec.levy.manage'),
    ('tec.networkDevice.gestionar', 'tec.equiposRed.gestionar', 'tec.networkDevice.manage'),
    ('tec.serviceTechnical.editar', 'tec.servicioTecnico.editar', 'tec.serviceTechnical.update'),
    ('tec.serviceTechnical.ver', 'tec.servicioTecnico.ver', 'tec.serviceTechnical.read'),
]
for old, new, src in m10_ren:
    rep(f'| `{old}` | Canónica propuesta para {src}. ', f'| `{new}` | Canónica para {src} (antes `{old}`; {PA47}). ')
for old, new, d in [('tec.material.authorize', 'tec.materiales.autorizar', 'Materiales.'),
                 ('tec.material.request', 'tec.materiales.solicitar', 'Materiales.'),
                 ('tec.syncConflict.resolve', 'tec.conflictos.resolver', 'Conflictos.')]:
    rep(f'| `{old}` | {d}', f'| `{new}` | Antes `{old}` ({PA47}). {d}')
for old, new, d in [('tec.ext.workOrder', 'tec.ext.ordenes.crear', 'Alta externa'),
                 ('tec.phone.lines', 'tec.telefonia.lineas.ver', 'Líneas'),
                 ('tec.phone.plant', 'tec.telefonia.redFisica.ver', 'Red telefónica')]:
    rep(f'| `{old}` | {d}', f'| `{old}` (alias) | Reemplazado por `{new}` (alias en 4.4.1; {PA47}). Texto original: {d}')
add_rows('##### M10 TEC — Técnica, campo y redes (capabilities de los anexos)', [
    f'| `tec.ordenes.crearDerivada` | Crear una OT derivada de un caso de atención o de otra OT (antes `tec.ot.crearDerivada` en M10 §4; {PA47}) | — | T-ATE, T-SAT, T-STE | suc | M10 §4, PAN-TEC-49 (reemplazada por M09) |',
])
lines = t.split('\n')
hi = lines.index('##### M10 TEC — Técnica, campo y redes (capabilities de los anexos)')
s = hi + 4
e = s
while lines[e].startswith('|'):
    e += 1
lines[s:e] = sorted(lines[s:e], key=lambda r: cap_of(r))
t = '\n'.join(lines)

# ---------------------------------------------------------------- 4.4.2 M16
add_rows('##### M16 SUE — Personal y sueldos (capabilities de los anexos)', [
    '| `sue.novedades.editar` | Modificar novedades del período (PATCH) | — | T-RRHH; jefes de área (por asignación) | area / tenant | API-SUE-40 |',
    '| `sue.liquidaciones.crear` | Crear una liquidación (borrador) | S | T-RRHH | tenant | API-SUE-49 |',
    '| `sue.liquidaciones.anular` | Anular una liquidación (`/void`) | S D | T-RRHH (solicita), T-GER (aprueba) | tenant | API-SUE-52 |',
])

# ---------------------------------------------------------------- 4.4.2 M19
add_rows('##### M19 POR — Landing, portal y app del socio (capabilities de los anexos)', [
    '| `por.conformidades.firmar` | Firmar conformidad o disconformidad de una visita técnica desde el portal (antes: acceso `firmar` sin capability) | — | C-SOC, C-REP (si la relación incluye `firmar`) | rel | API-POR-59 |',
    '| `por.totem.operar` | Operar el tótem de autogestión con identidad de dispositivo: identificar, consultar deuda, pagar, recargar prepaga (antes: credencial de dispositivo sin capability) | — | S-KSK | suc (caja del dispositivo) | API-POR-100 a API-POR-104, PAN-POR-78 a PAN-POR-83 |',
])

# ---------------------------------------------------------------- 4.4.3
old_par = 'Nombres usados por los anexos que **no** se registran como capability: no siguen `modulo.recurso.accion` con acción en español, son comodines o duplican una capability existente. Cada anexo debe reemplazarlos por la canónica propuesta (T02 no edita los otros anexos). Hasta que se corrijan, el chequeo de permisos no los reconoce. Las propuestas marcadas [VERIFICAR] requieren decisión del anexo dueño.'
rep(old_par, old_par + '\n\n'
    '**Estado: En corrección – pasada de cierre (05-11-2026).** Los renombres de esta tabla quedan a cargo de los anexos dueños en esta pasada: cada anexo reemplaza el nombre por la canónica y deja "antes `x`" en la fila o una nota por sección. Se mantienen sin cambio los comodines permitidos por AL-08 de T03 y los scopes de token externo (`recurso:acción` de T10, API-TES-87, API-SUE-86). Decisiones aplicadas en T02 en esta pasada: (1) las capabilities de plataforma de T03 usan la forma canónica de T02 `uxd.plataforma.<recurso>.<accion>` (como `iam.plataforma.*` y `cfg.plataforma.*`); `plt.uxd.*` y las canónicas propuestas anteriores `uxd.diccionarioBase.ver`, `uxd.marca.asistir` y `uxd.tokens.ver` quedan como alias en 4.4.1; (2) las capabilities de M10 con acción o recurso en inglés pasan al español con alias en 4.4.1 (PA 4/7 del cierre, DEC-072; dueño M10); el vocabulario `tec.ot.*` de M10 §4 se resuelve a `tec.ordenes.*`; (3) los nombres en kebab-case o snake_case de T06 y T10 (`int.operaciones.resolver-manual`, `int.bitacora.ver-payload`, `bia.datos_abiertos.publicar`, `bia.datos_sensibles.ver`, `bia.reportes.programar_externos`) ya están corregidos en sus anexos y quedan como alias.')

for old_c, new_c, extra in [
    ('plt.uxd.diccionarioBase.ver', 'uxd.plataforma.diccionarioBase.ver', 'uxd.diccionarioBase.ver'),
    ('plt.uxd.flags.configurar', 'uxd.plataforma.flags.configurar', 'uxd.flags.configurar'),
    ('plt.uxd.marca.asistir', 'uxd.plataforma.marca.asistir', 'uxd.marca.asistir'),
    ('plt.uxd.marca.ver', 'uxd.plataforma.marca.ver', 'uxd.marca.ver'),
    ('plt.uxd.tokens.ver', 'uxd.plataforma.tokens.ver', 'uxd.tokens.ver'),
]:
    rep(f'| plt | `{old_c}` | `{extra}` |', f'| plt | `{old_c}` | `{new_c}` (antes `{extra}`; alias en 4.4.1) |')
rep('| plt | `plt.uxd.diccionarioBase.*` | — (explicitar las capabilities concretas por acción) |',
    '| plt | `plt.uxd.diccionarioBase.*` | — (explicitar: `uxd.plataforma.diccionarioBase.ver`, `.editar`, `.publicar`) |')
for src, old_c, new_c in [
    ('tec.crew.manage', 'tec.crew.gestionar', 'tec.cuadrillas.gestionar'),
    ('tec.device.manage', 'tec.device.gestionar', 'tec.dispositivos.gestionar'),
    ('tec.dispatch.manage', 'tec.dispatch.gestionar', 'tec.despacho.gestionar'),
    ('tec.estimate.manage', 'tec.estimate.gestionar', 'tec.estimaciones.gestionar'),
    ('tec.fieldForm.manage', 'tec.fieldForm.gestionar', 'tec.formulariosCampo.gestionar'),
    ('tec.levy.manage', 'tec.levy.gestionar', 'tec.contribucionesObra.gestionar'),
    ('tec.networkDevice.manage', 'tec.networkDevice.gestionar', 'tec.equiposRed.gestionar'),
    ('tec.serviceTechnical.read', 'tec.serviceTechnical.ver', 'tec.servicioTecnico.ver'),
    ('tec.serviceTechnical.update', 'tec.serviceTechnical.editar', 'tec.servicioTecnico.editar'),
]:
    rep(f'| tec | `{src}` | `{old_c}` |', f'| tec | `{src}` | `{new_c}` (antes `{old_c}`; {PA47}) |')
rep('| tec | `tec.phone.*` | — (explicitar las capabilities concretas por acción) |',
    '| tec | `tec.phone.*` | — (explicitar: `tec.telefonia.lineas.*`, `tec.telefonia.numeracion.*`, `tec.telefonia.redFisica.*`) |')

new443 = [
    ('tec', 'tec.material.authorize', 'tec.materiales.autorizar', 'Acción y recurso en inglés (PA 4/7)', 'API-TEC-14, PAN-TEC-09'),
    ('tec', 'tec.material.request', 'tec.materiales.solicitar', 'Acción y recurso en inglés (PA 4/7)', 'API-TEC-14'),
    ('tec', 'tec.syncConflict.resolve', 'tec.conflictos.resolver', 'Acción y recurso en inglés (PA 4/7)', 'API-TEC-24, PAN-TEC-24'),
    ('tec', 'tec.ext.workOrder', 'tec.ext.ordenes.crear', 'Falta la acción; duplica una capability existente', 'API-TEC-49'),
    ('tec', 'tec.phone.lines', 'tec.telefonia.lineas.ver', 'Recurso en inglés y sin acción (PA 4/7)', 'PAN-TEC-44'),
    ('tec', 'tec.phone.plant', 'tec.telefonia.redFisica.ver', 'Recurso en inglés y sin acción (PA 4/7)', 'PAN-TEC-42'),
    ('tec', 'tec.phone.numbering', 'tec.telefonia.numeracion.configurar', 'Recurso en inglés y sin acción; registrada en §4.4 M10 (PA 4/7)', 'PAN-TEC-43'),
    ('tec', 'tec.onCall.manage', 'tec.guardias.gestionar', 'Acción y recurso en inglés; registrada en §4.4 M10 (PA 4/7)', 'PAN-TEC-61, API-TEC-51'),
    ('tec', 'tec.waterQuality.manage', 'tec.calidadAgua.gestionar', 'Acción y recurso en inglés; registrada en §4.4 M10 (PA 4/7)', 'PAN-TEC-64, API-TEC-54'),
    ('tec', 'tec.ot.ver', 'tec.ordenes.ver', 'Sinónimo (`ot` por `ordenes`; PA 7)', 'M10 §4'),
    ('tec', 'tec.ot.crear', 'tec.ordenes.crear', 'Sinónimo (`ot` por `ordenes`; PA 7)', 'M10 §4'),
    ('tec', 'tec.ot.editar', 'tec.ordenes.editar', 'Sinónimo (`ot` por `ordenes`; PA 7)', 'M10 §4'),
    ('tec', 'tec.ot.asignar', 'tec.ordenes.asignar', 'Sinónimo (`ot` por `ordenes`; PA 7)', 'M10 §4'),
    ('tec', 'tec.ot.cerrar', 'tec.ordenes.cerrar', 'Sinónimo (`ot` por `ordenes`; PA 7)', 'M10 §4'),
    ('tec', 'tec.ot.anular', 'tec.ordenes.cancelar', 'Sinónimo (`ot` por `ordenes`; PA 7)', 'M10 §4'),
    ('tec', 'tec.ot.reabrir', 'tec.ordenes.reabrir', 'Sinónimo (`ot` por `ordenes`; PA 7)', 'M10 §4'),
    ('tec', 'tec.ot.cierreMasivo', 'tec.ordenes.cerrarMasivo', 'Sinónimo (`ot` por `ordenes`; PA 7)', 'M10 §4'),
    ('tec', 'tec.ot.crearDerivada', 'tec.ordenes.crearDerivada', 'Sinónimo (`ot` por `ordenes`; PA 7)', 'M10 §4, PAN-TEC-49'),
    ('tec', 'tec.ot.confirmar', 'tec.ordenes.confirmar [VERIFICAR con M10]', 'Sinónimo (`ot` por `ordenes`); acción sin capability registrada', 'M10 §4'),
    ('tec', 'tec.ot.exportar', 'tec.ordenes.exportar [VERIFICAR con M10]', 'Sinónimo (`ot` por `ordenes`); acción sin capability registrada', 'M10 §4'),
]
lines = t.split('\n')
hi = lines.index('#### 4.4.3 Nombres fuera de convención o sinónimos (canónica propuesta)')
s = hi
while not lines[s].startswith('| Módulo |'):
    s += 1
s += 2
e = s
while lines[e].startswith('|'):
    e += 1
body = lines[s:e]
names = {re.match(r'\| [^|]+ \| `([^`]+)`', r).group(1) for r in body}
for mod, n, c, why, src in new443:
    assert n not in names, n
    body.append(f'| {mod} | `{n}` | `{c}` | {why} | M10 | {src} |'.replace('`tec.ordenes.confirmar [VERIFICAR con M10]`', '`tec.ordenes.confirmar` [VERIFICAR con M10]').replace('`tec.ordenes.exportar [VERIFICAR con M10]`', '`tec.ordenes.exportar` [VERIFICAR con M10]'))
def k443(r):
    m = re.match(r'\| ([^|]+) \| `([^`]+)`', r)
    return (m.group(1).strip(), m.group(2))
lines[s:e] = sorted(body, key=k443)
t = '\n'.join(lines)

# ---------------------------------------------------------------- §16 CU con dueño
rep('### CU-GOB-01 — Auditoría de cambio de regla (BASE §54)\n\n',
    '### CU-GOB-01 — Auditoría de cambio de regla (BASE §54; dueño T11)\n\n'
    'Caso de uso dueño: T11 §16.1 (CU-GOB-01, aprobación del cambio de configuración); T10 y T01 lo citan para el tablero y la alerta. T02 describe solo la parte de auditoría y aislamiento (evidencia AUD-DEMO-001).\n\n')
rep('### CU-API-01 — Cliente BI (BASE §59)\n\n',
    '### CU-API-01 — Cliente BI (BASE §59; dueño T10)\n\n'
    'Caso de uso dueño: T10 §16 (CU-API-01, cliente de BI de la cooperativa); T02 describe solo la parte de credenciales, scopes y revocación (RF-IAM-113, P-IAM-20).\n\n')

out = t.encode('utf-8')
open(P, 'wb').write(out)
print('OK', len(raw), '->', len(out))
