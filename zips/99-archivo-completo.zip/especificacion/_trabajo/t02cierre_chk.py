﻿import re
L=open('anexos/T02-IAM-identidad-roles-auditoria.md',encoding='utf-8').read().split('\n')
defs={}
alias={}
for i,l in enumerate(L[220:2268],start=221):
    m=re.match(r'\| `([^`]+)` \|',l)
    if m:
        if i>=794 and i<820: alias[m.group(1)]=i
        else: defs.setdefault(m.group(1),[]).append(i)
dups={k:v for k,v in defs.items() if len(v)>1}
print('defs',len(defs),'dups',dups)
req="""tec.ext.ordenes.crear tec.telefonia.llamadas.ver crm.turnero.pantalla.ver crm.webhooks.recibir crm.ivr.consultar crm.config.canales.configurar crm.config.tramites.configurar mor.plataforma.restricciones.configurar mor.ext.expedientes.ver mor.ext.expedientes.registrar mor.ext.condicionMora.ver mor.bloqueos.ver mor.excepciones.editar mor.protecciones.ver mor.protecciones.editar mor.restricciones.configurar mor.incobrables.ver mor.informes.ver mor.informes.exportar cmp.concursos.ver cmp.concursos.editar cmp.reportes.exportar stk.lotes.editar stk.rendiciones.editar stk.inventarios.cerrar stk.revaluaciones.ver stk.revaluaciones.aprobar stk.fabricacion.estructuras.editar stk.fabricacion.ordenes.editar iam.directorio.ver mig.proyectos.configurar mig.paralelo.aprobar mig.bypass.aprobar mig.corte.aprobar mig.actaAceptacion.firmar int.operaciones.resolverManual int.bitacora.verPayload bia.datosAbiertos.publicar bia.datosSensibles.ver bia.reportes.programarExternos wfl.instancias.iniciar wfl.instancias.administrar wfl.firmas.solicitar per.documentacion.registrar per.documentacion.validar sue.novedades.editar sue.liquidaciones.crear sue.liquidaciones.anular por.conformidades.firmar por.totem.operar uxd.plataforma.diccionarioBase.editar uxd.diccionarioBase.ver uxd.flags.configurar uxd.marca.asistir uxd.tokens.ver uxd.marca.ver""".split()
for r in req: print(('OK  ' if r in defs else 'FALTA ')+r, defs.get(r,''))
