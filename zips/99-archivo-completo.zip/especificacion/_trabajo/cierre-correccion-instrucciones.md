# Pasada de cierre de la corrección de inconsistencias

Fuente de pendientes: `_trabajo/correccion-inconsistencias-pendientes-cierre.md` (PA numeradas 1–21) y los informes de grupo en `_trabajo/`.

## Reglas
- Editar solo los archivos asignados al grupo. Otros archivos: solo lectura.
- No borrar contenido: lo reemplazado se marca con "antes `x`" o "Reemplazado por …" (regla del proyecto).
- Conservar BOM y finales de línea de cada archivo (leer y escribir con `[IO.File]::ReadAllText/WriteAllText` y la codificación detectada). Sin mojibake.
- Datos de ejemplo solo ficticios; sin secretos.
- Todas las PA del pendiente se toman como **Asumida (DEC-072)** con la opción recomendada. Aplicar sus consecuencias en los archivos del grupo.
- Registrar cada PA en la §21 (o sección de preguntas abiertas) del anexo dueño que indica la tabla siguiente, con el siguiente ID libre `PA-<MOD>-nn` del anexo, estado "Asumida (DEC-072)". Si ya existe una PA equivalente, no duplicar: actualizarla.
- No editar `02-preguntas-abiertas.md`, la maestra ni el plan (los consolida el grupo final).
- Verificar al terminar: IDs definidos una sola vez, tablas con columnas coherentes, sin `<!-- SIGUE -->`, sin mojibake.
- Informe final: cambios por archivo, PA registradas (ID, anexo, tema), lo que no se pudo cerrar y por qué.

## Dueño de cada PA del pendiente
| PA | Tema | Anexo dueño |
|---|---|---|
| 1 | Estados de `platformNotices` | T09 |
| 2 | `communicationTypeId` obligatorio con tipo "campaña" | T09 |
| 3 | Errores de unicidad/campos en T05 | T05 |
| 4 y 7 | Capabilities de M10 al español con alias | M10 (T02 lo refleja) |
| 5 | Dueño CU-CIC-01 = M08 (absorbe PA-CAT-20 para ese CU) | M08 |
| 6 | Dueño CU-SOL-01 = M09 | M09 |
| 8 | Máquinas de estado de `collectorSettlements`, `gatewayTransactions`, `thirdPartyCollections`, `externalObligationImports`, `crmCalendarEvents`, `technicalProcedures`, `fixedAssetValueChanges`, `mrpRuns`, transiciones de `agreementInstallments` | anexo dueño de cada colección según T05 |
| 9 | `membershipId` → `associateMembershipId` | M17 (T05 lo aplica) |
| 10 | `costCenterModelId` como colección de M15 | M15 (T05 la agrega) |
| 11 | `responsibleAreaId` → `crmAreas` | T11 |
| 12 | Factor de simultaneidad 0,6 | T08 |
| 13 | Copias de 10 años vía archivo en frío (DEC-087) | T08 |
| 14 | Estados de `aiUsageLogs` | T06 |
| 15 | Acta de aceptación de migración en `documents` (tipo "acta") | anexo dueño de MIG |
| 16 | Barra inferior del portal = maestra/T03; nueva PAN Comunidad en M19 | M19 (T03 la cita) |
| 17 | Pantallas de empleado: dueño M16, M19 incrusta | M16 |
| 18 | Versiones de formularios del portal en `formVersions` (T11) | M19 |
| 19 | Estados propuestos de `cashFlowScenarios`, `payslipNotifications`, `performanceReviews`, `objectives`, `providerAgreements`, `donationCampaigns`, `housingPlans` | anexo dueño de cada colección |
| 20 | M18 usa `inventoryItemId` | M18 |
| 21 | API-SOC-006 sigue como endpoint HTTP | M18 |
| PA-PER-17, PA-CAT-20, PA-CAT-21, PA-TAR-20, PA-FAC-21, PA-FIS-19, PA-FIS-20 | Propuestas del grupo M01–M06 (ver informe) | M01–M06 (confirmar que estén en su §21 como Asumida) |

## Renombre de capabilities no canónicas
T02 §4.4.3 lista 187 nombres no canónicos con su canónica propuesta y anexo. Cada grupo renombra los que aparecen en sus archivos (dejando "antes `x`" en la fila o una nota por sección). Comodines permitidos por AL-08 de T03 se mantienen. Scopes de token externo (T10 `recurso:acción`, API-TES-87, API-SUE-86) se mantienen.
