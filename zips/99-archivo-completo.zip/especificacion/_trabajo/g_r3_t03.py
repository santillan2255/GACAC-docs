import re, os, json, sys
sys.stdout.reconfigure(encoding='utf-8')
B = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
P = os.path.join(B, 'anexos', 'T03-UXD-experiencia-marca-diccionario.md')
an = json.load(open(os.path.join(B, '_trabajo', 'g_r3_analisis.json'), encoding='utf-8'))
reg = set(json.load(open(os.path.join(B, '_trabajo', 'g_r3_t02.json'), encoding='utf-8'))['reg'])
raw = open(P, 'rb').read()
assert not raw.startswith(b'\xef\xbb\xbf') and b'\r\n' not in raw
L = raw.decode('utf-8').split('\n')
CAPRE = re.compile(r'(?<!antes )`([a-z]{3}\.[A-Za-z0-9.]+)`')

sm109 = {}
for i, l in enumerate(L, 1):
    m = re.match(r'\| (SM-[A-Z]{3}-\d+) \|', l)
    if m and i > 2000:
        c = l.split('|')
        caps = [k for k in CAPRE.findall(c[4]) if k in reg]
        if caps:
            sm109.setdefault(m.group(1), caps[0])

manual = {
    ('SM-ADM-004', 'com.avisos.ver'): 'com.inbox.ver',
    ('SM-PWS-031', 'com.avisos.ver'): 'com.inbox.ver',
    ('SM-PWE-006', 'com.avisos.ver'): 'com.inbox.ver',
    ('SM-PWS-001', 'por.inicio.ver'): 'por.portal.ver',
    ('SM-PWS-040', 'por.inicio.ver'): 'por.portal.ver',
    ('SM-PWS-025', 'por.interrupciones.ver'): 'por.portal.ver',
    ('SM-PWS-023', 'por.tramites.ver'): 'por.tramites.iniciar',
    ('SM-PWE-016', 'uxd.preferencias.editar'): 'por.perfil.editar',
    ('SM-PWC-018', 'uxd.preferencias.editar'): 'por.perfil.editar',
    ('SM-PWC-001', 'med.campo.ver'): 'med.campo.leer',
    ('SM-PWC-016', 'med.campo.ver'): 'med.campo.leer',
    ('SM-PWC-001', 'cob.campo.ver'): 'cob.cobranzaCampo.ver',
    ('SM-PWC-016', 'cob.campo.ver'): 'cob.cobranzaCampo.ver',
    ('SM-ADM-102', 'tec.factibilidades.ver'): 'tec.factibilidad.ver',
}
keep = {'uxd.preferencias.editar', 'por.asistente.ver', 'wfl.asistente.ver'}

done, kept = [], []
for cap in list(an) + ['tec.factibilidades.ver']:
    pat = re.compile(r'(?<!antes )`' + re.escape(cap) + r'`(?! \(antes)')
    for i, l in enumerate(L):
        if not pat.search(l):
            continue
        m = re.match(r'\| (SM-[A-Z]{3}-\d+) \|', l)
        sm = m.group(1) if m else None
        new = manual.get((sm, cap))
        if not new and cap not in keep and sm and i + 1 < 2000:
            new = sm109.get(sm)
        if new and new in reg | {'por.portal.ver'}:
            L[i] = pat.sub('`' + new + '` (antes `' + cap + '`)', l)
            done.append((cap, new, sm, i + 1))
        else:
            kept.append((cap, sm, i + 1, l))

open(P, 'wb').write('\n'.join(L).encode('utf-8'))
print('reemplazos', len(done))
for k in kept:
    print('QUEDA', k[0], k[1], k[2], k[3][:160])
json.dump(done, open(os.path.join(B, '_trabajo', 'g_r3_t03_done.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
