#!/usr/bin/env python3
"""Genera inventario ScreenHelp M01 + T02 desde tablas PAN-* de los anexos."""
from __future__ import annotations

import re
from pathlib import Path

from cu_map_m01_t02 import CU_M01, CU_T02, NUCLEO_M01, NUCLEO_T02

ROOT = Path(__file__).resolve().parents[1]
M01 = ROOT / "anexos" / "M01-PER-personas-titulares-cuentas.md"
T02 = ROOT / "anexos" / "T02-IAM-identidad-roles-auditoria.md"
OUT = ROOT / "_trabajo" / "inventario-screenhelp-m01-t02.md"

PAN_ROW = re.compile(
    r"^\|\s*(PAN-(?:PER|IAM)-\d+)\s*\|"
)


def extract_pans(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    seen: set[str] = set()
    order: list[str] = []
    for line in text.splitlines():
        m = PAN_ROW.match(line)
        if m:
            pid = m.group(1)
            if pid not in seen:
                seen.add(pid)
                order.append(pid)
    return order


def main() -> None:
    m01 = extract_pans(M01)
    t02 = extract_pans(T02)
    lines = [
        "# Inventario ScreenHelp — M01 + T02 (fase 3b)",
        "",
        "| Campo | Valor |",
        "|---|---|",
        "| Fecha | 19-11-2026 |",
        "| Origen | Generado desde anexos M01 §pantallas, T02 §10 |",
        "| Uso | Export GoodApps; completar columnas CU, ayuda base, IA |",
        "| Norma | RF-UXD-049; `06` §6.1–6.2; DIR-12, DIR-13 |",
        "",
        "Estado por fila: `Pendiente` → borrador ScreenHelp → revisado export.",
        "",
        "## M01 PER",
        "",
        "| screenId | ScreenHelp | CU | FAQ distinta | IA uso | Notas |",
        "|---|---|---|---|---|---|",
    ]
    for pid in m01:
        cu = CU_M01.get(pid, "—")
        sh = "Revisado export (T03b)" if pid in NUCLEO_M01 else "Pendiente"
        note = "Núcleo export" if pid in NUCLEO_M01 else ""
        lines.append(f"| {pid} | {sh} | {cu} | No | No | {note} |")
    lines.extend(
        [
            "",
            "## T02 IAM",
            "",
            "| screenId | ScreenHelp | CU | FAQ distinta | IA uso | Notas |",
            "|---|---|---|---|---|---|",
        ]
    )
    for pid in t02:
        cu = CU_T02.get(pid, "—")
        sh = "Revisado export (T03b)" if pid in NUCLEO_T02 else "Pendiente"
        note = "Núcleo export"
        if pid in ("PAN-IAM-01", "PAN-IAM-02"):
            note += "; ayuda formato T03"
        if pid not in NUCLEO_T02:
            note = ""
        lines.append(f"| {pid} | {sh} | {cu} | No | No | {note} |")
    lines.extend(
        [
            "",
            f"**Totales:** M01 = {len(m01)} pantallas; T02 = {len(t02)} pantallas.",
            "",
        ]
    )
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {OUT} ({len(m01)} + {len(t02)} rows)")


if __name__ == "__main__":
    main()