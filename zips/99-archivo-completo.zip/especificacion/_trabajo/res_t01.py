import re
from res_lib import Doc

d = Doc(r'anexos\T01-PLA-*.md')

# --- JOB-PLA-01: excepción explícita en la tabla de clases de cola ---
d.after_line('| `maintenance` | Backups lógicos, purgas, limpieza,', [
    '| — (sin cola; excepción explícita) | JOB-PLA-01 `pla:outbox-relay`: proceso dedicado del worker que lee `outboxEvents` y alimenta la cola `events`; no es un job de BullMQ (ver la nota siguiente y §12) | — | 1 instancia por elección de líder | — |'])

# --- Cat. 2 y 4: destinos y nombres canónicos ---
d.rep('`status` (enum `ok`, `pendingChecklist`, `blocked`), `checklistSnapshotId`, `activatedAt`',
      '`status` (enum `ok`, `pendingChecklist`, `blocked`), `checklistSnapshotId` (→ `tenantChecklists`, instantánea en `snapshots`), `activatedAt`')
ls = d.t.split('\n')
k = [i for i, l in enumerate(ls) if l.startswith('`supportCases`: `number`')]
assert len(k) == 1
new, n = re.subn(r'`grantIds(\[\])?`', lambda m: m.group(0) + ' (→ `supportAccessGrants`)', ls[k[0]], count=1)
assert n == 1
ls[k[0]] = new
d.t = '\n'.join(ls)
d.n += 1
d.rep('`grantId`, `agentUserId`, `tokenJti`', '`supportAccessGrantId` (→ `supportAccessGrants`; nombre canónico de T05, antes `grantId`), `agentUserId`, `tokenJti`')
d.rep('Índice `{ tenantId: 1, grantId: 1 }`.', 'Índice `{ tenantId: 1, supportAccessGrantId: 1 }` (antes `grantId`).')
d.rep('`supportSessions.grantId` | `supportAccessGrants`', '`supportSessions.supportAccessGrantId` (antes `grantId`) | `supportAccessGrants`')
d.rep('`linkedCaseIds`, `postmortemFileId`', '`linkedCaseIds` (→ `supportCases`), `postmortemFileId`')
d.rep('| `bullJobId` | String | No | Identificador del job en BullMQ; nulo para JOB-PLA-01 (proceso dedicado). |',
      '| `jobId` | String | No | Identificador del job en BullMQ (nombre canónico de T05; antes `bullJobId`); nulo para JOB-PLA-01 (proceso dedicado). |')
d.rep('`{tenantId, jobName, bullJobId, status:', '`{tenantId, jobName, jobId (antes bullJobId), status:')
d.rep('| `status` | enum `applied`, `failed`, `rolledBack` | Sí | `failed` bloquea el despliegue; `rolledBack` solo para pasos `expand` sin datos escritos. |',
      '| `status` | enum `applied`, `failed`, `rolledBack` | Sí | `failed` bloquea el despliegue; `rolledBack` solo para pasos de la fase de expansión de `phase` sin datos escritos (antes "pasos `expand`": `expand` es un valor de `phase`, no de `status`). |')
d.rep('| `schemaMigrations` | `applied` | `rolledBack` | Vuelta atrás del release | Solo pasos `expand` sin datos escritos | — |',
      '| `schemaMigrations` | `applied` | `rolledBack` | Vuelta atrás del release | Solo pasos de la fase de expansión (`phase`) sin datos escritos | — |')

# --- Cat. 5: celdas de capability ---
api = {
    'API-PLA-62': '`pla.archivos.ver` (implícita; el control efectivo es la capability de lectura del módulo dueño, que confirma `canAccessFile`; antes "capability de lectura de la entidad dueña del archivo, según storedFiles.moduleCode y ownerRef")',
    'API-PLA-63': '`pla.archivos.subir` (implícita; el control efectivo es la capability de alta o edición del módulo dueño; antes "capability de edición de la entidad a la que se adjunta")',
    'API-PLA-65': '`public: true` (antes "público")',
    'API-PLA-66': '`pla.salud.sondear` (S-SYS; solo red privada del orquestador, sin sesión; antes "Infraestructura: solo red privada del orquestador")',
    'API-PLA-67': '`pla.misProcesos.ver` (alcance self: solo quien lanzó el job; antes "sesión con alcance self sobre jobRuns.requestedBy")',
}
for a, c in api.items():
    d.cell('| %s |' % a, 3, c)

# --- Cat. 7: CU-ARQ-01 de T01 pasa a CU-PLA-15 (dueño de CU-ARQ-01: T11) ---
d.rep('| **CU-ARQ-01** (BASE §58) |', '| **CU-PLA-15** (parte PLA de CU-ARQ-01, dueño T11; antes CU-ARQ-01) (BASE §58) |')
d.rep('| RF-PLA-004, RF-PLA-035, RF-PLA-148, RF-PLA-149, CU-ARQ-01 |', '| RF-PLA-004, RF-PLA-035, RF-PLA-148, RF-PLA-149, CU-PLA-15 (antes CU-ARQ-01) |')

# --- Cat. 1: estados iniciales explícitos ---
d.before_line('`healthSnapshots.status` (`up`, `degraded`, `down`) es una medición inmutable', [
    '| `healthSnapshots` | — | `up` | Muestra de JOB-PLA-08 con el servicio sano | — | — |',
    '| `healthSnapshots` | — | `degraded` | Muestra de JOB-PLA-08 con el servicio degradado | — | — |',
    '| `healthSnapshots` | — | `down` | Muestra de JOB-PLA-08 con el servicio caído | — | PLA-ALR-01 si corresponde |',
    ''])
d.rep('`healthSnapshots.status` (`up`, `degraded`, `down`) es una medición inmutable de cada muestra y no tiene transiciones.',
      '`healthSnapshots.status` (`up`, `degraded`, `down`) es una medición inmutable de cada muestra y no tiene transiciones: cada muestra nace en su valor (filas "—" de la tabla).\n\n'
      '### 8.13. Estados iniciales de las máquinas de §8.2 a §8.11\n\n'
      'Corrección del cierre de residuales (05-11-2026; PA-PLA-15): explicita el estado de alta de las máquinas descritas en texto o con origen implícito. Las transiciones siguen en cada subsección.\n\n'
      '| Colección | Desde | Hacia | Disparador | Guarda (RN) | Evento |\n|---|---|---|---|---|---|\n'
      '| `tenantModuleActivations.mode` | — | `off` | Alta de la activación al licenciar el módulo | Licencia vigente | — |\n'
      '| `tenantChecklists.items.status` | — | `pending` | Generación del checklist del módulo | — | — |\n'
      '| `saasContracts.status` | — | `draft` | Alta del contrato por Comercial | — | — |\n'
      '| `supportCases.status` | — | `received` | Alta del caso (admin, correo, teléfono o plataforma) | — | — |\n'
      '| `platformIncidents.status` | — | `investigating` | Declaración del incidente | — | — |\n'
      '| `restoreRequests.status` | — | `requested` | Operaciones o admin del tenant vía caso (antes "→ `requested`") | Motivo, punto en el tiempo, modo | — |\n'
      '| `alerts.status` | — | `open` | Regla de alerta disparada | Deduplicación por ventana | — |\n'
      '| `tenantExports.status` | — | `queued` | Pedido de exportación (CU-PLA-14) | — | — |\n'
      '| `jobRuns.status` | — | `queued` | Encolado del job | — | — |\n'
      '| `releases.status` | — | `candidate` | Build aprobado por el pipeline | — | — |')

# --- PA-PLA-15 ---
d.before_line('## 22. Trazabilidad de fuentes', '''### PA-PLA-15 — Cierre de residuales del anexo (estados, referencias, API, colas y CU)

- **Pregunta:** ¿cómo se cierran los residuales del anexo detectados por los entregables de análisis?
- **Contexto:** 10 máquinas no declaraban el estado de alta; `schemaMigrations` citaba `expand` (valor de `phase`) como si fuera de `status`; 5 referencias no tenían destino en la definición del campo; 24 colecciones del §7 no tenían tabla de campos; 5 filas de §11 citaban reglas de acceso en lugar de una capability; JOB-PLA-01 corría como "proceso dedicado" sin fila en la tabla de clases de cola; el ID CU-ARQ-01 es de T11.
- **Opciones:**
  - A) Agregar §8.13 y las filas "—" de `healthSnapshots`; aclarar `schemaMigrations`; declarar destinos en cada campo y usar los nombres canónicos de T05 (`supportAccessGrantId`, `jobId`); agregar las tablas de campos de §7.12 (derivadas del texto y de T05, obligatoriedad por regla); usar `public: true` y las capabilities implícitas o técnicas registradas en T02 (PA-IAM-18): `pla.archivos.ver`, `pla.archivos.subir`, `pla.misProcesos.ver`, `pla.salud.sondear`; agregar a la tabla de colas la fila de excepción de JOB-PLA-01; renumerar el CU propio a CU-PLA-15. **(Recomendada)**.
  - B) Mover JOB-PLA-01 a la cola `maintenance` y mantener el resto como está.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** diagramas de estados, ER y contratos OpenAPI de T01.
- **Estado:** Asumida (DEC-072): opción A.
'''.split('\n'))
print('T01 cambios', d.save())
