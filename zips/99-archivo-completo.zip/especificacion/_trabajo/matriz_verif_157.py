"""Compara §15.7 de 04-matriz con las líneas IMPLEMENTAR del plan (solo lectura)."""
import os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
import plan_recuento as pr
from lib_espec import expandir_ids, celdas

ESPEC = pr.ESPEC
M = open(os.path.join(ESPEC, '04-matriz-trazabilidad.md'), encoding='utf-8').read().split('\n')
prompts = {p['id']: p for p in pr.leer_prompts()}
vistos = set()
dif = 0
for i, l in enumerate(M):
    m = re.match(r'^\| (PRO-O\d+-\d+) \| ', l)
    if not m or i < 3000:
        continue
    c = celdas(l)
    if len(c) < 6:
        print('fila corta', i + 1, len(c), l[:120])
        continue
    pid = m.group(1)
    if pid in vistos:
        continue
    vistos.add(pid)
    imp = set(expandir_ids(c[4], 'RF')) | set(expandir_ids(c[4], 'RNF'))
    p = prompts[pid]
    plan = set(p['rf']) | set(p['rnf'])
    if imp != plan or int(c[2]) != len(p['rf']):
        dif += 1
        print(i + 1, pid, 'matriz', c[2], 'plan', len(p['rf']), 'solo matriz', sorted(imp - plan), 'solo plan', sorted(plan - imp))
print('prompts en 15.7', len(vistos), 'diferencias', dif)
