# Edición segura de anexos M01-M06 (ronda de residuales 05-11-2026): conserva BOM y finales de línea.
import glob, os, re

ANEXOS = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'anexos')
LOG = []


class Doc:
    def __init__(self, mod):
        self.path = glob.glob(os.path.join(ANEXOS, mod + '-*.md'))[0]
        self.mod = mod
        raw = open(self.path, 'rb').read()
        self.bom = raw.startswith(b'\xef\xbb\xbf')
        txt = raw.decode('utf-8-sig')
        self.crlf = '\r\n' in txt
        self.t = txt.replace('\r\n', '\n')
        self.n = {}

    def count(self, cat, k=1):
        self.n[cat] = self.n.get(cat, 0) + k

    def rep(self, old, new, cat=None, cnt=1):
        c = self.t.count(old)
        if c != cnt:
            raise SystemExit('%s: se esperaban %d apariciones y hay %d de: %r' % (self.mod, cnt, c, old[:120]))
        self.t = self.t.replace(old, new)
        if cat:
            self.count(cat)

    def rep_line(self, startswith, new, cat=None):
        ls = self.t.split('\n')
        idx = [i for i, l in enumerate(ls) if l.startswith(startswith)]
        if len(idx) != 1:
            raise SystemExit('%s: línea no única (%d): %r' % (self.mod, len(idx), startswith[:100]))
        ls[idx[0]] = new(ls[idx[0]]) if callable(new) else new
        self.t = '\n'.join(ls)
        if cat:
            self.count(cat)

    def insert_before(self, anchor, block, cat=None):
        c = self.t.count(anchor)
        if c != 1:
            raise SystemExit('%s: ancla no única (%d): %r' % (self.mod, c, anchor[:100]))
        self.t = self.t.replace(anchor, block + anchor)
        if cat:
            self.count(cat)

    def insert_after(self, anchor, block, cat=None):
        c = self.t.count(anchor)
        if c != 1:
            raise SystemExit('%s: ancla no única (%d): %r' % (self.mod, c, anchor[:100]))
        self.t = self.t.replace(anchor, anchor + block)
        if cat:
            self.count(cat)

    def section(self, num):
        ls = self.t.split('\n')
        a = next(i for i, l in enumerate(ls) if l.startswith('## %d.' % num))
        b = next(i for i, l in enumerate(ls) if i > a and l.startswith('## '))
        return a, b

    def anchor_field_tables(self, cat='3'):
        """Antepone `**`x`** — campos.` a cada "Campos de `x`" del §7 cuyo título (### 7.x) no empieza por `x`,
        para que cada tabla quede asociada a su colección."""
        ls = self.t.split('\n')
        a, b = self.section(7)
        first = None
        out, k = [], 0
        for i, l in enumerate(ls):
            if a <= i < b:
                if l.startswith('### '):
                    tk = re.findall(r'`([A-Za-z0-9_]+)`', l)
                    first = tk[0] if tk else None
                elif l.startswith('**`'):
                    tk = re.findall(r'`([A-Za-z0-9_]+)`', l)
                    first = tk[0] if tk else first
                m = re.match(r'^Campos de `([A-Za-z0-9_]+)`', l)
                if m and m.group(1) != first:
                    prev = out[-2] if len(out) >= 2 else ''
                    if not prev.startswith('**`%s`**' % m.group(1)):
                        out += ['**`%s`** — tabla de campos.' % m.group(1), '']
                        k += 1
                    first = m.group(1)
            out.append(l)
        self.t = '\n'.join(out)
        if k:
            self.count(cat, k)
        return k

    def save(self):
        txt = self.t.replace('\n', '\r\n') if self.crlf else self.t
        data = txt.encode('utf-8')
        if self.bom:
            data = b'\xef\xbb\xbf' + data
        open(self.path, 'wb').write(data)
        LOG.append((self.mod, dict(self.n)))
        print(self.mod, 'guardado', dict(sorted(self.n.items())))
