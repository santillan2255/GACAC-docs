﻿import re
L=open('anexos/T09-COM-comunidad-comunicaciones.md',encoding='utf-8').read().split('\n')
for i,l in enumerate(L[2198:2262],start=2199):
    m=re.match(r'\| (PAN-COM-\d+) \| ([^|]*)\| ([^|]*)\|',l)
    if m: print(i,m.group(1),'|',m.group(2)[:90],'|',m.group(3)[:80])
