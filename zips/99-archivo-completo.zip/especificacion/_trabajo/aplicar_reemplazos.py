"""Aplica reemplazos exactos (1 coincidencia cada uno) preservando BOM y verificando barras por línea.

Uso: python aplicar_reemplazos.py lote.json
lote.json = [{"archivo": "...", "viejo": "...", "nuevo": "...", "filas_nuevas": 0}, ...]
"""
import json
import sys
from pathlib import Path


def main():
    lote = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    raiz = Path(__file__).resolve().parents[3]
    por_archivo = {}
    for r in lote:
        por_archivo.setdefault(r['archivo'], []).append(r)
    errores = 0
    for archivo, reps in por_archivo.items():
        p = raiz / archivo
        crudo = p.read_bytes()
        bom = crudo.startswith(b'\xef\xbb\xbf')
        texto = crudo.decode('utf-8-sig')
        barras_antes = texto.count('|')
        esperado = barras_antes
        crlf = '\r\n' in texto
        for r in reps:
            viejo, nuevo = r['viejo'], r['nuevo']
            if crlf:
                viejo, nuevo = viejo.replace('\n', '\r\n'), nuevo.replace('\n', '\r\n')
            n = texto.count(viejo)
            if n != 1:
                print(f'ERROR {archivo}: {n} coincidencias para {viejo[:70]!r}')
                errores += 1
                continue
            esperado += nuevo.count('|') - viejo.count('|')
            texto = texto.replace(viejo, nuevo)
        if texto.count('|') != esperado:
            print(f'ERROR {archivo}: barras {texto.count("|")} != {esperado}; no se escribe')
            errores += 1
            continue
        p.write_bytes((b'\xef\xbb\xbf' if bom else b'') + texto.encode('utf-8'))
        print(f'OK {archivo}: {len(reps)} reemplazos, barras {barras_antes} -> {texto.count("|")}')
    sys.exit(1 if errores else 0)


if __name__ == '__main__':
    main()
