"""Edición de anexos M12-M19 (residuales 05-11-2026): conserva BOM y finales de línea."""
import os, glob

ANEXOS = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
MOJI = ['Ã¡', 'Ã©', 'Ã­', 'Ã³', 'Ãº', 'Ã±', 'â€', 'Â°', 'Â§', '\ufffd']


class Doc:
    def __init__(self, name):
        p = glob.glob(os.path.join(ANEXOS, name))
        assert len(p) == 1, (name, p)
        self.path = p[0]
        raw = open(self.path, 'rb').read()
        self.bom = raw.startswith(b'\xef\xbb\xbf')
        t = raw.decode('utf-8-sig')
        self.crlf = '\r\n' in t
        self.t = t.replace('\r\n', '\n')
        self.moji0 = sum(self.t.count(m) for m in MOJI)
        self.n = 0
        self.cats = {}

    def rep(self, old, new, count=1, cat=0):
        c = self.t.count(old)
        assert c == count, 'esperaba %d y hay %d: %r' % (count, c, old[:200])
        self.t = self.t.replace(old, new)
        self.n += 1
        self.cats[cat] = self.cats.get(cat, 0) + count

    def insert_before(self, anchor, text, cat=0):
        assert self.t.count(anchor) == 1, ('ancla', anchor, self.t.count(anchor))
        self.t = self.t.replace(anchor, text + anchor)
        self.n += 1
        self.cats[cat] = self.cats.get(cat, 0) + 1

    def save(self):
        m = sum(self.t.count(x) for x in MOJI)
        assert m <= self.moji0, 'mojibake nuevo en ' + self.path
        t = self.t.replace('\n', '\r\n') if self.crlf else self.t
        open(self.path, 'wb').write((b'\xef\xbb\xbf' if self.bom else b'') + t.encode('utf-8'))
        print('guardado', os.path.basename(self.path), 'cambios', self.n, 'por categoría', dict(sorted(self.cats.items())))
