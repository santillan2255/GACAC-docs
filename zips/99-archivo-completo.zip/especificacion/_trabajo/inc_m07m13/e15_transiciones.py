"""Categoría 5: tablas de transición para colecciones del §7 que solo enumeraban estados."""
from ed import load, save

H = "| Colección | Desde | Hacia | Disparador | Guarda | Evento |\n|---|---|---|---|---|---|\n"

SEC = {
    "M07": ("### 8.16 Otras colecciones con estado (`currentAccounts.status`, `allocations.status`)",
            "Los valores ya estaban en §7; se explicitan las transiciones.",
            [
                ("`currentAccounts`", "(nuevo)", "`active`", "Alta de la cuenta del titular (M01)", "—", "—"),
                ("`currentAccounts`", "`active`", "`closed`", "Cierre de la cuenta en M01", "Saldo cero y sin obligaciones abiertas", "—"),
                ("`allocations`", "(nuevo)", "`active`", "Imputación de un recibo, saldo a favor o nota de crédito", "Importe ≤ saldo abierto de la obligación", "`cob.payment.confirmed` (EVT-COB-04)"),
                ("`allocations`", "`active`", "`reversed`", "Anulación del recibo o reasignación de la imputación", "La imputación no fue revertida antes", "`cob.allocation.reversed` (EVT-COB-06); `cob.receipt.voided` (EVT-COB-05) si anula el recibo"),
            ]),
    "M08": ("### 8.13 Otras colecciones con estado (lotes, evaluaciones, obligaciones de convenio, seguimientos)",
            "Los valores ya estaban en §7; se explicitan las transiciones.",
            [
                ("`delinquencyBatches`", "(nuevo)", "`running`", "Generación o proceso de un lote de instancia", "—", "—"),
                ("`delinquencyBatches`", "`running`", "`completed`", "Fin del proceso sin error", "—", "`mor.batch.generated` (EVT-MOR-07)"),
                ("`delinquencyBatches`", "`running`", "`failed`", "Error del job", "—", "—"),
                ("`delinquencyBatches`", "`completed`", "`annulled`", "Anulación del lote", "Notificaciones del lote no procesadas", "`mor.batch.annulled` (EVT-MOR-07)"),
                ("`delinquencyEvaluations`", "(nuevo)", "`open`", "Evaluación de la cuenta a una fecha", "—", "—"),
                ("`delinquencyEvaluations`", "`open`", "`closed`", "Decisión por servicio registrada", "Todas las decisiones de `perService[]` cargadas", "`mor.evaluation.closed` (EVT-MOR-06)"),
                ("`agreementObligations`", "(nuevo)", "`included`", "Alta del convenio con la obligación", "—", "—"),
                ("`agreementObligations`", "`included`", "`restored`", "Anulación o caducidad del convenio", "—", "—"),
                ("`collectionFollowUps`", "(nuevo)", "`open`", "Alta del seguimiento de gestión", "—", "—"),
                ("`collectionFollowUps`", "`open`", "`closed`", "Resultado registrado por el gestor", "—", "—"),
            ]),
    "M09": ("### 8.12 Otras colecciones con estado (`crmProjects.status`, `crmChannels.status`)",
            "Los valores ya estaban en §7; se explicitan las transiciones.",
            [
                ("`crmProjects`", "(nuevo)", "`active`", "Alta del proyecto", "—", "—"),
                ("`crmProjects`", "`active`", "`onHold`", "Pausa por el responsable", "—", "—"),
                ("`crmProjects`", "`onHold`", "`active`", "Reanudación", "—", "—"),
                ("`crmProjects`", "`active` · `onHold`", "`closed`", "Cierre por el responsable", "Sin casos abiertos del proyecto", "—"),
                ("`crmChannels`", "(nuevo)", "`draft`", "Alta del canal", "—", "—"),
                ("`crmChannels`", "`draft`", "`testing`", "Prueba de conexión", "Credenciales del conector cargadas (T06)", "—"),
                ("`crmChannels`", "`testing`", "`active`", "Activación", "Prueba exitosa", "—"),
                ("`crmChannels`", "`active`", "`suspended`", "Suspensión manual o caída del conector", "—", "—"),
                ("`crmChannels`", "`suspended`", "`active`", "Reactivación", "Prueba exitosa", "—"),
            ]),
    "M13": ("### 8.12 Otras colecciones con estado (`lots.status`, `reorderSuggestions.status`)",
            "Los valores ya estaban en §7; se explicitan las transiciones.",
            [
                ("`lots`", "(nuevo)", "`available`", "Ingreso del lote", "—", "—"),
                ("`lots`", "`available`", "`blocked`", "Bloqueo de calidad", "—", "—"),
                ("`lots`", "`blocked`", "`available`", "Liberación", "—", "—"),
                ("`lots`", "`available` · `blocked`", "`expired`", "Job de vencimiento", "Fecha de vencimiento cumplida", "—"),
                ("`lots`", "`available`", "`depleted`", "Último egreso", "Saldo del lote cero", "—"),
                ("`reorderSuggestions`", "(nuevo)", "`open`", "Corrida de reposición", "Saldo bajo mínimo o punto de pedido", "`stk.reorder.suggested` (EVT-STK-13)"),
                ("`reorderSuggestions`", "`open`", "`converted`", "Conversión en solicitud de M12", "—", "—"),
                ("`reorderSuggestions`", "`open`", "`dismissed`", "Descarte por el usuario", "—", "—"),
            ]),
}

for o, (head, intro, rows) in SEC.items():
    t, bom, crlf = load(o)
    L = t.split("\n")
    i0 = next(i for i, l in enumerate(L) if l.startswith("## 8."))
    i1 = next(i for i in range(i0 + 1, len(L)) if L[i].startswith("## "))
    num = head.split()[1]
    assert not any(l.startswith("### " + num + " ") for l in L), (o, num)
    block = [head, "", intro, "", "Estado inicial: ver las filas `(nuevo)`.", ""] + H.rstrip("\n").split("\n") + \
            ["| " + " | ".join(r) + " |" for r in rows] + [""]
    L[i1:i1] = block
    save(o, "\n".join(L), bom, crlf)
    print(o, len(rows))
