import sys, os, json, re
sys.path.insert(0, r"c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo")
import generar_er_completo as g

OWNERS = ["M07", "M08", "M09", "M10", "M11", "M12", "M13"]
rows, by_id, by_name, model, vol, ttl, alt = g.build()
out = {}
for o in OWNERS:
    mo = model[o]
    ents = {}
    for n, e in mo["ents"].items():
        a = e["anchor"]
        ents[n] = {
            "id": e["row"]["id"], "anchor": list(a) if a else None, "parsed": e["parsed"],
            "line": e.get("line"), "section": e["section"][1] if e["section"] else None,
            "fields": {k: {kk: vv for kk, vv in f.items()} for k, f in e["fields"].items()},
            "refs": e["row"]["refs"], "purpose": e["row"]["purpose"],
        }
    out[o] = {"file": mo["file"], "ents": ents}
json.dump(out, open(os.path.join(os.path.dirname(__file__), "modelo.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for o in OWNERS:
    ents = out[o]["ents"]
    kinds = {}
    for n, e in ents.items():
        k = e["anchor"][3] if e["anchor"] else "none"
        kinds[k] = kinds.get(k, 0) + 1
    notab = [n for n, e in ents.items() if not e["anchor"] or e["anchor"][3] != "heading" or True]
    t05only = sum(1 for e in ents.values() for f in e["fields"].values() if f["src"] == "T05")
    unres = sum(1 for e in ents.values() for f in e["fields"].values() if "fk" in f and not f["fk"])
    inf = sum(1 for e in ents.values() for f in e["fields"].values() if f.get("fk") and f.get("fkhow") not in ("anexo", "t05", "canon", "exact"))
    print(o, len(ents), kinds, "T05only", t05only, "unres", unres, "inf", inf)
