import re, sys
from ed import load
OBJ = {
    "M07": ["allocationPolicies", "accountStatements", "cashRegisters", "paymentTenders", "staticQrCodes", "collectorSettlements",
            "collectionAgencies", "paymentReferences", "agencyPublishedDebts", "agencyNoveltyFiles", "gatewayTransactions",
            "gatewayWebhookEvents", "thirdPartyCollections", "externalObligationImports"],
    "M08": ["holdReasons", "delinquencyStages", "delinquencyNoticeModels", "delinquencyReasons", "financingInstitutionPlans"],
    "M09": ["crmCaseSubtypes", "crmCalendarEvents"],
    "M10": ["damageAssessments", "technicalProcedures", "waterSamples"],
    "M13": ["stockBalances", "fixedAssetValueChanges", "mrpRuns"],
}
for o, names in OBJ.items():
    t, _, _ = load(o)
    L = t.split("\n")
    for n in names:
        hits = [i for i, l in enumerate(L) if ("`%s`" % n) in l and ("Campos" in l or l.startswith("###") or l.startswith("- `" + n) or l.startswith("**`" + n) or ("**`%s`**" % n) in l or l.startswith("`" + n))]
        print("==", o, n, [h + 1 for h in hits][:6])
        for h in hits[:3]:
            for j in range(h, min(h + 4, len(L))):
                l = L[j]
                for mm in re.finditer(r"`(status|stockState|defaultStatus)`[^;,]{0,160}", l):
                    print("   %d: %s" % (j + 1, mm.group(0)))
