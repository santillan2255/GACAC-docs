"""M10 §10: capability o regla de acceso para PAN-TEC-33, 49, 50..60 (app de campo y portal)."""
from ed import load, save, edit

print(edit("M10", [
    ("| PAN-TEC-33 | Red v1 (absorbida) | — | No existe como pantalla; se migra a PAN-TEC-30/31. | — |",
     "| PAN-TEC-33 | Red v1 (absorbida) | Sin ruta: no se publica (absorbida en PAN-TEC-30/31) | No existe como pantalla; se migra a PAN-TEC-30/31. | No aplica: sin pantalla propia; el acceso es el de PAN-TEC-30 (`tec.network.configure`) y PAN-TEC-31 (`tec.network.manage`) |"),
    ("| PAN-TEC-49 | Carga rápida de reclamo | — | Reemplazada por M09 (caso) + derivación a OT. | — |",
     "| PAN-TEC-49 | Carga rápida de reclamo | Sin ruta en M10: se abre la carga de caso de M09 | Reemplazada por M09 (caso) + derivación a OT. | No aplica en M10: el acceso es el de la carga de caso de M09 (`crm.casos.crear`) y la derivación a OT (`tec.ot.crearDerivada`) |"),
]))

CAMPO = {
    "PAN-TEC-60": "`tec.campo.ver`",
    "PAN-TEC-50": "`tec.campo.ver`",
    "PAN-TEC-51": "`tec.campo.ejecutar` (con `tec.campo.enCamino`, `tec.campo.evidencia`, `tec.campo.materiales`, `tec.campo.conformidad` y `tec.campo.cerrar` por paso)",
    "PAN-TEC-52": "`stk.custodia.ver`; devolución con `tec.campo.materiales`",
    "PAN-TEC-53": "`tec.campo.ver`; descartar evidencia exige supervisor",
    "PAN-TEC-54": "`tec.inspecciones.editar` y `tec.campo.ejecutar`",
    "PAN-TEC-55": "`tec.campo.crearOt` (si V2 #2/#30)",
    "PAN-TEC-56": "`tec.campo.ver`",
}
PORTAL = {
    "PAN-TEC-57": "`por.visitas.reservar` (sesión de socio, contratos o casos propios o con relación autorizada)",
    "PAN-TEC-58": "`por.visitas.ver`; `por.visitas.reprogramar` y `por.visitas.cancelar` para las acciones (sesión de socio, datos propios)",
    "PAN-TEC-59": "`por.visitas.ver` (sesión de socio, gestiones propias; sin datos internos de red)",
}

t, bom, crlf = load("M10")
L = t.split("\n")
h2 = "| ID | Pantalla | Ruta | Propósito / componentes | Perfil | Ola |"
i = L.index(h2)
L[i] = "| ID | Pantalla | Ruta | Propósito / componentes | Perfil | Capability | Ola |"
L[i + 1] = "|---|---|---|---|---|---|---|"
j = i + 2
while L[j].startswith("| PAN-TEC-"):
    c = L[j].rstrip().rstrip("|").rstrip().split(" | ")
    pid = c[0].lstrip("| ").strip()
    assert len(c) == 6 and pid in CAMPO, (pid, len(c))
    c.insert(5, CAMPO[pid])
    L[j] = " | ".join(c) + " |"
    j += 1
h3 = "| ID | Pantalla | Ruta | Propósito | Ola |"
i = L.index(h3)
L[i] = "| ID | Pantalla | Ruta | Propósito | Capability | Ola |"
L[i + 1] = "|---|---|---|---|---|---|"
j = i + 2
while L[j].startswith("| PAN-TEC-"):
    c = L[j].rstrip().rstrip("|").rstrip().split(" | ")
    pid = c[0].lstrip("| ").strip()
    assert len(c) == 5 and pid in PORTAL, (pid, len(c))
    c.insert(4, PORTAL[pid])
    L[j] = " | ".join(c) + " |"
    j += 1
save("M10", "\n".join(L), bom, crlf)
print("ok")
