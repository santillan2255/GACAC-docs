"""Categoría 6: criterio de aceptación verificable para RF que tenían '—'."""
from ed import load, save

C = {
    "M09": {
        "RF-CRM-181": "M09 no genera archivos de discador: el universo de casos se entrega a T09 por consulta filtrada y T09 produce el archivo del canal IVR con el modelo heredado; ninguna pantalla de M09 exporta ese archivo.",
        "RF-CRM-184": "Un aviso de caso se emite a T09 sin dirección de destino; T09 elige móvil de la cuenta, teléfono web o teléfono de la persona según preferencia y verificación, y el destino usado queda en la comunicación vinculada al caso.",
        "RF-CRM-254": "Ninguna exportación regulatoria ni informe de deuda se emite desde M09; cada salida listada en §22 existe en el módulo destino (M06, T10, M08 o M10) con su propio ID.",
        "RF-CRM-255": "Al cambiar un caso a un tipo o estado con plantilla configurada (PRM-CRM-056), M09 envía a T09 solo la clave de plantilla y las variables; si la clave no existe en T09 la configuración se rechaza.",
        "RF-CRM-256": "Al cerrar un caso con encuesta habilitada, la encuesta se envía con el motor de T09 y la respuesta queda vinculada al caso (RF-CRM-119); M09 no mantiene un editor propio de encuestas.",
    },
    "M10": {
        "RF-TEC-133": "Con el parámetro activo, una OT de corte por mora se genera aunque falte la observación técnica y queda marcada como tal; con el parámetro inactivo la generación se rechaza indicando el dato faltante.",
        "RF-TEC-199": "La exportación KML de una central contiene una marca por central, repartidor y caja con su identificador y coordenadas; los elementos sin coordenadas se informan aparte y no se exportan.",
        "RF-TEC-208": "Con la regla de exclusión configurada en el lector, los números excluidos no generan registros importados y los de Telco IP clave 99 se importan con importe 0; sin la regla se importan normalmente.",
        "RF-TEC-214": "Si el archivo trae llamadas rechazadas, se importan con público, abonado y duración y quedan marcadas como rechazadas; si el formato no las trae, la importación no falla.",
        "RF-TEC-220": "Sin permiso de ubicación la app funciona y no registra posición; con permiso, la posición se guarda como dato auxiliar y nunca modifica el domicilio contratado sin una acción explícita del usuario.",
        "RF-TEC-225": "La vista previa permite marcar registros y exportar a KML solo los marcados (o todos si no hay marca); el archivo abre en Google Earth con una marca por registro con coordenadas.",
    },
    "M12": {
        "RF-CMP-147": "M12 no ofrece opciones de partes de producción; las SA de fabricación recibidas desde M13 se procesan como cualquier SA con su origen identificado.",
    },
}

for owner, mp in C.items():
    t, bom, crlf = load(owner)
    L = t.split("\n")
    n = 0
    for i, l in enumerate(L):
        for k, v in mp.items():
            if l.startswith("| " + k + " |"):
                assert l.endswith("| — |"), l
                L[i] = l[: -len("— |")] + v + " |"
                n += 1
    assert n == len(mp), (owner, n)
    save(owner, "\n".join(L), bom, crlf)
    print(owner, n)
