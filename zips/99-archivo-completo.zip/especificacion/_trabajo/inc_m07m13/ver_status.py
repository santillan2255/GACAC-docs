import json, sys
from ed import load
m = json.load(open("modelo.json", encoding="utf-8"))
OBJ = {
    "M07": ["allocationPolicies", "accountStatements", "cashRegisters", "paymentTenders", "staticQrCodes", "collectorSettlements",
            "collectionAgencies", "paymentReferences", "agencyPublishedDebts", "agencyNoveltyFiles", "gatewayTransactions",
            "gatewayWebhookEvents", "thirdPartyCollections", "externalObligationImports"],
    "M08": ["holdReasons", "delinquencyStages", "delinquencyNoticeModels", "delinquencyReasons", "financialEntities"],
    "M09": ["crmCaseSubtypes", "crmCalendarEvents"],
    "M10": ["connectionEstimates", "damageAssessments", "technicalProcedures", "fieldForms", "fieldDevices", "onCallShifts", "waterSamples"],
    "M13": ["stockBalances", "fixedAssetValueChanges", "mrpRuns"],
}
for o, names in OBJ.items():
    t, _, _ = load(o)
    L = t.split("\n")
    ents = m[o]["ents"]
    for n in names:
        e = ents.get(n)
        if not e:
            print(o, n, "NO ENT"); continue
        a = e["anchor"]
        ln = a[1] if isinstance(a, list) else a.get("line")
        print("==", o, n, a)
        for j in range(ln - 1, min(ln + 25, len(L))):
            if "tatus" in L[j] or "stockState" in L[j]:
                print("  %d: %s" % (j + 1, L[j][:400]))
