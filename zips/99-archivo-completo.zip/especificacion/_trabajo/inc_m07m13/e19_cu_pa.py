from ed import edit
P = "pendiente de decisión (pregunta abierta en el informe de corrección de inconsistencias"
print(edit("M09", [
    ("Definición dueña pendiente (PA-INC-M09-01): M02 también lo describe «en lo que toca al contrato»; mientras tanto,",
     "Definición dueña " + P + "; propuesta: este anexo). M02 también lo describe «en lo que toca al contrato»; mientras tanto,"),
    ("Definición dueña pendiente (PA-INC-M08-01; propuesta: M08 «CU-CIC-01»).",
     "Definición dueña " + P + "; propuesta: M08 «CU-CIC-01»)."),
]))
print(edit("M08", [
    ("Definición dueña pendiente (PA-INC-M08-01; propuesta: este anexo,",
     "Definición dueña " + P + "; propuesta: este anexo,"),
]))
