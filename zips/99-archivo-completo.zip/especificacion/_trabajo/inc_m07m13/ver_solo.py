import re
from ed import load
OBJ = {"M07": ["currentAccounts", "allocations"],
       "M08": ["interestBillingRunItems", "delinquencyBatches", "delinquencyEvaluations", "agreementObligations", "agreementInstallments", "collectionFollowUps"],
       "M09": ["crmProjects", "crmWorkLogs", "crmChannels"],
       "M13": ["stockMovements", "lots", "revaluations", "reorderSuggestions"]}
for o, ns in OBJ.items():
    t, _, _ = load(o)
    L = t.split("\n")
    for n in ns:
        for i, l in enumerate(L):
            if ("`%s`" % n) in l and (l.startswith("#") or l.startswith("- `") or l.startswith("`" + n) or "Campos" in l):
                seg = L[i:i + 30]
                for j, s in enumerate(seg):
                    for m in re.finditer(r"`(status|state)`[^;]{0,200}", s):
                        if "`" in m.group(0)[9:]:
                            print(o, n, i + j + 1, m.group(0)[:200]); break
                    else:
                        continue
                    break
                break
