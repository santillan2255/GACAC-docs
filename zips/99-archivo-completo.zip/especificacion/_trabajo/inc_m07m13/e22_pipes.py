"""Escapa '|' dentro de spans de código en filas de tabla cuya cantidad de columnas no coincide con el encabezado."""
import re
from ed import load, save


def esc_code(l):
    out, i = [], 0
    parts = re.split(r"(`[^`]*`)", l)
    return "".join(re.sub(r"(?<!\\)\|", r"\\|", p) if p.startswith("`") and p.endswith("`") and len(p) > 1 else p for p in parts)


tot = {}
for o in ["M07", "M08", "M09", "M10", "M11", "M12", "M13"]:
    t, bom, crlf = load(o)
    L = t.split("\n")
    n_fix = 0
    i = 0
    while i < len(L):
        if L[i].startswith("|") and i + 1 < len(L) and re.match(r"^\|[\s:|-]+\|\s*$", L[i + 1]):
            n = len(re.findall(r"(?<!\\)\|", L[i]))
            j = i + 2
            while j < len(L) and L[j].startswith("|"):
                if len(re.findall(r"(?<!\\)\|", L[j])) != n:
                    f = esc_code(L[j])
                    if len(re.findall(r"(?<!\\)\|", f)) == n:
                        L[j] = f
                        n_fix += 1
                j += 1
            i = j
        else:
            i += 1
    save(o, "\n".join(L), bom, crlf)
    tot[o] = n_fix
print(tot)
