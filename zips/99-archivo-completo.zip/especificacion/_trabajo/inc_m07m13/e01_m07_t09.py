from ed import edit

N = " (T09 envía la comunicación; antes figuraba M10 por error)"
print(edit("M07", [
    ("| obligación, fecha, canal | M08 (reconexión, instancias), M05, COB (deuda publicada), M10 |",
     "| obligación, fecha, canal | M08 (reconexión, instancias), M05, COB (deuda publicada), T09 (cancela recordatorios; antes M10) |"),
    ("| M15 (asiento por entidad), M08, M10 (aviso), M19, M14 (caja virtual) |",
     "| M15 (asiento por entidad), M08, T09 (aviso; antes M10), M19, M14 (caja virtual) |"),
    ("| obligación, código, definitivo | M10 (aviso), M08 |",
     "| obligación, código, definitivo | T09 (aviso; antes M10), M08 |"),
    ("| adhesión | M05 (leyenda en factura), M10 |",
     "| adhesión | M05 (leyenda en factura), T09 (aviso; antes M10) |"),
    ("| transacción, cuentas | M08 (cargos), M15, M10 |",
     "| transacción, cuentas | M08 (cargos), M15, T09 (aviso; antes M10) |"),
    ("| Cambio de estado | intención | M19, M10 |",
     "| Cambio de estado | intención | M19, T09 (aviso del link; antes M10) |"),
    ("| M10 comunicaciones | Interno | Envío de recibos, links, avisos de rechazo | Plantillas `cob.*` | Eventos | O5 |",
     "| T09 comunicaciones (antes figuraba \"M10 comunicaciones\" por error) | Interno | Envío de recibos, links, avisos de rechazo | Plantillas `cob.*` | Eventos y comando `com.communications.emit` (API-COM-75) | O5 |"),
    ("| Enviar por canal M10. |",
     "| Enviar por el motor de comunicaciones de T09 (`com.communications.emit`; antes \"canal M10\"). |"),
]))
