"""M09 §11: capabilities en filas con regla de acceso, servicio interno crm.openCase (§11.5) y API-CRM-80."""
from ed import edit

PUB = "`public: true` (sin capability, RF-IAM-061"
print(edit("M09", [
    ("| API-CRM-05 | POST | `/api/admin/crm/cases/:id/transitions` | según transición |",
     "| API-CRM-05 | POST | `/api/admin/crm/cases/:id/transitions` | `crm.casos.editar` más la capability propia de la transición según §8.1 (`crm.casos.resolver`, `crm.casos.cerrar`, `crm.casos.reabrir`, `crm.casos.anular`, `crm.casos.derivar`); antes \"según transición\" |"),
    ("| `/api/public/:tenantSlug/crm/cancellation-form` | — |",
     "| `/api/public/:tenantSlug/crm/cancellation-form` | " + PUB + ") |"),
    ("| `/api/public/:tenantSlug/crm/cancellations` | — (rate limit + captcha) |",
     "| `/api/public/:tenantSlug/crm/cancellations` | " + PUB + "; rate limit + captcha) |"),
    ("| `/api/public/:tenantSlug/crm/cases/status?number=&code=` | — |",
     "| `/api/public/:tenantSlug/crm/cases/status?number=&code=` | " + PUB + "; número y código verificador) |"),
    ("| `/api/public/:tenantSlug/crm/webchat/sessions` · `/messages` | — |",
     "| `/api/public/:tenantSlug/crm/webchat/sessions` · `/messages` | " + PUB + "; rate limit) |"),
    ("| `/api/public/:tenantSlug/crm/outages` | — |",
     "| `/api/public/:tenantSlug/crm/outages` | " + PUB + ") |"),
    ("| `/api/public/:tenantSlug/crm/queue/displays/:displayId/stream` | token de pantalla |",
     "| `/api/public/:tenantSlug/crm/queue/displays/:displayId/stream` | `crm.turnero.pantalla.ver` (cuenta técnica S-KSK de la pantalla enrolada; antes \"token de pantalla\") |"),
    ("| `/api/public/:tenantSlug/crm/queue/kiosks/:kioskId/tickets` | token de dispositivo |",
     "| `/api/public/:tenantSlug/crm/queue/kiosks/:kioskId/tickets` | `crm.turnero.emitir` (cuenta técnica S-KSK del tótem enrolado; antes \"token de dispositivo\") |"),
    ("| `/api/v1/ext/crm/webhooks/:channelKind/:connectionId` | firma del proveedor |",
     "| `/api/v1/ext/crm/webhooks/:channelKind/:connectionId` | `crm.webhooks.recibir` (cuenta técnica del canal; la llamada se autentica con la firma del proveedor) |"),
    ("| `/api/v1/ext/crm/ivr/:connectionId/lookup` · `/cases` | token de integración |",
     "| `/api/v1/ext/crm/ivr/:connectionId/lookup` · `/cases` | `crm.ivr.consultar` (`lookup`) y `crm.casos.crear` (`/cases`) (scope del cliente API de la integración IVR; antes \"token de integración\") |"),
    ("| API-CRM-80 | — (servicio interno) | `crmService.createCase`, `crmService.getIncidentSummaryForWorkOrder`, `crmService.getCaseLinks` | módulos internos | Comandos y consultas que invocan M03/M05/M08/M10/M19 | Sí |",
     "| API-CRM-80 | — | — | — | **Reemplazado por servicios internos** `crm.openCase` (antes `crmService.createCase`), `crm.getIncidentSummaryForWorkOrder` (antes `crmService.getIncidentSummaryForWorkOrder`) y `crm.getCaseLinks` (antes `crmService.getCaseLinks`), definidos en §11.5: no son rutas HTTP. Descripción original: \"Comandos y consultas que invocan M03/M05/M08/M10/M19\". | — |"),
]))

BLOQUE = """
### 11.5 Servicios internos (no HTTP)

Llamadas en proceso entre módulos del monolito modular (DEC-003). El módulo invocante usa su cuenta técnica (T02 RF-IAM-115) con la capability indicada; `tenantId` y actor salen del contexto de la llamada, nunca de la entrada.

| Servicio | Invocante | Capability de la cuenta técnica | Entrada | Salida | Errores |
|---|---|---|---|---|---|
| `crm.openCase` (antes `crmService.createCase`) | M19 (envío de formularios del portal, §9.5 de M19), M03, M05, M08, M10 | `crm.casos.crear` | `{ caseTypeCode, caseSubtypeCode?, kind?, subject, description, origin: { module, sourceRef, channelKind?, intakeRouteCode?, conversationId? }, requester: { personId?, userId?, displayName, documentType?, documentNumber?, phone?, email? }, context?: { accountId?, contractId?, serviceId?, requestedServiceId?, requestedPlanId?, premiseId?, servicePointId?, invoiceId?, geo? }, requirements?[], acceptedTerms?[], documentIds?[], customFields?, priority?, idempotencyKey }`. `caseTypeCode` es el `code` de `crmCaseTypes` (M19 cita `type=solicitudAlta`; para el alta de servicio el tipo es `serviceActivation`, §9.2). | `{ caseId, number, baseStatus, status, slaResolutionDueAt?, possibleDuplicateOf?, receiptDocumentId?, created }`; `created = false` cuando la misma `idempotencyKey` ya creó el caso (devuelve el mismo caso). | `crm.caseType.notFound` o `crm.caseType.inactive` (tipo inexistente o inactivo); `crm.case.validation` (faltan datos mínimos del tipo o la vía de ingreso no está habilitada, RN-CRM-058); `crm.case.accountNotAuthorized` (la cuenta no pertenece al solicitante, RN-CRM-005); `crm.idempotency.conflict` (misma clave con otra entrada). |
| `crm.getIncidentSummaryForWorkOrder` (antes `crmService.getIncidentSummaryForWorkOrder`) | M10 | `crm.casos.ver` | `{ workOrderId }` | Resumen del incidente común vinculado a la OT (datos de `crmIncidents`) o `null` si no hay [VERIFICAR] | No declarados en el anexo [VERIFICAR] |
| `crm.getCaseLinks` (antes `crmService.getCaseLinks`) | M03, M05, M08, M10, M19 | `crm.casos.ver` | `{ caseId }` | `crmCases.links[]` (`entityType`, `entityId`, `relation`) | No declarados en el anexo [VERIFICAR] |

Efectos de `crm.openCase`: los del paso 5 de §9.1 (caso, primer `crmCaseEvents`, outbox `crm.case.created` EVT-CRM-01, número del contador atómico, SLA). Sin cuenta identificada el caso se crea con `context.accountId = null` y marca "cuenta a identificar" (RN-CRM-005, §9.1 paso 2); la detección de duplicados marca `possibleDuplicateOf` y no bloquea (§9.1 paso 6).
"""
print(edit("M09", [("\n\n## 12. Eventos y jobs\n", "\n" + BLOQUE + "\n## 12. Eventos y jobs\n")]))
