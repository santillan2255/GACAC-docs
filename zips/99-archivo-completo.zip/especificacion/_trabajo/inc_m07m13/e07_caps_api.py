"""Categoría 1: filas API con rol o texto libre en la columna Capability (M07, M08, M11)."""
from ed import edit

PUB = "`public: true` (sin capability, RF-IAM-061"
print("M07", edit("M07", [
    ("| `/api/public/{tenantSlug}/cob/payment-references/{code}` | Público (rate limit) |",
     "| `/api/public/{tenantSlug}/cob/payment-references/{code}` | " + PUB + "; rate limit; antes \"Público (rate limit)\") |"),
    ("| `/api/public/{tenantSlug}/cob/payment-references/{code}/intents` | Público (rate limit + captcha) |",
     "| `/api/public/{tenantSlug}/cob/payment-references/{code}/intents` | " + PUB + "; rate limit + captcha; antes \"Público (rate limit + captcha)\") |"),
    ("| `/api/public/{tenantSlug}/cob/receipts/verify/{validationCode}` | Público |",
     "| `/api/public/{tenantSlug}/cob/receipts/verify/{validationCode}` | " + PUB + "; antes \"Público\") |"),
]))
print("M08", edit("M08", [
    ("| `/api/platform/mor/restriction-rules[/:id]` | plataforma |",
     "| `/api/platform/mor/restriction-rules[/:id]` | `mor.plataforma.restricciones.configurar` (rol de plataforma; antes \"plataforma\") |"),
    ("| `/api/mor/agreements` · `/:id/accept` · `/:id/sign` | `mor.convenios.solicitar/aceptar/firmar` |",
     "| `/api/mor/agreements` · `/:id/accept` · `/:id/sign` | `mor.convenios.solicitar` (POST `/api/mor/agreements`), `mor.convenios.aceptar` (`/:id/accept`), `mor.convenios.firmar` (`/:id/sign`) |"),
    ("| `/api/v1/ext/mor/collection-cases` | token de estudio |",
     "| `/api/v1/ext/mor/collection-cases` | `mor.ext.expedientes.ver` (scope del cliente API del estudio de cobranza; antes \"token de estudio\") |"),
    ("| `/api/v1/ext/mor/collection-cases/:id/events` | token de estudio |",
     "| `/api/v1/ext/mor/collection-cases/:id/events` | `mor.ext.expedientes.registrar` (scope del cliente API del estudio de cobranza; antes \"token de estudio\") |"),
    ("| `/api/v1/ext/mor/delinquency-status` | token de regulador/BI (T10) |",
     "| `/api/v1/ext/mor/delinquency-status` | `mor.ext.condicionMora.ver` (scope del cliente API de regulador o BI, T10; antes \"token de regulador/BI (T10)\") |"),
]))
print("M11", edit("M11", [
    ("| `/api/admin/ven/billing-items/lock` | interno M05 |",
     "| `/api/admin/ven/billing-items/lock` | `fac.facturacion.ejecutar` (cuenta técnica de M05; antes \"interno M05\") |"),
    ("| `/api/public/<tenantSlug>/quotes/:token` | token firmado |",
     "| `/api/public/<tenantSlug>/quotes/:token` | " + PUB + "; acceso por token firmado del enlace) |"),
    ("| `/api/public/<tenantSlug>/quotes/:token/otp` | token firmado |",
     "| `/api/public/<tenantSlug>/quotes/:token/otp` | " + PUB + "; acceso por token firmado del enlace) |"),
    ("| `/api/public/<tenantSlug>/quotes/:token/decision` | token + OTP |",
     "| `/api/public/<tenantSlug>/quotes/:token/decision` | " + PUB + "; acceso por token firmado del enlace más OTP) |"),
]))
