"""Categoría 5: tablas de transición donde el estado final no era alcanzable de forma explícita y valores de status deducibles."""
from ed import edit

H = "| Desde | Hacia | Disparador | Guarda | Evento |\n|---|---|---|---|---|\n"

print(edit("M08", [
    ("`proposed` → `approved` (doble control; evento `mor.writeOff.approved`) / `rejected`; `approved` → `partiallyRecovered` → `reverted` (recupero total).\n",
     "`proposed` → `approved` (doble control; evento `mor.writeOff.approved`) / `rejected`; `approved` → `partiallyRecovered` → `reverted` (recupero total).\n\n"
     "Transiciones explícitas (`writeOffs.status`; el texto anterior dejaba `rejected` sin origen claro):\n\n" + H +
     "| (nuevo) | `proposed` | Propuesta de incobrable | — | — |\n"
     "| `proposed` | `approved` | Aprobación del segundo usuario | Doble control: aprobador distinto del proponente | `mor.writeOff.approved` |\n"
     "| `proposed` | `rejected` | Rechazo del aprobador | Motivo obligatorio | — |\n"
     "| `approved` | `partiallyRecovered` | Imputación de un cobro posterior | Recupero menor al saldo dado de baja | — |\n"
     "| `approved` · `partiallyRecovered` | `reverted` | Recupero total | Recupero igual al saldo dado de baja | — |\n"),
    ("`draft` → `proposed` → `approved` → `executed` (documentos de signo contrario emitidos e imputados; evento `mor.prescription.executed`) / `rejected`.\n",
     "`draft` → `proposed` → `approved` → `executed` (documentos de signo contrario emitidos e imputados; evento `mor.prescription.executed`) / `rejected`.\n\n"
     "Transiciones explícitas (`prescriptionRuns.status`; el texto anterior dejaba `rejected` sin origen claro):\n\n" + H +
     "| (nuevo) | `draft` | Alta de la corrida con fecha de corte y reglas | — | — |\n"
     "| `draft` | `proposed` | Cálculo de ítems elegibles | Al menos un ítem elegible | — |\n"
     "| `proposed` | `approved` | Aprobación | Aprobador con capability de aprobación (`approval`) | — |\n"
     "| `proposed` | `rejected` | Rechazo del aprobador | Motivo obligatorio | — |\n"
     "| `approved` | `executed` | Emisión e imputación de documentos de signo contrario | Documentos emitidos en M05 e imputados en M07 | `mor.prescription.executed` |\n"),
]))

print(edit("M09", [
    ("`proposed` → `accepted` | `corrected` | `discarded` (decisión humana) ; `proposed` → `expired` (el caso avanzó sin decisión) ; creación directa `failed` (error del proveedor; no bloquea). No hay reversión: una nueva sugerencia es un registro nuevo.\n",
     "`proposed` → `accepted` | `corrected` | `discarded` (decisión humana) ; `proposed` → `expired` (el caso avanzó sin decisión) ; creación directa `failed` (error del proveedor; no bloquea). No hay reversión: una nueva sugerencia es un registro nuevo.\n\n"
     "Transiciones explícitas (el texto anterior no mostraba el origen de `failed`):\n\n" + H +
     "| (nuevo) | `proposed` | Respuesta válida del proveedor de IA | — | — |\n"
     "| (nuevo) | `failed` | Error o tiempo agotado del proveedor de IA | No bloquea el caso | — |\n"
     "| `proposed` | `accepted` · `corrected` · `discarded` | Decisión del operador | Usuario humano con acceso al caso | — |\n"
     "| `proposed` | `expired` | El caso avanzó sin decisión | Cambio de estado del caso posterior a la sugerencia | — |\n"),
    ("| `defaultStatus` | string | No | Estado inicial (`TICKETS_SUBTIPOS.COD_ESTADO`). |",
     "| `defaultStatus` | string | No | Estado inicial (`TICKETS_SUBTIPOS.COD_ESTADO`). Valor: un `code` de `crmStatusSets.states[]` (§7.8) del conjunto asignado al tipo, con `isInitial = true`; si falta, se usa el estado inicial del conjunto. |"),
]))

ACT = " (`active`, `inactive`; catálogo)"
print(edit("M07", [
    ("`printerProfile` (T06); `status`. Índice `{tenantId, code}` único.",
     "`printerProfile` (T06); `status` enum `active`, `inactive` (catálogo; una caja `inactive` no abre sesiones). Índice `{tenantId, code}` único."),
    ("`currentTransaction` `{ reference, amount, intentId, loadedAt }`, `status`. Origen: `CAJAS_QR`",
     "`currentTransaction` `{ reference, amount, intentId, loadedAt }`, `status` enum `active`, `inactive`. Origen: `CAJAS_QR`"),
    ("| `status` | enum | — | `IMPORTAR` |",
     "| `status` | enum `active`, `inactive` | — | `IMPORTAR` |"),
]))
print(edit("M08", [
    ("`unlockInterest` ({ rate, conceptId, voucherTypeId }; V2 #2770/#2771/#2984), `status`.",
     "`unlockInterest` ({ rate, conceptId, voucherTypeId }; V2 #2770/#2771/#2984), `status`" + ACT + "."),
    ("`requiresNote` (Boolean), `status`.", "`requiresNote` (Boolean), `status`" + ACT + "."),
    ("`validFrom`, `validTo`, `status`.\n\n### 7.25", "`validFrom`, `validTo`, `status`" + ACT + ".\n\n### 7.25"),
]))
