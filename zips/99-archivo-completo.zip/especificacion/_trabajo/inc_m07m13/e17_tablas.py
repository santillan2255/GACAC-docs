"""Categorías 2, 3 y 4: tablas de campos normalizadas para colecciones del §7 sin tabla, referencias con destino declarado
y nombres alineados con T05. Se agrega una sección al final del §7; las listas originales no se tocan."""
import sys, re, json
sys.path.insert(0, r"c:\Users\lenovo\Documents\GACAC\docs\entregables-analisis-diseno\_trabajo")
import generar_er_completo as g
from ed import load, save
import parse_campos as pc

DRY = "--dry" in sys.argv
OWNERS = ["M07", "M08", "M09", "M10", "M11", "M12", "M13"]
rows, by_id, by_name, model, vol, ttl, alt = g.build()


def esc(s):
    s = (s or "").replace("\n", " ").strip()
    s = re.sub(r"(?<!\\)\|", r"\\|", s)
    if s.count("`") % 2:
        s = s.replace("`", "")
    if len(s) > 170:
        s = s[:167].rstrip()
        if s.count("`") % 2:
            s = s[: s.rfind("`")].rstrip()
        s += "…"
    return s


def owner_of(col):
    r = by_name.get(col)
    if isinstance(r, list):
        r = r[0] if r else None
    return r["owner"] if r else None


def has_table(L, a):
    if not a or a[3] != "heading":
        return False
    j = a[1] + 1
    while j < len(L) and not L[j].startswith("#"):
        if re.match(r"^\| *(Campo|Nombre|Atributo)\b", L[j]):
            return True
        j += 1
    return False


def segmento(L, n, a, anchor_lines):
    k, ln, col = a[3], a[1], a[2]
    if k == "row":
        c = L[ln].split(" | ")
        return " | ".join(c[1:]).rstrip(" |") if len(c) > 1 else ""
    if k == "line":
        s = L[ln]
        p = s.find("`%s`" % n)
        s = s[p + len(n) + 2:]
        s = re.sub(r"^\s*\([^)]*\)", "", s)
        return s.lstrip(" :*").split(" — ", 1)[0] if s.lstrip().startswith("—") else s.lstrip(" :*")
    if k == "bold":
        s = L[ln][col:]
        p = s.find("**`%s`**" % n)
        s = s[p + len(n) + 6:] if p >= 0 else s
        q = s.find("**`")
        if q > 0:
            s = s[:q]
        s = re.sub(r"^\s*\([^)]*\)", "", s)
        return s.lstrip(" :")
    if k == "heading":
        out = []
        j = ln + 1
        while j < len(L) and not L[j].startswith("#") and (j == ln + 1 or j not in anchor_lines):
            s = L[j]
            m = re.search(r"Campos(?: comunes)?:\s*", s)
            if m:
                out.append(s[m.end():])
            elif s.startswith("`") and not out:
                out.append(s)
            j += 1
        return " ; ".join(out)
    return ""


IMPL = "; antes implícita por el nombre"
OVR = {
    ("M07", "sessionId"): "`cashSessions` (M07)" + IMPL,
    ("M07", "sessionIds"): "`cashSessions` (M07)" + IMPL,
    ("M07", "operationId"): "`cashOperations` (M07)" + IMPL,
    ("M07", "targetId"): "polimórfica según `kind` (`obligations`, `paymentCoupons`, `delinquencyNotices` [M08], `paymentIntents`, `agreementInstallments` [M08], `currentAccounts`)",
    ("M08", "collectionEntityId"): "`collectionAgencies` (M07); antes implícita por el nombre",
    ("M08", "importBatchId"): "[VERIFICAR] destino no deducible (lote de importación)",
    ("M09", "communicationRunIds"): "[VERIFICAR] corridas de comunicación de T09 (colección no identificada en T05)",
    ("M09", "providerMessageId"): "— (identificador del proveedor del canal; no es referencia interna)",
    ("M09", "targetId"): "[VERIFICAR] polimórfica según el tipo de destino",
    ("M10", "connectorId"): "[VERIFICAR] conector de T06 (colección no identificada en T05)",
    ("M10", "evidenceIds"): "`fieldEvidence` (M10); antes implícita por el nombre",
    ("M12", "recipientId"): "[VERIFICAR] destino no deducible",
    ("M12", "targetId"): "[VERIFICAR] polimórfica según el tipo de destino",
    ("M13", "eventId"): "`accountingEvents` (M15); antes implícita por el nombre",
}

stats = {}
for o in OWNERS:
    t, bom, crlf = load(o)
    L = t.split("\n")
    mo = model[o]
    i7 = next(i for i, l in enumerate(L) if l.startswith("## 7."))
    i8 = next(i for i in range(i7 + 1, len(L)) if L[i].startswith("## "))
    subs = [int(m.group(1)) for l in L[i7:i8] for m in [re.match(r"### 7\.(\d+)\b", l)] if m]
    secno = "7.%d" % (max(subs) + 1)
    assert not any(l.startswith("### " + secno + " ") for l in L)
    anchor_lines = {e["anchor"][1] for e in mo["ents"].values() if e["anchor"] and e["anchor"][3] != "heading"}
    out = ["### %s Tablas de campos normalizadas y referencias declaradas" % secno, "",
           "Corrección de consistencia (categorías 2, 3 y 4 de `_trabajo/correccion-inconsistencias-instrucciones.md`). "
           "Para cada colección cuyo §7 lista los campos en texto se da la tabla normalizada; para las que ya tienen tabla, solo las referencias cuyo destino estaba implícito o faltaba. "
           "Fuentes: la lista del anexo y el catálogo de T05. La lista original sigue vigente como descripción; para nombres de campo y referencias prevalece esta tabla, alineada con T05. "
           "`[VERIFICAR]` marca tipo, obligatoriedad o destino no deducibles del anexo ni de T05. Referencia: colección destino (anexo dueño).", ""]
    k = 0
    st = dict(tablas=0, campos=0, refs_inf=0, refs_sin=0, alias=0, t05=0, refsolo=0, vacias=[])
    for n, e in sorted(mo["ents"].items(), key=lambda x: (x[1]["anchor"][1] if x[1]["anchor"] else 10 ** 9)):
        a = e["anchor"]
        F = e["fields"]
        if not a:
            continue
        tab = has_table(L, a)
        if not tab and a[3] == "bold":
            tab = any(re.match(r"^\| *Campo\b", L[j]) for j in range(a[1] + 1, min(a[1] + 4, len(L))))
        if tab:
            parsed = []
        else:
            seg = segmento(L, n, a, anchor_lines)
            seg2 = seg.lstrip(" ;:")
            if not seg2.strip():
                j = a[1] + 1
                while j < len(L) and not L[j].strip():
                    j += 1
                seg2 = L[j] if j < len(L) and L[j].startswith("`{") else ""
            parsed = pc.parse_brace(seg2) if seg2.startswith("`{") else pc.parse(seg)
        names = [f["name"] for f in parsed]
        t05only = [fn for fn, f in F.items() if f["src"] == "T05" and fn not in names]
        alias = {}
        for fn in t05only:
            fk = F[fn].get("fk")
            if not fk:
                continue
            def compatible(x):
                if x.endswith("Ids") != fn.endswith("Ids"):
                    return False
                if x.endswith("Ref") and fn.endswith("Id") and x[:-3] == fn[:-2]:
                    return True
                return fn.lower().endswith(x.lower()) and fn != x
            c = [x for x in names if F.get(x, {}).get("fk") == fk and x not in alias and F.get(x, {}).get("src") != "T05" and compatible(x)]
            if len(c) == 1:
                alias[c[0]] = fn
        rowsout = []

        def por_nombre(fn):
            m = re.match(r"^(\w+?)(Id|Ids)$", fn)
            if not m:
                return None
            b = m.group(1)
            for c in (b + "s", b + "es", b[:-1] + "ies" if b.endswith("y") else None, b):
                if c and owner_of(c):
                    return c
            w = re.findall(r"[A-Z]?[a-z0-9]+", b)
            if not w:
                return None
            last = w[-1][0].upper() + w[-1][1:]
            sufs = [last + "s", last + "es", (last[:-1] + "ies") if last.endswith("y") else None]
            c = [x for x in by_name if any(s and x.endswith(s) for s in sufs)]
            co = [x for x in c if owner_of(x) == o]
            if len(co) == 1:
                return co[0]
            return None

        def ref_of(fn, base):
            if (o, fn) in OVR:
                v = OVR[(o, fn)]
                if v.startswith("[VERIFICAR]"):
                    st["refs_sin"] += 1
                else:
                    st["refs_inf"] += 1
                return v, True
            f = F.get(fn) or F.get(base) or {}
            if fn.startswith("external") or fn.startswith("legacy"):
                return "— (identificador del sistema externo; no es referencia interna)", False
            if "fk" not in f or not f.get("fk"):
                if re.search(r"Ids?$", fn) and fn not in ("tenantId",):
                    c = por_nombre(fn)
                    if c:
                        st["refs_inf"] += 1
                        return "`%s` (%s); antes implícita por el nombre" % (c, owner_of(c)), True
                    st["refs_sin"] += 1
                    return "[VERIFICAR] destino no deducible (identificador externo o interno)", True
                if "fk" not in f:
                    return "—", False
            if f["fk"]:
                how = f.get("fkhow") or ""
                r = "`%s` (%s)" % (f["fk"], owner_of(f["fk"]) or "[VERIFICAR] dueño")
                if how.startswith("nombre"):
                    st["refs_inf"] += 1
                    return r + "; antes implícita por el nombre", True
                if how == "polimórfica":
                    st["refs_inf"] += 1
                    return r + "; polimórfica según el tipo", True
                return r, False
            st["refs_sin"] += 1
            return "[VERIFICAR] destino no deducible (identificador externo o interno)", True

        if tab:
            for fn, f in F.items():
                if f["src"] != "anexo":
                    continue
                r, flag = ref_of(fn, fn)
                if flag:
                    rowsout.append((fn, r))
            if not rowsout:
                continue
            k += 1
            st["refsolo"] += 1
            out += ["#### %s.%d `%s` (%s) — referencias declaradas" % (secno, k, n, e["row"]["id"]), "",
                    "| Campo | Referencia |", "|---|---|"]
            out += ["| `%s` | %s |" % r for r in rowsout]
            out.append("")
            continue
        if not parsed and not t05only:
            st["vacias"].append(n)
            continue
        for f in parsed:
            fn = f["name"]
            shown = alias.get(fn, fn)
            r, _ = ref_of(shown, fn)
            d = esc(pc.desc_de(f))
            if fn in alias:
                d = ("Nombre de T05; antes `%s` en este anexo. " % fn) + d
                st["alias"] += 1
            rowsout.append((shown, pc.tipo_de(f), pc.oblig_de(f), d.strip() or "—", r))
        for fn in t05only:
            if fn in alias.values():
                continue
            f = F[fn]
            r, _ = ref_of(fn, fn)
            st["t05"] += 1
            tp = f.get("type") if f.get("type") not in (None, "", "any") else pc.tipo_de(dict(name=fn, opt=False, arr=False, rest="", vals=[]))
            rowsout.append((fn, tp, "[VERIFICAR]", "Declarado en T05; no figuraba en la lista del anexo.", r))
        k += 1
        st["tablas"] += 1
        st["campos"] += len(rowsout)
        sec = e["section"][1] if e["section"] else None
        out += ["#### %s.%d `%s` (%s)" % (secno, k, n, e["row"]["id"]), "",
                ("Lista original: §%s." % sec.split(" ")[0]) if sec else "Lista original: texto del §7.", "",
                "| Campo | Tipo | Oblig. | Descripción | Referencia |", "|---|---|---|---|---|"]
        out += ["| `%s` | %s | %s | %s | %s |" % r for r in rowsout]
        out.append("")
    stats[o] = st
    if DRY:
        open("prev_%s.md" % o, "w", encoding="utf-8").write("\n".join(out))
    else:
        L[i8:i8] = out
        save(o, "\n".join(L), bom, crlf)
print(json.dumps(stats, ensure_ascii=False))
