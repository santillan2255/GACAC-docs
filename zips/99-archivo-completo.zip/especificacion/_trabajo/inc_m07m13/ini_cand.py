import re, json
from ed import load
out = {}
for o in ["M07", "M08", "M09", "M10", "M11", "M12", "M13"]:
    t, _, _ = load(o)
    L = t.split("\n")
    i0 = next(i for i, l in enumerate(L) if l.startswith("## 8."))
    i1 = next(i for i in range(i0 + 1, len(L)) if L[i].startswith("## "))
    secs = [i for i in range(i0, i1) if L[i].startswith("### ")] + [i1]
    for a, b in zip(secs, secs[1:]):
        body = [l for l in L[a + 1:b] if l.strip()]
        if "inicial" in " ".join(body).lower():
            continue
        first = body[0] if body else ""
        cand = None
        if first.startswith("|"):
            row = body[2] if len(body) > 2 else ""
            c = [x.strip() for x in row.strip("|").split("|")]
            m = re.findall(r"`([A-Za-z]+)`", c[0])
            cand = (m[0] if m else c[0]) + "  <<" + " | ".join(c[:2])[:80]
        else:
            m = re.match(r"\W*`([A-Za-z]+)", first)
            cand = (m.group(1) if m else "?") + "  <<" + first[:80]
        print(o, a + 1, L[a][:55], "=>", cand)
