import re
from ed import load, save, edit

t, bom, crlf = load("M08")
L = t.split("\n")
n = 0
for i, l in enumerate(L):
    m = re.match(r"^\| (ESC-MOR-(59|60|61|62|63)) \| (.*?) \| (.*?) \| (.*) \|$", l)
    if m:
        L[i] = "| %s | %s. Dado: %s | %s |" % (m.group(1), m.group(3), m.group(4), m.group(5))
        n += 1
assert n == 5, n
save("M08", "\n".join(L), bom, crlf)
print("M08", n)
print(edit("M12", [("tolerancia de cantidad); |precio factura − precio OC| ≤", "tolerancia de cantidad); \\|precio factura − precio OC\\| ≤")]))
