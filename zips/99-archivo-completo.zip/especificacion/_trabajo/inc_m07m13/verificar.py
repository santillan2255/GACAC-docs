import re, collections, sys
from ed import path

EXP = {"M07": (True, True), "M08": (False, True)}
for o in ["M07", "M08", "M09", "M10", "M11", "M12", "M13"]:
    p = path(o)
    raw = open(p, "rb").read()
    bom = raw.startswith(b"\xef\xbb\xbf")
    crlf = b"\r\n" in raw
    lf_only = raw.count(b"\n") - raw.count(b"\r\n")
    t = raw.decode("utf-8-sig").replace("\r\n", "\n")
    L = t.split("\n")
    exp = EXP.get(o, (False, False))
    eol_ok = (crlf and lf_only == 0) if exp[1] else (not crlf)
    heads = collections.Counter(l.strip() for l in L if l.startswith("#"))
    dup_h = [h for h, c in heads.items() if c > 1]
    ids = collections.Counter()
    hdr_id = False
    for i, l in enumerate(L):
        if l.startswith("| ID |") or l.startswith("| API-ID |"):
            hdr_id = True
            continue
        if not l.startswith("|"):
            hdr_id = False
            continue
        if hdr_id:
            m = re.match(r"^\| ([A-Z]+-[A-Z]+-\d+[a-z]?) \|", l)
            if m:
                ids[m.group(1)] += 1
    dup_id = [k for k, c in ids.items() if c > 1]
    moj = [i + 1 for i, l in enumerate(L) if re.search("Ã[\x80-\xbf¡-ÿ]|Â[\xa0-\xbf]|â€|\ufffd", l)]
    sigue = [i + 1 for i, l in enumerate(L) if "<!-- SIGUE" in l]
    bad = []
    i = 0
    while i < len(L):
        if L[i].startswith("|") and i + 1 < len(L) and re.match(r"^\|[\s:|-]+\|\s*$", L[i + 1]):
            n = len(re.findall(r"(?<!\\)\|", L[i]))
            j = i + 2
            while j < len(L) and L[j].startswith("|"):
                k = len(re.findall(r"(?<!\\)\|", L[j]))
                if k != n:
                    bad.append(j + 1)
                j += 1
            i = j
        else:
            i += 1
    print(o, "BOM", bom, "CRLF", crlf, "EOL_ok", eol_ok, "| dup_head", len(dup_h), dup_h[:4], "| dup_id", dup_id[:8],
          "| mojibake", moj[:5], "| SIGUE", sigue, "| filas_col_mal", len(bad), bad[:12])
