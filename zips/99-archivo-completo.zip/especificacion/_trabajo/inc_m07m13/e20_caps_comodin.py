"""Categoría 1: capabilities con comodín o compactadas en filas de pantalla y API pasan a capabilities explícitas modulo.recurso.accion."""
from ed import load, save

M = {
    "M08": {
        "PAN-MOR-02": ("`mor.politicasInteres.ver/configurar`", "`mor.politicasInteres.ver`, `mor.politicasInteres.configurar`"),
        "PAN-MOR-03": ("`mor.tasas.*`", "`mor.tasas.ver`, `mor.tasas.editar`"),
        "PAN-MOR-04": ("`mor.indices.*`", "`mor.indices.ver`, `mor.indices.importar`"),
        "PAN-MOR-08": ("`mor.interesesFacturar.*`", "`mor.interesesFacturar.ver`, `mor.interesesFacturar.simular`, `mor.interesesFacturar.ejecutar`, `mor.interesesFacturar.aprobar`, `mor.interesesFacturar.cancelar`"),
        "PAN-MOR-09": ("`mor.bloqueos.*`", "`mor.bloqueos.ver` (nueva), `mor.bloqueos.crear`, `mor.bloqueos.masivos`, `mor.bloqueos.liberar`"),
        "PAN-MOR-10": ("`mor.politicasMora.*`", "`mor.politicasMora.ver`, `mor.politicasMora.configurar`"),
        "PAN-MOR-19": ("`mor.tratamiento.*`", "`mor.tratamiento.ver`, `mor.tratamiento.ejecutar`"),
        "PAN-MOR-23": ("`mor.excepciones.*`", "`mor.excepciones.ver`, `mor.excepciones.editar` (nueva), `mor.excepciones.aprobar`"),
        "PAN-MOR-24": ("`mor.protecciones.*`", "`mor.protecciones.ver` (nueva), `mor.protecciones.editar` (nueva), `mor.protecciones.aprobar`"),
        "PAN-MOR-25": ("`mor.restricciones.*`", "`mor.restricciones.ver`, `mor.restricciones.configurar` (nueva), `mor.restricciones.configurarNormativas`"),
        "PAN-MOR-33": ("`mor.garantias.*`", "`mor.garantias.ver`, `mor.garantias.editar`"),
        "PAN-MOR-34": ("`mor.gestionExterna.*`", "`mor.gestionExterna.ver`, `mor.gestionExterna.editar`, `mor.gestionExterna.registrarAvance`"),
        "PAN-MOR-35": ("`mor.incobrables.*`", "`mor.incobrables.ver` (nueva), `mor.incobrables.proponer`, `mor.incobrables.aprobar`"),
        "PAN-MOR-36": ("`mor.prescripcion.*`", "`mor.prescripcion.configurar`, `mor.prescripcion.proponer`, `mor.prescripcion.aprobar`"),
        "PAN-MOR-37": ("`mor.*.ver` + `exportar`", "`mor.informes.ver` (nueva), `mor.informes.exportar` (nueva)"),
        "API-MOR-26": ("`mor.politicasMora.*`", "`mor.politicasMora.ver` (GET), `mor.politicasMora.configurar` (POST, PATCH)"),
        "API-MOR-46": ("`mor.excepciones.*`", "`mor.excepciones.ver` (GET), `mor.excepciones.editar` (POST, PATCH; nueva)"),
        "API-MOR-48": ("`mor.protecciones.*`", "`mor.protecciones.ver` (GET; nueva), `mor.protecciones.editar` (POST, PATCH; nueva)"),
        "API-MOR-50": ("`mor.restricciones.*`", "`mor.restricciones.ver` (GET), `mor.restricciones.configurar` (POST, PATCH; nueva); filas `normative`: `mor.restricciones.configurarNormativas`"),
        "API-MOR-74": ("`mor.garantias.*`", "`mor.garantias.ver` (GET), `mor.garantias.editar` (POST, PATCH)"),
        "API-MOR-77": ("`mor.gestionExterna.*`", "`mor.gestionExterna.ver` (GET), `mor.gestionExterna.editar` (POST, PATCH)"),
        "API-MOR-83": ("`mor.*.ver`", "`mor.informes.ver` (nueva)"),
        "API-MOR-84": ("`mor.*.exportar`", "`mor.informes.exportar` (nueva)"),
    },
    "M09": {
        "PAN-CRM-25": ("token de pantalla", "`crm.turnero.pantalla.ver` (cuenta técnica S-KSK con token de pantalla)"),
        "PAN-CRM-26": ("token de dispositivo", "`crm.turnero.emitir` (cuenta técnica S-KSK con token de dispositivo)"),
        "API-CRM-28": ("`crm.incidentes.*`", "`crm.incidentes.ver` (GET), `crm.incidentes.crear` (POST), `crm.incidentes.editar` (PATCH)"),
        "API-CRM-32": ("`crm.mesaEntradas.*`", "`crm.mesaEntradas.ver` (GET), `crm.mesaEntradas.crear` (alta), `crm.mesaEntradas.pasar` (`/transfers`, `/acknowledge`), `crm.mesaEntradas.registrarSalida` (`/outgoing`)"),
        "API-CRM-39": ("`crm.config.*` correspondiente",
                       "`crm.config.tipos.configurar` (case-types, case-subtypes), `crm.config.estados.configurar` (status-sets), `crm.config.areas.configurar` (areas), `crm.config.sla.configurar` (sla-policies), `crm.config.reglas.configurar` (routing-rules, quick-replies), `crm.config.canales.configurar` (channels, bot-flows, ai-settings; nueva), `crm.config.tramites.configurar` (procedure-types, incident-classes; nueva)"),
        "API-CRM-43": ("`crm.horas.*`", "`crm.horas.ver` (GET), `crm.horas.registrar` (POST, PATCH)"),
    },
    "M10": {
        "API-TEC-38": ("`tec.phone.*`", "`tec.telefonia.redFisica.ver` / `tec.telefonia.redFisica.editar` (exchanges, ports, frames, frame-groups, strips, positions, boxes, dslams), `tec.telefonia.numeracion.ver` / `tec.telefonia.numeracion.editar` (prefixes, numbers), `tec.telefonia.lineas.ver` / `tec.telefonia.lineas.editar` (lines), `tec.telefonia.configurar` (operators, service-types, modalities)"),
    },
    "M11": {
        "API-VEN-092": ("API key con scope `ven.read`", "`ven.presupuestos.ver`, `ven.ventas.ver` (scopes de la API key, cuenta técnica S-API)"),
    },
    "M12": {
        "API-CMP-035": ("`cmp.concursos.*`", "`cmp.concursos.ver` (GET; nueva), `cmp.concursos.editar` (POST, PATCH; nueva), `cmp.concursos.adjudicar` (adjudicación)"),
        "API-CMP-100": ("`cmp.*.exportar`", "`cmp.reportes.exportar` (nueva)"),
        "API-CMP-110": ("`cmp.portal.*` (rol `supplier`)", "`cmp.portal.verOrdenes` (orders), `cmp.portal.cotizar` (quotes), `cmp.portal.subirComprobante` (invoices), `cmp.portal.verPagos` (payments, certificates); rol `supplier`"),
        "API-CMP-120": ("API key con scope `cmp.read`", "`cmp.ordenes.ver`, `cmp.comprobantes.ver` (scopes de la API key, cuenta técnica S-API)"),
    },
    "M13": {
        "API-STK-10": ("`stk.depositos.*`", "`stk.depositos.ver` (GET), `stk.depositos.editar` (POST, PATCH)"),
        "API-STK-28": ("`stk.lotes.*`", "`stk.lotes.ver` (GET), `stk.lotes.editar` (POST; nueva)"),
        "API-STK-39": ("`stk.rendiciones.*`", "`stk.rendiciones.ver` (GET), `stk.rendiciones.editar` (crear, contar, ajustar; nueva), `stk.rendiciones.aprobar` (cerrar)"),
        "API-STK-46": ("`stk.inventarios.*`", "`stk.inventarios.ver` (GET), `stk.inventarios.contar` (POST, `/snapshot`, `/lines`), `stk.inventarios.cerrar` (`/close`; nueva)"),
        "API-STK-51": ("`stk.revaluaciones.*`", "`stk.revaluaciones.ver` (GET; nueva), `stk.revaluaciones.crear` (POST), `stk.revaluaciones.aprobar` (`/approve`, `/post`; nueva)"),
        "API-STK-53": ("`stk.bienesUso.*`", "`stk.bienesUso.ver` (GET), `stk.bienesUso.editar` (POST, PATCH)"),
        "API-STK-61": ("`stk.rma.*`", "`stk.rma.ver` (GET), `stk.rma.crear` (POST), `stk.rma.editar` (PATCH, `/status`, `/ship`, `/return`), `stk.rma.cerrar` (cierre)"),
        "API-STK-62": ("`stk.recepciones.*`", "`stk.recepciones.ver` (GET), `stk.recepciones.crear` (POST), `stk.recepciones.editar` (PATCH, `/status`), `stk.recepciones.entregar` (`/deliver`)"),
        "API-STK-63": ("`stk.fabricacion.estructuras.*`", "`stk.fabricacion.estructuras.ver` (GET), `stk.fabricacion.estructuras.editar` (POST, PUT, `/versions`, `/clone`, `/cost`; nueva)"),
        "API-STK-64": ("`stk.fabricacion.estructuras.*`", "`stk.fabricacion.estructuras.ver` (GET), `stk.fabricacion.estructuras.editar` (POST; nueva)"),
        "API-STK-65": ("`stk.fabricacion.ordenes.*`", "`stk.fabricacion.ordenes.ver` (GET), `stk.fabricacion.ordenes.editar` (POST, PATCH, `/launch`, `/finish`, `/cancel`, `/void`, `/extend`; nueva)"),
        "API-STK-66": ("`stk.fabricacion.partes.*`", "`stk.fabricacion.partes.ver` (GET), `stk.fabricacion.partes.crear` (POST, `/damage`, `/void`, `/labels`), `stk.fabricacion.partes.lanzar` (`/launch`), `stk.fabricacion.partes.finalizar` (`/finish`)"),
    },
}

for o, mp in M.items():
    t, bom, crlf = load(o)
    L = t.split("\n")
    n = 0
    for i, l in enumerate(L):
        for k, (old, new) in mp.items():
            if l.startswith("| " + k + " |"):
                cell = " " + old + " |"
                assert l.count(cell) == 1, (o, k, l[:200])
                L[i] = l.replace(cell, " %s (antes %s) |" % (new, old), 1)
                n += 1
    assert n == len(mp), (o, n, len(mp))
    save(o, "\n".join(L), bom, crlf)
    print(o, n)
