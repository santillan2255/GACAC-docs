"""Categoría 7: consumos declarados que T11 §12.3 no lista (06a tabla 7.2): se dejan explícitos en el §12.2."""
from ed import edit

print(edit("M07", [
    ("Los jobs se detallan en 9.20 (JOB-COB-01..22).",
     "**Consumos pendientes de registro en T11 (INC-06-06):** M07 consume `int.circuit.opened` / `.closed` (EVT-INT-04) de T06 para la salud del conector y la excepción `connectorDown`; T11 §12.3 no lista a M07 como consumidor de EVT-INT-04 y debe agregarlo.\n\nLos jobs se detallan en 9.20 (JOB-COB-01..22)."),
]))
print(edit("M08", [
    ("| `per.person.deceased` | M01 | Señala reconexiones a titular fallecido (RN-MOR-097). |\n",
     "| `per.person.deceased` | M01 | Señala reconexiones a titular fallecido (RN-MOR-097). |\n\n"
     "**Consumos pendientes de registro en T11 (INC-06-06):** T11 §12.3 no lista a M08 como consumidor de los siguientes eventos, que M08 consume según la tabla anterior; T11 debe agregarlo: EVT-COM-29 `com.communication.allChannelsFailed` (T09; tarea \"canal alternativo\"), EVT-CRM-05 `crm.case.statusChanged` (M09; libera la protección temporal) y EVT-TEC-14 `tec.visit.failed` (M10; transición del caso de interrupción).\n"),
]))
