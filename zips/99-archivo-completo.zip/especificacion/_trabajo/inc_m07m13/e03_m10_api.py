"""M10 §11: normaliza la tabla API al formato de la guía (API-ID | Método | Ruta | Capability | Descripción | Idempotente),
separa capabilities compuestas, reemplaza reglas de acceso por capabilities y mueve API-TEC-56 a servicios internos."""
import re
from ed import load, save

CAPS = {
    "API-TEC-01": "`tec.feasibility.read` (GET), `tec.feasibility.create` (POST)",
    "API-TEC-02": "`tec.feasibility.read` (GET), `tec.feasibility.update` (PATCH)",
    "API-TEC-04": "`tec.feasibility.cancel` (`/cancel`), `tec.feasibility.reopen` (`/reopen`)",
    "API-TEC-07": "`tec.workOrder.read` (GET), `tec.workOrder.create` (POST)",
    "API-TEC-08": "`tec.workOrder.read` (GET), `tec.workOrder.update` (PATCH)",
    "API-TEC-12": "`tec.workOrder.cancel` (`cancel`), `tec.workOrder.reopen` (`reopen`, `restore`)",
    "API-TEC-14": "`tec.material.request` (GET/POST, `cancel`, `return`), `tec.material.authorize` (`authorize`)",
    "API-TEC-15": "`tec.workOrder.bulkCreate` (`bulk-create`), `tec.workOrder.bulkClose` (`bulk-close`); el estado del job lo ve quien lo lanzó",
    "API-TEC-23": "`tec.installation.read` (GET), `tec.installation.review` (POST)",
    "API-TEC-29": "`tec.network.manage` (escritura), `tec.network.read` (GET `tree`, `geo`)",
    "API-TEC-35": "`tec.serviceTechnical.read` (GET), `tec.serviceTechnical.update` (PATCH)",
    "API-TEC-37": "`tec.inspection.manage` (CRUD y acciones), `tec.inspection.approve` (`approve`, `annul`)",
    "API-TEC-40": "`por.visitas.reservar` (sesión de socio titular o autorizado; antes \"sesión de socio (titular/autorizado)\")",
    "API-TEC-41": "`por.visitas.ver` (GET), `por.visitas.reprogramar` (`reschedule`), `por.visitas.cancelar` (`cancel`) (sesión de socio; antes \"sesión de socio\")",
    "API-TEC-42": "`tec.campo.ver` (perfil técnico de la app de campo; antes \"perfil técnico\")",
    "API-TEC-43": "`tec.campo.ejecutar` (perfil de campo; antes \"perfil de campo\")",
    "API-TEC-44": "`tec.campo.evidencia` (perfil de campo; antes \"perfil de campo\")",
    "API-TEC-45": "`stk.custodia.ver` (perfil técnico; antes \"perfil técnico\")",
    "API-TEC-46": "`tec.campo.ver` (`register`, perfil de campo), `tec.device.manage` (`revoke`)",
    "API-TEC-49": "`tec.ext.ordenes.crear` (scope del cliente API de T02 por token de servicio; antes \"token de servicio con scope `tec.ext.workOrder`\")",
    "API-TEC-50": "`tec.ext.aprovisionamiento.callback` (cuenta técnica del sistema de red; la llamada se autentica con firma HMAC del sistema)",
    "API-TEC-51": "`tec.onCall.manage` (turnos y `current`), `tec.campo.ejecutar` (`accept`, `arrive`, `safe`; antes \"perfil de campo\")",
}

METHODS = r"(GET/POST/PATCH|GET/PATCH|GET/POST|GET|POST|PATCH|PUT|DELETE|CRUD)"


def split_route(cell):
    segs = [s.strip() for s in cell.split(" · ")]
    meths, routes = [], []
    last = None
    for s in segs:
        m = re.match(r"^`" + METHODS + r" (.+)`$", s)
        if m:
            last = m.group(1)
            meths.append(last)
            routes.append("`" + m.group(2) + "`")
        else:
            m2 = re.match(r"^`([^`]+)`$", s)
            if not m2:
                raise SystemExit("segmento no reconocido: %r" % s)
            meths.append(last)
            routes.append(s)
    out = []
    for m in meths:
        if not out or out[-1] != m:
            out.append(m)
    return " · ".join(out), " · ".join(routes), set("/".join(meths).replace("CRUD", "GET/POST/PATCH/DELETE").split("/"))


def idem(ms):
    if ms <= {"GET"}:
        return "Sí (lectura)"
    parts = []
    if "POST" in ms:
        parts.append("POST con `Idempotency-Key`")
    if "PATCH" in ms or "PUT" in ms:
        parts.append("PATCH con `If-Match`/`version`")
    if "DELETE" in ms:
        parts.append("DELETE por `version`")
    return "Sí (" + "; ".join(parts) + ")"


t, bom, crlf = load("M10")
L = t.split("\n")
hdr = "| ID | Método y ruta | Propósito | Capability | Notas |"
i = L.index(hdr)
assert L[i + 1].startswith("|---")
L[i] = "| API-ID | Método | Ruta | Capability | Descripción | Idempotente |"
L[i + 1] = "|---|---|---|---|---|---|"
j = i + 2
moved = None
while L[j].startswith("| API-TEC-"):
    c = [x.strip() for x in L[j].strip().strip("|").split(" | ")]
    assert len(c) == 5, (len(c), L[j][:80])
    aid, mr, prop, cap, notes = c
    if aid == "API-TEC-56":
        moved = c
        L[j] = ("| API-TEC-56 | — | — | — | **Reemplazado por servicio interno `tec.getQuotaUsage`** (ver §11.1): no es una ruta HTTP. "
                "Descripción original: \"%s\". | — |" % prop)
        j += 1
        continue
    meth, route, ms = split_route(mr)
    desc = prop.rstrip(".") + "."
    if notes not in ("—", "-", ""):
        desc += " " + notes
    cap2 = CAPS.get(aid, cap)
    L[j] = "| %s | %s | %s | %s | %s | %s |" % (aid, meth, route, cap2, desc, idem(ms))
    j += 1

# servicios internos: después del párrafo de errores de dominio
k = next(x for x in range(j, len(L)) if L[x].startswith("Errores de dominio (campo `code`)"))
aid, mr, prop, cap, notes = moved
bloque = [
    "",
    "### 11.1 Servicios internos (no HTTP)",
    "",
    "Llamadas en proceso entre módulos del monolito modular (DEC-003); no se publican como rutas. Cada servicio declara módulo invocante, entrada, salida y errores.",
    "",
    "| Servicio | Invocante | Entrada | Salida | Errores | Origen |",
    "|---|---|---|---|---|---|",
    "| `tec.getQuotaUsage` | M04 (cuenta técnica de servicio; antes \"Token interno de servicio (M04)\") | `{ contractId, period }` | `{ unit, quantity, revision, reportedAt }` de la última revisión atribuida, o `null` si no hay consumo informado (M04 aplica RN-TAR-251 punto 5). Solo lectura. | No declarados en el anexo [VERIFICAR] | Antes fila API-TEC-56. %s |" % prop,
]
L[k + 1:k + 1] = bloque
save("M10", "\n".join(L), bom, crlf)
print("ok", j - i - 2)
