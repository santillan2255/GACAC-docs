import re
from ed import load
CAP = re.compile(r"`[a-z]+\.[A-Za-z]+(\.[A-Za-z]+)+`|public: true|sin capability|Reemplazado|—")
for o in ["M07", "M08", "M09", "M10", "M11", "M12", "M13"]:
    L = load(o)[0].split("\n")
    hdr = None
    for i, l in enumerate(L):
        if l.startswith("|") and re.search(r"\| *Capabilit(y|ies) *\|", l) and i + 1 < len(L) and L[i + 1].startswith("|--") or (l.startswith("|") and i + 1 < len(L) and L[i + 1].startswith("|---") and "Capabilit" in l):
            cols = [c.strip() for c in l.strip().strip("|").split("|")]
            hdr = [k for k, c in enumerate(cols) if c.startswith("Capabilit")]
            continue
        if hdr is not None:
            if not l.startswith("|"):
                hdr = None
                continue
            if l.startswith("|---"):
                continue
            cells = [c.strip() for c in re.split(r"(?<!\\)\|", l.strip().strip("|"))]
            for k in hdr:
                if k < len(cells) and not CAP.search(cells[k]):
                    print(o, i + 1, cells[0][:14], "|", cells[k][:120])
