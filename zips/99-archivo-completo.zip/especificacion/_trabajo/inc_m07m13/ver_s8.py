import re
from ed import load
for o in ["M07", "M08", "M09", "M10", "M11", "M12", "M13"]:
    t, _, _ = load(o)
    L = t.split("\n")
    i0 = next(i for i, l in enumerate(L) if l.startswith("## 8."))
    i1 = next(i for i in range(i0 + 1, len(L)) if L[i].startswith("## "))
    secs = [i for i in range(i0, i1) if L[i].startswith("### ")]
    secs.append(i1)
    for a, b in zip(secs, secs[1:]):
        body = [l for l in L[a + 1:b] if l.strip()]
        txt = " ".join(body)
        ini = "inicial" in txt.lower()
        first = body[0][:110] if body else ""
        print(o, a + 1, L[a][:60], "| INI" if ini else "| --", "|", first)
