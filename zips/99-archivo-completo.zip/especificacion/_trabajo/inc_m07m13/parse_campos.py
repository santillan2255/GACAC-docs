"""Parser de listas de campos en texto ("Campos: `a` (…), `b` enum `x`, `y`; …") de los §7."""
import re

STOP = re.compile(r"(?:^|\s)(Índices?|Indice|Origen|Mapeo|Validaci[oó]n|Regla|Reglas|Precarga|Unicidad|Único)\b\s*[:`{]")
TYPEW = [
    (r"\bObjectId\s*\[\]|\[ObjectId\]", "ObjectId[]"), (r"\bObjectId\b", "ObjectId"),
    (r"\bDecimal128\b|\bmoney\b", "Decimal128"), (r"\bBoolean\b|\bbool\b", "bool"),
    (r"\bInt\b|\binteger\b|\bnúmero entero\b", "int"), (r"\bDate\b|\bfecha\b", "Date"),
    (r"\bString\b|\bstring\b", "string"), (r"^\(?Enum\b", "enum"), (r"^\(?Object\b", "object"), (r"\bUUID\b", "UUID"), (r"\bGeoJSON\b", "GeoJSON"),
]


def split_top(s):
    """Divide en ',' y ';' de nivel superior; devuelve [(sep_previo, item)]."""
    out, buf, depth, tick, prev = [], [], 0, False, ""
    i = 0
    while i < len(s):
        c = s[i]
        if c == "`":
            tick = not tick
        elif not tick:
            if c in "([{":
                depth += 1
            elif c in ")]}":
                depth = max(0, depth - 1)
            elif c in ",;" and depth == 0:
                out.append((prev, "".join(buf).strip()))
                buf, prev = [], c
                i += 1
                continue
        buf.append(c)
        i += 1
    if "".join(buf).strip():
        out.append((prev, "".join(buf).strip()))
    return out


BARE = re.compile(r"^`[A-Za-z][\w]*`(\s*\([^)]*\))?\.?$")
HEAD = re.compile(r"^(?:y\s+|más\s+)?`([A-Za-z][\w.]*)(\??)(\[\])?`\s*(.*)$", re.S)


def parse(text):
    text = text.replace("\\|", "|")
    m = STOP.search(text)
    if m:
        text = text[:m.start()]
    items = split_top(text)
    fields = []
    i = 0
    while i < len(items):
        sep, it = items[i]
        h = HEAD.match(it.strip(" .:"))
        if not h:
            i += 1
            continue
        name, opt, arr, rest = h.group(1), h.group(2), h.group(3), h.group(4).strip()
        if "." in name:
            i += 1
            continue
        vals = []
        if re.match(r"^enum\b", rest):
            vals = re.findall(r"`([^`]+)`", rest)
            pipes = "|" in rest
            if not pipes:
                semi = ";" in "".join(x[0] for x in items[i + 1:])
                j = i + 1
                while j < len(items) and items[j][0] == "," and BARE.match(items[j][1].strip()):
                    tok = re.findall(r"`([^`]+)`", items[j][1])[0]
                    if not semi and re.search(r"(Id|Ids|At|Date|Key|Ref|Name|Code)$", tok):
                        break
                    vals += re.findall(r"`([^`]+)`", items[j][1])
                    j += 1
                i = j - 1
        fields.append(dict(name=name, opt=bool(opt), arr=bool(arr), rest=rest, vals=vals))
        i += 1
    return fields


def parse_brace(text):
    """Lista estilo `{ code, name?, kind: a|b, items[{ … }], address{ … } }`."""
    m = re.search(r"`\{(.*)\}`", text)
    if not m:
        return []
    body = m.group(1)
    fields = []
    for _, it in split_top(body):
        h = re.match(r"^([A-Za-z]\w*)(\??)(\[\])?\s*(.*)$", it.strip(), re.S)
        if not h:
            continue
        name, opt, arr, rest = h.groups()
        rest = rest.strip()
        vals = []
        if rest.startswith(":"):
            v = rest[1:].strip()
            if re.match(r"^[A-Za-z]\w*(\s*\|\s*[A-Za-z]\w*)+", v):
                vals = [x.strip() for x in re.match(r"^([A-Za-z]\w*(?:\s*\|\s*[A-Za-z]\w*)+)", v).group(1).split("|")]
                rest = v[len(re.match(r"^([A-Za-z]\w*(?:\s*\|\s*[A-Za-z]\w*)+)", v).group(1)):].strip()
            else:
                rest = v
        if rest.startswith("[") or arr:
            arr = True
        fields.append(dict(name=name, opt=bool(opt), arr=bool(arr), rest=rest, vals=vals))
    return fields


def tipo_de(f):
    n, r = f["name"], f["rest"]
    if f["vals"] or r.startswith("enum") or re.match(r"^\(`[a-z]\w*`\s*[,/|]\s*`[a-z]", r) or re.match(r"^\(?`[a-z]\w*(\|\w+)+`", r):
        return "enum"
    if r.startswith("(`{") or r.startswith("({"):
        return "object"
    if r.startswith("(`[") or r.startswith("(["):
        return "array"
    if f["arr"] or r.startswith("[") or r.startswith("`[") or re.match(r"^\(\[", r):
        return "array"
    if r.startswith("{") or r.startswith("`{") or re.match(r"^\(\{", r):
        return "object"
    head = r[:60]
    for pat, t in TYPEW:
        if re.search(pat, head):
            return t
    if n.endswith("Ids"):
        return "ObjectId[]"
    if n.endswith("Id"):
        return "ObjectId"
    if n.startswith("external") and n.endswith("Id"):
        return "string"
    if n.endswith("By"):
        return "ObjectId"
    if n.endswith("At") or n.endswith("Date") or n.endswith("Start") or n.endswith("End") or n in ("date", "validFrom", "validTo", "periodFrom", "periodTo", "from", "to", "start", "end"):
        return "Date"
    if re.match(r"^(is|has|allow|allows|requires|include|includes)[A-Z]", n) or n in ("active", "accepted", "free", "fulfilled", "definitive", "generic", "hidden", "regulatory", "valid"):
        return "bool"
    if re.search(r"(amount|Amount|total|Total|percent|Percent|Pct|rate|Rate|fee|Fee|Value|value|price|Price|cost|Cost|Qty|quantity|Quantity|coefficient|Debt|debt|Balance|balance)$", n):
        return "Decimal128"
    if re.search(r"(count|Count|order|Order|number|Number|days|Days|seq|Seconds|Minutes|Hours|No)$", n):
        return "int / string [VERIFICAR]" if n.endswith(("number", "Number", "No")) else "int"
    if re.search(r"(code|Code|name|Name|Key|key|reason|Reason|description|notes|observations|label|subject|text|Text|Ref|ref)$", n):
        return "string"
    return "[VERIFICAR]"


def oblig_de(f):
    r = f["rest"][:40]
    if f["opt"] or re.search(r"\bopcional\b|\(C\)|\bNo\b", r):
        return "No"
    if re.search(r"\(O\)|\bSí\b|\(O[;,)]", r):
        return "Sí"
    return "[VERIFICAR]"


def desc_de(f):
    r = f["rest"]
    if f["vals"]:
        return "Valores: " + ", ".join("`%s`" % v for v in f["vals"]) + "."
    r = re.sub(r"^enum\b", "", r).strip()
    r = r.strip()
    if r.startswith("(") and r.endswith(")"):
        r = r[1:-1]
    if re.fullmatch(r"\s*(bool|Boolean|Decimal128|Int|String|Date|ObjectId|UUID|money|dict|O|C|Sí|No)\s*", r):
        return ""
    r = re.sub(r"^(Int|String|Boolean|Decimal128|Date|ObjectId|Enum|Object)\s*,\s*", "", r)
    r = re.sub(r"^(Sí|No)\s*;\s*", "", r)
    return r
