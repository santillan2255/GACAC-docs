from ed import edit

print(edit("M13", [
    ("1. M09/M02 confirman la baja comercial; publican `cat.serviceContract.terminated`; STK pasa la asignación",
     "1. M09/M02 confirman la baja comercial; M02 publica `cat.contract.terminated` (EVT-CAT-15; antes citado como `cat.serviceContract.terminated`, que no está en el catálogo de T11); STK pasa la asignación"),
    ("| `cat.serviceContract.terminated` / `planChanged` | M02 | Asignaciones a `pendingReturn`. Nombres según T11 (`cat.contract.*`). |",
     "| `cat.contract.terminated` (EVT-CAT-15) / `cat.contract.planChanged` (EVT-CAT-18) | M02 | Asignaciones a `pendingReturn`. Antes citados como `cat.serviceContract.terminated` / `planChanged`; se alinean al catálogo de T11. |"),
]))
