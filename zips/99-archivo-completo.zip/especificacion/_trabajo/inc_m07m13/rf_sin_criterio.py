import os, re, sys, glob
BASE = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos"
PREF = {"M07": "COB", "M08": "MOR", "M09": "CRM", "M10": "TEC", "M11": "VEN", "M12": "CMP", "M13": "STK"}


def celdas(l):
    s = l.strip().replace("\\|", "\u0001")
    s = s[1:] if s.startswith("|") else s
    s = s[:-1] if s.endswith("|") else s
    return [c.strip().replace("\u0001", "\\|") for c in s.split("|")]


for o, p in PREF.items():
    f = glob.glob(os.path.join(BASE, o + "-*.md"))[0]
    L = open(f, encoding="utf-8-sig").read().split("\n")
    cab = None
    malos = []
    for i, l in enumerate(L):
        if l.startswith("|") and i + 1 < len(L) and re.match(r"^\|\s*:?-{3}", L[i + 1]):
            cab = [c.lower() for c in celdas(l)]
            continue
        m = re.match(r"^\|\s*\**(RF-" + p + r"-\d{3})\**\s*\|", l)
        if m:
            c = celdas(l)
            k = next((j for j, h in enumerate(cab or []) if h.startswith("criterio")), None)
            v = c[k] if k is not None and k < len(c) else "(sin columna)"
            if v.strip() in ("", "-", "—", "(sin columna)"):
                malos.append((m.group(1), i + 1, v, len(c), len(cab or [])))
    print(o, len(malos))
    for x in malos:
        print("  ", x)
