"""Categoría 5: estado inicial explícito en cada máquina de §8 que no lo declaraba (deducido de la primera transición)."""
import re
from ed import load, save

MANUAL = {
    ("M07", "8.8"): "lote `draft`; ítem `presented`",
    ("M07", "8.14"): "conciliación `open`; rendición a tesorería `prepared`",
    ("M07", "8.15"): "lista de cobro `draft`; excepción `open`",
    ("M08", "8.2"): "`recorded` (registro inmutable)",
    ("M09", "8.11"): "pase `sent`",
    ("M10", "8.13"): "elemento `planned`; conexión servicio-red `connected`",
    ("M10", "8.14"): "número `available`; línea `active`; importación `uploaded`",
}
SKIP = {("M13", "8.4")}

tot = {}
for o in ["M07", "M08", "M09", "M10", "M11", "M12", "M13"]:
    t, bom, crlf = load(o)
    L = t.split("\n")
    i0 = next(i for i, l in enumerate(L) if l.startswith("## 8."))
    i1 = next(i for i in range(i0 + 1, len(L)) if L[i].startswith("## "))
    secs = [i for i in range(i0, i1) if L[i].startswith("### ")] + [i1]
    ins = []
    for a, b in zip(secs, secs[1:]):
        num = re.match(r"### (8\.\d+)", L[a]).group(1)
        body = [l for l in L[a + 1:b] if l.strip()]
        if "inicial" in " ".join(body).lower() or (o, num) in SKIP:
            continue
        if (o, num) in MANUAL:
            val = MANUAL[(o, num)]
        else:
            first = body[0]
            if first.startswith("|"):
                c = [x.strip() for x in body[2].strip("|").split("|")]
                src = c[0]
                if src.startswith("(nuevo)") or src.startswith("— →"):
                    m = re.findall(r"`([A-Za-z]+)`", src)
                elif src == "—":
                    m = re.findall(r"`([A-Za-z]+)`", c[1])
                else:
                    m = re.findall(r"`([A-Za-z]+)`", src)
            else:
                m = re.match(r"\W*`([A-Za-z]+)", first)
                m = [m.group(1)] if m else []
            assert m, (o, num)
            val = "`%s`" % m[0]
        ins.append((a + 1, "Estado inicial: %s." % val))
    for pos, txt in reversed(ins):
        L[pos:pos] = ["", txt] if L[pos].strip() == "" else ["", txt, ""]
    save(o, "\n".join(L), bom, crlf)
    tot[o] = len(ins)
print(tot, sum(tot.values()))
