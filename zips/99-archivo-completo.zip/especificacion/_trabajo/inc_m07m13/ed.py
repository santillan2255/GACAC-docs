"""Edición segura de anexos: conserva BOM y fin de línea; cada reemplazo debe aparecer las veces esperadas."""
import glob
import os

BASE = r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos"


def path(owner):
    return glob.glob(os.path.join(BASE, owner + "-*.md"))[0]


def load(owner):
    b = open(path(owner), "rb").read()
    bom = b.startswith(b"\xef\xbb\xbf")
    t = b.decode("utf-8-sig")
    crlf = "\r\n" in t
    if crlf:
        t = t.replace("\r\n", "\n")
    return t, bom, crlf


def save(owner, t, bom, crlf):
    if crlf:
        t = t.replace("\n", "\r\n")
    b = t.encode("utf-8")
    if bom:
        b = b"\xef\xbb\xbf" + b
    open(path(owner), "wb").write(b)


def edit(owner, repls, dry=False):
    t, bom, crlf = load(owner)
    log = []
    for r in repls:
        old, new = r[0], r[1]
        n = r[2] if len(r) > 2 else 1
        c = t.count(old)
        if c != n:
            raise SystemExit("%s: se esperaban %d apariciones y hay %d de: %r" % (owner, n, c, old[:120]))
        t = t.replace(old, new)
        log.append(old[:60])
    if not dry:
        save(owner, t, bom, crlf)
    return len(log)
