from ed import edit

print(edit("M10", [
    ("| Token interno de servicio (M19 con `por.consumos.ver` resuelto, M09 con `crm.casos.ver`) |",
     "| `tec.telefonia.llamadas.ver` (cuenta técnica de servicio de M19, con `por.consumos.ver` resuelto, o de M09, con `crm.casos.ver`; antes \"Token interno de servicio\") |"),
]))
