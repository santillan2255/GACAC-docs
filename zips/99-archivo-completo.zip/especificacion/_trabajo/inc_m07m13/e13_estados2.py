from ed import edit
print(edit("M08", [
    ("`regulatoryCode` (ej. `R/C`), `status`. Validación: exactamente una",
     "`regulatoryCode` (ej. `R/C`), `status` (`active`, `inactive`; catálogo). Validación: exactamente una"),
    ("`legalText` (texto normativo obligatorio por servicio), `version`, `status`.",
     "`legalText` (texto normativo obligatorio por servicio), `version`, `status` (`draft`, `published`, `retired`; catálogo versionado, §8.1)."),
]))
