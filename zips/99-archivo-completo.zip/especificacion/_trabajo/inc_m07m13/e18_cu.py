"""Categoría 10: casos de uso compartidos; el anexo dueño conserva la definición, los demás citan su parte."""
from ed import edit

print(edit("M13", [
    ("| MED-002 ya instalado en otro suministro ⇒ bloqueo hasta resolver. | BASE §7 |",
     "| MED-002 ya instalado en otro suministro ⇒ bloqueo hasta resolver. | BASE §7. Definición dueña: M03 «CU-07 — Reemplazo de medidor»; aquí solo el tramo de stock (custodia y estados del medidor). |"),
    ("equipo distinto del reservado ⇒ sustitución validada. | BASE §73 |",
     "equipo distinto del reservado ⇒ sustitución validada. | BASE §73. Definición dueña: M10 «CU-INS-01 (BASE §73, parte técnica)»; aquí solo el tramo de stock (aplicación y custodia del equipo). |"),
    ("| El costo del módem no se convierte automáticamente en cargo al socio. | BASE §78 |",
     "| El costo del módem no se convierte automáticamente en cargo al socio. | BASE §78. Definición dueña: M12 «CU-OPE-01 — Compra de módems por servicio»; aquí solo el tramo de stock. |"),
]))

print(edit("M12", [
    ("### CU-FIS-01 — Pago con retención (BASE §61, compartido con M06/M14)\n\n",
     "### CU-FIS-01 — Pago con retención (BASE §61, compartido con M06/M14)\n\n"
     "- **Definición dueña:** M06 «CU-FIS-01 — Retención en un pago a proveedor (BASE §61, original)». Aquí solo el tramo de compras (orden de pago con la retención aplicada).\n"),
]))

print(edit("M11", [
    ("### CU-PRO-01 — Instalación financiada en el piloto (BASE §72)\n\n",
     "### CU-PRO-01 — Instalación financiada en el piloto (BASE §72)\n\n"
     "- **Definición dueña:** M02 «CU-PRO-01 (BASE) — Contratar Internet (piloto)». Aquí solo el tramo de ventas (cargo de instalación y su financiación).\n"),
    ("### CU-INS-01 — Primer cobro con instalación (BASE §73, compartido con M04/M05)\n\n",
     "### CU-INS-01 — Primer cobro con instalación (BASE §73, compartido con M04/M05)\n\n"
     "- **Definición dueña:** M10 «CU-INS-01 (BASE §73, parte técnica) — Instalación integral». Aquí solo el aporte de ventas al primer cobro.\n"),
]))

print(edit("M10", [
    ("### CU-AUT-01 (BASE §50, parte técnica) — Contratación con turno desde la app\n\n",
     "### CU-AUT-01 (BASE §50, parte técnica) — Contratación con turno desde la app\n\n"
     "- **Definición dueña:** M19 «CU-AUT-01 — Ciclo completo de Internet». Aquí solo el tramo técnico (factibilidad, reserva, visita e instalación).\n"),
    ("### CU-INS-01 (BASE §73, parte técnica) — Instalación integral\n\n",
     "### CU-INS-01 (BASE §73, parte técnica) — Instalación integral\n\n"
     "- **Definición dueña:** este anexo. M11 (primer cobro), M13 (stock) y T09 (encuesta) citan su tramo.\n"),
    ("### CU-GEO-01 (BASE §77, parte operativa) — Punto de prestación\n\n",
     "### CU-GEO-01 (BASE §77, parte operativa) — Punto de prestación\n\n"
     "- **Definición dueña:** T04 «CU-GEO-01 — Dirección de prestación georreferenciada (BASE §77, original)». Aquí solo el uso operativo del punto.\n"),
    ("La compra y el pago se describen en M13, M14 y M15.",
     "La compra y el pago se describen en M12 (definición dueña: «CU-OPE-01 — Compra de módems por servicio»), M13, M14 y M15."),
]))

print(edit("M09", [
    ("### CU-SOL-01 — Alta de Internet y baja de TV (BASE §48)\n\n",
     "### CU-SOL-01 — Alta de Internet y baja de TV (BASE §48)\n\n"
     "Definición dueña pendiente (PA-INC-M09-01): M02 también lo describe «en lo que toca al contrato»; mientras tanto, este texto cubre solo la solicitud y su circuito de atención.\n\n"),
    ("### CU-CIC-01 — Suspensión temporal y reactivación de Internet (BASE §53)\n\nVer §9.4.",
     "### CU-CIC-01 — Suspensión temporal y reactivación de Internet (BASE §53)\n\nDefinición dueña pendiente (PA-INC-M08-01; propuesta: M08 «CU-CIC-01»). Aquí solo el tramo de atención. Ver §9.4."),
]))

print(edit("M08", [
    ("### CU-CIC-01 — Suspensión temporal y reactivación de Internet (BASE §53)\n\n",
     "### CU-CIC-01 — Suspensión temporal y reactivación de Internet (BASE §53)\n\n"
     "Definición dueña pendiente (PA-INC-M08-01; propuesta: este anexo, que define el caso de suspensión y reactivación). M02 describe el cambio de estado del contrato y M09 el tramo de atención.\n\n"),
    ("### CU-CTA-01 — Evaluación de mora en cuenta unificada (BASE §68)\n\n",
     "### CU-CTA-01 — Evaluación de mora en cuenta unificada (BASE §68)\n\n"
     "Definición dueña: M07 «CU-CTA-01 — Cuenta unificada con mínimo (BASE §68)». Aquí solo la evaluación de mora posterior.\n\n"),
]))

print(edit("M07", [
    ("**CU-FAC-01 — Factura agrupada multiservicio cobrada (BASE §44).** ",
     "**CU-FAC-01 — Factura agrupada multiservicio cobrada (BASE §44).** Definición dueña: M05 «CU-FAC-01»; aquí solo el tramo de cobranza. "),
    ("**CU-103 — Factura agrupada por grupo de facturación (BASE §103).** ",
     "**CU-103 — Factura agrupada por grupo de facturación (BASE §103).** Definición dueña: M05 «CU-103»; aquí solo el tramo de cobranza e imputación. "),
]))
