from ed import edit
print(edit("M13", [
    ("`contractId` (C), `stockState` (O), `quantity` (O)",
     "`contractId` (C), `stockState` (O; mismos valores que `stockMovements.stockState`, §7.11: `available`, `inTransit`, `custody`, `applied`, `repair`, `supplier`, `quarantine`, `consigned`, `scrap`; es dimensión del saldo, no máquina de estados), `quantity` (O)"),
]))
