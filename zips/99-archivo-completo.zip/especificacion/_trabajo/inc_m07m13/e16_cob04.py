from ed import edit
print(edit("M07", [
    ("| operación, recibos (cada uno con su `legalEntityId`; uno por entidad, RF-COB-193), imputaciones por componente (cada una con el `itemClass` de su obligación, RN-COB-157), canal, medios por recibo, fecha de cobro, `legalEntityId` de la caja |",
     "| `cashOperationId`, `receipts[]` (`{ receiptId, legalEntityId }`; uno por entidad, RF-COB-193), `allocations[]` (`{ allocationId, obligationId, component, itemClass, amount }`; RN-COB-157), `channel`, `tendersByReceipt[]` (`{ receiptId, method, amount }`), `paymentDate`, `legalEntityId` (de la caja) (antes: \"operación, recibos, imputaciones por componente, canal, medios por recibo, fecha de cobro, `legalEntityId` de la caja\") |"),
]))
