"""Categoría 7: payloads en texto libre del §12.1 de M07 y M08 pasan a nombres de campo (se conserva el texto anterior)."""
from ed import load, save

M07 = {
    "EVT-COB-01": "`obligationId`, `currentAccountId`, `serviceId`, `dueSchedule[]`",
    "EVT-COB-02": "`obligationId`, `settledAt`, `channel`",
    "EVT-COB-03": "`obligationId`, `cause`",
    "EVT-COB-05": "`receiptId`, `reversedAllocationIds[]`",
    "EVT-COB-06": "`allocationIds[]`",
    "EVT-COB-07": "`obligationId`, `components[]`, `paymentDate`",
    "EVT-COB-08": "`currentAccountId`, `minimumPayment`, `paidAmount`, `fulfilled`",
    "EVT-COB-09": "`creditBalanceId`, `origin`",
    "EVT-COB-10": "`certificateNumber`, `regime`, `amount`",
    "EVT-COB-11": "`channel`, `netAmount`, `feeAmount`, `expectedCreditDate`, `treasuryAccountId`",
    "EVT-COB-12": "`sessionId`, `expected[]`, `declared[]`, `differences[]`",
    "EVT-COB-14": "`sessionId`, `amount`",
    "EVT-COB-15": "`channel`, `grossFee`, `feeVat`",
    "EVT-COB-16": "`obligationId`, `rejectCode`, `definitive`",
    "EVT-COB-17": "`directDebitMandateId`",
    "EVT-COB-18": "`transactionId`, `currentAccountIds[]`",
    "EVT-COB-19": "`refundCaseId`",
    "EVT-COB-20": "`paymentIntentId`, `status`",
    "EVT-COB-21": "`thirdPartyBillerId`, `amount`, `fee`",
    "EVT-COB-22": "`collectionExceptionId`, `type`, `severity`",
    "EVT-COB-23": "`actorId`, `before`, `after`",
    "EVT-COB-24": "`informedOperationRef`, `currentAccountId`, `amount`, `channel`, `evidenceStoredFileIds[]`",
    "EVT-COB-25": "`sessionId`, `reason`, `authorizedBy`",
    "EVT-COB-26": "`unidentifiedReceiptId`, `currentAccountId`, `cashOperationId`",
    "EVT-COB-27": "`refundCaseId`, `currentAccountId`, `amount`, `paymentMethod`",
}
M08 = {
    "EVT-MOR-01": "`policyType` (interés, mora, esquema, plan), `policyId`, `version`",
    "EVT-MOR-04": "`runId`, `totals`",
    "EVT-MOR-05": "`documentId`, `holdReasonId`, `origin`",
    "EVT-MOR-06": "`accountId`, `decisionsByService[]`",
    "EVT-MOR-07": "`batchId`, `stageId`, `count`, `debtAmount`",
    "EVT-MOR-08": "`noticeId`, `accountId`, `stageId`",
    "EVT-MOR-10": "`noticeId`, `reason`",
    "EVT-MOR-11": "`noticeId`, `promisedDate`, `amount`",
    "EVT-MOR-14": "`agreementId`, `amounts`",
    "EVT-MOR-17": "`caseId`",
}


def apply(owner, mp, col):
    t, bom, crlf = load(owner)
    L = t.split("\n")
    n = 0
    for i, l in enumerate(L):
        for k, v in mp.items():
            if l.startswith("| " + k + " |"):
                c = l.split(" | ")
                old = c[col]
                c[col] = "%s (antes: \"%s\")" % (v, old)
                L[i] = " | ".join(c)
                n += 1
    assert n == len(mp), (owner, n)
    save(owner, "\n".join(L), bom, crlf)
    return n


print(apply("M07", M07, 3), apply("M08", M08, 2))
