from ed import edit
print(edit("M08", [
    ("Identidad técnica por tenant con capabilities de jobs `mor:*`",
     "Identidad técnica por tenant (cuenta técnica S-SYS, RF-IAM-115) con las capabilities `mor.<recurso>.<acción>` que ejecuta cada job (antes `mor:*`, sintaxis fuera de la convención de T02)"),
]))
