import sys, io, glob
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
F = glob.glob(r"c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos\T05-*")[0]
t = open(F, "rb").read().decode("utf-8")
NL = "\r\n"

def rep(old, new):
    global t
    assert t.count(old) == 1, old[:80]
    t = t.replace(old, new)

rep("PA-DAT-03 se agregó el 5-11-2026 en el cierre de la corrección de inconsistencias y queda **Asumida (DEC-072)**.",
    "PA-DAT-03 se agregó el 5-11-2026 en el cierre de la corrección de inconsistencias y queda **Asumida (DEC-072)**; PA-DAT-04 se agregó el mismo día en el cierre de residuales y también queda **Asumida (DEC-072)**.")

pa = [
"### PA-DAT-04 — Destinos de referencia pendientes y alineación del catálogo con los anexos dueños",
"",
"- **Pregunta:** ¿qué destino toman los campos de referencia marcados [VERIFICAR] en §7.2.1 y en el catálogo, y cómo se resuelven las diferencias de nombre entre el catálogo y los §7 de los anexos dueños?",
"- **Contexto:** cierre de residuales del 5-11-2026 (`_trabajo/residuales-instrucciones.md`). El diagrama entidad-relación (`docs/entregables-analisis-diseno/03-er/`) contaba 393 campos que solo figuraban en T05; la mayoría eran nombres de T05 distintos del anexo dueño y una parte eran nombres citados en notas \"antes `x`\", que el generador también cuenta. Seguían abiertos los [VERIFICAR] de `templateId`, `deviceId`, `targetAccountId`, `importBatchId`, `projectId`, `lineId`, `memberId`, `paymentId` y `unitId`, el doble destino de `taxRateIds` y las cuentas contables de COL-FIS-16 y COL-FIS-18.",
"- **Opciones:**",
"  - A) Fijar un destino único por colección o módulo, alinear el catálogo al anexo dueño cuando el anexo usa un nombre canónico y conservar el canónico de §7.2 cuando el anexo no lo usa (el anexo debe renombrar) **(Recomendada)**.",
"  - B) Dejar los [VERIFICAR] hasta que cada anexo dueño confirme — bloquea los esquemas de las olas O1 a O10.",
"- **Impacto si no se responde:** se asume A.",
"- **Bloquea:** §7.2.1; COL-FIS-16, COL-FIS-18, COL-TAR-20, COL-INS-11; las 64 filas alineadas (§7.3 a §7.7).",
"- **Estado:** **Asumida (DEC-072)**, opción A. Aplicada el 5-11-2026:",
"  - §7.2.1: `templateId` de M12 y T02 → `messageTemplates`; de M10 y M17 → `documentTemplates`; de M08 `suspensionRestrictionRules` → `code` de la fila de plataforma de la misma colección; `deviceId` de M03 → `fieldDevices`; de M16 y T06 → dispositivo embebido en `localAgents.devices[]`; `targetAccountId` de M08 → `accounts`; `importBatchId` → `migrationBatches` (T02, M11) y `masterImportJobs` (M08); `projectId` → `crmProjects` (M11) y `works` (M13); `taxRateIds` → solo `vatRates` (el resto de los tributos en `taxIds` → `taxDefinitions`; M04 debe separar los campos); `lineId` de T10 → renglón `invoices.lines[]`; `memberId` → `associateMemberships`; `paymentId` → `receipts`; `unitId` de M01 → subdocumento `premises.units`; filas nuevas `rightId` → `burialRights` y `paymentOrderRef` → `paymentOrders`.",
"  - Cuentas contables de `vatRates` y `taxDefinitions` en `entityAccountAssignments` (COL-CON-38); M06 no guarda `ledgerAccountId` y M15 debe admitir `entityType` `vatRate` y `taxDefinition`.",
"  - `apiUsageDaily` único `{apiClientId, day}` (antes `date`, alineado a T10); `relationships` ya usaba `subjectPersonId`/`target` en las dos columnas (sin cambio).",
"  - 64 filas del catálogo alineadas a los §7 de T01, T02, T04, T06, T08, T10, M07, M09, M10, M13, M14, M15 y M16, con nota \"5-11-2026, residuales: alineado a … §7; antes …\".",
"  - Se mantiene el nombre de T05 porque el anexo dueño usa uno no canónico de §7.2 o §7.2.1 (el anexo debe renombrar): M14 `paymentFiles` (`originTreasuryAccountId`; el anexo dice `originAccountId`); T01 `tenantExports` (`storedFileId`; el anexo dice `fileId`); M04 `tariffScheduleId` (el anexo dice `scheduleId`, admitido solo dentro de M04); M13 `stockDocumentId` y `currentContractId`; M17 `fromAssociateMembershipId`, `toAssociateMembershipId`, `grantorAssociateMembershipId` y `proxyAssociateMembershipId`; M16 `cbuHmac` y el número de `laborLawsuits`; M18 `documentRefId` (apunta a `documents`; el anexo lo apunta a `storedFiles`), `supplierId` (el anexo dice `providerId`), `fuelTypes.vatRateId` y `housingContributions.invoiceId`.",
"  - Las 6 filas `R` pasan a `C (antes R)`. Los totales no cambian: 1.108 filas y 1.057 colecciones a crear. Ya no bloquea.",
"",
]
anchor = "## 22. Trazabilidad"
rep(anchor, NL.join(pa) + NL + anchor)
rep("| `_GUIA-REDACCION-ANEXOS.md` §9 (formato de PA) | §21 |",
    "| `_GUIA-REDACCION-ANEXOS.md` §9 (formato de PA) | §21 |" + NL +
    "| `_trabajo/residuales-instrucciones.md` (cierre de residuales, 5-11-2026) | PA-DAT-04; §7.2.1; tabla de control §7.7.10; COL-FIS-16, COL-FIS-18, COL-TAR-20, COL-INS-11, COL-BIA-23 y las filas alineadas |")
open(F, "wb").write(t.encode("utf-8"))
print("ok")
