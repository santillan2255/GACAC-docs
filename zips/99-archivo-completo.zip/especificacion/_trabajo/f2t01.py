import sys, re
sys.path.insert(0, r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo')
from repl import apply, fpath
from conc_lib import read, write

P = []
P.append(("Configuración versionada, registro de parámetros, tablas maestras, sucursales/puntos de venta y geografía → **T04 CFG**.",
          "Configuración versionada, registro de parámetros, tablas maestras, entidades jurídicas, sucursales, puestos y geografía → **T04 CFG** (DEC-064); los puntos de venta fiscales son de **M06 FIS**."))
P.append(("`supportCaseMessages`, `supportAccessGrants`, `supportSessions`",
          "`supportCaseMessages`, `supportAccessGrants` (dueño T02, CTR-DAT-02; T01 lo consume), `supportSessions`"))
P.append(("auditEvents", "auditLogs", 0))
P.append(("| plugin de auditoría de `apps/api/src/core/audit` + `auditLogs` |",
          "| plugin de auditoría de `apps/api/src/core/audit` + `auditLogs` de T02 (antes `auditEvents`, CTR-DAT-24) |"))
# DECs en RF
P.append(("| RF-PLA-029 | Aislamiento en **IA**:", "| RF-PLA-029 | Aislamiento en **IA** (clave del proveedor de IA provista por la plataforma, con opción de clave propia del tenant, DEC-020):"))
P.append(("| RF-PLA-065 | **Capa 1 — Licencia**: qué módulos contrató el tenant (`tenantLicenses`), con origen (plan, complemento, prueba, cortesía), vigencia y cupos. | CNX §2.4, AGR-005 |",
          "| RF-PLA-065 | **Capa 1 — Licencia**: qué módulos contrató el tenant (`tenantLicenses`), con origen (plan, complemento, prueba, cortesía), vigencia y cupos. La plataforma habilita los servicios según la licencia; el administrador del tenant los publica, con aprobación de otro usuario en producción (DEC-021, M02). | CNX §2.4, AGR-005, DEC-021 |"))
P.append(("| CNX §2.4 (`packs: basico/todo`), BASE §99.3 (planes por tamaño), BASE §97.11 | Estándar | O1 | A validar (PA-PLA-09) |",
          "| CNX §2.4 (`packs: basico/todo`), BASE §99.3 (planes por tamaño), BASE §97.11, DEC-065 | Estándar | O1 | Adoptado (DEC-065: packs por tamaño más complementos con cupo por contratos activos) |"))
P.append(("| RF-PLA-078 | Cupos por dimensión:", "| RF-PLA-078 | Cupos por dimensión (el consumo de mensajería del proveedor de plataforma se vende como complemento medido, DEC-077 y DEC-065):"))
P.append(("| RF-PLA-127 | Claves de cifrado (KMS) y bóveda de secretos con su propio respaldo y procedimiento de recuperación. | AGR-019 (claves) |",
          "| RF-PLA-127 | Claves de cifrado (KMS) y bóveda de secretos con su propio respaldo y procedimiento de recuperación; la bóveda usa cifrado por sobre en MongoDB con clave maestra en AWS KMS (DEC-074). | AGR-019 (claves), DEC-074 |"))
P.append(("| RF-PLA-131 | Perfil de volumen a relevar y mantener:", "| RF-PLA-131 | Perfil de volumen a relevar y mantener (referencia de DEC-075: tenant estándar 25.000 suministros, grande 150.000; diseño para 100 tenants y hasta 300 sin rediseño):"))
P.append(("| RF-PLA-076 | Registrar por tenant el **contrato SaaS**: plan, módulos, cupos, vigencia, renovación, región, objetivos de servicio (SLA/RPO/RTO), condiciones de salida y documento firmado. | BASE §97.11, AGR-005 |",
          "| RF-PLA-076 | Registrar por tenant el **contrato SaaS**: plan, módulos, cupos, vigencia, renovación, región, objetivos de servicio (SLA/RPO/RTO), condiciones de salida y documento firmado, con el contrato tipo de encargo de tratamiento (GoodApps como prestador por cuenta de la cooperativa, art. 25 Ley 25.326). | BASE §97.11, AGR-005, DEC-062, DEC-063, DEC-076 |"))
# RN-PLA-006 / 007
P.append(("| RN-PLA-006 | Los datos de la cooperativa (razón social, CUIT, domicilio, IIBB, inicio de actividades, logo) viven en la entidad tenant (identidad) y en T04/M06 (datos fiscales detallados, sucursales, puntos de venta, depósitos); no en variables. |",
          "| RN-PLA-006 | Los datos de la cooperativa (razón social, CUIT, domicilio, IIBB, inicio de actividades, logo) viven en la entidad tenant (identidad) y en T04/M06 (datos fiscales detallados, sucursales, puntos de venta, depósitos); no en variables. **Corregido (DEC-064):** `tenants` guarda los datos de contratación; los datos legales y fiscales básicos de cada persona jurídica viven en `legalEntities` de T04 (la entidad por defecto se crea con el tenant desde esos datos, T04 RF-CFG-135); sucursales en `branches` de T04; puntos de venta y perfil fiscal en M06; logo en T03. |"))
P.append(("| **Mejorar**. | — | Ver PA-PLA-14 (varias personas jurídicas). |",
          "| **Mejorar**. | — | PA-PLA-14 respondida por DEC-064: un tenant puede tener varias entidades jurídicas con CUIT distintos en `legalEntities` (T04); la unicidad de esta regla aplica al CUIT principal del contrato. |"))
# 7.4 tabla de módulos
P.append(("| `tenantBranding`, `dictionaryEntries`, `pinnedShortcuts` |",
          "| `tenantBrandings` (CTR-DAT-51), `dictionaryEntries`, `pinnedShortcuts` |"))
P.append(("| `cfg` | Configuración versionada, parámetros, maestros, geografía, sucursales | T04 | O1 | `parameterValues`, `configPackages`, `masterTables`, `branches`, `pointsOfSale`, `geo*` |",
          "| `cfg` | Configuración versionada, parámetros, maestros, geografía, entidades jurídicas y sucursales | T04 | O0–O1 | `parameterValues` (alias `tenantParameters`, CTR-DAT-49), `configVersions` (antes citado como `configPackages`), `masterTableDefinitions` (antes `masterTables`), `legalEntities` y `branches` (O0, DEC-064), `workstations`, `geo*`; `pointsOfSale` es de M06 |"))
# tenants
P.append(("| `brandingRef` | ObjectId → `uxd.tenantBranding` | No | Referencia a T03. |",
          "| `brandingRef` | ObjectId → `tenantBrandings` (T03) | No | Referencia a T03 (nombre de la colección corregido por CTR-DAT-51). |"))
P.append(("Mapeo ProCoop: `Configuracion*.pro` + variables 518–527 y 709 + `EMPRESAS` (ver PA-PLA-14).",
          "Mapeo ProCoop: `Configuracion*.pro` + variables 518–527 y 709; `EMPRESAS` → `legalEntities` de T04 (DEC-064, PA-PLA-14)."))
# supportAccessGrants
P.append(("#### 7.11.11. `supportAccessGrants`\n",
          "#### 7.11.11. `supportAccessGrants`\n\n> **Reemplazado por `supportAccessGrants` de T02 (CTR-DAT-02):** la concesión de acceso es de T02 (dueño de autorización). T01 la crea por comando desde el caso de soporte y consume su estado; la tabla siguiente queda como requisito de campos para T02.\n"))
# eventos
P.append(("| EVT-PLA-01 | `pla.tenant.created` | tenantId, code, kind, planCode | `iam` (invitación admin), `uxd` (branding), `com` (aviso), `pla` (checklist) |",
          "| EVT-PLA-01 | `pla.tenant.created` | tenantId, code, kind, planCode, legalName, cuit, legalForm, inaesRegistration, fiscalAddress | `iam` (invitación admin), `uxd` (branding), `com` (aviso), `pla` (checklist), `cfg` (entidad jurídica por defecto y casa central, T04 §9.16, DEC-064) |"))
P.append(("| EVT-PLA-21 | `pla.branch.created` / `.updated` | branchId, code, name, status | `uxd` (slots de marca por sucursal), `cfg` |",
          "| EVT-PLA-21 | `pla.branch.created` / `.updated` | branchId, code, name, status | `uxd` (slots de marca por sucursal), `cfg` — **Reemplazado por EVT-CFG-20 `cfg.branch.created/.updated/.deactivated` de T04** (dueño de `branches`, DEC-064; CTR-PLA-17) |"))
P.append(("| EVT-PLA-22 | `pla.tenantProfile.updated` | tenantId, changedFields (razón social, CUIT, domicilio legal, logo) | `uxd` (pie y documentos), `wfl` (plantillas), `fis` |",
          "| EVT-PLA-22 | `pla.tenantProfile.updated` | tenantId, changedFields (razón social, CUIT, domicilio legal, logo) | `uxd` (pie y documentos), `wfl` (plantillas), `fis`. Los cambios de datos legales de cada entidad jurídica se publican en EVT-CFG-19 `cfg.legalEntity.updated` de T04 (DEC-064); este evento queda para los datos de contratación del tenant |"))
# migración
P.append(("| `tenants` (identidad) + M06/T04 (datos fiscales) + T03 (logo) | Normalización de CUIT y domicilio | CUIT coincide con padrón ARCA |",
          "| `tenants` (identidad) + `legalEntities` de T04 (entidad por defecto, DEC-064) + M06 (perfil fiscal) + T03 (logo) | Normalización de CUIT y domicilio | CUIT coincide con padrón ARCA |"))
P.append(("| `EMPRESAS` (empresas del grupo), `SU_EMPRESAS` (empleadores) | Según PA-PLA-14 (entidades jurídicas del tenant en T04 / M16) | — | Conteo |",
          "| `EMPRESAS` (empresas del grupo), `SU_EMPRESAS` (empleadores) | `legalEntities` de T04 y su subdocumento `employer` (DEC-064, CTR-DAT-06; T04 RF-CFG-142) | Match por CUIT | Conteo |"))
P.append(("| `EMPRESAS` | PA-PLA-14 | A validar |",
          "| `EMPRESAS` | `legalEntities` de T04 (DEC-064) | Delegado |"))
# CTR
P.append(("| Región parametrizable por contrato (`PRM-PLA-049`); recomendada sa-east-1 (PA-PLA-01) | A validar (PA-PLA-01) |",
          "| Región parametrizable por contrato (`PRM-PLA-049`); AWS sa-east-1 con cláusulas contractuales de la AAIP (DEC-062) | DEC-062 |"))
P.append(("| `tenantLicenses` + activaciones + pantallas (T02); trial por `PRM-PLA-008` | AGR-004 + BASE §66 |\n",
          "| `tenantLicenses` + activaciones + pantallas (T02); trial por `PRM-PLA-008` | AGR-004 + BASE §66 |\n"
          "| CTR-PLA-17 | §2, RN-PLA-006, EVT-PLA-21 y §19 de este anexo vs DEC-064 y T05 (COL-CFG-41/42, CTR-DAT-48) | Perfil legal, sucursales y sus eventos repartidos entre T01 y T04 | `legalEntities` y `branches` son de T04 desde O0; T01 conserva los datos de contratación en `tenants` y publica `pla.tenant.created` con ellos; los eventos de sucursal pasan a EVT-CFG-20 | DEC-064 |\n"
          "| CTR-PLA-18 | Colecciones citadas por este anexo vs T05 | `brandingRef` → `uxd.tenantBranding`, `tenantParameters`, `configPackages`, `masterTables`, `pointsOfSale` en T04, `supportAccessGrants` y `auditEvents` como propios | `tenantBrandings` (T03, CTR-DAT-51); `parameterValues` (CTR-DAT-49); `configVersions` y `masterTableDefinitions` (T04); `pointsOfSale` (M06); `supportAccessGrants` y `auditLogs` (T02, CTR-DAT-02 y CTR-DAT-24) | T05 (modelo canónico) |\n"))
apply('T01', P, 'f2-g6-t01')

# Estados de PA
p = fpath('T01')
s = read(p)
est = {
    'PA-PLA-01': 'Respondida (DEC-062): AWS sa-east-1 (San Pablo) con cláusulas contractuales de transferencia internacional según la AAIP; diseño agnóstico de nube.',
    'PA-PLA-02': 'Respondida (DEC-063): RPO ≤ 15 min; RTO ≤ 4 h por tenant y ≤ 8 h para la plataforma completa.',
    'PA-PLA-03': 'Respondida (DEC-063): disponibilidad 99,5 % mensual; p95 interactivo ≤ 800 ms; soporte de lunes a viernes de 8 a 18 con P1 24×7.',
    'PA-PLA-08': 'Respondida (DEC-065): facturación del SaaS con M05 bajo el tenant `PLATFORM` desde O5 y prefactura exportable en O1.',
    'PA-PLA-09': 'Respondida (DEC-065): packs por tamaño más complementos con cupo por contratos activos; la mensajería revendida es un complemento medido (DEC-077).',
    'PA-PLA-14': 'Respondida (DEC-064): opción A; `legalEntities` y `branches` se definen en T04 (RF-CFG-134 a 142) desde O0, con `legalEntityId` obligatorio en los documentos económicos.',
}
L = s.split('\n')
for pa, txt in est.items():
    h = [i for i, l in enumerate(L) if l.startswith('### ' + pa + ' ')]
    assert len(h) == 1, pa
    i = h[0] + 1
    while not L[i].startswith('- **Bloquea:**'):
        assert not L[i].startswith('### '), pa
        i += 1
    if not L[i + 1].startswith('- **Estado:**'):
        L.insert(i + 1, '- **Estado:** ' + txt)
s = '\n'.join(L)

# Trazabilidad de DEC
old = '### 22.7. Variables V2 (orígenes de parámetros)'
assert s.count(old) == 1
add = ('### 22.8. Decisiones del solicitante que alcanzan a T01\n\n'
       '| DEC | Destino en este anexo |\n|---|---|\n'
       '| DEC-020 (claves de mapas e IA de plataforma, con opción propia del tenant) | RF-PLA-029; claves en la bóveda de T06 |\n'
       '| DEC-021 (la plataforma habilita servicios por licencia; el tenant publica con aprobación en producción) | RF-PLA-065, RF-PLA-070 |\n'
       '| DEC-025 (copias entre tenants con autorización explícita del tenant origen) | Sin requisito propio: la copia es de M02 y la recibe T04 como versión en borrador; el acceso de soporte entre tenants sigue la concesión de T02 |\n'
       '| DEC-026 (plantillas de plataforma sin precios ni condiciones reguladas) | RF-PLA-070 (la oferta la crea el tenant; las plantillas las define M02) |\n'
       '| DEC-062 (región AWS sa-east-1) | RF-PLA-076, CTR-PLA-14, PA-PLA-01 |\n'
       '| DEC-063 (disponibilidad, RPO, RTO, latencia y soporte) | RF-PLA-076, PA-PLA-02, PA-PLA-03 |\n'
       '| DEC-064 (varias entidades jurídicas por tenant) | RN-PLA-006, RN-PLA-007, EVT-PLA-01, EVT-PLA-21, EVT-PLA-22, §7.11.1, §19, CTR-PLA-17, PA-PLA-14 |\n'
       '| DEC-065 (packs, complementos y facturación del SaaS) | RF-PLA-072, RF-PLA-078, PA-PLA-08, PA-PLA-09 |\n'
       '| DEC-074 (bóveda con cifrado por sobre y AWS KMS) | RF-PLA-127 |\n'
       '| DEC-075 (perfil de capacidad) | RF-PLA-131 |\n'
       '| DEC-076 (GoodApps como prestador de tratamiento, art. 25) | RF-PLA-076 |\n'
       '| DEC-077 (dos modelos de mensajería) | RF-PLA-078 |\n\n')
s = s.rstrip('\n') + '\n\n' + add.rstrip('\n') + '\n'
write(p, s)
print('T01 estados y 22.8 ok')
