$ErrorActionPreference = 'Stop'
$base = 'c:\Users\lenovo\Documents\GACAC\docs\especificacion\anexos'
$utf8 = New-Object System.Text.UTF8Encoding($false)

$map = @{
  'M08-MOR-mora-financiacion.md' = @(
    @('\bserviceContractIds\b', 'contractIds'),
    @('\bserviceContractId\b', 'contractId'),
    @('\bdocumentTypeIds\b', 'voucherTypeIds'),
    @('\bdocumentTypeId\b', 'voucherTypeId'),
    @('\bfileId\b', 'storedFileId'),
    @('\bworkflowId\b', 'workflowInstanceId'),
    @('\baccountingAccountRef\b', 'ledgerAccountId')
  )
  'M07-COB-cuenta-corriente-cobranza.md' = @(
    @('\bdocumentTypeId\b', 'voucherTypeId'),
    @('\bfileId\b', 'storedFileId'),
    @('\bbankAccountId\b', 'treasuryAccountId'),
    @('\baccountingAccountRef\b', 'ledgerAccountId'),
    @('\bapprovalId\b', 'approvalRequestId')
  )
  'M12-CMP-compras-proveedores.md' = @(
    @('\bfileId\b', 'storedFileId'),
    @('\bworkflowId\b', 'workflowInstanceId'),
    @('\bbankAccountId\b', 'supplierBankAccountId')
  )
  'M15-CON-contabilidad.md' = @(
    @('\baccountIds\b', 'ledgerAccountIds'),
    @('\baccountId\b', 'ledgerAccountId'),
    @('\bmemberAccountId\b', 'accountId'),
    @('\bcompanyId\b', 'legalEntityId'),
    @('\bfileIds\b', 'storedFileIds'),
    @('\bfileId\b', 'storedFileId'),
    @('\bbankAccountId\b', 'treasuryAccountId')
  )
}

foreach ($f in $map.Keys) {
  $path = Join-Path $base $f
  $bytes = [System.IO.File]::ReadAllBytes($path)
  $hasBom = ($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191)
  $text = [System.IO.File]::ReadAllText($path, $utf8)
  foreach ($pair in $map[$f]) {
    $n = ([regex]::Matches($text, $pair[0])).Count
    $text = [regex]::Replace($text, $pair[0], $pair[1])
    Write-Output "$f : $($pair[0]) -> $($pair[1]) ($n)"
  }
  [System.IO.File]::WriteAllText($path, $text, (New-Object System.Text.UTF8Encoding($hasBom)))
}
