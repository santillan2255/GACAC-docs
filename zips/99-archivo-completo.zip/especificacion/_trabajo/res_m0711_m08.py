from res_m0711_lib import *

d = Doc('M08')
PA = 'PA-MOR-22'
H = lambda n: '#### 7.37.%s ' % n
V = '[VERIFICAR] destino no deducible (identificador externo o interno)'
A = '(%s; antes "%s")' % (PA, V)

# ---- tablas de "referencias declaradas" a 3 columnas (tipo explícito)
d.table_to3(H(1), {'base.taxIds': 'ObjectId[]', 'base.excludedTaxIds': 'ObjectId[]', 'adminFee.amount': 'Decimal128',
                   'adminFee.admissibilityRef': 'string', 'values.dailyRate': 'Decimal128'})
d.set_row(H(1), 'base.taxIds', '| `base.taxIds` | ObjectId[] | → M06 `taxDefinitions` (T05 §7.2.1, `taxIds`) %s |' % A, 2)
d.set_row(H(1), 'base.excludedTaxIds', '| `base.excludedTaxIds` | ObjectId[] | → M06 `taxDefinitions` (T05 §7.2.1, `taxIds`) %s |' % A, 2)
d.set_row(H(1), 'adminFee.amount', '| `adminFee.amount` | Decimal128 | No es referencia: importe del cargo administrativo %s |' % A, 2)
d.set_row(H(1), 'adminFee.admissibilityRef', '| `adminFee.admissibilityRef` | string | No es referencia: cita normativa de admisibilidad (texto) %s |' % A, 2)
d.set_row(H(1), 'fiscal.defaultVatSituationId', '| `fiscal.defaultVatSituationId` | ObjectId | → M06 `vatConditionSettings` (condición IVA por defecto, COL-FIS-15) %s |' % A, 2)
d.set_row(H(1), 'values.dailyRate', '| `values.dailyRate` | Decimal128 | No es referencia: tasa diaria %s |' % A, 2)
d.set_row(H(1), 'publishedVersionId', '| `publishedVersionId` | ObjectId | → T04 `configVersions` (versión publicada del paquete de configuración, COL-CFG-03) %s |' % A, 2)
d.table_to3(H(2), {'rates[].rateId': 'ObjectId'})
d.set_row(H(2), 'rates[].rateId', '| `rates[].rateId` | ObjectId | No es referencia: identificador del tramo dentro de la tabla (`COD_MOT`) %s |' % A, 2)
d.table_to3(H(5), {'scope.cycleIds': 'ObjectId[]'})
d.set_row(H(5), 'scope.cycleIds', '| `scope.cycleIds` | ObjectId[] | → M05 `billingCycles` (ciclo de facturación, COL-FAC-01) %s |' % A, 2)
d.table_to3(H(7), {'policyVersion': 'int'})
d.set_row(H(7), 'policyVersion', '| `policyVersion` | int | No es referencia: número de versión de `interestPolicies` usado en el cálculo %s |' % A, 2)
d.set_row(H(10), 'chargeRequestId', '| `chargeRequestId` | ObjectId | [VERIFICAR] | Cargo pedido a M05. | → M05 `billableItems` (cargo pendiente; T05 §7.2.1, `pendingChargeId`) %s |' % A, 2)
d.set_row(H(12), 'reasonId', '| `reasonId` | ObjectId | Sí | Mismo dato que `holdReasonId` (nombre de T05, fila final); se usa `holdReasonId`. | → M08 `holdReasons` (T05 §7.2.1, `reasonId`) %s |' % A, 2)
d.table_to3(H(16), {'noticeModelVersion': 'int'})
d.set_row(H(16), 'batchId', '| `delinquencyBatchId` | ObjectId | → M08 `delinquencyBatches`. Nombre canónico de T05 §7.2 (antes `batchId`; antes "`delinquencyBatches` (M08); antes implícita por el nombre") |', 4)
d.set_row(H(16), 'noticeModelVersion', '| `noticeModelVersion` | int | No es referencia: número de versión de `delinquencyNoticeModels` usado %s |' % A, 2)
d.set_row(H(16), 'costChargeRequestId', '| `costChargeRequestId` | ObjectId | → M05 `billableItems` (cargo del costo de envío; T05 §7.2.1, `pendingChargeId`) %s |' % A, 2)
d.table_to3(H(18), {'reasonText': 'string'})
d.set_row(H(18), 'reasonText', '| `reasonText` | string | No es referencia: motivo en texto libre %s |' % A, 2)
d.set_row(H(24), 'collectionEntityId', '| `collectionEntityId` | ObjectId | [VERIFICAR] | Ente recaudador de M07 cuando la entidad también cobra (antes tipo `array`). | → M07 `collectionAgencies` (ente recaudador, no `debtCollectionAgencies` de M08; %s; antes "`collectionAgencies` (M07); antes implícita por el nombre") |' % PA, 2)
d.table_to3(H(26), {'planSnapshot': 'object', 'refinancesAgreementIds': 'ObjectId[]', 'guaranteeIds': 'ObjectId[]'})
d.set_row(H(26), 'targetAccountId', '| `targetAccountId` | ObjectId | → M01 `accounts` (cuenta de destino, V2 #2634; T05 §7.2.1) %s |' % A, 2)
d.set_row(H(26), 'planSnapshot', '| `planSnapshot` | object | No es referencia: condiciones del plan congeladas %s |' % A, 2)
d.set_row(H(26), 'templateId', '| `templateId` | ObjectId | → T11 `documentTemplates` (plantilla del convenio; T05 §7.2.1) %s |' % A, 2)
d.add_rows_end_of_table(H(26), ['| `signatureRequestId` | ObjectId | → T11 `signatureRequests` (pedido de firma de `signers[]`; COL-WFL-48 cita los convenios de M08). Declarado en T05; no figuraba en el anexo (%s). |' % PA], 2)
d.set_row(H(31), 'taxId', '| `taxId` | string | [VERIFICAR] | CUIT del estudio o agencia (antes tipo `ObjectId`). | No es referencia (T05 §7.2.1, `taxId`) %s |' % A, 2)

# §7 original: nombre canónico delinquencyBatchId
d.replace_in_line('| `batchId` / `batchNumber` |', '| `batchId` / `batchNumber` | ObjectId / Int | Sí | `LOTE`. |',
                  '| `delinquencyBatchId` / `batchNumber` | ObjectId / Int | Sí | `LOTE`. `delinquencyBatchId` → `delinquencyBatches`; nombre canónico de T05 §7.2 (antes `batchId`). |', 4)
d.replace_in_line('`{tenantId, batchId}`', '`{tenantId, batchId}`', '`{tenantId, delinquencyBatchId}` (antes `{tenantId, batchId}`)', 4)
# campos que T05 cita y el anexo no declaraba
d.add_rows_after('### 7.17 ', 'alertDaysBefore', ['| `personSensitiveDataId` | ObjectId → M01 `personSensitiveData` | No | Condición sensible acreditada (electrodependencia, salud) cuando `type` la requiere. Declarado en T05 (COL-MOR-20); no figuraba en el anexo (%s). |' % PA], 2)
d.add_rows_after('### 7.18 ', 'origin', ['| `code` | String | Sí | Código único de la regla en el tenant. Declarado en T05 (único `code`, COL-MOR-21); no figuraba en el anexo (%s). |' % PA], 2)
d.add_rows_after('### 7.26 ', 'signatures[]', ['| `signatureRequestId` | ObjectId → T11 `signatureRequests` | No | Pedido de firma de los firmantes. Declarado en T05 (COL-MOR-29); no figuraba en el anexo (%s). |' % PA], 2)

# ---- categoría 1: valores de estado en §7.37
d.set_row(H(3), 'status', '| `status` | enum | Sí | Valores: `active`, `inactive` (§8.15; %s); antes sin valores. | — |' % PA, 1)
d.set_row(H(31), 'status', '| `status` | enum | Sí | Valores: `active`, `suspended`, `inactive` (§8.15; %s); antes sin valores. | — |' % PA, 1)
d.set_row(H(17), 'fromStatus', '| `fromStatus` | enum | No | Valores de `delinquencyNotices.status` (§8.6): `open`, `processed`, `paid`, `excluded`, `inTechnical`, `closed`, `annulled`; nulo en el alta (§8.15; %s); antes sin valores. | — |' % PA, 1)
d.set_row(H(17), 'toStatus', '| `toStatus` | enum | Sí | Mismos valores que `fromStatus` (§8.15; %s); antes sin valores. | — |' % PA, 1)

# ---- categoría 4/6 y comando
d.replace_in_line('`scheduled`: si requiere técnica', '`tec.workOrders.create` (M10)', '`tec.workOrder.request` (M10; antes `tec.workOrders.create`: nombre del comando que emite M09 y consume M10, sin chocar con la capability `tec.ordenes.crear` de T02)', 5)
d.replace_in_line('`int.network.provisioning-result`', '`int.network.provisioning-result` EVT-INT-15 con resultado exitoso', '`int.network.provisioningResult` (antes `int.network.provisioning-result`) EVT-INT-15 con resultado exitoso', 6)
d.replace_in_line('`int.network.provisioning-result`', '`int.network.provisioning-result` EVT-INT-15 con resultado fallido', '`int.network.provisioningResult` (antes `int.network.provisioning-result`) EVT-INT-15 con resultado fallido', 6)
d.replace_in_line('| `int.network.provisioning-result` (EVT-INT-15) |', '| `int.network.provisioning-result` (EVT-INT-15) |', '| `int.network.provisioningResult` (EVT-INT-15; antes `int.network.provisioning-result`) |', 6)
d.replace_in_line('`int.provisioning.succeeded` / `.failed`', '`int.network.provisioning-result`.', '`int.network.provisioningResult` (antes `int.network.provisioning-result`).', 6)
d.replace_in_line('ESC-MOR-48', '`int.network.provisioning-result` exitoso', '`int.network.provisioningResult` (antes `int.network.provisioning-result`) exitoso', 6)

# ---- §7.38 resumen
d.insert_before_heading('## 8. Estados y transiciones', [
    '### 7.38 Residuales del 5-11-2026: referencias, nombres canónicos y valores de estado (%s)' % PA,
    '',
    'Ronda de residuales detectados al regenerar los entregables (categorías 1, 2 y 4 de `_trabajo/residuales-instrucciones.md`). Las filas de §7.37 quedaron corregidas en su lugar con "antes" (las tablas de "referencias declaradas" que se tocaron ganan la columna Tipo); esta tabla las resume. Referencia: colección destino precedida de →; "no es referencia" indica un dato.',
    '',
    '| Colección | Campo | Tipo | Referencia | Antes |',
    '|---|---|---|---|---|',
    '| `interestPolicies` | `base.taxIds`, `base.excludedTaxIds` | ObjectId[] | → M06 `taxDefinitions` | sin destino |',
    '| `interestPolicies` | `fiscal.defaultVatSituationId` | ObjectId | → M06 `vatConditionSettings` | sin destino |',
    '| `interestPolicies` | `publishedVersionId` | ObjectId | → T04 `configVersions` | sin destino |',
    '| `interestPolicies` | `adminFee.amount`, `adminFee.admissibilityRef`, `values.dailyRate` | Decimal128 / string / Decimal128 | No es referencia | sin destino |',
    '| `interestRateTables` | `rates[].rateId` | ObjectId | No es referencia (identificador del tramo) | sin destino |',
    '| `dueDateSurchargeSchemes` | `scope.cycleIds` | ObjectId[] | → M05 `billingCycles` | sin destino |',
    '| `interestCalculations` | `policyVersion` | int | No es referencia (número de versión) | sin destino |',
    '| `interestBillingRunItems` | `chargeRequestId` | ObjectId | → M05 `billableItems` | sin destino |',
    '| `documentHolds` | `reasonId` (usar `holdReasonId`) | ObjectId | → M08 `holdReasons` | `[VERIFICAR]` |',
    '| `delinquencyNotices` | `delinquencyBatchId` | ObjectId | → M08 `delinquencyBatches` | `batchId` |',
    '| `delinquencyNotices` | `noticeModelVersion` | int | No es referencia (número de versión) | sin destino |',
    '| `delinquencyNotices` | `costChargeRequestId` | ObjectId | → M05 `billableItems` | sin destino |',
    '| `delinquencyExceptions` | `reasonText` | string | No es referencia | sin destino |',
    '| `financingInstitutionPlans` | `collectionEntityId` | ObjectId | → M07 `collectionAgencies` | tipo `array` |',
    '| `agreements` | `targetAccountId` | ObjectId | → M01 `accounts` | sin destino |',
    '| `agreements` | `templateId` | ObjectId | → T11 `documentTemplates` | sin destino |',
    '| `agreements` | `planSnapshot` | object | No es referencia | sin destino |',
    '| `agreements` | `signatureRequestId` | ObjectId | → T11 `signatureRequests` | solo en T05 |',
    '| `serviceProtections` | `personSensitiveDataId` | ObjectId | → M01 `personSensitiveData` | solo en T05 |',
    '| `suspensionRestrictionRules` | `code` | string | — (único por tenant) | solo en T05 |',
    '| `debtCollectionAgencies` | `taxId` | string | No es referencia (CUIT) | tipo `ObjectId` |',
    '',
    'Campos que T05 cita con otro nombre (prevalece el anexo; T05 debe reflejarlo): `interestRateTables.policyId` no existe (la relación es `interestPolicies.lateInterest.rateTableId`) y `validFrom` es la vigencia por tramo `rates[].from`; `delinquencyPolicies.scope` = `scope.serviceId` y `scope.categoryIds`; `delinquencyExceptions.accountId`/`contractId` = `scope.accountId`/`scope.contractId`; `serviceProtections.contractId` = `scope.contractId`; `interruptionCases.noticeId` = `origin.noticeId`, `workOrderId` = `execution.workOrderId` y `provisioningCommandId` = `execution.remoteActionIds` (→ M10 `provisioningCommands`, que ejecuta T06; antes "[T06]"); `paymentPlans.financialInstitutionId` corresponde a `financingInstitutionPlans` (COL-MOR-27), no a `paymentPlans`. Valores de estado agregados: `interestIndexTables` (`active`, `inactive`), `debtCollectionAgencies` (`active`, `suspended`, `inactive`) y los de historial de `delinquencyNoticeEvents` (§8.15).',
])
d.replace_in_line('| `execution` | { mode (`technical`/`remote`/`direct`), workOrderId [M10], remoteActionIds [T06]', 'remoteActionIds [T06]', 'remoteActionIds [M10 `provisioningCommands`; antes "[T06]"; %s]' % PA, 2)

# ---- §8.15
rows = []
def r(c, f, t, trig, g='—', e='—'):
    rows.append('| `%s` | %s | %s | %s | %s | %s |' % (c, f, t, trig, g, e))
N = '(nuevo)'
r('interestPolicies', N, '`draft`', 'Configurador crea una versión (vale para las colecciones de la máquina común de §8.1)')
r('interestIndexTables', N, '`active`', 'Alta de la tabla de índice propio por el configurador', '`code` no repetido')
r('interestIndexTables', '`active`', '`inactive`', 'Baja por el configurador', 'Ninguna política vigente la usa; no se borra (T05 §7.1.5)')
r('interestIndexTables', '`inactive`', '`active`', 'Reactivación por el configurador')
r('interestBillingRunItems', N, '`preview`', 'Corrida en `previewing` (§8.4) calcula el ítem')
r('interestBillingRunItems', '`preview`', '`excluded`', 'Operador desmarca el ítem (`selected = false`)', 'Corrida en `previewed`')
r('interestBillingRunItems', '`excluded`', '`preview`', 'Operador vuelve a marcar el ítem', 'Corrida en `previewed`')
r('interestBillingRunItems', '`preview`', '`charged`', 'Corrida en `generating` crea el cargo en M05 (`chargeRequestId`)', 'Ítem seleccionado', '`mor.interestRun.completed` al terminar la corrida')
r('interestBillingRunItems', '`preview`', '`failed`', 'Error al crear el cargo', '—', '— (`error` registrado)')
r('interestBillingRunItems', '`failed`', '`charged`', 'Reintento idempotente de la corrida', '—')
r('documentHolds', N, '`active`', 'Bloqueo manual, de notificación, de orden de cambio de estado, de expediente o de sistema (`origin`)', 'Causa `holdReasonId` activa')
r('guarantees', N, '`requested`', 'Alta de la garantía exigida por el convenio, el contrato o la regla (`requirementRuleId`)')
r('guarantees', '`active`', '`released`', 'Liberación sin uso al cumplirse la obligación garantizada', 'Sin incumplimiento')
r('guarantees', '`active`', '`refunded`', 'Devolución del depósito en garantía (`liquidation.refundMode`)', 'Obligación garantizada cumplida; garantía de tipo `securityDeposit`')
r('guarantees', '`active`', '`expired`', 'Job de vencimientos', '`validTo` cumplido sin incumplimiento')
r('guarantees', '`executed`', '`applied`', 'Aplicación del importe a la deuda', 'Incumplimiento con causa', '—')
r('guarantees', '`applied`', '`refunded`', 'Devolución del remanente', '`liquidation.refundAmount` mayor que cero')
r('collectionCases', N, '`open`', 'Asignación de documentos a un estudio o agencia (`debtCollectionAgencyId`)')
r('debtCollectionAgencies', N, '`active`', 'Alta del estudio o agencia', 'Proveedor (`supplierId`) registrado en M12')
r('debtCollectionAgencies', '`active`', '`suspended`', 'Supervisor de recupero suspende nuevas asignaciones', 'Motivo registrado')
r('debtCollectionAgencies', '`suspended`', '`active`', 'Supervisor de recupero rehabilita')
r('debtCollectionAgencies', '`active` · `suspended`', '`inactive`', 'Baja', 'Sin expedientes abiertos asignados')
r('debtCollectionAgencies', '`inactive`', '`active`', 'Reactivación')
for c in ('holdReasons', 'delinquencyStages', 'delinquencyReasons', 'financingInstitutionPlans'):
    r(c, N, '`active`', 'Alta por el configurador', 'Validación del esquema (T04 §8.3)')
    r(c, '`active`', '`inactive`', 'Baja por el configurador', 'Si está referenciado se informa el conteo; no se borra (T05 §7.1.5)')
    r(c, '`inactive`', '`active`', 'Reactivación por el configurador')
r('delinquencyNoticeModels', N, '`draft`', 'Configurador crea una versión del modelo')
r('delinquencyNoticeModels', '`draft`', '`published`', 'Configurador publica', 'Plantilla validada; publicada queda inmutable (T05 §7.1.5)')
r('delinquencyNoticeModels', '`published`', '`retired`', 'Sistema al publicar la versión sucesora', 'Existe versión sucesora')
d.insert_before_heading('## 9. Procesos y flujos', [
    '### 8.15 Máquinas completadas y altas explícitas (residuales del 5-11-2026, %s)' % PA,
    '',
    'Completa las colecciones que los entregables marcaron sin valores (`interestIndexTables`, `debtCollectionAgencies`, `delinquencyNoticeEvents`), con estados sin transiciones (`interestBillingRunItems`), con patrón general sin tabla (`holdReasons`, `delinquencyStages`, `delinquencyReasons`, `financingInstitutionPlans`, `delinquencyNoticeModels`), las máquinas que decían el estado inicial solo en texto (§8.1, §8.5, §8.9, §8.10) y la garantía, cuyo §8.9 no daba origen a `released`, `refunded` y `expired` (INC-06-03). Las filas `(nuevo)` fijan el estado inicial. Valores asumidos en %s (DEC-072); coinciden con §7.37.' % PA,
    '',
    '`delinquencyNoticeEvents` es el historial inmutable de `delinquencyNotices`: cada documento se escribe con su estado final y no cambia; `fromStatus` y `toStatus` toman los valores de `delinquencyNotices.status` (§8.6) y no forman una máquina propia.',
    '',
    '| Colección | Desde | Hacia | Disparador | Guarda | Evento |',
    '|---|---|---|---|---|---|',
] + rows)
d.count(1, len(rows) + 1)

# ---- PA
d.insert_before_heading('## 22. Trazabilidad de fuentes', [
    '### %s — Residuales de los entregables: referencias, nombres canónicos, estados y alias (5-11-2026)' % PA,
    '- **Pregunta**: ¿Qué destino tienen las referencias que los entregables marcaron sin colección en M08 (§7.38), qué nombres se adoptan (`delinquencyBatchId`, `holdReasonId`), qué campos de T05 se incorporan (`personSensitiveDataId`, `signatureRequestId`, `code`), qué valores y transiciones tienen `interestIndexTables`, `debtCollectionAgencies`, `interestBillingRunItems` y las garantías, y cómo se nombran el evento `int.network.provisioning-result` y el comando de OT que M08 pide a M10?',
    '- **Contexto**: residuales de `docs/entregables-analisis-diseno/03-er/M08-MOR-mora-financiacion.md` §7, de `06a-indice-cobertura-secuencias-estados.md` §7 (INC-06-01, 02, 03, 08, 11) y de `_trabajo/correccion-inconsistencias-pendientes-cierre.md` (`delinquencyNotices.batchId`).',
    '- **Opciones**: A) **(Recomendada)** Destinos de §7.38 (T05 §7.2.1 cuando existe; `configVersions` de T04 para la versión publicada; `billingCycles` para los ciclos; `billableItems` para los pedidos de cargo), campos de T05 incorporados, máquinas de §8.15, evento `int.network.provisioningResult` (regla de guiones a camelCase; alias `int.network.provisioning-result`) y comando `tec.workOrder.request` (el que emite M09). B) Mantener `[VERIFICAR]` y los nombres anteriores.',
    '- **Impacto si no se responde**: A.',
    '- **Bloquea**: diagrama ER y diagramas de estados de M08; T05 COL-MOR-02, 13, 19, 20, 21, 24, 26, 29 y §7.2.1; alias de T11 §12.4.',
    '- **Estado**: Asumida (DEC-072): opción A. Aplicado en §7.37 (filas corregidas con "antes"), §7.17, §7.18, §7.26, §7.38, §8.15, §9 y §12. T05 debe reflejar las equivalencias de §7.38 (subcampos `scope.*`, `origin.noticeId`, `execution.*`; `policyId`/`validFrom` de COL-MOR-02; `financialInstitutionId` en COL-MOR-27) y en §7.2.1 `planSnapshot`, `noticeModelVersion`, `policyVersion`, `rates[].rateId` y `adminFee.*` como "no es referencia". T11 debe registrar el alias `int.network.provisioning-result` → `int.network.provisioningResult` en §12.4.',
    '',
])
d.count(9, 1)
d.save()
report()
