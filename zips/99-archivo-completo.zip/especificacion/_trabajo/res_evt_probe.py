import re, glob
pats = ['T01-*', 'T02-*', 'T03-*', 'T04*', 'T06-*', 'T07-*', 'T08-*', 'T10-*', 'T12-*']
files = [f for p in pats for f in glob.glob('../anexos/' + p + '.md')]
TOK = re.compile(r'`([a-z]{2,4}(?:\.[A-Za-z0-9-]+){2,4})`')
old6 = set()
for f in files:
    t = open(f, encoding='utf-8-sig').read()
    for i, l in enumerate(t.split('\n'), 1):
        if not l.startswith('| EVT-'):
            continue
        cells = l.split(' | ')
        for m in TOK.finditer(cells[1] if len(cells) > 1 else ''):
            tok = m.group(1)
            segs = tok.split('.')
            if len(segs) != 3 or '-' in tok:
                print(f[11:30], i, tok)
# citas de los nombres viejos de T06 en otros archivos
t06 = open(glob.glob('../anexos/T06-*.md')[0], encoding='utf-8-sig').read()
olds = set(re.findall(r'antes `(int\.[a-z-]+\.[a-z-]+)`', t06))
for f in files + glob.glob('../00-*.md') + glob.glob('../03-*.md'):
    if 'T06-' in f:
        continue
    t = open(f, encoding='utf-8-sig').read()
    for o in olds:
        for m in re.finditer(re.escape(o) + r'(?![A-Za-z0-9-])', t):
            ln = t.count('\n', 0, m.start()) + 1
            print('CITA', f[11:40], ln, o)
