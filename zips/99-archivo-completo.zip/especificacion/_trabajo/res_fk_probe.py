import json, re
m = json.load(open(r'c:\Users\lenovo\Documents\GACAC\docs\especificacion\_trabajo\res_er_model.json', encoding='utf-8'))
mine = ('T01', 'T02', 'T03', 'T04', 'T06', 'T07', 'T08', 'T10')
for n, e in m.items():
    if e['owner'] not in mine:
        continue
    for f, d in e['fields'].items():
        if 'fk' in d and not d['fk'] and d.get('fkhow') not in ('poly', 'user', 'self', 'noFK'):
            print(e['owner'], n, f, d.get('fkhow'), '|', (d.get('desc') or '')[:90])
