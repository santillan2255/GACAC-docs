import re, os, json, glob, sys
sys.stdout.reconfigure(encoding='utf-8')
B = r'c:\Users\lenovo\Documents\GACAC\docs\especificacion'
A = os.path.join(B, 'anexos')
T02 = open(os.path.join(A, 'T02-IAM-identidad-roles-auditoria.md'), encoding='utf-8').read().split('\n')
CAPRE = re.compile(r'`([a-z]{3}\.[A-Za-z0-9.]+)`')

reg = set()
for i, l in enumerate(T02, 1):
    if (221 <= i < 794 or 918 <= i < 2622) and l.startswith('| `'):
        m = CAPRE.match(l[2:])
        if m:
            reg.add(m.group(1))
alias = {}
for i, l in enumerate(T02, 1):
    if 794 <= i < 918 and l.startswith('| `'):
        c = [x.strip() for x in l.split('|')]
        a, b = CAPRE.findall(c[1]), CAPRE.findall(c[2])
        if a and b:
            alias[a[0]] = b[0]
r443 = {}
for i, l in enumerate(T02, 1):
    if 2622 <= i < 2861 and l.startswith('| '):
        c = [x.strip() for x in l.split('|')]
        if len(c) > 4:
            a = re.findall(r'`([^`]+)`', c[2]); b = re.findall(r'`([^`]+)`', c[3])
            if a and b:
                r443[a[0]] = (b[0], c[3])
print('registradas', len(reg), 'alias', len(alias), '443', len(r443))

pan = {}
for f in glob.glob(os.path.join(A, '*.md')):
    for l in open(f, encoding='utf-8-sig').read().split('\n'):
        m = re.match(r'\| (PAN-[A-Z]{3}-\d+) \|', l)
        if m and m.group(1) not in pan:
            c = l.split('|')
            pan[m.group(1)] = (os.path.basename(f)[:3], c[3].strip() if len(c) > 4 else '', c[4].strip() if len(c) > 4 else '', l)

miss = [x.strip() for x in open(os.path.join(B, '_trabajo', 't02r4_t03_sin_registro.txt'), encoding='utf-8') if x.strip()]
T03 = open(os.path.join(A, 'T03-UXD-experiencia-marca-diccionario.md'), encoding='utf-8').read().split('\n')
out = {}
for cap in miss:
    occ = []
    pat = re.compile(r'(?<!antes )`' + re.escape(cap) + r'`')
    for i, l in enumerate(T03, 1):
        if pat.search(l):
            c = [x.strip() for x in l.split('|')]
            pans = re.findall(r'\b([A-Z]{3})-(\d+)\b', ' '.join(c[1:4]))
            cand = []
            for m, n in pans:
                p = pan.get(f'PAN-{m}-{n}')
                if p:
                    for k in CAPRE.findall(p[2]) + CAPRE.findall(p[1]):
                        if k in reg and k not in cand:
                            cand.append(k)
            occ.append((i, c[1] if len(c) > 1 else '', ' | '.join(c[2:5])[:200], cand))
    mod, res = cap.split('.')[0], cap.split('.')[1]
    same = sorted(k for k in reg if k.startswith(f'{mod}.{res}.'))
    out[cap] = dict(occ=occ, same=same, alias=alias.get(cap), r443=r443.get(cap, [None])[0])
json.dump(out, open(os.path.join(B, '_trabajo', 'g_r3_analisis.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
with open(os.path.join(B, '_trabajo', 'g_r3_analisis.txt'), 'w', encoding='utf-8') as f:
    for cap, d in out.items():
        f.write(f"## {cap} alias={d['alias']} 443={d['r443']} mismo={d['same']}\n")
        for o in d['occ']:
            f.write(f"   L{o[0]} {o[1]} | {o[2]} -> {o[3]}\n")
json.dump(dict(reg=sorted(reg), r443={k: v[0] for k, v in r443.items()}), open(os.path.join(B, '_trabajo', 'g_r3_t02.json'), 'w', encoding='utf-8'), ensure_ascii=False)
