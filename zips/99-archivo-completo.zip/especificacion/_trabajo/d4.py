﻿import glob, json
from conc_lib import *
def ed(p, pairs):
    s = read(p)
    for o, n, e in pairs:
        assert s.count(o) == e, (p, o, s.count(o)); s = s.replace(o, n)
    write(p, s); print(os.path.basename(p), len(pairs))
p1 = glob.glob(os.path.join(ANX, 'T12-*parte1.md'))[0]
p2 = glob.glob(os.path.join(ANX, 'T12-*parte2.md'))[0]
ed(p1, [('JOB-TEC-09 `tec:importar-cdr`; EVT-TEC-27 `tec.cdr.attributed`; JOB-INT-23 `int:importar-cdr`;', 'JOB-TEC-09 `tec:importar-cdr`; EVT-TEC-27 `tec.cdr.attributed`; JOB-INT-23 `int:recibir-cdr`;', 1),
        ('| Jobs | JOB-INT-23 `int:importar-cdr`; JOB-TEC-09', '| Jobs | JOB-INT-23 `int:recibir-cdr`; JOB-TEC-09', 1)])
ed(p2, [('(M02, fin de cuotas de obra → JOB-CAT-12; M02 usa el alias `fac.cycle.closed`).', '(M02, fin de cuotas de obra → JOB-CAT-12).', 1)])
