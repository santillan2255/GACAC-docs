﻿import re,os
from conc_lib import *
ids=['CAT-26','CAT-27','FAC-21','FIS-22','FIS-23','COB-24','COB-25','COB-26','COB-27','TEC-32','TEC-33','TEC-34','VEN-15','CMP-15','STK-23','STK-24','TES-23','SUE-27','PLA-21','PLA-22','SOC-17']
for f in files():
    if 'T11' in f: continue
    for i,l in enumerate(read(f).split('\n'),1):
        for x in ids:
            if re.match(r'\|\s*(\*\*)?EVT-'+x+r'\b',l): print(os.path.basename(f)[:3],i,l)
L=read(T11).split('\n')
for n in (2323,2321,2312,2052,2051):
    print('T11',n,L[n-1])
print([l for l in L if l.startswith('| EVT-TAR-012') or l.startswith('| EVT-STK-07')])
