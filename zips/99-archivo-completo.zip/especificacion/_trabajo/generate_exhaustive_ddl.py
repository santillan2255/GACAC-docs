#!/usr/bin/env python3
"""
Genera DDL ejecutable (capa C) para ~1.058 tablas:
- pla: scripts manuales/generate_pla_sql.py (no sobrescribe)
- resto: campos parseados de §7 anexos dueños + convenciones T05
"""
from __future__ import annotations

import importlib.util
import re
import sys
from collections import defaultdict
from datetime import date
from pathlib import Path

ESPEC = Path(__file__).resolve().parents[1]
ANEXOS = ESPEC / "anexos"
T05 = ANEXOS / "T05-DAT-modelo-datos.md"
DDL_ROOT = ESPEC / "07-ddl" / "sql"
MANIFEST = ESPEC / "07-ddl" / "MANIFEST.md"

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ddl_type_map import mongo_field_to_sql  # noqa: E402
from generate_07_catalog_from_t05 import (  # noqa: E402
    PREFIX_SCHEMA,
    ROW_RE,
    collection_to_table,
    parse_t05,
    pk_name,
    tenant_column,
)

COLL_NAME = r"[a-z][a-zA-Z0-9_]*"
HEADER_RE = re.compile(
    rf"^#{{3,4}}\s+.*?[`']({COLL_NAME})[`']"
)
BOLD_HDR = re.compile(rf"\*\*[`']({COLL_NAME})[`']\*\*")
COLLECTION_BT = re.compile(rf"[`']({COLL_NAME})[`']")
ALT_HDR = re.compile(
    r"[`']([a-z][a-zA-Z0-9]*)[`']\s*—\s*tabla de campos",
    re.I,
)
SUBSEC_HDR = re.compile(rf"^####\s+[`']({COLL_NAME})[`']")
CAMPO_DE = re.compile(rf"Campos de\s+[`']({COLL_NAME})[`']", re.I)
PROSE_CAMPOS = re.compile(
    rf"^Campos:\s*(.+)$", re.I
)
INLINE_COL = re.compile(rf"^`({COLL_NAME})`:\s*(.+)")
BACKTICK_PAREN_COL = re.compile(rf"^`({COLL_NAME})`\s*\([^)]*\):\s*(.+)")
FIELD_HDR = re.compile(r"^\|\s*Campo\s*\|\s*Tipo\s*\|")
FIELD_ROW = re.compile(r"^\|\s*`([^`]+)`\s*\|\s*([^|]+)")

SKIP_SECTION = re.compile(
    r"subdocumento|Subdocumento|^#{3,4}\s+7\.\d+\.\d+\s+[^`]",
    re.I,
)

AUDIT_COLS = [
    ("CreatedAt", "DATETIME2(7)", False, "SYSUTCDATETIME()"),
    ("CreatedBy", "UNIQUEIDENTIFIER", True, None),
    ("UpdatedAt", "DATETIME2(7)", False, "SYSUTCDATETIME()"),
    ("UpdatedBy", "UNIQUEIDENTIFIER", True, None),
    ("RowVersion", "ROWVERSION", False, None),
]

LEGACY_JSON = ("LegacyJson", "NVARCHAR(MAX)", True, None)


def resolve_anexo(owner: str) -> Path | None:
    owner = owner.strip().split()[0]
    m = re.match(r"(M\d+|T\d+)", owner)
    if not m:
        return None
    code = m.group(1)
    hits = sorted(ANEXOS.glob(f"{code}-*.md"))
    return hits[0] if hits else None


def parse_collection_fields(path: Path) -> dict[str, list[tuple[str, str, str]]]:
    """collection -> [(field, type, oblig)]"""
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    out: dict[str, list] = defaultdict(list)
    current: str | None = None
    in_table = False

    for i, line in enumerate(lines):
        if line.strip().startswith("####") and "subdocumento" in line.lower():
            current = None
            in_table = False
            continue
        stripped = line.strip()
        bm = BOLD_HDR.search(line)
        if bm and (
            stripped.startswith("**`")
            or "—" in line
            or "(COL-" in line
        ):
            found_bold = BOLD_HDR.findall(line)
            for coll in found_bold:
                out.setdefault(coll, [])
            current = found_bold[0] if found_bold else bm.group(1)
            in_table = False
            if stripped.startswith("**`") and ":" in stripped:
                tail = stripped.split("**", 2)[-1]
                for field in re.findall(r"`([^`]+)`", tail):
                    field = field.split("(")[0].strip().replace("[]", "")
                    if field and field != "tenantId":
                        out[current].append((field, "string", "No"))
            continue
        m = HEADER_RE.match(line)
        am = ALT_HDR.search(line)
        if m and re.search(r"\b7\.", line):
            found = COLLECTION_BT.findall(line)
            if found:
                current = found[0]
                in_table = False
                continue
        if am and "campos de" in line.lower():
            current = am.group(1)
            in_table = False
            continue
        sm = SUBSEC_HDR.match(line)
        if sm:
            current = sm.group(1)
            in_table = False
            continue
        cm = CAMPO_DE.search(line)
        if cm:
            current = cm.group(1)
            in_table = False
            continue
        pm = PROSE_CAMPOS.match(line.strip())
        if current and pm:
            blob = pm.group(1)
            for field in re.findall(r"`([^`]+)`", blob):
                field = field.split("(")[0].strip().replace("[]", "")
                if field and field != "tenantId":
                    out[current].append((field, "string", "No"))
            in_table = False
            continue
        if (
            current
            and "campos:" in line.lower()
            and "`" in line
            and not line.strip().startswith("|")
        ):
            for field in re.findall(r"`([^`]+)`", line):
                field = field.split("(")[0].strip().replace("[]", "")
                if field and field != "tenantId":
                    out[current].append((field, "string", "No"))
            continue
        im = INLINE_COL.match(stripped) or BACKTICK_PAREN_COL.match(stripped)
        if im:
            current = im.group(1)
            in_table = False
            for field in re.findall(r"`([^`]+)`", im.group(2)):
                field = field.split("(")[0].strip().replace("[]", "")
                if field and field != "tenantId":
                    out[current].append((field, "string", "No"))
            continue
        if current and FIELD_HDR.match(line):
            in_table = True
            continue
        if not in_table or not current:
            continue
        if not line.startswith("|") or line.startswith("|---"):
            if line.strip() == "":
                in_table = False
            continue
        fm = FIELD_ROW.match(line)
        if not fm:
            continue
        field_cell, typ = fm.group(1), fm.group(2).strip()
        fields = re.findall(r"`([^`]+)`", field_cell)
        if not fields:
            fields = [field_cell.strip()]
        parts = [p.strip() for p in line.split("|")]
        oblig = "No"
        for p in parts[2:5]:
            pl = p.lower()
            if pl.startswith(("sí", "si")):
                oblig = "Sí"
                break
            if pl.startswith("no"):
                oblig = "No"
                break
        for field in fields:
            field = field.replace("[]", "").strip()
            if not field or field.startswith("_"):
                continue
            out[current].append((field, typ, oblig))
    return out


_MEGA_CACHE: dict[str, list[tuple[str, str, str]]] | None = None


def load_mega_field_cache() -> dict[str, list[tuple[str, str, str]]]:
    out: dict[str, list] = {}
    for path in sorted(ANEXOS.glob("[MT]*.md")):
        if "backup-sync" in path.parts:
            continue
        parsed = parse_collection_fields(path)
        for coll, fields in parsed.items():
            if coll not in out or len(fields) > len(out[coll]):
                out[coll] = fields
    return out


INHERIT_FIELDS: dict[str, tuple[str, list[tuple[str, str, str]]]] = {
    "simulatedJournalLines": (
        "journalLines",
        [
            ("scenarioId", "ObjectId", "Sí"),
            ("simulatedEntryKey", "string", "No"),
            ("originRealLineId", "ObjectId", "No"),
        ],
    ),
}


def fields_for_collection(owner: str, collection: str) -> list[tuple[str, str, str]]:
    global _MEGA_CACHE
    if _MEGA_CACHE is None:
        _MEGA_CACHE = load_mega_field_cache()
    if collection in _MEGA_CACHE and _MEGA_CACHE[collection]:
        return _MEGA_CACHE[collection]
    if collection in INHERIT_FIELDS:
        parent, extras = INHERIT_FIELDS[collection]
        base = fields_for_collection(owner, parent)
        seen = {f[0] for f in base}
        merged = list(base)
        for row in extras:
            if row[0] not in seen:
                merged.append(row)
        return merged
    path = resolve_anexo(owner)
    if not path:
        return []
    return parse_collection_fields(path).get(collection, [])


def needs_tenant(alc: str, tenant_str: str) -> bool:
    a = alc.strip().split("|")[0].split()[0].strip()
    if a == "G":
        return False
    if "No (global)" in tenant_str or tenant_str.strip().startswith("No"):
        return False
    if a == "P":
        return "Sí" in tenant_str
    return "Sí" in tenant_str or a.startswith("T")


def build_columns(
    table: str, collection: str, owner: str, alc: str, tenant_str: str
) -> tuple[list[tuple], str, bool]:
    pk = pk_name(table)
    cols: list[tuple] = []
    seen: set[str] = set()

    def add(col: str, sql_type: str, nullable: bool, default=None):
        if col in seen:
            return
        seen.add(col)
        cols.append((col, sql_type, nullable, default))

    add(pk, "UNIQUEIDENTIFIER", False, None)

    with_tenant = needs_tenant(alc, tenant_str)
    if with_tenant:
        add("TenantId", "UNIQUEIDENTIFIER", False, None)

    parsed = fields_for_collection(owner, collection)
    parsed_count = 0
    for field, typ, oblig in parsed:
        mapped = mongo_field_to_sql(field, typ)
        if not mapped:
            continue
        col, sql_type, _default_null = mapped
        oblig_sí = oblig.lower().startswith("sí") or oblig.lower() == "si"
        nullable = not oblig_sí
        # PK dedupe
        if col == pk:
            continue
        if col == "TenantId":
            if with_tenant:
                continue
            continue
        add(col, sql_type, nullable, None)
        parsed_count += 1

    add(*LEGACY_JSON)

    if parsed_count == 0:
        add("SpecificationNote", "NVARCHAR(512)", True, None)

    for a in AUDIT_COLS:
        if a[0] not in seen:
            add(*a)

    source = "anexo" if parsed_count else "fallback"
    return cols, source, with_tenant


def render_create(schema: str, table: str, cols: list, with_tenant: bool) -> str:
    pk = pk_name(table)
    lines = [
        f"-- {schema}.{table} — generado generate_exhaustive_ddl.py ({date.today()})",
        "",
        f"IF OBJECT_ID(N'{schema}.{table}', N'U') IS NULL",
        "BEGIN",
        f"    CREATE TABLE [{schema}].[{table}] (",
    ]
    parts = []
    for c in cols:
        name, sql_type, nullable, default = c
        if sql_type == "ROWVERSION":
            parts.append(f"        [{name}] {sql_type} NOT NULL")
            continue
        null = " NULL" if nullable else " NOT NULL"
        part = f"        [{name}] {sql_type}{null}"
        if default is not None:
            df = f"DF_{schema}_{table}_{name}"
            part += f"\n            CONSTRAINT [{df}] DEFAULT ({default})"
        parts.append(part)
    parts.append(f"        CONSTRAINT [PK_{schema}_{table}] PRIMARY KEY ([{pk}])")
    if with_tenant and schema != "pla":
        parts.append(
            f"        CONSTRAINT [FK_{schema}_{table}_Tenants] "
            f"FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])"
        )
    lines.append(",\n".join(parts))
    lines.append("    );")
    if with_tenant:
        lines.append(
            f"    CREATE INDEX [IX_{schema}_{table}_Tenant] "
            f"ON [{schema}].[{table}] ([TenantId]);"
        )
    lines.append("END;")
    lines.append("GO")
    return "\n".join(lines)


def load_pla_tables() -> set[str]:
    """Tablas pla ya definidas en generate_pla_sql."""
    spec_path = Path(__file__).resolve().parent / "generate_pla_sql.py"
    spec = importlib.util.spec_from_file_location("generate_pla_sql", spec_path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(mod)
    return {t["name"] for t in mod.TABLES}


def main() -> None:
    global _MEGA_CACHE
    _MEGA_CACHE = load_mega_field_cache()
    rows = parse_t05()
    pla_skip = load_pla_tables()
    stats = defaultdict(int)
    deploy_lines = [
        "-- CoopApps — despliegue completo (capa C)",
        "-- 1) pla: generate_pla_sql.py  2) resto: generate_exhaustive_ddl.py",
        "",
        ":r sql/000-all-schemas.sql",
        ":r sql/pla/deploy-all.sql",
        "",
    ]

    # schemas
    schemas = sorted({r["schema"] for r in rows if "A→" not in r["est"]})
    schema_sql = ["-- Esquemas de módulo", ""]
    for s in schemas:
        schema_sql.append(
            f"IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'{s}')\n"
            f"    EXEC(N'CREATE SCHEMA [{s}] AUTHORIZATION [dbo];');\nGO\n"
        )
    (DDL_ROOT / "000-all-schemas.sql").write_text("\n".join(schema_sql), encoding="utf-8")

    by_schema: dict[str, list] = defaultdict(list)
    for r in rows:
        if "A→" in r["est"]:
            stats["absorbed"] += 1
            continue
        by_schema[r["schema"]].append(r)

    for schema in sorted(by_schema.keys()):
        if schema == "pla":
            continue
        out_dir = DDL_ROOT / schema
        out_dir.mkdir(parents=True, exist_ok=True)
        deploy_schema = [f"-- Esquema {schema}", ""]
        group = sorted(by_schema[schema], key=lambda x: x["col_id"])
        for idx, r in enumerate(group, 1):
            table = r["table"]
            cols, source, with_tenant = build_columns(
                table, r["collection"], r["owner"], r["alc"], r["tenant"]
            )
            fname = f"{idx:04d}-{schema}.{table}.sql"
            sql = render_create(schema, table, cols, with_tenant)
            (out_dir / fname).write_text(sql + "\n", encoding="utf-8")
            stats[source] += 1
            deploy_schema.append(f":r {schema}/{fname}")
        deploy_schema.append("")
        (out_dir / "deploy-all.sql").write_text("\n".join(deploy_schema), encoding="utf-8")
        deploy_lines.append(f":r sql/{schema}/deploy-all.sql")

    stats["pla_manual"] = len(pla_skip)

    manifest = [
        f"# MANIFEST DDL — {date.today().strftime('%d-%m-%Y')}",
        "",
        "| Métrica | Valor |",
        "|---|---|",
        f"| Tablas generadas (no pla) | {stats['anexo'] + stats['fallback']} |",
        f"| Con campos desde anexo §7 | {stats['anexo']} |",
        f"| Fallback (solo PK+tenant+legacy+audit) | {stats['fallback']} |",
        f"| Absorbidas (sin SQL) | {stats['absorbed']} |",
        f"| pla (generate_pla_sql.py) | {stats['pla_manual']} |",
        f"| Colecciones en caché §7 (mega) | {len(_MEGA_CACHE or {})} |",
        "",
        "## Regenerar",
        "",
        "```text",
        "python docs/especificacion/_trabajo/generate_pla_sql.py",
        "python docs/especificacion/_trabajo/generate_exhaustive_ddl.py",
        "python docs/especificacion/_trabajo/validate_ddl_quality.py",
        "```",
        "",
        "## Despliegue",
        "",
        "```text",
        "sqlcmd ... -i docs/especificacion/07-ddl/deploy-coopapps-full.sql",
        "```",
    ]
    MANIFEST.write_text("\n".join(manifest), encoding="utf-8")
    (ESPEC / "07-ddl" / "deploy-coopapps-full.sql").write_text(
        "\n".join(deploy_lines), encoding="utf-8"
    )
    print(
        f"Done. anexo={stats['anexo']} fallback={stats['fallback']} "
        f"schemas={len(by_schema)}"
    )


if __name__ == "__main__":
    main()