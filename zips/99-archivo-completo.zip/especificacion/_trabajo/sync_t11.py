from sync_lib import Doc

d = Doc('T11-*.md')

d.rep('| EVT-STK-12 | `stk.item.belowMinimum` |',
      '| EVT-STK-12 | `stk.item.belowMinimum` (antes `stk.item.below-minimum`; M13 PA-STK-11) |', 'evento')

d.rep('| EVT-CRM-13 | `crm.commandRequest.requested` | `commandRequestId`, `caseId`, `targetModule`, `command`, `params` |',
      '| EVT-CRM-13 | `crm.commandRequest.requested` | `commandRequestId`, `caseId`, `targetModule`, `command` (código del comando de M09 §7, p. ej. `tec.workOrder.request`, antes `tec.workOrder.create`, M10 PA-TEC-23; `tec.workOrder.create` queda solo como alias de la capability `tec.ordenes.crear` de T02), `params` |',
      'evento')

old = d.line('| `int.ai.completion-ready` | T06 (productor), T09 |')
d.after_line(old, [
    '| `stk.item.below-minimum` | M13 (productor), M12, T09 | `stk.item.belowMinimum` (EVT-STK-12) | Alias (5-11-2026, PA-WFL-24, Asumida DEC-072): renombrado por la convención `<mod>.<agregado>.<hecho>` (INC-06-11; guiones a camelCase) en M13 RF-STK-029 (PA-STK-11). El productor y los consumidores deben adoptar el nombre nuevo |'
], 'alias')

d.rep('| Filas de conciliación en §12.4 | 203, una por canónico (5-11-2026, residuales:',
      '| Filas de conciliación en §12.4 | 204, una por canónico (5-11-2026, sincronización posterior a los residuales: suma el alias `stk.item.below-minimum` → EVT-STK-12, PA-WFL-24; antes 203. 5-11-2026, residuales:',
      'totales')

pa = '''### PA-WFL-24 - Sincronización posterior a la ronda de residuales: alias de M13 y comando de OT en EVT-CRM-13

- **Pregunta:** ¿qué falta en el catálogo de eventos después de la ronda de residuales de los anexos de módulo (`_trabajo/residuales-sincronizacion.md`)?
- **Contexto:** se verificó §12.3 y §12.4 contra los anexos dueños: los 27 tipos renombrados por T06 (PA-INT-27), los 8 de M17 (PA-INS-13) y los alias de M06 (`int.arca.params-synced`, PA-FIS-22), M08 (`int.network.provisioning-result`, PA-MOR-22) y M10 (`int.cdr.batch-received`, PA-TEC-23) ya estaban registrados con un solo canónico. Faltaban el alias `stk.item.below-minimum` de M13 (PA-STK-11; §12.3 ya usaba `stk.item.belowMinimum`) y el comando `tec.workOrder.request` (antes `tec.workOrder.create`) en el payload de EVT-CRM-13 (M10 PA-TEC-23).
- **Opciones:**
  - A) Agregar la fila de alias en §12.4, citar el nombre anterior en EVT-STK-12, nombrar el comando en el campo `command` de EVT-CRM-13 y actualizar §12.10. **(Recomendada)**.
  - B) No registrar el alias porque §12.3 ya tenía el nombre nuevo - el chequeo de CI (CTR-WFL-03) rechazaría a un consumidor que todavía use el nombre con guion.
- **Impacto si no se responde:** se asume A.
- **Bloquea:** §12.3 (EVT-STK-12, EVT-CRM-13), §12.4 y §12.10.
- **Estado:** **Asumida (DEC-072)**, opción A. Aplicada el 5-11-2026: §12.4 pasa a 204 filas (36 alias de eventos renombrados por INC-06-11); cada alias sigue con un solo canónico. Los comandos no son tipos de evento: `tec.workOrder.request` no se registra en `eventTypes.aliases`. Ya no bloquea.
'''
marker = '  - CU-ARQ-01 queda con dueño T11 (decisión del coordinador del 5-11-2026); T01 renumera el suyo.\n  - Ya no bloquea.\n'
d.rep(marker, marker + '\n' + pa, 'PA')
d.save()
