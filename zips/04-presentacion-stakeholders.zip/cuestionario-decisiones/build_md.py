#!/usr/bin/env python3
"""
Genera la COPIA de trabajo `copia-respuestas-stakeholder.md` leyendo solo los anexos.

Nunca escribe en docs/especificacion/ (02-preguntas-abiertas.md, anexos, etc.).
Si la copia ya existe, conserva Opción elegida / Ampliación / Respondido al refrescar textos.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ANEXOS = ROOT / "especificacion" / "anexos"
INDEX_02 = ROOT / "especificacion" / "02-preguntas-abiertas.md"
# Único archivo que este script puede crear o sobrescribir (salvo exportaciones manuales)
OUT = HERE / "copia-respuestas-stakeholder.md"
INDICE_JSON = HERE / "indice-02.json"
LEGACY_OUT = HERE / "preguntas-respuestas.md"

SKIP_PARTS = ("backup", "OLD", "backup-sync")

HEADER = """# Copia de trabajo — respuestas del stakeholder

> **No es** `docs/especificacion/02-preguntas-abiertas.md` ni el registro de decisiones oficial.
> Se genera leyendo los anexos; las respuestas viven **solo en este archivo** (y en tus exportaciones).
> Regenerar: `python build_md.py` (mantiene tus respuestas ya cargadas en esta copia).

"""

RESPONSE_LINES = (
    "- **Opción elegida:** —\n"
    "- **Ampliación:** —\n"
    "- **Respondido:** —\n"
)

PA_START = re.compile(
    r"^### (PA-[A-Z0-9]+(?:-[A-Z0-9]+)*) — (.+)$",
    re.MULTILINE,
)

FIELD_ELEGIDA = re.compile(r"(\- \*\*Opción elegida:\*\*)\s*.+", re.IGNORECASE)
FIELD_AMP = re.compile(r"(\- \*\*Ampliación:\*\*)\s*.+", re.IGNORECASE)
FIELD_FECHA = re.compile(r"(\- \*\*Respondido:\*\*)\s*.+", re.IGNORECASE)


def assert_out_safe(path: Path) -> None:
    path = path.resolve()
    spec = (ROOT / "especificacion").resolve()
    if path == spec or spec in path.parents:
        print("ERROR: la salida no puede estar dentro de especificacion/", file=sys.stderr)
        sys.exit(1)
    if path.parent.resolve() != HERE.resolve():
        print("ERROR: la copia debe vivir en la carpeta cuestionario-decisiones/", file=sys.stderr)
        sys.exit(1)


def should_skip(path: Path) -> bool:
    return any(s in path.parts for s in SKIP_PARTS)


def slice_block(text: str, start: int) -> str:
    rest = text[start:]
    ends: list[int] = []
    m = re.search(r"\n### PA-", rest)
    if m:
        ends.append(m.start())
    m = re.search(r"\n## [^#\n]", rest)
    if m:
        ends.append(m.start())
    end = min(ends) if ends else len(rest)
    return rest[:end].rstrip() + "\n"


def ensure_response_fields(block: str) -> str:
    if "**Opción elegida:**" in block:
        return block if block.endswith("\n") else block + "\n"
    return block.rstrip() + "\n\n" + RESPONSE_LINES


def load_saved_responses(path: Path) -> dict[str, tuple[str, str, str]]:
    if not path.is_file():
        return {}
    text = path.read_text(encoding="utf-8")
    saved: dict[str, tuple[str, str, str]] = {}
    for m in PA_START.finditer(text):
        pa_id = m.group(1)
        block = slice_block(text, m.start())

        def grab(name: str) -> str:
            rx = re.compile(r"\- \*\*" + re.escape(name) + r":\*\*\s*(.+)", re.IGNORECASE)
            hit = rx.search(block)
            return hit.group(1).strip() if hit else "—"

        elegida = grab("Opción elegida")
        amp = grab("Ampliación")
        fecha = grab("Respondido")
        if elegida != "—" or amp != "—" or (fecha and fecha != "—"):
            saved[pa_id] = (elegida, amp, fecha)
    return saved


def apply_saved(block: str, triple: tuple[str, str, str]) -> str:
    elegida, amp, fecha = triple
    block = FIELD_ELEGIDA.sub(r"\1 " + elegida, block, count=1)
    block = FIELD_AMP.sub(r"\1 " + amp.replace("\n", " "), block, count=1)
    block = FIELD_FECHA.sub(r"\1 " + fecha, block, count=1)
    return block


def collect_blocks() -> dict[str, str]:
    found: dict[str, str] = {}
    for path in sorted(ANEXOS.glob("*.md")):
        if should_skip(path):
            continue
        text = path.read_text(encoding="utf-8")
        for m in PA_START.finditer(text):
            pa_id = m.group(1)
            block = slice_block(text, m.start())
            block = ensure_response_fields(block)
            if pa_id not in found:
                found[pa_id] = block
    return found


ROW_02 = re.compile(
    r"^\| (PA-[^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \|",
    re.MULTILINE,
)


def build_indice_02() -> dict[str, dict[str, str]]:
    if not INDEX_02.is_file():
        return {}
    text = INDEX_02.read_text(encoding="utf-8")
    out: dict[str, dict[str, str]] = {}
    for m in ROW_02.finditer(text):
        pa_id = m.group(1).strip()
        out[pa_id] = {
            "anexo": m.group(2).strip(),
            "titulo": m.group(3).strip(),
            "recomendada": m.group(4).strip(),
            "estadoIndice": m.group(5).strip(),
        }
    return out


def sort_key(pa_id: str) -> tuple:
    m = re.match(r"^PA-([A-Z]+)(?:-(.+))?$", pa_id)
    if not m:
        return (999, pa_id)
    prefix, rest = m.group(1), m.group(2) or ""
    parts = re.split(r"[-P]", rest) if rest else []
    nums: list[int] = []
    for p in parts:
        if p.isdigit():
            nums.append(int(p))
        elif re.match(r"^P\d+$", p):
            nums.append(int(p[1:]))
    return (prefix, nums, pa_id)


def source_for_merge() -> Path:
    if OUT.is_file():
        return OUT
    if LEGACY_OUT.is_file():
        return LEGACY_OUT
    return OUT


def main() -> None:
    assert_out_safe(OUT)
    blocks = collect_blocks()
    saved = load_saved_responses(source_for_merge())
    merged = 0
    for pa_id, triple in saved.items():
        if pa_id in blocks:
            blocks[pa_id] = apply_saved(blocks[pa_id], triple)
            merged += 1

    ordered = sorted(blocks.keys(), key=sort_key)
    body = "\n".join(blocks[k] for k in ordered)
    count = len(ordered)
    note = f"\n**Total:** {count} preguntas"
    if saved:
        note += f" · **Respuestas conservadas:** {merged}"
    note += "\n\n---\n\n"

    OUT.write_text(HEADER + note + body, encoding="utf-8")
    indice = build_indice_02()
    INDICE_JSON.write_text(
        json.dumps(indice, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"Escrito {OUT.name} ({count} preguntas, {merged} respuestas conservadas)")
    print(f"Escrito {INDICE_JSON.name} ({len(indice)} entradas desde 02-preguntas-abiertas)")
    print("(No se modificó nada en docs/especificacion/)")


if __name__ == "__main__":
    main()