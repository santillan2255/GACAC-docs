#!/usr/bin/env python3
"""
Genera la COPIA de trabajo `copia-respuestas-stakeholder.md` leyendo solo los anexos.

Nunca escribe en docs/especificacion/ (02-preguntas-abiertas.md, anexos, etc.).
Si la copia ya existe, conserva Opción elegida / Ampliación / Respondido al refrescar textos.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ANEXOS = ROOT / "especificacion" / "anexos"
INDEX_02 = ROOT / "especificacion" / "02-preguntas-abiertas.md"
# Único archivo que este script puede crear o sobrescribir (salvo exportaciones manuales)
OUT = HERE / "copia-respuestas-stakeholder.md"
INDICE_JSON = HERE / "indice-02.json"
STACK_JSON = HERE / "stack-norms.json"
LEGACY_OUT = HERE / "preguntas-respuestas.md"

SYNTHETIC_PREFIXES = ("PA-STACK-", "PA-BRD-")

STACK_CTX = (
    "Según `06-impacto-adaptacion-stack-goodapps.md`: Azure SQL + EF Core + .NET 10 + React "
    "(DEC-111…119). DEC-001 (Node/Mongo) quedó reemplazada por DEC-111 (D-02 en §10). "
    "DIR-13: la tensión del índice 02 resume el debate; el cierre oficial vive en `01` y en el doc `06`."
)

SKIP_PARTS = ("backup", "OLD", "backup-sync")

HEADER = """# Copia de trabajo — respuestas del stakeholder

> **No es** `docs/especificacion/02-preguntas-abiertas.md` ni el registro de decisiones oficial.
> Se genera leyendo los anexos; las respuestas viven **solo en este archivo** (y en tus exportaciones).
> Regenerar: `python build_md.py` (mantiene tus respuestas ya cargadas en esta copia).
>
> **Stack vigente (GoodApps):** `06-impacto-adaptacion-stack-goodapps.md` — Azure SQL, no MongoDB (DEC-111).
> Las preguntas de anexos pueden citar DEC-001 o Mongo; el cuestionario las muestra con aviso de equivalencia.

"""

RESPONSE_LINES = (
    "- **Opción elegida:** —\n"
    "- **Ampliación:** —\n"
    "- **Respondido:** —\n"
)

PA_START = re.compile(
    r"^### (PA-[A-Z0-9]+(?:-[A-Z0-9]+)*) — (.+)$",
    re.MULTILINE,
)

FIELD_ELEGIDA = re.compile(r"(\- \*\*Opción elegida:\*\*)\s*.+", re.IGNORECASE)
FIELD_AMP = re.compile(r"(\- \*\*Ampliación:\*\*)\s*.+", re.IGNORECASE)
FIELD_FECHA = re.compile(r"(\- \*\*Respondido:\*\*)\s*.+", re.IGNORECASE)


def assert_out_safe(path: Path) -> None:
    path = path.resolve()
    spec = (ROOT / "especificacion").resolve()
    if path == spec or spec in path.parents:
        print("ERROR: la salida no puede estar dentro de especificacion/", file=sys.stderr)
        sys.exit(1)
    if path.parent.resolve() != HERE.resolve():
        print("ERROR: la copia debe vivir en la carpeta cuestionario-decisiones/", file=sys.stderr)
        sys.exit(1)


def should_skip(path: Path) -> bool:
    return any(s in path.parts for s in SKIP_PARTS)


def slice_block(text: str, start: int) -> str:
    rest = text[start:]
    ends: list[int] = []
    m = re.search(r"\n### PA-", rest)
    if m:
        ends.append(m.start())
    m = re.search(r"\n## [^#\n]", rest)
    if m:
        ends.append(m.start())
    end = min(ends) if ends else len(rest)
    return rest[:end].rstrip() + "\n"


def ensure_response_fields(block: str) -> str:
    if "**Opción elegida:**" in block:
        return block if block.endswith("\n") else block + "\n"
    return block.rstrip() + "\n\n" + RESPONSE_LINES


def load_saved_responses(path: Path) -> dict[str, tuple[str, str, str]]:
    if not path.is_file():
        return {}
    text = path.read_text(encoding="utf-8")
    saved: dict[str, tuple[str, str, str]] = {}
    for m in PA_START.finditer(text):
        pa_id = m.group(1)
        block = slice_block(text, m.start())

        def grab(name: str) -> str:
            rx = re.compile(r"\- \*\*" + re.escape(name) + r":\*\*\s*(.+)", re.IGNORECASE)
            hit = rx.search(block)
            return hit.group(1).strip() if hit else "—"

        elegida = grab("Opción elegida")
        amp = grab("Ampliación")
        fecha = grab("Respondido")
        if elegida != "—" or amp != "—" or (fecha and fecha != "—"):
            saved[pa_id] = (elegida, amp, fecha)
    return saved


def apply_saved(block: str, triple: tuple[str, str, str]) -> str:
    elegida, amp, fecha = triple
    block = FIELD_ELEGIDA.sub(r"\1 " + elegida, block, count=1)
    block = FIELD_AMP.sub(r"\1 " + amp.replace("\n", " "), block, count=1)
    block = FIELD_FECHA.sub(r"\1 " + fecha, block, count=1)
    return block


def collect_blocks() -> dict[str, str]:
    found: dict[str, str] = {}
    for path in sorted(ANEXOS.glob("*.md")):
        if should_skip(path):
            continue
        text = path.read_text(encoding="utf-8")
        for m in PA_START.finditer(text):
            pa_id = m.group(1)
            block = slice_block(text, m.start())
            block = ensure_response_fields(block)
            if pa_id not in found:
                found[pa_id] = block
    return found


ROW_02 = re.compile(
    r"^\| (PA-[^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \| ([^|]+) \|",
    re.MULTILINE,
)


def synthetic_title(pa_id: str, titulo_tabla: str) -> str:
    short = titulo_tabla.strip()
    if pa_id.startswith("PA-STACK-"):
        return short.split(" vs ")[0].strip() if " vs " in short else short[:72]
    if pa_id.startswith("PA-BRD-"):
        return "Marca CoopApps: manual gráfico vs repo"
    return short[:80]


def synthetic_pregunta(titulo_tabla: str) -> str:
    t = titulo_tabla.strip()
    if t.endswith("?"):
        return t
    if " vs " in t.lower():
        return f"¿Cómo cerramos la tensión «{t}»?"
    return f"¿{t}?" if "¿" not in t else t


def block_from_02_row(pa_id: str, row: dict[str, str]) -> str:
    titulo_tabla = row["titulo"]
    rec = row["recomendada"]
    estado = row["estadoIndice"]
    anexo = row["anexo"]
    title = synthetic_title(pa_id, titulo_tabla)
    pregunta = synthetic_pregunta(titulo_tabla)
    lines = [
        f"### {pa_id} — {title}",
        f"- **Pregunta:** {pregunta}",
        f"- **Contexto:** {STACK_CTX} Anexo / ámbito en índice 02: {anexo}. Tensión: {titulo_tabla}.",
        "- **Opciones:**",
        f"  - A) {rec} **(Recomendada)** — posición del índice `02-preguntas-abiertas` y doc `06` §10.",
        "  - B) Otra posición (describir en ampliación; requiere PA/DEC nueva si cambia comportamiento — DIR-11).",
        f"- **Estado:** {estado} (índice 02; no modifica la spec oficial).",
    ]
    if "Pendiente" in estado:
        lines.append(
            "- **Impacto si no se responde:** se mantiene la recomendación A del índice hasta nueva DEC."
        )
    return "\n".join(lines) + "\n\n" + RESPONSE_LINES


def collect_synthetic_blocks(indice: dict[str, dict[str, str]]) -> dict[str, str]:
    out: dict[str, str] = {}
    for pa_id, row in indice.items():
        if not any(pa_id.startswith(p) for p in SYNTHETIC_PREFIXES):
            continue
        out[pa_id] = block_from_02_row(pa_id, row)
    return out


def write_stack_norms() -> None:
    payload = {
        "doc06": "docs/especificacion/06-impacto-adaptacion-stack-goodapps.md",
        "summary": (
            "Implementación GoodApps: Azure SQL relacional, EF Core, .NET 10, React 19. "
            "Multitenant con TenantId (DEC-110). DEC-111 reemplaza DEC-001 (Node/Mongo)."
        ),
        "legacyPattern": "MongoDB|Mongo\\b|DEC-001|replica set|BullMQ|Node\\+Mongo|en Mongo|PITR.*Mongo",
        "decisions": {
            "DEC-111": "Stack .NET + Azure SQL + React (vigente)",
            "DEC-001": "Stack anterior citado en anexos; histórico — reemplazado por DEC-111",
            "DEC-117": "Modelo físico en 07-modelo-relacional-azure-sql.md",
        },
        "paStackIds": [
            k for k in sorted(indice_pa_stack_keys())
        ],
    }
    STACK_JSON.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def indice_pa_stack_keys() -> list[str]:
    if not INDEX_02.is_file():
        return []
    text = INDEX_02.read_text(encoding="utf-8")
    return [
        m.group(1).strip()
        for m in ROW_02.finditer(text)
        if m.group(1).strip().startswith("PA-STACK-")
    ]


def build_indice_02() -> dict[str, dict[str, str]]:
    if not INDEX_02.is_file():
        return {}
    text = INDEX_02.read_text(encoding="utf-8")
    out: dict[str, dict[str, str]] = {}
    for m in ROW_02.finditer(text):
        pa_id = m.group(1).strip()
        out[pa_id] = {
            "anexo": m.group(2).strip(),
            "titulo": m.group(3).strip(),
            "recomendada": m.group(4).strip(),
            "estadoIndice": m.group(5).strip(),
        }
    return out


def sort_key(pa_id: str) -> tuple:
    m = re.match(r"^PA-([A-Z]+)(?:-(.+))?$", pa_id)
    if not m:
        return (999, pa_id)
    prefix, rest = m.group(1), m.group(2) or ""
    parts = re.split(r"[-P]", rest) if rest else []
    nums: list[int] = []
    for p in parts:
        if p.isdigit():
            nums.append(int(p))
        elif re.match(r"^P\d+$", p):
            nums.append(int(p[1:]))
    return (prefix, nums, pa_id)


def source_for_merge() -> Path:
    if OUT.is_file():
        return OUT
    if LEGACY_OUT.is_file():
        return LEGACY_OUT
    return OUT


def main() -> None:
    assert_out_safe(OUT)
    indice = build_indice_02()
    blocks = collect_blocks()
    for pa_id, block in collect_synthetic_blocks(indice).items():
        if pa_id not in blocks:
            blocks[pa_id] = block
    saved = load_saved_responses(source_for_merge())
    merged = 0
    for pa_id, triple in saved.items():
        if pa_id in blocks:
            blocks[pa_id] = apply_saved(blocks[pa_id], triple)
            merged += 1

    ordered = sorted(blocks.keys(), key=sort_key)
    body = "\n".join(blocks[k] for k in ordered)
    count = len(ordered)
    note = f"\n**Total:** {count} preguntas"
    if saved:
        note += f" · **Respuestas conservadas:** {merged}"
    note += "\n\n---\n\n"

    OUT.write_text(HEADER + note + body, encoding="utf-8")
    INDICE_JSON.write_text(
        json.dumps(indice, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    write_stack_norms()
    print(f"Escrito {OUT.name} ({count} preguntas, {merged} respuestas conservadas)")
    print(f"Escrito {INDICE_JSON.name} ({len(indice)} entradas desde 02-preguntas-abiertas)")
    print(f"Escrito {STACK_JSON.name}")
    print("(No se modificó nada en docs/especificacion/)")


if __name__ == "__main__":
    main()