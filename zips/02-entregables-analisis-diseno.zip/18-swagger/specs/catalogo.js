window.GA_CATALOGO={
 "modulos": [
  {
   "clave": "m01-per",
   "anexo": "M01",
   "tipo": "Módulo funcional",
   "titulo": "API de M01 PER — Personas, titulares, asociados, cuentas, inmuebles y domicilios",
   "operaciones": 108,
   "rutas": 80,
   "esquemas": 31,
   "bytes": 316842
  },
  {
   "clave": "m02-cat",
   "anexo": "M02",
   "tipo": "Módulo funcional",
   "titulo": "API de M02 CAT — Catálogo de servicios, productos, planes, categorías, estados, contrato de servicio, habilitación por tenant, copia entre tenants y particularidades por servicio",
   "operaciones": 87,
   "rutas": 54,
   "esquemas": 36,
   "bytes": 254373
  },
  {
   "clave": "m03-med",
   "anexo": "M03",
   "tipo": "Módulo funcional",
   "titulo": "API de M03 MED — Medidores, lecturas, consumos, telemedición y prepago",
   "operaciones": 109,
   "rutas": 83,
   "esquemas": 46,
   "bytes": 299873
  },
  {
   "clave": "m04-tar",
   "anexo": "M04",
   "tipo": "Módulo funcional",
   "titulo": "API de M04 TAR — Tarifas y motor de cálculo",
   "operaciones": 111,
   "rutas": 73,
   "esquemas": 45,
   "bytes": 339485
  },
  {
   "clave": "m05-fac",
   "anexo": "M05",
   "tipo": "Módulo funcional",
   "titulo": "API de M05 FAC — Facturación: ciclos, lotes y comprobantes",
   "operaciones": 190,
   "rutas": 145,
   "esquemas": 48,
   "bytes": 542914
  },
  {
   "clave": "m06-fis",
   "anexo": "M06",
   "tipo": "Módulo funcional",
   "titulo": "API de M06 FIS — Fiscal e impuestos (ARCA, IVA, percepciones, retenciones, regímenes, terceros, reguladores)",
   "operaciones": 122,
   "rutas": 82,
   "esquemas": 57,
   "bytes": 358918
  },
  {
   "clave": "m07-cob",
   "anexo": "M07",
   "tipo": "Módulo funcional",
   "titulo": "API de M07 COB — Cuenta corriente, cobranza, cajas, entes, débitos, pasarelas y conciliación",
   "operaciones": 114,
   "rutas": 93,
   "esquemas": 55,
   "bytes": 360864
  },
  {
   "clave": "m08-mor",
   "anexo": "M08",
   "tipo": "Módulo funcional",
   "titulo": "API de M08 MOR — Mora, intereses, suspensión, corte, reconexión, financiación y convenios, garantías, incobrables, gestión judicial y prescripción",
   "operaciones": 184,
   "rutas": 137,
   "esquemas": 49,
   "bytes": 496228
  },
  {
   "clave": "m09-crm",
   "anexo": "M09",
   "tipo": "Módulo funcional",
   "titulo": "API de M09 CRM — CRM y atención (solicitudes, reclamos, tickets, mesa de entradas, turnero, canales, bot, IA, actividades internas)",
   "operaciones": 248,
   "rutas": 153,
   "esquemas": 52,
   "bytes": 694620
  },
  {
   "clave": "m10-tec",
   "anexo": "M10",
   "tipo": "Módulo funcional",
   "titulo": "API de M10 TEC — Técnica, campo, agenda, instalación, GIS/redes, obras, aprovisionamiento TIC y telefonía",
   "operaciones": 382,
   "rutas": 218,
   "esquemas": 86,
   "bytes": 1087109
  },
  {
   "clave": "m11-ven",
   "anexo": "M11",
   "tipo": "Módulo funcional",
   "titulo": "API de M11 VEN — Ventas, presupuestos y punto de venta",
   "operaciones": 70,
   "rutas": 58,
   "esquemas": 24,
   "bytes": 188459
  },
  {
   "clave": "m12-cmp",
   "anexo": "M12",
   "tipo": "Módulo funcional",
   "titulo": "API de M12 CMP — Compras y proveedores",
   "operaciones": 100,
   "rutas": 82,
   "esquemas": 33,
   "bytes": 274343
  },
  {
   "clave": "m13-stk",
   "anexo": "M13",
   "tipo": "Módulo funcional",
   "titulo": "API de M13 STK — Stock, equipos serializados, bienes de uso, RMA y fabricación",
   "operaciones": 143,
   "rutas": 101,
   "esquemas": 50,
   "bytes": 413813
  },
  {
   "clave": "m14-tes",
   "anexo": "M14",
   "tipo": "Módulo funcional",
   "titulo": "API de M14 TES — Tesorería y bancos",
   "operaciones": 166,
   "rutas": 129,
   "esquemas": 52,
   "bytes": 456437
  },
  {
   "clave": "m15-con",
   "anexo": "M15",
   "tipo": "Módulo funcional",
   "titulo": "API de M15 CON — Contabilidad, centros de costo, múltiples planes de cuentas, escenarios simulados y presupuestos",
   "operaciones": 135,
   "rutas": 100,
   "esquemas": 46,
   "bytes": 370904
  },
  {
   "clave": "m16-sue",
   "anexo": "M16",
   "tipo": "Módulo funcional",
   "titulo": "API de M16 SUE — Personal y sueldos",
   "operaciones": 271,
   "rutas": 162,
   "esquemas": 70,
   "bytes": 709688
  },
  {
   "clave": "m17-ins",
   "anexo": "M17",
   "tipo": "Módulo funcional",
   "titulo": "API de M17 INS — Gestión institucional (asociados, capital, asambleas, consejo, INAES)",
   "operaciones": 110,
   "rutas": 67,
   "esquemas": 45,
   "bytes": 296093
  },
  {
   "clave": "m18-soc",
   "anexo": "M18",
   "tipo": "Módulo funcional",
   "titulo": "API de M18 SOC — Servicios sociales, otros servicios y flota",
   "operaciones": 116,
   "rutas": 61,
   "esquemas": 63,
   "bytes": 324603
  },
  {
   "clave": "m19-por",
   "anexo": "M19",
   "tipo": "Módulo funcional",
   "titulo": "API de M19 POR — Landing, portal y app del socio (autogestión)",
   "operaciones": 192,
   "rutas": 156,
   "esquemas": 24,
   "bytes": 462071
  },
  {
   "clave": "t01-pla",
   "anexo": "T01",
   "tipo": "Módulo transversal",
   "titulo": "API de T01 PLA — Plataforma SaaS: arquitectura de referencia, stack, multitenancy, tenants, licencias, soporte, ambientes y backups",
   "operaciones": 106,
   "rutas": 89,
   "esquemas": 42,
   "bytes": 287353
  },
  {
   "clave": "t02-iam",
   "anexo": "T02",
   "tipo": "Módulo transversal",
   "titulo": "API de T02 IAM — Identidad, autenticación, roles, perfiles, alcance y auditoría",
   "operaciones": 128,
   "rutas": 100,
   "esquemas": 40,
   "bytes": 309849
  },
  {
   "clave": "t03-uxd",
   "anexo": "T03",
   "tipo": "Módulo transversal",
   "titulo": "API de T03 UXD — Experiencia, design system, marca por tenant, diccionario de términos y etiquetas, layouts y mapa del sitio",
   "operaciones": 56,
   "rutas": 40,
   "esquemas": 21,
   "bytes": 142788
  },
  {
   "clave": "t04-cfg",
   "anexo": "T04",
   "tipo": "Módulo transversal",
   "titulo": "API de T04 CFG — Configuración versionada, parámetros, tablas maestras y geografía",
   "operaciones": 106,
   "rutas": 80,
   "esquemas": 55,
   "bytes": 316477
  },
  {
   "clave": "t06-int",
   "anexo": "T06",
   "tipo": "Módulo transversal",
   "titulo": "API de T06 INT — Integraciones externas: marco común de conectores y fichas",
   "operaciones": 74,
   "rutas": 66,
   "esquemas": 28,
   "bytes": 206203
  },
  {
   "clave": "t07-mig",
   "anexo": "T07",
   "tipo": "Módulo transversal",
   "titulo": "API de T07 MIG — Migración desde ProCoop, convivencia, corrida paralela y by-pass",
   "operaciones": 54,
   "rutas": 43,
   "esquemas": 30,
   "bytes": 149233
  },
  {
   "clave": "t08-nfr",
   "anexo": "T08",
   "tipo": "Módulo transversal",
   "titulo": "API de T08 NFR — Requisitos no funcionales, seguridad, privacidad, observabilidad y calidad",
   "operaciones": 63,
   "rutas": 52,
   "esquemas": 27,
   "bytes": 160232
  },
  {
   "clave": "t09-com",
   "anexo": "T09",
   "tipo": "Módulo transversal",
   "titulo": "API de T09 COM — Comunidad y comunicaciones (muro, novedades, encuestas, eventos, beneficios, audiencias, notificaciones y campañas)",
   "operaciones": 326,
   "rutas": 231,
   "esquemas": 66,
   "bytes": 897791
  },
  {
   "clave": "t10-bia",
   "anexo": "T10",
   "tipo": "Módulo transversal",
   "titulo": "API de T10 BIA — Reportes, BI, tableros, exportaciones y APIs para terceros",
   "operaciones": 136,
   "rutas": 107,
   "esquemas": 77,
   "bytes": 413282
  },
  {
   "clave": "t10-bia-api-externa",
   "anexo": "T10",
   "tipo": "API externa",
   "titulo": "API externa de integración (T10 §11.2.6)",
   "operaciones": 66,
   "rutas": 64,
   "esquemas": 79,
   "bytes": 242965
  },
  {
   "clave": "t11-wfl",
   "anexo": "T11",
   "tipo": "Módulo transversal",
   "titulo": "API de T11 WFL — Workflow, eventos, tareas, aprobaciones y documentos",
   "operaciones": 120,
   "rutas": 102,
   "esquemas": 61,
   "bytes": 337715
  }
 ],
 "completa": {
  "clave": "goodapps-api-completa",
  "operaciones": 4193,
  "bytes": 11454800
 }
};
