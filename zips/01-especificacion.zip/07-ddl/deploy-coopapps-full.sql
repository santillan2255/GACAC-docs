-- CoopApps — despliegue completo (capa C)
-- 1) pla: generate_pla_sql.py  2) resto: generate_exhaustive_ddl.py

:r sql/000-all-schemas.sql
:r sql/pla/deploy-all.sql

:r sql/bia/deploy-all.sql
:r sql/cat/deploy-all.sql
:r sql/cfg/deploy-all.sql
:r sql/cmp/deploy-all.sql
:r sql/cob/deploy-all.sql
:r sql/com/deploy-all.sql
:r sql/con_/deploy-all.sql
:r sql/crm/deploy-all.sql
:r sql/fac/deploy-all.sql
:r sql/fis/deploy-all.sql
:r sql/iam/deploy-all.sql
:r sql/ins/deploy-all.sql
:r sql/int/deploy-all.sql
:r sql/med/deploy-all.sql
:r sql/mig/deploy-all.sql
:r sql/mor/deploy-all.sql
:r sql/nfr/deploy-all.sql
:r sql/per/deploy-all.sql
:r sql/por/deploy-all.sql
:r sql/soc/deploy-all.sql
:r sql/stk/deploy-all.sql
:r sql/sue/deploy-all.sql
:r sql/tar/deploy-all.sql
:r sql/tec/deploy-all.sql
:r sql/tes/deploy-all.sql
:r sql/uxd/deploy-all.sql
:r sql/ven/deploy-all.sql
:r sql/wfl/deploy-all.sql

:r sql/200-all-unique-indexes.sql
:r sql/201-deferred-foreign-keys.sql
-- Conservador (solo mismo esquema): comentar 201 y descomentar:
-- :r sql/203-foreign-keys-intramodule.sql
