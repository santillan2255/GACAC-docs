# Smoke test: crea base vacía CoopApps desde DDL capa C (requiere sqlcmd).
# Uso: .\smoke-deploy-ddl.ps1 -Server "localhost" -Database "GacacDdlSmoke"
param(
    [string]$Server = "localhost",
    [string]$Database = "GacacDdlSmoke",
    [switch]$IntegratedSecurity = $true
)

$ErrorActionPreference = "Stop"
$sqlcmd = Get-Command sqlcmd -ErrorAction SilentlyContinue
if (-not $sqlcmd) {
    Write-Host "sqlcmd no está en PATH. Instale SQL Server Command Line Tools o use SSMS para ejecutar deploy-coopapps-full.sql."
    Write-Host "https://learn.microsoft.com/sql/tools/sqlcmd/sqlcmd-download-install"
    exit 2
}

$ddlRoot = $PSScriptRoot
$master = Join-Path $ddlRoot "deploy-coopapps-full.sql"
if (-not (Test-Path $master)) {
    throw "No se encuentra $master"
}

$auth = if ($IntegratedSecurity) { "-E" } else { "-U usuario -P clave" }

Write-Host "Creando base $Database en $Server ..."
Invoke-Expression "sqlcmd -S `"$Server`" -Q `"IF DB_ID(N'$Database') IS NULL CREATE DATABASE [$Database];`" $auth"

Push-Location $ddlRoot
try {
    Write-Host "Ejecutando DDL (puede tardar varios minutos) ..."
    Invoke-Expression "sqlcmd -S `"$Server`" -d `"$Database`" -b -i deploy-coopapps-full.sql $auth"
    Write-Host "OK: despliegue DDL completado."
}
finally {
    Pop-Location
}