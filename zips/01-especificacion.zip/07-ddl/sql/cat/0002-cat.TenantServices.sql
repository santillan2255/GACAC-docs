-- cat.TenantServices — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.TenantServices', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[TenantServices] (
        [TenantServiceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CapabilityId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LabelKey] NVARCHAR(512) NOT NULL,
        [ServiceTypeCode] NVARCHAR(512) NULL,
        [IsPrincipal] BIT NULL,
        [EnablementJson] NVARCHAR(MAX) NOT NULL,
        [OfferStatus] VARCHAR(64) NOT NULL,
        [OperationStatus] VARCHAR(64) NOT NULL,
        [CurrentConfigVersionId] UNIQUEIDENTIFIER NULL,
        [ProfileJson] NVARCHAR(MAX) NOT NULL,
        [RegistrationProfile] VARCHAR(64) NOT NULL,
        [CalculationType] INT NOT NULL,
        [CalculationTypeLargeCustomers] INT NULL,
        [FlagsJson] NVARCHAR(MAX) NOT NULL,
        [RequirementsJson] NVARCHAR(MAX) NOT NULL,
        [RelatedServiceJson] NVARCHAR(MAX) NULL,
        [ConsumptionSplitMode] VARCHAR(64) NULL,
        [MembersJson] NVARCHAR(MAX) NULL,
        [RegistrationsJson] NVARCHAR(MAX) NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [DefaultOperationalStatusJson] NVARCHAR(MAX) NOT NULL,
        [WorkOrderTypesJson] NVARCHAR(MAX) NULL,
        [TransferJson] NVARCHAR(MAX) NULL,
        [DefaultBillingGroupId] UNIQUEIDENTIFIER NOT NULL,
        [PhoneMobileType] VARCHAR(64) NULL,
        [UniquenessJson] NVARCHAR(MAX) NOT NULL,
        [AddressDebtCheckJson] NVARCHAR(MAX) NOT NULL,
        [HolderRulesJson] NVARCHAR(MAX) NOT NULL,
        [LifecycleJson] NVARCHAR(MAX) NOT NULL,
        [DocumentsJson] NVARCHAR(MAX) NULL,
        [ChannelsJson] NVARCHAR(MAX) NOT NULL,
        [MappingsJson] NVARCHAR(MAX) NULL,
        [IntegrationsJson] NVARCHAR(MAX) NULL,
        [CopiedFromJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_TenantServices_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_TenantServices_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_TenantServices] PRIMARY KEY ([TenantServiceId]),
        CONSTRAINT [FK_cat_TenantServices_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_TenantServices_Tenant] ON [cat].[TenantServices] ([TenantId]);
END;
GO
