-- cat.ContractSpecialConditions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ContractSpecialConditions', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ContractSpecialConditions] (
        [ContractSpecialConditionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ContractId] UNIQUEIDENTIFIER NOT NULL,
        [Version] INT NOT NULL,
        [PriceTermsRef] NVARCHAR(MAX) NULL,
        [TermMonths] INT NULL,
        [PenaltiesJson] NVARCHAR(MAX) NULL,
        [RequiresInvoicePreReview] BIT NULL,
        [ApprovedBy] NVARCHAR(MAX) NULL,
        [ApprovedAt] DATETIME2(7) NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [ValidTo] DATETIME2(7) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ContractSpecialConditions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ContractSpecialConditions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ContractSpecialConditions] PRIMARY KEY ([ContractSpecialConditionId]),
        CONSTRAINT [FK_cat_ContractSpecialConditions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ContractSpecialConditions_Tenant] ON [cat].[ContractSpecialConditions] ([TenantId]);
END;
GO
