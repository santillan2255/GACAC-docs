-- cat.ServiceConfigVersions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceConfigVersions', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceConfigVersions] (
        [ServiceConfigVersionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ServiceId] UNIQUEIDENTIFIER NOT NULL,
        [Number] INT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ChangeKinds] VARCHAR(64) NOT NULL,
        [SnapshotJson] NVARCHAR(MAX) NOT NULL,
        [DiffFromPreviousJson] NVARCHAR(MAX) NULL,
        [ValidationsJson] NVARCHAR(MAX) NOT NULL,
        [SimulationRunIdsId] UNIQUEIDENTIFIER NULL,
        [EffectiveFrom] DATETIME2(7) NOT NULL,
        [RecordedAt] DATETIME2(7) NOT NULL,
        [WorkflowInstanceId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceConfigVersions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceConfigVersions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceConfigVersions] PRIMARY KEY ([ServiceConfigVersionId]),
        CONSTRAINT [FK_cat_ServiceConfigVersions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceConfigVersions_Tenant] ON [cat].[ServiceConfigVersions] ([TenantId]);
END;
GO
