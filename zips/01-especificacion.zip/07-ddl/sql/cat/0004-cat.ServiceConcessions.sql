-- cat.ServiceConcessions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceConcessions', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceConcessions] (
        [ServiceConcessionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CONCESIO] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [NOM_CESI] NVARCHAR(512) NULL,
        [Grantor] NVARCHAR(512) NULL,
        [AuthorityIds] NVARCHAR(512) NULL,
        [Jurisdiction] NVARCHAR(512) NULL,
        [InstrumentRef] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ValidTo] NVARCHAR(512) NULL,
        [ServiceIds] NVARCHAR(512) NULL,
        [Documents] NVARCHAR(512) NULL,
        [{tenantId, code}] NVARCHAR(512) NULL,
        [AuthorityIdsId] UNIQUEIDENTIFIER NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NULL,
        [DocumentsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceConcessions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceConcessions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceConcessions] PRIMARY KEY ([ServiceConcessionId]),
        CONSTRAINT [FK_cat_ServiceConcessions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceConcessions_Tenant] ON [cat].[ServiceConcessions] ([TenantId]);
END;
GO
