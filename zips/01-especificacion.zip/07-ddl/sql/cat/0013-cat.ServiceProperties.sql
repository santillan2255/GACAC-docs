-- cat.ServiceProperties — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceProperties', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceProperties] (
        [ServicePropertyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ServiceId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LabelKey] NVARCHAR(512) NULL,
        [ValueType] VARCHAR(64) NULL,
        [ListValuesJson] NVARCHAR(MAX) NULL,
        [Tension] NVARCHAR(MAX) NULL,
        [LinkedConcepts] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceProperties_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceProperties_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceProperties] PRIMARY KEY ([ServicePropertyId]),
        CONSTRAINT [FK_cat_ServiceProperties_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceProperties_Tenant] ON [cat].[ServiceProperties] ([TenantId]);
END;
GO
