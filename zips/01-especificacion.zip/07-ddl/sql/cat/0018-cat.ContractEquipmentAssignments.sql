-- cat.ContractEquipmentAssignments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ContractEquipmentAssignments', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ContractEquipmentAssignments] (
        [ContractEquipmentAssignmentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ContractId] UNIQUEIDENTIFIER NOT NULL,
        [InventoryItemId] UNIQUEIDENTIFIER NOT NULL,
        [Quantity] DECIMAL(18,4) NOT NULL,
        [SerialUnitId] UNIQUEIDENTIFIER NULL,
        [SerialNumber] NVARCHAR(512) NULL,
        [WarehouseId] UNIQUEIDENTIFIER NOT NULL,
        [Mode] VARCHAR(64) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ReturnCondition] VARCHAR(64) NULL,
        [ChargeProposalId] UNIQUEIDENTIFIER NULL,
        [SaleDocumentRefJson] NVARCHAR(MAX) NULL,
        [DeliveredAt] DATETIME2(7) NOT NULL,
        [ExpectedReturnAt] DATETIME2(7) NULL,
        [ReturnedAt] DATETIME2(7) NULL,
        [ReferencePrice] DECIMAL(18,4) NULL,
        [WorkOrderId] UNIQUEIDENTIFIER NULL,
        [RetrievalWorkOrderId] UNIQUEIDENTIFIER NULL,
        [Notes] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ContractEquipmentAssignments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ContractEquipmentAssignments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ContractEquipmentAssignments] PRIMARY KEY ([ContractEquipmentAssignmentId]),
        CONSTRAINT [FK_cat_ContractEquipmentAssignments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ContractEquipmentAssignments_Tenant] ON [cat].[ContractEquipmentAssignments] ([TenantId]);
END;
GO
