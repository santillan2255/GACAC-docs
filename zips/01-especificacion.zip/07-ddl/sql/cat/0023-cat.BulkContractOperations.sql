-- cat.BulkContractOperations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.BulkContractOperations', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[BulkContractOperations] (
        [BulkContractOperationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ClsTramites] NVARCHAR(512) NULL,
        [Operation] NVARCHAR(512) NULL,
        [MarkProvisional] NVARCHAR(512) NULL,
        [ChangeActivity] NVARCHAR(512) NULL,
        [ChangeClass] NVARCHAR(512) NULL,
        [ChangeCategory] NVARCHAR(512) NULL,
        [ChangeReference] NVARCHAR(512) NULL,
        [Terminate] NVARCHAR(512) NULL,
        [Recategorize] NVARCHAR(512) NULL,
        [ResetCategories] NVARCHAR(512) NULL,
        [MemberOutOfRangeAction] NVARCHAR(512) NULL,
        [Criteria] NVARCHAR(512) NULL,
        [ContractIds] NVARCHAR(512) NULL,
        [AlsoUnbilledConsumption] NVARCHAR(512) NULL,
        [RequestedBy] NVARCHAR(512) NULL,
        [OriginModule] NVARCHAR(512) NULL,
        [Cat] NVARCHAR(512) NULL,
        [Mor] NVARCHAR(512) NULL,
        [Tar] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [Simulated] NVARCHAR(512) NULL,
        [Approved] NVARCHAR(512) NULL,
        [Running] NVARCHAR(512) NULL,
        [Completed] NVARCHAR(512) NULL,
        [PartiallyFailed] NVARCHAR(512) NULL,
        [Reverted] NVARCHAR(512) NULL,
        [Results{contractId, outcome, message}] NVARCHAR(512) NULL,
        [RevertibleUntil] NVARCHAR(512) NULL,
        [JobId] NVARCHAR(512) NULL,
        [ContractIdsId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_BulkContractOperations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_BulkContractOperations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_BulkContractOperations] PRIMARY KEY ([BulkContractOperationId]),
        CONSTRAINT [FK_cat_BulkContractOperations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_BulkContractOperations_Tenant] ON [cat].[BulkContractOperations] ([TenantId]);
END;
GO
