-- cat.AutoServiceRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.AutoServiceRules', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[AutoServiceRules] (
        [AutoServiceRuleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LabelKey] NVARCHAR(512) NOT NULL,
        [TriggerEvent] VARCHAR(64) NOT NULL,
        [SourceServiceId] UNIQUEIDENTIFIER NOT NULL,
        [FiltersJson] NVARCHAR(MAX) NULL,
        [BillingGroupMode] VARCHAR(64) NOT NULL,
        [Mode] VARCHAR(64) NOT NULL,
        [LegalBasis] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_AutoServiceRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_AutoServiceRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_AutoServiceRules] PRIMARY KEY ([AutoServiceRuleId]),
        CONSTRAINT [FK_cat_AutoServiceRules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_AutoServiceRules_Tenant] ON [cat].[AutoServiceRules] ([TenantId]);
END;
GO
