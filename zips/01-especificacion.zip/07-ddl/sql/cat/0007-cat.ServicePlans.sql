-- cat.ServicePlans — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServicePlans', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServicePlans] (
        [ServicePlanId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ServiceId] NVARCHAR(512) NULL,
        [ServiceProductId] NVARCHAR(512) NULL,
        [ProductId] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NULL,
        [LabelKey] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [Published] NVARCHAR(512) NULL,
        [Discontinued] NVARCHAR(512) NULL,
        [Retired] NVARCHAR(512) NULL,
        [CurrentVersionId] NVARCHAR(512) NULL,
        [OfferChannels] NVARCHAR(512) NULL,
        [PublicVisibility] NVARCHAR(512) NULL,
        [OfferChannelsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServicePlans_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServicePlans_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServicePlans] PRIMARY KEY ([ServicePlanId]),
        CONSTRAINT [FK_cat_ServicePlans_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServicePlans_Tenant] ON [cat].[ServicePlans] ([TenantId]);
END;
GO
