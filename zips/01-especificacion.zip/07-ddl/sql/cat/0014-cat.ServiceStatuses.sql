-- cat.ServiceStatuses — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceStatuses', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceStatuses] (
        [ServiceStatusId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ServiceId] UNIQUEIDENTIFIER NOT NULL,
        [CanonicalStatus] VARCHAR(64) NOT NULL,
        [ImpliesDisconnection] BIT NOT NULL,
        [IsPrincipal] BIT NOT NULL,
        [VisibleToMember] BIT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceStatuses_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceStatuses_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceStatuses] PRIMARY KEY ([ServiceStatusId]),
        CONSTRAINT [FK_cat_ServiceStatuses_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceStatuses_Tenant] ON [cat].[ServiceStatuses] ([TenantId]);
END;
GO
