-- cat.BundleSubscriptions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.BundleSubscriptions', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[BundleSubscriptions] (
        [BundleSubscriptionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [BundleId] UNIQUEIDENTIFIER NOT NULL,
        [BundleVersion] INT NOT NULL,
        [HolderId] UNIQUEIDENTIFIER NOT NULL,
        [AccountId] UNIQUEIDENTIFIER NOT NULL,
        [ContractIdsId] UNIQUEIDENTIFIER NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_BundleSubscriptions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_BundleSubscriptions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_BundleSubscriptions] PRIMARY KEY ([BundleSubscriptionId]),
        CONSTRAINT [FK_cat_BundleSubscriptions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_BundleSubscriptions_Tenant] ON [cat].[BundleSubscriptions] ([TenantId]);
END;
GO
