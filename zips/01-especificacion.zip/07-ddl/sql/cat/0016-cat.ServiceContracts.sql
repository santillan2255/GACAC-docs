-- cat.ServiceContracts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceContracts', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceContracts] (
        [ServiceContractId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] NVARCHAR(512) NOT NULL,
        [ServiceId] UNIQUEIDENTIFIER NOT NULL,
        [HolderId] UNIQUEIDENTIFIER NOT NULL,
        [HolderIdentifierSnapshotJson] NVARCHAR(MAX) NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NULL,
        [AccountId] UNIQUEIDENTIFIER NOT NULL,
        [PayerAccountId] UNIQUEIDENTIFIER NULL,
        [CategoryId] UNIQUEIDENTIFIER NOT NULL,
        [CategoryHistoryJson] NVARCHAR(MAX) NOT NULL,
        [ServiceClassId] UNIQUEIDENTIFIER NULL,
        [PropertyValuesJson] NVARCHAR(MAX) NULL,
        [ActivityId] UNIQUEIDENTIFIER NULL,
        [Quantity] DECIMAL(18,4) NULL,
        [ServiceAddressJson] NVARCHAR(MAX) NOT NULL,
        [ServicePointId] UNIQUEIDENTIFIER NOT NULL,
        [PremiseId] UNIQUEIDENTIFIER NULL,
        [AddressHistoryJson] NVARCHAR(MAX) NOT NULL,
        [RouteJson] NVARCHAR(MAX) NULL,
        [SupplyCode] NVARCHAR(512) NULL,
        [MeteringPointId] UNIQUEIDENTIFIER NULL,
        [ExternalClientId] UNIQUEIDENTIFIER NULL,
        [FeasibilityRefId] UNIQUEIDENTIFIER NULL,
        [DeclaredAffidavitRefId] UNIQUEIDENTIFIER NULL,
        [GuarantorPersonId] UNIQUEIDENTIFIER NULL,
        [InstallerJson] NVARCHAR(MAX) NULL,
        [DueDate] DATETIME2(7) NULL,
        [BillingGroupId] UNIQUEIDENTIFIER NOT NULL,
        [LastBilledPeriod] NVARCHAR(512) NULL,
        [LifecycleStatus] VARCHAR(64) NOT NULL,
        [OperationalStatusId] UNIQUEIDENTIFIER NOT NULL,
        [SuspensionJson] NVARCHAR(MAX) NULL,
        [DatesJson] NVARCHAR(MAX) NOT NULL,
        [FlagsJson] NVARCHAR(MAX) NOT NULL,
        [OriginJson] NVARCHAR(MAX) NOT NULL,
        [AgreedConditionsJson] NVARCHAR(MAX) NOT NULL,
        [DomainAttributesJson] NVARCHAR(MAX) NULL,
        [CapitalAmountAtActivation] DECIMAL(18,4) NULL,
        [ParentContractId] UNIQUEIDENTIFIER NULL,
        [BundleSubscriptionId] UNIQUEIDENTIFIER NULL,
        [Observations] NVARCHAR(512) NULL,
        [SupersededByContractId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceContracts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceContracts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceContracts] PRIMARY KEY ([ServiceContractId]),
        CONSTRAINT [FK_cat_ServiceContracts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceContracts_Tenant] ON [cat].[ServiceContracts] ([TenantId]);
END;
GO
