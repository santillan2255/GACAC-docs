-- cat.ServiceCategoryGroups — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceCategoryGroups', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceCategoryGroups] (
        [ServiceCategoryGroupId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LabelKey] NVARCHAR(512) NULL,
        [RegulatoryCode] NVARCHAR(512) NULL,
        [ServiceId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceCategoryGroups_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceCategoryGroups_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceCategoryGroups] PRIMARY KEY ([ServiceCategoryGroupId]),
        CONSTRAINT [FK_cat_ServiceCategoryGroups_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceCategoryGroups_Tenant] ON [cat].[ServiceCategoryGroups] ([TenantId]);
END;
GO
