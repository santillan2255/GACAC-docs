-- cat.BillableConcepts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.BillableConcepts', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[BillableConcepts] (
        [BillableConceptId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ServiceId] UNIQUEIDENTIFIER NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [Trigger] VARCHAR(64) NOT NULL,
        [EventTypes] VARCHAR(64) NULL,
        [UnitOfMeasure] NVARCHAR(512) NOT NULL,
        [FiscalClassId] UNIQUEIDENTIFIER NOT NULL,
        [AccountingRubricId] UNIQUEIDENTIFIER NULL,
        [CostCenterId] UNIQUEIDENTIFIER NULL,
        [ThirdPartyId] UNIQUEIDENTIFIER NULL,
        [IsInternalCost] BIT NOT NULL,
        [RoundingJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_BillableConcepts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_BillableConcepts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_BillableConcepts] PRIMARY KEY ([BillableConceptId]),
        CONSTRAINT [FK_cat_BillableConcepts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_BillableConcepts_Tenant] ON [cat].[BillableConcepts] ([TenantId]);
END;
GO
