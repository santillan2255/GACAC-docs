-- cat.ServicePlanVersions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServicePlanVersions', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServicePlanVersions] (
        [ServicePlanVersionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [PlanId] UNIQUEIDENTIFIER NOT NULL,
        [Number] INT NOT NULL,
        [AttributesJson] NVARCHAR(MAX) NOT NULL,
        [Periodicity] VARCHAR(64) NOT NULL,
        [AllowedCategoryIdsId] UNIQUEIDENTIFIER NOT NULL,
        [ComponentsJson] NVARCHAR(MAX) NOT NULL,
        [PromotionsJson] NVARCHAR(MAX) NULL,
        [FinancingOptionsJson] NVARCHAR(MAX) NULL,
        [EquipmentJson] NVARCHAR(MAX) NULL,
        [RequirementsJson] NVARCHAR(MAX) NOT NULL,
        [TariffBindingJson] NVARCHAR(MAX) NOT NULL,
        [ConfigVersionId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServicePlanVersions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServicePlanVersions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServicePlanVersions] PRIMARY KEY ([ServicePlanVersionId]),
        CONSTRAINT [FK_cat_ServicePlanVersions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServicePlanVersions_Tenant] ON [cat].[ServicePlanVersions] ([TenantId]);
END;
GO
