-- cat.ServiceCategories — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceCategories', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceCategories] (
        [ServiceCategoryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ServiceId] UNIQUEIDENTIFIER NOT NULL,
        [GroupId] UNIQUEIDENTIFIER NULL,
        [IsSocial] BIT NOT NULL,
        [IsPrepaid] BIT NOT NULL,
        [IsResidential] BIT NULL,
        [IsGenerator] BIT NULL,
        [RegulatoryCodesJson] NVARCHAR(MAX) NULL,
        [NetworkProfileCode] NVARCHAR(512) NULL,
        [AdherentCount] INT NULL,
        [AllowsProportionalChange] BIT NULL,
        [HousingMinimumsJson] NVARCHAR(MAX) NULL,
        [ConsumeMinimumOnTermination] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceCategories_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceCategories_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceCategories] PRIMARY KEY ([ServiceCategoryId]),
        CONSTRAINT [FK_cat_ServiceCategories_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceCategories_Tenant] ON [cat].[ServiceCategories] ([TenantId]);
END;
GO
