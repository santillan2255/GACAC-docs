-- cat.ServiceContractHistory — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceContractHistory', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceContractHistory] (
        [ServiceContractHistoryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ContractId] UNIQUEIDENTIFIER NOT NULL,
        [EventType] VARCHAR(64) NOT NULL,
        [EffectiveAt] DATETIME2(7) NOT NULL,
        [RecordedAt] DATETIME2(7) NOT NULL,
        [ActorJson] NVARCHAR(MAX) NOT NULL,
        [SourceRefJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceContractHistory_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceContractHistory_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceContractHistory] PRIMARY KEY ([ServiceContractHistoryId]),
        CONSTRAINT [FK_cat_ServiceContractHistory_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceContractHistory_Tenant] ON [cat].[ServiceContractHistory] ([TenantId]);
END;
GO
