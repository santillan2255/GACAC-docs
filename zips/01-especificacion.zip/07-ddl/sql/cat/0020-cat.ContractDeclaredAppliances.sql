-- cat.ContractDeclaredAppliances — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ContractDeclaredAppliances', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ContractDeclaredAppliances] (
        [ContractDeclaredApplianceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ContractId] NVARCHAR(512) NULL,
        [TemplateRef] NVARCHAR(512) NULL,
        [ApplianceTypeId] NVARCHAR(512) NULL,
        [COD_ART] NVARCHAR(512) NULL,
        [Quantity] NVARCHAR(512) NULL,
        [CAN_ART] NVARCHAR(512) NULL,
        [Power] NVARCHAR(512) NULL,
        [PowerUnit] NVARCHAR(512) NULL,
        [Vehicle{plate, model}] NVARCHAR(512) NULL,
        [ElectricVehicle] NVARCHAR(512) NULL,
        [Brand] NVARCHAR(512) NULL,
        [MAR_ART] NVARCHAR(512) NULL,
        [SerialNumber] NVARCHAR(512) NULL,
        [SN_ART] NVARCHAR(512) NULL,
        [Model] NVARCHAR(512) NULL,
        [MD_ART] NVARCHAR(512) NULL,
        [DeclaredDate] NVARCHAR(512) NULL,
        [FEC_ART] NVARCHAR(512) NULL,
        [Use] NVARCHAR(512) NULL,
        [USU_ART] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [ESTADO] NVARCHAR(512) NULL,
        [Notes] NVARCHAR(512) NULL,
        [OBS_ART] NVARCHAR(512) NULL,
        [OBSERVA] NVARCHAR(512) NULL,
        [DeclarationDocId] NVARCHAR(512) NULL,
        [History] NVARCHAR(512) NULL,
        [HIS_ARTEFSUMS] NVARCHAR(512) NULL,
        [RecordedAt] DATETIME2(7) NULL,
        [FEC_REG] NVARCHAR(512) NULL,
        [HistoryJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ContractDeclaredAppliances_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ContractDeclaredAppliances_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ContractDeclaredAppliances] PRIMARY KEY ([ContractDeclaredApplianceId]),
        CONSTRAINT [FK_cat_ContractDeclaredAppliances_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ContractDeclaredAppliances_Tenant] ON [cat].[ContractDeclaredAppliances] ([TenantId]);
END;
GO
