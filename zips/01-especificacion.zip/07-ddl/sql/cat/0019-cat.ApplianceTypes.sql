-- cat.ApplianceTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ApplianceTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ApplianceTypes] (
        [ApplianceTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [LabelKey] NVARCHAR(512) NULL,
        [DES_ART] NVARCHAR(512) NULL,
        [IsObservation] NVARCHAR(512) NULL,
        [ES_OBSERVA] NVARCHAR(512) NULL,
        [ServiceIds] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [GasAppliance] NVARCHAR(512) NULL,
        [ElectricAppliance] NVARCHAR(512) NULL,
        [ElectricVehicle] NVARCHAR(512) NULL,
        [PowerUnit] NVARCHAR(512) NULL,
        [Kcal/h] NVARCHAR(512) NULL,
        [W] NVARCHAR(512) NULL,
        [KW] NVARCHAR(512) NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ApplianceTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ApplianceTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ApplianceTypes] PRIMARY KEY ([ApplianceTypeId]),
        CONSTRAINT [FK_cat_ApplianceTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ApplianceTypes_Tenant] ON [cat].[ApplianceTypes] ([TenantId]);
END;
GO
