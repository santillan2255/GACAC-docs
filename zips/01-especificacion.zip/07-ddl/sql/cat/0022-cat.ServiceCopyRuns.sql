-- cat.ServiceCopyRuns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceCopyRuns', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceCopyRuns] (
        [ServiceCopyRunId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TargetTenantId] UNIQUEIDENTIFIER NOT NULL,
        [TargetServiceId] UNIQUEIDENTIFIER NULL,
        [TargetMode] VARCHAR(64) NOT NULL,
        [ComponentsJson] NVARCHAR(MAX) NOT NULL,
        [DependenciesJson] NVARCHAR(MAX) NOT NULL,
        [Excluded] NVARCHAR(512) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [AuthorizationJson] NVARCHAR(MAX) NOT NULL,
        [IdempotencyKey] NVARCHAR(512) NOT NULL,
        [ResultJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceCopyRuns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceCopyRuns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceCopyRuns] PRIMARY KEY ([ServiceCopyRunId]),
        CONSTRAINT [FK_cat_ServiceCopyRuns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceCopyRuns_Tenant] ON [cat].[ServiceCopyRuns] ([TenantId]);
END;
GO
