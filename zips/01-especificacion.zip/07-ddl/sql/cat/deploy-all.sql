-- Esquema cat

:r cat/0001-cat.ServiceCapabilities.sql
:r cat/0002-cat.TenantServices.sql
:r cat/0003-cat.ServiceConfigVersions.sql
:r cat/0004-cat.ServiceConcessions.sql
:r cat/0005-cat.ServiceProducts.sql
:r cat/0006-cat.BillableConcepts.sql
:r cat/0007-cat.ServicePlans.sql
:r cat/0008-cat.ServicePlanVersions.sql
:r cat/0009-cat.ServiceBundles.sql
:r cat/0010-cat.ServiceCategories.sql
:r cat/0011-cat.ServiceCategoryGroups.sql
:r cat/0012-cat.ServiceClasses.sql
:r cat/0013-cat.ServiceProperties.sql
:r cat/0014-cat.ServiceStatuses.sql
:r cat/0015-cat.AutoServiceRules.sql
:r cat/0016-cat.ServiceContracts.sql
:r cat/0017-cat.ServiceContractHistory.sql
:r cat/0018-cat.ContractEquipmentAssignments.sql
:r cat/0019-cat.ApplianceTypes.sql
:r cat/0020-cat.ContractDeclaredAppliances.sql
:r cat/0021-cat.ContractSpecialConditions.sql
:r cat/0022-cat.ServiceCopyRuns.sql
:r cat/0023-cat.BulkContractOperations.sql
:r cat/0024-cat.ServiceTemplates.sql
:r cat/0025-cat.BundleSubscriptions.sql
