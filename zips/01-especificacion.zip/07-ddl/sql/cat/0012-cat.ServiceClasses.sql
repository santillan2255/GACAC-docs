-- cat.ServiceClasses — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceClasses', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceClasses] (
        [ServiceClassId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ServiceId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LabelKey] NVARCHAR(512) NULL,
        [Value1] NVARCHAR(MAX) NULL,
        [Value2] NVARCHAR(MAX) NULL,
        [Notes] NVARCHAR(MAX) NULL,
        [ThirdPartyConceptId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceClasses_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceClasses_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceClasses] PRIMARY KEY ([ServiceClassId]),
        CONSTRAINT [FK_cat_ServiceClasses_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceClasses_Tenant] ON [cat].[ServiceClasses] ([TenantId]);
END;
GO
