-- cat.ServiceBundles — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceBundles', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceBundles] (
        [ServiceBundleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LabelKey] NVARCHAR(512) NULL,
        [PlanVersionIdsId] UNIQUEIDENTIFIER NULL,
        [Rules] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceBundles_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceBundles_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceBundles] PRIMARY KEY ([ServiceBundleId]),
        CONSTRAINT [FK_cat_ServiceBundles_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cat_ServiceBundles_Tenant] ON [cat].[ServiceBundles] ([TenantId]);
END;
GO
