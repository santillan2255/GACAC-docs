-- cat.ServiceCapabilities — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cat.ServiceCapabilities', N'U') IS NULL
BEGIN
    CREATE TABLE [cat].[ServiceCapabilities] (
        [ServiceCapabilityId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Domain] VARCHAR(64) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Maturity] VARCHAR(64) NOT NULL,
        [RegistrationProfiles] VARCHAR(64) NOT NULL,
        [CalculationTypes] INT NOT NULL,
        [UnitKinds] VARCHAR(64) NOT NULL,
        [DomainAttributeSchemaJson] NVARCHAR(MAX) NOT NULL,
        [DomainSheetJson] NVARCHAR(MAX) NOT NULL,
        [RequiredPlatformModules] NVARCHAR(512) NOT NULL,
        [SensitiveData] BIT NOT NULL,
        [InsumosPendientes] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceCapabilities_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cat_ServiceCapabilities_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cat_ServiceCapabilities] PRIMARY KEY ([ServiceCapabilityId])
    );
END;
GO
