-- cmp.SupplyBalances — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SupplyBalances', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SupplyBalances] (
        [SupplyBalanceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NULL,
        [ServiceId] UNIQUEIDENTIFIER NULL,
        [ZoneId] UNIQUEIDENTIFIER NULL,
        [Period] NVARCHAR(MAX) NULL,
        [PurchasedQty] DECIMAL(18,4) NULL,
        [BoundaryMeasuredQty] DECIMAL(18,4) NULL,
        [BilledToUsersQty] DECIMAL(18,4) NULL,
        [LossQty] DECIMAL(18,4) NULL,
        [LossPct] DECIMAL(18,4) NULL,
        [InvoiceIdsJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NULL,
        [ApprovedById] UNIQUEIDENTIFIER NULL,
        [ApprovedAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplyBalances_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplyBalances_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SupplyBalances] PRIMARY KEY ([SupplyBalanceId]),
        CONSTRAINT [FK_cmp_SupplyBalances_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SupplyBalances_Tenant] ON [cmp].[SupplyBalances] ([TenantId]);
END;
GO
