-- cmp.SupplyRequests — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SupplyRequests', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SupplyRequests] (
        [SupplyRequestId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] NVARCHAR(512) NOT NULL,
        [OriginJson] NVARCHAR(MAX) NOT NULL,
        [Criticality] VARCHAR(64) NOT NULL,
        [Modality] VARCHAR(64) NOT NULL,
        [ItemsJson] NVARCHAR(MAX) NOT NULL,
        [EstimatedTotal] DECIMAL(18,4) NOT NULL,
        [ApprovalJson] NVARCHAR(MAX) NULL,
        [TakenByPurchasingAt] DATETIME2(7) NULL,
        [ExportedForSignatureJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplyRequests_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplyRequests_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SupplyRequests] PRIMARY KEY ([SupplyRequestId]),
        CONSTRAINT [FK_cmp_SupplyRequests_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SupplyRequests_Tenant] ON [cmp].[SupplyRequests] ([TenantId]);
END;
GO
