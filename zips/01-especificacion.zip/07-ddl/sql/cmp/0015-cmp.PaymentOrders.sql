-- cmp.PaymentOrders — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.PaymentOrders', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[PaymentOrders] (
        [PaymentOrderId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] NVARCHAR(512) NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [ApplicationsJson] NVARCHAR(MAX) NOT NULL,
        [CreditApplicationsJson] NVARCHAR(MAX) NULL,
        [NewAdvancesJson] NVARCHAR(MAX) NULL,
        [DiscountJson] NVARCHAR(MAX) NULL,
        [WithholdingsJson] NVARCHAR(MAX) NOT NULL,
        [TotalsJson] NVARCHAR(MAX) NOT NULL,
        [SupplierBankAccountId] UNIQUEIDENTIFIER NULL,
        [ApprovalJson] NVARCHAR(MAX) NOT NULL,
        [ExecutionJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PaymentOrders_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PaymentOrders_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_PaymentOrders] PRIMARY KEY ([PaymentOrderId]),
        CONSTRAINT [FK_cmp_PaymentOrders_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_PaymentOrders_Tenant] ON [cmp].[PaymentOrders] ([TenantId]);
END;
GO
