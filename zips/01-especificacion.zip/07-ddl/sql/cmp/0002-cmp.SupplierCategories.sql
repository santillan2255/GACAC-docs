-- cmp.SupplierCategories — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SupplierCategories', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SupplierCategories] (
        [SupplierCategoryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [ShortName] NVARCHAR(512) NULL,
        [BankCode] NVARCHAR(512) NULL,
        [AllowsDeferredPayment] BIT NULL,
        [Kind] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierCategories_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierCategories_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SupplierCategories] PRIMARY KEY ([SupplierCategoryId]),
        CONSTRAINT [FK_cmp_SupplierCategories_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SupplierCategories_Tenant] ON [cmp].[SupplierCategories] ([TenantId]);
END;
GO
