-- cmp.MatchExceptions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.MatchExceptions', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[MatchExceptions] (
        [MatchExceptionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [InvoiceId] UNIQUEIDENTIFIER NULL,
        [InvoiceItemId] UNIQUEIDENTIFIER NULL,
        [PurchaseOrderId] UNIQUEIDENTIFIER NULL,
        [ReceiptId] UNIQUEIDENTIFIER NULL,
        [Type] VARCHAR(64) NULL,
        [Expected] NVARCHAR(MAX) NULL,
        [Actual] NVARCHAR(MAX) NULL,
        [Difference] NVARCHAR(MAX) NULL,
        [AmountInDispute] NVARCHAR(MAX) NULL,
        [Cause] NVARCHAR(MAX) NULL,
        [Decision] VARCHAR(64) NULL,
        [WorkflowInstanceId] UNIQUEIDENTIFIER NULL,
        [DecidedById] UNIQUEIDENTIFIER NULL,
        [DecidedAt] DATETIME2(7) NULL,
        [Note] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_MatchExceptions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_MatchExceptions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_MatchExceptions] PRIMARY KEY ([MatchExceptionId]),
        CONSTRAINT [FK_cmp_MatchExceptions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_MatchExceptions_Tenant] ON [cmp].[MatchExceptions] ([TenantId]);
END;
GO
