-- cmp.PurchaseDocumentLinks — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.PurchaseDocumentLinks', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[PurchaseDocumentLinks] (
        [PurchaseDocumentLinkId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [OriginType] VARCHAR(64) NULL,
        [OriginId] UNIQUEIDENTIFIER NULL,
        [OriginItemId] UNIQUEIDENTIFIER NULL,
        [TargetType] NVARCHAR(MAX) NULL,
        [TargetId] UNIQUEIDENTIFIER NULL,
        [TargetItemId] UNIQUEIDENTIFIER NULL,
        [Quantity] DECIMAL(18,4) NULL,
        [OriginPrice] DECIMAL(18,4) NULL,
        [TargetPrice] DECIMAL(18,4) NULL,
        [CreatedAt] DATETIME2(7) NULL,
        [UndoneAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PurchaseDocumentLinks_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_PurchaseDocumentLinks] PRIMARY KEY ([PurchaseDocumentLinkId]),
        CONSTRAINT [FK_cmp_PurchaseDocumentLinks_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_PurchaseDocumentLinks_Tenant] ON [cmp].[PurchaseDocumentLinks] ([TenantId]);
END;
GO
