-- cmp.SupplierAdvances — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SupplierAdvances', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SupplierAdvances] (
        [SupplierAdvanceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SupplierId] UNIQUEIDENTIFIER NULL,
        [PaymentOrderId] UNIQUEIDENTIFIER NULL,
        [ConceptId] UNIQUEIDENTIFIER NULL,
        [Amount] DECIMAL(18,4) NULL,
        [AppliedAmount] DECIMAL(18,4) NULL,
        [InstallmentsJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierAdvances_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierAdvances_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SupplierAdvances] PRIMARY KEY ([SupplierAdvanceId]),
        CONSTRAINT [FK_cmp_SupplierAdvances_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SupplierAdvances_Tenant] ON [cmp].[SupplierAdvances] ([TenantId]);
END;
GO
