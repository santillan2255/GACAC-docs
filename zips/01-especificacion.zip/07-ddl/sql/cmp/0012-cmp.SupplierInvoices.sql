-- cmp.SupplierInvoices — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SupplierInvoices', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SupplierInvoices] (
        [SupplierInvoiceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SupplierId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [DueDatesJson] NVARCHAR(MAX) NOT NULL,
        [AuthorizationJson] NVARCHAR(MAX) NULL,
        [AmountsJson] NVARCHAR(MAX) NOT NULL,
        [VatTakenPct] DECIMAL(18,4) NULL,
        [ItemsJson] NVARCHAR(MAX) NOT NULL,
        [FuelJson] NVARCHAR(MAX) NULL,
        [WholesaleSupplyJson] NVARCHAR(MAX) NULL,
        [SignalRightsSettlementId] UNIQUEIDENTIFIER NULL,
        [SeparateInVatBook] NVARCHAR(MAX) NULL,
        [CustomerServiceRefJson] NVARCHAR(MAX) NULL,
        [HousingCategoryCheck] BIT NULL,
        [Source] VARCHAR(64) NOT NULL,
        [SourceRefsJson] NVARCHAR(MAX) NULL,
        [MatchStatus] VARCHAR(64) NOT NULL,
        [PaymentReleaseJson] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierInvoices_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierInvoices_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SupplierInvoices] PRIMARY KEY ([SupplierInvoiceId]),
        CONSTRAINT [FK_cmp_SupplierInvoices_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SupplierInvoices_Tenant] ON [cmp].[SupplierInvoices] ([TenantId]);
END;
GO
