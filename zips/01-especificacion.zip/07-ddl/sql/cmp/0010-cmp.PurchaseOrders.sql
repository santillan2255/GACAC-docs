-- cmp.PurchaseOrders — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.PurchaseOrders', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[PurchaseOrders] (
        [PurchaseOrderId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] NVARCHAR(512) NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [BlanketOrderId] UNIQUEIDENTIFIER NOT NULL,
        [SupplierId] UNIQUEIDENTIFIER NOT NULL,
        [ItemsJson] NVARCHAR(MAX) NOT NULL,
        [TotalsJson] NVARCHAR(MAX) NOT NULL,
        [BlanketLimitsJson] NVARCHAR(MAX) NOT NULL,
        [ApprovalJson] NVARCHAR(MAX) NOT NULL,
        [FundCommitmentRef] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PurchaseOrders_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PurchaseOrders_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_PurchaseOrders] PRIMARY KEY ([PurchaseOrderId]),
        CONSTRAINT [FK_cmp_PurchaseOrders_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_PurchaseOrders_Tenant] ON [cmp].[PurchaseOrders] ([TenantId]);
END;
GO
