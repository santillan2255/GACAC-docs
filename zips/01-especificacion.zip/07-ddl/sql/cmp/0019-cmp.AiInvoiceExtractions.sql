-- cmp.AiInvoiceExtractions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.AiInvoiceExtractions', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[AiInvoiceExtractions] (
        [AiInvoiceExtractionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [StoredFileId] UNIQUEIDENTIFIER NULL,
        [Model] NVARCHAR(MAX) NULL,
        [RequestedById] UNIQUEIDENTIFIER NULL,
        [RequestedAt] DATETIME2(7) NULL,
        [FieldsJson] NVARCHAR(MAX) NULL,
        [ProposedSupplierId] UNIQUEIDENTIFIER NULL,
        [ProposedItemsJson] NVARCHAR(MAX) NULL,
        [Tokens] NVARCHAR(MAX) NULL,
        [Outcome] VARCHAR(64) NULL,
        [InvoiceId] UNIQUEIDENTIFIER NULL,
        [CorrectionsJson] NVARCHAR(MAX) NULL,
        [AiUsageLogId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_AiInvoiceExtractions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_AiInvoiceExtractions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_AiInvoiceExtractions] PRIMARY KEY ([AiInvoiceExtractionId]),
        CONSTRAINT [FK_cmp_AiInvoiceExtractions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_AiInvoiceExtractions_Tenant] ON [cmp].[AiInvoiceExtractions] ([TenantId]);
END;
GO
