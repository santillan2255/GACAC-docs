-- cmp.SupplierEvaluations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SupplierEvaluations', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SupplierEvaluations] (
        [SupplierEvaluationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SupplierId] UNIQUEIDENTIFIER NULL,
        [UserId] UNIQUEIDENTIFIER NULL,
        [Date] DATETIME2(7) NULL,
        [Quality] NVARCHAR(MAX) NULL,
        [Score] NVARCHAR(MAX) NULL,
        [Note] NVARCHAR(MAX) NULL,
        [SourceDocument] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierEvaluations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierEvaluations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SupplierEvaluations] PRIMARY KEY ([SupplierEvaluationId]),
        CONSTRAINT [FK_cmp_SupplierEvaluations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SupplierEvaluations_Tenant] ON [cmp].[SupplierEvaluations] ([TenantId]);
END;
GO
