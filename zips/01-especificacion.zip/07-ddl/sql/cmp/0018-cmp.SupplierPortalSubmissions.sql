-- cmp.SupplierPortalSubmissions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SupplierPortalSubmissions', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SupplierPortalSubmissions] (
        [SupplierPortalSubmissionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TaxId] NVARCHAR(512) NULL,
        [LegalName] NVARCHAR(512) NULL,
        [SupplierId] UNIQUEIDENTIFIER NULL,
        [DocumentType] NVARCHAR(MAX) NULL,
        [PointOfSale] NVARCHAR(MAX) NULL,
        [Number] INT NULL,
        [IssueDate] DATETIME2(7) NULL,
        [DueDate] DATETIME2(7) NULL,
        [Amount] DECIMAL(18,4) NULL,
        [StoredFileId] UNIQUEIDENTIFIER NULL,
        [SubmittedById] UNIQUEIDENTIFIER NULL,
        [SubmittedAt] DATETIME2(7) NULL,
        [ReviewJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierPortalSubmissions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierPortalSubmissions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SupplierPortalSubmissions] PRIMARY KEY ([SupplierPortalSubmissionId]),
        CONSTRAINT [FK_cmp_SupplierPortalSubmissions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SupplierPortalSubmissions_Tenant] ON [cmp].[SupplierPortalSubmissions] ([TenantId]);
END;
GO
