-- cmp.SupplierCorrespondence — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SupplierCorrespondence', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SupplierCorrespondence] (
        [SupplierCorrespondenceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SupplierIdsJson] NVARCHAR(MAX) NULL,
        [Kind] VARCHAR(64) NULL,
        [TemplateId] UNIQUEIDENTIFIER NULL,
        [Subject] NVARCHAR(512) NULL,
        [Body] NVARCHAR(MAX) NULL,
        [SentAt] DATETIME2(7) NULL,
        [DeliveriesJson] NVARCHAR(MAX) NULL,
        [CommunicationId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierCorrespondence_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierCorrespondence_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SupplierCorrespondence] PRIMARY KEY ([SupplierCorrespondenceId]),
        CONSTRAINT [FK_cmp_SupplierCorrespondence_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SupplierCorrespondence_Tenant] ON [cmp].[SupplierCorrespondence] ([TenantId]);
END;
GO
