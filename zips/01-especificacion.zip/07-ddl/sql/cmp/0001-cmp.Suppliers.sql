-- cmp.Suppliers — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.Suppliers', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[Suppliers] (
        [SupplierId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NOT NULL,
        [IdentitySnapshotJson] NVARCHAR(MAX) NULL,
        [TaxId] NVARCHAR(MAX) NULL,
        [VatConditionCode] NVARCHAR(MAX) NULL,
        [GrossIncomeJson] NVARCHAR(MAX) NULL,
        [Addresses] NVARCHAR(MAX) NULL,
        [ContactsJson] NVARCHAR(MAX) NULL,
        [BankAccountsJson] NVARCHAR(MAX) NULL,
        [ProductTypeIdsId] UNIQUEIDENTIFIER NULL,
        [AuthorizedPersonsJson] NVARCHAR(MAX) NULL,
        [CategoryAssignmentsJson] NVARCHAR(MAX) NULL,
        [NotesJson] NVARCHAR(MAX) NULL,
        [LinkedAccountsJson] NVARCHAR(MAX) NULL,
        [PaysOthers] BIT NOT NULL,
        [DefaultPaymentTermsJson] NVARCHAR(MAX) NULL,
        [AccountingAccountId] UNIQUEIDENTIFIER NULL,
        [DocumentsJson] NVARCHAR(MAX) NULL,
        [PortalJson] NVARCHAR(MAX) NULL,
        [PerformanceJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_Suppliers_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_Suppliers_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_Suppliers] PRIMARY KEY ([SupplierId]),
        CONSTRAINT [FK_cmp_Suppliers_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_Suppliers_Tenant] ON [cmp].[Suppliers] ([TenantId]);
END;
GO
