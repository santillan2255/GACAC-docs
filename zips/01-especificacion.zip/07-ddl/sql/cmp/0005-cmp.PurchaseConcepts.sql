-- cmp.PurchaseConcepts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.PurchaseConcepts', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[PurchaseConcepts] (
        [PurchaseConceptId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [PrintName] NVARCHAR(512) NULL,
        [Unit] NVARCHAR(MAX) NULL,
        [AccountingCategoryId] UNIQUEIDENTIFIER NULL,
        [VatRateCode] NVARCHAR(512) NULL,
        [NonTaxed] NVARCHAR(MAX) NULL,
        [Type] NVARCHAR(MAX) NULL,
        [VatType] NVARCHAR(MAX) NULL,
        [GrossIncomeCode] NVARCHAR(512) NULL,
        [Active] BIT NULL,
        [VatRateId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PurchaseConcepts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PurchaseConcepts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_PurchaseConcepts] PRIMARY KEY ([PurchaseConceptId]),
        CONSTRAINT [FK_cmp_PurchaseConcepts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_PurchaseConcepts_Tenant] ON [cmp].[PurchaseConcepts] ([TenantId]);
END;
GO
