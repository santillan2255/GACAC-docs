-- cmp.SignalRightsSettlements — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SignalRightsSettlements', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SignalRightsSettlements] (
        [SignalRightsSettlementId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ContractId] UNIQUEIDENTIFIER NULL,
        [SupplierId] UNIQUEIDENTIFIER NULL,
        [Period] NVARCHAR(MAX) NULL,
        [CutoffDate] DATETIME2(7) NULL,
        [LinesJson] NVARCHAR(MAX) NULL,
        [MinimumApplied] NVARCHAR(MAX) NULL,
        [Total] DECIMAL(18,4) NULL,
        [AdjustsSettlementId] UNIQUEIDENTIFIER NULL,
        [ReportRef] NVARCHAR(512) NULL,
        [DeclarationStoredFileId] UNIQUEIDENTIFIER NULL,
        [InvoiceId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NULL,
        [ApprovedById] UNIQUEIDENTIFIER NULL,
        [ApprovedAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SignalRightsSettlements_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SignalRightsSettlements_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SignalRightsSettlements] PRIMARY KEY ([SignalRightsSettlementId]),
        CONSTRAINT [FK_cmp_SignalRightsSettlements_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SignalRightsSettlements_Tenant] ON [cmp].[SignalRightsSettlements] ([TenantId]);
END;
GO
