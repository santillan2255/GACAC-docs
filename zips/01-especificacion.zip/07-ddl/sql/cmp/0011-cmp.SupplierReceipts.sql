-- cmp.SupplierReceipts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SupplierReceipts', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SupplierReceipts] (
        [SupplierReceiptId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] INT NULL,
        [SupplierDocumentJson] NVARCHAR(MAX) NULL,
        [SupplierId] UNIQUEIDENTIFIER NULL,
        [Date] DATETIME2(7) NULL,
        [Kind] VARCHAR(64) NULL,
        [WarehouseId] UNIQUEIDENTIFIER NULL,
        [ReceiverId] UNIQUEIDENTIFIER NULL,
        [ItemsJson] NVARCHAR(MAX) NULL,
        [StockStatus] VARCHAR(64) NULL,
        [StockMovementIdsJson] NVARCHAR(MAX) NULL,
        [Status] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierReceipts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierReceipts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SupplierReceipts] PRIMARY KEY ([SupplierReceiptId]),
        CONSTRAINT [FK_cmp_SupplierReceipts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SupplierReceipts_Tenant] ON [cmp].[SupplierReceipts] ([TenantId]);
END;
GO
