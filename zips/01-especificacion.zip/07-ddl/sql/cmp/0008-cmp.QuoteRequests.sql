-- cmp.QuoteRequests — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.QuoteRequests', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[QuoteRequests] (
        [QuoteRequestId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [{ number, groupId, sourcingEventId?, supplierId, date, dueDate, currency, exchangeRate, sentAt, sentChannel, status, rejectReason, items[{ itemId, productId?, conceptId?, description, quantity, unitCost, previousCost, validityDays, leadTimeDays, note, criticality, pendingQty, evaluation: pending|awarded|discarded, awardedQty, justification }] }] NVARCHAR(512) NULL,
        [{tenantId, groupId}] NVARCHAR(512) NULL,
        [{tenantId, supplierId, status}] NVARCHAR(512) NULL,
        [SCOTIZ] NVARCHAR(512) NULL,
        [FECHA] NVARCHAR(512) NULL,
        [HORA] NVARCHAR(512) NULL,
        [COD_COM] NVARCHAR(512) NULL,
        [SUC_COM] NVARCHAR(512) NULL,
        [NUM_COM] NVARCHAR(512) NULL,
        [COD_PROV] NVARCHAR(512) NULL,
        [USU_GEN] NVARCHAR(512) NULL,
        [OBSE] NVARCHAR(512) NULL,
        [FVTO] NVARCHAR(512) NULL,
        [ESTADO] NVARCHAR(512) NULL,
        [TIP_MON] NVARCHAR(512) NULL,
        [COTIZ] NVARCHAR(512) NULL,
        [IT_SCOTIZ] NVARCHAR(512) NULL,
        [COD_PROD] NVARCHAR(512) NULL,
        [PRO_CON] NVARCHAR(512) NULL,
        [CANT] NVARCHAR(512) NULL,
        [COSTO] NVARCHAR(512) NULL,
        [PRE_ANT] NVARCHAR(512) NULL,
        [VALIDEZ] NVARCHAR(512) NULL,
        [CAN_PEN] NVARCHAR(512) NULL,
        [DES_PRO] NVARCHAR(512) NULL,
        [OBSE2] NVARCHAR(512) NULL,
        [CRITICIDAD] NVARCHAR(512) NULL,
        [Number] INT NULL,
        [GroupId] UNIQUEIDENTIFIER NULL,
        [SourcingEventId] UNIQUEIDENTIFIER NULL,
        [SupplierId] UNIQUEIDENTIFIER NULL,
        [Date] DATETIME2(7) NULL,
        [DueDate] DATETIME2(7) NULL,
        [Currency] NVARCHAR(MAX) NULL,
        [ExchangeRate] DECIMAL(18,4) NULL,
        [SentAt] DATETIME2(7) NULL,
        [SentChannel] NVARCHAR(MAX) NULL,
        [Status] NVARCHAR(MAX) NULL,
        [RejectReason] NVARCHAR(512) NULL,
        [ItemsJson] NVARCHAR(MAX) NULL,
        [SupplierIdsId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_QuoteRequests_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_QuoteRequests_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_QuoteRequests] PRIMARY KEY ([QuoteRequestId]),
        CONSTRAINT [FK_cmp_QuoteRequests_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_QuoteRequests_Tenant] ON [cmp].[QuoteRequests] ([TenantId]);
END;
GO
