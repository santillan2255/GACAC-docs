-- cmp.PurchaseLookups — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.PurchaseLookups', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[PurchaseLookups] (
        [PurchaseLookupId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [Notes] NVARCHAR(512) NULL,
        [Thresholds] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PurchaseLookups_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PurchaseLookups_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_PurchaseLookups] PRIMARY KEY ([PurchaseLookupId]),
        CONSTRAINT [FK_cmp_PurchaseLookups_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_PurchaseLookups_Tenant] ON [cmp].[PurchaseLookups] ([TenantId]);
END;
GO
