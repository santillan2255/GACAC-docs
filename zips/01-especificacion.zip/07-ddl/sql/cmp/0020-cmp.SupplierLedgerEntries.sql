-- cmp.SupplierLedgerEntries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SupplierLedgerEntries', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SupplierLedgerEntries] (
        [SupplierLedgerEntryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SupplierId] UNIQUEIDENTIFIER NULL,
        [Date] DATETIME2(7) NULL,
        [DocumentType] NVARCHAR(MAX) NULL,
        [DocumentId] UNIQUEIDENTIFIER NULL,
        [Debit] NVARCHAR(MAX) NULL,
        [Credit] NVARCHAR(MAX) NULL,
        [BalanceAfter] NVARCHAR(MAX) NULL,
        [DueDate] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierLedgerEntries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SupplierLedgerEntries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SupplierLedgerEntries] PRIMARY KEY ([SupplierLedgerEntryId]),
        CONSTRAINT [FK_cmp_SupplierLedgerEntries_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SupplierLedgerEntries_Tenant] ON [cmp].[SupplierLedgerEntries] ([TenantId]);
END;
GO
