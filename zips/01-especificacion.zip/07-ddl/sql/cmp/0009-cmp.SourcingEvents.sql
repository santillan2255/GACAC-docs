-- cmp.SourcingEvents — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SourcingEvents', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SourcingEvents] (
        [SourcingEventId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [{ number] NVARCHAR(512) NULL,
        [Number] INT NULL,
        [Modality] NVARCHAR(MAX) NULL,
        [Title] NVARCHAR(MAX) NULL,
        [SpecStoredFileIdsJson] NVARCHAR(MAX) NULL,
        [InvitedSupplierIdsJson] NVARCHAR(MAX) NULL,
        [InvitationTemplateId] UNIQUEIDENTIFIER NULL,
        [OffersDueAt] DATETIME2(7) NULL,
        [OpenedAt] DATETIME2(7) NULL,
        [OpeningActJson] NVARCHAR(MAX) NULL,
        [AwardSheetJson] NVARCHAR(MAX) NULL,
        [DossierCoverStoredFileId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NULL,
        [QuoteRequestId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SourcingEvents_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SourcingEvents_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SourcingEvents] PRIMARY KEY ([SourcingEventId]),
        CONSTRAINT [FK_cmp_SourcingEvents_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SourcingEvents_Tenant] ON [cmp].[SourcingEvents] ([TenantId]);
END;
GO
