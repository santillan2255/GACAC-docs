-- cmp.PurchaseForecasts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.PurchaseForecasts', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[PurchaseForecasts] (
        [PurchaseForecastId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SupplierId] UNIQUEIDENTIFIER NULL,
        [ConceptId] UNIQUEIDENTIFIER NULL,
        [ProductId] UNIQUEIDENTIFIER NULL,
        [From] DATETIME2(7) NULL,
        [To] DATETIME2(7) NULL,
        [Periodicity] VARCHAR(64) NULL,
        [Amount] DECIMAL(18,4) NULL,
        [Currency] NVARCHAR(MAX) NULL,
        [ServiceCode] NVARCHAR(512) NULL,
        [CostCenterId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PurchaseForecasts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_PurchaseForecasts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_PurchaseForecasts] PRIMARY KEY ([PurchaseForecastId]),
        CONSTRAINT [FK_cmp_PurchaseForecasts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_PurchaseForecasts_Tenant] ON [cmp].[PurchaseForecasts] ([TenantId]);
END;
GO
