-- Esquema cmp

:r cmp/0001-cmp.Suppliers.sql
:r cmp/0002-cmp.SupplierCategories.sql
:r cmp/0003-cmp.SupplierEvaluations.sql
:r cmp/0004-cmp.SupplierCorrespondence.sql
:r cmp/0005-cmp.PurchaseConcepts.sql
:r cmp/0006-cmp.PurchaseLookups.sql
:r cmp/0007-cmp.SupplyRequests.sql
:r cmp/0008-cmp.QuoteRequests.sql
:r cmp/0009-cmp.SourcingEvents.sql
:r cmp/0010-cmp.PurchaseOrders.sql
:r cmp/0011-cmp.SupplierReceipts.sql
:r cmp/0012-cmp.SupplierInvoices.sql
:r cmp/0013-cmp.PurchaseDocumentLinks.sql
:r cmp/0014-cmp.MatchExceptions.sql
:r cmp/0015-cmp.PaymentOrders.sql
:r cmp/0016-cmp.SupplierAdvances.sql
:r cmp/0017-cmp.PurchaseForecasts.sql
:r cmp/0018-cmp.SupplierPortalSubmissions.sql
:r cmp/0019-cmp.AiInvoiceExtractions.sql
:r cmp/0020-cmp.SupplierLedgerEntries.sql
:r cmp/0021-cmp.SupplyBalances.sql
:r cmp/0022-cmp.SignalRightsContracts.sql
:r cmp/0023-cmp.SignalRightsSettlements.sql
