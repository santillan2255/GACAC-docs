-- cmp.SignalRightsContracts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cmp.SignalRightsContracts', N'U') IS NULL
BEGIN
    CREATE TABLE [cmp].[SignalRightsContracts] (
        [SignalRightsContractId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SupplierId] UNIQUEIDENTIFIER NULL,
        [SignalsJson] NVARCHAR(MAX) NULL,
        [PackageIdsJson] NVARCHAR(MAX) NULL,
        [PricePerSubscriber] NVARCHAR(MAX) NULL,
        [Currency] NVARCHAR(MAX) NULL,
        [MinimumGuaranteed] NVARCHAR(MAX) NULL,
        [CountBasis] VARCHAR(64) NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [ValidTo] DATETIME2(7) NULL,
        [Status] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SignalRightsContracts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cmp_SignalRightsContracts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cmp_SignalRightsContracts] PRIMARY KEY ([SignalRightsContractId]),
        CONSTRAINT [FK_cmp_SignalRightsContracts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cmp_SignalRightsContracts_Tenant] ON [cmp].[SignalRightsContracts] ([TenantId]);
END;
GO
