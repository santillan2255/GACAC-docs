-- fis.WithholdingsApplied — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.WithholdingsApplied', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[WithholdingsApplied] (
        [WithholdingsAppliedId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [PaymentOrderId] UNIQUEIDENTIFIER NOT NULL,
        [SupplierPersonId] UNIQUEIDENTIFIER NOT NULL,
        [WithholdingTypeId] UNIQUEIDENTIFIER NOT NULL,
        [Date] DATETIME2(7) NOT NULL,
        [ReportingPeriod] NVARCHAR(512) NOT NULL,
        [AccumulationJson] NVARCHAR(MAX) NULL,
        [CertificateJson] NVARCHAR(MAX) NOT NULL,
        [ManualOverrideJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [FilingId] UNIQUEIDENTIFIER NULL,
        [ObligationId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_WithholdingsApplied_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_WithholdingsApplied_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_WithholdingsApplied] PRIMARY KEY ([WithholdingsAppliedId]),
        CONSTRAINT [FK_fis_WithholdingsApplied_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_WithholdingsApplied_Tenant] ON [fis].[WithholdingsApplied] ([TenantId]);
END;
GO
