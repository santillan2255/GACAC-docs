-- fis.TaxpayerRegistryEntries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.TaxpayerRegistryEntries', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[TaxpayerRegistryEntries] (
        [TaxpayerRegistryEntryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [RegistryId] NVARCHAR(512) NULL,
        [Cuit] NVARCHAR(512) NULL,
        [Cuit2] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [AccountId] NVARCHAR(512) NULL,
        [COD_SUM] NVARCHAR(512) NULL,
        [VatCode] NVARCHAR(512) NULL,
        [MonotributoCode] NVARCHAR(512) NULL,
        [GrossIncomeConditionCode] NVARCHAR(512) NULL,
        [COD_SIB] NVARCHAR(512) NULL,
        [Rate] NVARCHAR(512) NULL,
        [ALICUOTA] NVARCHAR(512) NULL,
        [GroupOrType] NVARCHAR(512) NULL,
        [TIPOC] NVARCHAR(512) NULL,
        [IBR] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ValidTo] NVARCHAR(512) NULL,
        [{tenantId, registryId, cuit}] NVARCHAR(512) NULL,
        [{tenantId, cuit, validFrom}] NVARCHAR(512) NULL,
        [IIBB_LUA] NVARCHAR(512) NULL,
        [EMPAFIP] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxpayerRegistryEntries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxpayerRegistryEntries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_TaxpayerRegistryEntries] PRIMARY KEY ([TaxpayerRegistryEntryId]),
        CONSTRAINT [FK_fis_TaxpayerRegistryEntries_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_TaxpayerRegistryEntries_Tenant] ON [fis].[TaxpayerRegistryEntries] ([TenantId]);
END;
GO
