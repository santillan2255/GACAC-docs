-- fis.ArcaReceivedImports — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.ArcaReceivedImports', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[ArcaReceivedImports] (
        [ArcaReceivedImportId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [Issued] NVARCHAR(512) NULL,
        [Received] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [Format] NVARCHAR(512) NULL,
        [Csv] NVARCHAR(512) NULL,
        [XlsxLegacy] NVARCHAR(512) NULL,
        [StoredFileId] NVARCHAR(512) NULL,
        [FileAssetId] NVARCHAR(512) NULL,
        [Rows] NVARCHAR(512) NULL,
        [{ date, arcaCbteType, pointOfSale, numberFrom, numberTo, docType, docNumber, name, exchangeRate, currency, net, untaxed, exempt, vat, total }] NVARCHAR(512) NULL,
        [Errors] NVARCHAR(512) NULL,
        [RowsJson] NVARCHAR(MAX) NULL,
        [ErrorsJson] NVARCHAR(MAX) NULL,
        [FileHash] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ArcaReceivedImports_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ArcaReceivedImports_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_ArcaReceivedImports] PRIMARY KEY ([ArcaReceivedImportId]),
        CONSTRAINT [FK_fis_ArcaReceivedImports_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_ArcaReceivedImports_Tenant] ON [fis].[ArcaReceivedImports] ([TenantId]);
END;
GO
