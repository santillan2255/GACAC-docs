-- fis.RegulatoryReportRuns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.RegulatoryReportRuns', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[RegulatoryReportRuns] (
        [RegulatoryReportRunId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ReportCode] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [Files] NVARCHAR(512) NULL,
        [Validation] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Acknowledgment] NVARCHAR(512) NULL,
        [FilesJson] NVARCHAR(MAX) NULL,
        [RectificationNo] INT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_RegulatoryReportRuns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_RegulatoryReportRuns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_RegulatoryReportRuns] PRIMARY KEY ([RegulatoryReportRunId]),
        CONSTRAINT [FK_fis_RegulatoryReportRuns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_RegulatoryReportRuns_Tenant] ON [fis].[RegulatoryReportRuns] ([TenantId]);
END;
GO
