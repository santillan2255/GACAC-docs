-- fis.WithholdingScales — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.WithholdingScales', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[WithholdingScales] (
        [WithholdingScaleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [WithholdingTypeId] NVARCHAR(512) NULL,
        [From] NVARCHAR(512) NULL,
        [IMP_MIN] NVARCHAR(512) NULL,
        [To] NVARCHAR(512) NULL,
        [IMP_MAX] NVARCHAR(512) NULL,
        [FixedAmount] NVARCHAR(512) NULL,
        [RET_PES] NVARCHAR(512) NULL,
        [Pct] NVARCHAR(512) NULL,
        [RET_POR] NVARCHAR(512) NULL,
        [Excess] NVARCHAR(512) NULL,
        [EXCEDENTE] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [CAT_RETG] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_WithholdingScales_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_WithholdingScales_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_WithholdingScales] PRIMARY KEY ([WithholdingScaleId]),
        CONSTRAINT [FK_fis_WithholdingScales_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_WithholdingScales_Tenant] ON [fis].[WithholdingScales] ([TenantId]);
END;
GO
