-- fis.NormativeAdoptions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.NormativeAdoptions', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[NormativeAdoptions] (
        [NormativeAdoptionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TableCode] NVARCHAR(512) NOT NULL,
        [PlatformVersionId] UNIQUEIDENTIFIER NOT NULL,
        [EffectiveFrom] DATETIME2(7) NOT NULL,
        [RecordedAt] DATETIME2(7) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [TenantRowsJson] NVARCHAR(MAX) NULL,
        [SimulationId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_NormativeAdoptions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_NormativeAdoptions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_NormativeAdoptions] PRIMARY KEY ([NormativeAdoptionId]),
        CONSTRAINT [FK_fis_NormativeAdoptions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_NormativeAdoptions_Tenant] ON [fis].[NormativeAdoptions] ([TenantId]);
END;
GO
