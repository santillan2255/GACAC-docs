-- fis.ConceptFiscalCases — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.ConceptFiscalCases', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[ConceptFiscalCases] (
        [ConceptFiscalCasId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ConceptId] UNIQUEIDENTIFIER NOT NULL,
        [CaseCode] VARCHAR(64) NOT NULL,
        [FiscalClass] VARCHAR(64) NOT NULL,
        [VatRateId] UNIQUEIDENTIFIER NULL,
        [WsfeBucket] VARCHAR(64) NOT NULL,
        [PublicServiceAccessory] BIT NOT NULL,
        [AccessoryApprovalJson] NVARCHAR(MAX) NULL,
        [ExcludedFromBasesJson] NVARCHAR(MAX) NOT NULL,
        [FiscalMoment] VARCHAR(64) NULL,
        [BasisJson] NVARCHAR(MAX) NOT NULL,
        [NormativeVersionId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ConceptFiscalCases_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ConceptFiscalCases_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_ConceptFiscalCases] PRIMARY KEY ([ConceptFiscalCasId]),
        CONSTRAINT [FK_fis_ConceptFiscalCases_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_ConceptFiscalCases_Tenant] ON [fis].[ConceptFiscalCases] ([TenantId]);
END;
GO
