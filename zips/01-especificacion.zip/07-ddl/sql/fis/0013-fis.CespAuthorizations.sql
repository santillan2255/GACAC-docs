-- fis.CespAuthorizations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.CespAuthorizations', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[CespAuthorizations] (
        [CespAuthorizationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [Description] NVARCHAR(512) NULL,
        [Cesp] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ValidTo] NVARCHAR(512) NULL,
        [ExpiresAt] DATETIME2(7) NULL,
        [PointOfSale] NVARCHAR(512) NULL,
        [VoucherTypeIds] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Expired] NVARCHAR(512) NULL,
        [Cancelled] NVARCHAR(512) NULL,
        [{tenantId, legalEntityId, pointOfSale, validFrom, validTo}] NVARCHAR(512) NULL,
        [CESPAFIP] NVARCHAR(512) NULL,
        [CAEA = 0] NVARCHAR(512) NULL,
        [VoucherTypeIdsId] UNIQUEIDENTIFIER NULL,
        [PointOfSaleId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_CespAuthorizations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_CespAuthorizations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_CespAuthorizations] PRIMARY KEY ([CespAuthorizationId]),
        CONSTRAINT [FK_fis_CespAuthorizations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_CespAuthorizations_Tenant] ON [fis].[CespAuthorizations] ([TenantId]);
END;
GO
