-- fis.VatLedgerLines — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.VatLedgerLines', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[VatLedgerLines] (
        [VatLedgerLineId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LedgerId] NVARCHAR(512) NULL,
        [DocumentRef] NVARCHAR(512) NULL,
        [DocumentId] NVARCHAR(512) NULL,
        [Date] NVARCHAR(512) NULL,
        [ArcaCbteType] NVARCHAR(512) NULL,
        [PointOfSale] NVARCHAR(512) NULL,
        [Number] NVARCHAR(512) NULL,
        [CounterpartyDocType] NVARCHAR(512) NULL,
        [CounterpartyDocNumber] NVARCHAR(512) NULL,
        [CounterpartyName] NVARCHAR(512) NULL,
        [VatConditionCode] NVARCHAR(512) NULL,
        [Sign] NVARCHAR(512) NULL,
        [Untaxed] NVARCHAR(512) NULL,
        [Exempt] NVARCHAR(512) NULL,
        [TaxedByRate{rate, arcaVatId, base, vat}] NVARCHAR(512) NULL,
        [Perceptions{taxDefinitionId, amount}] NVARCHAR(512) NULL,
        [OtherTaxes] NVARCHAR(512) NULL,
        [Total] NVARCHAR(512) NULL,
        [ActivityCode] NVARCHAR(512) NULL,
        [ServiceId] NVARCHAR(512) NULL,
        [BranchId] NVARCHAR(512) NULL,
        [InstallmentFinanced] NVARCHAR(512) NULL,
        [Lqsp] NVARCHAR(512) NULL,
        [{tenantId, ledgerId}] NVARCHAR(512) NULL,
        [{tenantId, documentRef}] NVARCHAR(512) NULL,
        [IVAVTA] NVARCHAR(512) NULL,
        [OtherTaxesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatLedgerLines_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatLedgerLines_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_VatLedgerLines] PRIMARY KEY ([VatLedgerLineId]),
        CONSTRAINT [FK_fis_VatLedgerLines_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_VatLedgerLines_Tenant] ON [fis].[VatLedgerLines] ([TenantId]);
END;
GO
