-- fis.ArcaSubmissions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.ArcaSubmissions', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[ArcaSubmissions] (
        [ArcaSubmissionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Operation] NVARCHAR(512) NULL,
        [FECAESolicitar] NVARCHAR(512) NULL,
        [FECAEARegInformativo] NVARCHAR(512) NULL,
        [FECAEASinMovimientoInformar] NVARCHAR(512) NULL,
        [FECompConsultar] NVARCHAR(512) NULL,
        [FECompUltimoAutorizado] NVARCHAR(512) NULL,
        [FECAEASolicitar] NVARCHAR(512) NULL,
        [FECAEAConsultar] NVARCHAR(512) NULL,
        [GetPersona] NVARCHAR(512) NULL,
        [GetIdPersonaListByDocumento] NVARCHAR(512) NULL,
        [GetPersona_v2 constancia] NVARCHAR(512) NULL,
        [FEParamGet*] NVARCHAR(512) NULL,
        [Environment] NVARCHAR(512) NULL,
        [PointOfSale] NVARCHAR(512) NULL,
        [ArcaCbteType] NVARCHAR(512) NULL,
        [RangeFrom] NVARCHAR(512) NULL,
        [RangeTo] NVARCHAR(512) NULL,
        [Count] NVARCHAR(512) NULL,
        [AuthorizationIds] NVARCHAR(512) NULL,
        [RequestMaskedRef] NVARCHAR(512) NULL,
        [ResponseMaskedRef] NVARCHAR(512) NULL,
        [HeaderResult] NVARCHAR(512) NULL,
        [Errors] NVARCHAR(512) NULL,
        [DurationMs] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Sending] NVARCHAR(512) NULL,
        [Answered] NVARCHAR(512) NULL,
        [Timeout] NVARCHAR(512) NULL,
        [TransportError] NVARCHAR(512) NULL,
        [JobId] NVARCHAR(512) NULL,
        [CorrelationId] NVARCHAR(512) NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [{tenantId, createdAt}] NVARCHAR(512) NULL,
        [{tenantId, legalEntityId, pointOfSale, arcaCbteType, rangeFrom}] NVARCHAR(512) NULL,
        [AuthorizationIdsId] UNIQUEIDENTIFIER NULL,
        [ErrorsJson] NVARCHAR(MAX) NULL,
        [IntegrationOperationId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ArcaSubmissions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ArcaSubmissions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_ArcaSubmissions] PRIMARY KEY ([ArcaSubmissionId]),
        CONSTRAINT [FK_fis_ArcaSubmissions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_ArcaSubmissions_Tenant] ON [fis].[ArcaSubmissions] ([TenantId]);
END;
GO
