-- fis.ThirdPartyAgreements — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.ThirdPartyAgreements', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[ThirdPartyAgreements] (
        [ThirdPartyAgreementId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [BeneficiaryJson] NVARCHAR(MAX) NOT NULL,
        [BasisJson] NVARCHAR(MAX) NOT NULL,
        [ConceptsJson] NVARCHAR(MAX) NOT NULL,
        [CollectionFeeJson] NVARCHAR(MAX) NULL,
        [PartialPaymentPolicy] VARCHAR(64) NOT NULL,
        [RemittanceJson] NVARCHAR(MAX) NOT NULL,
        [LiabilityLedgerAccountId] UNIQUEIDENTIFIER NOT NULL,
        [MoraPolicyJson] NVARCHAR(MAX) NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ThirdPartyAgreements_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ThirdPartyAgreements_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_ThirdPartyAgreements] PRIMARY KEY ([ThirdPartyAgreementId]),
        CONSTRAINT [FK_fis_ThirdPartyAgreements_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_ThirdPartyAgreements_Tenant] ON [fis].[ThirdPartyAgreements] ([TenantId]);
END;
GO
