-- fis.TaxCalculationTraces — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.TaxCalculationTraces', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[TaxCalculationTraces] (
        [TaxCalculationTraceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [DocumentRef] NVARCHAR(512) NULL,
        [DocumentId] NVARCHAR(512) NULL,
        [Lines] NVARCHAR(512) NULL,
        [{ itemRef, taxDefinitionId, base, rate, amount, rule, normativeVersionIds, registryEntryId, exemptionId, supplyUsageId, supplyUsageClass, skippedReason }] NVARCHAR(512) NULL,
        [SupplyUsageId] NVARCHAR(512) NULL,
        [SupplyUsageClass] NVARCHAR(512) NULL,
        [PremiseUsagesUsageClass] NVARCHAR(512) NULL,
        [Totals] NVARCHAR(512) NULL,
        [ComputedAt] DATETIME2(7) NULL,
        [EngineVersion] NVARCHAR(512) NULL,
        [{tenantId, documentRef}] NVARCHAR(512) NULL,
        [LinesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxCalculationTraces_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxCalculationTraces_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_TaxCalculationTraces] PRIMARY KEY ([TaxCalculationTraceId]),
        CONSTRAINT [FK_fis_TaxCalculationTraces_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_TaxCalculationTraces_Tenant] ON [fis].[TaxCalculationTraces] ([TenantId]);
END;
GO
