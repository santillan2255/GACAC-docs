-- fis.VatRates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.VatRates', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[VatRates] (
        [VatRateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Rate] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [Taxed] NVARCHAR(512) NULL,
        [Exempt] NVARCHAR(512) NULL,
        [Untaxed] NVARCHAR(512) NULL,
        [NotSubject] NVARCHAR(512) NULL,
        [ArcaVatId] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [ALI_IVA] NVARCHAR(512) NULL,
        [EntityAccountAssignments] NVARCHAR(512) NULL,
        [EntityType = vatRate] NVARCHAR(512) NULL,
        [Usage] NVARCHAR(512) NULL,
        [Sales] NVARCHAR(512) NULL,
        [Purchases] NVARCHAR(512) NULL,
        [SalesPerception] NVARCHAR(512) NULL,
        [Accounts{ sales, purchases, salesPerception }] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatRates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatRates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_VatRates] PRIMARY KEY ([VatRateId]),
        CONSTRAINT [FK_fis_VatRates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_VatRates_Tenant] ON [fis].[VatRates] ([TenantId]);
END;
GO
