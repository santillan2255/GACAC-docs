-- fis.ThirdPartyCharges — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.ThirdPartyCharges', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[ThirdPartyCharges] (
        [ThirdPartyChargeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AgreementId] NVARCHAR(512) NULL,
        [ConceptIndex] NVARCHAR(512) NULL,
        [InvoiceId] NVARCHAR(512) NULL,
        [DocumentId] NVARCHAR(512) NULL,
        [AccountId] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [Amount] NVARCHAR(512) NULL,
        [CollectedAmount] NVARCHAR(512) NULL,
        [Collections{ paymentId, amount, date }] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Billed] NVARCHAR(512) NULL,
        [PartiallyCollected] NVARCHAR(512) NULL,
        [Collected] NVARCHAR(512) NULL,
        [Cancelled] NVARCHAR(512) NULL,
        [RemittanceId] NVARCHAR(512) NULL,
        [{tenantId, agreementId, period}] NVARCHAR(512) NULL,
        [{tenantId, invoiceId}] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ThirdPartyCharges_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ThirdPartyCharges_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_ThirdPartyCharges] PRIMARY KEY ([ThirdPartyChargeId]),
        CONSTRAINT [FK_fis_ThirdPartyCharges_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_ThirdPartyCharges_Tenant] ON [fis].[ThirdPartyCharges] ([TenantId]);
END;
GO
