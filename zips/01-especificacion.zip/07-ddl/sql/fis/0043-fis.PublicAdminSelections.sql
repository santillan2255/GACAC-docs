-- fis.PublicAdminSelections — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.PublicAdminSelections', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[PublicAdminSelections] (
        [PublicAdminSelectionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SelectionKey] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [IssueDate] NVARCHAR(512) NULL,
        [Items] NVARCHAR(512) NULL,
        [{ documentId, serviceId, consumption, meterId, supplyAddress }] NVARCHAR(512) NULL,
        [Filters] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Replaced] NVARCHAR(512) NULL,
        [ReplacedById] NVARCHAR(512) NULL,
        [{tenantId, selectionKey, period, issueDate, status}] NVARCHAR(512) NULL,
        [COMPROBANTES_ADM] NVARCHAR(512) NULL,
        [ID_FAC] NVARCHAR(512) NULL,
        [COD_SER] NVARCHAR(512) NULL,
        [PERIODO] NVARCHAR(512) NULL,
        [FECHA] NVARCHAR(512) NULL,
        [USU_REG] NVARCHAR(512) NULL,
        [ItemsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_PublicAdminSelections_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_PublicAdminSelections_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_PublicAdminSelections] PRIMARY KEY ([PublicAdminSelectionId]),
        CONSTRAINT [FK_fis_PublicAdminSelections_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_PublicAdminSelections_Tenant] ON [fis].[PublicAdminSelections] ([TenantId]);
END;
GO
