-- fis.RegulatoryReports — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.RegulatoryReports', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[RegulatoryReports] (
        [RegulatoryReportId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [ERSEP-CIR70-2021] NVARCHAR(512) NULL,
        [ERSEP-CONSUMOS] NVARCHAR(512) NULL,
        [ERSEP-PERDIDAS] NVARCHAR(512) NULL,
        [ERSEP-SERVICIOS] NVARCHAR(512) NULL,
        [ERSEP-DNU311-2020] NVARCHAR(512) NULL,
        [ERSEP-TS-166-16] NVARCHAR(512) NULL,
        [ERSEP-TS-296-16] NVARCHAR(512) NULL,
        [ERSEP-TS-617] NVARCHAR(512) NULL,
        [ENARGAS-SARI] NVARCHAR(512) NULL,
        [ENARGAS-FCUDS] NVARCHAR(512) NULL,
        [ENARGAS-MOROSIDAD-XLS] NVARCHAR(512) NULL,
        [ENARGAS-FACTURAS-XLS] NVARCHAR(512) NULL,
        [ENACOM-*] NVARCHAR(512) NULL,
        [SE-ENERGIA] NVARCHAR(512) NULL,
        [SE-GENERADORES] NVARCHAR(512) NULL,
        [FECESCOR-RENDICION] NVARCHAR(512) NULL,
        [Organism] NVARCHAR(512) NULL,
        [Services] NVARCHAR(512) NULL,
        [Files] NVARCHAR(512) NULL,
        [FormatVersion] NVARCHAR(512) NULL,
        [Periodicity] NVARCHAR(512) NULL,
        [DeadlineRule] NVARCHAR(512) NULL,
        [MasterTablesRef] NVARCHAR(512) NULL,
        [Source] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [ServicesJson] NVARCHAR(MAX) NULL,
        [FilesJson] NVARCHAR(MAX) NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_RegulatoryReports_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_RegulatoryReports_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_RegulatoryReports] PRIMARY KEY ([RegulatoryReportId])
    );
END;
GO
