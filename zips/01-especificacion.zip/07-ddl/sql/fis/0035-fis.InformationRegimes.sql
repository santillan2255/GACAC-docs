-- fis.InformationRegimes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.InformationRegimes', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[InformationRegimes] (
        [InformationRegimeId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [LID-RG4597] NVARCHAR(512) NULL,
        [RG3685] NVARCHAR(512) NULL,
        [RG1361] NVARCHAR(512) NULL,
        [RG3349] NVARCHAR(512) NULL,
        [RG3571] NVARCHAR(512) NULL,
        [RG46-2019] NVARCHAR(512) NULL,
        [RG5746-2025] NVARCHAR(512) NULL,
        [CIR70-2021-ERSEP] NVARCHAR(512) NULL,
        [SICORE] NVARCHAR(512) NULL,
        [SIRE-F2004] NVARCHAR(512) NULL,
        [SIRE-F2005] NVARCHAR(512) NULL,
        [SIRCAR] NVARCHAR(512) NULL,
        [ARBA] NVARCHAR(512) NULL,
        [A122R] NVARCHAR(512) NULL,
        [SANTAFE] NVARCHAR(512) NULL,
        [LAPAMPA] NVARCHAR(512) NULL,
        [RIONEGRO] NVARCHAR(512) NULL,
        [DGR-CBA] NVARCHAR(512) NULL,
        [SILARPIB] NVARCHAR(512) NULL,
        [MUNICIPAL] NVARCHAR(512) NULL,
        [FEDECOBA] NVARCHAR(512) NULL,
        [FECESCOR] NVARCHAR(512) NULL,
        [RG2177] NVARCHAR(512) NULL,
        [Organism] NVARCHAR(512) NULL,
        [FormatVersion] NVARCHAR(512) NULL,
        [FileNamePattern] NVARCHAR(512) NULL,
        [Encoding] NVARCHAR(512) NULL,
        [Periodicity] NVARCHAR(512) NULL,
        [FileLayoutId] NVARCHAR(512) NULL,
        [LayoutRef] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [Source] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_InformationRegimes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_InformationRegimes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_InformationRegimes] PRIMARY KEY ([InformationRegimeId])
    );
END;
GO
