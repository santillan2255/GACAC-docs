-- fis.ProvincialValidationCodes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.ProvincialValidationCodes', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[ProvincialValidationCodes] (
        [ProvincialValidationCodeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Jurisdiction] NVARCHAR(512) NULL,
        [PointOfSale] NVARCHAR(512) NULL,
        [VoucherTypeId] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ValidTo] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NULL,
        [Legend] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [{tenantId, pointOfSale, voucherTypeId, validFrom}] NVARCHAR(512) NULL,
        [CVPIIBB] NVARCHAR(512) NULL,
        [PointOfSaleId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ProvincialValidationCodes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ProvincialValidationCodes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_ProvincialValidationCodes] PRIMARY KEY ([ProvincialValidationCodeId]),
        CONSTRAINT [FK_fis_ProvincialValidationCodes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_ProvincialValidationCodes_Tenant] ON [fis].[ProvincialValidationCodes] ([TenantId]);
END;
GO
