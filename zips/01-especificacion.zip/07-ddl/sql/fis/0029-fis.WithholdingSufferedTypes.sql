-- fis.WithholdingSufferedTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.WithholdingSufferedTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[WithholdingSufferedTypes] (
        [WithholdingSufferedTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Label] NVARCHAR(512) NULL,
        [Tax] NVARCHAR(512) NULL,
        [Regime] NVARCHAR(512) NULL,
        [LedgerAccountId] NVARCHAR(512) NULL,
        [CTA_CONT] NVARCHAR(512) NULL,
        [AccountId] NVARCHAR(512) NULL,
        [RequiresCertificate] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [RETS_TIPO] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_WithholdingSufferedTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_WithholdingSufferedTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_WithholdingSufferedTypes] PRIMARY KEY ([WithholdingSufferedTypeId]),
        CONSTRAINT [FK_fis_WithholdingSufferedTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_WithholdingSufferedTypes_Tenant] ON [fis].[WithholdingSufferedTypes] ([TenantId]);
END;
GO
