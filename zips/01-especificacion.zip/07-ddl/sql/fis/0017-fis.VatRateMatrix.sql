-- fis.VatRateMatrix — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.VatRateMatrix', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[VatRateMatrix] (
        [VatRateMatrixId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [VatRateId] NVARCHAR(512) NULL,
        [VatConditionSettingId] NVARCHAR(512) NULL,
        [SupplyUsageClasses] NVARCHAR(512) NULL,
        [SupplyUsageIds] NVARCHAR(512) NULL,
        [VatPct] NVARCHAR(512) NULL,
        [VatPct2] NVARCHAR(512) NULL,
        [PerceptionPct] NVARCHAR(512) NULL,
        [PerceptionTaxId] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [{tenantId, vatRateId, vatConditionSettingId, supplyUsageKey, validFrom}] NVARCHAR(512) NULL,
        [SupplyUsageKey] NVARCHAR(512) NULL,
        [{tenantId, vatRateId, vatConditionSettingId, validFrom}] NVARCHAR(512) NULL,
        [ALI_IVA_CF] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatRateMatrix_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatRateMatrix_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_VatRateMatrix] PRIMARY KEY ([VatRateMatrixId]),
        CONSTRAINT [FK_fis_VatRateMatrix_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_VatRateMatrix_Tenant] ON [fis].[VatRateMatrix] ([TenantId]);
END;
GO
