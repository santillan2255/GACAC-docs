-- fis.PointsOfSale — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.PointsOfSale', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[PointsOfSale] (
        [PointsOfSaleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [ElectronicCae, electronicCaea, cai, manual, fiscalPrinter, internal] NVARCHAR(512) NULL,
        [BranchId] NVARCHAR(512) NULL,
        [ServiceIds] NVARCHAR(512) NULL,
        [Channels] NVARCHAR(512) NULL,
        [Batch, counter, portal, field, prepaid] NVARCHAR(512) NULL,
        [Address] NVARCHAR(512) NULL,
        [ArcaEnabledAt] DATETIME2(7) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft, active, suspended, retired] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ValidTo] NVARCHAR(512) NULL,
        [{tenantId, number}] NVARCHAR(512) NULL,
        [PTOVENTA] NVARCHAR(512) NULL,
        [PointsOfSale] NVARCHAR(512) NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [{tenantId, legalEntityId, number}] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_PointsOfSale_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_PointsOfSale_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_PointsOfSale] PRIMARY KEY ([PointsOfSaleId]),
        CONSTRAINT [FK_fis_PointsOfSale_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_PointsOfSale_Tenant] ON [fis].[PointsOfSale] ([TenantId]);
END;
GO
