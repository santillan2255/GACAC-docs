-- fis.GrossIncomeSettings — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.GrossIncomeSettings', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[GrossIncomeSettings] (
        [GrossIncomeSettingId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ConditionsJson] NVARCHAR(MAX) NULL,
        [RatesJson] NVARCHAR(MAX) NULL,
        [MatrixJson] NVARCHAR(MAX) NULL,
        [ByDocumentJson] NVARCHAR(MAX) NULL,
        [MinimumTaxable] NVARCHAR(MAX) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [ValidTo] DATETIME2(7) NULL,
        [Jurisdiction] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_GrossIncomeSettings_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_GrossIncomeSettings_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_GrossIncomeSettings] PRIMARY KEY ([GrossIncomeSettingId]),
        CONSTRAINT [FK_fis_GrossIncomeSettings_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_GrossIncomeSettings_Tenant] ON [fis].[GrossIncomeSettings] ([TenantId]);
END;
GO
