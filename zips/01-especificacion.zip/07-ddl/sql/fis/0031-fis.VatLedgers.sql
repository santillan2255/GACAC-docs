-- fis.VatLedgers — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.VatLedgers', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[VatLedgers] (
        [VatLedgerId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [{tenantId, legalEntityId, kind, period, rectificationNo}] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [Sales] NVARCHAR(512) NULL,
        [Purchases] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [Criterion] NVARCHAR(512) NULL,
        [Invoiced] NVARCHAR(512) NULL,
        [Collected] NVARCHAR(512) NULL,
        [InvoicedAndCollected] NVARCHAR(512) NULL,
        [InstallmentsDue] NVARCHAR(512) NULL,
        [DateBasis] NVARCHAR(512) NULL,
        [Issue] NVARCHAR(512) NULL,
        [Due] NVARCHAR(512) NULL,
        [Filters] NVARCHAR(512) NULL,
        [ReportType] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [Closed] NVARCHAR(512) NULL,
        [Reopened] NVARCHAR(512) NULL,
        [Rectified] NVARCHAR(512) NULL,
        [SnapshotHash] NVARCHAR(512) NULL,
        [Totals{ byCondition, byRate, lqsp }] NVARCHAR(512) NULL,
        [ClosedBy/At] DATETIME2(7) NULL,
        [ReopenReason] NVARCHAR(512) NULL,
        [ClosedBy] NVARCHAR(MAX) NULL,
        [ClosedAt] DATETIME2(7) NULL,
        [RectificationNo] INT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatLedgers_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatLedgers_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_VatLedgers] PRIMARY KEY ([VatLedgerId]),
        CONSTRAINT [FK_fis_VatLedgers_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_VatLedgers_Tenant] ON [fis].[VatLedgers] ([TenantId]);
END;
GO
