-- fis.NormativeTableVersions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.NormativeTableVersions', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[NormativeTableVersions] (
        [NormativeTableVersionId] UNIQUEIDENTIFIER NOT NULL,
        [TableCode] NVARCHAR(512) NOT NULL,
        [VersionNumber] INT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [SourceJson] NVARCHAR(MAX) NOT NULL,
        [RowsJson] NVARCHAR(MAX) NOT NULL,
        [DiffFromPreviousJson] NVARCHAR(MAX) NULL,
        [Environment] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_NormativeTableVersions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_NormativeTableVersions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_NormativeTableVersions] PRIMARY KEY ([NormativeTableVersionId])
    );
END;
GO
