-- fis.DeterminedRates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.DeterminedRates', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[DeterminedRates] (
        [DeterminedRateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AccountId] NVARCHAR(512) NULL,
        [Jurisdiction] NVARCHAR(512) NULL,
        [Regime] NVARCHAR(512) NULL,
        [Rate] NVARCHAR(512) NULL,
        [Reason] NVARCHAR(512) NULL,
        [EvidenceId] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [ApprovedBy] NVARCHAR(512) NULL,
        [FrmAlicuotaDeterminada] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_DeterminedRates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_DeterminedRates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_DeterminedRates] PRIMARY KEY ([DeterminedRateId]),
        CONSTRAINT [FK_fis_DeterminedRates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_DeterminedRates_Tenant] ON [fis].[DeterminedRates] ([TenantId]);
END;
GO
