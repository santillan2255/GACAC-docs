-- fis.TaxpayerRegistries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.TaxpayerRegistries', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[TaxpayerRegistries] (
        [TaxpayerRegistryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] NVARCHAR(512) NULL,
        [ArcaOfflineCondition] NVARCHAR(512) NULL,
        [IibbRates] NVARCHAR(512) NULL,
        [Exclusions] NVARCHAR(512) NULL,
        [MaintainedBy] NVARCHAR(512) NULL,
        [Platform] NVARCHAR(512) NULL,
        [Tenant] NVARCHAR(512) NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [MaintainedBy = tenant] NVARCHAR(512) NULL,
        [Jurisdiction] NVARCHAR(512) NULL,
        [Regime] NVARCHAR(512) NULL,
        [RN-01-2017-CBA] NVARCHAR(512) NULL,
        [ARBA] NVARCHAR(512) NULL,
        [ATER-RN-208-24] NVARCHAR(512) NULL,
        [PublishedAt] DATETIME2(7) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ValidTo] NVARCHAR(512) NULL,
        [StoredFileId] NVARCHAR(512) NULL,
        [FileAssetId] NVARCHAR(512) NULL,
        [FileHash] NVARCHAR(512) NULL,
        [RowCount] NVARCHAR(512) NULL,
        [Errors] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Importing] NVARCHAR(512) NULL,
        [Validated] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Superseded] NVARCHAR(512) NULL,
        [Failed] NVARCHAR(512) NULL,
        [ApprovedBy] NVARCHAR(512) NULL,
        [ErrorsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxpayerRegistries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxpayerRegistries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_TaxpayerRegistries] PRIMARY KEY ([TaxpayerRegistryId]),
        CONSTRAINT [FK_fis_TaxpayerRegistries_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_TaxpayerRegistries_Tenant] ON [fis].[TaxpayerRegistries] ([TenantId]);
END;
GO
