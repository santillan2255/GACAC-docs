-- fis.FiscalSurveys — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.FiscalSurveys', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[FiscalSurveys] (
        [FiscalSurveyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [Items] NVARCHAR(512) NULL,
        [{ topic: ambito|prestaciones|tarifas|beneficios|tributos|cargos|bajas|documentos|responsables, evidence, decision, attachments, status }] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [InReview] NVARCHAR(512) NULL,
        [Approved] NVARCHAR(512) NULL,
        [Superseded] NVARCHAR(512) NULL,
        [ApprovedBy] NVARCHAR(512) NULL,
        [ApprovedAt] DATETIME2(7) NULL,
        [{tenantId, status}] NVARCHAR(512) NULL,
        [ItemsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_FiscalSurveys_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_FiscalSurveys_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_FiscalSurveys] PRIMARY KEY ([FiscalSurveyId]),
        CONSTRAINT [FK_fis_FiscalSurveys_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_FiscalSurveys_Tenant] ON [fis].[FiscalSurveys] ([TenantId]);
END;
GO
