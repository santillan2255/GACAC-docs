-- fis.NormativeTables — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.NormativeTables', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[NormativeTables] (
        [NormativeTableId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(MAX) NOT NULL,
        [Scope] VARCHAR(64) NOT NULL,
        [Jurisdiction] NVARCHAR(512) NULL,
        [ExtensibleByTenant] BIT NOT NULL,
        [SchemaRef] NVARCHAR(512) NOT NULL,
        [SyncSource] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_NormativeTables_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_NormativeTables_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_NormativeTables] PRIMARY KEY ([NormativeTableId])
    );
END;
GO
