-- fis.TaxAgentRegistrations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.TaxAgentRegistrations', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[TaxAgentRegistrations] (
        [TaxAgentRegistrationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [Organism] VARCHAR(64) NOT NULL,
        [Tax] VARCHAR(64) NOT NULL,
        [Regime] NVARCHAR(512) NOT NULL,
        [Role] VARCHAR(64) NOT NULL,
        [AgentNumber] NVARCHAR(512) NULL,
        [FilingSystem] VARCHAR(64) NOT NULL,
        [EvidenceIdsJson] NVARCHAR(MAX) NOT NULL,
        [ResponsibleUserIdsJson] NVARCHAR(MAX) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxAgentRegistrations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxAgentRegistrations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_TaxAgentRegistrations] PRIMARY KEY ([TaxAgentRegistrationId]),
        CONSTRAINT [FK_fis_TaxAgentRegistrations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_TaxAgentRegistrations_Tenant] ON [fis].[TaxAgentRegistrations] ([TenantId]);
END;
GO
