-- fis.TaxObligations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.TaxObligations', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[TaxObligations] (
        [TaxObligationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [TaxAgentRegistrationId] NVARCHAR(512) NULL,
        [OwnTaxObligationId] NVARCHAR(512) NULL,
        [Tax] NVARCHAR(512) NULL,
        [Regime] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [DueDate] NVARCHAR(512) NULL,
        [Amount] NVARCHAR(512) NULL,
        [SourceRefs] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Pending] NVARCHAR(512) NULL,
        [Ordered] NVARCHAR(512) NULL,
        [CancellationPending] NVARCHAR(512) NULL,
        [Paid] NVARCHAR(512) NULL,
        [Reconciled] NVARCHAR(512) NULL,
        [Cancelled] NVARCHAR(512) NULL,
        [PaymentConflict] NVARCHAR(512) NULL,
        [CreditBalanceAmount] NVARCHAR(512) NULL,
        [TreasuryMovementId] NVARCHAR(512) NULL,
        [JournalEntryId] NVARCHAR(512) NULL,
        [{tenantId, legalEntityId, regime, period}] NVARCHAR(512) NULL,
        [{tenantId, period, regime}] NVARCHAR(512) NULL,
        [SourceRefsJson] NVARCHAR(MAX) NULL,
        [PaymentConflictJson] NVARCHAR(MAX) NULL,
        [CapitalBaseRefJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxObligations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxObligations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_TaxObligations] PRIMARY KEY ([TaxObligationId]),
        CONSTRAINT [FK_fis_TaxObligations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_TaxObligations_Tenant] ON [fis].[TaxObligations] ([TenantId]);
END;
GO
