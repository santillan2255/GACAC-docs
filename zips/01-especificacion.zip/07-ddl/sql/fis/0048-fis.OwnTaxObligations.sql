-- fis.OwnTaxObligations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.OwnTaxObligations', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[OwnTaxObligations] (
        [OwnTaxObligationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [TaxJson] NVARCHAR(MAX) NOT NULL,
        [JurisdictionJson] NVARCHAR(MAX) NOT NULL,
        [ActivityScopeJson] NVARCHAR(MAX) NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [EffectJson] NVARCHAR(MAX) NULL,
        [CapitalBaseJson] NVARCHAR(MAX) NULL,
        [BasisJson] NVARCHAR(MAX) NOT NULL,
        [EvidenceIdsId] UNIQUEIDENTIFIER NOT NULL,
        [DeadlineRuleJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_OwnTaxObligations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_OwnTaxObligations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_OwnTaxObligations] PRIMARY KEY ([OwnTaxObligationId]),
        CONSTRAINT [FK_fis_OwnTaxObligations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_OwnTaxObligations_Tenant] ON [fis].[OwnTaxObligations] ([TenantId]);
END;
GO
