-- fis.WithholdingAssignments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.WithholdingAssignments', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[WithholdingAssignments] (
        [WithholdingAssignmentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TargetType] NVARCHAR(512) NULL,
        [Supplier] NVARCHAR(512) NULL,
        [Product] NVARCHAR(512) NULL,
        [PurchaseConcept] NVARCHAR(512) NULL,
        [TargetId] NVARCHAR(512) NULL,
        [WithholdingTypeId] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [PROVEED_RET] NVARCHAR(512) NULL,
        [PROD_SER_RET] NVARCHAR(512) NULL,
        [CON_COM_RET] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_WithholdingAssignments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_WithholdingAssignments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_WithholdingAssignments] PRIMARY KEY ([WithholdingAssignmentId]),
        CONSTRAINT [FK_fis_WithholdingAssignments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_WithholdingAssignments_Tenant] ON [fis].[WithholdingAssignments] ([TenantId]);
END;
GO
