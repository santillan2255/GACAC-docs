-- fis.RegimeFilings — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.RegimeFilings', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[RegimeFilings] (
        [RegimeFilingId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [RegimeCode] NVARCHAR(512) NULL,
        [FormatVersion] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [Jurisdiction] NVARCHAR(512) NULL,
        [OriginalFilingId] NVARCHAR(512) NULL,
        [RectificationNumber] NVARCHAR(512) NULL,
        [Universe] NVARCHAR(512) NULL,
        [Files] NVARCHAR(512) NULL,
        [{ storedFileId] NVARCHAR(512) NULL,
        [~~), name, hash, lines }] NVARCHAR(512) NULL,
        [Validation{ ok, errors }] NVARCHAR(512) NULL,
        [ControlTotals] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [SubmittedAt] DATETIME2(7) NULL,
        [SubmittedBy] NVARCHAR(512) NULL,
        [Acknowledgment{ number, storedFileId] NVARCHAR(512) NULL,
        [~~), receivedAt }] NVARCHAR(512) NULL,
        [Result{ accepted, rejectionReasons }] NVARCHAR(512) NULL,
        [{tenantId, legalEntityId, regimeCode, period, rectificationNumber}] NVARCHAR(512) NULL,
        [FilesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_RegimeFilings_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_RegimeFilings_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_RegimeFilings] PRIMARY KEY ([RegimeFilingId]),
        CONSTRAINT [FK_fis_RegimeFilings_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_RegimeFilings_Tenant] ON [fis].[RegimeFilings] ([TenantId]);
END;
GO
