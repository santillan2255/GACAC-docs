-- fis.ArcaAccessTickets — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.ArcaAccessTickets', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[ArcaAccessTickets] (
        [ArcaAccessTicketId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ArcaCredentialId] NVARCHAR(512) NULL,
        [CredentialId] NVARCHAR(512) NULL,
        [Service] NVARCHAR(512) NULL,
        [Environment] NVARCHAR(512) NULL,
        [RepresentedCuit] NVARCHAR(512) NULL,
        [UniqueId] NVARCHAR(512) NULL,
        [GenerationTime] NVARCHAR(512) NULL,
        [ExpirationTime] NVARCHAR(512) NULL,
        [TokenEnc] NVARCHAR(512) NULL,
        [SignEnc] NVARCHAR(512) NULL,
        [ObtainedAt] DATETIME2(7) NULL,
        [{tenantId, arcaCredentialId, service, environment}] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ArcaAccessTickets_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ArcaAccessTickets_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_ArcaAccessTickets] PRIMARY KEY ([ArcaAccessTicketId]),
        CONSTRAINT [FK_fis_ArcaAccessTickets_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_ArcaAccessTickets_Tenant] ON [fis].[ArcaAccessTickets] ([TenantId]);
END;
GO
