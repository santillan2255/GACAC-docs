-- fis.TaxDefinitions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.TaxDefinitions', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[TaxDefinitions] (
        [TaxDefinitionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Level] VARCHAR(64) NOT NULL,
        [Nature] VARCHAR(64) NOT NULL,
        [ClassificationJson] NVARCHAR(MAX) NOT NULL,
        [ArcaTaxId] INT NOT NULL,
        [LedgerColumn] VARCHAR(64) NOT NULL,
        [SicoreCodesJson] NVARCHAR(MAX) NULL,
        [Jurisdiction] NVARCHAR(512) NULL,
        [BasisJson] NVARCHAR(MAX) NOT NULL,
        [TransferableToMember] BIT NOT NULL,
        [CalculationJson] NVARCHAR(MAX) NOT NULL,
        [AccountMapJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxDefinitions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxDefinitions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_TaxDefinitions] PRIMARY KEY ([TaxDefinitionId]),
        CONSTRAINT [FK_fis_TaxDefinitions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_TaxDefinitions_Tenant] ON [fis].[TaxDefinitions] ([TenantId]);
END;
GO
