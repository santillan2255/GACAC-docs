-- fis.FiscalDeadlines — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.FiscalDeadlines', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[FiscalDeadlines] (
        [FiscalDeadlineId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [RegimeCode] NVARCHAR(512) NULL,
        [ReportCode] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [DueDate] NVARCHAR(512) NULL,
        [Source] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Upcoming] NVARCHAR(512) NULL,
        [Due] NVARCHAR(512) NULL,
        [Filed] NVARCHAR(512) NULL,
        [Overdue] NVARCHAR(512) NULL,
        [FilingId] NVARCHAR(512) NULL,
        [{tenantId, dueDate}] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_FiscalDeadlines_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_FiscalDeadlines_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_FiscalDeadlines] PRIMARY KEY ([FiscalDeadlineId]),
        CONSTRAINT [FK_fis_FiscalDeadlines_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_FiscalDeadlines_Tenant] ON [fis].[FiscalDeadlines] ([TenantId]);
END;
GO
