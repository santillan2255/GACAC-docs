-- fis.CaeaPeriods — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.CaeaPeriods', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[CaeaPeriods] (
        [CaeaPeriodId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [YYYY-MM] NVARCHAR(512) NULL,
        [YyyyMM] NVARCHAR(512) NULL,
        [Order] NVARCHAR(512) NULL,
        [Caea] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ValidTo] NVARCHAR(512) NULL,
        [ReportDeadline] NVARCHAR(512) NULL,
        [PointsOfSale] NVARCHAR(512) NULL,
        [{ number, used: bool, reportedWithoutMovementAt }] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Requested] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Reporting] NVARCHAR(512) NULL,
        [Reported] NVARCHAR(512) NULL,
        [ExpiredWithPending] NVARCHAR(512) NULL,
        [ObtainedVia] NVARCHAR(512) NULL,
        [Consult] NVARCHAR(512) NULL,
        [Request] NVARCHAR(512) NULL,
        [{tenantId, legalEntityId, period, order}] NVARCHAR(512) NULL,
        [PointsOfSaleJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_CaeaPeriods_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_CaeaPeriods_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_CaeaPeriods] PRIMARY KEY ([CaeaPeriodId]),
        CONSTRAINT [FK_fis_CaeaPeriods_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_CaeaPeriods_Tenant] ON [fis].[CaeaPeriods] ([TenantId]);
END;
GO
