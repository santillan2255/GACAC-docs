-- fis.VatReconciliations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.VatReconciliations', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[VatReconciliations] (
        [VatReconciliationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ImportId] NVARCHAR(512) NULL,
        [LedgerId] NVARCHAR(512) NULL,
        [Tolerance] NVARCHAR(512) NULL,
        [Results] NVARCHAR(512) NULL,
        [{ kind: missingInCoopApps|missingInArca|amountDiff, documentRef, field, goodAppsValue, arcaValue }] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Open] NVARCHAR(512) NULL,
        [Reviewed] NVARCHAR(512) NULL,
        [Closed] NVARCHAR(512) NULL,
        [ResultsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatReconciliations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatReconciliations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_VatReconciliations] PRIMARY KEY ([VatReconciliationId]),
        CONSTRAINT [FK_fis_VatReconciliations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_VatReconciliations_Tenant] ON [fis].[VatReconciliations] ([TenantId]);
END;
GO
