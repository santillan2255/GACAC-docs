-- fis.RegulatoryConceptMaps — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.RegulatoryConceptMaps', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[RegulatoryConceptMaps] (
        [RegulatoryConceptMapId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ReportCode] NVARCHAR(512) NULL,
        [ServiceKind] NVARCHAR(512) NULL,
        [FixedPhone] NVARCHAR(512) NULL,
        [Mobile] NVARCHAR(512) NULL,
        [Internet] NVARCHAR(512) NULL,
        [Tv] NVARCHAR(512) NULL,
        [Gas] NVARCHAR(512) NULL,
        [Electricity] NVARCHAR(512) NULL,
        [MainServices] NVARCHAR(512) NULL,
        [Services] NVARCHAR(512) NULL,
        [Products] NVARCHAR(512) NULL,
        [Taxes] NVARCHAR(512) NULL,
        [CategoryMap{ categoryId, regulatorCode }] NVARCHAR(512) NULL,
        [COD_ENGAS] NVARCHAR(512) NULL,
        [EntityCodes{ entity] NVARCHAR(512) NULL,
        [UseMeterRegistration] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [ENACOM_ConfigTxt] NVARCHAR(512) NULL,
        [FrmEnargasConceptos] NVARCHAR(512) NULL,
        [MainServicesJson] NVARCHAR(MAX) NULL,
        [ServicesJson] NVARCHAR(MAX) NULL,
        [ProductsJson] NVARCHAR(MAX) NULL,
        [TaxesJson] NVARCHAR(MAX) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_RegulatoryConceptMaps_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_RegulatoryConceptMaps_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_RegulatoryConceptMaps] PRIMARY KEY ([RegulatoryConceptMapId]),
        CONSTRAINT [FK_fis_RegulatoryConceptMaps_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_RegulatoryConceptMaps_Tenant] ON [fis].[RegulatoryConceptMaps] ([TenantId]);
END;
GO
