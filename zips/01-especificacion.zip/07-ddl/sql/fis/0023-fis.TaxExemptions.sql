-- fis.TaxExemptions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.TaxExemptions', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[TaxExemptions] (
        [TaxExemptionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [PartyType] NVARCHAR(512) NULL,
        [Account] NVARCHAR(512) NULL,
        [Person] NVARCHAR(512) NULL,
        [Supplier] NVARCHAR(512) NULL,
        [PartyId] NVARCHAR(512) NULL,
        [Cuit] NVARCHAR(512) NULL,
        [Tax] NVARCHAR(512) NULL,
        [Regime] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [Exclusion] NVARCHAR(512) NULL,
        [NonWithholdingCertificate] NVARCHAR(512) NULL,
        [Reduction] NVARCHAR(512) NULL,
        [NoPerception] NVARCHAR(512) NULL,
        [Pct] NVARCHAR(512) NULL,
        [CertificateNumber] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [EvidenceId] NVARCHAR(512) NULL,
        [Source] NVARCHAR(512) NULL,
        [Manual] NVARCHAR(512) NULL,
        [Registry] NVARCHAR(512) NULL,
        [{tenantId, partyId, tax, validFrom}] NVARCHAR(512) NULL,
        [SUMSOCNO_COBRAR_PERCEPCION] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxExemptions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_TaxExemptions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_TaxExemptions] PRIMARY KEY ([TaxExemptionId]),
        CONSTRAINT [FK_fis_TaxExemptions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_TaxExemptions_Tenant] ON [fis].[TaxExemptions] ([TenantId]);
END;
GO
