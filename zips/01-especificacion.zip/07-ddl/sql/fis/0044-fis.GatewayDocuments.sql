-- fis.GatewayDocuments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.GatewayDocuments', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[GatewayDocuments] (
        [GatewayDocumentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ExternalSystemId] NVARCHAR(512) NULL,
        [SourceFileName] NVARCHAR(512) NULL,
        [ApiClientId] NVARCHAR(512) NULL,
        [ArcaCbteType] NVARCHAR(512) NULL,
        [PointOfSale] NVARCHAR(512) NULL,
        [Number] NVARCHAR(512) NULL,
        [IssueDate] NVARCHAR(512) NULL,
        [Total] NVARCHAR(512) NULL,
        [DocType] NVARCHAR(512) NULL,
        [DocNumber] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [Concept] NVARCHAR(512) NULL,
        [ServiceFrom/To] NVARCHAR(512) NULL,
        [Currency] NVARCHAR(512) NULL,
        [ExchangeRate] NVARCHAR(512) NULL,
        [Untaxed] NVARCHAR(512) NULL,
        [Net] NVARCHAR(512) NULL,
        [Exempt] NVARCHAR(512) NULL,
        [Vat] NVARCHAR(512) NULL,
        [TaxesTotal] NVARCHAR(512) NULL,
        [PaymentDueDate] NVARCHAR(512) NULL,
        [Taxes] NVARCHAR(512) NULL,
        [Cancelled] NVARCHAR(512) NULL,
        [Related] NVARCHAR(512) NULL,
        [{ type, pos, number, cuit, date }] NVARCHAR(512) NULL,
        [FiscalAuthorizationId] NVARCHAR(512) NULL,
        [AuthorizationId] NVARCHAR(512) NULL,
        [ExportStatus] NVARCHAR(512) NULL,
        [Pending] NVARCHAR(512) NULL,
        [ExportedOk] NVARCHAR(512) NULL,
        [ExportedError] NVARCHAR(512) NULL,
        [{tenantId, arcaCbteType, pointOfSale, number}] NVARCHAR(512) NULL,
        [ELECTRONICA_FC] NVARCHAR(512) NULL,
        [ELECTRONICA_IVA] NVARCHAR(512) NULL,
        [ELECTRONICA_TRIB] NVARCHAR(512) NULL,
        [ELECTRONICA_RELCOMP] NVARCHAR(512) NULL,
        [ServiceFrom] DATETIME2(7) NULL,
        [ServiceTo] DATETIME2(7) NULL,
        [VatJson] NVARCHAR(MAX) NULL,
        [TaxesJson] NVARCHAR(MAX) NULL,
        [RelatedJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_GatewayDocuments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_GatewayDocuments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_GatewayDocuments] PRIMARY KEY ([GatewayDocumentId]),
        CONSTRAINT [FK_fis_GatewayDocuments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_GatewayDocuments_Tenant] ON [fis].[GatewayDocuments] ([TenantId]);
END;
GO
