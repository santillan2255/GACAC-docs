-- fis.ArcaCredentials — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.ArcaCredentials', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[ArcaCredentials] (
        [ArcaCredentialId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [Environment] VARCHAR(64) NOT NULL,
        [RepresentedCuit] NVARCHAR(512) NOT NULL,
        [CertificateCuit] NVARCHAR(512) NOT NULL,
        [Alias] NVARCHAR(512) NOT NULL,
        [CredentialRefId] UNIQUEIDENTIFIER NOT NULL,
        [AuthorizedServicesJson] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LastHealthCheckJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ArcaCredentials_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ArcaCredentials_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_ArcaCredentials] PRIMARY KEY ([ArcaCredentialId]),
        CONSTRAINT [FK_fis_ArcaCredentials_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_ArcaCredentials_Tenant] ON [fis].[ArcaCredentials] ([TenantId]);
END;
GO
