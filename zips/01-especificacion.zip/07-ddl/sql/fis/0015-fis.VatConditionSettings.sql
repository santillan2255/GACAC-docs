-- fis.VatConditionSettings — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.VatConditionSettings', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[VatConditionSettings] (
        [VatConditionSettingId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ArcaConditionId] INT NOT NULL,
        [InternalCode] NVARCHAR(512) NOT NULL,
        [Label] NVARCHAR(MAX) NOT NULL,
        [IsRegistered] BIT NOT NULL,
        [VatLedgerCriterion] VARCHAR(64) NOT NULL,
        [PerceptionMinimum] DECIMAL(18,4) NULL,
        [PerceptionOnNet] BIT NOT NULL,
        [IsUncategorized] BIT NOT NULL,
        [OfflineRegistryCode] NVARCHAR(512) NULL,
        [SireCode] NVARCHAR(512) NULL,
        [LedgerCode] NVARCHAR(512) NULL,
        [DefaultDocumentTypesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatConditionSettings_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_VatConditionSettings_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_VatConditionSettings] PRIMARY KEY ([VatConditionSettingId]),
        CONSTRAINT [FK_fis_VatConditionSettings_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_VatConditionSettings_Tenant] ON [fis].[VatConditionSettings] ([TenantId]);
END;
GO
