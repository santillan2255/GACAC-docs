-- fis.ThirdPartyRemittances — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.ThirdPartyRemittances', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[ThirdPartyRemittances] (
        [ThirdPartyRemittanceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AgreementId] NVARCHAR(512) NULL,
        [PeriodFrom/To] NVARCHAR(512) NULL,
        [BilledTotal] NVARCHAR(512) NULL,
        [CollectedTotal] NVARCHAR(512) NULL,
        [Fee] NVARCHAR(512) NULL,
        [NetToRemit] NVARCHAR(512) NULL,
        [ReportStoredFileId] NVARCHAR(512) NULL,
        [ReportAssetId] NVARCHAR(512) NULL,
        [PaymentOrderId] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [ReconciledAt] DATETIME2(7) NULL,
        [PeriodFrom] DATETIME2(7) NOT NULL,
        [PeriodTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ThirdPartyRemittances_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_ThirdPartyRemittances_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_ThirdPartyRemittances] PRIMARY KEY ([ThirdPartyRemittanceId]),
        CONSTRAINT [FK_fis_ThirdPartyRemittances_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_ThirdPartyRemittances_Tenant] ON [fis].[ThirdPartyRemittances] ([TenantId]);
END;
GO
