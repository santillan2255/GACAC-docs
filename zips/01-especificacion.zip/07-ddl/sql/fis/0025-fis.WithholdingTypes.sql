-- fis.WithholdingTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.WithholdingTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[WithholdingTypes] (
        [WithholdingTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Tax] NVARCHAR(512) NULL,
        [IB] NVARCHAR(512) NULL,
        [IV] NVARCHAR(512) NULL,
        [GN] NVARCHAR(512) NULL,
        [SS] NVARCHAR(512) NULL,
        [Label] NVARCHAR(512) NULL,
        [RegimeCode] NVARCHAR(512) NULL,
        [COD_REG] NVARCHAR(512) NULL,
        [MinWithholding] NVARCHAR(512) NULL,
        [MIN_RET] NVARCHAR(512) NULL,
        [MinTaxable] NVARCHAR(512) NULL,
        [MIN_IMP] NVARCHAR(512) NULL,
        [FixedAmount] NVARCHAR(512) NULL,
        [RET_PES] NVARCHAR(512) NULL,
        [FixedPct] NVARCHAR(512) NULL,
        [RET_POR] NVARCHAR(512) NULL,
        [FixedExcess] NVARCHAR(512) NULL,
        [RET_EXE] NVARCHAR(512) NULL,
        [BaseFlags{ addNet, addTaxes, addExempt, addVat, addPerceptions, subNet, subTaxes, subExempt, subVat, subPerceptions }] NVARCHAR(512) NULL,
        [Factor] NVARCHAR(512) NULL,
        [M_FACTOR] NVARCHAR(512) NULL,
        [OnlyFullPayment] NVARCHAR(512) NULL,
        [TOT_PRO] NVARCHAR(512) NULL,
        [ByItem] NVARCHAR(512) NULL,
        [CALCULAXITEM] NVARCHAR(512) NULL,
        [AccumulationMonths] NVARCHAR(512) NULL,
        [ACUM_MES] NVARCHAR(512) NULL,
        [CalendarAccumulation] NVARCHAR(512) NULL,
        [ACUM_CALE] NVARCHAR(512) NULL,
        [AnnualMinimumDiscount] NVARCHAR(512) NULL,
        [DESC_ANUAL] NVARCHAR(512) NULL,
        [OwnNumbering] NVARCHAR(512) NULL,
        [NUMERO] NVARCHAR(512) NULL,
        [BaseTypeCode] NVARCHAR(512) NULL,
        [RETE_TIPO_BASE] NVARCHAR(512) NULL,
        [TaxAgentRegistrationId] NVARCHAR(512) NULL,
        [AgentRegistrationId] NVARCHAR(512) NULL,
        [LedgerAccountId] NVARCHAR(512) NULL,
        [AccountId] NVARCHAR(512) NULL,
        [ValidFrom/validTo] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_WithholdingTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_WithholdingTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_WithholdingTypes] PRIMARY KEY ([WithholdingTypeId]),
        CONSTRAINT [FK_fis_WithholdingTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_WithholdingTypes_Tenant] ON [fis].[WithholdingTypes] ([TenantId]);
END;
GO
