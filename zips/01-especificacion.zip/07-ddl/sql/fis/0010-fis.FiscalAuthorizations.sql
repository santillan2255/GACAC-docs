-- fis.FiscalAuthorizations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.FiscalAuthorizations', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[FiscalAuthorizations] (
        [FiscalAuthorizationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [DocumentRefId] UNIQUEIDENTIFIER NOT NULL,
        [SourceModule] VARCHAR(64) NOT NULL,
        [IssueDate] DATETIME2(7) NOT NULL,
        [AuthorizationKind] VARCHAR(64) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [PayloadJson] NVARCHAR(MAX) NOT NULL,
        [PayloadHash] NVARCHAR(512) NOT NULL,
        [PrevalidationJson] NVARCHAR(MAX) NOT NULL,
        [AttemptsJson] NVARCHAR(MAX) NOT NULL,
        [ObservationsJson] NVARCHAR(MAX) NULL,
        [QrDataJson] NVARCHAR(MAX) NULL,
        [BarcodeData] NVARCHAR(512) NULL,
        [CaeaReportedJson] NVARCHAR(MAX) NULL,
        [ReconciliationJson] NVARCHAR(MAX) NULL,
        [IdempotencyKey] NVARCHAR(512) NOT NULL,
        [PointOfSaleId] UNIQUEIDENTIFIER NOT NULL,
        [IssueAttempt] INT NOT NULL,
        [RejectionKind] VARCHAR(64) NULL,
        [CancelReason] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_FiscalAuthorizations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_FiscalAuthorizations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_FiscalAuthorizations] PRIMARY KEY ([FiscalAuthorizationId]),
        CONSTRAINT [FK_fis_FiscalAuthorizations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_FiscalAuthorizations_Tenant] ON [fis].[FiscalAuthorizations] ([TenantId]);
END;
GO
