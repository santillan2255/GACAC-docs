-- fis.FiscalProfiles — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fis.FiscalProfiles', N'U') IS NULL
BEGIN
    CREATE TABLE [fis].[FiscalProfiles] (
        [FiscalProfileId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [LegalName] NVARCHAR(512) NOT NULL,
        [Cuit] NVARCHAR(512) NOT NULL,
        [VatConditionCode] INT NOT NULL,
        [GrossIncomeJson] NVARCHAR(MAX) NOT NULL,
        [ActivityStartDate] DATETIME2(7) NOT NULL,
        [FiscalAddressJson] NVARCHAR(MAX) NOT NULL,
        [ArcaActivitiesJson] NVARCHAR(MAX) NULL,
        [FiscalLogoStoredFileId] UNIQUEIDENTIFIER NULL,
        [MipymeStatusJson] NVARCHAR(MAX) NULL,
        [RegulatoryMapJson] NVARCHAR(MAX) NULL,
        [SurveyId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_FiscalProfiles_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fis_FiscalProfiles_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fis_FiscalProfiles] PRIMARY KEY ([FiscalProfileId]),
        CONSTRAINT [FK_fis_FiscalProfiles_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fis_FiscalProfiles_Tenant] ON [fis].[FiscalProfiles] ([TenantId]);
END;
GO
