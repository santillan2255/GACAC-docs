-- bia.Bi_fact_consumption — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_consumption', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_consumption] (
        [Bi_fact_consumptionId] UNIQUEIDENTIFIER NOT NULL,
        [Contrato] NVARCHAR(512) NULL,
        [Medidor] NVARCHAR(512) NULL,
        [Periodo] NVARCHAR(512) NULL,
        [Canal] NVARCHAR(512) NULL,
        [Cantidad] NVARCHAR(512) NULL,
        [Estimado] NVARCHAR(512) NULL,
        [Origen] NVARCHAR(512) NULL,
        [ConsumptionId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_consumption_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_consumption_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_consumption] PRIMARY KEY ([Bi_fact_consumptionId])
    );
END;
GO
