-- bia.Bi_dim_category — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_dim_category', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_dim_category] (
        [Bi_dim_categoryId] UNIQUEIDENTIFIER NOT NULL,
        [Codigo] NVARCHAR(512) NULL,
        [Nombre] NVARCHAR(512) NULL,
        [Jerarquia] NVARCHAR(512) NULL,
        [Vigencia] NVARCHAR(512) NULL,
        [CategoryId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_category_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_category_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_dim_category] PRIMARY KEY ([Bi_dim_categoryId])
    );
END;
GO
