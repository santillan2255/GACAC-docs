-- bia.ReportAccessLogs — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ReportAccessLogs', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ReportAccessLogs] (
        [ReportAccessLogId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [INFO_AUD] NVARCHAR(512) NULL,
        [COD_AUD] NVARCHAR(512) NULL,
        [COD_INF] NVARCHAR(512) NULL,
        [FEC_REG] NVARCHAR(512) NULL,
        [TIP_VIS] NVARCHAR(512) NULL,
        [ReportCode] NVARCHAR(512) NULL,
        [RunId] NVARCHAR(512) NULL,
        [ExportId] NVARCHAR(512) NULL,
        [Action] NVARCHAR(512) NULL,
        [View] NVARCHAR(512) NULL,
        [Export] NVARCHAR(512) NULL,
        [Download] NVARCHAR(512) NULL,
        [Unmask] NVARCHAR(512) NULL,
        [ApiRead] NVARCHAR(512) NULL,
        [UserId] NVARCHAR(512) NULL,
        [ApiClientId] NVARCHAR(512) NULL,
        [Ip] NVARCHAR(512) NULL,
        [UserAgent] NVARCHAR(512) NULL,
        [RowCount] NVARCHAR(512) NULL,
        [ContainsPersonalData] NVARCHAR(512) NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [LegalEntities] NVARCHAR(512) NULL,
        [FilterSummary] NVARCHAR(512) NULL,
        [At] DATETIME2(7) NULL,
        [{tenantId, at:-1}] NVARCHAR(512) NULL,
        [{tenantId, reportCode, at:-1}] NVARCHAR(512) NULL,
        [{tenantId, legalEntityId, at:-1}] NVARCHAR(512) NULL,
        [PRM-BIA-017] NVARCHAR(512) NULL,
        [ReportDefinitionId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportAccessLogs_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportAccessLogs_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ReportAccessLogs] PRIMARY KEY ([ReportAccessLogId]),
        CONSTRAINT [FK_bia_ReportAccessLogs_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ReportAccessLogs_Tenant] ON [bia].[ReportAccessLogs] ([TenantId]);
END;
GO
