-- bia.Bi_fact_purchase — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_purchase', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_purchase] (
        [Bi_fact_purchaseId] UNIQUEIDENTIFIER NOT NULL,
        [Tipo] NVARCHAR(512) NULL,
        [Proveedor] NVARCHAR(512) NULL,
        [Rubro] NVARCHAR(512) NULL,
        [Importes] NVARCHAR(512) NULL,
        [Fechas] NVARCHAR(512) NULL,
        [Estado] NVARCHAR(512) NULL,
        [SupplierInvoiceId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_purchase_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_purchase_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_purchase] PRIMARY KEY ([Bi_fact_purchaseId])
    );
END;
GO
