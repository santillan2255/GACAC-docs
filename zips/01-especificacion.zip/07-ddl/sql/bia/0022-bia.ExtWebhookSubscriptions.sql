-- bia.ExtWebhookSubscriptions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ExtWebhookSubscriptions', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ExtWebhookSubscriptions] (
        [ExtWebhookSubscriptionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ApiClientId] NVARCHAR(512) NULL,
        [Url] NVARCHAR(512) NULL,
        [EventTypes] NVARCHAR(512) NULL,
        [SecretHash] NVARCHAR(512) NULL,
        [SecretPrefix] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Paused] NVARCHAR(512) NULL,
        [Disabled] NVARCHAR(512) NULL,
        [FailingSince] NVARCHAR(512) NULL,
        [Description] NVARCHAR(512) NULL,
        [EventTypesJson] NVARCHAR(MAX) NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ExtWebhookSubscriptions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ExtWebhookSubscriptions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ExtWebhookSubscriptions] PRIMARY KEY ([ExtWebhookSubscriptionId]),
        CONSTRAINT [FK_bia_ExtWebhookSubscriptions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ExtWebhookSubscriptions_Tenant] ON [bia].[ExtWebhookSubscriptions] ([TenantId]);
END;
GO
