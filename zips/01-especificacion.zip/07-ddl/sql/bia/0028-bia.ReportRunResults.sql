-- bia.ReportRunResults — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ReportRunResults', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ReportRunResults] (
        [ReportRunResultId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ReportRunId] NVARCHAR(512) NULL,
        [RowNo] NVARCHAR(512) NULL,
        [Row] NVARCHAR(512) NULL,
        [ExpiresAt] DATETIME2(7) NULL,
        [ReportRunsExpiresAt] DATETIME2(7) NULL,
        [PRM-BIA-015] NVARCHAR(512) NULL,
        [{tenantId, reportRunId, rowNo}] NVARCHAR(512) NULL,
        [ResultRefStorage = collection] NVARCHAR(512) NULL,
        [Key = reportRunId] NVARCHAR(512) NULL,
        [RowJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportRunResults_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportRunResults_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ReportRunResults] PRIMARY KEY ([ReportRunResultId]),
        CONSTRAINT [FK_bia_ReportRunResults_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ReportRunResults_Tenant] ON [bia].[ReportRunResults] ([TenantId]);
END;
GO
