-- bia.Bi_fact_invoiceLine — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_invoiceLine', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_invoiceLine] (
        [Bi_fact_invoiceLineId] UNIQUEIDENTIFIER NOT NULL,
        [InvoiceId] UNIQUEIDENTIFIER NOT NULL,
        [Concepto] NVARCHAR(512) NULL,
        [Cantidad] NVARCHAR(512) NULL,
        [Precio] NVARCHAR(512) NULL,
        [Importe] NVARCHAR(512) NULL,
        [Impuesto] NVARCHAR(512) NULL,
        [Tramo] NVARCHAR(512) NULL,
        [Categoria] NVARCHAR(512) NULL,
        [LineId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_invoiceLine_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_invoiceLine_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_invoiceLine] PRIMARY KEY ([Bi_fact_invoiceLineId])
    );
END;
GO
