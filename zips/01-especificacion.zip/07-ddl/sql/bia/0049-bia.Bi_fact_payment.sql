-- bia.Bi_fact_payment — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_payment', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_payment] (
        [Bi_fact_paymentId] UNIQUEIDENTIFIER NOT NULL,
        [PaymentId] UNIQUEIDENTIFIER NULL,
        [Canal] NVARCHAR(512) NULL,
        [Ente] NVARCHAR(512) NULL,
        [Fechas] NVARCHAR(512) NULL,
        [Importe] NVARCHAR(512) NULL,
        [Comision] NVARCHAR(512) NULL,
        [Estado] NVARCHAR(512) NULL,
        [ReceiptId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_payment_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_payment_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_payment] PRIMARY KEY ([Bi_fact_paymentId])
    );
END;
GO
