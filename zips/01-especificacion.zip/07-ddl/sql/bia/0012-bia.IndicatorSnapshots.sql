-- bia.IndicatorSnapshots — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.IndicatorSnapshots', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[IndicatorSnapshots] (
        [IndicatorSnapshotId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TENDTAB] NVARCHAR(512) NULL,
        [IndicatorId] NVARCHAR(512) NULL,
        [IndicatorDefinitions] NVARCHAR(512) NULL,
        [IndicatorCode] NVARCHAR(512) NULL,
        [DefinitionVersion] NVARCHAR(512) NULL,
        [PeriodType] NVARCHAR(512) NULL,
        [PeriodKey] NVARCHAR(512) NULL,
        [2026-10] NVARCHAR(512) NULL,
        [2026-W44] NVARCHAR(512) NULL,
        [2026-11-03] NVARCHAR(512) NULL,
        [Cycle:2026-10] NVARCHAR(512) NULL,
        [DimensionKey] NVARCHAR(512) NULL,
        [REF_1REF_4] NVARCHAR(512) NULL,
        [Dimensions] NVARCHAR(512) NULL,
        [Value] NVARCHAR(512) NULL,
        [Numerator] NVARCHAR(512) NULL,
        [Denominator] NVARCHAR(512) NULL,
        [Count] NVARCHAR(512) NULL,
        [ComputedAt] DATETIME2(7) NULL,
        [SourceWatermark] NVARCHAR(512) NULL,
        [IsClosed] NVARCHAR(512) NULL,
        [ScenarioId] NVARCHAR(512) NULL,
        [SimulationScenarios] NVARCHAR(512) NULL,
        [{tenantId, indicatorCode, periodType, periodKey, dimensionKey}] NVARCHAR(512) NULL,
        [{tenantId, indicatorCode, computedAt:-1}] NVARCHAR(512) NULL,
        [DimensionsJson] NVARCHAR(MAX) NULL,
        [Date] DATETIME2(7) NOT NULL,
        [ScopeKey] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_IndicatorSnapshots_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_IndicatorSnapshots_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_IndicatorSnapshots] PRIMARY KEY ([IndicatorSnapshotId]),
        CONSTRAINT [FK_bia_IndicatorSnapshots_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_IndicatorSnapshots_Tenant] ON [bia].[IndicatorSnapshots] ([TenantId]);
END;
GO
