-- bia.ExportLayouts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ExportLayouts', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ExportLayouts] (
        [ExportLayoutId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SourceType] VARCHAR(64) NOT NULL,
        [SourceRef] NVARCHAR(512) NOT NULL,
        [TargetType] VARCHAR(64) NOT NULL,
        [FileNamePattern] NVARCHAR(512) NOT NULL,
        [Columns] DATETIME2(7) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ExportLayouts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ExportLayouts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ExportLayouts] PRIMARY KEY ([ExportLayoutId]),
        CONSTRAINT [FK_bia_ExportLayouts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ExportLayouts_Tenant] ON [bia].[ExportLayouts] ([TenantId]);
END;
GO
