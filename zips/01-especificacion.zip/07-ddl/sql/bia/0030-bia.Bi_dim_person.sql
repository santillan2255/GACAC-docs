-- bia.Bi_dim_person — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_dim_person', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_dim_person] (
        [Bi_dim_personId] UNIQUEIDENTIFIER NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NOT NULL,
        [Tipo] NVARCHAR(512) NULL,
        [Condicion_IVA] NVARCHAR(512) NULL,
        [Localidad] NVARCHAR(512) NULL,
        [Estado] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_person_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_person_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_dim_person] PRIMARY KEY ([Bi_dim_personId])
    );
END;
GO
