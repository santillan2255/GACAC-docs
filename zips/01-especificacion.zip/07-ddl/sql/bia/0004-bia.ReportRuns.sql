-- bia.ReportRuns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ReportRuns', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ReportRuns] (
        [ReportRunId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [RequestedById] UNIQUEIDENTIFIER NOT NULL,
        [Trigger] VARCHAR(64) NOT NULL,
        [ParametersJson] NVARCHAR(MAX) NOT NULL,
        [EffectiveScopeJson] NVARCHAR(MAX) NOT NULL,
        [Mode] VARCHAR(64) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ProgressJson] NVARCHAR(MAX) NULL,
        [ResultRefJson] NVARCHAR(MAX) NULL,
        [MetadataJson] NVARCHAR(MAX) NOT NULL,
        [ErrorJson] NVARCHAR(MAX) NULL,
        [JobId] NVARCHAR(512) NULL,
        [IdempotencyKey] NVARCHAR(512) NULL,
        [ExpiresAt] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportRuns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportRuns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ReportRuns] PRIMARY KEY ([ReportRunId]),
        CONSTRAINT [FK_bia_ReportRuns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ReportRuns_Tenant] ON [bia].[ReportRuns] ([TenantId]);
END;
GO
