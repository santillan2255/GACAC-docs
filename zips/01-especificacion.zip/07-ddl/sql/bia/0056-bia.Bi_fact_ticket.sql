-- bia.Bi_fact_ticket — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_ticket', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_ticket] (
        [Bi_fact_ticketId] UNIQUEIDENTIFIER NOT NULL,
        [Tipo] NVARCHAR(512) NULL,
        [Canal] NVARCHAR(512) NULL,
        [Area] NVARCHAR(512) NULL,
        [Prioridad] NVARCHAR(512) NULL,
        [SLA] NVARCHAR(512) NULL,
        [Tiempos] NVARCHAR(512) NULL,
        [Estado] NVARCHAR(512) NULL,
        [Satisfaccion] NVARCHAR(512) NULL,
        [CrmCaseId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_ticket_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_ticket_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_ticket] PRIMARY KEY ([Bi_fact_ticketId])
    );
END;
GO
