-- bia.Bi_fact_journalLine — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_journalLine', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_journalLine] (
        [Bi_fact_journalLineId] UNIQUEIDENTIFIER NOT NULL,
        [Asiento] NVARCHAR(512) NULL,
        [Cuenta] NVARCHAR(512) NULL,
        [Centro] NVARCHAR(512) NULL,
        [Debe] NVARCHAR(512) NULL,
        [Haber] NVARCHAR(512) NULL,
        [Ejercicio] NVARCHAR(512) NULL,
        [Plan] NVARCHAR(512) NULL,
        [Escenario] NVARCHAR(512) NULL,
        [JournalLineId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_journalLine_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_journalLine_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_journalLine] PRIMARY KEY ([Bi_fact_journalLineId])
    );
END;
GO
