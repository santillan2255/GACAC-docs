-- bia.Bi_fact_reading — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_reading', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_reading] (
        [Bi_fact_readingId] UNIQUEIDENTIFIER NOT NULL,
        [Ruta] NVARCHAR(512) NULL,
        [Lecturista] NVARCHAR(512) NULL,
        [Resultado] NVARCHAR(512) NULL,
        [Observacion] NVARCHAR(512) NULL,
        [Fecha] NVARCHAR(512) NULL,
        [MeterReadingId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_reading_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_reading_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_reading] PRIMARY KEY ([Bi_fact_readingId])
    );
END;
GO
