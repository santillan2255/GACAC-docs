-- bia.Bi_fact_treasury — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_treasury', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_treasury] (
        [Bi_fact_treasuryId] UNIQUEIDENTIFIER NOT NULL,
        [Cuenta] NVARCHAR(512) NULL,
        [Tipo] NVARCHAR(512) NULL,
        [Fecha] NVARCHAR(512) NULL,
        [Fecha_contable] NVARCHAR(512) NULL,
        [Importe] NVARCHAR(512) NULL,
        [Conciliado] NVARCHAR(512) NULL,
        [TreasuryMovementId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_treasury_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_treasury_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_treasury] PRIMARY KEY ([Bi_fact_treasuryId])
    );
END;
GO
