-- bia.Bi_fact_agreement — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_agreement', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_agreement] (
        [Bi_fact_agreementId] UNIQUEIDENTIFIER NOT NULL,
        [Plan] NVARCHAR(512) NULL,
        [Cuotas] NVARCHAR(512) NULL,
        [Capital] NVARCHAR(512) NULL,
        [Interes] NVARCHAR(512) NULL,
        [Estado] NVARCHAR(512) NULL,
        [AgreementId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_agreement_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_agreement_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_agreement] PRIMARY KEY ([Bi_fact_agreementId])
    );
END;
GO
