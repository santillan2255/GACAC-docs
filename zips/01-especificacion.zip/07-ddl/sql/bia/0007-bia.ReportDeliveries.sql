-- bia.ReportDeliveries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ReportDeliveries', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ReportDeliveries] (
        [ReportDeliveryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ScheduleId] NVARCHAR(512) NULL,
        [RunId] NVARCHAR(512) NULL,
        [ExportIds] NVARCHAR(512) NULL,
        [Recipient] NVARCHAR(512) NULL,
        [Channel] NVARCHAR(512) NULL,
        [Email] NVARCHAR(512) NULL,
        [InApp] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Pending] NVARCHAR(512) NULL,
        [Sent] NVARCHAR(512) NULL,
        [SkippedNoPermission] NVARCHAR(512) NULL,
        [Failed] NVARCHAR(512) NULL,
        [Bounced] NVARCHAR(512) NULL,
        [ProviderMessageId] NVARCHAR(512) NULL,
        [SentAt] DATETIME2(7) NULL,
        [Error] NVARCHAR(512) NULL,
        [{tenantId, scheduleId, createdAt:-1}] NVARCHAR(512) NULL,
        [ExportIdsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportDeliveries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportDeliveries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ReportDeliveries] PRIMARY KEY ([ReportDeliveryId]),
        CONSTRAINT [FK_bia_ReportDeliveries_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ReportDeliveries_Tenant] ON [bia].[ReportDeliveries] ([TenantId]);
END;
GO
