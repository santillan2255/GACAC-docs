-- bia.ApiUsageLogs — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ApiUsageLogs', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ApiUsageLogs] (
        [ApiUsageLogId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ApiClientId] NVARCHAR(512) NULL,
        [CredentialPrefix] NVARCHAR(512) NULL,
        [RequestId] NVARCHAR(512) NULL,
        [Method] NVARCHAR(512) NULL,
        [Route] NVARCHAR(512) NULL,
        [ScopeUsed] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [200] NVARCHAR(512) NULL,
        [599] NVARCHAR(512) NULL,
        [ProblemType] NVARCHAR(512) NULL,
        [LatencyMs] NVARCHAR(512) NULL,
        [Rows] NVARCHAR(512) NULL,
        [Bytes] NVARCHAR(512) NULL,
        [Ip] NVARCHAR(512) NULL,
        [At] DATETIME2(7) NULL,
        [ApiUsageDaily] NVARCHAR(512) NULL,
        [PRM-BIA-017] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ApiUsageLogs_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ApiUsageLogs_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ApiUsageLogs] PRIMARY KEY ([ApiUsageLogId]),
        CONSTRAINT [FK_bia_ApiUsageLogs_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ApiUsageLogs_Tenant] ON [bia].[ApiUsageLogs] ([TenantId]);
END;
GO
