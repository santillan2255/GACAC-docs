-- bia.Bi_dim_account — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_dim_account', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_dim_account] (
        [Bi_dim_accountId] UNIQUEIDENTIFIER NOT NULL,
        [AccountId] UNIQUEIDENTIFIER NOT NULL,
        [Titular] NVARCHAR(512) NULL,
        [Sucursal] NVARCHAR(512) NULL,
        [Zona] NVARCHAR(512) NULL,
        [Sector] NVARCHAR(512) NULL,
        [Ruta] NVARCHAR(512) NULL,
        [Localidad] NVARCHAR(512) NULL,
        [Barrio] NVARCHAR(512) NULL,
        [Estado] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_account_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_account_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_dim_account] PRIMARY KEY ([Bi_dim_accountId])
    );
END;
GO
