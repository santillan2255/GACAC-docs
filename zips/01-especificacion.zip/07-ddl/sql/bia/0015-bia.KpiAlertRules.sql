-- bia.KpiAlertRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.KpiAlertRules', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[KpiAlertRules] (
        [KpiAlertRuleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [IndicatorId] NVARCHAR(512) NULL,
        [IndicatorDefinitions] NVARCHAR(512) NULL,
        [IndicatorCode] NVARCHAR(512) NULL,
        [Condition] NVARCHAR(512) NULL,
        [{ op: lt/lte/gt/gte/outOfRange/changePctGt, value, value2, forPeriods }] NVARCHAR(512) NULL,
        [DimensionsFilter] NVARCHAR(512) NULL,
        [Severity] NVARCHAR(512) NULL,
        [Info] NVARCHAR(512) NULL,
        [Warning] NVARCHAR(512) NULL,
        [Critical] NVARCHAR(512) NULL,
        [Recipients] NVARCHAR(512) NULL,
        [Channels] NVARCHAR(512) NULL,
        [InApp] NVARCHAR(512) NULL,
        [Email] NVARCHAR(512) NULL,
        [Push] NVARCHAR(512) NULL,
        [DedupWindowMinutes] NVARCHAR(512) NULL,
        [Escalation] NVARCHAR(512) NULL,
        [{ afterMinutes, toRoleId }] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Paused] NVARCHAR(512) NULL,
        [ConditionJson] NVARCHAR(MAX) NULL,
        [RecipientsJson] NVARCHAR(MAX) NULL,
        [EscalationJson] NVARCHAR(MAX) NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_KpiAlertRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_KpiAlertRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_KpiAlertRules] PRIMARY KEY ([KpiAlertRuleId]),
        CONSTRAINT [FK_bia_KpiAlertRules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_KpiAlertRules_Tenant] ON [bia].[KpiAlertRules] ([TenantId]);
END;
GO
