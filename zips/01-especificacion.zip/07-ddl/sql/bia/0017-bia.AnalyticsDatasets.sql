-- bia.AnalyticsDatasets — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.AnalyticsDatasets', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[AnalyticsDatasets] (
        [AnalyticsDatasetId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [DS-<DOMINIO>] NVARCHAR(512) NULL,
        [NameKey] NVARCHAR(512) NULL,
        [DescriptionKey] NVARCHAR(512) NULL,
        [OwnerModule] NVARCHAR(512) NULL,
        [Grain] NVARCHAR(512) NULL,
        [FactCollection] NVARCHAR(512) NULL,
        [Bi_fact_*] NVARCHAR(512) NULL,
        [Dimensions] NVARCHAR(512) NULL,
        [{ key, labelKey, collection, joinKey, scd: type1/type2 }] NVARCHAR(512) NULL,
        [Measures] NVARCHAR(512) NULL,
        [{ key, labelKey, type, aggregation, additive: full/semi/none, currencyField }] NVARCHAR(512) NULL,
        [Fields] NVARCHAR(512) NULL,
        [{ key, type, sensitive, pii, enumKey }] NVARCHAR(512) NULL,
        [ExposedTo] NVARCHAR(512) NULL,
        [{ builder, api, bi, ai, openData }] NVARCHAR(512) NULL,
        [RequiredCapabilities] NVARCHAR(512) NULL,
        [ApiScope] NVARCHAR(512) NULL,
        [FreshnessTargetMinutes] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [Certified] NVARCHAR(512) NULL,
        [Deprecated] NVARCHAR(512) NULL,
        [Version] NVARCHAR(512) NULL,
        [DimensionsJson] NVARCHAR(MAX) NULL,
        [MeasuresJson] NVARCHAR(MAX) NULL,
        [FieldsJson] NVARCHAR(MAX) NULL,
        [ExposedToJson] NVARCHAR(MAX) NULL,
        [RequiredCapabilitiesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_AnalyticsDatasets_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_AnalyticsDatasets_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_AnalyticsDatasets] PRIMARY KEY ([AnalyticsDatasetId]),
        CONSTRAINT [FK_bia_AnalyticsDatasets_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_AnalyticsDatasets_Tenant] ON [bia].[AnalyticsDatasets] ([TenantId]);
END;
GO
