-- bia.ReportPresets — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ReportPresets', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ReportPresets] (
        [ReportPresetId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ReportCode] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [OwnerUserId] UNIQUEIDENTIFIER NOT NULL,
        [SharedWithRoleIdsId] UNIQUEIDENTIFIER NULL,
        [ParametersJson] NVARCHAR(MAX) NOT NULL,
        [IsDefault] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportPresets_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportPresets_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ReportPresets] PRIMARY KEY ([ReportPresetId]),
        CONSTRAINT [FK_bia_ReportPresets_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ReportPresets_Tenant] ON [bia].[ReportPresets] ([TenantId]);
END;
GO
