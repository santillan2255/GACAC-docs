-- bia.Bi_dim_date — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_dim_date', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_dim_date] (
        [Bi_dim_dateId] UNIQUEIDENTIFIER NOT NULL,
        [Fecha] NVARCHAR(512) NULL,
        [Semana_ISO] NVARCHAR(512) NULL,
        [Mes] NVARCHAR(512) NULL,
        [Trimestre] NVARCHAR(512) NULL,
        [Ano] NVARCHAR(512) NULL,
        [Dia_habil_del_tenant] NVARCHAR(512) NULL,
        [Feriado] NVARCHAR(512) NULL,
        [DateKey] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_date_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_date_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_dim_date] PRIMARY KEY ([Bi_dim_dateId])
    );
END;
GO
