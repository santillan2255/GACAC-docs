-- bia.OpenDataPublications — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.OpenDataPublications', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[OpenDataPublications] (
        [OpenDataPublicationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [DatasetCode] NVARCHAR(512) NULL,
        [Slug] NVARCHAR(512) NULL,
        [TitleKey] NVARCHAR(512) NULL,
        [DescriptionKey] NVARCHAR(512) NULL,
        [License] NVARCHAR(512) NULL,
        [CC-BY-40] NVARCHAR(512) NULL,
        [Aggregation] NVARCHAR(512) NULL,
        [MinCellSize] NVARCHAR(512) NULL,
        [Refresh] NVARCHAR(512) NULL,
        [Monthly] NVARCHAR(512) NULL,
        [Quarterly] NVARCHAR(512) NULL,
        [Formats] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [Approved] NVARCHAR(512) NULL,
        [Published] NVARCHAR(512) NULL,
        [Withdrawn] NVARCHAR(512) NULL,
        [ApprovedBy/At] DATETIME2(7) NULL,
        [LastPublishedAt] DATETIME2(7) NULL,
        [Versions] NVARCHAR(512) NULL,
        [{ version, storageKey, rows, publishedAt }] NVARCHAR(512) NULL,
        [FormatsJson] NVARCHAR(MAX) NULL,
        [ApprovedById] UNIQUEIDENTIFIER NULL,
        [ApprovedAt] DATETIME2(7) NULL,
        [VersionsJson] NVARCHAR(MAX) NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_OpenDataPublications_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_OpenDataPublications_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_OpenDataPublications] PRIMARY KEY ([OpenDataPublicationId]),
        CONSTRAINT [FK_bia_OpenDataPublications_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_OpenDataPublications_Tenant] ON [bia].[OpenDataPublications] ([TenantId]);
END;
GO
