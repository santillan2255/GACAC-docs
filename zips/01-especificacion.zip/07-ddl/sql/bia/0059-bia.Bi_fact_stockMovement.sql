-- bia.Bi_fact_stockMovement — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_stockMovement', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_stockMovement] (
        [Bi_fact_stockMovementId] UNIQUEIDENTIFIER NOT NULL,
        [Producto] NVARCHAR(512) NULL,
        [Deposito] NVARCHAR(512) NULL,
        [Ubicacion] NVARCHAR(512) NULL,
        [Serie] NVARCHAR(512) NULL,
        [Tipo] NVARCHAR(512) NULL,
        [Cantidad] NVARCHAR(512) NULL,
        [Costo] NVARCHAR(512) NULL,
        [StockMovementId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_stockMovement_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_stockMovement_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_stockMovement] PRIMARY KEY ([Bi_fact_stockMovementId])
    );
END;
GO
