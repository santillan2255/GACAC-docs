-- bia.Bi_snap_balance — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_snap_balance', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_snap_balance] (
        [Bi_snap_balanceId] UNIQUEIDENTIFIER NOT NULL,
        [Saldo] NVARCHAR(512) NULL,
        [Vencido] NVARCHAR(512) NULL,
        [Aging_buckets] NVARCHAR(512) NULL,
        [Deuda_en_convenio] NVARCHAR(512) NULL,
        [CurrentAccountId] UNIQUEIDENTIFIER NOT NULL,
        [CutoffDate] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_snap_balance_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_snap_balance_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_snap_balance] PRIMARY KEY ([Bi_snap_balanceId])
    );
END;
GO
