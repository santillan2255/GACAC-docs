-- bia.ReportExports — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ReportExports', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ReportExports] (
        [ReportExportId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [RunId] NVARCHAR(512) NULL,
        [ScreenKey] NVARCHAR(512) NULL,
        [Filters] NVARCHAR(512) NULL,
        [Format] NVARCHAR(512) NULL,
        [Xlsx] NVARCHAR(512) NULL,
        [Csv] NVARCHAR(512) NULL,
        [Pdf] NVARCHAR(512) NULL,
        [Layout] NVARCHAR(512) NULL,
        [Kml] NVARCHAR(512) NULL,
        [Geojson] NVARCHAR(512) NULL,
        [Zip] NVARCHAR(512) NULL,
        [CsvDialect] NVARCHAR(512) NULL,
        [Regional] NVARCHAR(512) NULL,
        [Technical] NVARCHAR(512) NULL,
        [LayoutId] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Queued] NVARCHAR(512) NULL,
        [Generating] NVARCHAR(512) NULL,
        [Ready] NVARCHAR(512) NULL,
        [Failed] NVARCHAR(512) NULL,
        [Expired] NVARCHAR(512) NULL,
        [Cancelled] NVARCHAR(512) NULL,
        [StoredFileId] NVARCHAR(512) NULL,
        [StoredFiles] NVARCHAR(512) NULL,
        [Tenants/<tenantId>/bia/exports/<yyyy>/<mm>/<id>] NVARCHAR(512) NULL,
        [StorageKey] NVARCHAR(512) NULL,
        [FileName] NVARCHAR(512) NULL,
        [SizeBytes] NVARCHAR(512) NULL,
        [Sha256] NVARCHAR(512) NULL,
        [RowCount] NVARCHAR(512) NULL,
        [ContainsPersonalData] NVARCHAR(512) NULL,
        [Masked] NVARCHAR(512) NULL,
        [RequestedBy] NVARCHAR(512) NULL,
        [ExpiresAt] DATETIME2(7) NULL,
        [Downloads] NVARCHAR(512) NULL,
        [{ at, userId, ip }] NVARCHAR(512) NULL,
        [Error] NVARCHAR(512) NULL,
        [{tenantId, requestedBy, createdAt:-1}] NVARCHAR(512) NULL,
        [{tenantId, status}] NVARCHAR(512) NULL,
        [{expiresAt}] NVARCHAR(512) NULL,
        [ReportRunId] UNIQUEIDENTIFIER NOT NULL,
        [RequestedById] UNIQUEIDENTIFIER NULL,
        [DownloadsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportExports_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportExports_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ReportExports] PRIMARY KEY ([ReportExportId]),
        CONSTRAINT [FK_bia_ReportExports_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ReportExports_Tenant] ON [bia].[ReportExports] ([TenantId]);
END;
GO
