-- bia.Bi_fact_invoice — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_invoice', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_invoice] (
        [Bi_fact_invoiceId] UNIQUEIDENTIFIER NOT NULL,
        [InvoiceId] UNIQUEIDENTIFIER NOT NULL,
        [Tipo] NVARCHAR(512) NULL,
        [Letra] NVARCHAR(512) NULL,
        [PV] NVARCHAR(512) NULL,
        [Numero] NVARCHAR(512) NULL,
        [Fechas] NVARCHAR(512) NULL,
        [Contrato] NVARCHAR(512) NULL,
        [Cuenta] NVARCHAR(512) NULL,
        [Servicio] NVARCHAR(512) NULL,
        [Neto] NVARCHAR(512) NULL,
        [Impuestos] NVARCHAR(512) NULL,
        [Total] NVARCHAR(512) NULL,
        [Estado] NVARCHAR(512) NULL,
        [Autorizado] NVARCHAR(512) NULL,
        [Anulado] NVARCHAR(512) NULL,
        [Modalidad] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_invoice_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_invoice_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_invoice] PRIMARY KEY ([Bi_fact_invoiceId])
    );
END;
GO
