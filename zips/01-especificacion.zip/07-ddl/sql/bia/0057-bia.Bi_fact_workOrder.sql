-- bia.Bi_fact_workOrder — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_workOrder', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_workOrder] (
        [Bi_fact_workOrderId] UNIQUEIDENTIFIER NOT NULL,
        [Tipo] NVARCHAR(512) NULL,
        [Operacion] NVARCHAR(512) NULL,
        [Cuadrilla] NVARCHAR(512) NULL,
        [Fechas] NVARCHAR(512) NULL,
        [Resultado] NVARCHAR(512) NULL,
        [Reclamo] NVARCHAR(512) NULL,
        [Reincidencia] NVARCHAR(512) NULL,
        [Costos] NVARCHAR(512) NULL,
        [WorkOrderId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_workOrder_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_workOrder_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_workOrder] PRIMARY KEY ([Bi_fact_workOrderId])
    );
END;
GO
