-- bia.Bi_dim_employee — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_dim_employee', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_dim_employee] (
        [Bi_dim_employeeId] UNIQUEIDENTIFIER NOT NULL,
        [Codigo] NVARCHAR(512) NULL,
        [Nombre] NVARCHAR(512) NULL,
        [Jerarquia] NVARCHAR(512) NULL,
        [Vigencia] NVARCHAR(512) NULL,
        [EmployeeId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_employee_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_employee_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_dim_employee] PRIMARY KEY ([Bi_dim_employeeId])
    );
END;
GO
