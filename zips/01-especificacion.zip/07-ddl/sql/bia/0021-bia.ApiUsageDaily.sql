-- bia.ApiUsageDaily — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ApiUsageDaily', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ApiUsageDaily] (
        [ApiUsageDailyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ApiClientId] UNIQUEIDENTIFIER NOT NULL,
        [Date] DATETIME2(7) NOT NULL,
        [Route] NVARCHAR(512) NOT NULL,
        [Status] INT NOT NULL,
        [Calls] INT NOT NULL,
        [LatencyP95Ms] INT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ApiUsageDaily_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ApiUsageDaily_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ApiUsageDaily] PRIMARY KEY ([ApiUsageDailyId]),
        CONSTRAINT [FK_bia_ApiUsageDaily_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ApiUsageDaily_Tenant] ON [bia].[ApiUsageDaily] ([TenantId]);
END;
GO
