-- bia.DashboardUserPrefs — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.DashboardUserPrefs', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[DashboardUserPrefs] (
        [DashboardUserPrefId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [UserId] NVARCHAR(512) NULL,
        [DashboardCode] NVARCHAR(512) NULL,
        [Pinned] NVARCHAR(512) NULL,
        [Hidden] NVARCHAR(512) NULL,
        [Order] NVARCHAR(512) NULL,
        [Filters] NVARCHAR(512) NULL,
        [{tenantId, userId, dashboardCode}] NVARCHAR(512) NULL,
        [MembershipId] UNIQUEIDENTIFIER NOT NULL,
        [PinnedJson] NVARCHAR(MAX) NULL,
        [HiddenJson] NVARCHAR(MAX) NULL,
        [OrderJson] NVARCHAR(MAX) NULL,
        [FiltersJson] NVARCHAR(MAX) NULL,
        [DashboardId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_DashboardUserPrefs_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_DashboardUserPrefs_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_DashboardUserPrefs] PRIMARY KEY ([DashboardUserPrefId]),
        CONSTRAINT [FK_bia_DashboardUserPrefs_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_DashboardUserPrefs_Tenant] ON [bia].[DashboardUserPrefs] ([TenantId]);
END;
GO
