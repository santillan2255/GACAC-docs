-- bia.Bi_fact_apiUsage — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_apiUsage', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_apiUsage] (
        [Bi_fact_apiUsageId] UNIQUEIDENTIFIER NOT NULL,
        [Cliente] NVARCHAR(512) NULL,
        [Endpoint] NVARCHAR(512) NULL,
        [Estado] NVARCHAR(512) NULL,
        [Latencia] NVARCHAR(512) NULL,
        [ApiClientId] UNIQUEIDENTIFIER NOT NULL,
        [Date] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_apiUsage_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_apiUsage_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_apiUsage] PRIMARY KEY ([Bi_fact_apiUsageId])
    );
END;
GO
