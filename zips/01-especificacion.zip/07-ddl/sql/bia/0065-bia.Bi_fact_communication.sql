-- bia.Bi_fact_communication — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_communication', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_communication] (
        [Bi_fact_communicationId] UNIQUEIDENTIFIER NOT NULL,
        [Canal] NVARCHAR(512) NULL,
        [Campana] NVARCHAR(512) NULL,
        [Entregado] NVARCHAR(512) NULL,
        [Abierto] NVARCHAR(512) NULL,
        [CommunicationId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_communication_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_communication_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_communication] PRIMARY KEY ([Bi_fact_communicationId])
    );
END;
GO
