-- bia.Bi_fact_ledgerEntry — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_ledgerEntry', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_ledgerEntry] (
        [Bi_fact_ledgerEntryId] UNIQUEIDENTIFIER NOT NULL,
        [AccountId] UNIQUEIDENTIFIER NULL,
        [ContractId] UNIQUEIDENTIFIER NULL,
        [Servicio] NVARCHAR(512) NULL,
        [Tipo] NVARCHAR(512) NULL,
        [Debito_credito] NVARCHAR(512) NULL,
        [Fecha_efectiva] NVARCHAR(512) NULL,
        [RecordedAt] DATETIME2(7) NULL,
        [Documento] NVARCHAR(512) NULL,
        [LedgerEntryId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_ledgerEntry_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_ledgerEntry_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_ledgerEntry] PRIMARY KEY ([Bi_fact_ledgerEntryId])
    );
END;
GO
