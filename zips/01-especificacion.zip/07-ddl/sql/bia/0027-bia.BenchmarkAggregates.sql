-- bia.BenchmarkAggregates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.BenchmarkAggregates', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[BenchmarkAggregates] (
        [BenchmarkAggregateId] UNIQUEIDENTIFIER NOT NULL,
        [IndicatorCode] NVARCHAR(512) NULL,
        [PeriodKey] NVARCHAR(512) NULL,
        [SegmentKey] NVARCHAR(512) NULL,
        [N] NVARCHAR(512) NULL,
        [P25] NVARCHAR(512) NULL,
        [Median] NVARCHAR(512) NULL,
        [P75] NVARCHAR(512) NULL,
        [Mean] NVARCHAR(512) NULL,
        [ComputedAt] DATETIME2(7) NULL,
        [IndicatorSnapshots] NVARCHAR(512) NULL,
        [DimensionsBenchmark=true] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NOT NULL,
        [Metric] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_BenchmarkAggregates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_BenchmarkAggregates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_BenchmarkAggregates] PRIMARY KEY ([BenchmarkAggregateId])
    );
END;
GO
