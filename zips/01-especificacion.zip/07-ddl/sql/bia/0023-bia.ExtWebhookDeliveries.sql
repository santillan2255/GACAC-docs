-- bia.ExtWebhookDeliveries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ExtWebhookDeliveries', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ExtWebhookDeliveries] (
        [ExtWebhookDeliveryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SubscriptionId] NVARCHAR(512) NULL,
        [EventId] NVARCHAR(512) NULL,
        [EventType] NVARCHAR(512) NULL,
        [PayloadRef] NVARCHAR(512) NULL,
        [Attempt] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Pending] NVARCHAR(512) NULL,
        [Delivered] NVARCHAR(512) NULL,
        [Failed] NVARCHAR(512) NULL,
        [Retrying] NVARCHAR(512) NULL,
        [Dead] NVARCHAR(512) NULL,
        [ResponseStatus] NVARCHAR(512) NULL,
        [ResponseMs] NVARCHAR(512) NULL,
        [NextAttemptAt] DATETIME2(7) NULL,
        [DeliveredAt] DATETIME2(7) NULL,
        [{tenantId, subscriptionId, createdAt:-1}] NVARCHAR(512) NULL,
        [{status, nextAttemptAt}] NVARCHAR(512) NULL,
        [PRM-BIA-049] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ExtWebhookDeliveries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ExtWebhookDeliveries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ExtWebhookDeliveries] PRIMARY KEY ([ExtWebhookDeliveryId]),
        CONSTRAINT [FK_bia_ExtWebhookDeliveries_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ExtWebhookDeliveries_Tenant] ON [bia].[ExtWebhookDeliveries] ([TenantId]);
END;
GO
