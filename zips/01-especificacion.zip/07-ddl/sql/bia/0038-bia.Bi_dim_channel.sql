-- bia.Bi_dim_channel — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_dim_channel', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_dim_channel] (
        [Bi_dim_channelId] UNIQUEIDENTIFIER NOT NULL,
        [Codigo] NVARCHAR(512) NULL,
        [Nombre] NVARCHAR(512) NULL,
        [Jerarquia] NVARCHAR(512) NULL,
        [Vigencia] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_channel_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_channel_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_dim_channel] PRIMARY KEY ([Bi_dim_channelId])
    );
END;
GO
