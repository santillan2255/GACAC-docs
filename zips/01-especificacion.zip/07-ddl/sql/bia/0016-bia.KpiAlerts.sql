-- bia.KpiAlerts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.KpiAlerts', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[KpiAlerts] (
        [KpiAlertId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [KpiAlertRuleId] NVARCHAR(512) NULL,
        [KpiAlertRules] NVARCHAR(512) NULL,
        [RuleId] NVARCHAR(512) NULL,
        [IndicatorCode] NVARCHAR(512) NULL,
        [DimensionKey] NVARCHAR(512) NULL,
        [Value] NVARCHAR(512) NULL,
        [Severity] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Open] NVARCHAR(512) NULL,
        [Acknowledged] NVARCHAR(512) NULL,
        [Resolved] NVARCHAR(512) NULL,
        [Muted] NVARCHAR(512) NULL,
        [OpenedAt] DATETIME2(7) NULL,
        [AcknowledgedBy/At] DATETIME2(7) NULL,
        [ResolvedBy/At] DATETIME2(7) NULL,
        [ResolutionNote] NVARCHAR(512) NULL,
        [ObjectRef] NVARCHAR(512) NULL,
        [Notifications] NVARCHAR(512) NULL,
        [{tenantId, status, severity}] NVARCHAR(512) NULL,
        [{tenantId, kpiAlertRuleId, dimensionKey, status}] NVARCHAR(512) NULL,
        [AcknowledgedById] UNIQUEIDENTIFIER NULL,
        [AcknowledgedAt] DATETIME2(7) NULL,
        [ResolvedById] UNIQUEIDENTIFIER NULL,
        [ResolvedAt] DATETIME2(7) NULL,
        [NotificationsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_KpiAlerts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_KpiAlerts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_KpiAlerts] PRIMARY KEY ([KpiAlertId]),
        CONSTRAINT [FK_bia_KpiAlerts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_KpiAlerts_Tenant] ON [bia].[KpiAlerts] ([TenantId]);
END;
GO
