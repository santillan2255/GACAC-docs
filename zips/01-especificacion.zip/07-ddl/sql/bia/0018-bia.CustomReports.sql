-- bia.CustomReports — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.CustomReports', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[CustomReports] (
        [CustomReportId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [REP-TEN-NNNN] NVARCHAR(512) NULL,
        [DatasetId] NVARCHAR(512) NULL,
        [Fields] NVARCHAR(512) NULL,
        [Filters] NVARCHAR(512) NULL,
        [GroupBy] NVARCHAR(512) NULL,
        [Measures] NVARCHAR(512) NULL,
        [Sort] NVARCHAR(512) NULL,
        [Chart] NVARCHAR(512) NULL,
        [{ type, x, y }] NVARCHAR(512) NULL,
        [ConditionalFormats] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [InReview] NVARCHAR(512) NULL,
        [Published] NVARCHAR(512) NULL,
        [Deprecated] NVARCHAR(512) NULL,
        [OwnerUserId] NVARCHAR(512) NULL,
        [PublishedToRoleIds] NVARCHAR(512) NULL,
        [ApprovedBy/At] DATETIME2(7) NULL,
        [TemplateOriginId] NVARCHAR(512) NULL,
        [CustomReports] NVARCHAR(512) NULL,
        [Version] NVARCHAR(512) NULL,
        [ReportDefinitions] NVARCHAR(512) NULL,
        [Origin=custom] NVARCHAR(512) NULL,
        [FieldsJson] NVARCHAR(MAX) NULL,
        [FiltersJson] NVARCHAR(MAX) NULL,
        [GroupByJson] NVARCHAR(MAX) NULL,
        [MeasuresJson] NVARCHAR(MAX) NULL,
        [SortJson] NVARCHAR(MAX) NULL,
        [ChartJson] NVARCHAR(MAX) NULL,
        [ConditionalFormatsJson] NVARCHAR(MAX) NULL,
        [PublishedToRoleIdsJson] NVARCHAR(MAX) NULL,
        [ApprovedById] UNIQUEIDENTIFIER NULL,
        [ApprovedAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_CustomReports_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_CustomReports_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_CustomReports] PRIMARY KEY ([CustomReportId]),
        CONSTRAINT [FK_bia_CustomReports_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_CustomReports_Tenant] ON [bia].[CustomReports] ([TenantId]);
END;
GO
