-- bia.ReportDefinitions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ReportDefinitions', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ReportDefinitions] (
        [ReportDefinitionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Origin] VARCHAR(64) NOT NULL,
        [OwnerModule] VARCHAR(64) NOT NULL,
        [Cluster] NVARCHAR(512) NOT NULL,
        [Grain] VARCHAR(64) NOT NULL,
        [Source] VARCHAR(64) NOT NULL,
        [ProviderKey] NVARCHAR(512) NOT NULL,
        [DatasetId] UNIQUEIDENTIFIER NOT NULL,
        [Parameters] VARCHAR(64) NOT NULL,
        [DateTypes] VARCHAR(64) NULL,
        [Columns] VARCHAR(64) NOT NULL,
        [Outputs] VARCHAR(64) NOT NULL,
        [Sensitivity] VARCHAR(64) NOT NULL,
        [ScopeDimensions] VARCHAR(64) NULL,
        [TemplateId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [ProcoopEquivalents] NVARCHAR(512) NULL,
        [Wave] NVARCHAR(512) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [DefinitionVersion] INT NOT NULL,
        [TenantOverridesJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportDefinitions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportDefinitions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ReportDefinitions] PRIMARY KEY ([ReportDefinitionId]),
        CONSTRAINT [FK_bia_ReportDefinitions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ReportDefinitions_Tenant] ON [bia].[ReportDefinitions] ([TenantId]);
END;
GO
