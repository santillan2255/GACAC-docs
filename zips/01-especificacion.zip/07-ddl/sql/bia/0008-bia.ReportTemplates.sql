-- bia.ReportTemplates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ReportTemplates', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ReportTemplates] (
        [ReportTemplateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ReportCode] NVARCHAR(512) NULL,
        [Scope] VARCHAR(64) NULL,
        [Engine] NVARCHAR(512) NULL,
        [Paper] VARCHAR(64) NULL,
        [Orientation] NVARCHAR(512) NULL,
        [Header] NVARCHAR(512) NULL,
        [Footer] NVARCHAR(512) NULL,
        [ColumnOrderJson] NVARCHAR(MAX) NULL,
        [AssetsJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportTemplates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportTemplates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ReportTemplates] PRIMARY KEY ([ReportTemplateId]),
        CONSTRAINT [FK_bia_ReportTemplates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ReportTemplates_Tenant] ON [bia].[ReportTemplates] ([TenantId]);
END;
GO
