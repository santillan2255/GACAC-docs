-- bia.Bi_fact_turn — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_turn', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_turn] (
        [Bi_fact_turnId] UNIQUEIDENTIFIER NOT NULL,
        [Area] NVARCHAR(512) NULL,
        [Box] NVARCHAR(512) NULL,
        [Espera] NVARCHAR(512) NULL,
        [Atencion] NVARCHAR(512) NULL,
        [Resultado] NVARCHAR(512) NULL,
        [CrmQueueTicketId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_turn_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_turn_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_turn] PRIMARY KEY ([Bi_fact_turnId])
    );
END;
GO
