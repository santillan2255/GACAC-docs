-- bia.ExtBulkExports — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ExtBulkExports', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ExtBulkExports] (
        [ExtBulkExportId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ApiClientId] NVARCHAR(512) NULL,
        [UserId] NVARCHAR(512) NULL,
        [DatasetCode] NVARCHAR(512) NULL,
        [Resource] NVARCHAR(512) NULL,
        [Filters] NVARCHAR(512) NULL,
        [Format] NVARCHAR(512) NULL,
        [Ndjson] NVARCHAR(512) NULL,
        [Csv] NVARCHAR(512) NULL,
        [Parquet] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Queued] NVARCHAR(512) NULL,
        [Running] NVARCHAR(512) NULL,
        [Ready] NVARCHAR(512) NULL,
        [Failed] NVARCHAR(512) NULL,
        [Expired] NVARCHAR(512) NULL,
        [Parts] NVARCHAR(512) NULL,
        [{ storageKey, rows, sha256 }] NVARCHAR(512) NULL,
        [AsOf] NVARCHAR(512) NULL,
        [ExpiresAt] DATETIME2(7) NULL,
        [Purpose] NVARCHAR(512) NULL,
        [Bi] NVARCHAR(512) NULL,
        [Exit] NVARCHAR(512) NULL,
        [FiltersJson] NVARCHAR(MAX) NULL,
        [PartsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ExtBulkExports_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ExtBulkExports_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ExtBulkExports] PRIMARY KEY ([ExtBulkExportId]),
        CONSTRAINT [FK_bia_ExtBulkExports_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ExtBulkExports_Tenant] ON [bia].[ExtBulkExports] ([TenantId]);
END;
GO
