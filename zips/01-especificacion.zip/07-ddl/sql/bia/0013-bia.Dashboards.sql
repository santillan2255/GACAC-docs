-- bia.Dashboards — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Dashboards', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Dashboards] (
        [DashboardId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [DSH-<ROL>] NVARCHAR(512) NULL,
        [NameKey] NVARCHAR(512) NULL,
        [AudienceRoleIds] NVARCHAR(512) NULL,
        [AudienceType] NVARCHAR(512) NULL,
        [Platform] NVARCHAR(512) NULL,
        [Tenant] NVARCHAR(512) NULL,
        [Area] NVARCHAR(512) NULL,
        [Widgets] NVARCHAR(512) NULL,
        [{ widgetId, type: kpi/series/bars/ranking/pie/table/heatmap/funnel/map/alertList/pendingList, indicatorCodes, reportCode, dimensions, period, size: s/m/l, position }] NVARCHAR(512) NULL,
        [GlobalFilters] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [Published] NVARCHAR(512) NULL,
        [Archived] NVARCHAR(512) NULL,
        [Origin] NVARCHAR(512) NULL,
        [System] NVARCHAR(512) NULL,
        [Legacy] NVARCHAR(512) NULL,
        [Table] NVARCHAR(512) NULL,
        [GRUPTAB] NVARCHAR(512) NULL,
        [GRUTAB] NVARCHAR(512) NULL,
        [LegacyRef] NVARCHAR(512) NULL,
        [GRAFTABTIP_GRA] NVARCHAR(512) NULL,
        [WidgetsType] NVARCHAR(512) NULL,
        [AudienceRoleIdsJson] NVARCHAR(MAX) NULL,
        [WidgetsJson] NVARCHAR(MAX) NULL,
        [GlobalFiltersJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Dashboards_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Dashboards_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Dashboards] PRIMARY KEY ([DashboardId]),
        CONSTRAINT [FK_bia_Dashboards_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_Dashboards_Tenant] ON [bia].[Dashboards] ([TenantId]);
END;
GO
