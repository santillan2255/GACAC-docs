-- bia.Bi_fact_payroll — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_payroll', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_payroll] (
        [Bi_fact_payrollId] UNIQUEIDENTIFIER NOT NULL,
        [Liquidacion] NVARCHAR(512) NULL,
        [Concepto] NVARCHAR(512) NULL,
        [Centro] NVARCHAR(512) NULL,
        [Importe] NVARCHAR(512) NULL,
        [Horas] NVARCHAR(512) NULL,
        [PayslipId] UNIQUEIDENTIFIER NOT NULL,
        [ConceptCode] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_payroll_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_payroll_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_payroll] PRIMARY KEY ([Bi_fact_payrollId])
    );
END;
GO
