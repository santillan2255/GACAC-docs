-- bia.Bi_fact_member — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_member', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_member] (
        [Bi_fact_memberId] UNIQUEIDENTIFIER NOT NULL,
        [Alta] NVARCHAR(512) NULL,
        [Baja asociado] NVARCHAR(512) NULL,
        [Capital_suscripto_integrado] NVARCHAR(512) NULL,
        [AssociateMembershipId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [Date] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_member_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_member_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_member] PRIMARY KEY ([Bi_fact_memberId])
    );
END;
GO
