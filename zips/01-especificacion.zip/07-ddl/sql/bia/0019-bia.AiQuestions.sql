-- bia.AiQuestions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.AiQuestions', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[AiQuestions] (
        [AiQuestionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [UserId] NVARCHAR(512) NULL,
        [Room] NVARCHAR(512) NULL,
        [QuestionText] NVARCHAR(512) NULL,
        [CatalogQuestionCode] NVARCHAR(512) NULL,
        [CatalogQuestionId] NVARCHAR(512) NULL,
        [SemanticQuery] NVARCHAR(512) NULL,
        [ResultSummary] NVARCHAR(512) NULL,
        [Citations] NVARCHAR(512) NULL,
        [{ indicatorCode | datasetCode, cutoff, universeText }] NVARCHAR(512) NULL,
        [AnswerText] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Answered] NVARCHAR(512) NULL,
        [Refused] NVARCHAR(512) NULL,
        [Failed] NVARCHAR(512) NULL,
        [RefusalReason] NVARCHAR(512) NULL,
        [OutOfScope] NVARCHAR(512) NULL,
        [NoData] NVARCHAR(512) NULL,
        [Unsupported] NVARCHAR(512) NULL,
        [Pii] NVARCHAR(512) NULL,
        [Provider] NVARCHAR(512) NULL,
        [Model] NVARCHAR(512) NULL,
        [TokensIn] NVARCHAR(512) NULL,
        [TokensOut] NVARCHAR(512) NULL,
        [Feedback] NVARCHAR(512) NULL,
        [Up] NVARCHAR(512) NULL,
        [Down] NVARCHAR(512) NULL,
        [At] DATETIME2(7) NULL,
        [PRM-BIA-035] NVARCHAR(512) NULL,
        [SemanticQueryJson] NVARCHAR(MAX) NULL,
        [CitationsJson] NVARCHAR(MAX) NULL,
        [AiUsageLogId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_AiQuestions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_AiQuestions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_AiQuestions] PRIMARY KEY ([AiQuestionId]),
        CONSTRAINT [FK_bia_AiQuestions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_AiQuestions_Tenant] ON [bia].[AiQuestions] ([TenantId]);
END;
GO
