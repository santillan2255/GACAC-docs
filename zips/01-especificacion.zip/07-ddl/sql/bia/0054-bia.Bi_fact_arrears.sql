-- bia.Bi_fact_arrears — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_arrears', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_arrears] (
        [Bi_fact_arrearId] UNIQUEIDENTIFIER NOT NULL,
        [Instancia] NVARCHAR(512) NULL,
        [Notificacion] NVARCHAR(512) NULL,
        [Promesa] NVARCHAR(512) NULL,
        [Corte] NVARCHAR(512) NULL,
        [Reconexion] NVARCHAR(512) NULL,
        [AccountId] UNIQUEIDENTIFIER NOT NULL,
        [CutoffDate] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_arrears_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_arrears_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_arrears] PRIMARY KEY ([Bi_fact_arrearId])
    );
END;
GO
