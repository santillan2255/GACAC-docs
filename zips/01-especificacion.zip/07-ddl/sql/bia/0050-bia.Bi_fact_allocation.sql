-- bia.Bi_fact_allocation — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_fact_allocation', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_fact_allocation] (
        [Bi_fact_allocationId] UNIQUEIDENTIFIER NOT NULL,
        [PaymentId] UNIQUEIDENTIFIER NULL,
        [InvoiceId] UNIQUEIDENTIFIER NULL,
        [Importe] NVARCHAR(512) NULL,
        [Fecha_efectiva] NVARCHAR(512) NULL,
        [AllocationId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_allocation_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_fact_allocation_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_fact_allocation] PRIMARY KEY ([Bi_fact_allocationId])
    );
END;
GO
