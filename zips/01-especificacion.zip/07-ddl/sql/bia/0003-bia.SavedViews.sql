-- bia.SavedViews — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.SavedViews', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[SavedViews] (
        [SavedViewId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [DataTable] NVARCHAR(512) NULL,
        [ScreenKey] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [OwnerUserId] NVARCHAR(512) NULL,
        [SharedWithRoleIds] NVARCHAR(512) NULL,
        [Filters] NVARCHAR(512) NULL,
        [Eq/in/between/contains/gte/lte] NVARCHAR(512) NULL,
        [Columns] NVARCHAR(512) NULL,
        [FieldKey] NVARCHAR(512) NULL,
        [Width] NVARCHAR(512) NULL,
        [Visible] NVARCHAR(512) NULL,
        [Sort] NVARCHAR(512) NULL,
        [GroupBy] NVARCHAR(512) NULL,
        [PageSize] NVARCHAR(512) NULL,
        [IsDefault] NVARCHAR(512) NULL,
        [Legacy] NVARCHAR(512) NULL,
        [Table] NVARCHAR(512) NULL,
        [ENTIDACOU] NVARCHAR(512) NULL,
        [LegacyRef] NVARCHAR(512) NULL,
        [{tenantId, screenKey, ownerUserId}] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_SavedViews_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_SavedViews_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_SavedViews] PRIMARY KEY ([SavedViewId]),
        CONSTRAINT [FK_bia_SavedViews_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_SavedViews_Tenant] ON [bia].[SavedViews] ([TenantId]);
END;
GO
