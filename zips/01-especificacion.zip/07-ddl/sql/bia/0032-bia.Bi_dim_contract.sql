-- bia.Bi_dim_contract — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.Bi_dim_contract', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[Bi_dim_contract] (
        [Bi_dim_contractId] UNIQUEIDENTIFIER NOT NULL,
        [ContractId] UNIQUEIDENTIFIER NOT NULL,
        [Servicio] NVARCHAR(512) NULL,
        [Plan] NVARCHAR(512) NULL,
        [Categoria] NVARCHAR(512) NULL,
        [Estado] NVARCHAR(512) NULL,
        [Fecha_alta_baja] NVARCHAR(512) NULL,
        [Prepago] NVARCHAR(512) NULL,
        [Medido] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_contract_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_Bi_dim_contract_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_Bi_dim_contract] PRIMARY KEY ([Bi_dim_contractId])
    );
END;
GO
