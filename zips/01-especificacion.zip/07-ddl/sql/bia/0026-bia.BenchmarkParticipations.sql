-- bia.BenchmarkParticipations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.BenchmarkParticipations', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[BenchmarkParticipations] (
        [BenchmarkParticipationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Status] NVARCHAR(512) NULL,
        [OptedIn] NVARCHAR(512) NULL,
        [OptedOut] NVARCHAR(512) NULL,
        [SegmentAttributes] NVARCHAR(512) NULL,
        [{ services, sizeBand, province }] NVARCHAR(512) NULL,
        [ConsentBy/At] DATETIME2(7) NULL,
        [WithdrawnAt] DATETIME2(7) NULL,
        [SegmentAttributesJson] NVARCHAR(MAX) NULL,
        [ConsentById] UNIQUEIDENTIFIER NULL,
        [ConsentAt] DATETIME2(7) NULL,
        [Period] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_BenchmarkParticipations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_BenchmarkParticipations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_BenchmarkParticipations] PRIMARY KEY ([BenchmarkParticipationId]),
        CONSTRAINT [FK_bia_BenchmarkParticipations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_BenchmarkParticipations_Tenant] ON [bia].[BenchmarkParticipations] ([TenantId]);
END;
GO
