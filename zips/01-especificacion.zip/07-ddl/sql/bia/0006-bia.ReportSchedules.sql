-- bia.ReportSchedules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.ReportSchedules', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[ReportSchedules] (
        [ReportScheduleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ReportCode] NVARCHAR(512) NULL,
        [PresetId] NVARCHAR(512) NULL,
        [Parameters] NVARCHAR(512) NULL,
        [OwnerUserId] NVARCHAR(512) NULL,
        [Recurrence] NVARCHAR(512) NULL,
        [{ type: daily/weekly/monthly/businessDay/cron/event, daysOfWeek, dayOfMonth, nthBusinessDay, cron, eventType, timeOfDay }] NVARCHAR(512) NULL,
        [TimeZone] NVARCHAR(512) NULL,
        [Formats] NVARCHAR(512) NULL,
        [Recipients] NVARCHAR(512) NULL,
        [{ type: user/role/email, ref, verifiedAt }] NVARCHAR(512) NULL,
        [DeliveryMode] NVARCHAR(512) NULL,
        [Link] NVARCHAR(512) NULL,
        [Attachment] NVARCHAR(512) NULL,
        [SubjectKey] NVARCHAR(512) NULL,
        [MessageText] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Paused] NVARCHAR(512) NULL,
        [Suspended] NVARCHAR(512) NULL,
        [Disabled] NVARCHAR(512) NULL,
        [ConsecutiveFailures] NVARCHAR(512) NULL,
        [NextRunAt] DATETIME2(7) NULL,
        [LastRunAt] DATETIME2(7) NULL,
        [LastRunId] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ValidTo] NVARCHAR(512) NULL,
        [{tenantId, status, nextRunAt}] NVARCHAR(512) NULL,
        [{tenantId, ownerUserId}] NVARCHAR(512) NULL,
        [ParametersJson] NVARCHAR(MAX) NULL,
        [RecurrenceJson] NVARCHAR(MAX) NULL,
        [FormatsJson] NVARCHAR(MAX) NULL,
        [RecipientsJson] NVARCHAR(MAX) NULL,
        [ReportDefinitionId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportSchedules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_ReportSchedules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_ReportSchedules] PRIMARY KEY ([ReportScheduleId]),
        CONSTRAINT [FK_bia_ReportSchedules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_ReportSchedules_Tenant] ON [bia].[ReportSchedules] ([TenantId]);
END;
GO
