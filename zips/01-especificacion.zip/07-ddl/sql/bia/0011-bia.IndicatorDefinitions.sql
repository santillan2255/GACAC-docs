-- bia.IndicatorDefinitions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'bia.IndicatorDefinitions', N'U') IS NULL
BEGIN
    CREATE TABLE [bia].[IndicatorDefinitions] (
        [IndicatorDefinitionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [OwnerModule] VARCHAR(64) NOT NULL,
        [FormulaJson] NVARCHAR(MAX) NOT NULL,
        [DatasetId] UNIQUEIDENTIFIER NOT NULL,
        [Grain] VARCHAR(64) NOT NULL,
        [UniverseJson] NVARCHAR(MAX) NOT NULL,
        [Unit] VARCHAR(64) NOT NULL,
        [Decimals] INT NOT NULL,
        [Direction] VARCHAR(64) NOT NULL,
        [TargetsJson] NVARCHAR(MAX) NULL,
        [Dimensions] NVARCHAR(512) NULL,
        [Refresh] VARCHAR(64) NOT NULL,
        [DetailCapability] NVARCHAR(512) NOT NULL,
        [DrillReportCode] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [DefinitionVersion] INT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_IndicatorDefinitions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_bia_IndicatorDefinitions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_bia_IndicatorDefinitions] PRIMARY KEY ([IndicatorDefinitionId]),
        CONSTRAINT [FK_bia_IndicatorDefinitions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_bia_IndicatorDefinitions_Tenant] ON [bia].[IndicatorDefinitions] ([TenantId]);
END;
GO
