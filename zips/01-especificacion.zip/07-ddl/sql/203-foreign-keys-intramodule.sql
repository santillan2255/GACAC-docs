-- FK intra-módulo (mismo esquema) — 2026-11-19
-- Variante conservadora: sin FK cruzadas entre esquemas
-- Sustituye a 201-deferred-foreign-keys.sql en deploy si se desea

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_CustomReports_DatasetId_AnalyticsDatasets'
)
BEGIN
    ALTER TABLE [bia].[CustomReports]
        ADD CONSTRAINT [FK_bia_CustomReports_DatasetId_AnalyticsDatasets]
        FOREIGN KEY ([DatasetId]) REFERENCES [bia].[AnalyticsDatasets] ([AnalyticsDatasetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_DashboardUserPrefs_DashboardId_Dashboards'
)
BEGIN
    ALTER TABLE [bia].[DashboardUserPrefs]
        ADD CONSTRAINT [FK_bia_DashboardUserPrefs_DashboardId_Dashboards]
        FOREIGN KEY ([DashboardId]) REFERENCES [bia].[Dashboards] ([DashboardId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportExports_LayoutId_ExportLayouts'
)
BEGIN
    ALTER TABLE [bia].[ReportExports]
        ADD CONSTRAINT [FK_bia_ReportExports_LayoutId_ExportLayouts]
        FOREIGN KEY ([LayoutId]) REFERENCES [bia].[ExportLayouts] ([ExportLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ExtWebhookDeliveries_SubscriptionId_ExtWebhookSubscriptions'
)
BEGIN
    ALTER TABLE [bia].[ExtWebhookDeliveries]
        ADD CONSTRAINT [FK_bia_ExtWebhookDeliveries_SubscriptionId_ExtWebhookSubscriptions]
        FOREIGN KEY ([SubscriptionId]) REFERENCES [bia].[ExtWebhookSubscriptions] ([ExtWebhookSubscriptionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_IndicatorSnapshots_IndicatorId_IndicatorDefinitions'
)
BEGIN
    ALTER TABLE [bia].[IndicatorSnapshots]
        ADD CONSTRAINT [FK_bia_IndicatorSnapshots_IndicatorId_IndicatorDefinitions]
        FOREIGN KEY ([IndicatorId]) REFERENCES [bia].[IndicatorDefinitions] ([IndicatorDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_KpiAlertRules_IndicatorId_IndicatorDefinitions'
)
BEGIN
    ALTER TABLE [bia].[KpiAlertRules]
        ADD CONSTRAINT [FK_bia_KpiAlertRules_IndicatorId_IndicatorDefinitions]
        FOREIGN KEY ([IndicatorId]) REFERENCES [bia].[IndicatorDefinitions] ([IndicatorDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_KpiAlerts_KpiAlertRuleId_KpiAlertRules'
)
BEGIN
    ALTER TABLE [bia].[KpiAlerts]
        ADD CONSTRAINT [FK_bia_KpiAlerts_KpiAlertRuleId_KpiAlertRules]
        FOREIGN KEY ([KpiAlertRuleId]) REFERENCES [bia].[KpiAlertRules] ([KpiAlertRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportAccessLogs_ReportDefinitionId_ReportDefinitions'
)
BEGIN
    ALTER TABLE [bia].[ReportAccessLogs]
        ADD CONSTRAINT [FK_bia_ReportAccessLogs_ReportDefinitionId_ReportDefinitions]
        FOREIGN KEY ([ReportDefinitionId]) REFERENCES [bia].[ReportDefinitions] ([ReportDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportSchedules_ReportDefinitionId_ReportDefinitions'
)
BEGIN
    ALTER TABLE [bia].[ReportSchedules]
        ADD CONSTRAINT [FK_bia_ReportSchedules_ReportDefinitionId_ReportDefinitions]
        FOREIGN KEY ([ReportDefinitionId]) REFERENCES [bia].[ReportDefinitions] ([ReportDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportSchedules_PresetId_ReportPresets'
)
BEGIN
    ALTER TABLE [bia].[ReportSchedules]
        ADD CONSTRAINT [FK_bia_ReportSchedules_PresetId_ReportPresets]
        FOREIGN KEY ([PresetId]) REFERENCES [bia].[ReportPresets] ([ReportPresetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportExports_ReportRunId_ReportRuns'
)
BEGIN
    ALTER TABLE [bia].[ReportExports]
        ADD CONSTRAINT [FK_bia_ReportExports_ReportRunId_ReportRuns]
        FOREIGN KEY ([ReportRunId]) REFERENCES [bia].[ReportRuns] ([ReportRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportAccessLogs_RunId_ReportRuns'
)
BEGIN
    ALTER TABLE [bia].[ReportAccessLogs]
        ADD CONSTRAINT [FK_bia_ReportAccessLogs_RunId_ReportRuns]
        FOREIGN KEY ([RunId]) REFERENCES [bia].[ReportRuns] ([ReportRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportRunResults_ReportRunId_ReportRuns'
)
BEGIN
    ALTER TABLE [bia].[ReportRunResults]
        ADD CONSTRAINT [FK_bia_ReportRunResults_ReportRunId_ReportRuns]
        FOREIGN KEY ([ReportRunId]) REFERENCES [bia].[ReportRuns] ([ReportRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportSchedules_LastRunId_ReportRuns'
)
BEGIN
    ALTER TABLE [bia].[ReportSchedules]
        ADD CONSTRAINT [FK_bia_ReportSchedules_LastRunId_ReportRuns]
        FOREIGN KEY ([LastRunId]) REFERENCES [bia].[ReportRuns] ([ReportRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportDeliveries_RunId_ReportRuns'
)
BEGIN
    ALTER TABLE [bia].[ReportDeliveries]
        ADD CONSTRAINT [FK_bia_ReportDeliveries_RunId_ReportRuns]
        FOREIGN KEY ([RunId]) REFERENCES [bia].[ReportRuns] ([ReportRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportAccessLogs_ExportId_ReportExports'
)
BEGIN
    ALTER TABLE [bia].[ReportAccessLogs]
        ADD CONSTRAINT [FK_bia_ReportAccessLogs_ExportId_ReportExports]
        FOREIGN KEY ([ExportId]) REFERENCES [bia].[ReportExports] ([ReportExportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportDeliveries_ScheduleId_ReportSchedules'
)
BEGIN
    ALTER TABLE [bia].[ReportDeliveries]
        ADD CONSTRAINT [FK_bia_ReportDeliveries_ScheduleId_ReportSchedules]
        FOREIGN KEY ([ScheduleId]) REFERENCES [bia].[ReportSchedules] ([ReportScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceTemplates_CapabilityId_ServiceCapabilities'
)
BEGIN
    ALTER TABLE [cat].[ServiceTemplates]
        ADD CONSTRAINT [FK_cat_ServiceTemplates_CapabilityId_ServiceCapabilities]
        FOREIGN KEY ([CapabilityId]) REFERENCES [cat].[ServiceCapabilities] ([ServiceCapabilityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_TenantServices_CapabilityId_ServiceCapabilities'
)
BEGIN
    ALTER TABLE [cat].[TenantServices]
        ADD CONSTRAINT [FK_cat_TenantServices_CapabilityId_ServiceCapabilities]
        FOREIGN KEY ([CapabilityId]) REFERENCES [cat].[ServiceCapabilities] ([ServiceCapabilityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceBundles_PlanVersionIdsId_ServicePlanVersions'
)
BEGIN
    ALTER TABLE [cat].[ServiceBundles]
        ADD CONSTRAINT [FK_cat_ServiceBundles_PlanVersionIdsId_ServicePlanVersions]
        FOREIGN KEY ([PlanVersionIdsId]) REFERENCES [cat].[ServicePlanVersions] ([ServicePlanVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServicePlans_CurrentVersionId_ServicePlanVersions'
)
BEGIN
    ALTER TABLE [cat].[ServicePlans]
        ADD CONSTRAINT [FK_cat_ServicePlans_CurrentVersionId_ServicePlanVersions]
        FOREIGN KEY ([CurrentVersionId]) REFERENCES [cat].[ServicePlanVersions] ([ServicePlanVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BundleSubscriptions_BundleId_ServiceBundles'
)
BEGIN
    ALTER TABLE [cat].[BundleSubscriptions]
        ADD CONSTRAINT [FK_cat_BundleSubscriptions_BundleId_ServiceBundles]
        FOREIGN KEY ([BundleId]) REFERENCES [cat].[ServiceBundles] ([ServiceBundleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServicePlans_ServiceProductId_ServiceProducts'
)
BEGIN
    ALTER TABLE [cat].[ServicePlans]
        ADD CONSTRAINT [FK_cat_ServicePlans_ServiceProductId_ServiceProducts]
        FOREIGN KEY ([ServiceProductId]) REFERENCES [cat].[ServiceProducts] ([ServiceProductId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_OperationalStatusId_ServiceStatuses'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts]
        ADD CONSTRAINT [FK_cat_ServiceContracts_OperationalStatusId_ServiceStatuses]
        FOREIGN KEY ([OperationalStatusId]) REFERENCES [cat].[ServiceStatuses] ([ServiceStatusId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ApplianceTypes_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ApplianceTypes]
        ADD CONSTRAINT [FK_cat_ApplianceTypes_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceCategoryGroups_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ServiceCategoryGroups]
        ADD CONSTRAINT [FK_cat_ServiceCategoryGroups_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceClasses_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ServiceClasses]
        ADD CONSTRAINT [FK_cat_ServiceClasses_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceConcessions_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ServiceConcessions]
        ADD CONSTRAINT [FK_cat_ServiceConcessions_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServicePlans_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ServicePlans]
        ADD CONSTRAINT [FK_cat_ServicePlans_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceProperties_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ServiceProperties]
        ADD CONSTRAINT [FK_cat_ServiceProperties_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractDeclaredAppliances_ApplianceTypeId_ApplianceTypes'
)
BEGIN
    ALTER TABLE [cat].[ContractDeclaredAppliances]
        ADD CONSTRAINT [FK_cat_ContractDeclaredAppliances_ApplianceTypeId_ApplianceTypes]
        FOREIGN KEY ([ApplianceTypeId]) REFERENCES [cat].[ApplianceTypes] ([ApplianceTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceCategories_GroupId_ServiceCategoryGroups'
)
BEGIN
    ALTER TABLE [cat].[ServiceCategories]
        ADD CONSTRAINT [FK_cat_ServiceCategories_GroupId_ServiceCategoryGroups]
        FOREIGN KEY ([GroupId]) REFERENCES [cat].[ServiceCategoryGroups] ([ServiceCategoryGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Holidays_CalendarId_Calendars'
)
BEGIN
    ALTER TABLE [cfg].[Holidays]
        ADD CONSTRAINT [FK_cfg_Holidays_CalendarId_Calendars]
        FOREIGN KEY ([CalendarId]) REFERENCES [cfg].[Calendars] ([CalendarId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_FormCustomizations_ConfigVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [cfg].[FormCustomizations]
        ADD CONSTRAINT [FK_cfg_FormCustomizations_ConfigVersionId_ConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_MasterImportJobs_ConfigVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [cfg].[MasterImportJobs]
        ADD CONSTRAINT [FK_cfg_MasterImportJobs_ConfigVersionId_ConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_SeedApplications_ConfigVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [cfg].[SeedApplications]
        ADD CONSTRAINT [FK_cfg_SeedApplications_ConfigVersionId_ConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Provinces_CountryId_Countries'
)
BEGIN
    ALTER TABLE [cfg].[Provinces]
        ADD CONSTRAINT [FK_cfg_Provinces_CountryId_Countries]
        FOREIGN KEY ([CountryId]) REFERENCES [cfg].[Countries] ([CountryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_EconomicIndexValues_SeriesId_EconomicIndexSeries'
)
BEGIN
    ALTER TABLE [cfg].[EconomicIndexValues]
        ADD CONSTRAINT [FK_cfg_EconomicIndexValues_SeriesId_EconomicIndexSeries]
        FOREIGN KEY ([SeriesId]) REFERENCES [cfg].[EconomicIndexSeries] ([EconomicIndexSeryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_PlatformTableReleases_SeriesId_EconomicIndexSeries'
)
BEGIN
    ALTER TABLE [cfg].[PlatformTableReleases]
        ADD CONSTRAINT [FK_cfg_PlatformTableReleases_SeriesId_EconomicIndexSeries]
        FOREIGN KEY ([SeriesId]) REFERENCES [cfg].[EconomicIndexSeries] ([EconomicIndexSeryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_PlatformTableAdoptions_SeriesId_EconomicIndexSeries'
)
BEGIN
    ALTER TABLE [cfg].[PlatformTableAdoptions]
        ADD CONSTRAINT [FK_cfg_PlatformTableAdoptions_SeriesId_EconomicIndexSeries]
        FOREIGN KEY ([SeriesId]) REFERENCES [cfg].[EconomicIndexSeries] ([EconomicIndexSeryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_EnumerationItems_EnumerationId_Enumerations'
)
BEGIN
    ALTER TABLE [cfg].[EnumerationItems]
        ADD CONSTRAINT [FK_cfg_EnumerationItems_EnumerationId_Enumerations]
        FOREIGN KEY ([EnumerationId]) REFERENCES [cfg].[Enumerations] ([EnumerationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Branches_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [cfg].[Branches]
        ADD CONSTRAINT [FK_cfg_Branches_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_MasterImportJobs_PlatformTableReleaseId_PlatformTableReleases'
)
BEGIN
    ALTER TABLE [cfg].[MasterImportJobs]
        ADD CONSTRAINT [FK_cfg_MasterImportJobs_PlatformTableReleaseId_PlatformTableReleases]
        FOREIGN KEY ([PlatformTableReleaseId]) REFERENCES [cfg].[PlatformTableReleases] ([PlatformTableReleasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_PlatformTableAdoptions_ReleaseId_PlatformTableReleases'
)
BEGIN
    ALTER TABLE [cfg].[PlatformTableAdoptions]
        ADD CONSTRAINT [FK_cfg_PlatformTableAdoptions_ReleaseId_PlatformTableReleases]
        FOREIGN KEY ([ReleaseId]) REFERENCES [cfg].[PlatformTableReleases] ([PlatformTableReleasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Departments_ProvinceId_Provinces'
)
BEGIN
    ALTER TABLE [cfg].[Departments]
        ADD CONSTRAINT [FK_cfg_Departments_ProvinceId_Provinces]
        FOREIGN KEY ([ProvinceId]) REFERENCES [cfg].[Provinces] ([ProvinceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Localities_DepartmentId_Departments'
)
BEGIN
    ALTER TABLE [cfg].[Localities]
        ADD CONSTRAINT [FK_cfg_Localities_DepartmentId_Departments]
        FOREIGN KEY ([DepartmentId]) REFERENCES [cfg].[Departments] ([DepartmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Branches_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[Branches]
        ADD CONSTRAINT [FK_cfg_Branches_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_CadastralDistricts_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[CadastralDistricts]
        ADD CONSTRAINT [FK_cfg_CadastralDistricts_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Neighborhoods_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[Neighborhoods]
        ADD CONSTRAINT [FK_cfg_Neighborhoods_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_PostalCodes_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[PostalCodes]
        ADD CONSTRAINT [FK_cfg_PostalCodes_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Streets_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[Streets]
        ADD CONSTRAINT [FK_cfg_Streets_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_StreetProposals_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[StreetProposals]
        ADD CONSTRAINT [FK_cfg_StreetProposals_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Workstations_BranchId_Branches'
)
BEGIN
    ALTER TABLE [cfg].[Workstations]
        ADD CONSTRAINT [FK_cfg_Workstations_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Zones_BranchId_Branches'
)
BEGIN
    ALTER TABLE [cfg].[Zones]
        ADD CONSTRAINT [FK_cfg_Zones_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_SeedApplications_SeedPackId_SeedPacks'
)
BEGIN
    ALTER TABLE [cfg].[SeedApplications]
        ADD CONSTRAINT [FK_cfg_SeedApplications_SeedPackId_SeedPacks]
        FOREIGN KEY ([SeedPackId]) REFERENCES [cfg].[SeedPacks] ([SeedPackId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_StreetAliases_StreetId_Streets'
)
BEGIN
    ALTER TABLE [cfg].[StreetAliases]
        ADD CONSTRAINT [FK_cfg_StreetAliases_StreetId_Streets]
        FOREIGN KEY ([StreetId]) REFERENCES [cfg].[Streets] ([StreetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_StreetProposals_PlatformStreetId_Streets'
)
BEGIN
    ALTER TABLE [cfg].[StreetProposals]
        ADD CONSTRAINT [FK_cfg_StreetProposals_PlatformStreetId_Streets]
        FOREIGN KEY ([PlatformStreetId]) REFERENCES [cfg].[Streets] ([StreetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_StreetProposals_StreetId_Streets'
)
BEGIN
    ALTER TABLE [cfg].[StreetProposals]
        ADD CONSTRAINT [FK_cfg_StreetProposals_StreetId_Streets]
        FOREIGN KEY ([StreetId]) REFERENCES [cfg].[Streets] ([StreetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierAdvances_PaymentOrderId_PaymentOrders'
)
BEGIN
    ALTER TABLE [cmp].[SupplierAdvances]
        ADD CONSTRAINT [FK_cmp_SupplierAdvances_PaymentOrderId_PaymentOrders]
        FOREIGN KEY ([PaymentOrderId]) REFERENCES [cmp].[PaymentOrders] ([PaymentOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierAdvances_ConceptId_PurchaseConcepts'
)
BEGIN
    ALTER TABLE [cmp].[SupplierAdvances]
        ADD CONSTRAINT [FK_cmp_SupplierAdvances_ConceptId_PurchaseConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cmp].[PurchaseConcepts] ([PurchaseConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseForecasts_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseForecasts]
        ADD CONSTRAINT [FK_cmp_PurchaseForecasts_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseOrders_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseOrders]
        ADD CONSTRAINT [FK_cmp_PurchaseOrders_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsContracts_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsContracts]
        ADD CONSTRAINT [FK_cmp_SignalRightsContracts_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierAdvances_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierAdvances]
        ADD CONSTRAINT [FK_cmp_SupplierAdvances_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierEvaluations_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierEvaluations]
        ADD CONSTRAINT [FK_cmp_SupplierEvaluations_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierInvoices_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierInvoices]
        ADD CONSTRAINT [FK_cmp_SupplierInvoices_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_AiInvoiceExtractions_ProposedSupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[AiInvoiceExtractions]
        ADD CONSTRAINT [FK_cmp_AiInvoiceExtractions_ProposedSupplierId_Suppliers]
        FOREIGN KEY ([ProposedSupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsSettlements_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsSettlements]
        ADD CONSTRAINT [FK_cmp_SignalRightsSettlements_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierLedgerEntries_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierLedgerEntries]
        ADD CONSTRAINT [FK_cmp_SupplierLedgerEntries_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierPortalSubmissions_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierPortalSubmissions]
        ADD CONSTRAINT [FK_cmp_SupplierPortalSubmissions_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierReceipts_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierReceipts]
        ADD CONSTRAINT [FK_cmp_SupplierReceipts_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_QuoteRequests_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[QuoteRequests]
        ADD CONSTRAINT [FK_cmp_QuoteRequests_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_QuoteRequests_SupplierIdsId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[QuoteRequests]
        ADD CONSTRAINT [FK_cmp_QuoteRequests_SupplierIdsId_Suppliers]
        FOREIGN KEY ([SupplierIdsId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_MatchExceptions_PurchaseOrderId_PurchaseOrders'
)
BEGIN
    ALTER TABLE [cmp].[MatchExceptions]
        ADD CONSTRAINT [FK_cmp_MatchExceptions_PurchaseOrderId_PurchaseOrders]
        FOREIGN KEY ([PurchaseOrderId]) REFERENCES [cmp].[PurchaseOrders] ([PurchaseOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsSettlements_ContractId_SignalRightsContracts'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsSettlements]
        ADD CONSTRAINT [FK_cmp_SignalRightsSettlements_ContractId_SignalRightsContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cmp].[SignalRightsContracts] ([SignalRightsContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_AiInvoiceExtractions_InvoiceId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [cmp].[AiInvoiceExtractions]
        ADD CONSTRAINT [FK_cmp_AiInvoiceExtractions_InvoiceId_SupplierInvoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsSettlements_InvoiceId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsSettlements]
        ADD CONSTRAINT [FK_cmp_SignalRightsSettlements_InvoiceId_SupplierInvoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_MatchExceptions_InvoiceId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [cmp].[MatchExceptions]
        ADD CONSTRAINT [FK_cmp_MatchExceptions_InvoiceId_SupplierInvoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_MatchExceptions_InvoiceItemId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [cmp].[MatchExceptions]
        ADD CONSTRAINT [FK_cmp_MatchExceptions_InvoiceItemId_SupplierInvoices]
        FOREIGN KEY ([InvoiceItemId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_MatchExceptions_ReceiptId_SupplierReceipts'
)
BEGIN
    ALTER TABLE [cmp].[MatchExceptions]
        ADD CONSTRAINT [FK_cmp_MatchExceptions_ReceiptId_SupplierReceipts]
        FOREIGN KEY ([ReceiptId]) REFERENCES [cmp].[SupplierReceipts] ([SupplierReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseDocumentLinks_OriginId_SupplyRequests'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseDocumentLinks]
        ADD CONSTRAINT [FK_cmp_PurchaseDocumentLinks_OriginId_SupplyRequests]
        FOREIGN KEY ([OriginId]) REFERENCES [cmp].[SupplyRequests] ([SupplyRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseDocumentLinks_TargetId_SupplyRequests'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseDocumentLinks]
        ADD CONSTRAINT [FK_cmp_PurchaseDocumentLinks_TargetId_SupplyRequests]
        FOREIGN KEY ([TargetId]) REFERENCES [cmp].[SupplyRequests] ([SupplyRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_ReversalAllocationIdsId_Allocations'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_ReversalAllocationIdsId_Allocations]
        FOREIGN KEY ([ReversalAllocationIdsId]) REFERENCES [cob].[Allocations] ([AllocationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CreditBalances_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[CreditBalances]
        ADD CONSTRAINT [FK_cob_CreditBalances_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitMandates_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitMandates]
        ADD CONSTRAINT [FK_cob_DirectDebitMandates_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ExternalKeyAliases_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[ExternalKeyAliases]
        ADD CONSTRAINT [FK_cob_ExternalKeyAliases_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AccountStatements_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[AccountStatements]
        ADD CONSTRAINT [FK_cob_AccountStatements_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Receipts_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[Receipts]
        ADD CONSTRAINT [FK_cob_Receipts_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentCoupons_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[PaymentCoupons]
        ADD CONSTRAINT [FK_cob_PaymentCoupons_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_RefundCases_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[RefundCases]
        ADD CONSTRAINT [FK_cob_RefundCases_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Receipts_CreditBalanceIdsId_CreditBalances'
)
BEGIN
    ALTER TABLE [cob].[Receipts]
        ADD CONSTRAINT [FK_cob_Receipts_CreditBalanceIdsId_CreditBalances]
        FOREIGN KEY ([CreditBalanceIdsId]) REFERENCES [cob].[CreditBalances] ([CreditBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentReferences_TargetId_Obligations'
)
BEGIN
    ALTER TABLE [cob].[PaymentReferences]
        ADD CONSTRAINT [FK_cob_PaymentReferences_TargetId_Obligations]
        FOREIGN KEY ([TargetId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_UnidentifiedReceipts_CandidateObligationIdsId_Obligations'
)
BEGIN
    ALTER TABLE [cob].[UnidentifiedReceipts]
        ADD CONSTRAINT [FK_cob_UnidentifiedReceipts_CandidateObligationIdsId_Obligations]
        FOREIGN KEY ([CandidateObligationIdsId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_ChargeObligationIdsId_Obligations'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_ChargeObligationIdsId_Obligations]
        FOREIGN KEY ([ChargeObligationIdsId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyCollections_ObligationId_Obligations'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyCollections]
        ADD CONSTRAINT [FK_cob_ThirdPartyCollections_ObligationId_Obligations]
        FOREIGN KEY ([ObligationId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentCoupons_ObligationIdsId_Obligations'
)
BEGIN
    ALTER TABLE [cob].[PaymentCoupons]
        ADD CONSTRAINT [FK_cob_PaymentCoupons_ObligationIdsId_Obligations]
        FOREIGN KEY ([ObligationIdsId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AccountStatements_PaymentReferenceIdsId_PaymentReferences'
)
BEGIN
    ALTER TABLE [cob].[AccountStatements]
        ADD CONSTRAINT [FK_cob_AccountStatements_PaymentReferenceIdsId_PaymentReferences]
        FOREIGN KEY ([PaymentReferenceIdsId]) REFERENCES [cob].[PaymentReferences] ([PaymentReferenceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentCoupons_PaymentReferenceId_PaymentReferences'
)
BEGIN
    ALTER TABLE [cob].[PaymentCoupons]
        ADD CONSTRAINT [FK_cob_PaymentCoupons_PaymentReferenceId_PaymentReferences]
        FOREIGN KEY ([PaymentReferenceId]) REFERENCES [cob].[PaymentReferences] ([PaymentReferenceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlementLines_UnidentifiedId_UnidentifiedReceipts'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlementLines]
        ADD CONSTRAINT [FK_cob_AgencySettlementLines_UnidentifiedId_UnidentifiedReceipts]
        FOREIGN KEY ([UnidentifiedId]) REFERENCES [cob].[UnidentifiedReceipts] ([UnidentifiedReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceImportRows_ListId_AudienceImportLists'
)
BEGIN
    ALTER TABLE [com].[AudienceImportRows]
        ADD CONSTRAINT [FK_com_AudienceImportRows_ListId_AudienceImportLists]
        FOREIGN KEY ([ListId]) REFERENCES [com].[AudienceImportLists] ([AudienceImportListId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Benefits_BenefitPartnerId_BenefitPartners'
)
BEGIN
    ALTER TABLE [com].[Benefits]
        ADD CONSTRAINT [FK_com_Benefits_BenefitPartnerId_BenefitPartners]
        FOREIGN KEY ([BenefitPartnerId]) REFERENCES [com].[BenefitPartners] ([BenefitPartnerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_BenefitRedemptions_PartnerId_BenefitPartners'
)
BEGIN
    ALTER TABLE [com].[BenefitRedemptions]
        ADD CONSTRAINT [FK_com_BenefitRedemptions_PartnerId_BenefitPartners]
        FOREIGN KEY ([PartnerId]) REFERENCES [com].[BenefitPartners] ([BenefitPartnerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_MessageTemplates_CommunicationTypeId_CommunicationTypes'
)
BEGIN
    ALTER TABLE [com].[MessageTemplates]
        ADD CONSTRAINT [FK_com_MessageTemplates_CommunicationTypeId_CommunicationTypes]
        FOREIGN KEY ([CommunicationTypeId]) REFERENCES [com].[CommunicationTypes] ([CommunicationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AppNotifications_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [com].[AppNotifications]
        ADD CONSTRAINT [FK_com_AppNotifications_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunicationAttempts_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [com].[CommunicationAttempts]
        ADD CONSTRAINT [FK_com_CommunicationAttempts_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SuppressionEntries_SourceCommunicationId_Communications'
)
BEGIN
    ALTER TABLE [com].[SuppressionEntries]
        ADD CONSTRAINT [FK_com_SuppressionEntries_SourceCommunicationId_Communications]
        FOREIGN KEY ([SourceCommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_NewsletterRecipients_CommunicationIdsId_Communications'
)
BEGIN
    ALTER TABLE [com].[NewsletterRecipients]
        ADD CONSTRAINT [FK_com_NewsletterRecipients_CommunicationIdsId_Communications]
        FOREIGN KEY ([CommunicationIdsId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunicationEvents_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [com].[CommunicationEvents]
        ADD CONSTRAINT [FK_com_CommunicationEvents_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_TrackedLinks_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [com].[TrackedLinks]
        ADD CONSTRAINT [FK_com_TrackedLinks_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyInvitations_CommunicationIdsId_Communications'
)
BEGIN
    ALTER TABLE [com].[SurveyInvitations]
        ADD CONSTRAINT [FK_com_SurveyInvitations_CommunicationIdsId_Communications]
        FOREIGN KEY ([CommunicationIdsId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ModerationPolicies_CurrentGuidelinesId_CommunityGuidelines'
)
BEGIN
    ALTER TABLE [com].[ModerationPolicies]
        ADD CONSTRAINT [FK_com_ModerationPolicies_CurrentGuidelinesId_CommunityGuidelines]
        FOREIGN KEY ([CurrentGuidelinesId]) REFERENCES [com].[CommunityGuidelines] ([CommunityGuidelineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunitySanctions_CaseIdsId_ModerationCases'
)
BEGIN
    ALTER TABLE [com].[CommunitySanctions]
        ADD CONSTRAINT [FK_com_CommunitySanctions_CaseIdsId_ModerationCases]
        FOREIGN KEY ([CaseIdsId]) REFERENCES [com].[ModerationCases] ([ModerationCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ModerationRules_PolicyId_ModerationPolicies'
)
BEGIN
    ALTER TABLE [com].[ModerationRules]
        ADD CONSTRAINT [FK_com_ModerationRules_PolicyId_ModerationPolicies]
        FOREIGN KEY ([PolicyId]) REFERENCES [com].[ModerationPolicies] ([ModerationPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Newsletters_RuleId_NewsletterRules'
)
BEGIN
    ALTER TABLE [com].[Newsletters]
        ADD CONSTRAINT [FK_com_Newsletters_RuleId_NewsletterRules]
        FOREIGN KEY ([RuleId]) REFERENCES [com].[NewsletterRules] ([NewsletterRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ModerationRules_CategoryIdsId_PostCategories'
)
BEGIN
    ALTER TABLE [com].[ModerationRules]
        ADD CONSTRAINT [FK_com_ModerationRules_CategoryIdsId_PostCategories]
        FOREIGN KEY ([CategoryIdsId]) REFERENCES [com].[PostCategories] ([PostCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Posts_CategoryId_PostCategories'
)
BEGIN
    ALTER TABLE [com].[Posts]
        ADD CONSTRAINT [FK_com_Posts_CategoryId_PostCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [com].[PostCategories] ([PostCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_GreetingRules_PostTemplateId_PostTemplates'
)
BEGIN
    ALTER TABLE [com].[GreetingRules]
        ADD CONSTRAINT [FK_com_GreetingRules_PostTemplateId_PostTemplates]
        FOREIGN KEY ([PostTemplateId]) REFERENCES [com].[PostTemplates] ([PostTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostAllocationRules_ModelId_DistributionModels'
)
BEGIN
    ALTER TABLE [con].[CostAllocationRules]
        ADD CONSTRAINT [FK_con_CostAllocationRules_ModelId_DistributionModels]
        FOREIGN KEY ([ModelId]) REFERENCES [con].[DistributionModels] ([DistributionModelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostCenterModels_DistributionModelId_DistributionModels'
)
BEGIN
    ALTER TABLE [con].[CostCenterModels]
        ADD CONSTRAINT [FK_con_CostCenterModels_DistributionModelId_DistributionModels]
        FOREIGN KEY ([DistributionModelId]) REFERENCES [con].[DistributionModels] ([DistributionModelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostDistributionRuns_DistributionModelId_DistributionModels'
)
BEGIN
    ALTER TABLE [con].[CostDistributionRuns]
        ADD CONSTRAINT [FK_con_CostDistributionRuns_DistributionModelId_DistributionModels]
        FOREIGN KEY ([DistributionModelId]) REFERENCES [con].[DistributionModels] ([DistributionModelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountRoles_CostCenterModelId_CostCenterModels'
)
BEGIN
    ALTER TABLE [con].[AccountRoles]
        ADD CONSTRAINT [FK_con_AccountRoles_CostCenterModelId_CostCenterModels]
        FOREIGN KEY ([CostCenterModelId]) REFERENCES [con].[CostCenterModels] ([CostCenterModelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountingPeriods_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[AccountingPeriods]
        ADD CONSTRAINT [FK_con_AccountingPeriods_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_Budgets_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[Budgets]
        ADD CONSTRAINT [FK_con_Budgets_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ReconciliationRuns_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[ReconciliationRuns]
        ADD CONSTRAINT [FK_con_ReconciliationRuns_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_RubricatedBooks_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[RubricatedBooks]
        ADD CONSTRAINT [FK_con_RubricatedBooks_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_FinancialStatementRuns_ComparativeFiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[FinancialStatementRuns]
        ADD CONSTRAINT [FK_con_FinancialStatementRuns_ComparativeFiscalYearId_FiscalYears]
        FOREIGN KEY ([ComparativeFiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_FinancialStatementRuns_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[FinancialStatementRuns]
        ADD CONSTRAINT [FK_con_FinancialStatementRuns_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_InflationAdjustmentRuns_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[InflationAdjustmentRuns]
        ADD CONSTRAINT [FK_con_InflationAdjustmentRuns_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_PeriodId_AccountingPeriods'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_PeriodId_AccountingPeriods]
        FOREIGN KEY ([PeriodId]) REFERENCES [con].[AccountingPeriods] ([AccountingPeriodId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_Commitments_BudgetId_Budgets'
)
BEGIN
    ALTER TABLE [con].[Commitments]
        ADD CONSTRAINT [FK_con_Commitments_BudgetId_Budgets]
        FOREIGN KEY ([BudgetId]) REFERENCES [con].[Budgets] ([BudgetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_BudgetLines_BudgetId_Budgets'
)
BEGIN
    ALTER TABLE [con].[BudgetLines]
        ADD CONSTRAINT [FK_con_BudgetLines_BudgetId_Budgets]
        FOREIGN KEY ([BudgetId]) REFERENCES [con].[Budgets] ([BudgetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountingEvents_PostingBatchId_PostingBatches'
)
BEGIN
    ALTER TABLE [con].[AccountingEvents]
        ADD CONSTRAINT [FK_con_AccountingEvents_PostingBatchId_PostingBatches]
        FOREIGN KEY ([PostingBatchId]) REFERENCES [con].[PostingBatches] ([PostingBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalEntries_PostingBatchId_PostingBatches'
)
BEGIN
    ALTER TABLE [con].[JournalEntries]
        ADD CONSTRAINT [FK_con_JournalEntries_PostingBatchId_PostingBatches]
        FOREIGN KEY ([PostingBatchId]) REFERENCES [con].[PostingBatches] ([PostingBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalEntries_RubricatedBookId_RubricatedBooks'
)
BEGIN
    ALTER TABLE [con].[JournalEntries]
        ADD CONSTRAINT [FK_con_JournalEntries_RubricatedBookId_RubricatedBooks]
        FOREIGN KEY ([RubricatedBookId]) REFERENCES [con].[RubricatedBooks] ([RubricatedBookId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_FinancialStatementRuns_TemplateIdsId_StatementTemplates'
)
BEGIN
    ALTER TABLE [con].[FinancialStatementRuns]
        ADD CONSTRAINT [FK_con_FinancialStatementRuns_TemplateIdsId_StatementTemplates]
        FOREIGN KEY ([TemplateIdsId]) REFERENCES [con].[StatementTemplates] ([StatementTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityTypes_FrequencyId_CrmActivityFrequencies'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityTypes]
        ADD CONSTRAINT [FK_crm_CrmActivityTypes_FrequencyId_CrmActivityFrequencies]
        FOREIGN KEY ([FrequencyId]) REFERENCES [crm].[CrmActivityFrequencies] ([CrmActivityFrequencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivities_FrequencyId_CrmActivityFrequencies'
)
BEGIN
    ALTER TABLE [crm].[CrmActivities]
        ADD CONSTRAINT [FK_crm_CrmActivities_FrequencyId_CrmActivityFrequencies]
        FOREIGN KEY ([FrequencyId]) REFERENCES [crm].[CrmActivityFrequencies] ([CrmActivityFrequencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityTypes_RubroId_CrmActivityRubros'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityTypes]
        ADD CONSTRAINT [FK_crm_CrmActivityTypes_RubroId_CrmActivityRubros]
        FOREIGN KEY ([RubroId]) REFERENCES [crm].[CrmActivityRubros] ([CrmActivityRubroId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivities_RubroId_CrmActivityRubros'
)
BEGIN
    ALTER TABLE [crm].[CrmActivities]
        ADD CONSTRAINT [FK_crm_CrmActivities_RubroId_CrmActivityRubros]
        FOREIGN KEY ([RubroId]) REFERENCES [crm].[CrmActivityRubros] ([CrmActivityRubroId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityTypes_AreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityTypes]
        ADD CONSTRAINT [FK_crm_CrmActivityTypes_AreaId_CrmAreas]
        FOREIGN KEY ([AreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueAppointments_AreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueAppointments]
        ADD CONSTRAINT [FK_crm_CrmQueueAppointments_AreaId_CrmAreas]
        FOREIGN KEY ([AreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueTicketEvents_AreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueTicketEvents]
        ADD CONSTRAINT [FK_crm_CrmQueueTicketEvents_AreaId_CrmAreas]
        FOREIGN KEY ([AreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQuickReplies_AreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [crm].[CrmQuickReplies]
        ADD CONSTRAINT [FK_crm_CrmQuickReplies_AreaId_CrmAreas]
        FOREIGN KEY ([AreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_AreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_AreaId_CrmAreas]
        FOREIGN KEY ([AreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivities_ActivityTypeId_CrmActivityTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmActivities]
        ADD CONSTRAINT [FK_crm_CrmActivities_ActivityTypeId_CrmActivityTypes]
        FOREIGN KEY ([ActivityTypeId]) REFERENCES [crm].[CrmActivityTypes] ([CrmActivityTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivities_TypeId_CrmActivityTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmActivities]
        ADD CONSTRAINT [FK_crm_CrmActivities_TypeId_CrmActivityTypes]
        FOREIGN KEY ([TypeId]) REFERENCES [crm].[CrmActivityTypes] ([CrmActivityTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityOccurrences_ActivityId_CrmActivities'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityOccurrences]
        ADD CONSTRAINT [FK_crm_CrmActivityOccurrences_ActivityId_CrmActivities]
        FOREIGN KEY ([ActivityId]) REFERENCES [crm].[CrmActivities] ([CrmActivityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmBotSessions_FlowId_CrmBotFlows'
)
BEGIN
    ALTER TABLE [crm].[CrmBotSessions]
        ADD CONSTRAINT [FK_crm_CrmBotSessions_FlowId_CrmBotFlows]
        FOREIGN KEY ([FlowId]) REFERENCES [crm].[CrmBotFlows] ([CrmBotFlowId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCalendarEvents_EventTypeId_CrmCalendarEventTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmCalendarEvents]
        ADD CONSTRAINT [FK_crm_CrmCalendarEvents_EventTypeId_CrmCalendarEventTypes]
        FOREIGN KEY ([EventTypeId]) REFERENCES [crm].[CrmCalendarEventTypes] ([CrmCalendarEventTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCalendarEvents_TypeId_CrmCalendarEventTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmCalendarEvents]
        ADD CONSTRAINT [FK_crm_CrmCalendarEvents_TypeId_CrmCalendarEventTypes]
        FOREIGN KEY ([TypeId]) REFERENCES [crm].[CrmCalendarEventTypes] ([CrmCalendarEventTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityOccurrences_CalendarEventId_CrmCalendarEvents'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityOccurrences]
        ADD CONSTRAINT [FK_crm_CrmActivityOccurrences_CalendarEventId_CrmCalendarEvents]
        FOREIGN KEY ([CalendarEventId]) REFERENCES [crm].[CrmCalendarEvents] ([CrmCalendarEventId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_CaseSubtypeId_CrmCaseSubtypes'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_CaseSubtypeId_CrmCaseSubtypes]
        FOREIGN KEY ([CaseSubtypeId]) REFERENCES [crm].[CrmCaseSubtypes] ([CrmCaseSubtypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_CaseTypeId_CrmCaseTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_CaseTypeId_CrmCaseTypes]
        FOREIGN KEY ([CaseTypeId]) REFERENCES [crm].[CrmCaseTypes] ([CrmCaseTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmConversations_ChannelId_CrmChannels'
)
BEGIN
    ALTER TABLE [crm].[CrmConversations]
        ADD CONSTRAINT [FK_crm_CrmConversations_ChannelId_CrmChannels]
        FOREIGN KEY ([ChannelId]) REFERENCES [crm].[CrmChannels] ([CrmChannelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCircularRuns_CircularId_CrmCirculars'
)
BEGIN
    ALTER TABLE [crm].[CrmCircularRuns]
        ADD CONSTRAINT [FK_crm_CrmCircularRuns_CircularId_CrmCirculars]
        FOREIGN KEY ([CircularId]) REFERENCES [crm].[CrmCirculars] ([CrmCircularId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_ContactIdsId_CrmContacts'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_ContactIdsId_CrmContacts]
        FOREIGN KEY ([ContactIdsId]) REFERENCES [crm].[CrmContacts] ([CrmContactId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmBotSessions_ConversationId_CrmConversations'
)
BEGIN
    ALTER TABLE [crm].[CrmBotSessions]
        ADD CONSTRAINT [FK_crm_CrmBotSessions_ConversationId_CrmConversations]
        FOREIGN KEY ([ConversationId]) REFERENCES [crm].[CrmConversations] ([CrmConversationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmIncidents_IncidentClassId_CrmIncidentClasses'
)
BEGIN
    ALTER TABLE [crm].[CrmIncidents]
        ADD CONSTRAINT [FK_crm_CrmIncidents_IncidentClassId_CrmIncidentClasses]
        FOREIGN KEY ([IncidentClassId]) REFERENCES [crm].[CrmIncidentClasses] ([CrmIncidentClassId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_IncidentId_CrmIncidents'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_IncidentId_CrmIncidents]
        FOREIGN KEY ([IncidentId]) REFERENCES [crm].[CrmIncidents] ([CrmIncidentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_ProjectId_CrmProjects'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_ProjectId_CrmProjects]
        FOREIGN KEY ([ProjectId]) REFERENCES [crm].[CrmProjects] ([CrmProjectId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueDesks_DeskTypeId_CrmQueueDeskTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueDesks]
        ADD CONSTRAINT [FK_crm_CrmQueueDesks_DeskTypeId_CrmQueueDeskTypes]
        FOREIGN KEY ([DeskTypeId]) REFERENCES [crm].[CrmQueueDeskTypes] ([CrmQueueDeskTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueDeskSessions_DeskId_CrmQueueDesks'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueDeskSessions]
        ADD CONSTRAINT [FK_crm_CrmQueueDeskSessions_DeskId_CrmQueueDesks]
        FOREIGN KEY ([DeskId]) REFERENCES [crm].[CrmQueueDesks] ([CrmQueueDeskId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueTicketEvents_DeskId_CrmQueueDesks'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueTicketEvents]
        ADD CONSTRAINT [FK_crm_CrmQueueTicketEvents_DeskId_CrmQueueDesks]
        FOREIGN KEY ([DeskId]) REFERENCES [crm].[CrmQueueDesks] ([CrmQueueDeskId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueTicketEvents_DeskSessionId_CrmQueueDeskSessions'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueTicketEvents]
        ADD CONSTRAINT [FK_crm_CrmQueueTicketEvents_DeskSessionId_CrmQueueDeskSessions]
        FOREIGN KEY ([DeskSessionId]) REFERENCES [crm].[CrmQueueDeskSessions] ([CrmQueueDeskSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueAppointments_QueueTicketId_CrmQueueTickets'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueAppointments]
        ADD CONSTRAINT [FK_crm_CrmQueueAppointments_QueueTicketId_CrmQueueTickets]
        FOREIGN KEY ([QueueTicketId]) REFERENCES [crm].[CrmQueueTickets] ([CrmQueueTicketId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueTicketEvents_QueueTicketId_CrmQueueTickets'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueTicketEvents]
        ADD CONSTRAINT [FK_crm_CrmQueueTicketEvents_QueueTicketId_CrmQueueTickets]
        FOREIGN KEY ([QueueTicketId]) REFERENCES [crm].[CrmQueueTickets] ([CrmQueueTicketId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_StatusSetId_CrmStatusSets'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_StatusSetId_CrmStatusSets]
        FOREIGN KEY ([StatusSetId]) REFERENCES [crm].[CrmStatusSets] ([CrmStatusSetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmAiSuggestions_TargetId_CrmCases'
)
BEGIN
    ALTER TABLE [crm].[CrmAiSuggestions]
        ADD CONSTRAINT [FK_crm_CrmAiSuggestions_TargetId_CrmCases]
        FOREIGN KEY ([TargetId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmBotSessions_CrmCaseId_CrmCases'
)
BEGIN
    ALTER TABLE [crm].[CrmBotSessions]
        ADD CONSTRAINT [FK_crm_CrmBotSessions_CrmCaseId_CrmCases]
        FOREIGN KEY ([CrmCaseId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BarcodeAssignments_FormatId_BarcodeFormats'
)
BEGIN
    ALTER TABLE [fac].[BarcodeAssignments]
        ADD CONSTRAINT [FK_fac_BarcodeAssignments_FormatId_BarcodeFormats]
        FOREIGN KEY ([FormatId]) REFERENCES [fac].[BarcodeFormats] ([BarcodeFormatId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingImportRows_ImportId_BillingImports'
)
BEGIN
    ALTER TABLE [fac].[BillingImportRows]
        ADD CONSTRAINT [FK_fac_BillingImportRows_ImportId_BillingImports]
        FOREIGN KEY ([ImportId]) REFERENCES [fac].[BillingImports] ([BillingImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceExternalData_ImportId_BillingImports'
)
BEGIN
    ALTER TABLE [fac].[InvoiceExternalData]
        ADD CONSTRAINT [FK_fac_InvoiceExternalData_ImportId_BillingImports]
        FOREIGN KEY ([ImportId]) REFERENCES [fac].[BillingImports] ([BillingImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingExceptions_ReprocessRunId_BillingRuns'
)
BEGIN
    ALTER TABLE [fac].[BillingExceptions]
        ADD CONSTRAINT [FK_fac_BillingExceptions_ReprocessRunId_BillingRuns]
        FOREIGN KEY ([ReprocessRunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingRunItems_CarriedOverToRunId_BillingRuns'
)
BEGIN
    ALTER TABLE [fac].[BillingRunItems]
        ADD CONSTRAINT [FK_fac_BillingRunItems_CarriedOverToRunId_BillingRuns]
        FOREIGN KEY ([CarriedOverToRunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_DistributionRuns_BillingRunId_BillingRuns'
)
BEGIN
    ALTER TABLE [fac].[DistributionRuns]
        ADD CONSTRAINT [FK_fac_DistributionRuns_BillingRunId_BillingRuns]
        FOREIGN KEY ([BillingRunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingRunNumberRanges_RunId_BillingRuns'
)
BEGIN
    ALTER TABLE [fac].[BillingRunNumberRanges]
        ADD CONSTRAINT [FK_fac_BillingRunNumberRanges_RunId_BillingRuns]
        FOREIGN KEY ([RunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BilledPeriods_RunId_BillingRuns'
)
BEGIN
    ALTER TABLE [fac].[BilledPeriods]
        ADD CONSTRAINT [FK_fac_BilledPeriods_RunId_BillingRuns]
        FOREIGN KEY ([RunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingCycles_UniverseId_BillingUniverses'
)
BEGIN
    ALTER TABLE [fac].[BillingCycles]
        ADD CONSTRAINT [FK_fac_BillingCycles_UniverseId_BillingUniverses]
        FOREIGN KEY ([UniverseId]) REFERENCES [fac].[BillingUniverses] ([BillingUniversId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDeliveries_DistributionRunId_DistributionRuns'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDeliveries]
        ADD CONSTRAINT [FK_fac_InvoiceDeliveries_DistributionRunId_DistributionRuns]
        FOREIGN KEY ([DistributionRunId]) REFERENCES [fac].[DistributionRuns] ([DistributionRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingCycles_DueDateSchemeId_DueDateSchemes'
)
BEGIN
    ALTER TABLE [fac].[BillingCycles]
        ADD CONSTRAINT [FK_fac_BillingCycles_DueDateSchemeId_DueDateSchemes]
        FOREIGN KEY ([DueDateSchemeId]) REFERENCES [fac].[DueDateSchemes] ([DueDateSchemeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingTemplates_PrintTemplateId_InvoiceTemplates'
)
BEGIN
    ALTER TABLE [fac].[BillingTemplates]
        ADD CONSTRAINT [FK_fac_BillingTemplates_PrintTemplateId_InvoiceTemplates]
        FOREIGN KEY ([PrintTemplateId]) REFERENCES [fac].[InvoiceTemplates] ([InvoiceTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingCycles_TemplateId_BillingTemplates'
)
BEGIN
    ALTER TABLE [fac].[BillingCycles]
        ADD CONSTRAINT [FK_fac_BillingCycles_TemplateId_BillingTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [fac].[BillingTemplates] ([BillingTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_MassOperationItems_OperationId_MassOperations'
)
BEGIN
    ALTER TABLE [fac].[MassOperationItems]
        ADD CONSTRAINT [FK_fac_MassOperationItems_OperationId_MassOperations]
        FOREIGN KEY ([OperationId]) REFERENCES [fac].[MassOperations] ([MassOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_DistributionRoutes_PostalCarrierId_PostalCarriers'
)
BEGIN
    ALTER TABLE [fac].[DistributionRoutes]
        ADD CONSTRAINT [FK_fac_DistributionRoutes_PostalCarrierId_PostalCarriers]
        FOREIGN KEY ([PostalCarrierId]) REFERENCES [fac].[PostalCarriers] ([PostalCarrierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDeliveries_RouteId_DistributionRoutes'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDeliveries]
        ADD CONSTRAINT [FK_fac_InvoiceDeliveries_RouteId_DistributionRoutes]
        FOREIGN KEY ([RouteId]) REFERENCES [fac].[DistributionRoutes] ([DistributionRouteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingGroups_VoucherTypeOverrideId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fac].[BillingGroups]
        ADD CONSTRAINT [FK_fac_BillingGroups_VoucherTypeOverrideId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeOverrideId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingRunNumberRanges_NumberingVoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fac].[BillingRunNumberRanges]
        ADD CONSTRAINT [FK_fac_BillingRunNumberRanges_NumberingVoucherTypeId_VoucherTypes]
        FOREIGN KEY ([NumberingVoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingRunNumberRanges_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fac].[BillingRunNumberRanges]
        ADD CONSTRAINT [FK_fac_BillingRunNumberRanges_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_Invoices_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fac].[Invoices]
        ADD CONSTRAINT [FK_fac_Invoices_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_NumberSequences_NumberingVoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fac].[NumberSequences]
        ADD CONSTRAINT [FK_fac_NumberSequences_NumberingVoucherTypeId_VoucherTypes]
        FOREIGN KEY ([NumberingVoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_DeliveryPreferences_BillingGroupId_BillingGroups'
)
BEGIN
    ALTER TABLE [fac].[DeliveryPreferences]
        ADD CONSTRAINT [FK_fac_DeliveryPreferences_BillingGroupId_BillingGroups]
        FOREIGN KEY ([BillingGroupId]) REFERENCES [fac].[BillingGroups] ([BillingGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_NumberSequences_BillingGroupId_BillingGroups'
)
BEGIN
    ALTER TABLE [fac].[NumberSequences]
        ADD CONSTRAINT [FK_fac_NumberSequences_BillingGroupId_BillingGroups]
        FOREIGN KEY ([BillingGroupId]) REFERENCES [fac].[BillingGroups] ([BillingGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BilledPeriods_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[BilledPeriods]
        ADD CONSTRAINT [FK_fac_BilledPeriods_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceAnnulmentRequests_InvoiceIdsId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[InvoiceAnnulmentRequests]
        ADD CONSTRAINT [FK_fac_InvoiceAnnulmentRequests_InvoiceIdsId_Invoices]
        FOREIGN KEY ([InvoiceIdsId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDeliveries_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDeliveries]
        ADD CONSTRAINT [FK_fac_InvoiceDeliveries_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDocuments_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDocuments]
        ADD CONSTRAINT [FK_fac_InvoiceDocuments_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceExternalData_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[InvoiceExternalData]
        ADD CONSTRAINT [FK_fac_InvoiceExternalData_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_PaymentSlips_InvoiceIdsId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[PaymentSlips]
        ADD CONSTRAINT [FK_fac_PaymentSlips_InvoiceIdsId_Invoices]
        FOREIGN KEY ([InvoiceIdsId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceRelations_RequestId_InvoiceAnnulmentRequests'
)
BEGIN
    ALTER TABLE [fac].[InvoiceRelations]
        ADD CONSTRAINT [FK_fac_InvoiceRelations_RequestId_InvoiceAnnulmentRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [fac].[InvoiceAnnulmentRequests] ([InvoiceAnnulmentRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaAccessTickets_ArcaCredentialId_ArcaCredentials'
)
BEGIN
    ALTER TABLE [fis].[ArcaAccessTickets]
        ADD CONSTRAINT [FK_fis_ArcaAccessTickets_ArcaCredentialId_ArcaCredentials]
        FOREIGN KEY ([ArcaCredentialId]) REFERENCES [fis].[ArcaCredentials] ([ArcaCredentialId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatReconciliations_ImportId_ArcaReceivedImports'
)
BEGIN
    ALTER TABLE [fis].[VatReconciliations]
        ADD CONSTRAINT [FK_fis_VatReconciliations_ImportId_ArcaReceivedImports]
        FOREIGN KEY ([ImportId]) REFERENCES [fis].[ArcaReceivedImports] ([ArcaReceivedImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ConceptFiscalCases_NormativeVersionId_NormativeTableVersions'
)
BEGIN
    ALTER TABLE [fis].[ConceptFiscalCases]
        ADD CONSTRAINT [FK_fis_ConceptFiscalCases_NormativeVersionId_NormativeTableVersions]
        FOREIGN KEY ([NormativeVersionId]) REFERENCES [fis].[NormativeTableVersions] ([NormativeTableVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_NormativeAdoptions_PlatformVersionId_NormativeTableVersions'
)
BEGIN
    ALTER TABLE [fis].[NormativeAdoptions]
        ADD CONSTRAINT [FK_fis_NormativeAdoptions_PlatformVersionId_NormativeTableVersions]
        FOREIGN KEY ([PlatformVersionId]) REFERENCES [fis].[NormativeTableVersions] ([NormativeTableVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatRates_ArcaVatId_NormativeTables'
)
BEGIN
    ALTER TABLE [fis].[VatRates]
        ADD CONSTRAINT [FK_fis_VatRates_ArcaVatId_NormativeTables]
        FOREIGN KEY ([ArcaVatId]) REFERENCES [fis].[NormativeTables] ([NormativeTableId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxObligations_OwnTaxObligationId_OwnTaxObligations'
)
BEGIN
    ALTER TABLE [fis].[TaxObligations]
        ADD CONSTRAINT [FK_fis_TaxObligations_OwnTaxObligationId_OwnTaxObligations]
        FOREIGN KEY ([OwnTaxObligationId]) REFERENCES [fis].[OwnTaxObligations] ([OwnTaxObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_CespAuthorizations_PointOfSaleId_PointsOfSale'
)
BEGIN
    ALTER TABLE [fis].[CespAuthorizations]
        ADD CONSTRAINT [FK_fis_CespAuthorizations_PointOfSaleId_PointsOfSale]
        FOREIGN KEY ([PointOfSaleId]) REFERENCES [fis].[PointsOfSale] ([PointsOfSaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ProvincialValidationCodes_PointOfSaleId_PointsOfSale'
)
BEGIN
    ALTER TABLE [fis].[ProvincialValidationCodes]
        ADD CONSTRAINT [FK_fis_ProvincialValidationCodes_PointOfSaleId_PointsOfSale]
        FOREIGN KEY ([PointOfSaleId]) REFERENCES [fis].[PointsOfSale] ([PointsOfSaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_FiscalAuthorizations_PointOfSaleId_PointsOfSale'
)
BEGIN
    ALTER TABLE [fis].[FiscalAuthorizations]
        ADD CONSTRAINT [FK_fis_FiscalAuthorizations_PointOfSaleId_PointsOfSale]
        FOREIGN KEY ([PointOfSaleId]) REFERENCES [fis].[PointsOfSale] ([PointsOfSaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_FiscalDeadlines_FilingId_RegimeFilings'
)
BEGIN
    ALTER TABLE [fis].[FiscalDeadlines]
        ADD CONSTRAINT [FK_fis_FiscalDeadlines_FilingId_RegimeFilings]
        FOREIGN KEY ([FilingId]) REFERENCES [fis].[RegimeFilings] ([RegimeFilingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingsApplied_FilingId_RegimeFilings'
)
BEGIN
    ALTER TABLE [fis].[WithholdingsApplied]
        ADD CONSTRAINT [FK_fis_WithholdingsApplied_FilingId_RegimeFilings]
        FOREIGN KEY ([FilingId]) REFERENCES [fis].[RegimeFilings] ([RegimeFilingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxObligations_TaxAgentRegistrationId_TaxAgentRegistrations'
)
BEGIN
    ALTER TABLE [fis].[TaxObligations]
        ADD CONSTRAINT [FK_fis_TaxObligations_TaxAgentRegistrationId_TaxAgentRegistrations]
        FOREIGN KEY ([TaxAgentRegistrationId]) REFERENCES [fis].[TaxAgentRegistrations] ([TaxAgentRegistrationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingTypes_TaxAgentRegistrationId_TaxAgentRegistrations'
)
BEGIN
    ALTER TABLE [fis].[WithholdingTypes]
        ADD CONSTRAINT [FK_fis_WithholdingTypes_TaxAgentRegistrationId_TaxAgentRegistrations]
        FOREIGN KEY ([TaxAgentRegistrationId]) REFERENCES [fis].[TaxAgentRegistrations] ([TaxAgentRegistrationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatRateMatrix_PerceptionTaxId_TaxDefinitions'
)
BEGIN
    ALTER TABLE [fis].[VatRateMatrix]
        ADD CONSTRAINT [FK_fis_VatRateMatrix_PerceptionTaxId_TaxDefinitions]
        FOREIGN KEY ([PerceptionTaxId]) REFERENCES [fis].[TaxDefinitions] ([TaxDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingsApplied_SupplierPersonId_TaxExemptions'
)
BEGIN
    ALTER TABLE [fis].[WithholdingsApplied]
        ADD CONSTRAINT [FK_fis_WithholdingsApplied_SupplierPersonId_TaxExemptions]
        FOREIGN KEY ([SupplierPersonId]) REFERENCES [fis].[TaxExemptions] ([TaxExemptionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingsApplied_ObligationId_TaxObligations'
)
BEGIN
    ALTER TABLE [fis].[WithholdingsApplied]
        ADD CONSTRAINT [FK_fis_WithholdingsApplied_ObligationId_TaxObligations]
        FOREIGN KEY ([ObligationId]) REFERENCES [fis].[TaxObligations] ([TaxObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxpayerRegistryEntries_RegistryId_TaxpayerRegistries'
)
BEGIN
    ALTER TABLE [fis].[TaxpayerRegistryEntries]
        ADD CONSTRAINT [FK_fis_TaxpayerRegistryEntries_RegistryId_TaxpayerRegistries]
        FOREIGN KEY ([RegistryId]) REFERENCES [fis].[TaxpayerRegistries] ([TaxpayerRegistryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyRemittances_AgreementId_ThirdPartyAgreements'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyRemittances]
        ADD CONSTRAINT [FK_fis_ThirdPartyRemittances_AgreementId_ThirdPartyAgreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [fis].[ThirdPartyAgreements] ([ThirdPartyAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyCharges_AgreementId_ThirdPartyAgreements'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyCharges]
        ADD CONSTRAINT [FK_fis_ThirdPartyCharges_AgreementId_ThirdPartyAgreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [fis].[ThirdPartyAgreements] ([ThirdPartyAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyCharges_RemittanceId_ThirdPartyRemittances'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyCharges]
        ADD CONSTRAINT [FK_fis_ThirdPartyCharges_RemittanceId_ThirdPartyRemittances]
        FOREIGN KEY ([RemittanceId]) REFERENCES [fis].[ThirdPartyRemittances] ([ThirdPartyRemittanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatRateMatrix_VatConditionSettingId_VatConditionSettings'
)
BEGIN
    ALTER TABLE [fis].[VatRateMatrix]
        ADD CONSTRAINT [FK_fis_VatRateMatrix_VatConditionSettingId_VatConditionSettings]
        FOREIGN KEY ([VatConditionSettingId]) REFERENCES [fis].[VatConditionSettings] ([VatConditionSettingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatLedgerLines_LedgerId_VatLedgers'
)
BEGIN
    ALTER TABLE [fis].[VatLedgerLines]
        ADD CONSTRAINT [FK_fis_VatLedgerLines_LedgerId_VatLedgers]
        FOREIGN KEY ([LedgerId]) REFERENCES [fis].[VatLedgers] ([VatLedgerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatReconciliations_LedgerId_VatLedgers'
)
BEGIN
    ALTER TABLE [fis].[VatReconciliations]
        ADD CONSTRAINT [FK_fis_VatReconciliations_LedgerId_VatLedgers]
        FOREIGN KEY ([LedgerId]) REFERENCES [fis].[VatLedgers] ([VatLedgerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatRateMatrix_VatRateId_VatRates'
)
BEGIN
    ALTER TABLE [fis].[VatRateMatrix]
        ADD CONSTRAINT [FK_fis_VatRateMatrix_VatRateId_VatRates]
        FOREIGN KEY ([VatRateId]) REFERENCES [fis].[VatRates] ([VatRateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingAssignments_WithholdingTypeId_WithholdingTypes'
)
BEGIN
    ALTER TABLE [fis].[WithholdingAssignments]
        ADD CONSTRAINT [FK_fis_WithholdingAssignments_WithholdingTypeId_WithholdingTypes]
        FOREIGN KEY ([WithholdingTypeId]) REFERENCES [fis].[WithholdingTypes] ([WithholdingTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingScales_WithholdingTypeId_WithholdingTypes'
)
BEGIN
    ALTER TABLE [fis].[WithholdingScales]
        ADD CONSTRAINT [FK_fis_WithholdingScales_WithholdingTypeId_WithholdingTypes]
        FOREIGN KEY ([WithholdingTypeId]) REFERENCES [fis].[WithholdingTypes] ([WithholdingTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingsApplied_WithholdingTypeId_WithholdingTypes'
)
BEGIN
    ALTER TABLE [fis].[WithholdingsApplied]
        ADD CONSTRAINT [FK_fis_WithholdingsApplied_WithholdingTypeId_WithholdingTypes]
        FOREIGN KEY ([WithholdingTypeId]) REFERENCES [fis].[WithholdingTypes] ([WithholdingTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_FederatedLinks_IdpConfigId_IdentityProviderConfigs'
)
BEGIN
    ALTER TABLE [iam].[FederatedLinks]
        ADD CONSTRAINT [FK_iam_FederatedLinks_IdpConfigId_IdentityProviderConfigs]
        FOREIGN KEY ([IdpConfigId]) REFERENCES [iam].[IdentityProviderConfigs] ([IdentityProviderConfigId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ProfileAssignments_ScreenProfileId_ScreenProfiles'
)
BEGIN
    ALTER TABLE [iam].[ProfileAssignments]
        ADD CONSTRAINT [FK_iam_ProfileAssignments_ScreenProfileId_ScreenProfiles]
        FOREIGN KEY ([ScreenProfileId]) REFERENCES [iam].[ScreenProfiles] ([ScreenProfileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_SodExceptions_SodRuleId_SodRules'
)
BEGIN
    ALTER TABLE [iam].[SodExceptions]
        ADD CONSTRAINT [FK_iam_SodExceptions_SodRuleId_SodRules]
        FOREIGN KEY ([SodRuleId]) REFERENCES [iam].[SodRules] ([SodRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_Sessions_SupportGrantId_SupportAccessGrants'
)
BEGIN
    ALTER TABLE [iam].[Sessions]
        ADD CONSTRAINT [FK_iam_Sessions_SupportGrantId_SupportAccessGrants]
        FOREIGN KEY ([SupportGrantId]) REFERENCES [iam].[SupportAccessGrants] ([SupportAccessGrantId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalSubscriptionRules_CapitalItemId_CapitalItems'
)
BEGIN
    ALTER TABLE [ins].[CapitalSubscriptionRules]
        ADD CONSTRAINT [FK_ins_CapitalSubscriptionRules_CapitalItemId_CapitalItems]
        FOREIGN KEY ([CapitalItemId]) REFERENCES [ins].[CapitalItems] ([CapitalItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalMovements_CapitalItemId_CapitalItems'
)
BEGIN
    ALTER TABLE [ins].[CapitalMovements]
        ADD CONSTRAINT [FK_ins_CapitalMovements_CapitalItemId_CapitalItems]
        FOREIGN KEY ([CapitalItemId]) REFERENCES [ins].[CapitalItems] ([CapitalItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalBalances_CapitalItemId_CapitalItems'
)
BEGIN
    ALTER TABLE [ins].[CapitalBalances]
        ADD CONSTRAINT [FK_ins_CapitalBalances_CapitalItemId_CapitalItems]
        FOREIGN KEY ([CapitalItemId]) REFERENCES [ins].[CapitalItems] ([CapitalItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_AssociateMemberships_ElectoralDistrictId_ElectoralDistricts'
)
BEGIN
    ALTER TABLE [ins].[AssociateMemberships]
        ADD CONSTRAINT [FK_ins_AssociateMemberships_ElectoralDistrictId_ElectoralDistricts]
        FOREIGN KEY ([ElectoralDistrictId]) REFERENCES [ins].[ElectoralDistricts] ([ElectoralDistrictId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_RosterEntries_DistrictId_ElectoralDistricts'
)
BEGIN
    ALTER TABLE [ins].[RosterEntries]
        ADD CONSTRAINT [FK_ins_RosterEntries_DistrictId_ElectoralDistricts]
        FOREIGN KEY ([DistrictId]) REFERENCES [ins].[ElectoralDistricts] ([ElectoralDistrictId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Meetings_BodyId_GovernanceBodies'
)
BEGIN
    ALTER TABLE [ins].[Meetings]
        ADD CONSTRAINT [FK_ins_Meetings_BodyId_GovernanceBodies]
        FOREIGN KEY ([BodyId]) REFERENCES [ins].[GovernanceBodies] ([GovernanceBodyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFees_BodyId_GovernanceBodies'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFees]
        ADD CONSTRAINT [FK_ins_InstitutionalFees_BodyId_GovernanceBodies]
        FOREIGN KEY ([BodyId]) REFERENCES [ins].[GovernanceBodies] ([GovernanceBodyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_BodyMandates_BodyId_GovernanceBodies'
)
BEGIN
    ALTER TABLE [ins].[BodyMandates]
        ADD CONSTRAINT [FK_ins_BodyMandates_BodyId_GovernanceBodies]
        FOREIGN KEY ([BodyId]) REFERENCES [ins].[GovernanceBodies] ([GovernanceBodyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_AssociateMemberships_InaesCategoryId_InaesCategories'
)
BEGIN
    ALTER TABLE [ins].[AssociateMemberships]
        ADD CONSTRAINT [FK_ins_AssociateMemberships_InaesCategoryId_InaesCategories]
        FOREIGN KEY ([InaesCategoryId]) REFERENCES [ins].[InaesCategories] ([InaesCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_ElectoralLists_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[ElectoralLists]
        ADD CONSTRAINT [FK_ins_ElectoralLists_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingPermissions_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[MeetingPermissions]
        ADD CONSTRAINT [FK_ins_MeetingPermissions_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Minutes_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[Minutes]
        ADD CONSTRAINT [FK_ins_Minutes_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Proxies_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[Proxies]
        ADD CONSTRAINT [FK_ins_Proxies_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Rosters_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[Rosters]
        ADD CONSTRAINT [FK_ins_Rosters_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Resolutions_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[Resolutions]
        ADD CONSTRAINT [FK_ins_Resolutions_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingAgendaItems_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[MeetingAgendaItems]
        ADD CONSTRAINT [FK_ins_MeetingAgendaItems_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_BodyMandates_ElectedAtMeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[BodyMandates]
        ADD CONSTRAINT [FK_ins_BodyMandates_ElectedAtMeetingId_Meetings]
        FOREIGN KEY ([ElectedAtMeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_VotingSessions_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[VotingSessions]
        ADD CONSTRAINT [FK_ins_VotingSessions_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingParticipants_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[MeetingParticipants]
        ADD CONSTRAINT [FK_ins_MeetingParticipants_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_AssociateMemberships_ExitMinuteId_Minutes'
)
BEGIN
    ALTER TABLE [ins].[AssociateMemberships]
        ADD CONSTRAINT [FK_ins_AssociateMemberships_ExitMinuteId_Minutes]
        FOREIGN KEY ([ExitMinuteId]) REFERENCES [ins].[Minutes] ([MinuteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Resolutions_MinuteId_Minutes'
)
BEGIN
    ALTER TABLE [ins].[Resolutions]
        ADD CONSTRAINT [FK_ins_Resolutions_MinuteId_Minutes]
        FOREIGN KEY ([MinuteId]) REFERENCES [ins].[Minutes] ([MinuteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalMovements_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalMovements]
        ADD CONSTRAINT [FK_ins_CapitalMovements_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalBalances_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalBalances]
        ADD CONSTRAINT [FK_ins_CapitalBalances_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalReserves_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalReserves]
        ADD CONSTRAINT [FK_ins_CapitalReserves_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MemberCredentials_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[MemberCredentials]
        ADD CONSTRAINT [FK_ins_MemberCredentials_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MembershipEvents_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[MembershipEvents]
        ADD CONSTRAINT [FK_ins_MembershipEvents_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Proxies_GrantorAssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[Proxies]
        ADD CONSTRAINT [FK_ins_Proxies_GrantorAssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([GrantorAssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Proxies_ProxyAssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[Proxies]
        ADD CONSTRAINT [FK_ins_Proxies_ProxyAssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([ProxyAssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_RosterEntries_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[RosterEntries]
        ADD CONSTRAINT [FK_ins_RosterEntries_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_ShareCertificates_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[ShareCertificates]
        ADD CONSTRAINT [FK_ins_ShareCertificates_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalRefunds_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalRefunds]
        ADD CONSTRAINT [FK_ins_CapitalRefunds_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_BodyMandates_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[BodyMandates]
        ADD CONSTRAINT [FK_ins_BodyMandates_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingParticipants_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[MeetingParticipants]
        ADD CONSTRAINT [FK_ins_MeetingParticipants_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalTransfers_FromAssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalTransfers]
        ADD CONSTRAINT [FK_ins_CapitalTransfers_FromAssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([FromAssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalTransfers_ToAssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalTransfers]
        ADD CONSTRAINT [FK_ins_CapitalTransfers_ToAssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([ToAssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusAllocations_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[SurplusAllocations]
        ADD CONSTRAINT [FK_ins_SurplusAllocations_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalBalances_LastMovementId_CapitalMovements'
)
BEGIN
    ALTER TABLE [ins].[CapitalBalances]
        ADD CONSTRAINT [FK_ins_CapitalBalances_LastMovementId_CapitalMovements]
        FOREIGN KEY ([LastMovementId]) REFERENCES [ins].[CapitalMovements] ([CapitalMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalReserves_MovementIdsId_CapitalMovements'
)
BEGIN
    ALTER TABLE [ins].[CapitalReserves]
        ADD CONSTRAINT [FK_ins_CapitalReserves_MovementIdsId_CapitalMovements]
        FOREIGN KEY ([MovementIdsId]) REFERENCES [ins].[CapitalMovements] ([CapitalMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalTransfers_MovementIdsId_CapitalMovements'
)
BEGIN
    ALTER TABLE [ins].[CapitalTransfers]
        ADD CONSTRAINT [FK_ins_CapitalTransfers_MovementIdsId_CapitalMovements]
        FOREIGN KEY ([MovementIdsId]) REFERENCES [ins].[CapitalMovements] ([CapitalMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusAllocations_MovementId_CapitalMovements'
)
BEGIN
    ALTER TABLE [ins].[SurplusAllocations]
        ADD CONSTRAINT [FK_ins_SurplusAllocations_MovementId_CapitalMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [ins].[CapitalMovements] ([CapitalMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingParticipants_ProxyIdsId_Proxies'
)
BEGIN
    ALTER TABLE [ins].[MeetingParticipants]
        ADD CONSTRAINT [FK_ins_MeetingParticipants_ProxyIdsId_Proxies]
        FOREIGN KEY ([ProxyIdsId]) REFERENCES [ins].[Proxies] ([ProxyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_RosterEntries_RosterId_Rosters'
)
BEGIN
    ALTER TABLE [ins].[RosterEntries]
        ADD CONSTRAINT [FK_ins_RosterEntries_RosterId_Rosters]
        FOREIGN KEY ([RosterId]) REFERENCES [ins].[Rosters] ([RosterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationFileExchanges_FileLayoutId_FileLayouts'
)
BEGIN
    ALTER TABLE [int].[IntegrationFileExchanges]
        ADD CONSTRAINT [FK_int_IntegrationFileExchanges_FileLayoutId_FileLayouts]
        FOREIGN KEY ([FileLayoutId]) REFERENCES [int].[FileLayouts] ([FileLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_AiUsageLogs_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[AiUsageLogs]
        ADD CONSTRAINT [FK_int_AiUsageLogs_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationAlerts_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[IntegrationAlerts]
        ADD CONSTRAINT [FK_int_IntegrationAlerts_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationFileExchanges_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[IntegrationFileExchanges]
        ADD CONSTRAINT [FK_int_IntegrationFileExchanges_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationReconciliations_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[IntegrationReconciliations]
        ADD CONSTRAINT [FK_int_IntegrationReconciliations_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationContingencies_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[IntegrationContingencies]
        ADD CONSTRAINT [FK_int_IntegrationContingencies_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationTokens_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[IntegrationTokens]
        ADD CONSTRAINT [FK_int_IntegrationTokens_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_WebhookEndpoints_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[WebhookEndpoints]
        ADD CONSTRAINT [FK_int_WebhookEndpoints_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_WebhookInbox_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[WebhookInbox]
        ADD CONSTRAINT [FK_int_WebhookInbox_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationContingencies_ClosingReconciliationId_IntegrationReconciliations'
)
BEGIN
    ALTER TABLE [int].[IntegrationContingencies]
        ADD CONSTRAINT [FK_int_IntegrationContingencies_ClosingReconciliationId_IntegrationReconciliations]
        FOREIGN KEY ([ClosingReconciliationId]) REFERENCES [int].[IntegrationReconciliations] ([IntegrationReconciliationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationCertificates_PrivateKeySecretId_IntegrationSecrets'
)
BEGIN
    ALTER TABLE [int].[IntegrationCertificates]
        ADD CONSTRAINT [FK_int_IntegrationCertificates_PrivateKeySecretId_IntegrationSecrets]
        FOREIGN KEY ([PrivateKeySecretId]) REFERENCES [int].[IntegrationSecrets] ([IntegrationSecretId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_LocalAgentCommands_LocalAgentId_LocalAgents'
)
BEGIN
    ALTER TABLE [int].[LocalAgentCommands]
        ADD CONSTRAINT [FK_int_LocalAgentCommands_LocalAgentId_LocalAgents]
        FOREIGN KEY ([LocalAgentId]) REFERENCES [int].[LocalAgents] ([LocalAgentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_WebhookInbox_EndpointId_WebhookEndpoints'
)
BEGIN
    ALTER TABLE [int].[WebhookInbox]
        ADD CONSTRAINT [FK_int_WebhookInbox_EndpointId_WebhookEndpoints]
        FOREIGN KEY ([EndpointId]) REFERENCES [int].[WebhookEndpoints] ([WebhookEndpointId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_InjectionBalances_DistributedGenerationContractId_DistributedGenerationContracts'
)
BEGIN
    ALTER TABLE [med].[InjectionBalances]
        ADD CONSTRAINT [FK_med_InjectionBalances_DistributedGenerationContractId_DistributedGenerationContracts]
        FOREIGN KEY ([DistributedGenerationContractId]) REFERENCES [med].[DistributedGenerationContracts] ([DistributedGenerationContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeterTypes_BrandId_MeterBrands'
)
BEGIN
    ALTER TABLE [med].[MeterTypes]
        ADD CONSTRAINT [FK_med_MeterTypes_BrandId_MeterBrands]
        FOREIGN KEY ([BrandId]) REFERENCES [med].[MeterBrands] ([MeterBrandId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_Meters_BrandId_MeterBrands'
)
BEGIN
    ALTER TABLE [med].[Meters]
        ADD CONSTRAINT [FK_med_Meters_BrandId_MeterBrands]
        FOREIGN KEY ([BrandId]) REFERENCES [med].[MeterBrands] ([MeterBrandId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_Meters_CurrentInstallationId_MeterInstallations'
)
BEGIN
    ALTER TABLE [med].[Meters]
        ADD CONSTRAINT [FK_med_Meters_CurrentInstallationId_MeterInstallations]
        FOREIGN KEY ([CurrentInstallationId]) REFERENCES [med].[MeterInstallations] ([MeterInstallationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ReadingTasks_CapturedReadingId_MeterReadings'
)
BEGIN
    ALTER TABLE [med].[ReadingTasks]
        ADD CONSTRAINT [FK_med_ReadingTasks_CapturedReadingId_MeterReadings]
        FOREIGN KEY ([CapturedReadingId]) REFERENCES [med].[MeterReadings] ([MeterReadingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeterTypes_MeteringSystemId_MeteringSystems'
)
BEGIN
    ALTER TABLE [med].[MeterTypes]
        ADD CONSTRAINT [FK_med_MeterTypes_MeteringSystemId_MeteringSystems]
        FOREIGN KEY ([MeteringSystemId]) REFERENCES [med].[MeteringSystems] ([MeteringSystemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_Meters_MeterTypeId_MeterTypes'
)
BEGIN
    ALTER TABLE [med].[Meters]
        ADD CONSTRAINT [FK_med_Meters_MeterTypeId_MeterTypes]
        FOREIGN KEY ([MeterTypeId]) REFERENCES [med].[MeterTypes] ([MeterTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ReadingImportJobs_BatchId_ReadingBatches'
)
BEGIN
    ALTER TABLE [med].[ReadingImportJobs]
        ADD CONSTRAINT [FK_med_ReadingImportJobs_BatchId_ReadingBatches]
        FOREIGN KEY ([BatchId]) REFERENCES [med].[ReadingBatches] ([ReadingBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ReadingImportJobs_ProfileId_ReadingImportProfiles'
)
BEGIN
    ALTER TABLE [med].[ReadingImportJobs]
        ADD CONSTRAINT [FK_med_ReadingImportJobs_ProfileId_ReadingImportProfiles]
        FOREIGN KEY ([ProfileId]) REFERENCES [med].[ReadingImportProfiles] ([ReadingImportProfileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeteringPoints_ReadingId_ReadingRoutes'
)
BEGIN
    ALTER TABLE [med].[MeteringPoints]
        ADD CONSTRAINT [FK_med_MeteringPoints_ReadingId_ReadingRoutes]
        FOREIGN KEY ([ReadingId]) REFERENCES [med].[ReadingRoutes] ([ReadingRouteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ConsumptionDistributions_ParentPointId_MeteringPoints'
)
BEGIN
    ALTER TABLE [med].[ConsumptionDistributions]
        ADD CONSTRAINT [FK_med_ConsumptionDistributions_ParentPointId_MeteringPoints]
        FOREIGN KEY ([ParentPointId]) REFERENCES [med].[MeteringPoints] ([MeteringPointId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_CutoverPlans_FinalSnapshotId_LegacySnapshots'
)
BEGIN
    ALTER TABLE [mig].[CutoverPlans]
        ADD CONSTRAINT [FK_mig_CutoverPlans_FinalSnapshotId_LegacySnapshots]
        FOREIGN KEY ([FinalSnapshotId]) REFERENCES [mig].[LegacySnapshots] ([LegacySnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationIssues_SnapshotId_LegacySnapshots'
)
BEGIN
    ALTER TABLE [mig].[MigrationIssues]
        ADD CONSTRAINT [FK_mig_MigrationIssues_SnapshotId_LegacySnapshots]
        FOREIGN KEY ([SnapshotId]) REFERENCES [mig].[LegacySnapshots] ([LegacySnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationMappingRules_MappingSetId_MigrationMappingSets'
)
BEGIN
    ALTER TABLE [mig].[MigrationMappingRules]
        ADD CONSTRAINT [FK_mig_MigrationMappingRules_MappingSetId_MigrationMappingSets]
        FOREIGN KEY ([MappingSetId]) REFERENCES [mig].[MigrationMappingSets] ([MigrationMappingSetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationValueMaps_MappingSetId_MigrationMappingSets'
)
BEGIN
    ALTER TABLE [mig].[MigrationValueMaps]
        ADD CONSTRAINT [FK_mig_MigrationValueMaps_MappingSetId_MigrationMappingSets]
        FOREIGN KEY ([MappingSetId]) REFERENCES [mig].[MigrationMappingSets] ([MigrationMappingSetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationIssues_RuleId_MigrationMappingRules'
)
BEGIN
    ALTER TABLE [mig].[MigrationIssues]
        ADD CONSTRAINT [FK_mig_MigrationIssues_RuleId_MigrationMappingRules]
        FOREIGN KEY ([RuleId]) REFERENCES [mig].[MigrationMappingRules] ([MigrationMappingRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_BypassPlans_ProjectId_MigrationProjects'
)
BEGIN
    ALTER TABLE [mig].[BypassPlans]
        ADD CONSTRAINT [FK_mig_BypassPlans_ProjectId_MigrationProjects]
        FOREIGN KEY ([ProjectId]) REFERENCES [mig].[MigrationProjects] ([MigrationProjectId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_CutoverPlans_ProjectId_MigrationProjects'
)
BEGIN
    ALTER TABLE [mig].[CutoverPlans]
        ADD CONSTRAINT [FK_mig_CutoverPlans_ProjectId_MigrationProjects]
        FOREIGN KEY ([ProjectId]) REFERENCES [mig].[MigrationProjects] ([MigrationProjectId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_RollbackJournal_CutoverId_CutoverPlans'
)
BEGIN
    ALTER TABLE [mig].[RollbackJournal]
        ADD CONSTRAINT [FK_mig_RollbackJournal_CutoverId_CutoverPlans]
        FOREIGN KEY ([CutoverId]) REFERENCES [mig].[CutoverPlans] ([CutoverPlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationBatches_RunId_MigrationRuns'
)
BEGIN
    ALTER TABLE [mig].[MigrationBatches]
        ADD CONSTRAINT [FK_mig_MigrationBatches_RunId_MigrationRuns]
        FOREIGN KEY ([RunId]) REFERENCES [mig].[MigrationRuns] ([MigrationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_RollbackJournal_RunId_MigrationRuns'
)
BEGIN
    ALTER TABLE [mig].[RollbackJournal]
        ADD CONSTRAINT [FK_mig_RollbackJournal_RunId_MigrationRuns]
        FOREIGN KEY ([RunId]) REFERENCES [mig].[MigrationRuns] ([MigrationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationIssues_RunId_MigrationRuns'
)
BEGIN
    ALTER TABLE [mig].[MigrationIssues]
        ADD CONSTRAINT [FK_mig_MigrationIssues_RunId_MigrationRuns]
        FOREIGN KEY ([RunId]) REFERENCES [mig].[MigrationRuns] ([MigrationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_CollectionCases_DebtCollectionAgencyId_DebtCollectionAgencies'
)
BEGIN
    ALTER TABLE [mor].[CollectionCases]
        ADD CONSTRAINT [FK_mor_CollectionCases_DebtCollectionAgencyId_DebtCollectionAgencies]
        FOREIGN KEY ([DebtCollectionAgencyId]) REFERENCES [mor].[DebtCollectionAgencies] ([DebtCollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyStages_PolicyId_DelinquencyPolicies'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyStages]
        ADD CONSTRAINT [FK_mor_DelinquencyStages_PolicyId_DelinquencyPolicies]
        FOREIGN KEY ([PolicyId]) REFERENCES [mor].[DelinquencyPolicies] ([DelinquencyPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyBatches_PolicyId_DelinquencyPolicies'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyBatches]
        ADD CONSTRAINT [FK_mor_DelinquencyBatches_PolicyId_DelinquencyPolicies]
        FOREIGN KEY ([PolicyId]) REFERENCES [mor].[DelinquencyPolicies] ([DelinquencyPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyExceptions_ReasonId_DelinquencyReasons'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyExceptions]
        ADD CONSTRAINT [FK_mor_DelinquencyExceptions_ReasonId_DelinquencyReasons]
        FOREIGN KEY ([ReasonId]) REFERENCES [mor].[DelinquencyReasons] ([DelinquencyReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyBatches_StageId_DelinquencyStages'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyBatches]
        ADD CONSTRAINT [FK_mor_DelinquencyBatches_StageId_DelinquencyStages]
        FOREIGN KEY ([StageId]) REFERENCES [mor].[DelinquencyStages] ([DelinquencyStageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNoticeModels_StageIdsId_DelinquencyStages'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNoticeModels]
        ADD CONSTRAINT [FK_mor_DelinquencyNoticeModels_StageIdsId_DelinquencyStages]
        FOREIGN KEY ([StageIdsId]) REFERENCES [mor].[DelinquencyStages] ([DelinquencyStageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_StageId_DelinquencyStages'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_StageId_DelinquencyStages]
        FOREIGN KEY ([StageId]) REFERENCES [mor].[DelinquencyStages] ([DelinquencyStageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_DelinquencyBatchId_DelinquencyBatches'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_DelinquencyBatchId_DelinquencyBatches]
        FOREIGN KEY ([DelinquencyBatchId]) REFERENCES [mor].[DelinquencyBatches] ([DelinquencyBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_NoticeModelId_DelinquencyNoticeModels'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_NoticeModelId_DelinquencyNoticeModels]
        FOREIGN KEY ([NoticeModelId]) REFERENCES [mor].[DelinquencyNoticeModels] ([DelinquencyNoticeModelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_Guarantees_RequirementRuleId_GuaranteeRequirementRules'
)
BEGIN
    ALTER TABLE [mor].[Guarantees]
        ADD CONSTRAINT [FK_mor_Guarantees_RequirementRuleId_GuaranteeRequirementRules]
        FOREIGN KEY ([RequirementRuleId]) REFERENCES [mor].[GuaranteeRequirementRules] ([GuaranteeRequirementRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DocumentHolds_HoldReasonId_HoldReasons'
)
BEGIN
    ALTER TABLE [mor].[DocumentHolds]
        ADD CONSTRAINT [FK_mor_DocumentHolds_HoldReasonId_HoldReasons]
        FOREIGN KEY ([HoldReasonId]) REFERENCES [mor].[HoldReasons] ([HoldReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DocumentHolds_ReasonId_HoldReasons'
)
BEGIN
    ALTER TABLE [mor].[DocumentHolds]
        ADD CONSTRAINT [FK_mor_DocumentHolds_ReasonId_HoldReasons]
        FOREIGN KEY ([ReasonId]) REFERENCES [mor].[HoldReasons] ([HoldReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestBillingRunItems_RunId_InterestBillingRuns'
)
BEGIN
    ALTER TABLE [mor].[InterestBillingRunItems]
        ADD CONSTRAINT [FK_mor_InterestBillingRunItems_RunId_InterestBillingRuns]
        FOREIGN KEY ([RunId]) REFERENCES [mor].[InterestBillingRuns] ([InterestBillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestIndexValues_TableId_InterestIndexTables'
)
BEGIN
    ALTER TABLE [mor].[InterestIndexValues]
        ADD CONSTRAINT [FK_mor_InterestIndexValues_TableId_InterestIndexTables]
        FOREIGN KEY ([TableId]) REFERENCES [mor].[InterestIndexTables] ([InterestIndexTableId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestPolicies_LateInterestIndexTableId_InterestIndexTables'
)
BEGIN
    ALTER TABLE [mor].[InterestPolicies]
        ADD CONSTRAINT [FK_mor_InterestPolicies_LateInterestIndexTableId_InterestIndexTables]
        FOREIGN KEY ([LateInterestIndexTableId]) REFERENCES [mor].[InterestIndexTables] ([InterestIndexTableId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestPolicies_LateInterestRateTableId_InterestRateTables'
)
BEGIN
    ALTER TABLE [mor].[InterestPolicies]
        ADD CONSTRAINT [FK_mor_InterestPolicies_LateInterestRateTableId_InterestRateTables]
        FOREIGN KEY ([LateInterestRateTableId]) REFERENCES [mor].[InterestRateTables] ([InterestRateTableId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestCalculations_PolicyId_InterestPolicies'
)
BEGIN
    ALTER TABLE [mor].[InterestCalculations]
        ADD CONSTRAINT [FK_mor_InterestCalculations_PolicyId_InterestPolicies]
        FOREIGN KEY ([PolicyId]) REFERENCES [mor].[InterestPolicies] ([InterestPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DeferredInterests_CalculationId_InterestCalculations'
)
BEGIN
    ALTER TABLE [mor].[DeferredInterests]
        ADD CONSTRAINT [FK_mor_DeferredInterests_CalculationId_InterestCalculations]
        FOREIGN KEY ([CalculationId]) REFERENCES [mor].[InterestCalculations] ([InterestCalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DocumentHolds_ReleaseCalculationId_InterestCalculations'
)
BEGIN
    ALTER TABLE [mor].[DocumentHolds]
        ADD CONSTRAINT [FK_mor_DocumentHolds_ReleaseCalculationId_InterestCalculations]
        FOREIGN KEY ([ReleaseCalculationId]) REFERENCES [mor].[InterestCalculations] ([InterestCalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementSimulations_CalculationIdsId_InterestCalculations'
)
BEGIN
    ALTER TABLE [mor].[AgreementSimulations]
        ADD CONSTRAINT [FK_mor_AgreementSimulations_CalculationIdsId_InterestCalculations]
        FOREIGN KEY ([CalculationIdsId]) REFERENCES [mor].[InterestCalculations] ([InterestCalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_HoldIdsId_DocumentHolds'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_HoldIdsId_DocumentHolds]
        FOREIGN KEY ([HoldIdsId]) REFERENCES [mor].[DocumentHolds] ([DocumentHoldId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_InterruptionCaseIdsId_InterruptionCases'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_InterruptionCaseIdsId_InterruptionCases]
        FOREIGN KEY ([InterruptionCaseIdsId]) REFERENCES [mor].[InterruptionCases] ([InterruptionCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNoticeEvents_NoticeId_DelinquencyNotices'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNoticeEvents]
        ADD CONSTRAINT [FK_mor_DelinquencyNoticeEvents_NoticeId_DelinquencyNotices]
        FOREIGN KEY ([NoticeId]) REFERENCES [mor].[DelinquencyNotices] ([DelinquencyNoticeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_PrescriptionRuns_PrescriptionRuleIdsId_PrescriptionRules'
)
BEGIN
    ALTER TABLE [mor].[PrescriptionRuns]
        ADD CONSTRAINT [FK_mor_PrescriptionRuns_PrescriptionRuleIdsId_PrescriptionRules]
        FOREIGN KEY ([PrescriptionRuleIdsId]) REFERENCES [mor].[PrescriptionRules] ([PrescriptionRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_ErasureLedger_RequestId_DataSubjectRequests'
)
BEGIN
    ALTER TABLE [nfr].[ErasureLedger]
        ADD CONSTRAINT [FK_nfr_ErasureLedger_RequestId_DataSubjectRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [nfr].[DataSubjectRequests] ([DataSubjectRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_ConsentRecords_NoticeId_PrivacyNotices'
)
BEGIN
    ALTER TABLE [nfr].[ConsentRecords]
        ADD CONSTRAINT [FK_nfr_ConsentRecords_NoticeId_PrivacyNotices]
        FOREIGN KEY ([NoticeId]) REFERENCES [nfr].[PrivacyNotices] ([PrivacyNoticeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_DataCatalogEntries_PurposesId_ProcessingActivities'
)
BEGIN
    ALTER TABLE [nfr].[DataCatalogEntries]
        ADD CONSTRAINT [FK_nfr_DataCatalogEntries_PurposesId_ProcessingActivities]
        FOREIGN KEY ([PurposesId]) REFERENCES [nfr].[ProcessingActivities] ([ProcessingActivityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_DataCatalogEntries_RetentionPolicyId_RetentionPolicies'
)
BEGIN
    ALTER TABLE [nfr].[DataCatalogEntries]
        ADD CONSTRAINT [FK_nfr_DataCatalogEntries_RetentionPolicyId_RetentionPolicies]
        FOREIGN KEY ([RetentionPolicyId]) REFERENCES [nfr].[RetentionPolicies] ([RetentionPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_RetentionRuns_RetentionPolicyId_RetentionPolicies'
)
BEGIN
    ALTER TABLE [nfr].[RetentionRuns]
        ADD CONSTRAINT [FK_nfr_RetentionRuns_RetentionPolicyId_RetentionPolicies]
        FOREIGN KEY ([RetentionPolicyId]) REFERENCES [nfr].[RetentionPolicies] ([RetentionPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_StatusNotices_IncidentId_SecurityIncidents'
)
BEGIN
    ALTER TABLE [nfr].[StatusNotices]
        ADD CONSTRAINT [FK_nfr_StatusNotices_IncidentId_SecurityIncidents]
        FOREIGN KEY ([IncidentId]) REFERENCES [nfr].[SecurityIncidents] ([SecurityIncidentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Holders_PersonId_Persons'
)
BEGIN
    ALTER TABLE [per].[Holders]
        ADD CONSTRAINT [FK_per_Holders_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_PersonIdentifierIndex_PersonId_Persons'
)
BEGIN
    ALTER TABLE [per].[PersonIdentifierIndex]
        ADD CONSTRAINT [FK_per_PersonIdentifierIndex_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_PersonSensitiveData_PersonId_Persons'
)
BEGIN
    ALTER TABLE [per].[PersonSensitiveData]
        ADD CONSTRAINT [FK_per_PersonSensitiveData_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Accounts_HolderId_Holders'
)
BEGIN
    ALTER TABLE [per].[Accounts]
        ADD CONSTRAINT [FK_per_Accounts_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LegacyPortalUserMap_ImportId_LegacyPortalImports'
)
BEGIN
    ALTER TABLE [por].[LegacyPortalUserMap]
        ADD CONSTRAINT [FK_por_LegacyPortalUserMap_ImportId_LegacyPortalImports]
        FOREIGN KEY ([ImportId]) REFERENCES [por].[LegacyPortalImports] ([LegacyPortalImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalDelegationInvites_AccessId_PortalAccountAccess'
)
BEGIN
    ALTER TABLE [por].[PortalDelegationInvites]
        ADD CONSTRAINT [FK_por_PortalDelegationInvites_AccessId_PortalAccountAccess]
        FOREIGN KEY ([AccessId]) REFERENCES [por].[PortalAccountAccess] ([PortalAccountAccesId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalUserPreferences_DismissedBannerIdsId_PortalBanners'
)
BEGIN
    ALTER TABLE [por].[PortalUserPreferences]
        ADD CONSTRAINT [FK_por_PortalUserPreferences_DismissedBannerIdsId_PortalBanners]
        FOREIGN KEY ([DismissedBannerIdsId]) REFERENCES [por].[PortalBanners] ([PortalBannerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BenefitRequests_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[BenefitRequests]
        ADD CONSTRAINT [FK_soc_BenefitRequests_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HealthAuthorizations_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[HealthAuthorizations]
        ADD CONSTRAINT [FK_soc_HealthAuthorizations_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingCertificates_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[HousingCertificates]
        ADD CONSTRAINT [FK_soc_HousingCertificates_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialWithdrawals_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialWithdrawals]
        ADD CONSTRAINT [FK_soc_HousingMaterialWithdrawals_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_MedicalProfessionals_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[MedicalProfessionals]
        ADD CONSTRAINT [FK_soc_MedicalProfessionals_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ProviderAgreements_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[ProviderAgreements]
        ADD CONSTRAINT [FK_soc_ProviderAgreements_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BloodCoverageRequests_FacilityId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[BloodCoverageRequests]
        ADD CONSTRAINT [FK_soc_BloodCoverageRequests_FacilityId_CareProviders]
        FOREIGN KEY ([FacilityId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TransportTrips_CompanyProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[TransportTrips]
        ADD CONSTRAINT [FK_soc_TransportTrips_CompanyProviderId_CareProviders]
        FOREIGN KEY ([CompanyProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleMaintenances_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[VehicleMaintenances]
        ADD CONSTRAINT [FK_soc_VehicleMaintenances_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FleetVehicles_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[FleetVehicles]
        ADD CONSTRAINT [FK_soc_FleetVehicles_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialServiceCases_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[BurialServiceCases]
        ADD CONSTRAINT [FK_soc_BurialServiceCases_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DeathSubsidyCases_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[DeathSubsidyCases]
        ADD CONSTRAINT [FK_soc_DeathSubsidyCases_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HealthAuthorizations_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[HealthAuthorizations]
        ADD CONSTRAINT [FK_soc_HealthAuthorizations_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_OrthopedicLoans_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[OrthopedicLoans]
        ADD CONSTRAINT [FK_soc_OrthopedicLoans_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BloodCoverageRequests_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[BloodCoverageRequests]
        ADD CONSTRAINT [FK_soc_BloodCoverageRequests_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TransportTrips_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[TransportTrips]
        ADD CONSTRAINT [FK_soc_TransportTrips_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialServiceCases_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[BurialServiceCases]
        ADD CONSTRAINT [FK_soc_BurialServiceCases_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryRegulations_CemeteryId_Cemeteries'
)
BEGIN
    ALTER TABLE [soc].[CemeteryRegulations]
        ADD CONSTRAINT [FK_soc_CemeteryRegulations_CemeteryId_Cemeteries]
        FOREIGN KEY ([CemeteryId]) REFERENCES [soc].[Cemeteries] ([CemeteryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialUnits_CemeteryId_Cemeteries'
)
BEGIN
    ALTER TABLE [soc].[BurialUnits]
        ADD CONSTRAINT [FK_soc_BurialUnits_CemeteryId_Cemeteries]
        FOREIGN KEY ([CemeteryId]) REFERENCES [soc].[Cemeteries] ([CemeteryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceDependents_CoveragePlanId_CoveragePlans'
)
BEGIN
    ALTER TABLE [soc].[ServiceDependents]
        ADD CONSTRAINT [FK_soc_ServiceDependents_CoveragePlanId_CoveragePlans]
        FOREIGN KEY ([CoveragePlanId]) REFERENCES [soc].[CoveragePlans] ([CoveragePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleUsages_DriverId_Drivers'
)
BEGIN
    ALTER TABLE [soc].[VehicleUsages]
        ADD CONSTRAINT [FK_soc_VehicleUsages_DriverId_Drivers]
        FOREIGN KEY ([DriverId]) REFERENCES [soc].[Drivers] ([DriverId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TripSettlements_DriverId_Drivers'
)
BEGIN
    ALTER TABLE [soc].[TripSettlements]
        ADD CONSTRAINT [FK_soc_TripSettlements_DriverId_Drivers]
        FOREIGN KEY ([DriverId]) REFERENCES [soc].[Drivers] ([DriverId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FleetVehicles_FuelTypeId_FuelTypes'
)
BEGIN
    ALTER TABLE [soc].[FleetVehicles]
        ADD CONSTRAINT [FK_soc_FleetVehicles_FuelTypeId_FuelTypes]
        FOREIGN KEY ([FuelTypeId]) REFERENCES [soc].[FuelTypes] ([FuelTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FuelLoads_FuelTypeId_FuelTypes'
)
BEGIN
    ALTER TABLE [soc].[FuelLoads]
        ADD CONSTRAINT [FK_soc_FuelLoads_FuelTypeId_FuelTypes]
        FOREIGN KEY ([FuelTypeId]) REFERENCES [soc].[FuelTypes] ([FuelTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingActivities_StageId_HousingStages'
)
BEGIN
    ALTER TABLE [soc].[HousingActivities]
        ADD CONSTRAINT [FK_soc_HousingActivities_StageId_HousingStages]
        FOREIGN KEY ([StageId]) REFERENCES [soc].[HousingStages] ([HousingStageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialWithdrawals_StageId_HousingStages'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialWithdrawals]
        ADD CONSTRAINT [FK_soc_HousingMaterialWithdrawals_StageId_HousingStages]
        FOREIGN KEY ([StageId]) REFERENCES [soc].[HousingStages] ([HousingStageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingActivityMaterials_ActivityId_HousingActivities'
)
BEGIN
    ALTER TABLE [soc].[HousingActivityMaterials]
        ADD CONSTRAINT [FK_soc_HousingActivityMaterials_ActivityId_HousingActivities]
        FOREIGN KEY ([ActivityId]) REFERENCES [soc].[HousingActivities] ([HousingActivityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_ActivityId_HousingActivities'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_ActivityId_HousingActivities]
        FOREIGN KEY ([ActivityId]) REFERENCES [soc].[HousingActivities] ([HousingActivityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingCertificates_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingCertificates]
        ADD CONSTRAINT [FK_soc_HousingCertificates_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingContributions_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingContributions]
        ADD CONSTRAINT [FK_soc_HousingContributions_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialAllocations_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialAllocations]
        ADD CONSTRAINT [FK_soc_HousingMaterialAllocations_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialWithdrawals_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialWithdrawals]
        ADD CONSTRAINT [FK_soc_HousingMaterialWithdrawals_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingPlanChanges_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingPlanChanges]
        ADD CONSTRAINT [FK_soc_HousingPlanChanges_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingTerminations_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingTerminations]
        ADD CONSTRAINT [FK_soc_HousingTerminations_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_CertificateId_HousingCertificates'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_CertificateId_HousingCertificates]
        FOREIGN KEY ([CertificateId]) REFERENCES [soc].[HousingCertificates] ([HousingCertificateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgressMaterials_AllocationId_HousingMaterialAllocations'
)
BEGIN
    ALTER TABLE [soc].[HousingProgressMaterials]
        ADD CONSTRAINT [FK_soc_HousingProgressMaterials_AllocationId_HousingMaterialAllocations]
        FOREIGN KEY ([AllocationId]) REFERENCES [soc].[HousingMaterialAllocations] ([HousingMaterialAllocationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgressMaterials_ProgressId_HousingProgress'
)
BEGIN
    ALTER TABLE [soc].[HousingProgressMaterials]
        ADD CONSTRAINT [FK_soc_HousingProgressMaterials_ProgressId_HousingProgress]
        FOREIGN KEY ([ProgressId]) REFERENCES [soc].[HousingProgress] ([HousingProgresId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_MedicalProfessionals_SpecialtyId_MedicalSpecialties'
)
BEGIN
    ALTER TABLE [soc].[MedicalProfessionals]
        ADD CONSTRAINT [FK_soc_MedicalProfessionals_SpecialtyId_MedicalSpecialties]
        FOREIGN KEY ([SpecialtyId]) REFERENCES [soc].[MedicalSpecialties] ([MedicalSpecialtyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TransportTrips_ProfessionalIdsId_MedicalProfessionals'
)
BEGIN
    ALTER TABLE [soc].[TransportTrips]
        ADD CONSTRAINT [FK_soc_TransportTrips_ProfessionalIdsId_MedicalProfessionals]
        FOREIGN KEY ([ProfessionalIdsId]) REFERENCES [soc].[MedicalProfessionals] ([MedicalProfessionalId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_OrthopedicLoans_ItemId_OrthopedicItems'
)
BEGIN
    ALTER TABLE [soc].[OrthopedicLoans]
        ADD CONSTRAINT [FK_soc_OrthopedicLoans_ItemId_OrthopedicItems]
        FOREIGN KEY ([ItemId]) REFERENCES [soc].[OrthopedicItems] ([OrthopedicItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BloodCoverageRequests_AgreementId_ProviderAgreements'
)
BEGIN
    ALTER TABLE [soc].[BloodCoverageRequests]
        ADD CONSTRAINT [FK_soc_BloodCoverageRequests_AgreementId_ProviderAgreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [soc].[ProviderAgreements] ([ProviderAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DonationCampaigns_AgreementId_ProviderAgreements'
)
BEGIN
    ALTER TABLE [soc].[DonationCampaigns]
        ADD CONSTRAINT [FK_soc_DonationCampaigns_AgreementId_ProviderAgreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [soc].[ProviderAgreements] ([ProviderAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DonationAppointments_CampaignId_DonationCampaigns'
)
BEGIN
    ALTER TABLE [soc].[DonationAppointments]
        ADD CONSTRAINT [FK_soc_DonationAppointments_CampaignId_DonationCampaigns]
        FOREIGN KEY ([CampaignId]) REFERENCES [soc].[DonationCampaigns] ([DonationCampaignId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DependentEvents_BeneficiaryId_ServiceBeneficiaries'
)
BEGIN
    ALTER TABLE [soc].[DependentEvents]
        ADD CONSTRAINT [FK_soc_DependentEvents_BeneficiaryId_ServiceBeneficiaries]
        FOREIGN KEY ([BeneficiaryId]) REFERENCES [soc].[ServiceBeneficiaries] ([ServiceBeneficiaryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DependentEvents_DependentId_ServiceDependents'
)
BEGIN
    ALTER TABLE [soc].[DependentEvents]
        ADD CONSTRAINT [FK_soc_DependentEvents_DependentId_ServiceDependents]
        FOREIGN KEY ([DependentId]) REFERENCES [soc].[ServiceDependents] ([ServiceDependentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TransportTrips_CharacteristicId_TripCharacteristics'
)
BEGIN
    ALTER TABLE [soc].[TransportTrips]
        ADD CONSTRAINT [FK_soc_TransportTrips_CharacteristicId_TripCharacteristics]
        FOREIGN KEY ([CharacteristicId]) REFERENCES [soc].[TripCharacteristics] ([TripCharacteristicId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TripLegs_TripId_TransportTrips'
)
BEGIN
    ALTER TABLE [soc].[TripLegs]
        ADD CONSTRAINT [FK_soc_TripLegs_TripId_TransportTrips]
        FOREIGN KEY ([TripId]) REFERENCES [soc].[TransportTrips] ([TransportTripId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialServiceCases_TripId_TransportTrips'
)
BEGIN
    ALTER TABLE [soc].[BurialServiceCases]
        ADD CONSTRAINT [FK_soc_BurialServiceCases_TripId_TransportTrips]
        FOREIGN KEY ([TripId]) REFERENCES [soc].[TransportTrips] ([TransportTripId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_DepreciationRuns_FixedAssetId_FixedAssets'
)
BEGIN
    ALTER TABLE [stk].[DepreciationRuns]
        ADD CONSTRAINT [FK_stk_DepreciationRuns_FixedAssetId_FixedAssets]
        FOREIGN KEY ([FixedAssetId]) REFERENCES [stk].[FixedAssets] ([FixedAssetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetDepreciations_FixedAssetId_FixedAssets'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetDepreciations]
        ADD CONSTRAINT [FK_stk_FixedAssetDepreciations_FixedAssetId_FixedAssets]
        FOREIGN KEY ([FixedAssetId]) REFERENCES [stk].[FixedAssets] ([FixedAssetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetHistory_FixedAssetId_FixedAssets'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetHistory]
        ADD CONSTRAINT [FK_stk_FixedAssetHistory_FixedAssetId_FixedAssets]
        FOREIGN KEY ([FixedAssetId]) REFERENCES [stk].[FixedAssets] ([FixedAssetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetValueChanges_FixedAssetId_FixedAssets'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetValueChanges]
        ADD CONSTRAINT [FK_stk_FixedAssetValueChanges_FixedAssetId_FixedAssets]
        FOREIGN KEY ([FixedAssetId]) REFERENCES [stk].[FixedAssets] ([FixedAssetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetDepreciations_DepreciationRunId_DepreciationRuns'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetDepreciations]
        ADD CONSTRAINT [FK_stk_FixedAssetDepreciations_DepreciationRunId_DepreciationRuns]
        FOREIGN KEY ([DepreciationRunId]) REFERENCES [stk].[DepreciationRuns] ([DepreciationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetDepreciations_RunId_DepreciationRuns'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetDepreciations]
        ADD CONSTRAINT [FK_stk_FixedAssetDepreciations_RunId_DepreciationRuns]
        FOREIGN KEY ([RunId]) REFERENCES [stk].[DepreciationRuns] ([DepreciationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemKits_ComponentItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ItemKits]
        ADD CONSTRAINT [FK_stk_ItemKits_ComponentItemId_InventoryItems]
        FOREIGN KEY ([ComponentItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemKits_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ItemKits]
        ADD CONSTRAINT [FK_stk_ItemKits_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemKits_KitItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ItemKits]
        ADD CONSTRAINT [FK_stk_ItemKits_KitItemId_InventoryItems]
        FOREIGN KEY ([KitItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Lots_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[Lots]
        ADD CONSTRAINT [FK_stk_Lots_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ManufacturingStages_ItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ManufacturingStages]
        ADD CONSTRAINT [FK_stk_ManufacturingStages_ItemId_InventoryItems]
        FOREIGN KEY ([ItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Revaluations_InventoryItemIdsId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[Revaluations]
        ADD CONSTRAINT [FK_stk_Revaluations_InventoryItemIdsId_InventoryItems]
        FOREIGN KEY ([InventoryItemIdsId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_CostLayers_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[CostLayers]
        ADD CONSTRAINT [FK_stk_CostLayers_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemCostStates_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ItemCostStates]
        ADD CONSTRAINT [FK_stk_ItemCostStates_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ReorderSuggestions_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ReorderSuggestions]
        ADD CONSTRAINT [FK_stk_ReorderSuggestions_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockReservations_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[StockReservations]
        ADD CONSTRAINT [FK_stk_StockReservations_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemLocationDefaults_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ItemLocationDefaults]
        ADD CONSTRAINT [FK_stk_ItemLocationDefaults_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockBalances_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[StockBalances]
        ADD CONSTRAINT [FK_stk_StockBalances_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_BomStructureVersions_ItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[BomStructureVersions]
        ADD CONSTRAINT [FK_stk_BomStructureVersions_ItemId_InventoryItems]
        FOREIGN KEY ([ItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_BomStructures_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[BomStructures]
        ADD CONSTRAINT [FK_stk_BomStructures_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Lots_LotTypeId_LotTypes'
)
BEGIN
    ALTER TABLE [stk].[Lots]
        ADD CONSTRAINT [FK_stk_Lots_LotTypeId_LotTypes]
        FOREIGN KEY ([LotTypeId]) REFERENCES [stk].[LotTypes] ([LotTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockBalances_LotId_Lots'
)
BEGIN
    ALTER TABLE [stk].[StockBalances]
        ADD CONSTRAINT [FK_stk_StockBalances_LotId_Lots]
        FOREIGN KEY ([LotId]) REFERENCES [stk].[Lots] ([LotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_MrpRuns_ManufacturingOrderIdsId_ManufacturingOrders'
)
BEGIN
    ALTER TABLE [stk].[MrpRuns]
        ADD CONSTRAINT [FK_stk_MrpRuns_ManufacturingOrderIdsId_ManufacturingOrders]
        FOREIGN KEY ([ManufacturingOrderIdsId]) REFERENCES [stk].[ManufacturingOrders] ([ManufacturingOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ProductionReports_ManufacturingOrderId_ManufacturingOrders'
)
BEGIN
    ALTER TABLE [stk].[ProductionReports]
        ADD CONSTRAINT [FK_stk_ProductionReports_ManufacturingOrderId_ManufacturingOrders]
        FOREIGN KEY ([ManufacturingOrderId]) REFERENCES [stk].[ManufacturingOrders] ([ManufacturingOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_SerialUnitEvents_RmaCaseId_RmaCases'
)
BEGIN
    ALTER TABLE [stk].[SerialUnitEvents]
        ADD CONSTRAINT [FK_stk_SerialUnitEvents_RmaCaseId_RmaCases]
        FOREIGN KEY ([RmaCaseId]) REFERENCES [stk].[RmaCases] ([RmaCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ServiceReceptions_SerialUnitId_SerialUnits'
)
BEGIN
    ALTER TABLE [stk].[ServiceReceptions]
        ADD CONSTRAINT [FK_stk_ServiceReceptions_SerialUnitId_SerialUnits]
        FOREIGN KEY ([SerialUnitId]) REFERENCES [stk].[SerialUnits] ([SerialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_SerialUnitEvents_SerialUnitId_SerialUnits'
)
BEGIN
    ALTER TABLE [stk].[SerialUnitEvents]
        ADD CONSTRAINT [FK_stk_SerialUnitEvents_SerialUnitId_SerialUnits]
        FOREIGN KEY ([SerialUnitId]) REFERENCES [stk].[SerialUnits] ([SerialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockReservations_SerialUnitId_SerialUnits'
)
BEGIN
    ALTER TABLE [stk].[StockReservations]
        ADD CONSTRAINT [FK_stk_StockReservations_SerialUnitId_SerialUnits]
        FOREIGN KEY ([SerialUnitId]) REFERENCES [stk].[SerialUnits] ([SerialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_CostLayers_InMovementId_StockMovements'
)
BEGIN
    ALTER TABLE [stk].[CostLayers]
        ADD CONSTRAINT [FK_stk_CostLayers_InMovementId_StockMovements]
        FOREIGN KEY ([InMovementId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_CostLayers_StockMovementId_StockMovements'
)
BEGIN
    ALTER TABLE [stk].[CostLayers]
        ADD CONSTRAINT [FK_stk_CostLayers_StockMovementId_StockMovements]
        FOREIGN KEY ([StockMovementId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_SerialUnitEvents_MovementId_StockMovements'
)
BEGIN
    ALTER TABLE [stk].[SerialUnitEvents]
        ADD CONSTRAINT [FK_stk_SerialUnitEvents_MovementId_StockMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemCostStates_InMovementId_StockMovements'
)
BEGIN
    ALTER TABLE [stk].[ItemCostStates]
        ADD CONSTRAINT [FK_stk_ItemCostStates_InMovementId_StockMovements]
        FOREIGN KEY ([InMovementId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_CrewSettlements_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[CrewSettlements]
        ADD CONSTRAINT [FK_stk_CrewSettlements_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemCostStates_ScopeWarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[ItemCostStates]
        ADD CONSTRAINT [FK_stk_ItemCostStates_ScopeWarehouseId_Warehouses]
        FOREIGN KEY ([ScopeWarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemCostStates_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[ItemCostStates]
        ADD CONSTRAINT [FK_stk_ItemCostStates_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_PhysicalCounts_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[PhysicalCounts]
        ADD CONSTRAINT [FK_stk_PhysicalCounts_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ReorderSuggestions_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[ReorderSuggestions]
        ADD CONSTRAINT [FK_stk_ReorderSuggestions_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockReservations_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[StockReservations]
        ADD CONSTRAINT [FK_stk_StockReservations_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_WarehouseLocations_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[WarehouseLocations]
        ADD CONSTRAINT [FK_stk_WarehouseLocations_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemLocationDefaults_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[ItemLocationDefaults]
        ADD CONSTRAINT [FK_stk_ItemLocationDefaults_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockBalances_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[StockBalances]
        ADD CONSTRAINT [FK_stk_StockBalances_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemLocationDefaults_WarehouseLocationId_WarehouseLocations'
)
BEGIN
    ALTER TABLE [stk].[ItemLocationDefaults]
        ADD CONSTRAINT [FK_stk_ItemLocationDefaults_WarehouseLocationId_WarehouseLocations]
        FOREIGN KEY ([WarehouseLocationId]) REFERENCES [stk].[WarehouseLocations] ([WarehouseLocationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockBalances_LocationId_WarehouseLocations'
)
BEGIN
    ALTER TABLE [stk].[StockBalances]
        ADD CONSTRAINT [FK_stk_StockBalances_LocationId_WarehouseLocations]
        FOREIGN KEY ([LocationId]) REFERENCES [stk].[WarehouseLocations] ([WarehouseLocationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_DeductionPlans_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[DeductionPlans]
        ADD CONSTRAINT [FK_sue_DeductionPlans_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeAssignments_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeAssignments]
        ADD CONSTRAINT [FK_sue_EmployeeAssignments_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeCostAllocations_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeCostAllocations]
        ADD CONSTRAINT [FK_sue_EmployeeCostAllocations_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeDocuments_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeDocuments]
        ADD CONSTRAINT [FK_sue_EmployeeDocuments_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeFamilyMembers_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeFamilyMembers]
        ADD CONSTRAINT [FK_sue_EmployeeFamilyMembers_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeNotes_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeNotes]
        ADD CONSTRAINT [FK_sue_EmployeeNotes_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeePayAccounts_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeePayAccounts]
        ADD CONSTRAINT [FK_sue_EmployeePayAccounts_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmploymentCertificates_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmploymentCertificates]
        ADD CONSTRAINT [FK_sue_EmploymentCertificates_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_IncomeTaxDeclarations_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[IncomeTaxDeclarations]
        ADD CONSTRAINT [FK_sue_IncomeTaxDeclarations_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LaborLawsuits_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[LaborLawsuits]
        ADD CONSTRAINT [FK_sue_LaborLawsuits_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PerformanceReviews_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[PerformanceReviews]
        ADD CONSTRAINT [FK_sue_PerformanceReviews_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeShiftAssignments_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeShiftAssignments]
        ADD CONSTRAINT [FK_sue_EmployeeShiftAssignments_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SupervisionLinks_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[SupervisionLinks]
        ADD CONSTRAINT [FK_sue_SupervisionLinks_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SupervisionLinks_SupervisorEmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[SupervisionLinks]
        ADD CONSTRAINT [FK_sue_SupervisionLinks_SupervisorEmployeeId_Employees]
        FOREIGN KEY ([SupervisorEmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_TimePunches_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[TimePunches]
        ADD CONSTRAINT [FK_sue_TimePunches_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_VacationBalances_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[VacationBalances]
        ADD CONSTRAINT [FK_sue_VacationBalances_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_WorkAreas_ManagerEmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[WorkAreas]
        ADD CONSTRAINT [FK_sue_WorkAreas_ManagerEmployeeId_Employees]
        FOREIGN KEY ([ManagerEmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Objectives_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[Objectives]
        ADD CONSTRAINT [FK_sue_Objectives_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_WorkAccidents_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[WorkAccidents]
        ADD CONSTRAINT [FK_sue_WorkAccidents_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmploymentStatusPeriods_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmploymentStatusPeriods]
        ADD CONSTRAINT [FK_sue_EmploymentStatusPeriods_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LeaveRequests_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[LeaveRequests]
        ADD CONSTRAINT [FK_sue_LeaveRequests_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Terminations_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[Terminations]
        ADD CONSTRAINT [FK_sue_Terminations_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_IncomeTaxCalculations_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[IncomeTaxCalculations]
        ADD CONSTRAINT [FK_sue_IncomeTaxCalculations_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_DisciplinaryActions_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[DisciplinaryActions]
        ADD CONSTRAINT [FK_sue_DisciplinaryActions_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_AdministrativeInquiries_EmployeeIdsId_Employees'
)
BEGIN
    ALTER TABLE [sue].[AdministrativeInquiries]
        ADD CONSTRAINT [FK_sue_AdministrativeInquiries_EmployeeIdsId_Employees]
        FOREIGN KEY ([EmployeeIdsId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Novelties_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[Novelties]
        ADD CONSTRAINT [FK_sue_Novelties_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayslipNotifications_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[PayslipNotifications]
        ADD CONSTRAINT [FK_sue_PayslipNotifications_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExtraTasks_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[ExtraTasks]
        ADD CONSTRAINT [FK_sue_ExtraTasks_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeExtras_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeExtras]
        ADD CONSTRAINT [FK_sue_EmployeeExtras_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExternalPayrollImports_LayoutId_ExternalPayrollLayouts'
)
BEGIN
    ALTER TABLE [sue].[ExternalPayrollImports]
        ADD CONSTRAINT [FK_sue_ExternalPayrollImports_LayoutId_ExternalPayrollLayouts]
        FOREIGN KEY ([LayoutId]) REFERENCES [sue].[ExternalPayrollLayouts] ([ExternalPayrollLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_StatutoryFilings_LayoutId_ExternalPayrollLayouts'
)
BEGIN
    ALTER TABLE [sue].[StatutoryFilings]
        ADD CONSTRAINT [FK_sue_StatutoryFilings_LayoutId_ExternalPayrollLayouts]
        FOREIGN KEY ([LayoutId]) REFERENCES [sue].[ExternalPayrollLayouts] ([ExternalPayrollLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExtraItems_GroupId_ExtraGroups'
)
BEGIN
    ALTER TABLE [sue].[ExtraItems]
        ADD CONSTRAINT [FK_sue_ExtraItems_GroupId_ExtraGroups]
        FOREIGN KEY ([GroupId]) REFERENCES [sue].[ExtraGroups] ([ExtraGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeExtras_ExtraItemId_ExtraItems'
)
BEGIN
    ALTER TABLE [sue].[EmployeeExtras]
        ADD CONSTRAINT [FK_sue_EmployeeExtras_ExtraItemId_ExtraItems]
        FOREIGN KEY ([ExtraItemId]) REFERENCES [sue].[ExtraItems] ([ExtraItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_TimePunches_ImportBatchId_NoveltyImportBatches'
)
BEGIN
    ALTER TABLE [sue].[TimePunches]
        ADD CONSTRAINT [FK_sue_TimePunches_ImportBatchId_NoveltyImportBatches]
        FOREIGN KEY ([ImportBatchId]) REFERENCES [sue].[NoveltyImportBatches] ([NoveltyImportBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LeaveCauses_NoveltyTypeId_NoveltyTypes'
)
BEGIN
    ALTER TABLE [sue].[LeaveCauses]
        ADD CONSTRAINT [FK_sue_LeaveCauses_NoveltyTypeId_NoveltyTypes]
        FOREIGN KEY ([NoveltyTypeId]) REFERENCES [sue].[NoveltyTypes] ([NoveltyTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Novelties_NoveltyTypeId_NoveltyTypes'
)
BEGIN
    ALTER TABLE [sue].[Novelties]
        ADD CONSTRAINT [FK_sue_Novelties_NoveltyTypeId_NoveltyTypes]
        FOREIGN KEY ([NoveltyTypeId]) REFERENCES [sue].[NoveltyTypes] ([NoveltyTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LeaveRequests_LeaveCauseId_LeaveCauses'
)
BEGIN
    ALTER TABLE [sue].[LeaveRequests]
        ADD CONSTRAINT [FK_sue_LeaveRequests_LeaveCauseId_LeaveCauses]
        FOREIGN KEY ([LeaveCauseId]) REFERENCES [sue].[LeaveCauses] ([LeaveCausId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollAccountingRules_PayrollConceptId_PayrollConcepts'
)
BEGIN
    ALTER TABLE [sue].[PayrollAccountingRules]
        ADD CONSTRAINT [FK_sue_PayrollAccountingRules_PayrollConceptId_PayrollConcepts]
        FOREIGN KEY ([PayrollConceptId]) REFERENCES [sue].[PayrollConcepts] ([PayrollConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollVariables_ConfigVersionId_PayrollConfigVersions'
)
BEGIN
    ALTER TABLE [sue].[PayrollVariables]
        ADD CONSTRAINT [FK_sue_PayrollVariables_ConfigVersionId_PayrollConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [sue].[PayrollConfigVersions] ([PayrollConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollRuns_PayrollTypeId_PayrollTypes'
)
BEGIN
    ALTER TABLE [sue].[PayrollRuns]
        ADD CONSTRAINT [FK_sue_PayrollRuns_PayrollTypeId_PayrollTypes]
        FOREIGN KEY ([PayrollTypeId]) REFERENCES [sue].[PayrollTypes] ([PayrollTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PerformanceCycles_TemplateId_PerformanceTemplates'
)
BEGIN
    ALTER TABLE [sue].[PerformanceCycles]
        ADD CONSTRAINT [FK_sue_PerformanceCycles_TemplateId_PerformanceTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [sue].[PerformanceTemplates] ([PerformanceTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PerformanceReviews_CycleId_PerformanceCycles'
)
BEGIN
    ALTER TABLE [sue].[PerformanceReviews]
        ADD CONSTRAINT [FK_sue_PerformanceReviews_CycleId_PerformanceCycles]
        FOREIGN KEY ([CycleId]) REFERENCES [sue].[PerformanceCycles] ([PerformanceCycleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Objectives_CycleId_PerformanceCycles'
)
BEGIN
    ALTER TABLE [sue].[Objectives]
        ADD CONSTRAINT [FK_sue_Objectives_CycleId_PerformanceCycles]
        FOREIGN KEY ([CycleId]) REFERENCES [sue].[PerformanceCycles] ([PerformanceCycleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeShiftAssignments_ShiftId_Shifts'
)
BEGIN
    ALTER TABLE [sue].[EmployeeShiftAssignments]
        ADD CONSTRAINT [FK_sue_EmployeeShiftAssignments_ShiftId_Shifts]
        FOREIGN KEY ([ShiftId]) REFERENCES [sue].[Shifts] ([ShiftId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Terminations_TerminationReasonId_TerminationReasons'
)
BEGIN
    ALTER TABLE [sue].[Terminations]
        ADD CONSTRAINT [FK_sue_Terminations_TerminationReasonId_TerminationReasons]
        FOREIGN KEY ([TerminationReasonId]) REFERENCES [sue].[TerminationReasons] ([TerminationReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SeniorityScales_UnionId_Unions'
)
BEGIN
    ALTER TABLE [sue].[SeniorityScales]
        ADD CONSTRAINT [FK_sue_SeniorityScales_UnionId_Unions]
        FOREIGN KEY ([UnionId]) REFERENCES [sue].[Unions] ([UnionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LaborAgreements_UnionId_Unions'
)
BEGIN
    ALTER TABLE [sue].[LaborAgreements]
        ADD CONSTRAINT [FK_sue_LaborAgreements_UnionId_Unions]
        FOREIGN KEY ([UnionId]) REFERENCES [sue].[Unions] ([UnionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Objectives_WorkAreaId_WorkAreas'
)
BEGIN
    ALTER TABLE [sue].[Objectives]
        ADD CONSTRAINT [FK_sue_Objectives_WorkAreaId_WorkAreas]
        FOREIGN KEY ([WorkAreaId]) REFERENCES [sue].[WorkAreas] ([WorkAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_BenefitGroupMembers_GroupId_BenefitGroups'
)
BEGIN
    ALTER TABLE [tar].[BenefitGroupMembers]
        ADD CONSTRAINT [FK_tar_BenefitGroupMembers_GroupId_BenefitGroups]
        FOREIGN KEY ([GroupId]) REFERENCES [tar].[BenefitGroups] ([BenefitGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_RoundingCarryEntries_CalculationId_Calculations'
)
BEGIN
    ALTER TABLE [tar].[RoundingCarryEntries]
        ADD CONSTRAINT [FK_tar_RoundingCarryEntries_CalculationId_Calculations]
        FOREIGN KEY ([CalculationId]) REFERENCES [tar].[Calculations] ([CalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_EventChargeBonuses_EventChargeId_EventCharges'
)
BEGIN
    ALTER TABLE [tar].[EventChargeBonuses]
        ADD CONSTRAINT [FK_tar_EventChargeBonuses_EventChargeId_EventCharges]
        FOREIGN KEY ([EventChargeId]) REFERENCES [tar].[EventCharges] ([EventChargeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_PhoneRates_RatePlanId_PhoneRatePlans'
)
BEGIN
    ALTER TABLE [tar].[PhoneRates]
        ADD CONSTRAINT [FK_tar_PhoneRates_RatePlanId_PhoneRatePlans]
        FOREIGN KEY ([RatePlanId]) REFERENCES [tar].[PhoneRatePlans] ([PhoneRatePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_PhoneBandAssignments_RatePlanId_PhoneRatePlans'
)
BEGIN
    ALTER TABLE [tar].[PhoneBandAssignments]
        ADD CONSTRAINT [FK_tar_PhoneBandAssignments_RatePlanId_PhoneRatePlans]
        FOREIGN KEY ([RatePlanId]) REFERENCES [tar].[PhoneRatePlans] ([PhoneRatePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_PhoneBandAssignments_BandId_PhoneTimeBands'
)
BEGIN
    ALTER TABLE [tar].[PhoneBandAssignments]
        ADD CONSTRAINT [FK_tar_PhoneBandAssignments_BandId_PhoneTimeBands]
        FOREIGN KEY ([BandId]) REFERENCES [tar].[PhoneTimeBands] ([PhoneTimeBandId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_PromotionAssignments_PromotionId_Promotions'
)
BEGIN
    ALTER TABLE [tar].[PromotionAssignments]
        ADD CONSTRAINT [FK_tar_PromotionAssignments_PromotionId_Promotions]
        FOREIGN KEY ([PromotionId]) REFERENCES [tar].[Promotions] ([PromotionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SubsidyRollImports_RegimeId_SubsidyRegimes'
)
BEGIN
    ALTER TABLE [tar].[SubsidyRollImports]
        ADD CONSTRAINT [FK_tar_SubsidyRollImports_RegimeId_SubsidyRegimes]
        FOREIGN KEY ([RegimeId]) REFERENCES [tar].[SubsidyRegimes] ([SubsidyRegimeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SubsidyEnrollments_RegimeId_SubsidyRegimes'
)
BEGIN
    ALTER TABLE [tar].[SubsidyEnrollments]
        ADD CONSTRAINT [FK_tar_SubsidyEnrollments_RegimeId_SubsidyRegimes]
        FOREIGN KEY ([RegimeId]) REFERENCES [tar].[SubsidyRegimes] ([SubsidyRegimeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SubsidyEnrollments_RollImportId_SubsidyRollImports'
)
BEGIN
    ALTER TABLE [tar].[SubsidyEnrollments]
        ADD CONSTRAINT [FK_tar_SubsidyEnrollments_RollImportId_SubsidyRollImports]
        FOREIGN KEY ([RollImportId]) REFERENCES [tar].[SubsidyRollImports] ([SubsidyRollImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_AdherentRates_ScheduleId_TariffSchedules'
)
BEGIN
    ALTER TABLE [tar].[AdherentRates]
        ADD CONSTRAINT [FK_tar_AdherentRates_ScheduleId_TariffSchedules]
        FOREIGN KEY ([ScheduleId]) REFERENCES [tar].[TariffSchedules] ([TariffScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_CategoryCoefficients_ScheduleId_TariffSchedules'
)
BEGIN
    ALTER TABLE [tar].[CategoryCoefficients]
        ADD CONSTRAINT [FK_tar_CategoryCoefficients_ScheduleId_TariffSchedules]
        FOREIGN KEY ([ScheduleId]) REFERENCES [tar].[TariffSchedules] ([TariffScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_ProductPrices_ScheduleId_TariffSchedules'
)
BEGIN
    ALTER TABLE [tar].[ProductPrices]
        ADD CONSTRAINT [FK_tar_ProductPrices_ScheduleId_TariffSchedules]
        FOREIGN KEY ([ScheduleId]) REFERENCES [tar].[TariffSchedules] ([TariffScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_RetroactiveDiffRuns_ScheduleId_TariffSchedules'
)
BEGIN
    ALTER TABLE [tar].[RetroactiveDiffRuns]
        ADD CONSTRAINT [FK_tar_RetroactiveDiffRuns_ScheduleId_TariffSchedules]
        FOREIGN KEY ([ScheduleId]) REFERENCES [tar].[TariffSchedules] ([TariffScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SimulationRuns_LinkedScheduleId_TariffSchedules'
)
BEGIN
    ALTER TABLE [tar].[SimulationRuns]
        ADD CONSTRAINT [FK_tar_SimulationRuns_LinkedScheduleId_TariffSchedules]
        FOREIGN KEY ([LinkedScheduleId]) REFERENCES [tar].[TariffSchedules] ([TariffScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SimulationResults_SimulationRunId_SimulationRuns'
)
BEGIN
    ALTER TABLE [tar].[SimulationResults]
        ADD CONSTRAINT [FK_tar_SimulationResults_SimulationRunId_SimulationRuns]
        FOREIGN KEY ([SimulationRunId]) REFERENCES [tar].[SimulationRuns] ([SimulationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TechnicalProcedures_InstallerId_CertifiedInstallers'
)
BEGIN
    ALTER TABLE [tec].[TechnicalProcedures]
        ADD CONSTRAINT [FK_tec_TechnicalProcedures_InstallerId_CertifiedInstallers]
        FOREIGN KEY ([InstallerId]) REFERENCES [tec].[CertifiedInstallers] ([CertifiedInstallerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FeasibilityRequests_EstimateId_ConnectionEstimates'
)
BEGIN
    ALTER TABLE [tec].[FeasibilityRequests]
        ADD CONSTRAINT [FK_tec_FeasibilityRequests_EstimateId_ConnectionEstimates]
        FOREIGN KEY ([EstimateId]) REFERENCES [tec].[ConnectionEstimates] ([ConnectionEstimateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldEvidence_DeviceId_FieldDevices'
)
BEGIN
    ALTER TABLE [tec].[FieldEvidence]
        ADD CONSTRAINT [FK_tec_FieldEvidence_DeviceId_FieldDevices]
        FOREIGN KEY ([DeviceId]) REFERENCES [tec].[FieldDevices] ([FieldDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_ChecklistFormIdsId_FieldForms'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes]
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_ChecklistFormIdsId_FieldForms]
        FOREIGN KEY ([ChecklistFormIdsId]) REFERENCES [tec].[FieldForms] ([FieldFormId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Crews_LeaderId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[Crews]
        ADD CONSTRAINT [FK_tec_Crews_LeaderId_FieldResources]
        FOREIGN KEY ([LeaderId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_OnCallShifts_BackupResourceId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[OnCallShifts]
        ADD CONSTRAINT [FK_tec_OnCallShifts_BackupResourceId_FieldResources]
        FOREIGN KEY ([BackupResourceId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_OnCallShifts_ChiefResourceId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[OnCallShifts]
        ADD CONSTRAINT [FK_tec_OnCallShifts_ChiefResourceId_FieldResources]
        FOREIGN KEY ([ChiefResourceId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_OnCallShifts_PrimaryResourceId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[OnCallShifts]
        ADD CONSTRAINT [FK_tec_OnCallShifts_PrimaryResourceId_FieldResources]
        FOREIGN KEY ([PrimaryResourceId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ResponsibleNotificationRules_FieldResourceId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[ResponsibleNotificationRules]
        ADD CONSTRAINT [FK_tec_ResponsibleNotificationRules_FieldResourceId_FieldResources]
        FOREIGN KEY ([FieldResourceId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Visits_AssignedResourceIdsId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[Visits]
        ADD CONSTRAINT [FK_tec_Visits_AssignedResourceIdsId_FieldResources]
        FOREIGN KEY ([AssignedResourceIdsId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FeasibilityRequests_TechnicalResponsibleId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[FeasibilityRequests]
        ADD CONSTRAINT [FK_tec_FeasibilityRequests_TechnicalResponsibleId_FieldResources]
        FOREIGN KEY ([TechnicalResponsibleId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Visits_AssignedCrewId_Crews'
)
BEGIN
    ALTER TABLE [tec].[Visits]
        ADD CONSTRAINT [FK_tec_Visits_AssignedCrewId_Crews]
        FOREIGN KEY ([AssignedCrewId]) REFERENCES [tec].[Crews] ([CrewId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkLayers_NetworkId_Networks'
)
BEGIN
    ALTER TABLE [tec].[NetworkLayers]
        ADD CONSTRAINT [FK_tec_NetworkLayers_NetworkId_Networks]
        FOREIGN KEY ([NetworkId]) REFERENCES [tec].[Networks] ([NetworkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentTypes_NetworkId_Networks'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentTypes]
        ADD CONSTRAINT [FK_tec_NetworkComponentTypes_NetworkId_Networks]
        FOREIGN KEY ([NetworkId]) REFERENCES [tec].[Networks] ([NetworkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentRelations_NetworkId_Networks'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentRelations]
        ADD CONSTRAINT [FK_tec_NetworkComponentRelations_NetworkId_Networks]
        FOREIGN KEY ([NetworkId]) REFERENCES [tec].[Networks] ([NetworkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkElements_NetworkId_Networks'
)
BEGIN
    ALTER TABLE [tec].[NetworkElements]
        ADD CONSTRAINT [FK_tec_NetworkElements_NetworkId_Networks]
        FOREIGN KEY ([NetworkId]) REFERENCES [tec].[Networks] ([NetworkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentTypes_LayerId_NetworkLayers'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentTypes]
        ADD CONSTRAINT [FK_tec_NetworkComponentTypes_LayerId_NetworkLayers]
        FOREIGN KEY ([LayerId]) REFERENCES [tec].[NetworkLayers] ([NetworkLayerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentRelations_LayerId_NetworkLayers'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentRelations]
        ADD CONSTRAINT [FK_tec_NetworkComponentRelations_LayerId_NetworkLayers]
        FOREIGN KEY ([LayerId]) REFERENCES [tec].[NetworkLayers] ([NetworkLayerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkElements_LayerId_NetworkLayers'
)
BEGIN
    ALTER TABLE [tec].[NetworkElements]
        ADD CONSTRAINT [FK_tec_NetworkElements_LayerId_NetworkLayers]
        FOREIGN KEY ([LayerId]) REFERENCES [tec].[NetworkLayers] ([NetworkLayerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkAttributeDefs_ComponentTypeId_NetworkComponentTypes'
)
BEGIN
    ALTER TABLE [tec].[NetworkAttributeDefs]
        ADD CONSTRAINT [FK_tec_NetworkAttributeDefs_ComponentTypeId_NetworkComponentTypes]
        FOREIGN KEY ([ComponentTypeId]) REFERENCES [tec].[NetworkComponentTypes] ([NetworkComponentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentRelations_ChildTypeId_NetworkComponentTypes'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentRelations]
        ADD CONSTRAINT [FK_tec_NetworkComponentRelations_ChildTypeId_NetworkComponentTypes]
        FOREIGN KEY ([ChildTypeId]) REFERENCES [tec].[NetworkComponentTypes] ([NetworkComponentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentRelations_ParentTypeId_NetworkComponentTypes'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentRelations]
        ADD CONSTRAINT [FK_tec_NetworkComponentRelations_ParentTypeId_NetworkComponentTypes]
        FOREIGN KEY ([ParentTypeId]) REFERENCES [tec].[NetworkComponentTypes] ([NetworkComponentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkElements_ComponentTypeId_NetworkComponentTypes'
)
BEGIN
    ALTER TABLE [tec].[NetworkElements]
        ADD CONSTRAINT [FK_tec_NetworkElements_ComponentTypeId_NetworkComponentTypes]
        FOREIGN KEY ([ComponentTypeId]) REFERENCES [tec].[NetworkComponentTypes] ([NetworkComponentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneNumbers_PrefixId_PhonePrefixes'
)
BEGIN
    ALTER TABLE [tec].[PhoneNumbers]
        ADD CONSTRAINT [FK_tec_PhoneNumbers_PrefixId_PhonePrefixes]
        FOREIGN KEY ([PrefixId]) REFERENCES [tec].[PhonePrefixes] ([PhonePrefixeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneExchanges_PrefixId_PhonePrefixes'
)
BEGIN
    ALTER TABLE [tec].[PhoneExchanges]
        ADD CONSTRAINT [FK_tec_PhoneExchanges_PrefixId_PhonePrefixes]
        FOREIGN KEY ([PrefixId]) REFERENCES [tec].[PhonePrefixes] ([PhonePrefixeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvisioningProfiles_ProvisioningSystemId_ProvisioningSystems'
)
BEGIN
    ALTER TABLE [tec].[ProvisioningProfiles]
        ADD CONSTRAINT [FK_tec_ProvisioningProfiles_ProvisioningSystemId_ProvisioningSystems]
        FOREIGN KEY ([ProvisioningSystemId]) REFERENCES [tec].[ProvisioningSystems] ([ProvisioningSystemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvisioningCommands_ProvisioningSystemId_ProvisioningSystems'
)
BEGIN
    ALTER TABLE [tec].[ProvisioningCommands]
        ADD CONSTRAINT [FK_tec_ProvisioningCommands_ProvisioningSystemId_ProvisioningSystems]
        FOREIGN KEY ([ProvisioningSystemId]) REFERENCES [tec].[ProvisioningSystems] ([ProvisioningSystemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkDevices_ProvisioningSystemId_ProvisioningSystems'
)
BEGIN
    ALTER TABLE [tec].[NetworkDevices]
        ADD CONSTRAINT [FK_tec_NetworkDevices_ProvisioningSystemId_ProvisioningSystems]
        FOREIGN KEY ([ProvisioningSystemId]) REFERENCES [tec].[ProvisioningSystems] ([ProvisioningSystemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_DefaultResolutionIdsId_ResolutionCodes'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes]
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_DefaultResolutionIdsId_ResolutionCodes]
        FOREIGN KEY ([DefaultResolutionIdsId]) REFERENCES [tec].[ResolutionCodes] ([ResolutionCodeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Visits_ZoneId_SchedulingZones'
)
BEGIN
    ALTER TABLE [tec].[Visits]
        ADD CONSTRAINT [FK_tec_Visits_ZoneId_SchedulingZones]
        FOREIGN KEY ([ZoneId]) REFERENCES [tec].[SchedulingZones] ([SchedulingZoneId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_SyncConflicts_SyncMutationId_SyncMutations'
)
BEGIN
    ALTER TABLE [tec].[SyncConflicts]
        ADD CONSTRAINT [FK_tec_SyncConflicts_SyncMutationId_SyncMutations]
        FOREIGN KEY ([SyncMutationId]) REFERENCES [tec].[SyncMutations] ([SyncMutationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TaskCatalog_TaskGroupId_TaskGroups'
)
BEGIN
    ALTER TABLE [tec].[TaskCatalog]
        ADD CONSTRAINT [FK_tec_TaskCatalog_TaskGroupId_TaskGroups]
        FOREIGN KEY ([TaskGroupId]) REFERENCES [tec].[TaskGroups] ([TaskGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_RequiredTaskIdsId_TaskCatalog'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes]
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_RequiredTaskIdsId_TaskCatalog]
        FOREIGN KEY ([RequiredTaskIdsId]) REFERENCES [tec].[TaskCatalog] ([TaskCatalogId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberingPlan_ModalityId_TelecomModalities'
)
BEGIN
    ALTER TABLE [tec].[NumberingPlan]
        ADD CONSTRAINT [FK_tec_NumberingPlan_ModalityId_TelecomModalities]
        FOREIGN KEY ([ModalityId]) REFERENCES [tec].[TelecomModalities] ([TelecomModalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CallRecords_OperatorId_TelecomOperators'
)
BEGIN
    ALTER TABLE [tec].[CallRecords]
        ADD CONSTRAINT [FK_tec_CallRecords_OperatorId_TelecomOperators]
        FOREIGN KEY ([OperatorId]) REFERENCES [tec].[TelecomOperators] ([TelecomOperatorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberPortings_CounterpartOperatorId_TelecomOperators'
)
BEGIN
    ALTER TABLE [tec].[NumberPortings]
        ADD CONSTRAINT [FK_tec_NumberPortings_CounterpartOperatorId_TelecomOperators]
        FOREIGN KEY ([CounterpartOperatorId]) REFERENCES [tec].[TelecomOperators] ([TelecomOperatorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberingPlan_ServiceTypeId_TelecomServiceTypes'
)
BEGIN
    ALTER TABLE [tec].[NumberingPlan]
        ADD CONSTRAINT [FK_tec_NumberingPlan_ServiceTypeId_TelecomServiceTypes]
        FOREIGN KEY ([ServiceTypeId]) REFERENCES [tec].[TelecomServiceTypes] ([TelecomServiceTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Visits_BookingId_VisitBookings'
)
BEGIN
    ALTER TABLE [tec].[Visits]
        ADD CONSTRAINT [FK_tec_Visits_BookingId_VisitBookings]
        FOREIGN KEY ([BookingId]) REFERENCES [tec].[VisitBookings] ([VisitBookingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Visits_VisitTypeId_VisitTypes'
)
BEGIN
    ALTER TABLE [tec].[Visits]
        ADD CONSTRAINT [FK_tec_Visits_VisitTypeId_VisitTypes]
        FOREIGN KEY ([VisitTypeId]) REFERENCES [tec].[VisitTypes] ([VisitTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_VisitTypeId_VisitTypes'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes]
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_VisitTypeId_VisitTypes]
        FOREIGN KEY ([VisitTypeId]) REFERENCES [tec].[VisitTypes] ([VisitTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CashFlowSnapshots_ScenarioId_CashFlowScenarios'
)
BEGIN
    ALTER TABLE [tes].[CashFlowSnapshots]
        ADD CONSTRAINT [FK_tes_CashFlowSnapshots_ScenarioId_CashFlowScenarios]
        FOREIGN KEY ([ScenarioId]) REFERENCES [tes].[CashFlowScenarios] ([CashFlowScenarioId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PlannedCashItems_ScenarioId_CashFlowScenarios'
)
BEGIN
    ALTER TABLE [tes].[PlannedCashItems]
        ADD CONSTRAINT [FK_tes_PlannedCashItems_ScenarioId_CashFlowScenarios]
        FOREIGN KEY ([ScenarioId]) REFERENCES [tes].[CashFlowScenarios] ([CashFlowScenarioId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankBranches_InstitutionId_FinancialInstitutions'
)
BEGIN
    ALTER TABLE [tes].[BankBranches]
        ADD CONSTRAINT [FK_tes_BankBranches_InstitutionId_FinancialInstitutions]
        FOREIGN KEY ([InstitutionId]) REFERENCES [tes].[FinancialInstitutions] ([FinancialInstitutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckDrawerAccounts_InstitutionId_FinancialInstitutions'
)
BEGIN
    ALTER TABLE [tes].[CheckDrawerAccounts]
        ADD CONSTRAINT [FK_tes_CheckDrawerAccounts_InstitutionId_FinancialInstitutions]
        FOREIGN KEY ([InstitutionId]) REFERENCES [tes].[FinancialInstitutions] ([FinancialInstitutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_StatementImportProfiles_InstitutionId_FinancialInstitutions'
)
BEGIN
    ALTER TABLE [tes].[StatementImportProfiles]
        ADD CONSTRAINT [FK_tes_StatementImportProfiles_InstitutionId_FinancialInstitutions]
        FOREIGN KEY ([InstitutionId]) REFERENCES [tes].[FinancialInstitutions] ([FinancialInstitutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckDrawerAccounts_BankBranchId_BankBranches'
)
BEGIN
    ALTER TABLE [tes].[CheckDrawerAccounts]
        ADD CONSTRAINT [FK_tes_CheckDrawerAccounts_BankBranchId_BankBranches]
        FOREIGN KEY ([BankBranchId]) REFERENCES [tes].[BankBranches] ([BankBrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ThirdPartyChecks_InstrumentTypeId_InstrumentTypes'
)
BEGIN
    ALTER TABLE [tes].[ThirdPartyChecks]
        ADD CONSTRAINT [FK_tes_ThirdPartyChecks_InstrumentTypeId_InstrumentTypes]
        FOREIGN KEY ([InstrumentTypeId]) REFERENCES [tes].[InstrumentTypes] ([InstrumentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_InterbankingSyncRuns_ConnectionId_InterbankingConnections'
)
BEGIN
    ALTER TABLE [tes].[InterbankingSyncRuns]
        ADD CONSTRAINT [FK_tes_InterbankingSyncRuns_ConnectionId_InterbankingConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [tes].[InterbankingConnections] ([InterbankingConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_OwnChecks_PaymentExecutionId_PaymentExecutions'
)
BEGIN
    ALTER TABLE [tes].[OwnChecks]
        ADD CONSTRAINT [FK_tes_OwnChecks_PaymentExecutionId_PaymentExecutions]
        FOREIGN KEY ([PaymentExecutionId]) REFERENCES [tes].[PaymentExecutions] ([PaymentExecutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementImports_ProfileId_StatementImportProfiles'
)
BEGIN
    ALTER TABLE [tes].[BankStatementImports]
        ADD CONSTRAINT [FK_tes_BankStatementImports_ProfileId_StatementImportProfiles]
        FOREIGN KEY ([ProfileId]) REFERENCES [tes].[StatementImportProfiles] ([StatementImportProfileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_Checkbooks_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[Checkbooks]
        ADD CONSTRAINT [FK_tes_Checkbooks_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_FundCommitments_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[FundCommitments]
        ADD CONSTRAINT [FK_tes_FundCommitments_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_InterbankingBalanceSnapshots_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[InterbankingBalanceSnapshots]
        ADD CONSTRAINT [FK_tes_InterbankingBalanceSnapshots_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_InterbankingSyncRuns_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[InterbankingSyncRuns]
        ADD CONSTRAINT [FK_tes_InterbankingSyncRuns_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementImports_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[BankStatementImports]
        ADD CONSTRAINT [FK_tes_BankStatementImports_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PaymentCashSessions_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[PaymentCashSessions]
        ADD CONSTRAINT [FK_tes_PaymentCashSessions_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PaymentFiles_OriginTreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[PaymentFiles]
        ADD CONSTRAINT [FK_tes_PaymentFiles_OriginTreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([OriginTreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationRules_AccountIdsId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationRules]
        ADD CONSTRAINT [FK_tes_ReconciliationRules_AccountIdsId_TreasuryAccounts]
        FOREIGN KEY ([AccountIdsId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_Reconciliations_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[Reconciliations]
        ADD CONSTRAINT [FK_tes_Reconciliations_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryAccountSigners_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[TreasuryAccountSigners]
        ADD CONSTRAINT [FK_tes_TreasuryAccountSigners_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PlannedCashItems_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[PlannedCashItems]
        ADD CONSTRAINT [FK_tes_PlannedCashItems_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryMovements_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[TreasuryMovements]
        ADD CONSTRAINT [FK_tes_TreasuryMovements_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CashRemittances_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[CashRemittances]
        ADD CONSTRAINT [FK_tes_CashRemittances_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_OwnChecks_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[OwnChecks]
        ADD CONSTRAINT [FK_tes_OwnChecks_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PayrollPaymentBatches_OriginTreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[PayrollPaymentBatches]
        ADD CONSTRAINT [FK_tes_PayrollPaymentBatches_OriginTreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([OriginTreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ThirdPartyChecks_CustodyAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[ThirdPartyChecks]
        ADD CONSTRAINT [FK_tes_ThirdPartyChecks_CustodyAccountId_TreasuryAccounts]
        FOREIGN KEY ([CustodyAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckEvents_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[CheckEvents]
        ADD CONSTRAINT [FK_tes_CheckEvents_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryCashClosings_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[TreasuryCashClosings]
        ADD CONSTRAINT [FK_tes_TreasuryCashClosings_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankDeposits_SourceAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[BankDeposits]
        ADD CONSTRAINT [FK_tes_BankDeposits_SourceAccountId_TreasuryAccounts]
        FOREIGN KEY ([SourceAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankDeposits_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[BankDeposits]
        ADD CONSTRAINT [FK_tes_BankDeposits_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardSettlements_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[CardSettlements]
        ADD CONSTRAINT [FK_tes_CardSettlements_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_OwnChecks_CheckbookId_Checkbooks'
)
BEGIN
    ALTER TABLE [tes].[OwnChecks]
        ADD CONSTRAINT [FK_tes_OwnChecks_CheckbookId_Checkbooks]
        FOREIGN KEY ([CheckbookId]) REFERENCES [tes].[Checkbooks] ([CheckbookId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementImports_SyncRunId_InterbankingSyncRuns'
)
BEGIN
    ALTER TABLE [tes].[BankStatementImports]
        ADD CONSTRAINT [FK_tes_BankStatementImports_SyncRunId_InterbankingSyncRuns]
        FOREIGN KEY ([SyncRunId]) REFERENCES [tes].[InterbankingSyncRuns] ([InterbankingSyncRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PayrollPaymentBatches_PaymentFileIdsId_PaymentFiles'
)
BEGIN
    ALTER TABLE [tes].[PayrollPaymentBatches]
        ADD CONSTRAINT [FK_tes_PayrollPaymentBatches_PaymentFileIdsId_PaymentFiles]
        FOREIGN KEY ([PaymentFileIdsId]) REFERENCES [tes].[PaymentFiles] ([PaymentFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_RuleId_ReconciliationRules'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_RuleId_ReconciliationRules]
        FOREIGN KEY ([RuleId]) REFERENCES [tes].[ReconciliationRules] ([ReconciliationRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_ReconciliationId_Reconciliations'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_ReconciliationId_Reconciliations]
        FOREIGN KEY ([ReconciliationId]) REFERENCES [tes].[Reconciliations] ([ReconciliationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementLines_SuggestedCategoryId_TreasuryCategories'
)
BEGIN
    ALTER TABLE [tes].[BankStatementLines]
        ADD CONSTRAINT [FK_tes_BankStatementLines_SuggestedCategoryId_TreasuryCategories]
        FOREIGN KEY ([SuggestedCategoryId]) REFERENCES [tes].[TreasuryCategories] ([TreasuryCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_StatementLineIdsId_BankStatementLines'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_StatementLineIdsId_BankStatementLines]
        FOREIGN KEY ([StatementLineIdsId]) REFERENCES [tes].[BankStatementLines] ([BankStatementLineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankDeposits_StatementLineIdsId_BankStatementLines'
)
BEGIN
    ALTER TABLE [tes].[BankDeposits]
        ADD CONSTRAINT [FK_tes_BankDeposits_StatementLineIdsId_BankStatementLines]
        FOREIGN KEY ([StatementLineIdsId]) REFERENCES [tes].[BankStatementLines] ([BankStatementLineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PlannedCashItems_ConceptRefId_TreasuryConcepts'
)
BEGIN
    ALTER TABLE [tes].[PlannedCashItems]
        ADD CONSTRAINT [FK_tes_PlannedCashItems_ConceptRefId_TreasuryConcepts]
        FOREIGN KEY ([ConceptRefId]) REFERENCES [tes].[TreasuryConcepts] ([TreasuryConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CashRemittances_ShortageMovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[CashRemittances]
        ADD CONSTRAINT [FK_tes_CashRemittances_ShortageMovementId_TreasuryMovements]
        FOREIGN KEY ([ShortageMovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_OwnChecks_MovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[OwnChecks]
        ADD CONSTRAINT [FK_tes_OwnChecks_MovementId_TreasuryMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PayrollPaymentBatches_MovementIdsId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[PayrollPaymentBatches]
        ADD CONSTRAINT [FK_tes_PayrollPaymentBatches_MovementIdsId_TreasuryMovements]
        FOREIGN KEY ([MovementIdsId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_DifferenceMovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_DifferenceMovementId_TreasuryMovements]
        FOREIGN KEY ([DifferenceMovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_MovementIdsId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_MovementIdsId_TreasuryMovements]
        FOREIGN KEY ([MovementIdsId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ThirdPartyChecks_TreasuryMovementIdsId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[ThirdPartyChecks]
        ADD CONSTRAINT [FK_tes_ThirdPartyChecks_TreasuryMovementIdsId_TreasuryMovements]
        FOREIGN KEY ([TreasuryMovementIdsId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckEvents_MovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[CheckEvents]
        ADD CONSTRAINT [FK_tes_CheckEvents_MovementId_TreasuryMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryCashClosings_ShortageMovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[TreasuryCashClosings]
        ADD CONSTRAINT [FK_tes_TreasuryCashClosings_ShortageMovementId_TreasuryMovements]
        FOREIGN KEY ([ShortageMovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_WithholdingPresentations_MovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[WithholdingPresentations]
        ADD CONSTRAINT [FK_tes_WithholdingPresentations_MovementId_TreasuryMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardPresentations_MovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[CardPresentations]
        ADD CONSTRAINT [FK_tes_CardPresentations_MovementId_TreasuryMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardSettlements_TreasuryMovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[CardSettlements]
        ADD CONSTRAINT [FK_tes_CardSettlements_TreasuryMovementId_TreasuryMovements]
        FOREIGN KEY ([TreasuryMovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckEvents_CheckId_ThirdPartyChecks'
)
BEGIN
    ALTER TABLE [tes].[CheckEvents]
        ADD CONSTRAINT [FK_tes_CheckEvents_CheckId_ThirdPartyChecks]
        FOREIGN KEY ([CheckId]) REFERENCES [tes].[ThirdPartyChecks] ([ThirdPartyCheckId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankDeposits_OperationId_TreasuryOperations'
)
BEGIN
    ALTER TABLE [tes].[BankDeposits]
        ADD CONSTRAINT [FK_tes_BankDeposits_OperationId_TreasuryOperations]
        FOREIGN KEY ([OperationId]) REFERENCES [tes].[TreasuryOperations] ([TreasuryOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesQuotes_ConditionIdsId_SalesConditions'
)
BEGIN
    ALTER TABLE [ven].[SalesQuotes]
        ADD CONSTRAINT [FK_ven_SalesQuotes_ConditionIdsId_SalesConditions]
        FOREIGN KEY ([ConditionIdsId]) REFERENCES [ven].[SalesConditions] ([SalesConditionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_OperationCharges_FinancingPlanId_SalesFinancingPlans'
)
BEGIN
    ALTER TABLE [ven].[OperationCharges]
        ADD CONSTRAINT [FK_ven_OperationCharges_FinancingPlanId_SalesFinancingPlans]
        FOREIGN KEY ([FinancingPlanId]) REFERENCES [ven].[SalesFinancingPlans] ([SalesFinancingPlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosTerminals_PriceListId_SalesPriceLists'
)
BEGIN
    ALTER TABLE [ven].[PosTerminals]
        ADD CONSTRAINT [FK_ven_PosTerminals_PriceListId_SalesPriceLists]
        FOREIGN KEY ([PriceListId]) REFERENCES [ven].[SalesPriceLists] ([SalesPriceListId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_PriceListId_SalesPriceLists'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders]
        ADD CONSTRAINT [FK_ven_SalesOrders_PriceListId_SalesPriceLists]
        FOREIGN KEY ([PriceListId]) REFERENCES [ven].[SalesPriceLists] ([SalesPriceListId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosTerminals_DefaultSalesRepId_SalesReps'
)
BEGIN
    ALTER TABLE [ven].[PosTerminals]
        ADD CONSTRAINT [FK_ven_PosTerminals_DefaultSalesRepId_SalesReps]
        FOREIGN KEY ([DefaultSalesRepId]) REFERENCES [ven].[SalesReps] ([SalesRepId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesQuotes_SalesRepId_SalesReps'
)
BEGIN
    ALTER TABLE [ven].[SalesQuotes]
        ADD CONSTRAINT [FK_ven_SalesQuotes_SalesRepId_SalesReps]
        FOREIGN KEY ([SalesRepId]) REFERENCES [ven].[SalesReps] ([SalesRepId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_SalesRepId_SalesReps'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders]
        ADD CONSTRAINT [FK_ven_SalesOrders_SalesRepId_SalesReps]
        FOREIGN KEY ([SalesRepId]) REFERENCES [ven].[SalesReps] ([SalesRepId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosSessions_PosTerminalId_PosTerminals'
)
BEGIN
    ALTER TABLE [ven].[PosSessions]
        ADD CONSTRAINT [FK_ven_PosSessions_PosTerminalId_PosTerminals]
        FOREIGN KEY ([PosTerminalId]) REFERENCES [ven].[PosTerminals] ([PosTerminalId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_PosSessionId_PosSessions'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders]
        ADD CONSTRAINT [FK_ven_SalesOrders_PosSessionId_PosSessions]
        FOREIGN KEY ([PosSessionId]) REFERENCES [ven].[PosSessions] ([PosSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesQuoteAcceptances_QuoteId_SalesQuotes'
)
BEGIN
    ALTER TABLE [ven].[SalesQuoteAcceptances]
        ADD CONSTRAINT [FK_ven_SalesQuoteAcceptances_QuoteId_SalesQuotes]
        FOREIGN KEY ([QuoteId]) REFERENCES [ven].[SalesQuotes] ([SalesQuoteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_QuoteId_SalesQuotes'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders]
        ADD CONSTRAINT [FK_ven_SalesOrders_QuoteId_SalesQuotes]
        FOREIGN KEY ([QuoteId]) REFERENCES [ven].[SalesQuotes] ([SalesQuoteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalSteps_ApprovalRequestId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalSteps]
        ADD CONSTRAINT [FK_wfl_ApprovalSteps_ApprovalRequestId_ApprovalRequests]
        FOREIGN KEY ([ApprovalRequestId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalDecisions_ApprovalRequestId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalDecisions]
        ADD CONSTRAINT [FK_wfl_ApprovalDecisions_ApprovalRequestId_ApprovalRequests]
        FOREIGN KEY ([ApprovalRequestId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_TemplateVersions_ApprovalRequestId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [wfl].[TemplateVersions]
        ADD CONSTRAINT [FK_wfl_TemplateVersions_ApprovalRequestId_ApprovalRequests]
        FOREIGN KEY ([ApprovalRequestId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_BulkRunItems_BulkRunId_BulkRuns'
)
BEGIN
    ALTER TABLE [wfl].[BulkRunItems]
        ADD CONSTRAINT [FK_wfl_BulkRunItems_BulkRunId_BulkRuns]
        FOREIGN KEY ([BulkRunId]) REFERENCES [wfl].[BulkRuns] ([BulkRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_BulkRunItems_ReprocessRunId_BulkRuns'
)
BEGIN
    ALTER TABLE [wfl].[BulkRunItems]
        ADD CONSTRAINT [FK_wfl_BulkRunItems_ReprocessRunId_BulkRuns]
        FOREIGN KEY ([ReprocessRunId]) REFERENCES [wfl].[BulkRuns] ([BulkRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_RenderRequests_BulkRunId_BulkRuns'
)
BEGIN
    ALTER TABLE [wfl].[RenderRequests]
        ADD CONSTRAINT [FK_wfl_RenderRequests_BulkRunId_BulkRuns]
        FOREIGN KEY ([BulkRunId]) REFERENCES [wfl].[BulkRuns] ([BulkRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalDecisions_DelegationId_Delegations'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalDecisions]
        ADD CONSTRAINT [FK_wfl_ApprovalDecisions_DelegationId_Delegations]
        FOREIGN KEY ([DelegationId]) REFERENCES [wfl].[Delegations] ([DelegationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_Documents_DocumentTypeId_DocumentTypes'
)
BEGIN
    ALTER TABLE [wfl].[Documents]
        ADD CONSTRAINT [FK_wfl_Documents_DocumentTypeId_DocumentTypes]
        FOREIGN KEY ([DocumentTypeId]) REFERENCES [wfl].[DocumentTypes] ([DocumentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentLinks_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[DocumentLinks]
        ADD CONSTRAINT [FK_wfl_DocumentLinks_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_Dossiers_CoverDocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[Dossiers]
        ADD CONSTRAINT [FK_wfl_Dossiers_CoverDocumentId_Documents]
        FOREIGN KEY ([CoverDocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureRequests_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[SignatureRequests]
        ADD CONSTRAINT [FK_wfl_SignatureRequests_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentVersions_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[DocumentVersions]
        ADD CONSTRAINT [FK_wfl_DocumentVersions_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentAccessLogs_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[DocumentAccessLogs]
        ADD CONSTRAINT [FK_wfl_DocumentAccessLogs_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ShareLinks_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[ShareLinks]
        ADD CONSTRAINT [FK_wfl_ShareLinks_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalDecisions_EvidenceDocumentIdsId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalDecisions]
        ADD CONSTRAINT [FK_wfl_ApprovalDecisions_EvidenceDocumentIdsId_Documents]
        FOREIGN KEY ([EvidenceDocumentIdsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_TaskComments_DocumentIdsId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[TaskComments]
        ADD CONSTRAINT [FK_wfl_TaskComments_DocumentIdsId_Documents]
        FOREIGN KEY ([DocumentIdsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_FormSubmissions_DocumentIdsId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[FormSubmissions]
        ADD CONSTRAINT [FK_wfl_FormSubmissions_DocumentIdsId_Documents]
        FOREIGN KEY ([DocumentIdsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DossierEntries_DossierId_Dossiers'
)
BEGIN
    ALTER TABLE [wfl].[DossierEntries]
        ADD CONSTRAINT [FK_wfl_DossierEntries_DossierId_Dossiers]
        FOREIGN KEY ([DossierId]) REFERENCES [wfl].[Dossiers] ([DossierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DossierTimeline_DossierId_Dossiers'
)
BEGIN
    ALTER TABLE [wfl].[DossierTimeline]
        ADD CONSTRAINT [FK_wfl_DossierTimeline_DossierId_Dossiers]
        FOREIGN KEY ([DossierId]) REFERENCES [wfl].[Dossiers] ([DossierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_NumberingAssignments_NumberingSequenceId_NumberingSequences'
)
BEGIN
    ALTER TABLE [wfl].[NumberingAssignments]
        ADD CONSTRAINT [FK_wfl_NumberingAssignments_NumberingSequenceId_NumberingSequences]
        FOREIGN KEY ([NumberingSequenceId]) REFERENCES [wfl].[NumberingSequences] ([NumberingSequenceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_OperationSteps_OperationId_Operations'
)
BEGIN
    ALTER TABLE [wfl].[OperationSteps]
        ADD CONSTRAINT [FK_wfl_OperationSteps_OperationId_Operations]
        FOREIGN KEY ([OperationId]) REFERENCES [wfl].[Operations] ([OperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureRequests_SignatureProfileId_SignatureProfiles'
)
BEGIN
    ALTER TABLE [wfl].[SignatureRequests]
        ADD CONSTRAINT [FK_wfl_SignatureRequests_SignatureProfileId_SignatureProfiles]
        FOREIGN KEY ([SignatureProfileId]) REFERENCES [wfl].[SignatureProfiles] ([SignatureProfileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentVersions_SignaturesId_SignatureRequests'
)
BEGIN
    ALTER TABLE [wfl].[DocumentVersions]
        ADD CONSTRAINT [FK_wfl_DocumentVersions_SignaturesId_SignatureRequests]
        FOREIGN KEY ([SignaturesId]) REFERENCES [wfl].[SignatureRequests] ([SignatureRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureParticipants_SignatureRequestId_SignatureRequests'
)
BEGIN
    ALTER TABLE [wfl].[SignatureParticipants]
        ADD CONSTRAINT [FK_wfl_SignatureParticipants_SignatureRequestId_SignatureRequests]
        FOREIGN KEY ([SignatureRequestId]) REFERENCES [wfl].[SignatureRequests] ([SignatureRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentAccessLogs_VersionId_DocumentVersions'
)
BEGIN
    ALTER TABLE [wfl].[DocumentAccessLogs]
        ADD CONSTRAINT [FK_wfl_DocumentAccessLogs_VersionId_DocumentVersions]
        FOREIGN KEY ([VersionId]) REFERENCES [wfl].[DocumentVersions] ([DocumentVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ShareLinks_VersionId_DocumentVersions'
)
BEGIN
    ALTER TABLE [wfl].[ShareLinks]
        ADD CONSTRAINT [FK_wfl_ShareLinks_VersionId_DocumentVersions]
        FOREIGN KEY ([VersionId]) REFERENCES [wfl].[DocumentVersions] ([DocumentVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureEvidences_SignatureParticipantId_SignatureParticipants'
)
BEGIN
    ALTER TABLE [wfl].[SignatureEvidences]
        ADD CONSTRAINT [FK_wfl_SignatureEvidences_SignatureParticipantId_SignatureParticipants]
        FOREIGN KEY ([SignatureParticipantId]) REFERENCES [wfl].[SignatureParticipants] ([SignatureParticipantId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SlaTimers_SlaPolicyId_SlaPolicies'
)
BEGIN
    ALTER TABLE [wfl].[SlaTimers]
        ADD CONSTRAINT [FK_wfl_SlaTimers_SlaPolicyId_SlaPolicies]
        FOREIGN KEY ([SlaPolicyId]) REFERENCES [wfl].[SlaPolicies] ([SlaPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalSteps_SlaTimerId_SlaTimers'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalSteps]
        ADD CONSTRAINT [FK_wfl_ApprovalSteps_SlaTimerId_SlaTimers]
        FOREIGN KEY ([SlaTimerId]) REFERENCES [wfl].[SlaTimers] ([SlaTimerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalDecisions_ApprovalStepId_ApprovalSteps'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalDecisions]
        ADD CONSTRAINT [FK_wfl_ApprovalDecisions_ApprovalStepId_ApprovalSteps]
        FOREIGN KEY ([ApprovalStepId]) REFERENCES [wfl].[ApprovalSteps] ([ApprovalStepId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_WorkflowInstanceEvents_WorkflowInstanceId_WorkflowInstances'
)
BEGIN
    ALTER TABLE [wfl].[WorkflowInstanceEvents]
        ADD CONSTRAINT [FK_wfl_WorkflowInstanceEvents_WorkflowInstanceId_WorkflowInstances]
        FOREIGN KEY ([WorkflowInstanceId]) REFERENCES [wfl].[WorkflowInstances] ([WorkflowInstanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_FormSubmissions_WorkflowInstanceId_WorkflowInstances'
)
BEGIN
    ALTER TABLE [wfl].[FormSubmissions]
        ADD CONSTRAINT [FK_wfl_FormSubmissions_WorkflowInstanceId_WorkflowInstances]
        FOREIGN KEY ([WorkflowInstanceId]) REFERENCES [wfl].[WorkflowInstances] ([WorkflowInstanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSnapshotMembers_SnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[AudienceSnapshotMembers]
        ADD CONSTRAINT [FK_com_AudienceSnapshotMembers_SnapshotId_AudienceSnapshots]
        FOREIGN KEY ([SnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Posts_AudienceSnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[Posts] WITH NOCHECK
        ADD CONSTRAINT [FK_com_Posts_AudienceSnapshotId_AudienceSnapshots]
        FOREIGN KEY ([AudienceSnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSegments_LastSnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[AudienceSegments] WITH NOCHECK
        ADD CONSTRAINT [FK_com_AudienceSegments_LastSnapshotId_AudienceSnapshots]
        FOREIGN KEY ([LastSnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Campaigns_AudienceSnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[Campaigns]
        ADD CONSTRAINT [FK_com_Campaigns_AudienceSnapshotId_AudienceSnapshots]
        FOREIGN KEY ([AudienceSnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Newsletters_AudienceSnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[Newsletters]
        ADD CONSTRAINT [FK_com_Newsletters_AudienceSnapshotId_AudienceSnapshots]
        FOREIGN KEY ([AudienceSnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Surveys_AudienceSnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[Surveys]
        ADD CONSTRAINT [FK_com_Surveys_AudienceSnapshotId_AudienceSnapshots]
        FOREIGN KEY ([AudienceSnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentIntents_MandateId_DirectDebitMandates'
)
BEGIN
    ALTER TABLE [cob].[PaymentIntents]
        ADD CONSTRAINT [FK_cob_PaymentIntents_MandateId_DirectDebitMandates]
        FOREIGN KEY ([MandateId]) REFERENCES [cob].[DirectDebitMandates] ([DirectDebitMandateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalRefunds_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[CapitalRefunds]
        ADD CONSTRAINT [FK_ins_CapitalRefunds_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFees_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFees]
        ADD CONSTRAINT [FK_ins_InstitutionalFees_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingAgendaItems_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[MeetingAgendaItems] WITH NOCHECK
        ADD CONSTRAINT [FK_ins_MeetingAgendaItems_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_BodyMandates_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[BodyMandates]
        ADD CONSTRAINT [FK_ins_BodyMandates_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusDistributions_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[SurplusDistributions]
        ADD CONSTRAINT [FK_ins_SurplusDistributions_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalShareValues_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[CapitalShareValues]
        ADD CONSTRAINT [FK_ins_CapitalShareValues_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalTransfers_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[CapitalTransfers]
        ADD CONSTRAINT [FK_ins_CapitalTransfers_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_BenefitRedemptions_BenefitId_Benefits'
)
BEGIN
    ALTER TABLE [com].[BenefitRedemptions]
        ADD CONSTRAINT [FK_com_BenefitRedemptions_BenefitId_Benefits]
        FOREIGN KEY ([BenefitId]) REFERENCES [com].[Benefits] ([BenefitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollPaymentRequests_ExternalImportId_ExternalPayrollImports'
)
BEGIN
    ALTER TABLE [sue].[PayrollPaymentRequests] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_PayrollPaymentRequests_ExternalImportId_ExternalPayrollImports]
        FOREIGN KEY ([ExternalImportId]) REFERENCES [sue].[ExternalPayrollImports] ([ExternalPayrollImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardPresentations_VoucherIdsId_CardVouchers'
)
BEGIN
    ALTER TABLE [tes].[CardPresentations] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_CardPresentations_VoucherIdsId_CardVouchers]
        FOREIGN KEY ([VoucherIdsId]) REFERENCES [tes].[CardVouchers] ([CardVoucherId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardSettlements_VoucherIdsId_CardVouchers'
)
BEGIN
    ALTER TABLE [tes].[CardSettlements] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_CardSettlements_VoucherIdsId_CardVouchers]
        FOREIGN KEY ([VoucherIdsId]) REFERENCES [tes].[CardVouchers] ([CardVoucherId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_RenderRequests_TemplateVersionId_TemplateVersions'
)
BEGIN
    ALTER TABLE [wfl].[RenderRequests]
        ADD CONSTRAINT [FK_wfl_RenderRequests_TemplateVersionId_TemplateVersions]
        FOREIGN KEY ([TemplateVersionId]) REFERENCES [wfl].[TemplateVersions] ([TemplateVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentTemplates_CurrentVersionId_TemplateVersions'
)
BEGIN
    ALTER TABLE [wfl].[DocumentTemplates] WITH NOCHECK
        ADD CONSTRAINT [FK_wfl_DocumentTemplates_CurrentVersionId_TemplateVersions]
        FOREIGN KEY ([CurrentVersionId]) REFERENCES [wfl].[TemplateVersions] ([TemplateVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyCollections_ThirdPartyBillerId_ThirdPartyBillers'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyCollections]
        ADD CONSTRAINT [FK_cob_ThirdPartyCollections_ThirdPartyBillerId_ThirdPartyBillers]
        FOREIGN KEY ([ThirdPartyBillerId]) REFERENCES [cob].[ThirdPartyBillers] ([ThirdPartyBillerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_HandoverId_TreasuryHandovers'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_HandoverId_TreasuryHandovers]
        FOREIGN KEY ([HandoverId]) REFERENCES [cob].[TreasuryHandovers] ([TreasuryHandoverId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashSessions_HandoverId_TreasuryHandovers'
)
BEGIN
    ALTER TABLE [cob].[CashSessions] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CashSessions_HandoverId_TreasuryHandovers]
        FOREIGN KEY ([HandoverId]) REFERENCES [cob].[TreasuryHandovers] ([TreasuryHandoverId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyPublishedDebts_ExportId_AgencyDebtExports'
)
BEGIN
    ALTER TABLE [cob].[AgencyPublishedDebts]
        ADD CONSTRAINT [FK_cob_AgencyPublishedDebts_ExportId_AgencyDebtExports]
        FOREIGN KEY ([ExportId]) REFERENCES [cob].[AgencyDebtExports] ([AgencyDebtExportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitBatches_ExportId_AgencyDebtExports'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitBatches]
        ADD CONSTRAINT [FK_cob_DirectDebitBatches_ExportId_AgencyDebtExports]
        FOREIGN KEY ([ExportId]) REFERENCES [cob].[AgencyDebtExports] ([AgencyDebtExportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractEquipmentAssignments_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[ContractEquipmentAssignments]
        ADD CONSTRAINT [FK_cat_ContractEquipmentAssignments_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BulkContractOperations_ContractIdsId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[BulkContractOperations]
        ADD CONSTRAINT [FK_cat_BulkContractOperations_ContractIdsId_ServiceContracts]
        FOREIGN KEY ([ContractIdsId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContractHistory_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[ServiceContractHistory]
        ADD CONSTRAINT [FK_cat_ServiceContractHistory_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractSpecialConditions_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[ContractSpecialConditions]
        ADD CONSTRAINT [FK_cat_ContractSpecialConditions_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BundleSubscriptions_ContractIdsId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[BundleSubscriptions] WITH NOCHECK
        ADD CONSTRAINT [FK_cat_BundleSubscriptions_ContractIdsId_ServiceContracts]
        FOREIGN KEY ([ContractIdsId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractDeclaredAppliances_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[ContractDeclaredAppliances]
        ADD CONSTRAINT [FK_cat_ContractDeclaredAppliances_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceTechnicalProfiles_LastCommandId_ProvisioningCommands'
)
BEGIN
    ALTER TABLE [tec].[ServiceTechnicalProfiles]
        ADD CONSTRAINT [FK_tec_ServiceTechnicalProfiles_LastCommandId_ProvisioningCommands]
        FOREIGN KEY ([LastCommandId]) REFERENCES [tec].[ProvisioningCommands] ([ProvisioningCommandId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountRoles_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[AccountRoles]
        ADD CONSTRAINT [FK_con_AccountRoles_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerAccounts_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[LedgerAccounts]
        ADD CONSTRAINT [FK_con_LedgerAccounts_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountRubrics_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[AccountRubrics]
        ADD CONSTRAINT [FK_con_AccountRubrics_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ResultTargets_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[ResultTargets]
        ADD CONSTRAINT [FK_con_ResultTargets_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_PostingRules_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[PostingRules]
        ADD CONSTRAINT [FK_con_PostingRules_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_EntryTemplates_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[EntryTemplates]
        ADD CONSTRAINT [FK_con_EntryTemplates_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerProjections_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[LedgerProjections]
        ADD CONSTRAINT [FK_con_LedgerProjections_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_EntityAccountAssignments_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[EntityAccountAssignments]
        ADD CONSTRAINT [FK_con_EntityAccountAssignments_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_SimulationScenarios_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[SimulationScenarios] WITH NOCHECK
        ADD CONSTRAINT [FK_con_SimulationScenarios_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFeeSettlements_FeeId_InstitutionalFees'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFeeSettlements]
        ADD CONSTRAINT [FK_ins_InstitutionalFeeSettlements_FeeId_InstitutionalFees]
        FOREIGN KEY ([FeeId]) REFERENCES [ins].[InstitutionalFees] ([InstitutionalFeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_GatewayTransactionId_GatewayTransactions'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_GatewayTransactionId_GatewayTransactions]
        FOREIGN KEY ([GatewayTransactionId]) REFERENCES [cob].[GatewayTransactions] ([GatewayTransactionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_GatewayTransactionId_GatewayTransactions'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_GatewayTransactionId_GatewayTransactions]
        FOREIGN KEY ([GatewayTransactionId]) REFERENCES [cob].[GatewayTransactions] ([GatewayTransactionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentIntents_TransactionIdsId_GatewayTransactions'
)
BEGIN
    ALTER TABLE [cob].[PaymentIntents] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_PaymentIntents_TransactionIdsId_GatewayTransactions]
        FOREIGN KEY ([TransactionIdsId]) REFERENCES [cob].[GatewayTransactions] ([GatewayTransactionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountRoles_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[AccountRoles]
        ADD CONSTRAINT [FK_con_AccountRoles_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ResultTargets_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[ResultTargets]
        ADD CONSTRAINT [FK_con_ResultTargets_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_PostingRules_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[PostingRules]
        ADD CONSTRAINT [FK_con_PostingRules_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ExternalLedgerMappings_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[ExternalLedgerMappings]
        ADD CONSTRAINT [FK_con_ExternalLedgerMappings_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountMappings_SourceAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[AccountMappings]
        ADD CONSTRAINT [FK_con_AccountMappings_SourceAccountId_LedgerAccounts]
        FOREIGN KEY ([SourceAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerProjections_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[LedgerProjections]
        ADD CONSTRAINT [FK_con_LedgerProjections_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_BudgetLines_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[BudgetLines]
        ADD CONSTRAINT [FK_con_BudgetLines_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_EntityAccountAssignments_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[EntityAccountAssignments]
        ADD CONSTRAINT [FK_con_EntityAccountAssignments_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneLines_PhoneNumberId_PhoneNumbers'
)
BEGIN
    ALTER TABLE [tec].[PhoneLines]
        ADD CONSTRAINT [FK_tec_PhoneLines_PhoneNumberId_PhoneNumbers]
        FOREIGN KEY ([PhoneNumberId]) REFERENCES [tec].[PhoneNumbers] ([PhoneNumberId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberPortings_PhoneNumberId_PhoneNumbers'
)
BEGIN
    ALTER TABLE [tec].[NumberPortings]
        ADD CONSTRAINT [FK_tec_NumberPortings_PhoneNumberId_PhoneNumbers]
        FOREIGN KEY ([PhoneNumberId]) REFERENCES [tec].[PhoneNumbers] ([PhoneNumberId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LandingPageVersions_LandingPageId_LandingPages'
)
BEGIN
    ALTER TABLE [por].[LandingPageVersions] WITH NOCHECK
        ADD CONSTRAINT [FK_por_LandingPageVersions_LandingPageId_LandingPages]
        FOREIGN KEY ([LandingPageId]) REFERENCES [por].[LandingPages] ([LandingPageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FleetVehicles_GpsDeviceId_GpsDevices'
)
BEGIN
    ALTER TABLE [soc].[FleetVehicles] WITH NOCHECK
        ADD CONSTRAINT [FK_soc_FleetVehicles_GpsDeviceId_GpsDevices]
        FOREIGN KEY ([GpsDeviceId]) REFERENCES [soc].[GpsDevices] ([GpsDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditAccess_DeviceId_TrustedDevices'
)
BEGIN
    ALTER TABLE [iam].[AuditAccess]
        ADD CONSTRAINT [FK_iam_AuditAccess_DeviceId_TrustedDevices]
        FOREIGN KEY ([DeviceId]) REFERENCES [iam].[TrustedDevices] ([TrustedDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitMandates_GatewayConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitMandates]
        ADD CONSTRAINT [FK_cob_DirectDebitMandates_GatewayConnectorId_GatewayConnectors]
        FOREIGN KEY ([GatewayConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayWebhookEvents_ConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[GatewayWebhookEvents]
        ADD CONSTRAINT [FK_cob_GatewayWebhookEvents_ConnectorId_GatewayConnectors]
        FOREIGN KEY ([ConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyBillers_SummaryServiceConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyBillers]
        ADD CONSTRAINT [FK_cob_ThirdPartyBillers_SummaryServiceConnectorId_GatewayConnectors]
        FOREIGN KEY ([SummaryServiceConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_ConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_ConnectorId_GatewayConnectors]
        FOREIGN KEY ([ConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentChannels_GatewayConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[PaymentChannels]
        ADD CONSTRAINT [FK_cob_PaymentChannels_GatewayConnectorId_GatewayConnectors]
        FOREIGN KEY ([GatewayConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayTransactions_ConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[GatewayTransactions]
        ADD CONSTRAINT [FK_cob_GatewayTransactions_ConnectorId_GatewayConnectors]
        FOREIGN KEY ([ConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentIntents_GatewayConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[PaymentIntents]
        ADD CONSTRAINT [FK_cob_PaymentIntents_GatewayConnectorId_GatewayConnectors]
        FOREIGN KEY ([GatewayConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_ConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters]
        ADD CONSTRAINT [FK_cob_CashRegisters_ConnectorId_GatewayConnectors]
        FOREIGN KEY ([ConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_StaticQrCodes_GatewayConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[StaticQrCodes] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_StaticQrCodes_GatewayConnectorId_GatewayConnectors]
        FOREIGN KEY ([GatewayConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostCenters_GroupIdsId_CostCenterGroups'
)
BEGIN
    ALTER TABLE [con].[CostCenters] WITH NOCHECK
        ADD CONSTRAINT [FK_con_CostCenters_GroupIdsId_CostCenterGroups]
        FOREIGN KEY ([GroupIdsId]) REFERENCES [con].[CostCenterGroups] ([CostCenterGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_EditPresence_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[EditPresence]
        ADD CONSTRAINT [FK_iam_EditPresence_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditAccess_ActorId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[AuditAccess]
        ADD CONSTRAINT [FK_iam_AuditAccess_ActorId_Memberships]
        FOREIGN KEY ([ActorId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AccessReviews_ReviewerMembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[AccessReviews]
        ADD CONSTRAINT [FK_iam_AccessReviews_ReviewerMembershipId_Memberships]
        FOREIGN KEY ([ReviewerMembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditMessages_TriggeredById_Memberships'
)
BEGIN
    ALTER TABLE [iam].[AuditMessages]
        ADD CONSTRAINT [FK_iam_AuditMessages_TriggeredById_Memberships]
        FOREIGN KEY ([TriggeredById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ApiClients_OwnerMembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[ApiClients]
        ADD CONSTRAINT [FK_iam_ApiClients_OwnerMembershipId_Memberships]
        FOREIGN KEY ([OwnerMembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_SodExceptions_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [iam].[SodExceptions]
        ADD CONSTRAINT [FK_iam_SodExceptions_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_SodExceptions_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[SodExceptions]
        ADD CONSTRAINT [FK_iam_SodExceptions_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_SodExceptions_RequestedById_Memberships'
)
BEGIN
    ALTER TABLE [iam].[SodExceptions]
        ADD CONSTRAINT [FK_iam_SodExceptions_RequestedById_Memberships]
        FOREIGN KEY ([RequestedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ProfileAssignments_GrantedById_Memberships'
)
BEGIN
    ALTER TABLE [iam].[ProfileAssignments]
        ADD CONSTRAINT [FK_iam_ProfileAssignments_GrantedById_Memberships]
        FOREIGN KEY ([GrantedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ProfileAssignments_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[ProfileAssignments]
        ADD CONSTRAINT [FK_iam_ProfileAssignments_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ActionTokens_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[ActionTokens]
        ADD CONSTRAINT [FK_iam_ActionTokens_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_MessageTemplates_CurrentVersionId_MessageTemplateVersions'
)
BEGIN
    ALTER TABLE [com].[MessageTemplates] WITH NOCHECK
        ADD CONSTRAINT [FK_com_MessageTemplates_CurrentVersionId_MessageTemplateVersions]
        FOREIGN KEY ([CurrentVersionId]) REFERENCES [com].[MessageTemplateVersions] ([MessageTemplateVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Resolutions_AgendaItemId_MeetingAgendaItems'
)
BEGIN
    ALTER TABLE [ins].[Resolutions] WITH NOCHECK
        ADD CONSTRAINT [FK_ins_Resolutions_AgendaItemId_MeetingAgendaItems]
        FOREIGN KEY ([AgendaItemId]) REFERENCES [ins].[MeetingAgendaItems] ([MeetingAgendaItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_VotingSessions_AgendaItemId_MeetingAgendaItems'
)
BEGIN
    ALTER TABLE [ins].[VotingSessions] WITH NOCHECK
        ADD CONSTRAINT [FK_ins_VotingSessions_AgendaItemId_MeetingAgendaItems]
        FOREIGN KEY ([AgendaItemId]) REFERENCES [ins].[MeetingAgendaItems] ([MeetingAgendaItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryActs_RightId_BurialRights'
)
BEGIN
    ALTER TABLE [soc].[CemeteryActs]
        ADD CONSTRAINT [FK_soc_CemeteryActs_RightId_BurialRights]
        FOREIGN KEY ([RightId]) REFERENCES [soc].[BurialRights] ([BurialRightId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialUnits_CurrentRightId_BurialRights'
)
BEGIN
    ALTER TABLE [soc].[BurialUnits] WITH NOCHECK
        ADD CONSTRAINT [FK_soc_BurialUnits_CurrentRightId_BurialRights]
        FOREIGN KEY ([CurrentRightId]) REFERENCES [soc].[BurialRights] ([BurialRightId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialRightEvents_RightId_BurialRights'
)
BEGIN
    ALTER TABLE [soc].[BurialRightEvents]
        ADD CONSTRAINT [FK_soc_BurialRightEvents_RightId_BurialRights]
        FOREIGN KEY ([RightId]) REFERENCES [soc].[BurialRights] ([BurialRightId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReceivedWithholdings_PresentationId_WithholdingPresentations'
)
BEGIN
    ALTER TABLE [tes].[ReceivedWithholdings] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_ReceivedWithholdings_PresentationId_WithholdingPresentations]
        FOREIGN KEY ([PresentationId]) REFERENCES [tes].[WithholdingPresentations] ([WithholdingPresentationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_WorkAccidents_LeaveRequestIdsId_LeaveRequests'
)
BEGIN
    ALTER TABLE [sue].[WorkAccidents]
        ADD CONSTRAINT [FK_sue_WorkAccidents_LeaveRequestIdsId_LeaveRequests]
        FOREIGN KEY ([LeaveRequestIdsId]) REFERENCES [sue].[LeaveRequests] ([LeaveRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmploymentStatusPeriods_SourceRefId_LeaveRequests'
)
BEGIN
    ALTER TABLE [sue].[EmploymentStatusPeriods]
        ADD CONSTRAINT [FK_sue_EmploymentStatusPeriods_SourceRefId_LeaveRequests]
        FOREIGN KEY ([SourceRefId]) REFERENCES [sue].[LeaveRequests] ([LeaveRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialOccupancies_EndActId_CemeteryActs'
)
BEGIN
    ALTER TABLE [soc].[BurialOccupancies]
        ADD CONSTRAINT [FK_soc_BurialOccupancies_EndActId_CemeteryActs]
        FOREIGN KEY ([EndActId]) REFERENCES [soc].[CemeteryActs] ([CemeteryActId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialOccupancies_IntermentActId_CemeteryActs'
)
BEGIN
    ALTER TABLE [soc].[BurialOccupancies]
        ADD CONSTRAINT [FK_soc_BurialOccupancies_IntermentActId_CemeteryActs]
        FOREIGN KEY ([IntermentActId]) REFERENCES [soc].[CemeteryActs] ([CemeteryActId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialServiceCases_CemeteryActId_CemeteryActs'
)
BEGIN
    ALTER TABLE [soc].[BurialServiceCases]
        ADD CONSTRAINT [FK_soc_BurialServiceCases_CemeteryActId_CemeteryActs]
        FOREIGN KEY ([CemeteryActId]) REFERENCES [soc].[CemeteryActs] ([CemeteryActId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeExtras_TerminationId_Terminations'
)
BEGIN
    ALTER TABLE [sue].[EmployeeExtras]
        ADD CONSTRAINT [FK_sue_EmployeeExtras_TerminationId_Terminations]
        FOREIGN KEY ([TerminationId]) REFERENCES [sue].[Terminations] ([TerminationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_BomStructures_CurrentVersionId_BomStructureVersions'
)
BEGIN
    ALTER TABLE [stk].[BomStructures] WITH NOCHECK
        ADD CONSTRAINT [FK_stk_BomStructures_CurrentVersionId_BomStructureVersions]
        FOREIGN KEY ([CurrentVersionId]) REFERENCES [stk].[BomStructureVersions] ([BomStructureVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingParticipants_MandateId_BodyMandates'
)
BEGIN
    ALTER TABLE [ins].[MeetingParticipants]
        ADD CONSTRAINT [FK_ins_MeetingParticipants_MandateId_BodyMandates]
        FOREIGN KEY ([MandateId]) REFERENCES [ins].[BodyMandates] ([BodyMandateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFeeSettlements_MandateId_BodyMandates'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFeeSettlements]
        ADD CONSTRAINT [FK_ins_InstitutionalFeeSettlements_MandateId_BodyMandates]
        FOREIGN KEY ([MandateId]) REFERENCES [ins].[BodyMandates] ([BodyMandateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_OperationCharges_InstallmentIdsId_SalesInstallments'
)
BEGIN
    ALTER TABLE [ven].[OperationCharges]
        ADD CONSTRAINT [FK_ven_OperationCharges_InstallmentIdsId_SalesInstallments]
        FOREIGN KEY ([InstallmentIdsId]) REFERENCES [ven].[SalesInstallments] ([SalesInstallmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_InstallmentIdsId_SalesInstallments'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders] WITH NOCHECK
        ADD CONSTRAINT [FK_ven_SalesOrders_InstallmentIdsId_SalesInstallments]
        FOREIGN KEY ([InstallmentIdsId]) REFERENCES [ven].[SalesInstallments] ([SalesInstallmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingAgendaItems_VotingSessionId_VotingSessions'
)
BEGIN
    ALTER TABLE [ins].[MeetingAgendaItems] WITH NOCHECK
        ADD CONSTRAINT [FK_ins_MeetingAgendaItems_VotingSessionId_VotingSessions]
        FOREIGN KEY ([VotingSessionId]) REFERENCES [ins].[VotingSessions] ([VotingSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_VoteTallies_VotingSessionId_VotingSessions'
)
BEGIN
    ALTER TABLE [ins].[VoteTallies]
        ADD CONSTRAINT [FK_ins_VoteTallies_VotingSessionId_VotingSessions]
        FOREIGN KEY ([VotingSessionId]) REFERENCES [ins].[VotingSessions] ([VotingSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_QuoteRequests_SourcingEventId_SourcingEvents'
)
BEGIN
    ALTER TABLE [cmp].[QuoteRequests] WITH NOCHECK
        ADD CONSTRAINT [FK_cmp_QuoteRequests_SourcingEventId_SourcingEvents]
        FOREIGN KEY ([SourcingEventId]) REFERENCES [cmp].[SourcingEvents] ([SourcingEventId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryScales_SalaryCategoryId_SalaryCategories'
)
BEGIN
    ALTER TABLE [sue].[SalaryScales]
        ADD CONSTRAINT [FK_sue_SalaryScales_SalaryCategoryId_SalaryCategories]
        FOREIGN KEY ([SalaryCategoryId]) REFERENCES [sue].[SalaryCategories] ([SalaryCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_SettlementId_AgencySettlements'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_SettlementId_AgencySettlements]
        FOREIGN KEY ([SettlementId]) REFERENCES [cob].[AgencySettlements] ([AgencySettlementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlementLines_SettlementId_AgencySettlements'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlementLines]
        ADD CONSTRAINT [FK_cob_AgencySettlementLines_SettlementId_AgencySettlements]
        FOREIGN KEY ([SettlementId]) REFERENCES [cob].[AgencySettlements] ([AgencySettlementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitMandates_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitMandates]
        ADD CONSTRAINT [FK_cob_DirectDebitMandates_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyDebtExports_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[AgencyDebtExports]
        ADD CONSTRAINT [FK_cob_AgencyDebtExports_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ExternalKeyAliases_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[ExternalKeyAliases]
        ADD CONSTRAINT [FK_cob_ExternalKeyAliases_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayConnectors_SettlementAgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[GatewayConnectors] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_GatewayConnectors_SettlementAgencyId_CollectionAgencies]
        FOREIGN KEY ([SettlementAgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlements_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlements]
        ADD CONSTRAINT [FK_cob_AgencySettlements_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionReconciliations_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[CollectionReconciliations]
        ADD CONSTRAINT [FK_cob_CollectionReconciliations_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyNoveltyFiles_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[AgencyNoveltyFiles]
        ADD CONSTRAINT [FK_cob_AgencyNoveltyFiles_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CashRegisters_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyPublishedDebts_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[AgencyPublishedDebts]
        ADD CONSTRAINT [FK_cob_AgencyPublishedDebts_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitBatches_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitBatches]
        ADD CONSTRAINT [FK_cob_DirectDebitBatches_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashOperations_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[CashOperations]
        ADD CONSTRAINT [FK_cob_CashOperations_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FuelLoads_TripSettlementId_TripSettlements'
)
BEGIN
    ALTER TABLE [soc].[FuelLoads]
        ADD CONSTRAINT [FK_soc_FuelLoads_TripSettlementId_TripSettlements]
        FOREIGN KEY ([TripSettlementId]) REFERENCES [soc].[TripSettlements] ([TripSettlementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunicationEvents_LinkId_TrackedLinks'
)
BEGIN
    ALTER TABLE [com].[CommunicationEvents]
        ADD CONSTRAINT [FK_com_CommunicationEvents_LinkId_TrackedLinks]
        FOREIGN KEY ([LinkId]) REFERENCES [com].[TrackedLinks] ([TrackedLinkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSnapshots_OwnerId_Posts'
)
BEGIN
    ALTER TABLE [com].[AudienceSnapshots] WITH NOCHECK
        ADD CONSTRAINT [FK_com_AudienceSnapshots_OwnerId_Posts]
        FOREIGN KEY ([OwnerId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Benefits_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[Benefits]
        ADD CONSTRAINT [FK_com_Benefits_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_NewsletterRecipients_PostIdsId_Posts'
)
BEGIN
    ALTER TABLE [com].[NewsletterRecipients]
        ADD CONSTRAINT [FK_com_NewsletterRecipients_PostIdsId_Posts]
        FOREIGN KEY ([PostIdsId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostViews_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[PostViews]
        ADD CONSTRAINT [FK_com_PostViews_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ContentReports_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[ContentReports]
        ADD CONSTRAINT [FK_com_ContentReports_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostReactions_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[PostReactions]
        ADD CONSTRAINT [FK_com_PostReactions_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Events_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[Events]
        ADD CONSTRAINT [FK_com_Events_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostDailyStats_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[PostDailyStats]
        ADD CONSTRAINT [FK_com_PostDailyStats_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostUserStates_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[PostUserStates]
        ADD CONSTRAINT [FK_com_PostUserStates_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Newsletters_FeaturedPostId_Posts'
)
BEGIN
    ALTER TABLE [com].[Newsletters]
        ADD CONSTRAINT [FK_com_Newsletters_FeaturedPostId_Posts]
        FOREIGN KEY ([FeaturedPostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryIncreaseBatches_ResultingScaleId_SalaryScales'
)
BEGIN
    ALTER TABLE [sue].[SalaryIncreaseBatches] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_SalaryIncreaseBatches_ResultingScaleId_SalaryScales]
        FOREIGN KEY ([ResultingScaleId]) REFERENCES [sue].[SalaryScales] ([SalaryScaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryIncreaseBatches_SalaryScaleIdsId_SalaryScales'
)
BEGIN
    ALTER TABLE [sue].[SalaryIncreaseBatches]
        ADD CONSTRAINT [FK_sue_SalaryIncreaseBatches_SalaryScaleIdsId_SalaryScales]
        FOREIGN KEY ([SalaryScaleIdsId]) REFERENCES [sue].[SalaryScales] ([SalaryScaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSnapshots_SegmentId_AudienceSegments'
)
BEGIN
    ALTER TABLE [com].[AudienceSnapshots] WITH NOCHECK
        ADD CONSTRAINT [FK_com_AudienceSnapshots_SegmentId_AudienceSegments]
        FOREIGN KEY ([SegmentId]) REFERENCES [com].[AudienceSegments] ([AudienceSegmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Posts_AudienceSegmentId_AudienceSegments'
)
BEGIN
    ALTER TABLE [com].[Posts] WITH NOCHECK
        ADD CONSTRAINT [FK_com_Posts_AudienceSegmentId_AudienceSegments]
        FOREIGN KEY ([AudienceSegmentId]) REFERENCES [com].[AudienceSegments] ([AudienceSegmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_InvoiceMessages_SegmentId_AudienceSegments'
)
BEGIN
    ALTER TABLE [com].[InvoiceMessages]
        ADD CONSTRAINT [FK_com_InvoiceMessages_SegmentId_AudienceSegments]
        FOREIGN KEY ([SegmentId]) REFERENCES [com].[AudienceSegments] ([AudienceSegmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkTypes_PrintTemplateId_WorkOrderPrintTemplates'
)
BEGIN
    ALTER TABLE [tec].[WorkTypes] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_WorkTypes_PrintTemplateId_WorkOrderPrintTemplates]
        FOREIGN KEY ([PrintTemplateId]) REFERENCES [tec].[WorkOrderPrintTemplates] ([WorkOrderPrintTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigStagingRecords_IssuesId_MigrationIssues'
)
BEGIN
    ALTER TABLE [mig].[MigStagingRecords] WITH NOCHECK
        ADD CONSTRAINT [FK_mig_MigStagingRecords_IssuesId_MigrationIssues]
        FOREIGN KEY ([IssuesId]) REFERENCES [mig].[MigrationIssues] ([MigrationIssueId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Payslips_IncomeTaxCalculationId_IncomeTaxCalculations'
)
BEGIN
    ALTER TABLE [sue].[Payslips] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_Payslips_IncomeTaxCalculationId_IncomeTaxCalculations]
        FOREIGN KEY ([IncomeTaxCalculationId]) REFERENCES [sue].[IncomeTaxCalculations] ([IncomeTaxCalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_DefaultWorkTypeId_WorkTypes'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_DefaultWorkTypeId_WorkTypes]
        FOREIGN KEY ([DefaultWorkTypeId]) REFERENCES [tec].[WorkTypes] ([WorkTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_TrackedLinks_CampaignId_Campaigns'
)
BEGIN
    ALTER TABLE [com].[TrackedLinks]
        ADD CONSTRAINT [FK_com_TrackedLinks_CampaignId_Campaigns]
        FOREIGN KEY ([CampaignId]) REFERENCES [com].[Campaigns] ([CampaignId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_InvoiceMessages_CampaignId_Campaigns'
)
BEGIN
    ALTER TABLE [com].[InvoiceMessages]
        ADD CONSTRAINT [FK_com_InvoiceMessages_CampaignId_Campaigns]
        FOREIGN KEY ([CampaignId]) REFERENCES [com].[Campaigns] ([CampaignId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusAllocations_DistributionId_SurplusDistributions'
)
BEGIN
    ALTER TABLE [ins].[SurplusAllocations]
        ADD CONSTRAINT [FK_ins_SurplusAllocations_DistributionId_SurplusDistributions]
        FOREIGN KEY ([DistributionId]) REFERENCES [ins].[SurplusDistributions] ([SurplusDistributionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_BomStructureVersions_BomStructureId_BomStructures'
)
BEGIN
    ALTER TABLE [stk].[BomStructureVersions] WITH NOCHECK
        ADD CONSTRAINT [FK_stk_BomStructureVersions_BomStructureId_BomStructures]
        FOREIGN KEY ([BomStructureId]) REFERENCES [stk].[BomStructures] ([BomStructureId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ProductDivisions_BomStructureId_BomStructures'
)
BEGIN
    ALTER TABLE [stk].[ProductDivisions]
        ADD CONSTRAINT [FK_stk_ProductDivisions_BomStructureId_BomStructures]
        FOREIGN KEY ([BomStructureId]) REFERENCES [stk].[BomStructures] ([BomStructureId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_AdministrativeInquiries_ResultingActionIdsId_DisciplinaryActions'
)
BEGIN
    ALTER TABLE [sue].[AdministrativeInquiries] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_AdministrativeInquiries_ResultingActionIdsId_DisciplinaryActions]
        FOREIGN KEY ([ResultingActionIdsId]) REFERENCES [sue].[DisciplinaryActions] ([DisciplinaryActionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Works_GroupId_WorkGroups'
)
BEGIN
    ALTER TABLE [tec].[Works] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_Works_GroupId_WorkGroups]
        FOREIGN KEY ([GroupId]) REFERENCES [tec].[WorkGroups] ([WorkGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_FiscalAuthorizations_DocumentRefId_GatewayDocuments'
)
BEGIN
    ALTER TABLE [fis].[FiscalAuthorizations] WITH NOCHECK
        ADD CONSTRAINT [FK_fis_FiscalAuthorizations_DocumentRefId_GatewayDocuments]
        FOREIGN KEY ([DocumentRefId]) REFERENCES [fis].[GatewayDocuments] ([GatewayDocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_DisciplinaryActions_InquiryId_AdministrativeInquiries'
)
BEGIN
    ALTER TABLE [sue].[DisciplinaryActions] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_DisciplinaryActions_InquiryId_AdministrativeInquiries]
        FOREIGN KEY ([InquiryId]) REFERENCES [sue].[AdministrativeInquiries] ([AdministrativeInquiryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_Identities_MfaId_AuthFactors'
)
BEGIN
    ALTER TABLE [iam].[Identities] WITH NOCHECK
        ADD CONSTRAINT [FK_iam_Identities_MfaId_AuthFactors]
        FOREIGN KEY ([MfaId]) REFERENCES [iam].[AuthFactors] ([AuthFactorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_WithholdingPresentations_ReceivedWithholdingIdsId_ReceivedWithholdings'
)
BEGIN
    ALTER TABLE [tes].[WithholdingPresentations] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_WithholdingPresentations_ReceivedWithholdingIdsId_ReceivedWithholdings]
        FOREIGN KEY ([ReceivedWithholdingIdsId]) REFERENCES [tes].[ReceivedWithholdings] ([ReceivedWithholdingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayWebhookEvents_RelatedIntentId_PaymentIntents'
)
BEGIN
    ALTER TABLE [cob].[GatewayWebhookEvents]
        ADD CONSTRAINT [FK_cob_GatewayWebhookEvents_RelatedIntentId_PaymentIntents]
        FOREIGN KEY ([RelatedIntentId]) REFERENCES [cob].[PaymentIntents] ([PaymentIntentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_IntentId_PaymentIntents'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_IntentId_PaymentIntents]
        FOREIGN KEY ([IntentId]) REFERENCES [cob].[PaymentIntents] ([PaymentIntentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayTransactions_IntentId_PaymentIntents'
)
BEGIN
    ALTER TABLE [cob].[GatewayTransactions] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_GatewayTransactions_IntentId_PaymentIntents]
        FOREIGN KEY ([IntentId]) REFERENCES [cob].[PaymentIntents] ([PaymentIntentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LaborAgreements_SeniorityScaleId_SeniorityScales'
)
BEGIN
    ALTER TABLE [sue].[LaborAgreements] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_LaborAgreements_SeniorityScaleId_SeniorityScales]
        FOREIGN KEY ([SeniorityScaleId]) REFERENCES [sue].[SeniorityScales] ([SeniorityScaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_TemplateVersions_DocumentTemplateId_DocumentTemplates'
)
BEGIN
    ALTER TABLE [wfl].[TemplateVersions] WITH NOCHECK
        ADD CONSTRAINT [FK_wfl_TemplateVersions_DocumentTemplateId_DocumentTemplates]
        FOREIGN KEY ([DocumentTemplateId]) REFERENCES [wfl].[DocumentTemplates] ([DocumentTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerProjections_MappingId_AccountMappings'
)
BEGIN
    ALTER TABLE [con].[LedgerProjections]
        ADD CONSTRAINT [FK_con_LedgerProjections_MappingId_AccountMappings]
        FOREIGN KEY ([MappingId]) REFERENCES [con].[AccountMappings] ([AccountMappingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_FormVersions_FormDefinitionId_FormDefinitions'
)
BEGIN
    ALTER TABLE [wfl].[FormVersions] WITH NOCHECK
        ADD CONSTRAINT [FK_wfl_FormVersions_FormDefinitionId_FormDefinitions]
        FOREIGN KEY ([FormDefinitionId]) REFERENCES [wfl].[FormDefinitions] ([FormDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PlatformNoticeReads_NoticeId_PlatformNotices'
)
BEGIN
    ALTER TABLE [com].[PlatformNoticeReads]
        ADD CONSTRAINT [FK_com_PlatformNoticeReads_NoticeId_PlatformNotices]
        FOREIGN KEY ([NoticeId]) REFERENCES [com].[PlatformNotices] ([PlatformNoticeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrders_ConformityId_ServiceConformities'
)
BEGIN
    ALTER TABLE [tec].[WorkOrders] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_WorkOrders_ConformityId_ServiceConformities]
        FOREIGN KEY ([ConformityId]) REFERENCES [tec].[ServiceConformities] ([ServiceConformityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleMaintenances_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[VehicleMaintenances]
        ADD CONSTRAINT [FK_soc_VehicleMaintenances_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleUsages_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[VehicleUsages]
        ADD CONSTRAINT [FK_soc_VehicleUsages_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleDocuments_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[VehicleDocuments]
        ADD CONSTRAINT [FK_soc_VehicleDocuments_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_GpsDevices_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[GpsDevices] WITH NOCHECK
        ADD CONSTRAINT [FK_soc_GpsDevices_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TripSettlements_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[TripSettlements]
        ADD CONSTRAINT [FK_soc_TripSettlements_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FuelLoads_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[FuelLoads]
        ADD CONSTRAINT [FK_soc_FuelLoads_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectorSettlements_RoundIdsId_CollectionRounds'
)
BEGIN
    ALTER TABLE [cob].[CollectorSettlements]
        ADD CONSTRAINT [FK_cob_CollectorSettlements_RoundIdsId_CollectionRounds]
        FOREIGN KEY ([RoundIdsId]) REFERENCES [cob].[CollectionRounds] ([CollectionRoundId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SourcingEvents_QuoteRequestId_QuoteRequests'
)
BEGIN
    ALTER TABLE [cmp].[SourcingEvents] WITH NOCHECK
        ADD CONSTRAINT [FK_cmp_SourcingEvents_QuoteRequestId_QuoteRequests]
        FOREIGN KEY ([QuoteRequestId]) REFERENCES [cmp].[QuoteRequests] ([QuoteRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryScales_IncreaseBatchId_SalaryIncreaseBatches'
)
BEGIN
    ALTER TABLE [sue].[SalaryScales] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_SalaryScales_IncreaseBatchId_SalaryIncreaseBatches]
        FOREIGN KEY ([IncreaseBatchId]) REFERENCES [sue].[SalaryIncreaseBatches] ([SalaryIncreaseBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardVouchers_PresentationId_CardPresentations'
)
BEGIN
    ALTER TABLE [tes].[CardVouchers] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_CardVouchers_PresentationId_CardPresentations]
        FOREIGN KEY ([PresentationId]) REFERENCES [tes].[CardPresentations] ([CardPresentationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ApiCredentials_ApiClientId_ApiClients'
)
BEGIN
    ALTER TABLE [iam].[ApiCredentials]
        ADD CONSTRAINT [FK_iam_ApiCredentials_ApiClientId_ApiClients]
        FOREIGN KEY ([ApiClientId]) REFERENCES [iam].[ApiClients] ([ApiClientId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LeaveRequests_NoveltyIdsId_Novelties'
)
BEGIN
    ALTER TABLE [sue].[LeaveRequests]
        ADD CONSTRAINT [FK_sue_LeaveRequests_NoveltyIdsId_Novelties]
        FOREIGN KEY ([NoveltyIdsId]) REFERENCES [sue].[Novelties] ([NoveltyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_IncomeTaxCalculations_OverrideNoveltyId_Novelties'
)
BEGIN
    ALTER TABLE [sue].[IncomeTaxCalculations] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_IncomeTaxCalculations_OverrideNoveltyId_Novelties]
        FOREIGN KEY ([OverrideNoveltyId]) REFERENCES [sue].[Novelties] ([NoveltyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExtraTasks_NoveltyIdsId_Novelties'
)
BEGIN
    ALTER TABLE [sue].[ExtraTasks]
        ADD CONSTRAINT [FK_sue_ExtraTasks_NoveltyIdsId_Novelties]
        FOREIGN KEY ([NoveltyIdsId]) REFERENCES [sue].[Novelties] ([NoveltyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CallRecords_AttributedLineId_PhoneLines'
)
BEGIN
    ALTER TABLE [tec].[CallRecords]
        ADD CONSTRAINT [FK_tec_CallRecords_AttributedLineId_PhoneLines]
        FOREIGN KEY ([AttributedLineId]) REFERENCES [tec].[PhoneLines] ([PhoneLineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_EventRegistrations_EventId_Events'
)
BEGIN
    ALTER TABLE [com].[EventRegistrations]
        ADD CONSTRAINT [FK_com_EventRegistrations_EventId_Events]
        FOREIGN KEY ([EventId]) REFERENCES [com].[Events] ([EventId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExternalPayrollImports_PaymentRequestId_PayrollPaymentRequests'
)
BEGIN
    ALTER TABLE [sue].[ExternalPayrollImports] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_ExternalPayrollImports_PaymentRequestId_PayrollPaymentRequests]
        FOREIGN KEY ([PaymentRequestId]) REFERENCES [sue].[PayrollPaymentRequests] ([PayrollPaymentRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollRuns_PaymentRequestId_PayrollPaymentRequests'
)
BEGIN
    ALTER TABLE [sue].[PayrollRuns] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_PayrollRuns_PaymentRequestId_PayrollPaymentRequests]
        FOREIGN KEY ([PaymentRequestId]) REFERENCES [sue].[PayrollPaymentRequests] ([PayrollPaymentRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStripPositions_StripId_PhoneStrips'
)
BEGIN
    ALTER TABLE [tec].[PhoneStripPositions]
        ADD CONSTRAINT [FK_tec_PhoneStripPositions_StripId_PhoneStrips]
        FOREIGN KEY ([StripId]) REFERENCES [tec].[PhoneStrips] ([PhoneStripId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LandingPages_DraftVersionId_LandingPageVersions'
)
BEGIN
    ALTER TABLE [por].[LandingPages] WITH NOCHECK
        ADD CONSTRAINT [FK_por_LandingPages_DraftVersionId_LandingPageVersions]
        FOREIGN KEY ([DraftVersionId]) REFERENCES [por].[LandingPageVersions] ([LandingPageVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LandingPages_PublishedVersionId_LandingPageVersions'
)
BEGIN
    ALTER TABLE [por].[LandingPages]
        ADD CONSTRAINT [FK_por_LandingPages_PublishedVersionId_LandingPageVersions]
        FOREIGN KEY ([PublishedVersionId]) REFERENCES [por].[LandingPageVersions] ([LandingPageVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryCategories_LaborAgreementId_LaborAgreements'
)
BEGIN
    ALTER TABLE [sue].[SalaryCategories]
        ADD CONSTRAINT [FK_sue_SalaryCategories_LaborAgreementId_LaborAgreements]
        FOREIGN KEY ([LaborAgreementId]) REFERENCES [sue].[LaborAgreements] ([LaborAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryScales_LaborAgreementId_LaborAgreements'
)
BEGIN
    ALTER TABLE [sue].[SalaryScales]
        ADD CONSTRAINT [FK_sue_SalaryScales_LaborAgreementId_LaborAgreements]
        FOREIGN KEY ([LaborAgreementId]) REFERENCES [sue].[LaborAgreements] ([LaborAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SeniorityScales_LaborAgreementId_LaborAgreements'
)
BEGIN
    ALTER TABLE [sue].[SeniorityScales] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_SeniorityScales_LaborAgreementId_LaborAgreements]
        FOREIGN KEY ([LaborAgreementId]) REFERENCES [sue].[LaborAgreements] ([LaborAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalEntries_TemplateId_EntryTemplates'
)
BEGIN
    ALTER TABLE [con].[JournalEntries]
        ADD CONSTRAINT [FK_con_JournalEntries_TemplateId_EntryTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [con].[EntryTemplates] ([EntryTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CallRecords_CdrImportId_CdrImports'
)
BEGIN
    ALTER TABLE [tec].[CallRecords]
        ADD CONSTRAINT [FK_tec_CallRecords_CdrImportId_CdrImports]
        FOREIGN KEY ([CdrImportId]) REFERENCES [tec].[CdrImports] ([CdrImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_RefundCases_ReconciliationId_CollectionReconciliations'
)
BEGIN
    ALTER TABLE [cob].[RefundCases]
        ADD CONSTRAINT [FK_cob_RefundCases_ReconciliationId_CollectionReconciliations]
        FOREIGN KEY ([ReconciliationId]) REFERENCES [cob].[CollectionReconciliations] ([CollectionReconciliationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementSimulations_ConvertedAgreementId_Agreements'
)
BEGIN
    ALTER TABLE [mor].[AgreementSimulations]
        ADD CONSTRAINT [FK_mor_AgreementSimulations_ConvertedAgreementId_Agreements]
        FOREIGN KEY ([ConvertedAgreementId]) REFERENCES [mor].[Agreements] ([AgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementObligations_AgreementId_Agreements'
)
BEGIN
    ALTER TABLE [mor].[AgreementObligations]
        ADD CONSTRAINT [FK_mor_AgreementObligations_AgreementId_Agreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [mor].[Agreements] ([AgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementInstallments_AgreementId_Agreements'
)
BEGIN
    ALTER TABLE [mor].[AgreementInstallments]
        ADD CONSTRAINT [FK_mor_AgreementInstallments_AgreementId_Agreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [mor].[Agreements] ([AgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_Guarantees_AgreementId_Agreements'
)
BEGIN
    ALTER TABLE [mor].[Guarantees] WITH NOCHECK
        ADD CONSTRAINT [FK_mor_Guarantees_AgreementId_Agreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [mor].[Agreements] ([AgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceConformities_SignatureEvidenceId_FieldEvidence'
)
BEGIN
    ALTER TABLE [tec].[ServiceConformities] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_ServiceConformities_SignatureEvidenceId_FieldEvidence]
        FOREIGN KEY ([SignatureEvidenceId]) REFERENCES [tec].[FieldEvidence] ([FieldEvidenceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_Agreements_GuaranteeIdsId_Guarantees'
)
BEGIN
    ALTER TABLE [mor].[Agreements] WITH NOCHECK
        ADD CONSTRAINT [FK_mor_Agreements_GuaranteeIdsId_Guarantees]
        FOREIGN KEY ([GuaranteeIdsId]) REFERENCES [mor].[Guarantees] ([GuaranteeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_NewsletterRecipients_NewsletterId_Newsletters'
)
BEGIN
    ALTER TABLE [com].[NewsletterRecipients]
        ADD CONSTRAINT [FK_com_NewsletterRecipients_NewsletterId_Newsletters]
        FOREIGN KEY ([NewsletterId]) REFERENCES [com].[Newsletters] ([NewsletterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ExternalLedgerTransfers_EntryIdsId_JournalEntries'
)
BEGIN
    ALTER TABLE [con].[ExternalLedgerTransfers]
        ADD CONSTRAINT [FK_con_ExternalLedgerTransfers_EntryIdsId_JournalEntries]
        FOREIGN KEY ([EntryIdsId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostDistributionRuns_ReclassificationEntryId_JournalEntries'
)
BEGIN
    ALTER TABLE [con].[CostDistributionRuns]
        ADD CONSTRAINT [FK_con_CostDistributionRuns_ReclassificationEntryId_JournalEntries]
        FOREIGN KEY ([ReclassificationEntryId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_InflationAdjustmentRuns_EntryId_JournalEntries'
)
BEGIN
    ALTER TABLE [con].[InflationAdjustmentRuns]
        ADD CONSTRAINT [FK_con_InflationAdjustmentRuns_EntryId_JournalEntries]
        FOREIGN KEY ([EntryId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalLines_EntryId_JournalEntries'
)
BEGIN
    ALTER TABLE [con].[JournalLines]
        ADD CONSTRAINT [FK_con_JournalLines_EntryId_JournalEntries]
        FOREIGN KEY ([EntryId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentCoupons_StatementId_AccountStatements'
)
BEGIN
    ALTER TABLE [cob].[PaymentCoupons] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_PaymentCoupons_StatementId_AccountStatements]
        FOREIGN KEY ([StatementId]) REFERENCES [cob].[AccountStatements] ([AccountStatementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionAgencies_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [cob].[CollectionAgencies] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CollectionAgencies_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_StaticQrCodes_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [cob].[StaticQrCodes] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_StaticQrCodes_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashOperations_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [cob].[CashOperations]
        ADD CONSTRAINT [FK_cob_CashOperations_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashSessions_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [cob].[CashSessions]
        ADD CONSTRAINT [FK_cob_CashSessions_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Collectors_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [cob].[Collectors] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_Collectors_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CdrImports_ExchangeId_PhoneExchanges'
)
BEGIN
    ALTER TABLE [tec].[CdrImports]
        ADD CONSTRAINT [FK_tec_CdrImports_ExchangeId_PhoneExchanges]
        FOREIGN KEY ([ExchangeId]) REFERENCES [tec].[PhoneExchanges] ([PhoneExchangeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Dslams_ExchangeId_PhoneExchanges'
)
BEGIN
    ALTER TABLE [tec].[Dslams]
        ADD CONSTRAINT [FK_tec_Dslams_ExchangeId_PhoneExchanges]
        FOREIGN KEY ([ExchangeId]) REFERENCES [tec].[PhoneExchanges] ([PhoneExchangeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneFrames_ExchangeId_PhoneExchanges'
)
BEGIN
    ALTER TABLE [tec].[PhoneFrames]
        ADD CONSTRAINT [FK_tec_PhoneFrames_ExchangeId_PhoneExchanges]
        FOREIGN KEY ([ExchangeId]) REFERENCES [tec].[PhoneExchanges] ([PhoneExchangeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhonePorts_OwnerId_PhoneExchanges'
)
BEGIN
    ALTER TABLE [tec].[PhonePorts]
        ADD CONSTRAINT [FK_tec_PhonePorts_OwnerId_PhoneExchanges]
        FOREIGN KEY ([OwnerId]) REFERENCES [tec].[PhoneExchanges] ([PhoneExchangeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WaterSamples_SamplingPointId_WaterSamplingPoints'
)
BEGIN
    ALTER TABLE [tec].[WaterSamples]
        ADD CONSTRAINT [FK_tec_WaterSamples_SamplingPointId_WaterSamplingPoints]
        FOREIGN KEY ([SamplingPointId]) REFERENCES [tec].[WaterSamplingPoints] ([WaterSamplingPointId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesInstallments_OriginId_SalesOrders'
)
BEGIN
    ALTER TABLE [ven].[SalesInstallments] WITH NOCHECK
        ADD CONSTRAINT [FK_ven_SalesInstallments_OriginId_SalesOrders]
        FOREIGN KEY ([OriginId]) REFERENCES [ven].[SalesOrders] ([SalesOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesReturns_SalesOrderId_SalesOrders'
)
BEGIN
    ALTER TABLE [ven].[SalesReturns]
        ADD CONSTRAINT [FK_ven_SalesReturns_SalesOrderId_SalesOrders]
        FOREIGN KEY ([SalesOrderId]) REFERENCES [ven].[SalesOrders] ([SalesOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesDeliveries_SalesOrderId_SalesOrders'
)
BEGIN
    ALTER TABLE [ven].[SalesDeliveries]
        ADD CONSTRAINT [FK_ven_SalesDeliveries_SalesOrderId_SalesOrders]
        FOREIGN KEY ([SalesOrderId]) REFERENCES [ven].[SalesOrders] ([SalesOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_GatewayDocuments_FiscalAuthorizationId_FiscalAuthorizations'
)
BEGIN
    ALTER TABLE [fis].[GatewayDocuments] WITH NOCHECK
        ADD CONSTRAINT [FK_fis_GatewayDocuments_FiscalAuthorizationId_FiscalAuthorizations]
        FOREIGN KEY ([FiscalAuthorizationId]) REFERENCES [fis].[FiscalAuthorizations] ([FiscalAuthorizationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaSubmissions_AuthorizationIdsId_FiscalAuthorizations'
)
BEGIN
    ALTER TABLE [fis].[ArcaSubmissions]
        ADD CONSTRAINT [FK_fis_ArcaSubmissions_AuthorizationIdsId_FiscalAuthorizations]
        FOREIGN KEY ([AuthorizationIdsId]) REFERENCES [fis].[FiscalAuthorizations] ([FiscalAuthorizationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_MaintenancePlans_LastGeneratedWorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[MaintenancePlans]
        ADD CONSTRAINT [FK_tec_MaintenancePlans_LastGeneratedWorkOrderId_WorkOrders]
        FOREIGN KEY ([LastGeneratedWorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvisioningCommands_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[ProvisioningCommands]
        ADD CONSTRAINT [FK_tec_ProvisioningCommands_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_SyncConflicts_FollowUpWorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[SyncConflicts]
        ADD CONSTRAINT [FK_tec_SyncConflicts_FollowUpWorkOrderId_WorkOrders]
        FOREIGN KEY ([FollowUpWorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_SyncConflicts_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[SyncConflicts]
        ADD CONSTRAINT [FK_tec_SyncConflicts_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneNumbers_ReservedByWorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[PhoneNumbers]
        ADD CONSTRAINT [FK_tec_PhoneNumbers_ReservedByWorkOrderId_WorkOrders]
        FOREIGN KEY ([ReservedByWorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_DamageAssessments_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[DamageAssessments]
        ADD CONSTRAINT [FK_tec_DamageAssessments_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WaterSamples_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[WaterSamples]
        ADD CONSTRAINT [FK_tec_WaterSamples_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceNetworkConnections_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[ServiceNetworkConnections]
        ADD CONSTRAINT [FK_tec_ServiceNetworkConnections_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneLines_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[PhoneLines]
        ADD CONSTRAINT [FK_tec_PhoneLines_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldEvidence_EntityId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[FieldEvidence] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_FieldEvidence_EntityId_WorkOrders]
        FOREIGN KEY ([EntityId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberPortings_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[NumberPortings]
        ADD CONSTRAINT [FK_tec_NumberPortings_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_MaintenancePlans_OperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[MaintenancePlans]
        ADD CONSTRAINT [FK_tec_MaintenancePlans_OperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([OperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_IncidentCategories_DefaultOperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[IncidentCategories]
        ADD CONSTRAINT [FK_tec_IncidentCategories_DefaultOperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([DefaultOperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderPrintTemplates_OperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderPrintTemplates] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_WorkOrderPrintTemplates_OperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([OperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ChainedOrderRules_OperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[ChainedOrderRules]
        ADD CONSTRAINT [FK_tec_ChainedOrderRules_OperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([OperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ChainedOrderRules_SourceOperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[ChainedOrderRules]
        ADD CONSTRAINT [FK_tec_ChainedOrderRules_SourceOperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([SourceOperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ChainedOrderRules_TargetOperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[ChainedOrderRules]
        ADD CONSTRAINT [FK_tec_ChainedOrderRules_TargetOperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([TargetOperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FeasibilityRequests_OperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[FeasibilityRequests]
        ADD CONSTRAINT [FK_tec_FeasibilityRequests_OperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([OperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_MaintenancePlans_NetworkElementIdsId_NetworkElements'
)
BEGIN
    ALTER TABLE [tec].[MaintenancePlans]
        ADD CONSTRAINT [FK_tec_MaintenancePlans_NetworkElementIdsId_NetworkElements]
        FOREIGN KEY ([NetworkElementIdsId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceNetworkConnections_NetworkElementId_NetworkElements'
)
BEGIN
    ALTER TABLE [tec].[ServiceNetworkConnections]
        ADD CONSTRAINT [FK_tec_ServiceNetworkConnections_NetworkElementId_NetworkElements]
        FOREIGN KEY ([NetworkElementId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WaterSamplingPoints_NetworkElementId_NetworkElements'
)
BEGIN
    ALTER TABLE [tec].[WaterSamplingPoints]
        ADD CONSTRAINT [FK_tec_WaterSamplingPoints_NetworkElementId_NetworkElements]
        FOREIGN KEY ([NetworkElementId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneBoxes_NetworkElementId_NetworkElements'
)
BEGIN
    ALTER TABLE [tec].[PhoneBoxes]
        ADD CONSTRAINT [FK_tec_PhoneBoxes_NetworkElementId_NetworkElements]
        FOREIGN KEY ([NetworkElementId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkDevices_NetworkElementId_NetworkElements'
)
BEGIN
    ALTER TABLE [tec].[NetworkDevices] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_NetworkDevices_NetworkElementId_NetworkElements]
        FOREIGN KEY ([NetworkElementId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhonePorts_DslamId_Dslams'
)
BEGIN
    ALTER TABLE [tec].[PhonePorts]
        ADD CONSTRAINT [FK_tec_PhonePorts_DslamId_Dslams]
        FOREIGN KEY ([DslamId]) REFERENCES [tec].[Dslams] ([DslamId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialRights_UnitId_BurialUnits'
)
BEGIN
    ALTER TABLE [soc].[BurialRights] WITH NOCHECK
        ADD CONSTRAINT [FK_soc_BurialRights_UnitId_BurialUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[BurialUnits] ([BurialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryActs_TargetUnitId_BurialUnits'
)
BEGIN
    ALTER TABLE [soc].[CemeteryActs]
        ADD CONSTRAINT [FK_soc_CemeteryActs_TargetUnitId_BurialUnits]
        FOREIGN KEY ([TargetUnitId]) REFERENCES [soc].[BurialUnits] ([BurialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryActs_UnitId_BurialUnits'
)
BEGIN
    ALTER TABLE [soc].[CemeteryActs]
        ADD CONSTRAINT [FK_soc_CemeteryActs_UnitId_BurialUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[BurialUnits] ([BurialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialOccupancies_UnitId_BurialUnits'
)
BEGIN
    ALTER TABLE [soc].[BurialOccupancies]
        ADD CONSTRAINT [FK_soc_BurialOccupancies_UnitId_BurialUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[BurialUnits] ([BurialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_DirectDebitBatchId_DirectDebitBatches'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_DirectDebitBatchId_DirectDebitBatches]
        FOREIGN KEY ([DirectDebitBatchId]) REFERENCES [cob].[DirectDebitBatches] ([DirectDebitBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerAccounts_AllowedCostCenterIdsId_CostCenters'
)
BEGIN
    ALTER TABLE [con].[LedgerAccounts]
        ADD CONSTRAINT [FK_con_LedgerAccounts_AllowedCostCenterIdsId_CostCenters]
        FOREIGN KEY ([AllowedCostCenterIdsId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostCenterGroups_CostCenterIdsId_CostCenters'
)
BEGIN
    ALTER TABLE [con].[CostCenterGroups] WITH NOCHECK
        ADD CONSTRAINT [FK_con_CostCenterGroups_CostCenterIdsId_CostCenters]
        FOREIGN KEY ([CostCenterIdsId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_BudgetLines_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [con].[BudgetLines]
        ADD CONSTRAINT [FK_con_BudgetLines_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_StaticQrCodeId_StaticQrCodes'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CashRegisters_StaticQrCodeId_StaticQrCodes]
        FOREIGN KEY ([StaticQrCodeId]) REFERENCES [cob].[StaticQrCodes] ([StaticQrCodeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneExchanges_NetworkDeviceId_NetworkDevices'
)
BEGIN
    ALTER TABLE [tec].[PhoneExchanges]
        ADD CONSTRAINT [FK_tec_PhoneExchanges_NetworkDeviceId_NetworkDevices]
        FOREIGN KEY ([NetworkDeviceId]) REFERENCES [tec].[NetworkDevices] ([NetworkDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkElements_NetworkDeviceId_NetworkDevices'
)
BEGIN
    ALTER TABLE [tec].[NetworkElements] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_NetworkElements_NetworkDeviceId_NetworkDevices]
        FOREIGN KEY ([NetworkDeviceId]) REFERENCES [tec].[NetworkDevices] ([NetworkDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Dslams_NetworkDeviceId_NetworkDevices'
)
BEGIN
    ALTER TABLE [tec].[Dslams]
        ADD CONSTRAINT [FK_tec_Dslams_NetworkDeviceId_NetworkDevices]
        FOREIGN KEY ([NetworkDeviceId]) REFERENCES [tec].[NetworkDevices] ([NetworkDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_CashOperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_CashOperationId_CashOperations]
        FOREIGN KEY ([CashOperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyDebtExports_OperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[AgencyDebtExports]
        ADD CONSTRAINT [FK_cob_AgencyDebtExports_OperationId_CashOperations]
        FOREIGN KEY ([OperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayTransactions_CashOperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[GatewayTransactions]
        ADD CONSTRAINT [FK_cob_GatewayTransactions_CashOperationId_CashOperations]
        FOREIGN KEY ([CashOperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlements_CashOperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlements]
        ADD CONSTRAINT [FK_cob_AgencySettlements_CashOperationId_CashOperations]
        FOREIGN KEY ([CashOperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyCollections_CashOperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyCollections]
        ADD CONSTRAINT [FK_cob_ThirdPartyCollections_CashOperationId_CashOperations]
        FOREIGN KEY ([CashOperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Receipts_CashOperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[Receipts] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_Receipts_CashOperationId_CashOperations]
        FOREIGN KEY ([CashOperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardVouchers_SettlementId_CardSettlements'
)
BEGIN
    ALTER TABLE [tes].[CardVouchers] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_CardVouchers_SettlementId_CardSettlements]
        FOREIGN KEY ([SettlementId]) REFERENCES [tes].[CardSettlements] ([CardSettlementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_ReceiptId_Receipts'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_ReceiptId_Receipts]
        FOREIGN KEY ([ReceiptId]) REFERENCES [cob].[Receipts] ([ReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlementLines_ReceiptId_Receipts'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlementLines]
        ADD CONSTRAINT [FK_cob_AgencySettlementLines_ReceiptId_Receipts]
        FOREIGN KEY ([ReceiptId]) REFERENCES [cob].[Receipts] ([ReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyCollections_ReceiptId_Receipts'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyCollections]
        ADD CONSTRAINT [FK_cob_ThirdPartyCollections_ReceiptId_Receipts]
        FOREIGN KEY ([ReceiptId]) REFERENCES [cob].[Receipts] ([ReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashOperations_ReceiptIdsId_Receipts'
)
BEGIN
    ALTER TABLE [cob].[CashOperations] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CashOperations_ReceiptIdsId_Receipts]
        FOREIGN KEY ([ReceiptIdsId]) REFERENCES [cob].[Receipts] ([ReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ChartOfAccounts_ScenarioId_SimulationScenarios'
)
BEGIN
    ALTER TABLE [con].[ChartOfAccounts] WITH NOCHECK
        ADD CONSTRAINT [FK_con_ChartOfAccounts_ScenarioId_SimulationScenarios]
        FOREIGN KEY ([ScenarioId]) REFERENCES [con].[SimulationScenarios] ([SimulationScenarioId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostDistributionRuns_ScenarioId_SimulationScenarios'
)
BEGIN
    ALTER TABLE [con].[CostDistributionRuns]
        ADD CONSTRAINT [FK_con_CostDistributionRuns_ScenarioId_SimulationScenarios]
        FOREIGN KEY ([ScenarioId]) REFERENCES [con].[SimulationScenarios] ([SimulationScenarioId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerProjections_SourceLineId_JournalLines'
)
BEGIN
    ALTER TABLE [con].[LedgerProjections]
        ADD CONSTRAINT [FK_con_LedgerProjections_SourceLineId_JournalLines]
        FOREIGN KEY ([SourceLineId]) REFERENCES [con].[JournalLines] ([JournalLineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyResponses_InvitationId_SurveyInvitations'
)
BEGIN
    ALTER TABLE [com].[SurveyResponses]
        ADD CONSTRAINT [FK_com_SurveyResponses_InvitationId_SurveyInvitations]
        FOREIGN KEY ([InvitationId]) REFERENCES [com].[SurveyInvitations] ([SurveyInvitationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PlatformNotices_SurveyId_Surveys'
)
BEGIN
    ALTER TABLE [com].[PlatformNotices]
        ADD CONSTRAINT [FK_com_PlatformNotices_SurveyId_Surveys]
        FOREIGN KEY ([SurveyId]) REFERENCES [com].[Surveys] ([SurveyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyResponses_SurveyId_Surveys'
)
BEGIN
    ALTER TABLE [com].[SurveyResponses]
        ADD CONSTRAINT [FK_com_SurveyResponses_SurveyId_Surveys]
        FOREIGN KEY ([SurveyId]) REFERENCES [com].[Surveys] ([SurveyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyInvitations_SurveyId_Surveys'
)
BEGIN
    ALTER TABLE [com].[SurveyInvitations]
        ADD CONSTRAINT [FK_com_SurveyInvitations_SurveyId_Surveys]
        FOREIGN KEY ([SurveyId]) REFERENCES [com].[Surveys] ([SurveyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationIssues_StagingRecordId_MigStagingRecords'
)
BEGIN
    ALTER TABLE [mig].[MigrationIssues] WITH NOCHECK
        ADD CONSTRAINT [FK_mig_MigrationIssues_StagingRecordId_MigStagingRecords]
        FOREIGN KEY ([StagingRecordId]) REFERENCES [mig].[MigStagingRecords] ([MigStagingRecordId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_BundleSubscriptionId_BundleSubscriptions'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts] WITH NOCHECK
        ADD CONSTRAINT [FK_cat_ServiceContracts_BundleSubscriptionId_BundleSubscriptions]
        FOREIGN KEY ([BundleSubscriptionId]) REFERENCES [cat].[BundleSubscriptions] ([BundleSubscriptionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_IncomeTaxCalculations_PayslipId_Payslips'
)
BEGIN
    ALTER TABLE [sue].[IncomeTaxCalculations] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_IncomeTaxCalculations_PayslipId_Payslips]
        FOREIGN KEY ([PayslipId]) REFERENCES [sue].[Payslips] ([PayslipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Novelties_SettledPayslipId_Payslips'
)
BEGIN
    ALTER TABLE [sue].[Novelties] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_Novelties_SettledPayslipId_Payslips]
        FOREIGN KEY ([SettledPayslipId]) REFERENCES [sue].[Payslips] ([PayslipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayslipNotifications_PayslipId_Payslips'
)
BEGIN
    ALTER TABLE [sue].[PayslipNotifications]
        ADD CONSTRAINT [FK_sue_PayslipNotifications_PayslipId_Payslips]
        FOREIGN KEY ([PayslipId]) REFERENCES [sue].[Payslips] ([PayslipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Terminations_FinalPayrollRunId_PayrollRuns'
)
BEGIN
    ALTER TABLE [sue].[Terminations]
        ADD CONSTRAINT [FK_sue_Terminations_FinalPayrollRunId_PayrollRuns]
        FOREIGN KEY ([FinalPayrollRunId]) REFERENCES [sue].[PayrollRuns] ([PayrollRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollPaymentRequests_PayrollRunId_PayrollRuns'
)
BEGIN
    ALTER TABLE [sue].[PayrollPaymentRequests] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_PayrollPaymentRequests_PayrollRunId_PayrollRuns]
        FOREIGN KEY ([PayrollRunId]) REFERENCES [sue].[PayrollRuns] ([PayrollRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_StatutoryFilings_PayrollRunIdsId_PayrollRuns'
)
BEGIN
    ALTER TABLE [sue].[StatutoryFilings]
        ADD CONSTRAINT [FK_sue_StatutoryFilings_PayrollRunIdsId_PayrollRuns]
        FOREIGN KEY ([PayrollRunIdsId]) REFERENCES [sue].[PayrollRuns] ([PayrollRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_TreasuryHandovers_CashSessionIdsId_CashSessions'
)
BEGIN
    ALTER TABLE [cob].[TreasuryHandovers] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_TreasuryHandovers_CashSessionIdsId_CashSessions]
        FOREIGN KEY ([CashSessionIdsId]) REFERENCES [cob].[CashSessions] ([CashSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_TreasuryHandovers_SessionIdsId_CashSessions'
)
BEGIN
    ALTER TABLE [cob].[TreasuryHandovers]
        ADD CONSTRAINT [FK_cob_TreasuryHandovers_SessionIdsId_CashSessions]
        FOREIGN KEY ([SessionIdsId]) REFERENCES [cob].[CashSessions] ([CashSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectorSettlements_CashSessionId_CashSessions'
)
BEGIN
    ALTER TABLE [cob].[CollectorSettlements]
        ADD CONSTRAINT [FK_cob_CollectorSettlements_CashSessionId_CashSessions]
        FOREIGN KEY ([CashSessionId]) REFERENCES [cob].[CashSessions] ([CashSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashOperations_CashSessionId_CashSessions'
)
BEGIN
    ALTER TABLE [cob].[CashOperations]
        ADD CONSTRAINT [FK_cob_CashOperations_CashSessionId_CashSessions]
        FOREIGN KEY ([CashSessionId]) REFERENCES [cob].[CashSessions] ([CashSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AccountStatements_PaymentCouponId_PaymentCoupons'
)
BEGIN
    ALTER TABLE [cob].[AccountStatements] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_AccountStatements_PaymentCouponId_PaymentCoupons]
        FOREIGN KEY ([PaymentCouponId]) REFERENCES [cob].[PaymentCoupons] ([PaymentCouponId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionRounds_CollectorId_Collectors'
)
BEGIN
    ALTER TABLE [cob].[CollectionRounds]
        ADD CONSTRAINT [FK_cob_CollectionRounds_CollectorId_Collectors]
        FOREIGN KEY ([CollectorId]) REFERENCES [cob].[Collectors] ([CollectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectorSettlements_CollectorId_Collectors'
)
BEGIN
    ALTER TABLE [cob].[CollectorSettlements]
        ADD CONSTRAINT [FK_cob_CollectorSettlements_CollectorId_Collectors]
        FOREIGN KEY ([CollectorId]) REFERENCES [cob].[Collectors] ([CollectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_CollectorId_Collectors'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CashRegisters_CollectorId_Collectors]
        FOREIGN KEY ([CollectorId]) REFERENCES [cob].[Collectors] ([CollectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneBoxes_FrameId_PhoneFrames'
)
BEGIN
    ALTER TABLE [tec].[PhoneBoxes]
        ADD CONSTRAINT [FK_tec_PhoneBoxes_FrameId_PhoneFrames]
        FOREIGN KEY ([FrameId]) REFERENCES [tec].[PhoneFrames] ([PhoneFrameId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneFrameGroups_FrameId_PhoneFrames'
)
BEGIN
    ALTER TABLE [tec].[PhoneFrameGroups]
        ADD CONSTRAINT [FK_tec_PhoneFrameGroups_FrameId_PhoneFrames]
        FOREIGN KEY ([FrameId]) REFERENCES [tec].[PhoneFrames] ([PhoneFrameId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStripPositions_DslamPortId_PhonePorts'
)
BEGIN
    ALTER TABLE [tec].[PhoneStripPositions]
        ADD CONSTRAINT [FK_tec_PhoneStripPositions_DslamPortId_PhonePorts]
        FOREIGN KEY ([DslamPortId]) REFERENCES [tec].[PhonePorts] ([PhonePortId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStripPositions_ExchangePortId_PhonePorts'
)
BEGIN
    ALTER TABLE [tec].[PhoneStripPositions]
        ADD CONSTRAINT [FK_tec_PhoneStripPositions_ExchangePortId_PhonePorts]
        FOREIGN KEY ([ExchangePortId]) REFERENCES [tec].[PhonePorts] ([PhonePortId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberPortings_PortId_PhonePorts'
)
BEGIN
    ALTER TABLE [tec].[NumberPortings]
        ADD CONSTRAINT [FK_tec_NumberPortings_PortId_PhonePorts]
        FOREIGN KEY ([PortId]) REFERENCES [tec].[PhonePorts] ([PhonePortId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_FormDefinitions_FormDefinitionId_FormVersions'
)
BEGIN
    ALTER TABLE [wfl].[FormDefinitions] WITH NOCHECK
        ADD CONSTRAINT [FK_wfl_FormDefinitions_FormDefinitionId_FormVersions]
        FOREIGN KEY ([FormDefinitionId]) REFERENCES [wfl].[FormVersions] ([FormVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_FormSubmissions_FormVersionId_FormVersions'
)
BEGIN
    ALTER TABLE [wfl].[FormSubmissions]
        ADD CONSTRAINT [FK_wfl_FormSubmissions_FormVersionId_FormVersions]
        FOREIGN KEY ([FormVersionId]) REFERENCES [wfl].[FormVersions] ([FormVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkBeneficiaries_WorkId_Works'
)
BEGIN
    ALTER TABLE [tec].[WorkBeneficiaries]
        ADD CONSTRAINT [FK_tec_WorkBeneficiaries_WorkId_Works]
        FOREIGN KEY ([WorkId]) REFERENCES [tec].[Works] ([WorkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkGroups_WorkId_Works'
)
BEGIN
    ALTER TABLE [tec].[WorkGroups] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_WorkGroups_WorkId_Works]
        FOREIGN KEY ([WorkId]) REFERENCES [tec].[Works] ([WorkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_FederatedLinks_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[FederatedLinks]
        ADD CONSTRAINT [FK_iam_FederatedLinks_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_TrustedDevices_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[TrustedDevices]
        ADD CONSTRAINT [FK_iam_TrustedDevices_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditAccess_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[AuditAccess]
        ADD CONSTRAINT [FK_iam_AuditAccess_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_Memberships_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[Memberships]
        ADD CONSTRAINT [FK_iam_Memberships_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_OtpChallenges_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[OtpChallenges]
        ADD CONSTRAINT [FK_iam_OtpChallenges_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuthFactors_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[AuthFactors] WITH NOCHECK
        ADD CONSTRAINT [FK_iam_AuthFactors_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuthTransactions_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[AuthTransactions]
        ADD CONSTRAINT [FK_iam_AuthTransactions_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_SecurityAlerts_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[SecurityAlerts]
        ADD CONSTRAINT [FK_iam_SecurityAlerts_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TechnicalNotes_EntityId_FeasibilityRequests'
)
BEGIN
    ALTER TABLE [tec].[TechnicalNotes]
        ADD CONSTRAINT [FK_tec_TechnicalNotes_EntityId_FeasibilityRequests]
        FOREIGN KEY ([EntityId]) REFERENCES [tec].[FeasibilityRequests] ([FeasibilityRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStrips_FrameGroupId_PhoneFrameGroups'
)
BEGIN
    ALTER TABLE [tec].[PhoneStrips]
        ADD CONSTRAINT [FK_tec_PhoneStrips_FrameGroupId_PhoneFrameGroups]
        FOREIGN KEY ([FrameGroupId]) REFERENCES [tec].[PhoneFrameGroups] ([PhoneFrameGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStrips_OwnerId_PhoneFrameGroups'
)
BEGIN
    ALTER TABLE [tec].[PhoneStrips]
        ADD CONSTRAINT [FK_tec_PhoneStrips_OwnerId_PhoneFrameGroups]
        FOREIGN KEY ([OwnerId]) REFERENCES [tec].[PhoneFrameGroups] ([PhoneFrameGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_MessageTemplateVersions_TemplateId_MessageTemplates'
)
BEGIN
    ALTER TABLE [com].[MessageTemplateVersions] WITH NOCHECK
        ADD CONSTRAINT [FK_com_MessageTemplateVersions_TemplateId_MessageTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [com].[MessageTemplates] ([MessageTemplateId]);
END;
GO

