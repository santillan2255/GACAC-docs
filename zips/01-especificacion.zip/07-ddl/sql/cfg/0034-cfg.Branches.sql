-- cfg.Branches — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Branches', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Branches] (
        [BrancheId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [LocalityId] UNIQUEIDENTIFIER NOT NULL,
        [AddressJson] NVARCHAR(MAX) NOT NULL,
        [UsesJson] NVARCHAR(MAX) NOT NULL,
        [IsHeadquarters] BIT NOT NULL,
        [OpeningHoursJson] NVARCHAR(MAX) NULL,
        [CalendarCode] NVARCHAR(512) NULL,
        [ContactJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegalEntityHistoryJson] NVARCHAR(MAX) NULL,
        [Legacy] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Branches_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Branches_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Branches] PRIMARY KEY ([BrancheId]),
        CONSTRAINT [FK_cfg_Branches_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_Branches_Tenant] ON [cfg].[Branches] ([TenantId]);
END;
GO
