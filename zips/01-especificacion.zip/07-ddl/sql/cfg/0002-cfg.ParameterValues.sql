-- cfg.ParameterValues — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.ParameterValues', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[ParameterValues] (
        [ParameterValueId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Key] NVARCHAR(512) NOT NULL,
        [ScopeJson] NVARCHAR(MAX) NOT NULL,
        [Value] NVARCHAR(MAX) NOT NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [ValidTo] DATETIME2(7) NULL,
        [RecordedAt] DATETIME2(7) NOT NULL,
        [SupersededAt] DATETIME2(7) NULL,
        [ConfigVersionId] UNIQUEIDENTIFIER NOT NULL,
        [Origin] VARCHAR(64) NOT NULL,
        [Reason] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_ParameterValues_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_ParameterValues_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_ParameterValues] PRIMARY KEY ([ParameterValueId]),
        CONSTRAINT [FK_cfg_ParameterValues_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_ParameterValues_Tenant] ON [cfg].[ParameterValues] ([TenantId]);
END;
GO
