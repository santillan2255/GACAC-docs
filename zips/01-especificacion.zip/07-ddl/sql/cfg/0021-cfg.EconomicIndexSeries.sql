-- cfg.EconomicIndexSeries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.EconomicIndexSeries', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[EconomicIndexSeries] (
        [EconomicIndexSeryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [NameLabelKey] NVARCHAR(512) NULL,
        [Kind] VARCHAR(64) NULL,
        [Frequency] VARCHAR(64) NULL,
        [Unit] VARCHAR(64) NULL,
        [CurrencyCode] NVARCHAR(512) NULL,
        [RateSide] VARCHAR(64) NULL,
        [Source] NVARCHAR(512) NULL,
        [Adoptable] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_EconomicIndexSeries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_EconomicIndexSeries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_EconomicIndexSeries] PRIMARY KEY ([EconomicIndexSeryId]),
        CONSTRAINT [FK_cfg_EconomicIndexSeries_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_EconomicIndexSeries_Tenant] ON [cfg].[EconomicIndexSeries] ([TenantId]);
END;
GO
