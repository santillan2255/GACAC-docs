-- cfg.Provinces — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Provinces', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Provinces] (
        [ProvinceId] UNIQUEIDENTIFIER NOT NULL,
        [CountryIso2] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [IsoCode] NVARCHAR(512) NULL,
        [ExternalCodes] VARCHAR(64) NULL,
        [Centroid] NVARCHAR(512) NULL,
        [CountryId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Provinces_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Provinces_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Provinces] PRIMARY KEY ([ProvinceId])
    );
END;
GO
