-- cfg.Localities — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Localities', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Localities] (
        [LocalityId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ProvinceCode] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [DepartmentCode] NVARCHAR(512) NULL,
        [MunicipalityCode] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Kind] VARCHAR(64) NULL,
        [PostalCodesJson] NVARCHAR(MAX) NULL,
        [ExternalCodes] VARCHAR(64) NULL,
        [Centroid] NVARCHAR(512) NULL,
        [Source] NVARCHAR(512) NULL,
        [TenantAttributesJson] NVARCHAR(MAX) NULL,
        [IsTenantOwned] BIT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [DepartmentId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Localities_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Localities_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Localities] PRIMARY KEY ([LocalityId]),
        CONSTRAINT [FK_cfg_Localities_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_Localities_Tenant] ON [cfg].[Localities] ([TenantId]);
END;
GO
