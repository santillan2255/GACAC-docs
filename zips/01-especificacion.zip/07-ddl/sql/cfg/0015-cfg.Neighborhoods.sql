-- cfg.Neighborhoods — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Neighborhoods', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Neighborhoods] (
        [NeighborhoodId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LocalityCode] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Polygon] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LocalityId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Neighborhoods_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Neighborhoods_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Neighborhoods] PRIMARY KEY ([NeighborhoodId]),
        CONSTRAINT [FK_cfg_Neighborhoods_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_Neighborhoods_Tenant] ON [cfg].[Neighborhoods] ([TenantId]);
END;
GO
