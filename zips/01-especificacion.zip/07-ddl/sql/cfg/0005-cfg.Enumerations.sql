-- cfg.Enumerations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Enumerations', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Enumerations] (
        [EnumerationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [OwnerModule] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [System] NVARCHAR(512) NULL,
        [Extensible] NVARCHAR(512) NULL,
        [Tenant] NVARCHAR(512) NULL,
        [Platform] NVARCHAR(512) NULL,
        [LabelKey] NVARCHAR(512) NULL,
        [ItemAttributes] NVARCHAR(512) NULL,
        [Hierarchical] NVARCHAR(512) NULL,
        [Legacy] NVARCHAR(512) NULL,
        [{ table | confCtrl }] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Enumerations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Enumerations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Enumerations] PRIMARY KEY ([EnumerationId]),
        CONSTRAINT [FK_cfg_Enumerations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_Enumerations_Tenant] ON [cfg].[Enumerations] ([TenantId]);
END;
GO
