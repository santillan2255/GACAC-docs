-- cfg.ContributionBaseLimits — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.ContributionBaseLimits', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[ContributionBaseLimits] (
        [ContributionBaseLimitId] UNIQUEIDENTIFIER NOT NULL,
        [Period] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_ContributionBaseLimits_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_ContributionBaseLimits_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_ContributionBaseLimits] PRIMARY KEY ([ContributionBaseLimitId])
    );
END;
GO
