-- cfg.ContributionRates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.ContributionRates', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[ContributionRates] (
        [ContributionRateId] UNIQUEIDENTIFIER NOT NULL,
        [Subsystem] NVARCHAR(512) NOT NULL,
        [Regime] NVARCHAR(512) NOT NULL,
        [EmployerType] NVARCHAR(512) NOT NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_ContributionRates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_ContributionRates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_ContributionRates] PRIMARY KEY ([ContributionRateId])
    );
END;
GO
