-- cfg.IdentityDocumentTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.IdentityDocumentTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[IdentityDocumentTypes] (
        [IdentityDocumentTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LabelKey] NVARCHAR(512) NULL,
        [ArcaCode] NVARCHAR(512) NULL,
        [InaesCode] NVARCHAR(512) NULL,
        [EnargasCode] NVARCHAR(512) NULL,
        [SenCode] NVARCHAR(512) NULL,
        [Validation] NVARCHAR(512) NULL,
        [AppliesTo] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_IdentityDocumentTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_IdentityDocumentTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_IdentityDocumentTypes] PRIMARY KEY ([IdentityDocumentTypeId]),
        CONSTRAINT [FK_cfg_IdentityDocumentTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_IdentityDocumentTypes_Tenant] ON [cfg].[IdentityDocumentTypes] ([TenantId]);
END;
GO
