-- cfg.Zones — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Zones', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Zones] (
        [ZoneId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Kind] VARCHAR(64) NULL,
        [LocalityCodesJson] NVARCHAR(MAX) NULL,
        [Polygon] NVARCHAR(512) NULL,
        [BranchId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Geometry] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Zones_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Zones_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Zones] PRIMARY KEY ([ZoneId]),
        CONSTRAINT [FK_cfg_Zones_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_Zones_Tenant] ON [cfg].[Zones] ([TenantId]);
END;
GO
