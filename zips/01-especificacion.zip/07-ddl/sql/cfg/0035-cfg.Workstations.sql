-- cfg.Workstations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Workstations', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Workstations] (
        [WorkstationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [BranchId] NVARCHAR(512) NULL,
        [Branches] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [Counter] NVARCHAR(512) NULL,
        [Cashier] NVARCHAR(512) NULL,
        [Office] NVARCHAR(512) NULL,
        [Kiosk] NVARCHAR(512) NULL,
        [Field] NVARCHAR(512) NULL,
        [LocalAgentId] NVARCHAR(512) NULL,
        [Devices] NVARCHAR(512) NULL,
        [{ kind] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Inactive] NVARCHAR(512) NULL,
        [Legacy] NVARCHAR(512) NULL,
        [EQUIPOS] NVARCHAR(512) NULL,
        [{ tenantId, code }] NVARCHAR(512) NULL,
        [{ tenantId, branchId }] NVARCHAR(512) NULL,
        [DevicesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Workstations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Workstations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Workstations] PRIMARY KEY ([WorkstationId]),
        CONSTRAINT [FK_cfg_Workstations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_Workstations_Tenant] ON [cfg].[Workstations] ([TenantId]);
END;
GO
