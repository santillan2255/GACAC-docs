-- cfg.Currencies — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Currencies', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Currencies] (
        [CurrencyId] UNIQUEIDENTIFIER NOT NULL,
        [IsoCode] NVARCHAR(512) NOT NULL,
        [ArcaCode] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Symbol] NVARCHAR(512) NULL,
        [DecimalsAtributosDeTenantDivisible] NVARCHAR(512) NULL,
        [Rounding] NVARCHAR(512) NULL,
        [PerceptionPercent] NVARCHAR(512) NULL,
        [AllowChange] NVARCHAR(512) NULL,
        [AllowedForCollection] NVARCHAR(512) NULL,
        [IsSystem] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Currencies_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Currencies_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Currencies] PRIMARY KEY ([CurrencyId])
    );
END;
GO
