-- cfg.ParameterDefinitions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.ParameterDefinitions', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[ParameterDefinitions] (
        [ParameterDefinitionId] UNIQUEIDENTIFIER NOT NULL,
        [Key] NVARCHAR(512) NOT NULL,
        [Module] NVARCHAR(512) NOT NULL,
        [Group] NVARCHAR(512) NOT NULL,
        [Type] VARCHAR(64) NOT NULL,
        [ItemType] VARCHAR(64) NOT NULL,
        [JsonSchemaRef] NVARCHAR(512) NOT NULL,
        [EnumCode] NVARCHAR(512) NOT NULL,
        [ReferenceJson] NVARCHAR(MAX) NOT NULL,
        [Unit] NVARCHAR(512) NULL,
        [ValidationJson] NVARCHAR(MAX) NULL,
        [CrossValidator] NVARCHAR(512) NULL,
        [AllowedScopes] VARCHAR(64) NOT NULL,
        [DefaultValue] NVARCHAR(MAX) NOT NULL,
        [ChangeClass] VARCHAR(64) NOT NULL,
        [EffectiveMode] VARCHAR(64) NOT NULL,
        [PeriodRef] NVARCHAR(512) NOT NULL,
        [DependenciesJson] NVARCHAR(MAX) NULL,
        [Sensitive] BIT NOT NULL,
        [Visibility] VARCHAR(64) NOT NULL,
        [Channels] VARCHAR(64) NOT NULL,
        [LicenseCapability] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ReplacedBy] NVARCHAR(512) NULL,
        [PrmId] NVARCHAR(512) NOT NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_ParameterDefinitions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_ParameterDefinitions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_ParameterDefinitions] PRIMARY KEY ([ParameterDefinitionId])
    );
END;
GO
