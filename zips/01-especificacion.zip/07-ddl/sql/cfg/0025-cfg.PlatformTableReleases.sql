-- cfg.PlatformTableReleases — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.PlatformTableReleases', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[PlatformTableReleases] (
        [PlatformTableReleasId] UNIQUEIDENTIFIER NOT NULL,
        [TableCode] NVARCHAR(512) NULL,
        [SeriesId] NVARCHAR(512) NULL,
        [SeriesCode] NVARCHAR(512) NULL,
        [ReleaseNumber] NVARCHAR(512) NULL,
        [Summary] NVARCHAR(512) NULL,
        [Items] NVARCHAR(512) NULL,
        [SourceRef] NVARCHAR(512) NULL,
        [EffectiveAt] DATETIME2(7) NULL,
        [AffectsCalculation] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [Published] NVARCHAR(512) NULL,
        [Superseded] NVARCHAR(512) NULL,
        [PublishedBy] NVARCHAR(512) NULL,
        [PublishedAt] DATETIME2(7) NULL,
        [ItemsJson] NVARCHAR(MAX) NULL,
        [PublishedById] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_PlatformTableReleases_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_PlatformTableReleases_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_PlatformTableReleases] PRIMARY KEY ([PlatformTableReleasId])
    );
END;
GO
