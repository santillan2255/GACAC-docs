-- cfg.LegalEntities — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.LegalEntities', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[LegalEntities] (
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegalName] NVARCHAR(512) NOT NULL,
        [TradeName] NVARCHAR(512) NULL,
        [LegalForm] VARCHAR(64) NOT NULL,
        [InaesRegistration] NVARCHAR(512) NULL,
        [Fiscal] NVARCHAR(MAX) NOT NULL,
        [AddressJson] NVARCHAR(MAX) NOT NULL,
        [ContactJson] NVARCHAR(MAX) NULL,
        [BrandingVariantKey] NVARCHAR(512) NULL,
        [IsDefault] BIT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ChangeHistoryJson] NVARCHAR(MAX) NULL,
        [Employer] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_LegalEntities_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_LegalEntities_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_LegalEntities] PRIMARY KEY ([LegalEntityId]),
        CONSTRAINT [FK_cfg_LegalEntities_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_LegalEntities_Tenant] ON [cfg].[LegalEntities] ([TenantId]);
END;
GO
