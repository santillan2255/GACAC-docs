-- cfg.IncomeTaxScales — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.IncomeTaxScales', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[IncomeTaxScales] (
        [IncomeTaxScaleId] UNIQUEIDENTIFIER NOT NULL,
        [Type] VARCHAR(64) NOT NULL,
        [Year] NVARCHAR(512) NOT NULL,
        [Month] NVARCHAR(512) NOT NULL,
        [From] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_IncomeTaxScales_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_IncomeTaxScales_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_IncomeTaxScales] PRIMARY KEY ([IncomeTaxScaleId])
    );
END;
GO
