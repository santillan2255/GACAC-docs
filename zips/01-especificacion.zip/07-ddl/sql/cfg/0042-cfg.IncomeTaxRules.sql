-- cfg.IncomeTaxRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.IncomeTaxRules', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[IncomeTaxRules] (
        [IncomeTaxRuleId] UNIQUEIDENTIFIER NOT NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_IncomeTaxRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_IncomeTaxRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_IncomeTaxRules] PRIMARY KEY ([IncomeTaxRuleId])
    );
END;
GO
