-- cfg.SeedPacks — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.SeedPacks', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[SeedPacks] (
        [SeedPackId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Demo-base-s39] NVARCHAR(512) NULL,
        [Version] NVARCHAR(512) NULL,
        [Description] NVARCHAR(512) NULL,
        [Contents] NVARCHAR(512) NULL,
        [DemoOnly] NVARCHAR(512) NULL,
        [SeedApplications] NVARCHAR(512) NULL,
        [SeedPackCode] NVARCHAR(512) NULL,
        [AppliedAt] DATETIME2(7) NULL,
        [AppliedBy] NVARCHAR(512) NULL,
        [ConfigVersionId] NVARCHAR(512) NULL,
        [CreatedRecordRefs] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Applied] NVARCHAR(512) NULL,
        [Removed] NVARCHAR(512) NULL,
        [ContentsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_SeedPacks_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_SeedPacks_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_SeedPacks] PRIMARY KEY ([SeedPackId])
    );
END;
GO
