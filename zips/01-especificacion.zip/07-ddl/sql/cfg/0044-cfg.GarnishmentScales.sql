-- cfg.GarnishmentScales — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.GarnishmentScales', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[GarnishmentScales] (
        [GarnishmentScaleId] UNIQUEIDENTIFIER NOT NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_GarnishmentScales_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_GarnishmentScales_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_GarnishmentScales] PRIMARY KEY ([GarnishmentScaleId])
    );
END;
GO
