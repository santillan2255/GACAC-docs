-- cfg.EconomicIndexValues — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.EconomicIndexValues', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[EconomicIndexValues] (
        [EconomicIndexValueId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SeriesId] UNIQUEIDENTIFIER NOT NULL,
        [Date] DATETIME2(7) NOT NULL,
        [RecordedAt] DATETIME2(7) NULL,
        [DateOPeriod] NVARCHAR(512) NULL,
        [Time] NVARCHAR(512) NULL,
        [Value] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [PublishedAt] DATETIME2(7) NULL,
        [SupersededAt] DATETIME2(7) NULL,
        [RevisionOf] NVARCHAR(512) NULL,
        [Source] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_EconomicIndexValues_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_EconomicIndexValues_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_EconomicIndexValues] PRIMARY KEY ([EconomicIndexValueId]),
        CONSTRAINT [FK_cfg_EconomicIndexValues_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_EconomicIndexValues_Tenant] ON [cfg].[EconomicIndexValues] ([TenantId]);
END;
GO
