-- cfg.EnumerationItems — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.EnumerationItems', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[EnumerationItems] (
        [EnumerationItemId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [EnumCode] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NULL,
        [LabelKey] NVARCHAR(512) NULL,
        [Label] NVARCHAR(512) NULL,
        [Order] NVARCHAR(512) NULL,
        [Color] NVARCHAR(512) NULL,
        [Icon] NVARCHAR(512) NULL,
        [ParentCode] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ValidTo] NVARCHAR(512) NULL,
        [Attributes] NVARCHAR(512) NULL,
        [ExternalCodes] NVARCHAR(512) NULL,
        [{ arca, inaes, enargas, oceba, ersep, enacom, sen }] NVARCHAR(512) NULL,
        [IsSystem] NVARCHAR(512) NULL,
        [{ tenantId, enumCode, code }] NVARCHAR(512) NULL,
        [OriginalText] NVARCHAR(512) NULL,
        [ComponentsJson] NVARCHAR(MAX) NULL,
        [NormalizedJson] NVARCHAR(MAX) NULL,
        [Point] NVARCHAR(MAX) NULL,
        [Precision] VARCHAR(64) NULL,
        [Status] VARCHAR(64) NULL,
        [Source] VARCHAR(64) NULL,
        [HistoryJson] NVARCHAR(MAX) NULL,
        [ProviderRefsJson] NVARCHAR(MAX) NULL,
        [AttributesJson] NVARCHAR(MAX) NULL,
        [ExternalCodesJson] NVARCHAR(MAX) NULL,
        [EnumerationId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_EnumerationItems_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_EnumerationItems_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_EnumerationItems] PRIMARY KEY ([EnumerationItemId]),
        CONSTRAINT [FK_cfg_EnumerationItems_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_EnumerationItems_Tenant] ON [cfg].[EnumerationItems] ([TenantId]);
END;
GO
