-- cfg.GeocodeRequests — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.GeocodeRequests', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[GeocodeRequests] (
        [GeocodeRequestId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [NextAttemptAt] DATETIME2(7) NULL,
        [SubjectType] NVARCHAR(512) NULL,
        [SubjectId] UNIQUEIDENTIFIER NULL,
        [InputText] NVARCHAR(512) NULL,
        [Provider] VARCHAR(64) NOT NULL,
        [CandidatesObject] NVARCHAR(512) NULL,
        [Attempts] INT NULL,
        [LastError] NVARCHAR(512) NULL,
        [QuotaPeriod] NVARCHAR(512) NULL,
        [ExpiresAt] DATETIME2(7) NULL,
        [QueryHash] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_GeocodeRequests_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_GeocodeRequests_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_GeocodeRequests] PRIMARY KEY ([GeocodeRequestId]),
        CONSTRAINT [FK_cfg_GeocodeRequests_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_GeocodeRequests_Tenant] ON [cfg].[GeocodeRequests] ([TenantId]);
END;
GO
