-- cfg.PostalCodes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.PostalCodes', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[PostalCodes] (
        [PostalCodeId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Cpa] NVARCHAR(512) NULL,
        [LocalityCodesJson] NVARCHAR(MAX) NULL,
        [ProvinceCode] NVARCHAR(512) NULL,
        [Source] NVARCHAR(512) NULL,
        [LocalityId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_PostalCodes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_PostalCodes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_PostalCodes] PRIMARY KEY ([PostalCodeId])
    );
END;
GO
