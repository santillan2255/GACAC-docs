-- cfg.SeedApplications — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.SeedApplications', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[SeedApplications] (
        [SeedApplicationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SeedPackCode] NVARCHAR(512) NULL,
        [AppliedAt] DATETIME2(7) NULL,
        [AppliedById] UNIQUEIDENTIFIER NULL,
        [ConfigVersionId] UNIQUEIDENTIFIER NULL,
        [CreatedRecordRefsJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [SeedPackId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_SeedApplications_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_SeedApplications_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_SeedApplications] PRIMARY KEY ([SeedApplicationId]),
        CONSTRAINT [FK_cfg_SeedApplications_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_SeedApplications_Tenant] ON [cfg].[SeedApplications] ([TenantId]);
END;
GO
