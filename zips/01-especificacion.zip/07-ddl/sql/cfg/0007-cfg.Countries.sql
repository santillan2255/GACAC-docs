-- cfg.Countries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Countries', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Countries] (
        [CountryId] UNIQUEIDENTIFIER NOT NULL,
        [Iso2] NVARCHAR(512) NULL,
        [Iso3] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [ExternalCodesArca] NVARCHAR(512) NULL,
        [Active] BIT NULL,
        [IsoCode] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Countries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Countries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Countries] PRIMARY KEY ([CountryId])
    );
END;
GO
