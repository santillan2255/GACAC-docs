-- cfg.CadastralDistricts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.CadastralDistricts', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[CadastralDistricts] (
        [CadastralDistrictId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [District] NVARCHAR(512) NULL,
        [Section] NVARCHAR(512) NULL,
        [LocalityCode] NVARCHAR(512) NULL,
        [Description] NVARCHAR(512) NULL,
        [ExternalCodesJson] NVARCHAR(MAX) NULL,
        [LocalityId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_CadastralDistricts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_CadastralDistricts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_CadastralDistricts] PRIMARY KEY ([CadastralDistrictId]),
        CONSTRAINT [FK_cfg_CadastralDistricts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_CadastralDistricts_Tenant] ON [cfg].[CadastralDistricts] ([TenantId]);
END;
GO
