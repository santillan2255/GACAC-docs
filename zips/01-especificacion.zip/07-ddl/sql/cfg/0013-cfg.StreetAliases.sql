-- cfg.StreetAliases — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.StreetAliases', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[StreetAliases] (
        [StreetAliasId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [NormalizedAliasJson] NVARCHAR(MAX) NULL,
        [StreetId] UNIQUEIDENTIFIER NOT NULL,
        [AliasJson] NVARCHAR(MAX) NOT NULL,
        [Kind] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_StreetAliases_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_StreetAliases_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_StreetAliases] PRIMARY KEY ([StreetAliasId]),
        CONSTRAINT [FK_cfg_StreetAliases_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_StreetAliases_Tenant] ON [cfg].[StreetAliases] ([TenantId]);
END;
GO
