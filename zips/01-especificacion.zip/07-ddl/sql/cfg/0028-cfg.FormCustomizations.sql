-- cfg.FormCustomizations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.FormCustomizations', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[FormCustomizations] (
        [FormCustomizationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [FormKey] NVARCHAR(512) NULL,
        [FieldKey] NVARCHAR(512) NULL,
        [Hidden] NVARCHAR(512) NULL,
        [Required] NVARCHAR(512) NULL,
        [ReadOnly] NVARCHAR(512) NULL,
        [DefaultValue] NVARCHAR(512) NULL,
        [LabelKey] NVARCHAR(512) NULL,
        [HelpKey] NVARCHAR(512) NULL,
        [Order] NVARCHAR(512) NULL,
        [AllowedEnumCodes] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Superseded] NVARCHAR(512) NULL,
        [ConfigVersionId] NVARCHAR(512) NULL,
        [Legacy] NVARCHAR(512) NULL,
        [FORMULARIOS_PERSONALIZACIONESID_FORM] NVARCHAR(512) NULL,
        [ABM_VALIDACIONESCOD_ABM] NVARCHAR(512) NULL,
        [{ tenantId, formKey, fieldKey }] NVARCHAR(512) NULL,
        [AllowedEnumCodesJson] NVARCHAR(MAX) NULL,
        [ScreenCode] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_FormCustomizations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_FormCustomizations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_FormCustomizations] PRIMARY KEY ([FormCustomizationId]),
        CONSTRAINT [FK_cfg_FormCustomizations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_FormCustomizations_Tenant] ON [cfg].[FormCustomizations] ([TenantId]);
END;
GO
