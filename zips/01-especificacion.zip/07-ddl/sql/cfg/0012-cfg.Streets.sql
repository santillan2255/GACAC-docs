-- cfg.Streets — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Streets', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Streets] (
        [StreetId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LocalityCode] NVARCHAR(512) NULL,
        [NormalizedName] NVARCHAR(512) NULL,
        [DepartmentCode] NVARCHAR(512) NULL,
        [ProvinceCode] NVARCHAR(512) NULL,
        [SourceId] UNIQUEIDENTIFIER NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Kind] VARCHAR(64) NULL,
        [HeightsJson] NVARCHAR(MAX) NULL,
        [Source] VARCHAR(64) NULL,
        [SourceUpdatedAt] DATETIME2(7) NULL,
        [IsTenantOwned] BIT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [MergedInto] NVARCHAR(512) NULL,
        [GeometryRef] NVARCHAR(512) NULL,
        [LocalityId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Streets_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Streets_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Streets] PRIMARY KEY ([StreetId]),
        CONSTRAINT [FK_cfg_Streets_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_Streets_Tenant] ON [cfg].[Streets] ([TenantId]);
END;
GO
