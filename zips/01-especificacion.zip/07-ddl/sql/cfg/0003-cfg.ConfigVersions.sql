-- cfg.ConfigVersions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.ConfigVersions', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[ConfigVersions] (
        [ConfigVersionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] INT NOT NULL,
        [Origin] VARCHAR(64) NOT NULL,
        [SourceRefJson] NVARCHAR(MAX) NULL,
        [ChangeClasses] VARCHAR(64) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [EffectiveAt] DATETIME2(7) NOT NULL,
        [ScheduledAt] DATETIME2(7) NULL,
        [ContractPolicy] VARCHAR(64) NOT NULL,
        [ItemsJson] NVARCHAR(MAX) NOT NULL,
        [DependencyReportJson] NVARCHAR(MAX) NULL,
        [ValidationReportJson] NVARCHAR(MAX) NULL,
        [SimulationReportJson] NVARCHAR(MAX) NULL,
        [DiffBaseAt] DATETIME2(7) NULL,
        [WorkflowInstanceId] UNIQUEIDENTIFIER NULL,
        [ApprovalsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_ConfigVersions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_ConfigVersions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_ConfigVersions] PRIMARY KEY ([ConfigVersionId]),
        CONSTRAINT [FK_cfg_ConfigVersions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_ConfigVersions_Tenant] ON [cfg].[ConfigVersions] ([TenantId]);
END;
GO
