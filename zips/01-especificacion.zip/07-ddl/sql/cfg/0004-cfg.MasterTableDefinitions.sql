-- cfg.MasterTableDefinitions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.MasterTableDefinitions', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[MasterTableDefinitions] (
        [MasterTableDefinitionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Collection] NVARCHAR(512) NOT NULL,
        [OwnerModule] NVARCHAR(512) NOT NULL,
        [Scope] VARCHAR(64) NOT NULL,
        [AllowTenantRecords] BIT NOT NULL,
        [TenantAttributes] NVARCHAR(MAX) NULL,
        [Fields] NVARCHAR(MAX) NOT NULL,
        [NaturalKey] NVARCHAR(512) NOT NULL,
        [ValidityMode] VARCHAR(64) NOT NULL,
        [Versioned] BIT NOT NULL,
        [ReferencedByJson] NVARCHAR(MAX) NOT NULL,
        [LegacyTables] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_MasterTableDefinitions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_MasterTableDefinitions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_MasterTableDefinitions] PRIMARY KEY ([MasterTableDefinitionId]),
        CONSTRAINT [FK_cfg_MasterTableDefinitions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_MasterTableDefinitions_Tenant] ON [cfg].[MasterTableDefinitions] ([TenantId]);
END;
GO
