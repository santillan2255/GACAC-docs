-- cfg.PlatformTableAdoptions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.PlatformTableAdoptions', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[PlatformTableAdoptions] (
        [PlatformTableAdoptionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TableCode] NVARCHAR(512) NULL,
        [SeriesId] NVARCHAR(512) NULL,
        [SeriesCode] NVARCHAR(512) NULL,
        [Mode] NVARCHAR(512) NULL,
        [Follow] NVARCHAR(512) NULL,
        [Pinned] NVARCHAR(512) NULL,
        [Copy] NVARCHAR(512) NULL,
        [PinnedReleaseNumber] NVARCHAR(512) NULL,
        [PendingReleases] NVARCHAR(512) NULL,
        [AcknowledgedBy] NVARCHAR(512) NULL,
        [AcknowledgedAt] DATETIME2(7) NULL,
        [Purpose] NVARCHAR(512) NULL,
        [Inflation] NVARCHAR(512) NULL,
        [ExchangeRateUSD] NVARCHAR(512) NULL,
        [LateFee] NVARCHAR(512) NULL,
        [PendingReleasesJson] NVARCHAR(MAX) NULL,
        [AcknowledgedById] UNIQUEIDENTIFIER NULL,
        [ReleaseId] UNIQUEIDENTIFIER NOT NULL,
        [EffectiveFrom] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_PlatformTableAdoptions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_PlatformTableAdoptions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_PlatformTableAdoptions] PRIMARY KEY ([PlatformTableAdoptionId]),
        CONSTRAINT [FK_cfg_PlatformTableAdoptions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_PlatformTableAdoptions_Tenant] ON [cfg].[PlatformTableAdoptions] ([TenantId]);
END;
GO
