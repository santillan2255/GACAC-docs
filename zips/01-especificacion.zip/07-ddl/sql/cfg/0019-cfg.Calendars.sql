-- cfg.Calendars — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Calendars', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Calendars] (
        [CalendarId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Kind] VARCHAR(64) NULL,
        [ProvinceCode] NVARCHAR(512) NULL,
        [LocalityCode] NVARCHAR(512) NULL,
        [ParentCalendarCodesJson] NVARCHAR(MAX) NULL,
        [WeekendDays06] NVARCHAR(512) NULL,
        [Timezone] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Calendars_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Calendars_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Calendars] PRIMARY KEY ([CalendarId]),
        CONSTRAINT [FK_cfg_Calendars_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_Calendars_Tenant] ON [cfg].[Calendars] ([TenantId]);
END;
GO
