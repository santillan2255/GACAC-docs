-- cfg.StreetProposals — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.StreetProposals', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[StreetProposals] (
        [StreetProposalId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [StreetId] UNIQUEIDENTIFIER NULL,
        [ProposedById] UNIQUEIDENTIFIER NULL,
        [Evidence] NVARCHAR(512) NULL,
        [DecisionById] UNIQUEIDENTIFIER NULL,
        [DecisionAt] DATETIME2(7) NULL,
        [PlatformStreetId] UNIQUEIDENTIFIER NULL,
        [LocalityId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_StreetProposals_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_StreetProposals_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_StreetProposals] PRIMARY KEY ([StreetProposalId]),
        CONSTRAINT [FK_cfg_StreetProposals_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_StreetProposals_Tenant] ON [cfg].[StreetProposals] ([TenantId]);
END;
GO
