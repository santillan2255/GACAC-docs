-- cfg.PayrollOfficialCodes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.PayrollOfficialCodes', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[PayrollOfficialCodes] (
        [PayrollOfficialCodeId] UNIQUEIDENTIFIER NOT NULL,
        [Type] VARCHAR(64) NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_PayrollOfficialCodes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_PayrollOfficialCodes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_PayrollOfficialCodes] PRIMARY KEY ([PayrollOfficialCodeId])
    );
END;
GO
