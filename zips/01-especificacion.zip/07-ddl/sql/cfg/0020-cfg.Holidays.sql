-- cfg.Holidays — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.Holidays', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[Holidays] (
        [HolidayId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CalendarCode] NVARCHAR(512) NULL,
        [Date] DATETIME2(7) NOT NULL,
        [Recurring] NVARCHAR(512) NULL,
        [Year] NVARCHAR(512) NULL,
        [Kind] VARCHAR(64) NULL,
        [NameLabelKey] NVARCHAR(512) NULL,
        [SourceRef] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [RecordedAt] DATETIME2(7) NULL,
        [CalendarId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Holidays_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_Holidays_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_Holidays] PRIMARY KEY ([HolidayId]),
        CONSTRAINT [FK_cfg_Holidays_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_Holidays_Tenant] ON [cfg].[Holidays] ([TenantId]);
END;
GO
