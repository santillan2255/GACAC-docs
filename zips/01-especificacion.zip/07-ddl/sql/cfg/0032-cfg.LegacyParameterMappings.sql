-- cfg.LegacyParameterMappings — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.LegacyParameterMappings', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[LegacyParameterMappings] (
        [LegacyParameterMappingId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyTable] NVARCHAR(512) NULL,
        [VARIABLE] NVARCHAR(512) NULL,
        [VARIABLE_PMOVIL] NVARCHAR(512) NULL,
        [ModVar] NVARCHAR(512) NULL,
        [CodVar] NVARCHAR(512) NULL,
        [LegacyName] NVARCHAR(512) NULL,
        [NOM_VAR] NVARCHAR(512) NULL,
        [LegacyModule] NVARCHAR(512) NULL,
        [COD_MOD] NVARCHAR(512) NULL,
        [LegacyType] NVARCHAR(512) NULL,
        [DirectUse] NVARCHAR(512) NULL,
        [DestinationKind] NVARCHAR(512) NULL,
        [Parameter] NVARCHAR(512) NULL,
        [Dictionary] NVARCHAR(512) NULL,
        [TenantProfile] NVARCHAR(512) NULL,
        [Secret] NVARCHAR(512) NULL,
        [Env] NVARCHAR(512) NULL,
        [Discarded] NVARCHAR(512) NULL,
        [ReplacedBy] NVARCHAR(512) NULL,
        [ToValidate] NVARCHAR(512) NULL,
        [Keys] NVARCHAR(512) NULL,
        [Transform] NVARCHAR(512) NULL,
        [Identity] NVARCHAR(512) NULL,
        [InvertBoolean] NVARCHAR(512) NULL,
        [FkMap:<tabla>] NVARCHAR(512) NULL,
        [EnumMap] NVARCHAR(512) NULL,
        [Split] NVARCHAR(512) NULL,
        [TextDate→date] NVARCHAR(512) NULL,
        [PrmId] NVARCHAR(512) NULL,
        [Notes] NVARCHAR(512) NULL,
        [{ legacyTable, modVar, codVar }] NVARCHAR(512) NULL,
        [KeysJson] NVARCHAR(MAX) NULL,
        [ParameterKey] NVARCHAR(512) NOT NULL,
        [LegacyKey] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_LegacyParameterMappings_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_LegacyParameterMappings_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_LegacyParameterMappings] PRIMARY KEY ([LegacyParameterMappingId])
    );
END;
GO
