-- cfg.MasterImportJobs — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cfg.MasterImportJobs', N'U') IS NULL
BEGIN
    CREATE TABLE [cfg].[MasterImportJobs] (
        [MasterImportJobId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TargetTableCode] NVARCHAR(512) NULL,
        [FileRef] NVARCHAR(512) NULL,
        [Format] NVARCHAR(512) NULL,
        [Xlsx] NVARCHAR(512) NULL,
        [Csv] NVARCHAR(512) NULL,
        [FixedWidth] NVARCHAR(512) NULL,
        [LayoutRef] NVARCHAR(512) NULL,
        [Mapping] NVARCHAR(512) NULL,
        [Mode] NVARCHAR(512) NULL,
        [InsertOnly] NVARCHAR(512) NULL,
        [Upsert] NVARCHAR(512) NULL,
        [ReplaceValidity] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Counters] NVARCHAR(512) NULL,
        [Total] NVARCHAR(512) NULL,
        [Valid] NVARCHAR(512) NULL,
        [Errors] NVARCHAR(512) NULL,
        [Inserted] NVARCHAR(512) NULL,
        [Updated] NVARCHAR(512) NULL,
        [Closed] NVARCHAR(512) NULL,
        [ErrorFileRef] NVARCHAR(512) NULL,
        [ConfigVersionId] NVARCHAR(512) NULL,
        [PlatformTableReleaseId] NVARCHAR(512) NULL,
        [IdempotencyKey] NVARCHAR(512) NULL,
        [StoredFileId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_MasterImportJobs_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cfg_MasterImportJobs_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cfg_MasterImportJobs] PRIMARY KEY ([MasterImportJobId]),
        CONSTRAINT [FK_cfg_MasterImportJobs_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cfg_MasterImportJobs_Tenant] ON [cfg].[MasterImportJobs] ([TenantId]);
END;
GO
