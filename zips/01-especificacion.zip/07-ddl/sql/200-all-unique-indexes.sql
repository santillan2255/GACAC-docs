-- Índices únicos desde T05 — 2026-11-19
-- Regenerar: python docs/especificacion/_trabajo/generate_ddl_constraints.py

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_AuthFactors_1' AND object_id = OBJECT_ID(N'iam.AuthFactors')
)
    CREATE UNIQUE INDEX [UX_iam_AuthFactors_1] ON [iam].[AuthFactors] ([IdentityId], [Kind], [Label]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_FederatedLinks_1' AND object_id = OBJECT_ID(N'iam.FederatedLinks')
)
    CREATE UNIQUE INDEX [UX_iam_FederatedLinks_1] ON [iam].[FederatedLinks] ([Provider], [Subject]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_Roles_1' AND object_id = OBJECT_ID(N'iam.Roles')
)
    CREATE UNIQUE INDEX [UX_iam_Roles_1] ON [iam].[Roles] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_ScreenProfiles_1' AND object_id = OBJECT_ID(N'iam.ScreenProfiles')
)
    CREATE UNIQUE INDEX [UX_iam_ScreenProfiles_1] ON [iam].[ScreenProfiles] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_CapabilityCatalog_1' AND object_id = OBJECT_ID(N'iam.CapabilityCatalog')
)
    CREATE UNIQUE INDEX [UX_iam_CapabilityCatalog_1] ON [iam].[CapabilityCatalog] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_ScreenCatalog_1' AND object_id = OBJECT_ID(N'iam.ScreenCatalog')
)
    CREATE UNIQUE INDEX [UX_iam_ScreenCatalog_1] ON [iam].[ScreenCatalog] ([ScreenId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_ScreenCatalog_2' AND object_id = OBJECT_ID(N'iam.ScreenCatalog')
)
    CREATE UNIQUE INDEX [UX_iam_ScreenCatalog_2] ON [iam].[ScreenCatalog] ([Antes]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_SodRules_1' AND object_id = OBJECT_ID(N'iam.SodRules')
)
    CREATE UNIQUE INDEX [UX_iam_SodRules_1] ON [iam].[SodRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_Sessions_1' AND object_id = OBJECT_ID(N'iam.Sessions')
)
    CREATE UNIQUE INDEX [UX_iam_Sessions_1] ON [iam].[Sessions] ([TenantId], [RefreshFamilyId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_Sessions_2' AND object_id = OBJECT_ID(N'iam.Sessions')
)
    CREATE UNIQUE INDEX [UX_iam_Sessions_2] ON [iam].[Sessions] ([TenantId], [Antes]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_Sessions_3' AND object_id = OBJECT_ID(N'iam.Sessions')
)
    CREATE UNIQUE INDEX [UX_iam_Sessions_3] ON [iam].[Sessions] ([TenantId], [Antes]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_AuthTransactions_1' AND object_id = OBJECT_ID(N'iam.AuthTransactions')
)
    CREATE UNIQUE INDEX [UX_iam_AuthTransactions_1] ON [iam].[AuthTransactions] ([TxId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_TrustedDevices_1' AND object_id = OBJECT_ID(N'iam.TrustedDevices')
)
    CREATE UNIQUE INDEX [UX_iam_TrustedDevices_1] ON [iam].[TrustedDevices] ([IdentityId], [DeviceHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_ActionTokens_1' AND object_id = OBJECT_ID(N'iam.ActionTokens')
)
    CREATE UNIQUE INDEX [UX_iam_ActionTokens_1] ON [iam].[ActionTokens] ([TenantId], [TokenHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_EditPresence_1' AND object_id = OBJECT_ID(N'iam.EditPresence')
)
    CREATE UNIQUE INDEX [UX_iam_EditPresence_1] ON [iam].[EditPresence] ([TenantId], [EntityCollection], [EntityId], [MembershipId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_EditPresence_2' AND object_id = OBJECT_ID(N'iam.EditPresence')
)
    CREATE UNIQUE INDEX [UX_iam_EditPresence_2] ON [iam].[EditPresence] ([TenantId], [EntityRef], [MembershipId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_AuthorizationRequests_1' AND object_id = OBJECT_ID(N'iam.AuthorizationRequests')
)
    CREATE UNIQUE INDEX [UX_iam_AuthorizationRequests_1] ON [iam].[AuthorizationRequests] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_IdentityProviderConfigs_1' AND object_id = OBJECT_ID(N'iam.IdentityProviderConfigs')
)
    CREATE UNIQUE INDEX [UX_iam_IdentityProviderConfigs_1] ON [iam].[IdentityProviderConfigs] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_ApiClients_1' AND object_id = OBJECT_ID(N'iam.ApiClients')
)
    CREATE UNIQUE INDEX [UX_iam_ApiClients_1] ON [iam].[ApiClients] ([TenantId], [ClientId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_ApiCredentials_1' AND object_id = OBJECT_ID(N'iam.ApiCredentials')
)
    CREATE UNIQUE INDEX [UX_iam_ApiCredentials_1] ON [iam].[ApiCredentials] ([TenantId], [SecretPrefix]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_ApiCredentials_2' AND object_id = OBJECT_ID(N'iam.ApiCredentials')
)
    CREATE UNIQUE INDEX [UX_iam_ApiCredentials_2] ON [iam].[ApiCredentials] ([TenantId], [Antes]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_iam_AccessReviews_1' AND object_id = OBJECT_ID(N'iam.AccessReviews')
)
    CREATE UNIQUE INDEX [UX_iam_AccessReviews_1] ON [iam].[AccessReviews] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_TenantBrandings_1' AND object_id = OBJECT_ID(N'uxd.TenantBrandings')
)
    CREATE UNIQUE INDEX [UX_uxd_TenantBrandings_1] ON [uxd].[TenantBrandings] ([TenantId], [Channel], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_BrandAssets_1' AND object_id = OBJECT_ID(N'uxd.BrandAssets')
)
    CREATE UNIQUE INDEX [UX_uxd_BrandAssets_1] ON [uxd].[BrandAssets] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_DictionaryKeys_1' AND object_id = OBJECT_ID(N'uxd.DictionaryKeys')
)
    CREATE UNIQUE INDEX [UX_uxd_DictionaryKeys_1] ON [uxd].[DictionaryKeys] ([Key]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_TenantDictionaryEntries_1' AND object_id = OBJECT_ID(N'uxd.TenantDictionaryEntries')
)
    CREATE UNIQUE INDEX [UX_uxd_TenantDictionaryEntries_1] ON [uxd].[TenantDictionaryEntries] ([TenantId], [Key], [Locale]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_DictionaryReleases_1' AND object_id = OBJECT_ID(N'uxd.DictionaryReleases')
)
    CREATE UNIQUE INDEX [UX_uxd_DictionaryReleases_1] ON [uxd].[DictionaryReleases] ([TenantId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_DictionaryMissingKeys_1' AND object_id = OBJECT_ID(N'uxd.DictionaryMissingKeys')
)
    CREATE UNIQUE INDEX [UX_uxd_DictionaryMissingKeys_1] ON [uxd].[DictionaryMissingKeys] ([Key], [Locale]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_ScreenHelpArticles_1' AND object_id = OBJECT_ID(N'uxd.ScreenHelpArticles')
)
    CREATE UNIQUE INDEX [UX_uxd_ScreenHelpArticles_1] ON [uxd].[ScreenHelpArticles] ([TenantId], [ScreenId], [Scope]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_ScreenHelpArticles_2' AND object_id = OBJECT_ID(N'uxd.ScreenHelpArticles')
)
    CREATE UNIQUE INDEX [UX_uxd_ScreenHelpArticles_2] ON [uxd].[ScreenHelpArticles] ([TenantId], [ScreenCode], [Locale]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_UserUiPreferences_1' AND object_id = OBJECT_ID(N'uxd.UserUiPreferences')
)
    CREATE UNIQUE INDEX [UX_uxd_UserUiPreferences_1] ON [uxd].[UserUiPreferences] ([TenantId], [MembershipId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_DataTableViews_1' AND object_id = OBJECT_ID(N'uxd.DataTableViews')
)
    CREATE UNIQUE INDEX [UX_uxd_DataTableViews_1] ON [uxd].[DataTableViews] ([TenantId], [TableId], [OwnerId], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_DataTableViews_2' AND object_id = OBJECT_ID(N'uxd.DataTableViews')
)
    CREATE UNIQUE INDEX [UX_uxd_DataTableViews_2] ON [uxd].[DataTableViews] ([TenantId], [ScreenCode], [OwnerId], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_uxd_PwaNavConfigs_1' AND object_id = OBJECT_ID(N'uxd.PwaNavConfigs')
)
    CREATE UNIQUE INDEX [UX_uxd_PwaNavConfigs_1] ON [uxd].[PwaNavConfigs] ([TenantId], [App], [ScreenProfileId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_ParameterDefinitions_1' AND object_id = OBJECT_ID(N'cfg.ParameterDefinitions')
)
    CREATE UNIQUE INDEX [UX_cfg_ParameterDefinitions_1] ON [cfg].[ParameterDefinitions] ([Key]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_ParameterValues_1' AND object_id = OBJECT_ID(N'cfg.ParameterValues')
)
    CREATE UNIQUE INDEX [UX_cfg_ParameterValues_1] ON [cfg].[ParameterValues] ([TenantId], [Key], [ScopeType], [ScopeRefId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_ParameterValues_2' AND object_id = OBJECT_ID(N'cfg.ParameterValues')
)
    CREATE UNIQUE INDEX [UX_cfg_ParameterValues_2] ON [cfg].[ParameterValues] ([TenantId], [Key], [ScopeType], [ScopeId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_ConfigVersions_1' AND object_id = OBJECT_ID(N'cfg.ConfigVersions')
)
    CREATE UNIQUE INDEX [UX_cfg_ConfigVersions_1] ON [cfg].[ConfigVersions] ([TenantId], [Domain], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_MasterTableDefinitions_1' AND object_id = OBJECT_ID(N'cfg.MasterTableDefinitions')
)
    CREATE UNIQUE INDEX [UX_cfg_MasterTableDefinitions_1] ON [cfg].[MasterTableDefinitions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Enumerations_1' AND object_id = OBJECT_ID(N'cfg.Enumerations')
)
    CREATE UNIQUE INDEX [UX_cfg_Enumerations_1] ON [cfg].[Enumerations] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_EnumerationItems_1' AND object_id = OBJECT_ID(N'cfg.EnumerationItems')
)
    CREATE UNIQUE INDEX [UX_cfg_EnumerationItems_1] ON [cfg].[EnumerationItems] ([TenantId], [EnumCode], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_EnumerationItems_2' AND object_id = OBJECT_ID(N'cfg.EnumerationItems')
)
    CREATE UNIQUE INDEX [UX_cfg_EnumerationItems_2] ON [cfg].[EnumerationItems] ([TenantId], [EnumerationId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Countries_1' AND object_id = OBJECT_ID(N'cfg.Countries')
)
    CREATE UNIQUE INDEX [UX_cfg_Countries_1] ON [cfg].[Countries] ([IsoCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Provinces_1' AND object_id = OBJECT_ID(N'cfg.Provinces')
)
    CREATE UNIQUE INDEX [UX_cfg_Provinces_1] ON [cfg].[Provinces] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Departments_1' AND object_id = OBJECT_ID(N'cfg.Departments')
)
    CREATE UNIQUE INDEX [UX_cfg_Departments_1] ON [cfg].[Departments] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Localities_1' AND object_id = OBJECT_ID(N'cfg.Localities')
)
    CREATE UNIQUE INDEX [UX_cfg_Localities_1] ON [cfg].[Localities] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_PostalCodes_1' AND object_id = OBJECT_ID(N'cfg.PostalCodes')
)
    CREATE UNIQUE INDEX [UX_cfg_PostalCodes_1] ON [cfg].[PostalCodes] ([Code], [LocalityId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Streets_1' AND object_id = OBJECT_ID(N'cfg.Streets')
)
    CREATE UNIQUE INDEX [UX_cfg_Streets_1] ON [cfg].[Streets] ([TenantId], [LocalityCode], [NormalizedName]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Streets_2' AND object_id = OBJECT_ID(N'cfg.Streets')
)
    CREATE UNIQUE INDEX [UX_cfg_Streets_2] ON [cfg].[Streets] ([TenantId], [LocalityId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_StreetAliases_1' AND object_id = OBJECT_ID(N'cfg.StreetAliases')
)
    CREATE UNIQUE INDEX [UX_cfg_StreetAliases_1] ON [cfg].[StreetAliases] ([TenantId], [StreetId], [Alias]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Neighborhoods_1' AND object_id = OBJECT_ID(N'cfg.Neighborhoods')
)
    CREATE UNIQUE INDEX [UX_cfg_Neighborhoods_1] ON [cfg].[Neighborhoods] ([TenantId], [LocalityCode], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Neighborhoods_2' AND object_id = OBJECT_ID(N'cfg.Neighborhoods')
)
    CREATE UNIQUE INDEX [UX_cfg_Neighborhoods_2] ON [cfg].[Neighborhoods] ([TenantId], [LocalityId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Zones_1' AND object_id = OBJECT_ID(N'cfg.Zones')
)
    CREATE UNIQUE INDEX [UX_cfg_Zones_1] ON [cfg].[Zones] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_CadastralDistricts_1' AND object_id = OBJECT_ID(N'cfg.CadastralDistricts')
)
    CREATE UNIQUE INDEX [UX_cfg_CadastralDistricts_1] ON [cfg].[CadastralDistricts] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_GeocodeRequests_1' AND object_id = OBJECT_ID(N'cfg.GeocodeRequests')
)
    CREATE UNIQUE INDEX [UX_cfg_GeocodeRequests_1] ON [cfg].[GeocodeRequests] ([TenantId], [Provider], [QueryHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Calendars_1' AND object_id = OBJECT_ID(N'cfg.Calendars')
)
    CREATE UNIQUE INDEX [UX_cfg_Calendars_1] ON [cfg].[Calendars] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Holidays_1' AND object_id = OBJECT_ID(N'cfg.Holidays')
)
    CREATE UNIQUE INDEX [UX_cfg_Holidays_1] ON [cfg].[Holidays] ([TenantId], [CalendarCode], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Holidays_2' AND object_id = OBJECT_ID(N'cfg.Holidays')
)
    CREATE UNIQUE INDEX [UX_cfg_Holidays_2] ON [cfg].[Holidays] ([TenantId], [CalendarId], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_EconomicIndexSeries_1' AND object_id = OBJECT_ID(N'cfg.EconomicIndexSeries')
)
    CREATE UNIQUE INDEX [UX_cfg_EconomicIndexSeries_1] ON [cfg].[EconomicIndexSeries] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_EconomicIndexValues_1' AND object_id = OBJECT_ID(N'cfg.EconomicIndexValues')
)
    CREATE UNIQUE INDEX [UX_cfg_EconomicIndexValues_1] ON [cfg].[EconomicIndexValues] ([TenantId], [SeriesId], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Currencies_1' AND object_id = OBJECT_ID(N'cfg.Currencies')
)
    CREATE UNIQUE INDEX [UX_cfg_Currencies_1] ON [cfg].[Currencies] ([IsoCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_IdentityDocumentTypes_1' AND object_id = OBJECT_ID(N'cfg.IdentityDocumentTypes')
)
    CREATE UNIQUE INDEX [UX_cfg_IdentityDocumentTypes_1] ON [cfg].[IdentityDocumentTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_PlatformTableReleases_1' AND object_id = OBJECT_ID(N'cfg.PlatformTableReleases')
)
    CREATE UNIQUE INDEX [UX_cfg_PlatformTableReleases_1] ON [cfg].[PlatformTableReleases] ([TableCode], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_PlatformTableAdoptions_1' AND object_id = OBJECT_ID(N'cfg.PlatformTableAdoptions')
)
    CREATE UNIQUE INDEX [UX_cfg_PlatformTableAdoptions_1] ON [cfg].[PlatformTableAdoptions] ([TenantId], [TableCode], [EffectiveFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_CustomFieldDefinitions_1' AND object_id = OBJECT_ID(N'cfg.CustomFieldDefinitions')
)
    CREATE UNIQUE INDEX [UX_cfg_CustomFieldDefinitions_1] ON [cfg].[CustomFieldDefinitions] ([TenantId], [Entity], [Key]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_FormCustomizations_1' AND object_id = OBJECT_ID(N'cfg.FormCustomizations')
)
    CREATE UNIQUE INDEX [UX_cfg_FormCustomizations_1] ON [cfg].[FormCustomizations] ([TenantId], [FormKey], [FieldKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_FormCustomizations_2' AND object_id = OBJECT_ID(N'cfg.FormCustomizations')
)
    CREATE UNIQUE INDEX [UX_cfg_FormCustomizations_2] ON [cfg].[FormCustomizations] ([TenantId], [ScreenCode], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_SeedPacks_1' AND object_id = OBJECT_ID(N'cfg.SeedPacks')
)
    CREATE UNIQUE INDEX [UX_cfg_SeedPacks_1] ON [cfg].[SeedPacks] ([Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_SeedApplications_1' AND object_id = OBJECT_ID(N'cfg.SeedApplications')
)
    CREATE UNIQUE INDEX [UX_cfg_SeedApplications_1] ON [cfg].[SeedApplications] ([TenantId], [SeedPackCode], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_SeedApplications_2' AND object_id = OBJECT_ID(N'cfg.SeedApplications')
)
    CREATE UNIQUE INDEX [UX_cfg_SeedApplications_2] ON [cfg].[SeedApplications] ([TenantId], [SeedPackId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_LegacyParameterMappings_1' AND object_id = OBJECT_ID(N'cfg.LegacyParameterMappings')
)
    CREATE UNIQUE INDEX [UX_cfg_LegacyParameterMappings_1] ON [cfg].[LegacyParameterMappings] ([LegacyTable], [ModVar], [CodVar]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_LegacyParameterMappings_2' AND object_id = OBJECT_ID(N'cfg.LegacyParameterMappings')
)
    CREATE UNIQUE INDEX [UX_cfg_LegacyParameterMappings_2] ON [cfg].[LegacyParameterMappings] ([LegacyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_LegalEntities_1' AND object_id = OBJECT_ID(N'cfg.LegalEntities')
)
    CREATE UNIQUE INDEX [UX_cfg_LegalEntities_1] ON [cfg].[LegalEntities] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_LegalEntities_2' AND object_id = OBJECT_ID(N'cfg.LegalEntities')
)
    CREATE UNIQUE INDEX [UX_cfg_LegalEntities_2] ON [cfg].[LegalEntities] ([TenantId], [Fiscal]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_LegalEntities_3' AND object_id = OBJECT_ID(N'cfg.LegalEntities')
)
    CREATE UNIQUE INDEX [UX_cfg_LegalEntities_3] ON [cfg].[LegalEntities] ([TenantId], [IsDefault]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Branches_1' AND object_id = OBJECT_ID(N'cfg.Branches')
)
    CREATE UNIQUE INDEX [UX_cfg_Branches_1] ON [cfg].[Branches] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_Workstations_1' AND object_id = OBJECT_ID(N'cfg.Workstations')
)
    CREATE UNIQUE INDEX [UX_cfg_Workstations_1] ON [cfg].[Workstations] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_PayrollOfficialCodes_1' AND object_id = OBJECT_ID(N'cfg.PayrollOfficialCodes')
)
    CREATE UNIQUE INDEX [UX_cfg_PayrollOfficialCodes_1] ON [cfg].[PayrollOfficialCodes] ([Type], [Code], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_ContributionRates_1' AND object_id = OBJECT_ID(N'cfg.ContributionRates')
)
    CREATE UNIQUE INDEX [UX_cfg_ContributionRates_1] ON [cfg].[ContributionRates] ([Subsystem], [Regime], [EmployerType], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_ContributionBaseLimits_1' AND object_id = OBJECT_ID(N'cfg.ContributionBaseLimits')
)
    CREATE UNIQUE INDEX [UX_cfg_ContributionBaseLimits_1] ON [cfg].[ContributionBaseLimits] ([Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_MinimumWages_1' AND object_id = OBJECT_ID(N'cfg.MinimumWages')
)
    CREATE UNIQUE INDEX [UX_cfg_MinimumWages_1] ON [cfg].[MinimumWages] ([ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_IncomeTaxDeductionTables_1' AND object_id = OBJECT_ID(N'cfg.IncomeTaxDeductionTables')
)
    CREATE UNIQUE INDEX [UX_cfg_IncomeTaxDeductionTables_1] ON [cfg].[IncomeTaxDeductionTables] ([Type], [Year], [Month]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_IncomeTaxScales_1' AND object_id = OBJECT_ID(N'cfg.IncomeTaxScales')
)
    CREATE UNIQUE INDEX [UX_cfg_IncomeTaxScales_1] ON [cfg].[IncomeTaxScales] ([Type], [Year], [Month], [From]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_IncomeTaxRules_1' AND object_id = OBJECT_ID(N'cfg.IncomeTaxRules')
)
    CREATE UNIQUE INDEX [UX_cfg_IncomeTaxRules_1] ON [cfg].[IncomeTaxRules] ([ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_CedularTaxScales_1' AND object_id = OBJECT_ID(N'cfg.CedularTaxScales')
)
    CREATE UNIQUE INDEX [UX_cfg_CedularTaxScales_1] ON [cfg].[CedularTaxScales] ([ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_GarnishmentScales_1' AND object_id = OBJECT_ID(N'cfg.GarnishmentScales')
)
    CREATE UNIQUE INDEX [UX_cfg_GarnishmentScales_1] ON [cfg].[GarnishmentScales] ([ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cfg_LaborLawParameters_1' AND object_id = OBJECT_ID(N'cfg.LaborLawParameters')
)
    CREATE UNIQUE INDEX [UX_cfg_LaborLawParameters_1] ON [cfg].[LaborLawParameters] ([ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_IntegrationProviders_1' AND object_id = OBJECT_ID(N'int.IntegrationProviders')
)
    CREATE UNIQUE INDEX [UX_int_IntegrationProviders_1] ON [int].[IntegrationProviders] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_IntegrationConnections_1' AND object_id = OBJECT_ID(N'int.IntegrationConnections')
)
    CREATE UNIQUE INDEX [UX_int_IntegrationConnections_1] ON [int].[IntegrationConnections] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_IntegrationSecrets_1' AND object_id = OBJECT_ID(N'int.IntegrationSecrets')
)
    CREATE UNIQUE INDEX [UX_int_IntegrationSecrets_1] ON [int].[IntegrationSecrets] ([TenantId], [Ref]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_IntegrationCertificates_1' AND object_id = OBJECT_ID(N'int.IntegrationCertificates')
)
    CREATE UNIQUE INDEX [UX_int_IntegrationCertificates_1] ON [int].[IntegrationCertificates] ([TenantId], [Issuer], [SerialNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_IntegrationTokens_1' AND object_id = OBJECT_ID(N'int.IntegrationTokens')
)
    CREATE UNIQUE INDEX [UX_int_IntegrationTokens_1] ON [int].[IntegrationTokens] ([TenantId], [ConnectionId], [Scope]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_IntegrationOperations_1' AND object_id = OBJECT_ID(N'int.IntegrationOperations')
)
    CREATE UNIQUE INDEX [UX_int_IntegrationOperations_1] ON [int].[IntegrationOperations] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_WebhookEndpoints_1' AND object_id = OBJECT_ID(N'int.WebhookEndpoints')
)
    CREATE UNIQUE INDEX [UX_int_WebhookEndpoints_1] ON [int].[WebhookEndpoints] ([TenantId], [Path]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_WebhookInbox_1' AND object_id = OBJECT_ID(N'int.WebhookInbox')
)
    CREATE UNIQUE INDEX [UX_int_WebhookInbox_1] ON [int].[WebhookInbox] ([TenantId], [EndpointId], [DedupKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_WebhookInbox_2' AND object_id = OBJECT_ID(N'int.WebhookInbox')
)
    CREATE UNIQUE INDEX [UX_int_WebhookInbox_2] ON [int].[WebhookInbox] ([TenantId], [EndpointId], [DedupeKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_FileLayouts_1' AND object_id = OBJECT_ID(N'int.FileLayouts')
)
    CREATE UNIQUE INDEX [UX_int_FileLayouts_1] ON [int].[FileLayouts] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_IntegrationFileExchanges_1' AND object_id = OBJECT_ID(N'int.IntegrationFileExchanges')
)
    CREATE UNIQUE INDEX [UX_int_IntegrationFileExchanges_1] ON [int].[IntegrationFileExchanges] ([TenantId], [ConnectionId], [Sha256]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_IntegrationFileExchanges_2' AND object_id = OBJECT_ID(N'int.IntegrationFileExchanges')
)
    CREATE UNIQUE INDEX [UX_int_IntegrationFileExchanges_2] ON [int].[IntegrationFileExchanges] ([TenantId], [ConnectionId], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_ExternalReferences_1' AND object_id = OBJECT_ID(N'int.ExternalReferences')
)
    CREATE UNIQUE INDEX [UX_int_ExternalReferences_1] ON [int].[ExternalReferences] ([TenantId], [System], [ExternalId], [EntityType]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_ExternalReferences_2' AND object_id = OBJECT_ID(N'int.ExternalReferences')
)
    CREATE UNIQUE INDEX [UX_int_ExternalReferences_2] ON [int].[ExternalReferences] ([TenantId], [ProviderCode], [ExternalId], [EntityType]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_LocalAgents_1' AND object_id = OBJECT_ID(N'int.LocalAgents')
)
    CREATE UNIQUE INDEX [UX_int_LocalAgents_1] ON [int].[LocalAgents] ([TenantId], [AgentCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_int_LocalAgentCommands_1' AND object_id = OBJECT_ID(N'int.LocalAgentCommands')
)
    CREATE UNIQUE INDEX [UX_int_LocalAgentCommands_1] ON [int].[LocalAgentCommands] ([TenantId], [CommandId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_MigrationProjects_1' AND object_id = OBJECT_ID(N'mig.MigrationProjects')
)
    CREATE UNIQUE INDEX [UX_mig_MigrationProjects_1] ON [mig].[MigrationProjects] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_LegacySnapshots_1' AND object_id = OBJECT_ID(N'mig.LegacySnapshots')
)
    CREATE UNIQUE INDEX [UX_mig_LegacySnapshots_1] ON [mig].[LegacySnapshots] ([TenantId], [ProjectId], [TakenAt]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_MigrationMappingSets_1' AND object_id = OBJECT_ID(N'mig.MigrationMappingSets')
)
    CREATE UNIQUE INDEX [UX_mig_MigrationMappingSets_1] ON [mig].[MigrationMappingSets] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_MigrationMappingRules_1' AND object_id = OBJECT_ID(N'mig.MigrationMappingRules')
)
    CREATE UNIQUE INDEX [UX_mig_MigrationMappingRules_1] ON [mig].[MigrationMappingRules] ([TenantId], [MappingSetId], [SourceTable], [Target]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_MigrationValueMaps_1' AND object_id = OBJECT_ID(N'mig.MigrationValueMaps')
)
    CREATE UNIQUE INDEX [UX_mig_MigrationValueMaps_1] ON [mig].[MigrationValueMaps] ([TenantId], [MappingSetId], [Domain], [SourceValue]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_MigrationRuns_1' AND object_id = OBJECT_ID(N'mig.MigrationRuns')
)
    CREATE UNIQUE INDEX [UX_mig_MigrationRuns_1] ON [mig].[MigrationRuns] ([TenantId], [ProjectId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_MigrationBatches_1' AND object_id = OBJECT_ID(N'mig.MigrationBatches')
)
    CREATE UNIQUE INDEX [UX_mig_MigrationBatches_1] ON [mig].[MigrationBatches] ([TenantId], [RunId], [SourceTable], [BatchNo]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_MigStagingRecords_1' AND object_id = OBJECT_ID(N'mig.MigStagingRecords')
)
    CREATE UNIQUE INDEX [UX_mig_MigStagingRecords_1] ON [mig].[MigStagingRecords] ([TenantId], [BatchId], [SourceKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_LegacyIdMap_1' AND object_id = OBJECT_ID(N'mig.LegacyIdMap')
)
    CREATE UNIQUE INDEX [UX_mig_LegacyIdMap_1] ON [mig].[LegacyIdMap] ([TenantId], [SourceTable], [SourceKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_LegacyKeyAliases_1' AND object_id = OBJECT_ID(N'mig.LegacyKeyAliases')
)
    CREATE UNIQUE INDEX [UX_mig_LegacyKeyAliases_1] ON [mig].[LegacyKeyAliases] ([TenantId], [Kind], [Alias]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_MigrationReconciliations_1' AND object_id = OBJECT_ID(N'mig.MigrationReconciliations')
)
    CREATE UNIQUE INDEX [UX_mig_MigrationReconciliations_1] ON [mig].[MigrationReconciliations] ([TenantId], [RunId], [Check]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_ParallelRuns_1' AND object_id = OBJECT_ID(N'mig.ParallelRuns')
)
    CREATE UNIQUE INDEX [UX_mig_ParallelRuns_1] ON [mig].[ParallelRuns] ([TenantId], [ProjectId], [Period], [Domain]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_ParallelComparisons_1' AND object_id = OBJECT_ID(N'mig.ParallelComparisons')
)
    CREATE UNIQUE INDEX [UX_mig_ParallelComparisons_1] ON [mig].[ParallelComparisons] ([TenantId], [ParallelRunId], [ItemKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_BypassPlans_1' AND object_id = OBJECT_ID(N'mig.BypassPlans')
)
    CREATE UNIQUE INDEX [UX_mig_BypassPlans_1] ON [mig].[BypassPlans] ([TenantId], [ProjectId], [ModuleCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_CutoverPlans_1' AND object_id = OBJECT_ID(N'mig.CutoverPlans')
)
    CREATE UNIQUE INDEX [UX_mig_CutoverPlans_1] ON [mig].[CutoverPlans] ([TenantId], [ProjectId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_LegacyRecords_1' AND object_id = OBJECT_ID(N'mig.LegacyRecords')
)
    CREATE UNIQUE INDEX [UX_mig_LegacyRecords_1] ON [mig].[LegacyRecords] ([TenantId], [LegacyTable], [LegacyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mig_AnonymizationProfiles_1' AND object_id = OBJECT_ID(N'mig.AnonymizationProfiles')
)
    CREATE UNIQUE INDEX [UX_mig_AnonymizationProfiles_1] ON [mig].[AnonymizationProfiles] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_DataCatalogEntries_1' AND object_id = OBJECT_ID(N'nfr.DataCatalogEntries')
)
    CREATE UNIQUE INDEX [UX_nfr_DataCatalogEntries_1] ON [nfr].[DataCatalogEntries] ([TenantId], [Collection], [Field]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_ProcessingActivities_1' AND object_id = OBJECT_ID(N'nfr.ProcessingActivities')
)
    CREATE UNIQUE INDEX [UX_nfr_ProcessingActivities_1] ON [nfr].[ProcessingActivities] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_PrivacyNotices_1' AND object_id = OBJECT_ID(N'nfr.PrivacyNotices')
)
    CREATE UNIQUE INDEX [UX_nfr_PrivacyNotices_1] ON [nfr].[PrivacyNotices] ([TenantId], [Channel], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_DataSubjectRequests_1' AND object_id = OBJECT_ID(N'nfr.DataSubjectRequests')
)
    CREATE UNIQUE INDEX [UX_nfr_DataSubjectRequests_1] ON [nfr].[DataSubjectRequests] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_RetentionPolicies_1' AND object_id = OBJECT_ID(N'nfr.RetentionPolicies')
)
    CREATE UNIQUE INDEX [UX_nfr_RetentionPolicies_1] ON [nfr].[RetentionPolicies] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_LegalHolds_1' AND object_id = OBJECT_ID(N'nfr.LegalHolds')
)
    CREATE UNIQUE INDEX [UX_nfr_LegalHolds_1] ON [nfr].[LegalHolds] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_ErasureLedger_1' AND object_id = OBJECT_ID(N'nfr.ErasureLedger')
)
    CREATE UNIQUE INDEX [UX_nfr_ErasureLedger_1] ON [nfr].[ErasureLedger] ([TenantId], [EntityRef]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_SecurityIncidents_1' AND object_id = OBJECT_ID(N'nfr.SecurityIncidents')
)
    CREATE UNIQUE INDEX [UX_nfr_SecurityIncidents_1] ON [nfr].[SecurityIncidents] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_EncryptionKeys_1' AND object_id = OBJECT_ID(N'nfr.EncryptionKeys')
)
    CREATE UNIQUE INDEX [UX_nfr_EncryptionKeys_1] ON [nfr].[EncryptionKeys] ([TenantId], [Category], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_Locks_1' AND object_id = OBJECT_ID(N'nfr.Locks')
)
    CREATE UNIQUE INDEX [UX_nfr_Locks_1] ON [nfr].[Locks] ([TenantId], [Resource]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_SloDefinitions_1' AND object_id = OBJECT_ID(N'nfr.SloDefinitions')
)
    CREATE UNIQUE INDEX [UX_nfr_SloDefinitions_1] ON [nfr].[SloDefinitions] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_QualityEvidence_1' AND object_id = OBJECT_ID(N'nfr.QualityEvidence')
)
    CREATE UNIQUE INDEX [UX_nfr_QualityEvidence_1] ON [nfr].[QualityEvidence] ([Wave], [Control]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_nfr_Subprocessors_1' AND object_id = OBJECT_ID(N'nfr.Subprocessors')
)
    CREATE UNIQUE INDEX [UX_nfr_Subprocessors_1] ON [nfr].[Subprocessors] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_Posts_1' AND object_id = OBJECT_ID(N'com.Posts')
)
    CREATE UNIQUE INDEX [UX_com_Posts_1] ON [com].[Posts] ([TenantId], [Slug]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_PostCategories_1' AND object_id = OBJECT_ID(N'com.PostCategories')
)
    CREATE UNIQUE INDEX [UX_com_PostCategories_1] ON [com].[PostCategories] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_PostTemplates_1' AND object_id = OBJECT_ID(N'com.PostTemplates')
)
    CREATE UNIQUE INDEX [UX_com_PostTemplates_1] ON [com].[PostTemplates] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_PostReactions_1' AND object_id = OBJECT_ID(N'com.PostReactions')
)
    CREATE UNIQUE INDEX [UX_com_PostReactions_1] ON [com].[PostReactions] ([TenantId], [PostId], [MembershipId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_PostDailyStats_1' AND object_id = OBJECT_ID(N'com.PostDailyStats')
)
    CREATE UNIQUE INDEX [UX_com_PostDailyStats_1] ON [com].[PostDailyStats] ([TenantId], [PostId], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_PostUserStates_1' AND object_id = OBJECT_ID(N'com.PostUserStates')
)
    CREATE UNIQUE INDEX [UX_com_PostUserStates_1] ON [com].[PostUserStates] ([TenantId], [PostId], [MembershipId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_GreetingRules_1' AND object_id = OBJECT_ID(N'com.GreetingRules')
)
    CREATE UNIQUE INDEX [UX_com_GreetingRules_1] ON [com].[GreetingRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_ModerationPolicies_1' AND object_id = OBJECT_ID(N'com.ModerationPolicies')
)
    CREATE UNIQUE INDEX [UX_com_ModerationPolicies_1] ON [com].[ModerationPolicies] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_ModerationRules_1' AND object_id = OBJECT_ID(N'com.ModerationRules')
)
    CREATE UNIQUE INDEX [UX_com_ModerationRules_1] ON [com].[ModerationRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_GuidelineAcceptances_1' AND object_id = OBJECT_ID(N'com.GuidelineAcceptances')
)
    CREATE UNIQUE INDEX [UX_com_GuidelineAcceptances_1] ON [com].[GuidelineAcceptances] ([TenantId], [MembershipId], [GuidelinesVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_GuidelineAcceptances_2' AND object_id = OBJECT_ID(N'com.GuidelineAcceptances')
)
    CREATE UNIQUE INDEX [UX_com_GuidelineAcceptances_2] ON [com].[GuidelineAcceptances] ([TenantId], [MembershipId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_NewsletterRules_1' AND object_id = OBJECT_ID(N'com.NewsletterRules')
)
    CREATE UNIQUE INDEX [UX_com_NewsletterRules_1] ON [com].[NewsletterRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_Newsletters_1' AND object_id = OBJECT_ID(N'com.Newsletters')
)
    CREATE UNIQUE INDEX [UX_com_Newsletters_1] ON [com].[Newsletters] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_NewsletterRecipients_1' AND object_id = OBJECT_ID(N'com.NewsletterRecipients')
)
    CREATE UNIQUE INDEX [UX_com_NewsletterRecipients_1] ON [com].[NewsletterRecipients] ([TenantId], [NewsletterId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_Surveys_1' AND object_id = OBJECT_ID(N'com.Surveys')
)
    CREATE UNIQUE INDEX [UX_com_Surveys_1] ON [com].[Surveys] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_SurveyResponses_1' AND object_id = OBJECT_ID(N'com.SurveyResponses')
)
    CREATE UNIQUE INDEX [UX_com_SurveyResponses_1] ON [com].[SurveyResponses] ([TenantId], [SurveyId], [RespondentKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_SurveyInvitations_1' AND object_id = OBJECT_ID(N'com.SurveyInvitations')
)
    CREATE UNIQUE INDEX [UX_com_SurveyInvitations_1] ON [com].[SurveyInvitations] ([TenantId], [SurveyId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_SurveyTemplates_1' AND object_id = OBJECT_ID(N'com.SurveyTemplates')
)
    CREATE UNIQUE INDEX [UX_com_SurveyTemplates_1] ON [com].[SurveyTemplates] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_SurveyCategories_1' AND object_id = OBJECT_ID(N'com.SurveyCategories')
)
    CREATE UNIQUE INDEX [UX_com_SurveyCategories_1] ON [com].[SurveyCategories] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_Events_1' AND object_id = OBJECT_ID(N'com.Events')
)
    CREATE UNIQUE INDEX [UX_com_Events_1] ON [com].[Events] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_EventRegistrations_1' AND object_id = OBJECT_ID(N'com.EventRegistrations')
)
    CREATE UNIQUE INDEX [UX_com_EventRegistrations_1] ON [com].[EventRegistrations] ([TenantId], [EventId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_BenefitPartners_1' AND object_id = OBJECT_ID(N'com.BenefitPartners')
)
    CREATE UNIQUE INDEX [UX_com_BenefitPartners_1] ON [com].[BenefitPartners] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_Benefits_1' AND object_id = OBJECT_ID(N'com.Benefits')
)
    CREATE UNIQUE INDEX [UX_com_Benefits_1] ON [com].[Benefits] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_BenefitRedemptions_1' AND object_id = OBJECT_ID(N'com.BenefitRedemptions')
)
    CREATE UNIQUE INDEX [UX_com_BenefitRedemptions_1] ON [com].[BenefitRedemptions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_AudienceSegments_1' AND object_id = OBJECT_ID(N'com.AudienceSegments')
)
    CREATE UNIQUE INDEX [UX_com_AudienceSegments_1] ON [com].[AudienceSegments] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_AudienceSnapshotMembers_1' AND object_id = OBJECT_ID(N'com.AudienceSnapshotMembers')
)
    CREATE UNIQUE INDEX [UX_com_AudienceSnapshotMembers_1] ON [com].[AudienceSnapshotMembers] ([TenantId], [SnapshotId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_CommunicationTypes_1' AND object_id = OBJECT_ID(N'com.CommunicationTypes')
)
    CREATE UNIQUE INDEX [UX_com_CommunicationTypes_1] ON [com].[CommunicationTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_MessageTemplates_1' AND object_id = OBJECT_ID(N'com.MessageTemplates')
)
    CREATE UNIQUE INDEX [UX_com_MessageTemplates_1] ON [com].[MessageTemplates] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_MessageTemplateVersions_1' AND object_id = OBJECT_ID(N'com.MessageTemplateVersions')
)
    CREATE UNIQUE INDEX [UX_com_MessageTemplateVersions_1] ON [com].[MessageTemplateVersions] ([TenantId], [TemplateId], [VersionNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_MessageTemplateVersions_2' AND object_id = OBJECT_ID(N'com.MessageTemplateVersions')
)
    CREATE UNIQUE INDEX [UX_com_MessageTemplateVersions_2] ON [com].[MessageTemplateVersions] ([TenantId], [TemplateId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_TemplateVariables_1' AND object_id = OBJECT_ID(N'com.TemplateVariables')
)
    CREATE UNIQUE INDEX [UX_com_TemplateVariables_1] ON [com].[TemplateVariables] ([Key]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_Communications_1' AND object_id = OBJECT_ID(N'com.Communications')
)
    CREATE UNIQUE INDEX [UX_com_Communications_1] ON [com].[Communications] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_CommunicationEvents_1' AND object_id = OBJECT_ID(N'com.CommunicationEvents')
)
    CREATE UNIQUE INDEX [UX_com_CommunicationEvents_1] ON [com].[CommunicationEvents] ([TenantId], [Provider], [ProviderEventId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_TrackedLinks_1' AND object_id = OBJECT_ID(N'com.TrackedLinks')
)
    CREATE UNIQUE INDEX [UX_com_TrackedLinks_1] ON [com].[TrackedLinks] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_SenderIdentities_1' AND object_id = OBJECT_ID(N'com.SenderIdentities')
)
    CREATE UNIQUE INDEX [UX_com_SenderIdentities_1] ON [com].[SenderIdentities] ([TenantId], [Channel], [Address]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_ChannelSettings_1' AND object_id = OBJECT_ID(N'com.ChannelSettings')
)
    CREATE UNIQUE INDEX [UX_com_ChannelSettings_1] ON [com].[ChannelSettings] ([TenantId], [Channel]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_MessagingUsage_1' AND object_id = OBJECT_ID(N'com.MessagingUsage')
)
    CREATE UNIQUE INDEX [UX_com_MessagingUsage_1] ON [com].[MessagingUsage] ([TenantId], [DayKey], [Channel], [Purpose], [CommunicationTypeCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_MessagingUsage_2' AND object_id = OBJECT_ID(N'com.MessagingUsage')
)
    CREATE UNIQUE INDEX [UX_com_MessagingUsage_2] ON [com].[MessagingUsage] ([TenantId], [Period], [Channel]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_InternalNotificationRules_1' AND object_id = OBJECT_ID(N'com.InternalNotificationRules')
)
    CREATE UNIQUE INDEX [UX_com_InternalNotificationRules_1] ON [com].[InternalNotificationRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_Campaigns_1' AND object_id = OBJECT_ID(N'com.Campaigns')
)
    CREATE UNIQUE INDEX [UX_com_Campaigns_1] ON [com].[Campaigns] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_InvoiceMessages_1' AND object_id = OBJECT_ID(N'com.InvoiceMessages')
)
    CREATE UNIQUE INDEX [UX_com_InvoiceMessages_1] ON [com].[InvoiceMessages] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_CommunicationPreferences_1' AND object_id = OBJECT_ID(N'com.CommunicationPreferences')
)
    CREATE UNIQUE INDEX [UX_com_CommunicationPreferences_1] ON [com].[CommunicationPreferences] ([TenantId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_SuppressionEntries_1' AND object_id = OBJECT_ID(N'com.SuppressionEntries')
)
    CREATE UNIQUE INDEX [UX_com_SuppressionEntries_1] ON [com].[SuppressionEntries] ([TenantId], [Channel], [AddressHmac]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_PushSubscriptions_1' AND object_id = OBJECT_ID(N'com.PushSubscriptions')
)
    CREATE UNIQUE INDEX [UX_com_PushSubscriptions_1] ON [com].[PushSubscriptions] ([TenantId], [EndpointHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_PlatformNoticeReads_1' AND object_id = OBJECT_ID(N'com.PlatformNoticeReads')
)
    CREATE UNIQUE INDEX [UX_com_PlatformNoticeReads_1] ON [com].[PlatformNoticeReads] ([TenantId], [NoticeId], [MembershipId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_com_OutageNotices_1' AND object_id = OBJECT_ID(N'com.OutageNotices')
)
    CREATE UNIQUE INDEX [UX_com_OutageNotices_1] ON [com].[OutageNotices] ([TenantId], [SourceKind], [SourceRefId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ReportDefinitions_1' AND object_id = OBJECT_ID(N'bia.ReportDefinitions')
)
    CREATE UNIQUE INDEX [UX_bia_ReportDefinitions_1] ON [bia].[ReportDefinitions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ReportPresets_1' AND object_id = OBJECT_ID(N'bia.ReportPresets')
)
    CREATE UNIQUE INDEX [UX_bia_ReportPresets_1] ON [bia].[ReportPresets] ([TenantId], [ReportCode], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ReportPresets_2' AND object_id = OBJECT_ID(N'bia.ReportPresets')
)
    CREATE UNIQUE INDEX [UX_bia_ReportPresets_2] ON [bia].[ReportPresets] ([TenantId], [ReportDefinitionId], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_SavedViews_1' AND object_id = OBJECT_ID(N'bia.SavedViews')
)
    CREATE UNIQUE INDEX [UX_bia_SavedViews_1] ON [bia].[SavedViews] ([TenantId], [OwnerUserId], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_SavedViews_2' AND object_id = OBJECT_ID(N'bia.SavedViews')
)
    CREATE UNIQUE INDEX [UX_bia_SavedViews_2] ON [bia].[SavedViews] ([TenantId], [OwnerId], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ReportSchedules_1' AND object_id = OBJECT_ID(N'bia.ReportSchedules')
)
    CREATE UNIQUE INDEX [UX_bia_ReportSchedules_1] ON [bia].[ReportSchedules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ReportTemplates_1' AND object_id = OBJECT_ID(N'bia.ReportTemplates')
)
    CREATE UNIQUE INDEX [UX_bia_ReportTemplates_1] ON [bia].[ReportTemplates] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ExportLayouts_1' AND object_id = OBJECT_ID(N'bia.ExportLayouts')
)
    CREATE UNIQUE INDEX [UX_bia_ExportLayouts_1] ON [bia].[ExportLayouts] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_IndicatorDefinitions_1' AND object_id = OBJECT_ID(N'bia.IndicatorDefinitions')
)
    CREATE UNIQUE INDEX [UX_bia_IndicatorDefinitions_1] ON [bia].[IndicatorDefinitions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_IndicatorSnapshots_1' AND object_id = OBJECT_ID(N'bia.IndicatorSnapshots')
)
    CREATE UNIQUE INDEX [UX_bia_IndicatorSnapshots_1] ON [bia].[IndicatorSnapshots] ([TenantId], [IndicatorCode], [PeriodKey], [DimensionKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_IndicatorSnapshots_2' AND object_id = OBJECT_ID(N'bia.IndicatorSnapshots')
)
    CREATE UNIQUE INDEX [UX_bia_IndicatorSnapshots_2] ON [bia].[IndicatorSnapshots] ([TenantId], [IndicatorId], [Date], [ScopeKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Dashboards_1' AND object_id = OBJECT_ID(N'bia.Dashboards')
)
    CREATE UNIQUE INDEX [UX_bia_Dashboards_1] ON [bia].[Dashboards] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_DashboardUserPrefs_1' AND object_id = OBJECT_ID(N'bia.DashboardUserPrefs')
)
    CREATE UNIQUE INDEX [UX_bia_DashboardUserPrefs_1] ON [bia].[DashboardUserPrefs] ([TenantId], [DashboardCode], [UserId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_DashboardUserPrefs_2' AND object_id = OBJECT_ID(N'bia.DashboardUserPrefs')
)
    CREATE UNIQUE INDEX [UX_bia_DashboardUserPrefs_2] ON [bia].[DashboardUserPrefs] ([TenantId], [DashboardId], [MembershipId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_KpiAlertRules_1' AND object_id = OBJECT_ID(N'bia.KpiAlertRules')
)
    CREATE UNIQUE INDEX [UX_bia_KpiAlertRules_1] ON [bia].[KpiAlertRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_AnalyticsDatasets_1' AND object_id = OBJECT_ID(N'bia.AnalyticsDatasets')
)
    CREATE UNIQUE INDEX [UX_bia_AnalyticsDatasets_1] ON [bia].[AnalyticsDatasets] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_CustomReports_1' AND object_id = OBJECT_ID(N'bia.CustomReports')
)
    CREATE UNIQUE INDEX [UX_bia_CustomReports_1] ON [bia].[CustomReports] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ApiUsageDaily_1' AND object_id = OBJECT_ID(N'bia.ApiUsageDaily')
)
    CREATE UNIQUE INDEX [UX_bia_ApiUsageDaily_1] ON [bia].[ApiUsageDaily] ([TenantId], [ApiClientId], [Date], [Route], [Status]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ApiUsageDaily_2' AND object_id = OBJECT_ID(N'bia.ApiUsageDaily')
)
    CREATE UNIQUE INDEX [UX_bia_ApiUsageDaily_2] ON [bia].[ApiUsageDaily] ([TenantId], [ApiClientId], [Day]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ApiUsageDaily_3' AND object_id = OBJECT_ID(N'bia.ApiUsageDaily')
)
    CREATE UNIQUE INDEX [UX_bia_ApiUsageDaily_3] ON [bia].[ApiUsageDaily] ([TenantId], [ApiClientId], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ExtWebhookSubscriptions_1' AND object_id = OBJECT_ID(N'bia.ExtWebhookSubscriptions')
)
    CREATE UNIQUE INDEX [UX_bia_ExtWebhookSubscriptions_1] ON [bia].[ExtWebhookSubscriptions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ExtWebhookDeliveries_1' AND object_id = OBJECT_ID(N'bia.ExtWebhookDeliveries')
)
    CREATE UNIQUE INDEX [UX_bia_ExtWebhookDeliveries_1] ON [bia].[ExtWebhookDeliveries] ([TenantId], [SubscriptionId], [EventId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_OpenDataPublications_1' AND object_id = OBJECT_ID(N'bia.OpenDataPublications')
)
    CREATE UNIQUE INDEX [UX_bia_OpenDataPublications_1] ON [bia].[OpenDataPublications] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_BenchmarkParticipations_1' AND object_id = OBJECT_ID(N'bia.BenchmarkParticipations')
)
    CREATE UNIQUE INDEX [UX_bia_BenchmarkParticipations_1] ON [bia].[BenchmarkParticipations] ([TenantId], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_BenchmarkAggregates_1' AND object_id = OBJECT_ID(N'bia.BenchmarkAggregates')
)
    CREATE UNIQUE INDEX [UX_bia_BenchmarkAggregates_1] ON [bia].[BenchmarkAggregates] ([IndicatorCode], [PeriodKey], [SegmentKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_BenchmarkAggregates_2' AND object_id = OBJECT_ID(N'bia.BenchmarkAggregates')
)
    CREATE UNIQUE INDEX [UX_bia_BenchmarkAggregates_2] ON [bia].[BenchmarkAggregates] ([Period], [Metric]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_ReportRunResults_1' AND object_id = OBJECT_ID(N'bia.ReportRunResults')
)
    CREATE UNIQUE INDEX [UX_bia_ReportRunResults_1] ON [bia].[ReportRunResults] ([TenantId], [ReportRunId], [RowNo]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_date_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_date')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_date_1] ON [bia].[Bi_dim_date] ([DateKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_person_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_person')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_person_1] ON [bia].[Bi_dim_person] ([PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_account_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_account')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_account_1] ON [bia].[Bi_dim_account] ([AccountId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_contract_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_contract')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_contract_1] ON [bia].[Bi_dim_contract] ([ContractId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_service_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_service')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_service_1] ON [bia].[Bi_dim_service] ([ServiceId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_category_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_category')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_category_1] ON [bia].[Bi_dim_category] ([CategoryId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_plan_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_plan')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_plan_1] ON [bia].[Bi_dim_plan] ([PlanVersionId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_product_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_product')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_product_1] ON [bia].[Bi_dim_product] ([ServiceProductId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_concept_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_concept')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_concept_1] ON [bia].[Bi_dim_concept] ([ConceptId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_channel_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_channel')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_channel_1] ON [bia].[Bi_dim_channel] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_cashbox_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_cashbox')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_cashbox_1] ON [bia].[Bi_dim_cashbox] ([CashRegisterId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_crew_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_crew')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_crew_1] ON [bia].[Bi_dim_crew] ([CrewId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_supplier_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_supplier')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_supplier_1] ON [bia].[Bi_dim_supplier] ([SupplierId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_glAccount_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_glAccount')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_glAccount_1] ON [bia].[Bi_dim_glAccount] ([LedgerAccountId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_costCenter_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_costCenter')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_costCenter_1] ON [bia].[Bi_dim_costCenter] ([CostCenterId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_employee_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_employee')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_employee_1] ON [bia].[Bi_dim_employee] ([EmployeeId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_branch_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_branch')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_branch_1] ON [bia].[Bi_dim_branch] ([BranchId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_dim_zone_1' AND object_id = OBJECT_ID(N'bia.Bi_dim_zone')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_dim_zone_1] ON [bia].[Bi_dim_zone] ([ZoneId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_invoice_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_invoice')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_invoice_1] ON [bia].[Bi_fact_invoice] ([InvoiceId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_invoiceLine_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_invoiceLine')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_invoiceLine_1] ON [bia].[Bi_fact_invoiceLine] ([InvoiceId], [LineId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_payment_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_payment')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_payment_1] ON [bia].[Bi_fact_payment] ([ReceiptId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_allocation_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_allocation')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_allocation_1] ON [bia].[Bi_fact_allocation] ([AllocationId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_ledgerEntry_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_ledgerEntry')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_ledgerEntry_1] ON [bia].[Bi_fact_ledgerEntry] ([LedgerEntryId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_consumption_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_consumption')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_consumption_1] ON [bia].[Bi_fact_consumption] ([ConsumptionId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_reading_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_reading')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_reading_1] ON [bia].[Bi_fact_reading] ([MeterReadingId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_arrears_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_arrears')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_arrears_1] ON [bia].[Bi_fact_arrears] ([AccountId], [CutoffDate]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_agreement_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_agreement')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_agreement_1] ON [bia].[Bi_fact_agreement] ([AgreementId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_ticket_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_ticket')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_ticket_1] ON [bia].[Bi_fact_ticket] ([CrmCaseId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_workOrder_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_workOrder')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_workOrder_1] ON [bia].[Bi_fact_workOrder] ([WorkOrderId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_turn_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_turn')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_turn_1] ON [bia].[Bi_fact_turn] ([CrmQueueTicketId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_stockMovement_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_stockMovement')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_stockMovement_1] ON [bia].[Bi_fact_stockMovement] ([StockMovementId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_purchase_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_purchase')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_purchase_1] ON [bia].[Bi_fact_purchase] ([SupplierInvoiceId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_treasury_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_treasury')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_treasury_1] ON [bia].[Bi_fact_treasury] ([TreasuryMovementId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_journalLine_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_journalLine')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_journalLine_1] ON [bia].[Bi_fact_journalLine] ([JournalLineId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_payroll_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_payroll')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_payroll_1] ON [bia].[Bi_fact_payroll] ([PayslipId], [ConceptCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_member_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_member')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_member_1] ON [bia].[Bi_fact_member] ([AssociateMembershipId], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_communication_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_communication')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_communication_1] ON [bia].[Bi_fact_communication] ([CommunicationId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_fact_apiUsage_1' AND object_id = OBJECT_ID(N'bia.Bi_fact_apiUsage')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_fact_apiUsage_1] ON [bia].[Bi_fact_apiUsage] ([ApiClientId], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_bia_Bi_snap_balance_1' AND object_id = OBJECT_ID(N'bia.Bi_snap_balance')
)
    CREATE UNIQUE INDEX [UX_bia_Bi_snap_balance_1] ON [bia].[Bi_snap_balance] ([CurrentAccountId], [CutoffDate]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_EventTypes_1' AND object_id = OBJECT_ID(N'wfl.EventTypes')
)
    CREATE UNIQUE INDEX [UX_wfl_EventTypes_1] ON [wfl].[EventTypes] ([Type], [SchemaVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_EventSubscriptions_1' AND object_id = OBJECT_ID(N'wfl.EventSubscriptions')
)
    CREATE UNIQUE INDEX [UX_wfl_EventSubscriptions_1] ON [wfl].[EventSubscriptions] ([TenantId], [Type], [Consumer]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_OperationalInboxItems_1' AND object_id = OBJECT_ID(N'wfl.OperationalInboxItems')
)
    CREATE UNIQUE INDEX [UX_wfl_OperationalInboxItems_1] ON [wfl].[OperationalInboxItems] ([TenantId], [SourceRef], [Kind]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_JobDefinitions_1' AND object_id = OBJECT_ID(N'wfl.JobDefinitions')
)
    CREATE UNIQUE INDEX [UX_wfl_JobDefinitions_1] ON [wfl].[JobDefinitions] ([Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_JobDefinitions_2' AND object_id = OBJECT_ID(N'wfl.JobDefinitions')
)
    CREATE UNIQUE INDEX [UX_wfl_JobDefinitions_2] ON [wfl].[JobDefinitions] ([Antes]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_JobSchedules_1' AND object_id = OBJECT_ID(N'wfl.JobSchedules')
)
    CREATE UNIQUE INDEX [UX_wfl_JobSchedules_1] ON [wfl].[JobSchedules] ([TenantId], [JobName]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_BulkRuns_1' AND object_id = OBJECT_ID(N'wfl.BulkRuns')
)
    CREATE UNIQUE INDEX [UX_wfl_BulkRuns_1] ON [wfl].[BulkRuns] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_BulkRunItems_1' AND object_id = OBJECT_ID(N'wfl.BulkRunItems')
)
    CREATE UNIQUE INDEX [UX_wfl_BulkRunItems_1] ON [wfl].[BulkRunItems] ([TenantId], [BulkRunId], [ItemKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_OperationTypes_1' AND object_id = OBJECT_ID(N'wfl.OperationTypes')
)
    CREATE UNIQUE INDEX [UX_wfl_OperationTypes_1] ON [wfl].[OperationTypes] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_Operations_1' AND object_id = OBJECT_ID(N'wfl.Operations')
)
    CREATE UNIQUE INDEX [UX_wfl_Operations_1] ON [wfl].[Operations] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_OperationSteps_1' AND object_id = OBJECT_ID(N'wfl.OperationSteps')
)
    CREATE UNIQUE INDEX [UX_wfl_OperationSteps_1] ON [wfl].[OperationSteps] ([TenantId], [OperationId], [Order]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_StateMachineRegistry_1' AND object_id = OBJECT_ID(N'wfl.StateMachineRegistry')
)
    CREATE UNIQUE INDEX [UX_wfl_StateMachineRegistry_1] ON [wfl].[StateMachineRegistry] ([Module], [Entity], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_StateMachineRegistry_2' AND object_id = OBJECT_ID(N'wfl.StateMachineRegistry')
)
    CREATE UNIQUE INDEX [UX_wfl_StateMachineRegistry_2] ON [wfl].[StateMachineRegistry] ([Entity], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_WorkflowDefinitions_1' AND object_id = OBJECT_ID(N'wfl.WorkflowDefinitions')
)
    CREATE UNIQUE INDEX [UX_wfl_WorkflowDefinitions_1] ON [wfl].[WorkflowDefinitions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_WorkflowVersions_1' AND object_id = OBJECT_ID(N'wfl.WorkflowVersions')
)
    CREATE UNIQUE INDEX [UX_wfl_WorkflowVersions_1] ON [wfl].[WorkflowVersions] ([TenantId], [WorkflowDefinitionId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_WorkflowInstances_1' AND object_id = OBJECT_ID(N'wfl.WorkflowInstances')
)
    CREATE UNIQUE INDEX [UX_wfl_WorkflowInstances_1] ON [wfl].[WorkflowInstances] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_SlaPolicies_1' AND object_id = OBJECT_ID(N'wfl.SlaPolicies')
)
    CREATE UNIQUE INDEX [UX_wfl_SlaPolicies_1] ON [wfl].[SlaPolicies] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_SlaTimers_1' AND object_id = OBJECT_ID(N'wfl.SlaTimers')
)
    CREATE UNIQUE INDEX [UX_wfl_SlaTimers_1] ON [wfl].[SlaTimers] ([TenantId], [TargetRef], [SlaPolicyId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_FormDefinitions_1' AND object_id = OBJECT_ID(N'wfl.FormDefinitions')
)
    CREATE UNIQUE INDEX [UX_wfl_FormDefinitions_1] ON [wfl].[FormDefinitions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_FormVersions_1' AND object_id = OBJECT_ID(N'wfl.FormVersions')
)
    CREATE UNIQUE INDEX [UX_wfl_FormVersions_1] ON [wfl].[FormVersions] ([TenantId], [FormDefinitionId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_ActionCatalog_1' AND object_id = OBJECT_ID(N'wfl.ActionCatalog')
)
    CREATE UNIQUE INDEX [UX_wfl_ActionCatalog_1] ON [wfl].[ActionCatalog] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_DataSourceCatalog_1' AND object_id = OBJECT_ID(N'wfl.DataSourceCatalog')
)
    CREATE UNIQUE INDEX [UX_wfl_DataSourceCatalog_1] ON [wfl].[DataSourceCatalog] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_ApprovalPolicies_1' AND object_id = OBJECT_ID(N'wfl.ApprovalPolicies')
)
    CREATE UNIQUE INDEX [UX_wfl_ApprovalPolicies_1] ON [wfl].[ApprovalPolicies] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_ApprovalRequests_1' AND object_id = OBJECT_ID(N'wfl.ApprovalRequests')
)
    CREATE UNIQUE INDEX [UX_wfl_ApprovalRequests_1] ON [wfl].[ApprovalRequests] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_ApprovalSteps_1' AND object_id = OBJECT_ID(N'wfl.ApprovalSteps')
)
    CREATE UNIQUE INDEX [UX_wfl_ApprovalSteps_1] ON [wfl].[ApprovalSteps] ([TenantId], [ApprovalRequestId], [Order]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_ApprovalDecisions_1' AND object_id = OBJECT_ID(N'wfl.ApprovalDecisions')
)
    CREATE UNIQUE INDEX [UX_wfl_ApprovalDecisions_1] ON [wfl].[ApprovalDecisions] ([TenantId], [ApprovalStepId], [DecidedBy]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_WorkItems_1' AND object_id = OBJECT_ID(N'wfl.WorkItems')
)
    CREATE UNIQUE INDEX [UX_wfl_WorkItems_1] ON [wfl].[WorkItems] ([TenantId], [SourceType], [SourceId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_WorkItems_2' AND object_id = OBJECT_ID(N'wfl.WorkItems')
)
    CREATE UNIQUE INDEX [UX_wfl_WorkItems_2] ON [wfl].[WorkItems] ([TenantId], [SourceRef], [AssigneeId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_AgendaEntries_1' AND object_id = OBJECT_ID(N'wfl.AgendaEntries')
)
    CREATE UNIQUE INDEX [UX_wfl_AgendaEntries_1] ON [wfl].[AgendaEntries] ([TenantId], [SourceType], [SourceId], [UserId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_AgendaFeeds_1' AND object_id = OBJECT_ID(N'wfl.AgendaFeeds')
)
    CREATE UNIQUE INDEX [UX_wfl_AgendaFeeds_1] ON [wfl].[AgendaFeeds] ([TenantId], [TokenHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_DocumentTypes_1' AND object_id = OBJECT_ID(N'wfl.DocumentTypes')
)
    CREATE UNIQUE INDEX [UX_wfl_DocumentTypes_1] ON [wfl].[DocumentTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_Documents_1' AND object_id = OBJECT_ID(N'wfl.Documents')
)
    CREATE UNIQUE INDEX [UX_wfl_Documents_1] ON [wfl].[Documents] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_DocumentVersions_1' AND object_id = OBJECT_ID(N'wfl.DocumentVersions')
)
    CREATE UNIQUE INDEX [UX_wfl_DocumentVersions_1] ON [wfl].[DocumentVersions] ([TenantId], [DocumentId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_DocumentLinks_1' AND object_id = OBJECT_ID(N'wfl.DocumentLinks')
)
    CREATE UNIQUE INDEX [UX_wfl_DocumentLinks_1] ON [wfl].[DocumentLinks] ([TenantId], [DocumentId], [SubjectType], [SubjectId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_ShareLinks_1' AND object_id = OBJECT_ID(N'wfl.ShareLinks')
)
    CREATE UNIQUE INDEX [UX_wfl_ShareLinks_1] ON [wfl].[ShareLinks] ([TenantId], [TokenHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_DocumentTemplates_1' AND object_id = OBJECT_ID(N'wfl.DocumentTemplates')
)
    CREATE UNIQUE INDEX [UX_wfl_DocumentTemplates_1] ON [wfl].[DocumentTemplates] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_TemplateVersions_1' AND object_id = OBJECT_ID(N'wfl.TemplateVersions')
)
    CREATE UNIQUE INDEX [UX_wfl_TemplateVersions_1] ON [wfl].[TemplateVersions] ([TenantId], [DocumentTemplateId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_TemplateDataContracts_1' AND object_id = OBJECT_ID(N'wfl.TemplateDataContracts')
)
    CREATE UNIQUE INDEX [UX_wfl_TemplateDataContracts_1] ON [wfl].[TemplateDataContracts] ([Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_RenderRequests_1' AND object_id = OBJECT_ID(N'wfl.RenderRequests')
)
    CREATE UNIQUE INDEX [UX_wfl_RenderRequests_1] ON [wfl].[RenderRequests] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_NumberingSequences_1' AND object_id = OBJECT_ID(N'wfl.NumberingSequences')
)
    CREATE UNIQUE INDEX [UX_wfl_NumberingSequences_1] ON [wfl].[NumberingSequences] ([TenantId], [Code], [ScopeHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_NumberingSequences_2' AND object_id = OBJECT_ID(N'wfl.NumberingSequences')
)
    CREATE UNIQUE INDEX [UX_wfl_NumberingSequences_2] ON [wfl].[NumberingSequences] ([TenantId], [Code], [LegalEntityId], [PeriodKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_NumberingAssignments_1' AND object_id = OBJECT_ID(N'wfl.NumberingAssignments')
)
    CREATE UNIQUE INDEX [UX_wfl_NumberingAssignments_1] ON [wfl].[NumberingAssignments] ([TenantId], [NumberingSequenceId], [Value]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_SignatureProfiles_1' AND object_id = OBJECT_ID(N'wfl.SignatureProfiles')
)
    CREATE UNIQUE INDEX [UX_wfl_SignatureProfiles_1] ON [wfl].[SignatureProfiles] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_SignatureRequests_1' AND object_id = OBJECT_ID(N'wfl.SignatureRequests')
)
    CREATE UNIQUE INDEX [UX_wfl_SignatureRequests_1] ON [wfl].[SignatureRequests] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_SignatureParticipants_1' AND object_id = OBJECT_ID(N'wfl.SignatureParticipants')
)
    CREATE UNIQUE INDEX [UX_wfl_SignatureParticipants_1] ON [wfl].[SignatureParticipants] ([TenantId], [SignatureRequestId], [Order]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_SignatureParticipants_2' AND object_id = OBJECT_ID(N'wfl.SignatureParticipants')
)
    CREATE UNIQUE INDEX [UX_wfl_SignatureParticipants_2] ON [wfl].[SignatureParticipants] ([TenantId], [SignatureRequestId], [PersonId], [Role]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_Dossiers_1' AND object_id = OBJECT_ID(N'wfl.Dossiers')
)
    CREATE UNIQUE INDEX [UX_wfl_Dossiers_1] ON [wfl].[Dossiers] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_DossierTimeline_1' AND object_id = OBJECT_ID(N'wfl.DossierTimeline')
)
    CREATE UNIQUE INDEX [UX_wfl_DossierTimeline_1] ON [wfl].[DossierTimeline] ([TenantId], [SubjectRef], [EventId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_wfl_DossierTimeline_2' AND object_id = OBJECT_ID(N'wfl.DossierTimeline')
)
    CREATE UNIQUE INDEX [UX_wfl_DossierTimeline_2] ON [wfl].[DossierTimeline] ([TenantId], [DossierId], [SourceRef]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_PersonIdentifierIndex_1' AND object_id = OBJECT_ID(N'per.PersonIdentifierIndex')
)
    CREATE UNIQUE INDEX [UX_per_PersonIdentifierIndex_1] ON [per].[PersonIdentifierIndex] ([TenantId], [DocumentTypeId], [Number], [ExceptionId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_PersonSensitiveData_1' AND object_id = OBJECT_ID(N'per.PersonSensitiveData')
)
    CREATE UNIQUE INDEX [UX_per_PersonSensitiveData_1] ON [per].[PersonSensitiveData] ([TenantId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_Holders_1' AND object_id = OBJECT_ID(N'per.Holders')
)
    CREATE UNIQUE INDEX [UX_per_Holders_1] ON [per].[Holders] ([TenantId], [HolderNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_Accounts_1' AND object_id = OBJECT_ID(N'per.Accounts')
)
    CREATE UNIQUE INDEX [UX_per_Accounts_1] ON [per].[Accounts] ([TenantId], [HolderId], [IsPrincipal:]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_ServicePoints_1' AND object_id = OBJECT_ID(N'per.ServicePoints')
)
    CREATE UNIQUE INDEX [UX_per_ServicePoints_1] ON [per].[ServicePoints] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_Relationships_1' AND object_id = OBJECT_ID(N'per.Relationships')
)
    CREATE UNIQUE INDEX [UX_per_Relationships_1] ON [per].[Relationships] ([TenantId], [SubjectPersonId], [TargetType], [TargetId], [RelationshipTypeId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_Relationships_2' AND object_id = OBJECT_ID(N'per.Relationships')
)
    CREATE UNIQUE INDEX [UX_per_Relationships_2] ON [per].[Relationships] ([TenantId], [FromPersonId], [ToPersonId], [RelationshipTypeId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_Blocks_1' AND object_id = OBJECT_ID(N'per.Blocks')
)
    CREATE UNIQUE INDEX [UX_per_Blocks_1] ON [per].[Blocks] ([TenantId], [SubjectRef], [HoldReasonId], [Status:]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_DocumentRequirementTypes_1' AND object_id = OBJECT_ID(N'per.DocumentRequirementTypes')
)
    CREATE UNIQUE INDEX [UX_per_DocumentRequirementTypes_1] ON [per].[DocumentRequirementTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_Transfers_1' AND object_id = OBJECT_ID(N'per.Transfers')
)
    CREATE UNIQUE INDEX [UX_per_Transfers_1] ON [per].[Transfers] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_PerRevisions_1' AND object_id = OBJECT_ID(N'per.PerRevisions')
)
    CREATE UNIQUE INDEX [UX_per_PerRevisions_1] ON [per].[PerRevisions] ([TenantId], [EntityType], [EntityId], [Revision]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_per_PerRevisions_2' AND object_id = OBJECT_ID(N'per.PerRevisions')
)
    CREATE UNIQUE INDEX [UX_per_PerRevisions_2] ON [per].[PerRevisions] ([TenantId], [SubjectRef], [Revision]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceCapabilities_1' AND object_id = OBJECT_ID(N'cat.ServiceCapabilities')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceCapabilities_1] ON [cat].[ServiceCapabilities] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_TenantServices_1' AND object_id = OBJECT_ID(N'cat.TenantServices')
)
    CREATE UNIQUE INDEX [UX_cat_TenantServices_1] ON [cat].[TenantServices] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceConfigVersions_1' AND object_id = OBJECT_ID(N'cat.ServiceConfigVersions')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceConfigVersions_1] ON [cat].[ServiceConfigVersions] ([TenantId], [ServiceId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceConcessions_1' AND object_id = OBJECT_ID(N'cat.ServiceConcessions')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceConcessions_1] ON [cat].[ServiceConcessions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceProducts_1' AND object_id = OBJECT_ID(N'cat.ServiceProducts')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceProducts_1] ON [cat].[ServiceProducts] ([TenantId], [ServiceId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_BillableConcepts_1' AND object_id = OBJECT_ID(N'cat.BillableConcepts')
)
    CREATE UNIQUE INDEX [UX_cat_BillableConcepts_1] ON [cat].[BillableConcepts] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServicePlans_1' AND object_id = OBJECT_ID(N'cat.ServicePlans')
)
    CREATE UNIQUE INDEX [UX_cat_ServicePlans_1] ON [cat].[ServicePlans] ([TenantId], [ServiceId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServicePlanVersions_1' AND object_id = OBJECT_ID(N'cat.ServicePlanVersions')
)
    CREATE UNIQUE INDEX [UX_cat_ServicePlanVersions_1] ON [cat].[ServicePlanVersions] ([TenantId], [PlanId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceBundles_1' AND object_id = OBJECT_ID(N'cat.ServiceBundles')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceBundles_1] ON [cat].[ServiceBundles] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceCategories_1' AND object_id = OBJECT_ID(N'cat.ServiceCategories')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceCategories_1] ON [cat].[ServiceCategories] ([TenantId], [ServiceId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceCategoryGroups_1' AND object_id = OBJECT_ID(N'cat.ServiceCategoryGroups')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceCategoryGroups_1] ON [cat].[ServiceCategoryGroups] ([TenantId], [ServiceId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceClasses_1' AND object_id = OBJECT_ID(N'cat.ServiceClasses')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceClasses_1] ON [cat].[ServiceClasses] ([TenantId], [ServiceId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceProperties_1' AND object_id = OBJECT_ID(N'cat.ServiceProperties')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceProperties_1] ON [cat].[ServiceProperties] ([TenantId], [ServiceId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceStatuses_1' AND object_id = OBJECT_ID(N'cat.ServiceStatuses')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceStatuses_1] ON [cat].[ServiceStatuses] ([TenantId], [ServiceId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_AutoServiceRules_1' AND object_id = OBJECT_ID(N'cat.AutoServiceRules')
)
    CREATE UNIQUE INDEX [UX_cat_AutoServiceRules_1] ON [cat].[AutoServiceRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceContracts_1' AND object_id = OBJECT_ID(N'cat.ServiceContracts')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceContracts_1] ON [cat].[ServiceContracts] ([TenantId], [ServiceId], [SupplyCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ContractEquipmentAssignments_1' AND object_id = OBJECT_ID(N'cat.ContractEquipmentAssignments')
)
    CREATE UNIQUE INDEX [UX_cat_ContractEquipmentAssignments_1] ON [cat].[ContractEquipmentAssignments] ([TenantId], [SerialUnitId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ApplianceTypes_1' AND object_id = OBJECT_ID(N'cat.ApplianceTypes')
)
    CREATE UNIQUE INDEX [UX_cat_ApplianceTypes_1] ON [cat].[ApplianceTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ContractSpecialConditions_1' AND object_id = OBJECT_ID(N'cat.ContractSpecialConditions')
)
    CREATE UNIQUE INDEX [UX_cat_ContractSpecialConditions_1] ON [cat].[ContractSpecialConditions] ([TenantId], [ContractId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceCopyRuns_1' AND object_id = OBJECT_ID(N'cat.ServiceCopyRuns')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceCopyRuns_1] ON [cat].[ServiceCopyRuns] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cat_ServiceTemplates_1' AND object_id = OBJECT_ID(N'cat.ServiceTemplates')
)
    CREATE UNIQUE INDEX [UX_cat_ServiceTemplates_1] ON [cat].[ServiceTemplates] ([Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_MeterBrands_1' AND object_id = OBJECT_ID(N'med.MeterBrands')
)
    CREATE UNIQUE INDEX [UX_med_MeterBrands_1] ON [med].[MeterBrands] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_MeterTypes_1' AND object_id = OBJECT_ID(N'med.MeterTypes')
)
    CREATE UNIQUE INDEX [UX_med_MeterTypes_1] ON [med].[MeterTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ReadingObservationCodes_1' AND object_id = OBJECT_ID(N'med.ReadingObservationCodes')
)
    CREATE UNIQUE INDEX [UX_med_ReadingObservationCodes_1] ON [med].[ReadingObservationCodes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ReadingResultCodes_1' AND object_id = OBJECT_ID(N'med.ReadingResultCodes')
)
    CREATE UNIQUE INDEX [UX_med_ReadingResultCodes_1] ON [med].[ReadingResultCodes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ReadingConditionCodes_1' AND object_id = OBJECT_ID(N'med.ReadingConditionCodes')
)
    CREATE UNIQUE INDEX [UX_med_ReadingConditionCodes_1] ON [med].[ReadingConditionCodes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_MeterObservationCodes_1' AND object_id = OBJECT_ID(N'med.MeterObservationCodes')
)
    CREATE UNIQUE INDEX [UX_med_MeterObservationCodes_1] ON [med].[MeterObservationCodes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_Meters_1' AND object_id = OBJECT_ID(N'med.Meters')
)
    CREATE UNIQUE INDEX [UX_med_Meters_1] ON [med].[Meters] ([TenantId], [ServiceId], [BrandId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_MeteringPoints_1' AND object_id = OBJECT_ID(N'med.MeteringPoints')
)
    CREATE UNIQUE INDEX [UX_med_MeteringPoints_1] ON [med].[MeteringPoints] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_MeteringChannels_1' AND object_id = OBJECT_ID(N'med.MeteringChannels')
)
    CREATE UNIQUE INDEX [UX_med_MeteringChannels_1] ON [med].[MeteringChannels] ([TenantId], [MeteringPointId], [ChannelType], [TouBand], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_MeterInstallations_1' AND object_id = OBJECT_ID(N'med.MeterInstallations')
)
    CREATE UNIQUE INDEX [UX_med_MeterInstallations_1] ON [med].[MeterInstallations] ([TenantId], [MeterId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ReadingRoutes_1' AND object_id = OBJECT_ID(N'med.ReadingRoutes')
)
    CREATE UNIQUE INDEX [UX_med_ReadingRoutes_1] ON [med].[ReadingRoutes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ReadingCalendars_1' AND object_id = OBJECT_ID(N'med.ReadingCalendars')
)
    CREATE UNIQUE INDEX [UX_med_ReadingCalendars_1] ON [med].[ReadingCalendars] ([TenantId], [ServiceId], [CycleCode], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ReadingBatches_1' AND object_id = OBJECT_ID(N'med.ReadingBatches')
)
    CREATE UNIQUE INDEX [UX_med_ReadingBatches_1] ON [med].[ReadingBatches] ([TenantId], [RouteId], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ReadingTasks_1' AND object_id = OBJECT_ID(N'med.ReadingTasks')
)
    CREATE UNIQUE INDEX [UX_med_ReadingTasks_1] ON [med].[ReadingTasks] ([TenantId], [MeteringPointId], [BatchId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ReaderWorkSessions_1' AND object_id = OBJECT_ID(N'med.ReaderWorkSessions')
)
    CREATE UNIQUE INDEX [UX_med_ReaderWorkSessions_1] ON [med].[ReaderWorkSessions] ([TenantId], [ReaderId], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_MeterReadings_1' AND object_id = OBJECT_ID(N'med.MeterReadings')
)
    CREATE UNIQUE INDEX [UX_med_MeterReadings_1] ON [med].[MeterReadings] ([TenantId], [ClientMutationId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ConsumptionDistributions_1' AND object_id = OBJECT_ID(N'med.ConsumptionDistributions')
)
    CREATE UNIQUE INDEX [UX_med_ConsumptionDistributions_1] ON [med].[ConsumptionDistributions] ([TenantId], [Children]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_DemandDeclarations_1' AND object_id = OBJECT_ID(N'med.DemandDeclarations')
)
    CREATE UNIQUE INDEX [UX_med_DemandDeclarations_1] ON [med].[DemandDeclarations] ([TenantId], [ChannelId], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_DemandTransgressions_1' AND object_id = OBJECT_ID(N'med.DemandTransgressions')
)
    CREATE UNIQUE INDEX [UX_med_DemandTransgressions_1] ON [med].[DemandTransgressions] ([TenantId], [ChannelId], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ReadingImportProfiles_1' AND object_id = OBJECT_ID(N'med.ReadingImportProfiles')
)
    CREATE UNIQUE INDEX [UX_med_ReadingImportProfiles_1] ON [med].[ReadingImportProfiles] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_ReadingImportJobs_1' AND object_id = OBJECT_ID(N'med.ReadingImportJobs')
)
    CREATE UNIQUE INDEX [UX_med_ReadingImportJobs_1] ON [med].[ReadingImportJobs] ([TenantId], [ProfileId], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_MeteringSystems_1' AND object_id = OBJECT_ID(N'med.MeteringSystems')
)
    CREATE UNIQUE INDEX [UX_med_MeteringSystems_1] ON [med].[MeteringSystems] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_TelemetryRegisterMappings_1' AND object_id = OBJECT_ID(N'med.TelemetryRegisterMappings')
)
    CREATE UNIQUE INDEX [UX_med_TelemetryRegisterMappings_1] ON [med].[TelemetryRegisterMappings] ([TenantId], [MeteringSystemId], [MeterTypeId], [CategoryId], [ChannelType], [TouBand]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_RemoteMeterOperations_1' AND object_id = OBJECT_ID(N'med.RemoteMeterOperations')
)
    CREATE UNIQUE INDEX [UX_med_RemoteMeterOperations_1] ON [med].[RemoteMeterOperations] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_PrepaidAccounts_1' AND object_id = OBJECT_ID(N'med.PrepaidAccounts')
)
    CREATE UNIQUE INDEX [UX_med_PrepaidAccounts_1] ON [med].[PrepaidAccounts] ([TenantId], [MeteringPointId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_PrepaidTopUps_1' AND object_id = OBJECT_ID(N'med.PrepaidTopUps')
)
    CREATE UNIQUE INDEX [UX_med_PrepaidTopUps_1] ON [med].[PrepaidTopUps] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_DistributedGenerationContracts_1' AND object_id = OBJECT_ID(N'med.DistributedGenerationContracts')
)
    CREATE UNIQUE INDEX [UX_med_DistributedGenerationContracts_1] ON [med].[DistributedGenerationContracts] ([TenantId], [ContractId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_med_InjectionBalances_1' AND object_id = OBJECT_ID(N'med.InjectionBalances')
)
    CREATE UNIQUE INDEX [UX_med_InjectionBalances_1] ON [med].[InjectionBalances] ([TenantId], [MeteringPointId], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_TariffSchedules_1' AND object_id = OBJECT_ID(N'tar.TariffSchedules')
)
    CREATE UNIQUE INDEX [UX_tar_TariffSchedules_1] ON [tar].[TariffSchedules] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_TariffServiceSettings_1' AND object_id = OBJECT_ID(N'tar.TariffServiceSettings')
)
    CREATE UNIQUE INDEX [UX_tar_TariffServiceSettings_1] ON [tar].[TariffServiceSettings] ([TenantId], [ServiceId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_TariffCategoryRates_1' AND object_id = OBJECT_ID(N'tar.TariffCategoryRates')
)
    CREATE UNIQUE INDEX [UX_tar_TariffCategoryRates_1] ON [tar].[TariffCategoryRates] ([TenantId], [TariffScheduleId], [CategoryId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_TariffRows_1' AND object_id = OBJECT_ID(N'tar.TariffRows')
)
    CREATE UNIQUE INDEX [UX_tar_TariffRows_1] ON [tar].[TariffRows] ([TenantId], [TariffScheduleId], [CategoryId], [EnergyType], [ConceptId], [TimeBand], [StepMin]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_ProductPrices_1' AND object_id = OBJECT_ID(N'tar.ProductPrices')
)
    CREATE UNIQUE INDEX [UX_tar_ProductPrices_1] ON [tar].[ProductPrices] ([TenantId], [ServiceProductId], [Kind], [CategoryId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_EventCharges_1' AND object_id = OBJECT_ID(N'tar.EventCharges')
)
    CREATE UNIQUE INDEX [UX_tar_EventCharges_1] ON [tar].[EventCharges] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_CategoryCoefficients_1' AND object_id = OBJECT_ID(N'tar.CategoryCoefficients')
)
    CREATE UNIQUE INDEX [UX_tar_CategoryCoefficients_1] ON [tar].[CategoryCoefficients] ([TenantId], [TariffScheduleId], [CategoryId], [Code], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_GasCalorificFactors_1' AND object_id = OBJECT_ID(N'tar.GasCalorificFactors')
)
    CREATE UNIQUE INDEX [UX_tar_GasCalorificFactors_1] ON [tar].[GasCalorificFactors] ([TenantId], [ServiceId], [ZoneId], [CategoryId], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_ChargeRules_1' AND object_id = OBJECT_ID(N'tar.ChargeRules')
)
    CREATE UNIQUE INDEX [UX_tar_ChargeRules_1] ON [tar].[ChargeRules] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_FormulaFunctions_1' AND object_id = OBJECT_ID(N'tar.FormulaFunctions')
)
    CREATE UNIQUE INDEX [UX_tar_FormulaFunctions_1] ON [tar].[FormulaFunctions] ([TenantId], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_BenefitGroups_1' AND object_id = OBJECT_ID(N'tar.BenefitGroups')
)
    CREATE UNIQUE INDEX [UX_tar_BenefitGroups_1] ON [tar].[BenefitGroups] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_SubsidyRegimes_1' AND object_id = OBJECT_ID(N'tar.SubsidyRegimes')
)
    CREATE UNIQUE INDEX [UX_tar_SubsidyRegimes_1] ON [tar].[SubsidyRegimes] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_SubsidyRollImports_1' AND object_id = OBJECT_ID(N'tar.SubsidyRollImports')
)
    CREATE UNIQUE INDEX [UX_tar_SubsidyRollImports_1] ON [tar].[SubsidyRollImports] ([TenantId], [RegimeId], [Period], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_Promotions_1' AND object_id = OBJECT_ID(N'tar.Promotions')
)
    CREATE UNIQUE INDEX [UX_tar_Promotions_1] ON [tar].[Promotions] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_WorksInstallmentPlans_1' AND object_id = OBJECT_ID(N'tar.WorksInstallmentPlans')
)
    CREATE UNIQUE INDEX [UX_tar_WorksInstallmentPlans_1] ON [tar].[WorksInstallmentPlans] ([TenantId], [ContractId], [WorkCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_WorksInstallmentPlans_2' AND object_id = OBJECT_ID(N'tar.WorksInstallmentPlans')
)
    CREATE UNIQUE INDEX [UX_tar_WorksInstallmentPlans_2] ON [tar].[WorksInstallmentPlans] ([TenantId], [WorkId], [PremiseId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_RoundingPolicies_1' AND object_id = OBJECT_ID(N'tar.RoundingPolicies')
)
    CREATE UNIQUE INDEX [UX_tar_RoundingPolicies_1] ON [tar].[RoundingPolicies] ([TenantId], [Scope], [VoucherTypeId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_PhoneRatePlans_1' AND object_id = OBJECT_ID(N'tar.PhoneRatePlans')
)
    CREATE UNIQUE INDEX [UX_tar_PhoneRatePlans_1] ON [tar].[PhoneRatePlans] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_PhoneTimeBands_1' AND object_id = OBJECT_ID(N'tar.PhoneTimeBands')
)
    CREATE UNIQUE INDEX [UX_tar_PhoneTimeBands_1] ON [tar].[PhoneTimeBands] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_PhoneBandAssignments_1' AND object_id = OBJECT_ID(N'tar.PhoneBandAssignments')
)
    CREATE UNIQUE INDEX [UX_tar_PhoneBandAssignments_1] ON [tar].[PhoneBandAssignments] ([TenantId], [RatePlanId], [CallTypeCode], [BandTypeCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_PhoneRates_1' AND object_id = OBJECT_ID(N'tar.PhoneRates')
)
    CREATE UNIQUE INDEX [UX_tar_PhoneRates_1] ON [tar].[PhoneRates] ([TenantId], [RatePlanId], [DestinationKey], [CallTypeCode], [BandTypeCode], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_PhoneDiscountPlans_1' AND object_id = OBJECT_ID(N'tar.PhoneDiscountPlans')
)
    CREATE UNIQUE INDEX [UX_tar_PhoneDiscountPlans_1] ON [tar].[PhoneDiscountPlans] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_PhoneFreeNumbers_1' AND object_id = OBJECT_ID(N'tar.PhoneFreeNumbers')
)
    CREATE UNIQUE INDEX [UX_tar_PhoneFreeNumbers_1] ON [tar].[PhoneFreeNumbers] ([TenantId], [Number], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_CalculationRuns_1' AND object_id = OBJECT_ID(N'tar.CalculationRuns')
)
    CREATE UNIQUE INDEX [UX_tar_CalculationRuns_1] ON [tar].[CalculationRuns] ([TenantId], [JobId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_Calculations_1' AND object_id = OBJECT_ID(N'tar.Calculations')
)
    CREATE UNIQUE INDEX [UX_tar_Calculations_1] ON [tar].[Calculations] ([TenantId], [CalculationRunId], [AccountId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_SimulationResults_1' AND object_id = OBJECT_ID(N'tar.SimulationResults')
)
    CREATE UNIQUE INDEX [UX_tar_SimulationResults_1] ON [tar].[SimulationResults] ([TenantId], [SimulationRunId], [AccountId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tar_NormativeDocuments_1' AND object_id = OBJECT_ID(N'tar.NormativeDocuments')
)
    CREATE UNIQUE INDEX [UX_tar_NormativeDocuments_1] ON [tar].[NormativeDocuments] ([TenantId], [Kind], [Authority], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingCycles_1' AND object_id = OBJECT_ID(N'fac.BillingCycles')
)
    CREATE UNIQUE INDEX [UX_fac_BillingCycles_1] ON [fac].[BillingCycles] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingUniverses_1' AND object_id = OBJECT_ID(N'fac.BillingUniverses')
)
    CREATE UNIQUE INDEX [UX_fac_BillingUniverses_1] ON [fac].[BillingUniverses] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingTemplates_1' AND object_id = OBJECT_ID(N'fac.BillingTemplates')
)
    CREATE UNIQUE INDEX [UX_fac_BillingTemplates_1] ON [fac].[BillingTemplates] ([TenantId], [Code], [TemplateVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingRuns_1' AND object_id = OBJECT_ID(N'fac.BillingRuns')
)
    CREATE UNIQUE INDEX [UX_fac_BillingRuns_1] ON [fac].[BillingRuns] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingRuns_2' AND object_id = OBJECT_ID(N'fac.BillingRuns')
)
    CREATE UNIQUE INDEX [UX_fac_BillingRuns_2] ON [fac].[BillingRuns] ([TenantId], [LockKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingRunItems_1' AND object_id = OBJECT_ID(N'fac.BillingRunItems')
)
    CREATE UNIQUE INDEX [UX_fac_BillingRunItems_1] ON [fac].[BillingRunItems] ([TenantId], [RunId], [ItemCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingExceptions_1' AND object_id = OBJECT_ID(N'fac.BillingExceptions')
)
    CREATE UNIQUE INDEX [UX_fac_BillingExceptions_1] ON [fac].[BillingExceptions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingExceptionReasons_1' AND object_id = OBJECT_ID(N'fac.BillingExceptionReasons')
)
    CREATE UNIQUE INDEX [UX_fac_BillingExceptionReasons_1] ON [fac].[BillingExceptionReasons] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BilledPeriods_1' AND object_id = OBJECT_ID(N'fac.BilledPeriods')
)
    CREATE UNIQUE INDEX [UX_fac_BilledPeriods_1] ON [fac].[BilledPeriods] ([TenantId], [ContractId], [ServiceId], [Period], [Sequence]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_InvoiceRelations_1' AND object_id = OBJECT_ID(N'fac.InvoiceRelations')
)
    CREATE UNIQUE INDEX [UX_fac_InvoiceRelations_1] ON [fac].[InvoiceRelations] ([TenantId], [OriginInvoiceId], [GeneratedInvoiceId], [RelationType]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_InvoiceAnnulmentRequests_1' AND object_id = OBJECT_ID(N'fac.InvoiceAnnulmentRequests')
)
    CREATE UNIQUE INDEX [UX_fac_InvoiceAnnulmentRequests_1] ON [fac].[InvoiceAnnulmentRequests] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_VoucherTypes_1' AND object_id = OBJECT_ID(N'fac.VoucherTypes')
)
    CREATE UNIQUE INDEX [UX_fac_VoucherTypes_1] ON [fac].[VoucherTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_VoucherResolutionRules_1' AND object_id = OBJECT_ID(N'fac.VoucherResolutionRules')
)
    CREATE UNIQUE INDEX [UX_fac_VoucherResolutionRules_1] ON [fac].[VoucherResolutionRules] ([TenantId], [TaxCondition], [MatrixVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_NumberSequences_1' AND object_id = OBJECT_ID(N'fac.NumberSequences')
)
    CREATE UNIQUE INDEX [UX_fac_NumberSequences_1] ON [fac].[NumberSequences] ([TenantId], [LegalEntityId], [NumberingVoucherTypeId], [PointOfSaleId], [BillingGroupId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingModePolicies_1' AND object_id = OBJECT_ID(N'fac.BillingModePolicies')
)
    CREATE UNIQUE INDEX [UX_fac_BillingModePolicies_1] ON [fac].[BillingModePolicies] ([TenantId], [PolicyVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingGroups_1' AND object_id = OBJECT_ID(N'fac.BillingGroups')
)
    CREATE UNIQUE INDEX [UX_fac_BillingGroups_1] ON [fac].[BillingGroups] ([TenantId], [HolderId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_DueDateSchemes_1' AND object_id = OBJECT_ID(N'fac.DueDateSchemes')
)
    CREATE UNIQUE INDEX [UX_fac_DueDateSchemes_1] ON [fac].[DueDateSchemes] ([TenantId], [Code], [SchemeVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_MassOperationItems_1' AND object_id = OBJECT_ID(N'fac.MassOperationItems')
)
    CREATE UNIQUE INDEX [UX_fac_MassOperationItems_1] ON [fac].[MassOperationItems] ([TenantId], [OperationId], [TargetId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingImports_1' AND object_id = OBJECT_ID(N'fac.BillingImports')
)
    CREATE UNIQUE INDEX [UX_fac_BillingImports_1] ON [fac].[BillingImports] ([TenantId], [Format], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingImportRows_1' AND object_id = OBJECT_ID(N'fac.BillingImportRows')
)
    CREATE UNIQUE INDEX [UX_fac_BillingImportRows_1] ON [fac].[BillingImportRows] ([TenantId], [ImportId], [RowNo]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_InvoiceExternalData_1' AND object_id = OBJECT_ID(N'fac.InvoiceExternalData')
)
    CREATE UNIQUE INDEX [UX_fac_InvoiceExternalData_1] ON [fac].[InvoiceExternalData] ([TenantId], [InvoiceId], [ProviderCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_InvoiceTemplates_1' AND object_id = OBJECT_ID(N'fac.InvoiceTemplates')
)
    CREATE UNIQUE INDEX [UX_fac_InvoiceTemplates_1] ON [fac].[InvoiceTemplates] ([TenantId], [Code], [TemplateVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_InvoiceLineOrders_1' AND object_id = OBJECT_ID(N'fac.InvoiceLineOrders')
)
    CREATE UNIQUE INDEX [UX_fac_InvoiceLineOrders_1] ON [fac].[InvoiceLineOrders] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_ConsumptionChartGroups_1' AND object_id = OBJECT_ID(N'fac.ConsumptionChartGroups')
)
    CREATE UNIQUE INDEX [UX_fac_ConsumptionChartGroups_1] ON [fac].[ConsumptionChartGroups] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BarcodeFormats_1' AND object_id = OBJECT_ID(N'fac.BarcodeFormats')
)
    CREATE UNIQUE INDEX [UX_fac_BarcodeFormats_1] ON [fac].[BarcodeFormats] ([TenantId], [Code], [FormatVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BarcodeAssignments_1' AND object_id = OBJECT_ID(N'fac.BarcodeAssignments')
)
    CREATE UNIQUE INDEX [UX_fac_BarcodeAssignments_1] ON [fac].[BarcodeAssignments] ([TenantId], [CollectorCode], [DocumentTypes]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_PaymentSlips_1' AND object_id = OBJECT_ID(N'fac.PaymentSlips')
)
    CREATE UNIQUE INDEX [UX_fac_PaymentSlips_1] ON [fac].[PaymentSlips] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_InvoiceDocuments_1' AND object_id = OBJECT_ID(N'fac.InvoiceDocuments')
)
    CREATE UNIQUE INDEX [UX_fac_InvoiceDocuments_1] ON [fac].[InvoiceDocuments] ([TenantId], [InvoiceId], [Kind], [TemplateVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_DeliveryPreferences_1' AND object_id = OBJECT_ID(N'fac.DeliveryPreferences')
)
    CREATE UNIQUE INDEX [UX_fac_DeliveryPreferences_1] ON [fac].[DeliveryPreferences] ([TenantId], [HolderId], [AccountId], [BillingGroupId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_DistributionRuns_1' AND object_id = OBJECT_ID(N'fac.DistributionRuns')
)
    CREATE UNIQUE INDEX [UX_fac_DistributionRuns_1] ON [fac].[DistributionRuns] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_DistributionRoutes_1' AND object_id = OBJECT_ID(N'fac.DistributionRoutes')
)
    CREATE UNIQUE INDEX [UX_fac_DistributionRoutes_1] ON [fac].[DistributionRoutes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_PostalCarriers_1' AND object_id = OBJECT_ID(N'fac.PostalCarriers')
)
    CREATE UNIQUE INDEX [UX_fac_PostalCarriers_1] ON [fac].[PostalCarriers] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fac_BillingCycleClosures_1' AND object_id = OBJECT_ID(N'fac.BillingCycleClosures')
)
    CREATE UNIQUE INDEX [UX_fac_BillingCycleClosures_1] ON [fac].[BillingCycleClosures] ([TenantId], [CycleId], [Period], [Sequence], [ClosureVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_NormativeTables_1' AND object_id = OBJECT_ID(N'fis.NormativeTables')
)
    CREATE UNIQUE INDEX [UX_fis_NormativeTables_1] ON [fis].[NormativeTables] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_NormativeTableVersions_1' AND object_id = OBJECT_ID(N'fis.NormativeTableVersions')
)
    CREATE UNIQUE INDEX [UX_fis_NormativeTableVersions_1] ON [fis].[NormativeTableVersions] ([TableCode], [VersionNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_NormativeAdoptions_1' AND object_id = OBJECT_ID(N'fis.NormativeAdoptions')
)
    CREATE UNIQUE INDEX [UX_fis_NormativeAdoptions_1] ON [fis].[NormativeAdoptions] ([TenantId], [TableCode], [EffectiveFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_FiscalProfiles_1' AND object_id = OBJECT_ID(N'fis.FiscalProfiles')
)
    CREATE UNIQUE INDEX [UX_fis_FiscalProfiles_1] ON [fis].[FiscalProfiles] ([TenantId], [LegalEntityId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_TaxAgentRegistrations_1' AND object_id = OBJECT_ID(N'fis.TaxAgentRegistrations')
)
    CREATE UNIQUE INDEX [UX_fis_TaxAgentRegistrations_1] ON [fis].[TaxAgentRegistrations] ([TenantId], [LegalEntityId], [Organism], [Tax], [Regime], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_ArcaCredentials_1' AND object_id = OBJECT_ID(N'fis.ArcaCredentials')
)
    CREATE UNIQUE INDEX [UX_fis_ArcaCredentials_1] ON [fis].[ArcaCredentials] ([TenantId], [LegalEntityId], [Environment], [Alias]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_ArcaAccessTickets_1' AND object_id = OBJECT_ID(N'fis.ArcaAccessTickets')
)
    CREATE UNIQUE INDEX [UX_fis_ArcaAccessTickets_1] ON [fis].[ArcaAccessTickets] ([TenantId], [ArcaCredentialId], [Service], [Environment]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_PointsOfSale_1' AND object_id = OBJECT_ID(N'fis.PointsOfSale')
)
    CREATE UNIQUE INDEX [UX_fis_PointsOfSale_1] ON [fis].[PointsOfSale] ([TenantId], [LegalEntityId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_CaeaPeriods_1' AND object_id = OBJECT_ID(N'fis.CaeaPeriods')
)
    CREATE UNIQUE INDEX [UX_fis_CaeaPeriods_1] ON [fis].[CaeaPeriods] ([TenantId], [LegalEntityId], [Period], [Order]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_ProvincialValidationCodes_1' AND object_id = OBJECT_ID(N'fis.ProvincialValidationCodes')
)
    CREATE UNIQUE INDEX [UX_fis_ProvincialValidationCodes_1] ON [fis].[ProvincialValidationCodes] ([TenantId], [PointOfSaleId], [VoucherTypeId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_VatConditionSettings_1' AND object_id = OBJECT_ID(N'fis.VatConditionSettings')
)
    CREATE UNIQUE INDEX [UX_fis_VatConditionSettings_1] ON [fis].[VatConditionSettings] ([TenantId], [ArcaConditionId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_VatRates_1' AND object_id = OBJECT_ID(N'fis.VatRates')
)
    CREATE UNIQUE INDEX [UX_fis_VatRates_1] ON [fis].[VatRates] ([TenantId], [ArcaVatId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_VatRateMatrix_1' AND object_id = OBJECT_ID(N'fis.VatRateMatrix')
)
    CREATE UNIQUE INDEX [UX_fis_VatRateMatrix_1] ON [fis].[VatRateMatrix] ([TenantId], [VatRateId], [VatConditionSettingId], [SupplyUsageKey], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_VatRateMatrix_2' AND object_id = OBJECT_ID(N'fis.VatRateMatrix')
)
    CREATE UNIQUE INDEX [UX_fis_VatRateMatrix_2] ON [fis].[VatRateMatrix] ([TenantId], [VatRateId], [VatConditionSettingId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_TaxDefinitions_1' AND object_id = OBJECT_ID(N'fis.TaxDefinitions')
)
    CREATE UNIQUE INDEX [UX_fis_TaxDefinitions_1] ON [fis].[TaxDefinitions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_GrossIncomeSettings_1' AND object_id = OBJECT_ID(N'fis.GrossIncomeSettings')
)
    CREATE UNIQUE INDEX [UX_fis_GrossIncomeSettings_1] ON [fis].[GrossIncomeSettings] ([TenantId], [Jurisdiction], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_TaxpayerRegistries_1' AND object_id = OBJECT_ID(N'fis.TaxpayerRegistries')
)
    CREATE UNIQUE INDEX [UX_fis_TaxpayerRegistries_1] ON [fis].[TaxpayerRegistries] ([TenantId], [Kind], [Jurisdiction], [Regime], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_TaxpayerRegistryEntries_1' AND object_id = OBJECT_ID(N'fis.TaxpayerRegistryEntries')
)
    CREATE UNIQUE INDEX [UX_fis_TaxpayerRegistryEntries_1] ON [fis].[TaxpayerRegistryEntries] ([TenantId], [RegistryId], [Cuit]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_DeterminedRates_1' AND object_id = OBJECT_ID(N'fis.DeterminedRates')
)
    CREATE UNIQUE INDEX [UX_fis_DeterminedRates_1] ON [fis].[DeterminedRates] ([TenantId], [AccountId], [Jurisdiction], [Regime], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_TaxExemptions_1' AND object_id = OBJECT_ID(N'fis.TaxExemptions')
)
    CREATE UNIQUE INDEX [UX_fis_TaxExemptions_1] ON [fis].[TaxExemptions] ([TenantId], [PartyId], [Tax], [Regime], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_TaxCalculationTraces_1' AND object_id = OBJECT_ID(N'fis.TaxCalculationTraces')
)
    CREATE UNIQUE INDEX [UX_fis_TaxCalculationTraces_1] ON [fis].[TaxCalculationTraces] ([TenantId], [DocumentRef]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_WithholdingTypes_1' AND object_id = OBJECT_ID(N'fis.WithholdingTypes')
)
    CREATE UNIQUE INDEX [UX_fis_WithholdingTypes_1] ON [fis].[WithholdingTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_WithholdingScales_1' AND object_id = OBJECT_ID(N'fis.WithholdingScales')
)
    CREATE UNIQUE INDEX [UX_fis_WithholdingScales_1] ON [fis].[WithholdingScales] ([TenantId], [WithholdingTypeId], [From], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_WithholdingAssignments_1' AND object_id = OBJECT_ID(N'fis.WithholdingAssignments')
)
    CREATE UNIQUE INDEX [UX_fis_WithholdingAssignments_1] ON [fis].[WithholdingAssignments] ([TenantId], [TargetType], [TargetId], [WithholdingTypeId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_WithholdingsApplied_1' AND object_id = OBJECT_ID(N'fis.WithholdingsApplied')
)
    CREATE UNIQUE INDEX [UX_fis_WithholdingsApplied_1] ON [fis].[WithholdingsApplied] ([TenantId], [LegalEntityId], [WithholdingTypeId], [CertificateInternalNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_WithholdingSufferedTypes_1' AND object_id = OBJECT_ID(N'fis.WithholdingSufferedTypes')
)
    CREATE UNIQUE INDEX [UX_fis_WithholdingSufferedTypes_1] ON [fis].[WithholdingSufferedTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_TaxObligations_1' AND object_id = OBJECT_ID(N'fis.TaxObligations')
)
    CREATE UNIQUE INDEX [UX_fis_TaxObligations_1] ON [fis].[TaxObligations] ([TenantId], [LegalEntityId], [Regime], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_VatLedgers_1' AND object_id = OBJECT_ID(N'fis.VatLedgers')
)
    CREATE UNIQUE INDEX [UX_fis_VatLedgers_1] ON [fis].[VatLedgers] ([TenantId], [LegalEntityId], [Kind], [Period], [RectificationNo]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_VatLedgerLines_1' AND object_id = OBJECT_ID(N'fis.VatLedgerLines')
)
    CREATE UNIQUE INDEX [UX_fis_VatLedgerLines_1] ON [fis].[VatLedgerLines] ([TenantId], [LedgerId], [DocumentRefId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_ArcaReceivedImports_1' AND object_id = OBJECT_ID(N'fis.ArcaReceivedImports')
)
    CREATE UNIQUE INDEX [UX_fis_ArcaReceivedImports_1] ON [fis].[ArcaReceivedImports] ([TenantId], [LegalEntityId], [Kind], [Period], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_InformationRegimes_1' AND object_id = OBJECT_ID(N'fis.InformationRegimes')
)
    CREATE UNIQUE INDEX [UX_fis_InformationRegimes_1] ON [fis].[InformationRegimes] ([Code], [FormatVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_RegimeFilings_1' AND object_id = OBJECT_ID(N'fis.RegimeFilings')
)
    CREATE UNIQUE INDEX [UX_fis_RegimeFilings_1] ON [fis].[RegimeFilings] ([TenantId], [LegalEntityId], [RegimeCode], [Period], [RectificationNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_ThirdPartyAgreements_1' AND object_id = OBJECT_ID(N'fis.ThirdPartyAgreements')
)
    CREATE UNIQUE INDEX [UX_fis_ThirdPartyAgreements_1] ON [fis].[ThirdPartyAgreements] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_ThirdPartyCharges_1' AND object_id = OBJECT_ID(N'fis.ThirdPartyCharges')
)
    CREATE UNIQUE INDEX [UX_fis_ThirdPartyCharges_1] ON [fis].[ThirdPartyCharges] ([TenantId], [AgreementId], [InvoiceId], [ConceptIndex]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_ThirdPartyRemittances_1' AND object_id = OBJECT_ID(N'fis.ThirdPartyRemittances')
)
    CREATE UNIQUE INDEX [UX_fis_ThirdPartyRemittances_1] ON [fis].[ThirdPartyRemittances] ([TenantId], [AgreementId], [PeriodFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_RegulatoryReports_1' AND object_id = OBJECT_ID(N'fis.RegulatoryReports')
)
    CREATE UNIQUE INDEX [UX_fis_RegulatoryReports_1] ON [fis].[RegulatoryReports] ([Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_RegulatoryReportRuns_1' AND object_id = OBJECT_ID(N'fis.RegulatoryReportRuns')
)
    CREATE UNIQUE INDEX [UX_fis_RegulatoryReportRuns_1] ON [fis].[RegulatoryReportRuns] ([TenantId], [ReportCode], [Period], [RectificationNo]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_RegulatoryConceptMaps_1' AND object_id = OBJECT_ID(N'fis.RegulatoryConceptMaps')
)
    CREATE UNIQUE INDEX [UX_fis_RegulatoryConceptMaps_1] ON [fis].[RegulatoryConceptMaps] ([TenantId], [ReportCode], [ServiceKind], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_PublicAdminSelections_1' AND object_id = OBJECT_ID(N'fis.PublicAdminSelections')
)
    CREATE UNIQUE INDEX [UX_fis_PublicAdminSelections_1] ON [fis].[PublicAdminSelections] ([TenantId], [SelectionKey], [Period], [IssueDate]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_GatewayDocuments_1' AND object_id = OBJECT_ID(N'fis.GatewayDocuments')
)
    CREATE UNIQUE INDEX [UX_fis_GatewayDocuments_1] ON [fis].[GatewayDocuments] ([TenantId], [ArcaCbteType], [PointOfSale], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_FiscalDeadlines_1' AND object_id = OBJECT_ID(N'fis.FiscalDeadlines')
)
    CREATE UNIQUE INDEX [UX_fis_FiscalDeadlines_1] ON [fis].[FiscalDeadlines] ([TenantId], [RegimeCode], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_ConceptFiscalCases_1' AND object_id = OBJECT_ID(N'fis.ConceptFiscalCases')
)
    CREATE UNIQUE INDEX [UX_fis_ConceptFiscalCases_1] ON [fis].[ConceptFiscalCases] ([TenantId], [ConceptId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_fis_FiscalClasses_1' AND object_id = OBJECT_ID(N'fis.FiscalClasses')
)
    CREATE UNIQUE INDEX [UX_fis_FiscalClasses_1] ON [fis].[FiscalClasses] ([TenantId], [Code], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_CurrentAccounts_1' AND object_id = OBJECT_ID(N'cob.CurrentAccounts')
)
    CREATE UNIQUE INDEX [UX_cob_CurrentAccounts_1] ON [cob].[CurrentAccounts] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_Obligations_1' AND object_id = OBJECT_ID(N'cob.Obligations')
)
    CREATE UNIQUE INDEX [UX_cob_Obligations_1] ON [cob].[Obligations] ([TenantId], [SourceDocumentId], [SourceLineKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_Obligations_2' AND object_id = OBJECT_ID(N'cob.Obligations')
)
    CREATE UNIQUE INDEX [UX_cob_Obligations_2] ON [cob].[Obligations] ([TenantId], [FiscalGateStatus], [IssueDate]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_LedgerEntries_1' AND object_id = OBJECT_ID(N'cob.LedgerEntries')
)
    CREATE UNIQUE INDEX [UX_cob_LedgerEntries_1] ON [cob].[LedgerEntries] ([TenantId], [OperationId], [Kind]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_Allocations_1' AND object_id = OBJECT_ID(N'cob.Allocations')
)
    CREATE UNIQUE INDEX [UX_cob_Allocations_1] ON [cob].[Allocations] ([TenantId], [OperationId], [Sequence]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_AllocationPolicies_1' AND object_id = OBJECT_ID(N'cob.AllocationPolicies')
)
    CREATE UNIQUE INDEX [UX_cob_AllocationPolicies_1] ON [cob].[AllocationPolicies] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_UnidentifiedReceipts_1' AND object_id = OBJECT_ID(N'cob.UnidentifiedReceipts')
)
    CREATE UNIQUE INDEX [UX_cob_UnidentifiedReceipts_1] ON [cob].[UnidentifiedReceipts] ([TenantId], [SourceRef]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_AccountStatements_1' AND object_id = OBJECT_ID(N'cob.AccountStatements')
)
    CREATE UNIQUE INDEX [UX_cob_AccountStatements_1] ON [cob].[AccountStatements] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_CashRegisters_1' AND object_id = OBJECT_ID(N'cob.CashRegisters')
)
    CREATE UNIQUE INDEX [UX_cob_CashRegisters_1] ON [cob].[CashRegisters] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_CashSessions_1' AND object_id = OBJECT_ID(N'cob.CashSessions')
)
    CREATE UNIQUE INDEX [UX_cob_CashSessions_1] ON [cob].[CashSessions] ([TenantId], [CashRegisterId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_CashOperations_1' AND object_id = OBJECT_ID(N'cob.CashOperations')
)
    CREATE UNIQUE INDEX [UX_cob_CashOperations_1] ON [cob].[CashOperations] ([TenantId], [OperationId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_CashOperations_2' AND object_id = OBJECT_ID(N'cob.CashOperations')
)
    CREATE UNIQUE INDEX [UX_cob_CashOperations_2] ON [cob].[CashOperations] ([TenantId], [OperationNo]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_Receipts_1' AND object_id = OBJECT_ID(N'cob.Receipts')
)
    CREATE UNIQUE INDEX [UX_cob_Receipts_1] ON [cob].[Receipts] ([TenantId], [LegalEntityId], [NumberPointOfSale], [NumberNumber], [NumberVoucherTypeId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_PaymentMethods_1' AND object_id = OBJECT_ID(N'cob.PaymentMethods')
)
    CREATE UNIQUE INDEX [UX_cob_PaymentMethods_1] ON [cob].[PaymentMethods] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_CardPlans_1' AND object_id = OBJECT_ID(N'cob.CardPlans')
)
    CREATE UNIQUE INDEX [UX_cob_CardPlans_1] ON [cob].[CardPlans] ([TenantId], [Brand], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_StaticQrCodes_1' AND object_id = OBJECT_ID(N'cob.StaticQrCodes')
)
    CREATE UNIQUE INDEX [UX_cob_StaticQrCodes_1] ON [cob].[StaticQrCodes] ([TenantId], [ExternalQrId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_Collectors_1' AND object_id = OBJECT_ID(N'cob.Collectors')
)
    CREATE UNIQUE INDEX [UX_cob_Collectors_1] ON [cob].[Collectors] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_CollectionAgencies_1' AND object_id = OBJECT_ID(N'cob.CollectionAgencies')
)
    CREATE UNIQUE INDEX [UX_cob_CollectionAgencies_1] ON [cob].[CollectionAgencies] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_PaymentReferences_1' AND object_id = OBJECT_ID(N'cob.PaymentReferences')
)
    CREATE UNIQUE INDEX [UX_cob_PaymentReferences_1] ON [cob].[PaymentReferences] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_ExternalKeyAliases_1' AND object_id = OBJECT_ID(N'cob.ExternalKeyAliases')
)
    CREATE UNIQUE INDEX [UX_cob_ExternalKeyAliases_1] ON [cob].[ExternalKeyAliases] ([TenantId], [Source], [AgencyId], [ExternalKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_AgencyDebtExports_1' AND object_id = OBJECT_ID(N'cob.AgencyDebtExports')
)
    CREATE UNIQUE INDEX [UX_cob_AgencyDebtExports_1] ON [cob].[AgencyDebtExports] ([TenantId], [AgencyId], [Period], [Sequence]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_AgencyPublishedDebts_1' AND object_id = OBJECT_ID(N'cob.AgencyPublishedDebts')
)
    CREATE UNIQUE INDEX [UX_cob_AgencyPublishedDebts_1] ON [cob].[AgencyPublishedDebts] ([TenantId], [AgencyId], [Period], [Concept], [Identifier]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_AgencySettlements_1' AND object_id = OBJECT_ID(N'cob.AgencySettlements')
)
    CREATE UNIQUE INDEX [UX_cob_AgencySettlements_1] ON [cob].[AgencySettlements] ([TenantId], [AgencyId], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_AgencySettlementLines_1' AND object_id = OBJECT_ID(N'cob.AgencySettlementLines')
)
    CREATE UNIQUE INDEX [UX_cob_AgencySettlementLines_1] ON [cob].[AgencySettlementLines] ([TenantId], [SettlementId], [LineNo]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_AgencyNoveltyFiles_1' AND object_id = OBJECT_ID(N'cob.AgencyNoveltyFiles')
)
    CREATE UNIQUE INDEX [UX_cob_AgencyNoveltyFiles_1] ON [cob].[AgencyNoveltyFiles] ([TenantId], [AgencyId], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_DirectDebitMandates_1' AND object_id = OBJECT_ID(N'cob.DirectDebitMandates')
)
    CREATE UNIQUE INDEX [UX_cob_DirectDebitMandates_1] ON [cob].[DirectDebitMandates] ([TenantId], [CurrentAccountId], [Channel], [Status:]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_DirectDebitBatches_1' AND object_id = OBJECT_ID(N'cob.DirectDebitBatches')
)
    CREATE UNIQUE INDEX [UX_cob_DirectDebitBatches_1] ON [cob].[DirectDebitBatches] ([TenantId], [AgencyId], [PresentationDate], [Sequence]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_GatewayConnectors_1' AND object_id = OBJECT_ID(N'cob.GatewayConnectors')
)
    CREATE UNIQUE INDEX [UX_cob_GatewayConnectors_1] ON [cob].[GatewayConnectors] ([TenantId], [Provider], [Environment], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_PaymentChannels_1' AND object_id = OBJECT_ID(N'cob.PaymentChannels')
)
    CREATE UNIQUE INDEX [UX_cob_PaymentChannels_1] ON [cob].[PaymentChannels] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_GatewayTransactions_1' AND object_id = OBJECT_ID(N'cob.GatewayTransactions')
)
    CREATE UNIQUE INDEX [UX_cob_GatewayTransactions_1] ON [cob].[GatewayTransactions] ([TenantId], [ConnectorId], [ExternalPaymentId], [Type]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_GatewayWebhookEvents_1' AND object_id = OBJECT_ID(N'cob.GatewayWebhookEvents')
)
    CREATE UNIQUE INDEX [UX_cob_GatewayWebhookEvents_1] ON [cob].[GatewayWebhookEvents] ([TenantId], [ConnectorId], [DedupeKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_PaymentCoupons_1' AND object_id = OBJECT_ID(N'cob.PaymentCoupons')
)
    CREATE UNIQUE INDEX [UX_cob_PaymentCoupons_1] ON [cob].[PaymentCoupons] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_RefundCases_1' AND object_id = OBJECT_ID(N'cob.RefundCases')
)
    CREATE UNIQUE INDEX [UX_cob_RefundCases_1] ON [cob].[RefundCases] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_Chargebacks_1' AND object_id = OBJECT_ID(N'cob.Chargebacks')
)
    CREATE UNIQUE INDEX [UX_cob_Chargebacks_1] ON [cob].[Chargebacks] ([TenantId], [ConnectorId], [ExternalId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_TreasuryHandovers_1' AND object_id = OBJECT_ID(N'cob.TreasuryHandovers')
)
    CREATE UNIQUE INDEX [UX_cob_TreasuryHandovers_1] ON [cob].[TreasuryHandovers] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_ThirdPartyBillers_1' AND object_id = OBJECT_ID(N'cob.ThirdPartyBillers')
)
    CREATE UNIQUE INDEX [UX_cob_ThirdPartyBillers_1] ON [cob].[ThirdPartyBillers] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_ExternalObligationImports_1' AND object_id = OBJECT_ID(N'cob.ExternalObligationImports')
)
    CREATE UNIQUE INDEX [UX_cob_ExternalObligationImports_1] ON [cob].[ExternalObligationImports] ([TenantId], [Source], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_CollectionReportSchemes_1' AND object_id = OBJECT_ID(N'cob.CollectionReportSchemes')
)
    CREATE UNIQUE INDEX [UX_cob_CollectionReportSchemes_1] ON [cob].[CollectionReportSchemes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cob_CollectionAccountingGroups_1' AND object_id = OBJECT_ID(N'cob.CollectionAccountingGroups')
)
    CREATE UNIQUE INDEX [UX_cob_CollectionAccountingGroups_1] ON [cob].[CollectionAccountingGroups] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_InterestPolicies_1' AND object_id = OBJECT_ID(N'mor.InterestPolicies')
)
    CREATE UNIQUE INDEX [UX_mor_InterestPolicies_1] ON [mor].[InterestPolicies] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_InterestRateTables_1' AND object_id = OBJECT_ID(N'mor.InterestRateTables')
)
    CREATE UNIQUE INDEX [UX_mor_InterestRateTables_1] ON [mor].[InterestRateTables] ([TenantId], [Code], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_InterestIndexTables_1' AND object_id = OBJECT_ID(N'mor.InterestIndexTables')
)
    CREATE UNIQUE INDEX [UX_mor_InterestIndexTables_1] ON [mor].[InterestIndexTables] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_InterestIndexValues_1' AND object_id = OBJECT_ID(N'mor.InterestIndexValues')
)
    CREATE UNIQUE INDEX [UX_mor_InterestIndexValues_1] ON [mor].[InterestIndexValues] ([TenantId], [TableId], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_DueDateSurchargeSchemes_1' AND object_id = OBJECT_ID(N'mor.DueDateSurchargeSchemes')
)
    CREATE UNIQUE INDEX [UX_mor_DueDateSurchargeSchemes_1] ON [mor].[DueDateSurchargeSchemes] ([TenantId], [Code], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_EarlyPaymentDiscountRules_1' AND object_id = OBJECT_ID(N'mor.EarlyPaymentDiscountRules')
)
    CREATE UNIQUE INDEX [UX_mor_EarlyPaymentDiscountRules_1] ON [mor].[EarlyPaymentDiscountRules] ([TenantId], [VoucherTypeId], [DayFrom], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_InterestBillingRuns_1' AND object_id = OBJECT_ID(N'mor.InterestBillingRuns')
)
    CREATE UNIQUE INDEX [UX_mor_InterestBillingRuns_1] ON [mor].[InterestBillingRuns] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_InterestBillingRuns_2' AND object_id = OBJECT_ID(N'mor.InterestBillingRuns')
)
    CREATE UNIQUE INDEX [UX_mor_InterestBillingRuns_2] ON [mor].[InterestBillingRuns] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_InterestBillingRunItems_1' AND object_id = OBJECT_ID(N'mor.InterestBillingRunItems')
)
    CREATE UNIQUE INDEX [UX_mor_InterestBillingRunItems_1] ON [mor].[InterestBillingRunItems] ([TenantId], [RunId], [DocumentRefId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_HoldReasons_1' AND object_id = OBJECT_ID(N'mor.HoldReasons')
)
    CREATE UNIQUE INDEX [UX_mor_HoldReasons_1] ON [mor].[HoldReasons] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_DocumentHolds_1' AND object_id = OBJECT_ID(N'mor.DocumentHolds')
)
    CREATE UNIQUE INDEX [UX_mor_DocumentHolds_1] ON [mor].[DocumentHolds] ([TenantId], [DocumentRefId], [Status:]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_DelinquencyPolicies_1' AND object_id = OBJECT_ID(N'mor.DelinquencyPolicies')
)
    CREATE UNIQUE INDEX [UX_mor_DelinquencyPolicies_1] ON [mor].[DelinquencyPolicies] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_DelinquencyStages_1' AND object_id = OBJECT_ID(N'mor.DelinquencyStages')
)
    CREATE UNIQUE INDEX [UX_mor_DelinquencyStages_1] ON [mor].[DelinquencyStages] ([TenantId], [PolicyId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_DelinquencyNoticeModels_1' AND object_id = OBJECT_ID(N'mor.DelinquencyNoticeModels')
)
    CREATE UNIQUE INDEX [UX_mor_DelinquencyNoticeModels_1] ON [mor].[DelinquencyNoticeModels] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_DelinquencyBatches_1' AND object_id = OBJECT_ID(N'mor.DelinquencyBatches')
)
    CREATE UNIQUE INDEX [UX_mor_DelinquencyBatches_1] ON [mor].[DelinquencyBatches] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_SuspensionRestrictionRules_1' AND object_id = OBJECT_ID(N'mor.SuspensionRestrictionRules')
)
    CREATE UNIQUE INDEX [UX_mor_SuspensionRestrictionRules_1] ON [mor].[SuspensionRestrictionRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_DelinquencyReasons_1' AND object_id = OBJECT_ID(N'mor.DelinquencyReasons')
)
    CREATE UNIQUE INDEX [UX_mor_DelinquencyReasons_1] ON [mor].[DelinquencyReasons] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_InterruptionCases_1' AND object_id = OBJECT_ID(N'mor.InterruptionCases')
)
    CREATE UNIQUE INDEX [UX_mor_InterruptionCases_1] ON [mor].[InterruptionCases] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_InterruptionChargeRules_1' AND object_id = OBJECT_ID(N'mor.InterruptionChargeRules')
)
    CREATE UNIQUE INDEX [UX_mor_InterruptionChargeRules_1] ON [mor].[InterruptionChargeRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_PaymentPlans_1' AND object_id = OBJECT_ID(N'mor.PaymentPlans')
)
    CREATE UNIQUE INDEX [UX_mor_PaymentPlans_1] ON [mor].[PaymentPlans] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_Agreements_1' AND object_id = OBJECT_ID(N'mor.Agreements')
)
    CREATE UNIQUE INDEX [UX_mor_Agreements_1] ON [mor].[Agreements] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_AgreementObligations_1' AND object_id = OBJECT_ID(N'mor.AgreementObligations')
)
    CREATE UNIQUE INDEX [UX_mor_AgreementObligations_1] ON [mor].[AgreementObligations] ([TenantId], [AgreementId], [ObligationId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_AgreementInstallments_1' AND object_id = OBJECT_ID(N'mor.AgreementInstallments')
)
    CREATE UNIQUE INDEX [UX_mor_AgreementInstallments_1] ON [mor].[AgreementInstallments] ([TenantId], [AgreementId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_GuaranteeRequirementRules_1' AND object_id = OBJECT_ID(N'mor.GuaranteeRequirementRules')
)
    CREATE UNIQUE INDEX [UX_mor_GuaranteeRequirementRules_1] ON [mor].[GuaranteeRequirementRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_DebtCollectionAgencies_1' AND object_id = OBJECT_ID(N'mor.DebtCollectionAgencies')
)
    CREATE UNIQUE INDEX [UX_mor_DebtCollectionAgencies_1] ON [mor].[DebtCollectionAgencies] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_CollectionCases_1' AND object_id = OBJECT_ID(N'mor.CollectionCases')
)
    CREATE UNIQUE INDEX [UX_mor_CollectionCases_1] ON [mor].[CollectionCases] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_WriteOffs_1' AND object_id = OBJECT_ID(N'mor.WriteOffs')
)
    CREATE UNIQUE INDEX [UX_mor_WriteOffs_1] ON [mor].[WriteOffs] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_PrescriptionRules_1' AND object_id = OBJECT_ID(N'mor.PrescriptionRules')
)
    CREATE UNIQUE INDEX [UX_mor_PrescriptionRules_1] ON [mor].[PrescriptionRules] ([TenantId], [ObligationType], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_mor_PrescriptionRuns_1' AND object_id = OBJECT_ID(N'mor.PrescriptionRuns')
)
    CREATE UNIQUE INDEX [UX_mor_PrescriptionRuns_1] ON [mor].[PrescriptionRuns] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmCases_1' AND object_id = OBJECT_ID(N'crm.CrmCases')
)
    CREATE UNIQUE INDEX [UX_crm_CrmCases_1] ON [crm].[CrmCases] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmCases_2' AND object_id = OBJECT_ID(N'crm.CrmCases')
)
    CREATE UNIQUE INDEX [UX_crm_CrmCases_2] ON [crm].[CrmCases] ([TenantId], [DeskEntry]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmCases_3' AND object_id = OBJECT_ID(N'crm.CrmCases')
)
    CREATE UNIQUE INDEX [UX_crm_CrmCases_3] ON [crm].[CrmCases] ([TenantId], [CancellationRequest]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmCaseEvents_1' AND object_id = OBJECT_ID(N'crm.CrmCaseEvents')
)
    CREATE UNIQUE INDEX [UX_crm_CrmCaseEvents_1] ON [crm].[CrmCaseEvents] ([TenantId], [CrmCaseId], [Seq]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmCaseEvents_2' AND object_id = OBJECT_ID(N'crm.CrmCaseEvents')
)
    CREATE UNIQUE INDEX [UX_crm_CrmCaseEvents_2] ON [crm].[CrmCaseEvents] ([TenantId], [CaseId], [Seq]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmConversations_1' AND object_id = OBJECT_ID(N'crm.CrmConversations')
)
    CREATE UNIQUE INDEX [UX_crm_CrmConversations_1] ON [crm].[CrmConversations] ([TenantId], [ChannelId], [ExternalThreadId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmMessages_1' AND object_id = OBJECT_ID(N'crm.CrmMessages')
)
    CREATE UNIQUE INDEX [UX_crm_CrmMessages_1] ON [crm].[CrmMessages] ([TenantId], [ProviderMessageId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmCaseTypes_1' AND object_id = OBJECT_ID(N'crm.CrmCaseTypes')
)
    CREATE UNIQUE INDEX [UX_crm_CrmCaseTypes_1] ON [crm].[CrmCaseTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmCaseSubtypes_1' AND object_id = OBJECT_ID(N'crm.CrmCaseSubtypes')
)
    CREATE UNIQUE INDEX [UX_crm_CrmCaseSubtypes_1] ON [crm].[CrmCaseSubtypes] ([TenantId], [CaseTypeId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmStatusSets_1' AND object_id = OBJECT_ID(N'crm.CrmStatusSets')
)
    CREATE UNIQUE INDEX [UX_crm_CrmStatusSets_1] ON [crm].[CrmStatusSets] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmAreas_1' AND object_id = OBJECT_ID(N'crm.CrmAreas')
)
    CREATE UNIQUE INDEX [UX_crm_CrmAreas_1] ON [crm].[CrmAreas] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmSlaPolicies_1' AND object_id = OBJECT_ID(N'crm.CrmSlaPolicies')
)
    CREATE UNIQUE INDEX [UX_crm_CrmSlaPolicies_1] ON [crm].[CrmSlaPolicies] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmRoutingRules_1' AND object_id = OBJECT_ID(N'crm.CrmRoutingRules')
)
    CREATE UNIQUE INDEX [UX_crm_CrmRoutingRules_1] ON [crm].[CrmRoutingRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmCommandRequests_1' AND object_id = OBJECT_ID(N'crm.CrmCommandRequests')
)
    CREATE UNIQUE INDEX [UX_crm_CrmCommandRequests_1] ON [crm].[CrmCommandRequests] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmIncidents_1' AND object_id = OBJECT_ID(N'crm.CrmIncidents')
)
    CREATE UNIQUE INDEX [UX_crm_CrmIncidents_1] ON [crm].[CrmIncidents] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmIncidentClasses_1' AND object_id = OBJECT_ID(N'crm.CrmIncidentClasses')
)
    CREATE UNIQUE INDEX [UX_crm_CrmIncidentClasses_1] ON [crm].[CrmIncidentClasses] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmProcedureTypes_1' AND object_id = OBJECT_ID(N'crm.CrmProcedureTypes')
)
    CREATE UNIQUE INDEX [UX_crm_CrmProcedureTypes_1] ON [crm].[CrmProcedureTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmProjects_1' AND object_id = OBJECT_ID(N'crm.CrmProjects')
)
    CREATE UNIQUE INDEX [UX_crm_CrmProjects_1] ON [crm].[CrmProjects] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmAccountAssignments_1' AND object_id = OBJECT_ID(N'crm.CrmAccountAssignments')
)
    CREATE UNIQUE INDEX [UX_crm_CrmAccountAssignments_1] ON [crm].[CrmAccountAssignments] ([TenantId], [AccountId], [Role]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmQuickReplies_1' AND object_id = OBJECT_ID(N'crm.CrmQuickReplies')
)
    CREATE UNIQUE INDEX [UX_crm_CrmQuickReplies_1] ON [crm].[CrmQuickReplies] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmChannels_1' AND object_id = OBJECT_ID(N'crm.CrmChannels')
)
    CREATE UNIQUE INDEX [UX_crm_CrmChannels_1] ON [crm].[CrmChannels] ([TenantId], [Kind], [Address]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmChannels_2' AND object_id = OBJECT_ID(N'crm.CrmChannels')
)
    CREATE UNIQUE INDEX [UX_crm_CrmChannels_2] ON [crm].[CrmChannels] ([TenantId], [Kind], [Address]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmBotFlows_1' AND object_id = OBJECT_ID(N'crm.CrmBotFlows')
)
    CREATE UNIQUE INDEX [UX_crm_CrmBotFlows_1] ON [crm].[CrmBotFlows] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmQueueTickets_1' AND object_id = OBJECT_ID(N'crm.CrmQueueTickets')
)
    CREATE UNIQUE INDEX [UX_crm_CrmQueueTickets_1] ON [crm].[CrmQueueTickets] ([TenantId], [BranchId], [ServiceDate], [OriginAreaId], [Seq]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmQueueDeskTypes_1' AND object_id = OBJECT_ID(N'crm.CrmQueueDeskTypes')
)
    CREATE UNIQUE INDEX [UX_crm_CrmQueueDeskTypes_1] ON [crm].[CrmQueueDeskTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmQueueDesks_1' AND object_id = OBJECT_ID(N'crm.CrmQueueDesks')
)
    CREATE UNIQUE INDEX [UX_crm_CrmQueueDesks_1] ON [crm].[CrmQueueDesks] ([TenantId], [BranchId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmQueueDeskSessions_1' AND object_id = OBJECT_ID(N'crm.CrmQueueDeskSessions')
)
    CREATE UNIQUE INDEX [UX_crm_CrmQueueDeskSessions_1] ON [crm].[CrmQueueDeskSessions] ([TenantId], [DeskId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmQueueDisplays_1' AND object_id = OBJECT_ID(N'crm.CrmQueueDisplays')
)
    CREATE UNIQUE INDEX [UX_crm_CrmQueueDisplays_1] ON [crm].[CrmQueueDisplays] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmActivityFrequencies_1' AND object_id = OBJECT_ID(N'crm.CrmActivityFrequencies')
)
    CREATE UNIQUE INDEX [UX_crm_CrmActivityFrequencies_1] ON [crm].[CrmActivityFrequencies] ([TenantId], [Kind], [Days]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmActivityRubros_1' AND object_id = OBJECT_ID(N'crm.CrmActivityRubros')
)
    CREATE UNIQUE INDEX [UX_crm_CrmActivityRubros_1] ON [crm].[CrmActivityRubros] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmActivityTypes_1' AND object_id = OBJECT_ID(N'crm.CrmActivityTypes')
)
    CREATE UNIQUE INDEX [UX_crm_CrmActivityTypes_1] ON [crm].[CrmActivityTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmActivities_1' AND object_id = OBJECT_ID(N'crm.CrmActivities')
)
    CREATE UNIQUE INDEX [UX_crm_CrmActivities_1] ON [crm].[CrmActivities] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmActivityOccurrences_1' AND object_id = OBJECT_ID(N'crm.CrmActivityOccurrences')
)
    CREATE UNIQUE INDEX [UX_crm_CrmActivityOccurrences_1] ON [crm].[CrmActivityOccurrences] ([TenantId], [ActivityId], [DueDate]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmCalendarEventTypes_1' AND object_id = OBJECT_ID(N'crm.CrmCalendarEventTypes')
)
    CREATE UNIQUE INDEX [UX_crm_CrmCalendarEventTypes_1] ON [crm].[CrmCalendarEventTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_crm_CrmCirculars_1' AND object_id = OBJECT_ID(N'crm.CrmCirculars')
)
    CREATE UNIQUE INDEX [UX_crm_CrmCirculars_1] ON [crm].[CrmCirculars] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_FeasibilityRequests_1' AND object_id = OBJECT_ID(N'tec.FeasibilityRequests')
)
    CREATE UNIQUE INDEX [UX_tec_FeasibilityRequests_1] ON [tec].[FeasibilityRequests] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_WorkOrderOperationTypes_1' AND object_id = OBJECT_ID(N'tec.WorkOrderOperationTypes')
)
    CREATE UNIQUE INDEX [UX_tec_WorkOrderOperationTypes_1] ON [tec].[WorkOrderOperationTypes] ([TenantId], [ServiceId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_WorkTypes_1' AND object_id = OBJECT_ID(N'tec.WorkTypes')
)
    CREATE UNIQUE INDEX [UX_tec_WorkTypes_1] ON [tec].[WorkTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_IncidentCategories_1' AND object_id = OBJECT_ID(N'tec.IncidentCategories')
)
    CREATE UNIQUE INDEX [UX_tec_IncidentCategories_1] ON [tec].[IncidentCategories] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_ResolutionCodes_1' AND object_id = OBJECT_ID(N'tec.ResolutionCodes')
)
    CREATE UNIQUE INDEX [UX_tec_ResolutionCodes_1] ON [tec].[ResolutionCodes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_TaskCatalog_1' AND object_id = OBJECT_ID(N'tec.TaskCatalog')
)
    CREATE UNIQUE INDEX [UX_tec_TaskCatalog_1] ON [tec].[TaskCatalog] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_TaskGroups_1' AND object_id = OBJECT_ID(N'tec.TaskGroups')
)
    CREATE UNIQUE INDEX [UX_tec_TaskGroups_1] ON [tec].[TaskGroups] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_WorkOrderPrintTemplates_1' AND object_id = OBJECT_ID(N'tec.WorkOrderPrintTemplates')
)
    CREATE UNIQUE INDEX [UX_tec_WorkOrderPrintTemplates_1] ON [tec].[WorkOrderPrintTemplates] ([TenantId], [ServiceId], [OperationTypeId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_ChainedOrderRules_1' AND object_id = OBJECT_ID(N'tec.ChainedOrderRules')
)
    CREATE UNIQUE INDEX [UX_tec_ChainedOrderRules_1] ON [tec].[ChainedOrderRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_WorkOrders_1' AND object_id = OBJECT_ID(N'tec.WorkOrders')
)
    CREATE UNIQUE INDEX [UX_tec_WorkOrders_1] ON [tec].[WorkOrders] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_WorkOrderMaterials_1' AND object_id = OBJECT_ID(N'tec.WorkOrderMaterials')
)
    CREATE UNIQUE INDEX [UX_tec_WorkOrderMaterials_1] ON [tec].[WorkOrderMaterials] ([TenantId], [ClientMutationId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_FieldEvidence_1' AND object_id = OBJECT_ID(N'tec.FieldEvidence')
)
    CREATE UNIQUE INDEX [UX_tec_FieldEvidence_1] ON [tec].[FieldEvidence] ([TenantId], [ClientMutationId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_ServiceConformities_1' AND object_id = OBJECT_ID(N'tec.ServiceConformities')
)
    CREATE UNIQUE INDEX [UX_tec_ServiceConformities_1] ON [tec].[ServiceConformities] ([TenantId], [WorkOrderId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_TechnicalProcedures_1' AND object_id = OBJECT_ID(N'tec.TechnicalProcedures')
)
    CREATE UNIQUE INDEX [UX_tec_TechnicalProcedures_1] ON [tec].[TechnicalProcedures] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_VisitTypes_1' AND object_id = OBJECT_ID(N'tec.VisitTypes')
)
    CREATE UNIQUE INDEX [UX_tec_VisitTypes_1] ON [tec].[VisitTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_SchedulingZones_1' AND object_id = OBJECT_ID(N'tec.SchedulingZones')
)
    CREATE UNIQUE INDEX [UX_tec_SchedulingZones_1] ON [tec].[SchedulingZones] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_Crews_1' AND object_id = OBJECT_ID(N'tec.Crews')
)
    CREATE UNIQUE INDEX [UX_tec_Crews_1] ON [tec].[Crews] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_FieldResources_1' AND object_id = OBJECT_ID(N'tec.FieldResources')
)
    CREATE UNIQUE INDEX [UX_tec_FieldResources_1] ON [tec].[FieldResources] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_ResponsibleNotificationRules_1' AND object_id = OBJECT_ID(N'tec.ResponsibleNotificationRules')
)
    CREATE UNIQUE INDEX [UX_tec_ResponsibleNotificationRules_1] ON [tec].[ResponsibleNotificationRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_CertifiedInstallers_1' AND object_id = OBJECT_ID(N'tec.CertifiedInstallers')
)
    CREATE UNIQUE INDEX [UX_tec_CertifiedInstallers_1] ON [tec].[CertifiedInstallers] ([TenantId], [LicenseNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_FieldForms_1' AND object_id = OBJECT_ID(N'tec.FieldForms')
)
    CREATE UNIQUE INDEX [UX_tec_FieldForms_1] ON [tec].[FieldForms] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_FieldDevices_1' AND object_id = OBJECT_ID(N'tec.FieldDevices')
)
    CREATE UNIQUE INDEX [UX_tec_FieldDevices_1] ON [tec].[FieldDevices] ([TenantId], [DeviceId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_SyncMutations_1' AND object_id = OBJECT_ID(N'tec.SyncMutations')
)
    CREATE UNIQUE INDEX [UX_tec_SyncMutations_1] ON [tec].[SyncMutations] ([TenantId], [ClientMutationId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_MaintenancePlans_1' AND object_id = OBJECT_ID(N'tec.MaintenancePlans')
)
    CREATE UNIQUE INDEX [UX_tec_MaintenancePlans_1] ON [tec].[MaintenancePlans] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_OutagePlans_1' AND object_id = OBJECT_ID(N'tec.OutagePlans')
)
    CREATE UNIQUE INDEX [UX_tec_OutagePlans_1] ON [tec].[OutagePlans] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_Networks_1' AND object_id = OBJECT_ID(N'tec.Networks')
)
    CREATE UNIQUE INDEX [UX_tec_Networks_1] ON [tec].[Networks] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_NetworkLayers_1' AND object_id = OBJECT_ID(N'tec.NetworkLayers')
)
    CREATE UNIQUE INDEX [UX_tec_NetworkLayers_1] ON [tec].[NetworkLayers] ([TenantId], [NetworkId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_NetworkComponentTypes_1' AND object_id = OBJECT_ID(N'tec.NetworkComponentTypes')
)
    CREATE UNIQUE INDEX [UX_tec_NetworkComponentTypes_1] ON [tec].[NetworkComponentTypes] ([TenantId], [NetworkId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_NetworkComponentRelations_1' AND object_id = OBJECT_ID(N'tec.NetworkComponentRelations')
)
    CREATE UNIQUE INDEX [UX_tec_NetworkComponentRelations_1] ON [tec].[NetworkComponentRelations] ([TenantId], [NetworkId], [LayerId], [ParentTypeId], [ChildTypeId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_NetworkAttributeDefs_1' AND object_id = OBJECT_ID(N'tec.NetworkAttributeDefs')
)
    CREATE UNIQUE INDEX [UX_tec_NetworkAttributeDefs_1] ON [tec].[NetworkAttributeDefs] ([TenantId], [ComponentTypeId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_NetworkElements_1' AND object_id = OBJECT_ID(N'tec.NetworkElements')
)
    CREATE UNIQUE INDEX [UX_tec_NetworkElements_1] ON [tec].[NetworkElements] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_ServiceNetworkConnections_1' AND object_id = OBJECT_ID(N'tec.ServiceNetworkConnections')
)
    CREATE UNIQUE INDEX [UX_tec_ServiceNetworkConnections_1] ON [tec].[ServiceNetworkConnections] ([TenantId], [NetworkElementId], [Position]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_GisExportTemplates_1' AND object_id = OBJECT_ID(N'tec.GisExportTemplates')
)
    CREATE UNIQUE INDEX [UX_tec_GisExportTemplates_1] ON [tec].[GisExportTemplates] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_NetworkDevices_1' AND object_id = OBJECT_ID(N'tec.NetworkDevices')
)
    CREATE UNIQUE INDEX [UX_tec_NetworkDevices_1] ON [tec].[NetworkDevices] ([TenantId], [Kind], [Serial]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_ProvisioningSystems_1' AND object_id = OBJECT_ID(N'tec.ProvisioningSystems')
)
    CREATE UNIQUE INDEX [UX_tec_ProvisioningSystems_1] ON [tec].[ProvisioningSystems] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_ProvisioningProfiles_1' AND object_id = OBJECT_ID(N'tec.ProvisioningProfiles')
)
    CREATE UNIQUE INDEX [UX_tec_ProvisioningProfiles_1] ON [tec].[ProvisioningProfiles] ([TenantId], [ProvisioningSystemId], [PlanId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_ServiceTechnicalProfiles_1' AND object_id = OBJECT_ID(N'tec.ServiceTechnicalProfiles')
)
    CREATE UNIQUE INDEX [UX_tec_ServiceTechnicalProfiles_1] ON [tec].[ServiceTechnicalProfiles] ([TenantId], [ContractId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_ProvisioningCommands_1' AND object_id = OBJECT_ID(N'tec.ProvisioningCommands')
)
    CREATE UNIQUE INDEX [UX_tec_ProvisioningCommands_1] ON [tec].[ProvisioningCommands] ([TenantId], [CommandId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_Works_1' AND object_id = OBJECT_ID(N'tec.Works')
)
    CREATE UNIQUE INDEX [UX_tec_Works_1] ON [tec].[Works] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_WorkGroups_1' AND object_id = OBJECT_ID(N'tec.WorkGroups')
)
    CREATE UNIQUE INDEX [UX_tec_WorkGroups_1] ON [tec].[WorkGroups] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_WorkBeneficiaries_1' AND object_id = OBJECT_ID(N'tec.WorkBeneficiaries')
)
    CREATE UNIQUE INDEX [UX_tec_WorkBeneficiaries_1] ON [tec].[WorkBeneficiaries] ([TenantId], [WorkId], [PremiseId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_InspectionCases_1' AND object_id = OBJECT_ID(N'tec.InspectionCases')
)
    CREATE UNIQUE INDEX [UX_tec_InspectionCases_1] ON [tec].[InspectionCases] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_Seals_1' AND object_id = OBJECT_ID(N'tec.Seals')
)
    CREATE UNIQUE INDEX [UX_tec_Seals_1] ON [tec].[Seals] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_PhoneExchanges_1' AND object_id = OBJECT_ID(N'tec.PhoneExchanges')
)
    CREATE UNIQUE INDEX [UX_tec_PhoneExchanges_1] ON [tec].[PhoneExchanges] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_PhoneFrames_1' AND object_id = OBJECT_ID(N'tec.PhoneFrames')
)
    CREATE UNIQUE INDEX [UX_tec_PhoneFrames_1] ON [tec].[PhoneFrames] ([TenantId], [ExchangeId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_PhoneFrameGroups_1' AND object_id = OBJECT_ID(N'tec.PhoneFrameGroups')
)
    CREATE UNIQUE INDEX [UX_tec_PhoneFrameGroups_1] ON [tec].[PhoneFrameGroups] ([TenantId], [FrameId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_PhoneStrips_1' AND object_id = OBJECT_ID(N'tec.PhoneStrips')
)
    CREATE UNIQUE INDEX [UX_tec_PhoneStrips_1] ON [tec].[PhoneStrips] ([TenantId], [FrameGroupId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_PhoneStripPositions_1' AND object_id = OBJECT_ID(N'tec.PhoneStripPositions')
)
    CREATE UNIQUE INDEX [UX_tec_PhoneStripPositions_1] ON [tec].[PhoneStripPositions] ([TenantId], [StripId], [Position]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_PhoneBoxes_1' AND object_id = OBJECT_ID(N'tec.PhoneBoxes')
)
    CREATE UNIQUE INDEX [UX_tec_PhoneBoxes_1] ON [tec].[PhoneBoxes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_Dslams_1' AND object_id = OBJECT_ID(N'tec.Dslams')
)
    CREATE UNIQUE INDEX [UX_tec_Dslams_1] ON [tec].[Dslams] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_PhonePorts_1' AND object_id = OBJECT_ID(N'tec.PhonePorts')
)
    CREATE UNIQUE INDEX [UX_tec_PhonePorts_1] ON [tec].[PhonePorts] ([TenantId], [DslamId], [Port]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_PhonePrefixes_1' AND object_id = OBJECT_ID(N'tec.PhonePrefixes')
)
    CREATE UNIQUE INDEX [UX_tec_PhonePrefixes_1] ON [tec].[PhonePrefixes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_PhoneNumbers_1' AND object_id = OBJECT_ID(N'tec.PhoneNumbers')
)
    CREATE UNIQUE INDEX [UX_tec_PhoneNumbers_1] ON [tec].[PhoneNumbers] ([TenantId], [PrefixId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_PhoneLines_1' AND object_id = OBJECT_ID(N'tec.PhoneLines')
)
    CREATE UNIQUE INDEX [UX_tec_PhoneLines_1] ON [tec].[PhoneLines] ([TenantId], [PhoneNumberId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_NumberingPlan_1' AND object_id = OBJECT_ID(N'tec.NumberingPlan')
)
    CREATE UNIQUE INDEX [UX_tec_NumberingPlan_1] ON [tec].[NumberingPlan] ([TenantId], [DestinationKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_TelecomOperators_1' AND object_id = OBJECT_ID(N'tec.TelecomOperators')
)
    CREATE UNIQUE INDEX [UX_tec_TelecomOperators_1] ON [tec].[TelecomOperators] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_TelecomServiceTypes_1' AND object_id = OBJECT_ID(N'tec.TelecomServiceTypes')
)
    CREATE UNIQUE INDEX [UX_tec_TelecomServiceTypes_1] ON [tec].[TelecomServiceTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_TelecomModalities_1' AND object_id = OBJECT_ID(N'tec.TelecomModalities')
)
    CREATE UNIQUE INDEX [UX_tec_TelecomModalities_1] ON [tec].[TelecomModalities] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_CdrImports_1' AND object_id = OBJECT_ID(N'tec.CdrImports')
)
    CREATE UNIQUE INDEX [UX_tec_CdrImports_1] ON [tec].[CdrImports] ([TenantId], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_CallRecords_1' AND object_id = OBJECT_ID(N'tec.CallRecords')
)
    CREATE UNIQUE INDEX [UX_tec_CallRecords_1] ON [tec].[CallRecords] ([TenantId], [DedupeKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_MobileUsageImports_1' AND object_id = OBJECT_ID(N'tec.MobileUsageImports')
)
    CREATE UNIQUE INDEX [UX_tec_MobileUsageImports_1] ON [tec].[MobileUsageImports] ([TenantId], [OperatorId], [Period], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_ProvidedMailboxes_1' AND object_id = OBJECT_ID(N'tec.ProvidedMailboxes')
)
    CREATE UNIQUE INDEX [UX_tec_ProvidedMailboxes_1] ON [tec].[ProvidedMailboxes] ([TenantId], [Address]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_SlotCounters_1' AND object_id = OBJECT_ID(N'tec.SlotCounters')
)
    CREATE UNIQUE INDEX [UX_tec_SlotCounters_1] ON [tec].[SlotCounters] ([TenantId], [SlotKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tec_NumberPortings_1' AND object_id = OBJECT_ID(N'tec.NumberPortings')
)
    CREATE UNIQUE INDEX [UX_tec_NumberPortings_1] ON [tec].[NumberPortings] ([TenantId], [PortId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_OperationCharges_1' AND object_id = OBJECT_ID(N'ven.OperationCharges')
)
    CREATE UNIQUE INDEX [UX_ven_OperationCharges_1] ON [ven].[OperationCharges] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesConditions_1' AND object_id = OBJECT_ID(N'ven.SalesConditions')
)
    CREATE UNIQUE INDEX [UX_ven_SalesConditions_1] ON [ven].[SalesConditions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesQuotes_1' AND object_id = OBJECT_ID(N'ven.SalesQuotes')
)
    CREATE UNIQUE INDEX [UX_ven_SalesQuotes_1] ON [ven].[SalesQuotes] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesOrders_1' AND object_id = OBJECT_ID(N'ven.SalesOrders')
)
    CREATE UNIQUE INDEX [UX_ven_SalesOrders_1] ON [ven].[SalesOrders] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesDeliveries_1' AND object_id = OBJECT_ID(N'ven.SalesDeliveries')
)
    CREATE UNIQUE INDEX [UX_ven_SalesDeliveries_1] ON [ven].[SalesDeliveries] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesReturns_1' AND object_id = OBJECT_ID(N'ven.SalesReturns')
)
    CREATE UNIQUE INDEX [UX_ven_SalesReturns_1] ON [ven].[SalesReturns] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesFinancingPlans_1' AND object_id = OBJECT_ID(N'ven.SalesFinancingPlans')
)
    CREATE UNIQUE INDEX [UX_ven_SalesFinancingPlans_1] ON [ven].[SalesFinancingPlans] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesInstallments_1' AND object_id = OBJECT_ID(N'ven.SalesInstallments')
)
    CREATE UNIQUE INDEX [UX_ven_SalesInstallments_1] ON [ven].[SalesInstallments] ([TenantId], [OriginType], [OriginId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesReps_1' AND object_id = OBJECT_ID(N'ven.SalesReps')
)
    CREATE UNIQUE INDEX [UX_ven_SalesReps_1] ON [ven].[SalesReps] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesReps_2' AND object_id = OBJECT_ID(N'ven.SalesReps')
)
    CREATE UNIQUE INDEX [UX_ven_SalesReps_2] ON [ven].[SalesReps] ([TenantId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesReps_3' AND object_id = OBJECT_ID(N'ven.SalesReps')
)
    CREATE UNIQUE INDEX [UX_ven_SalesReps_3] ON [ven].[SalesReps] ([TenantId], [DEC]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesPriceLists_1' AND object_id = OBJECT_ID(N'ven.SalesPriceLists')
)
    CREATE UNIQUE INDEX [UX_ven_SalesPriceLists_1] ON [ven].[SalesPriceLists] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_SalesDiscountRules_1' AND object_id = OBJECT_ID(N'ven.SalesDiscountRules')
)
    CREATE UNIQUE INDEX [UX_ven_SalesDiscountRules_1] ON [ven].[SalesDiscountRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_PosTerminals_1' AND object_id = OBJECT_ID(N'ven.PosTerminals')
)
    CREATE UNIQUE INDEX [UX_ven_PosTerminals_1] ON [ven].[PosTerminals] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ven_PosSessions_1' AND object_id = OBJECT_ID(N'ven.PosSessions')
)
    CREATE UNIQUE INDEX [UX_ven_PosSessions_1] ON [ven].[PosSessions] ([TenantId], [PosTerminalId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_Suppliers_1' AND object_id = OBJECT_ID(N'cmp.Suppliers')
)
    CREATE UNIQUE INDEX [UX_cmp_Suppliers_1] ON [cmp].[Suppliers] ([TenantId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_Suppliers_2' AND object_id = OBJECT_ID(N'cmp.Suppliers')
)
    CREATE UNIQUE INDEX [UX_cmp_Suppliers_2] ON [cmp].[Suppliers] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_Suppliers_3' AND object_id = OBJECT_ID(N'cmp.Suppliers')
)
    CREATE UNIQUE INDEX [UX_cmp_Suppliers_3] ON [cmp].[Suppliers] ([TenantId], [Antes]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_Suppliers_4' AND object_id = OBJECT_ID(N'cmp.Suppliers')
)
    CREATE UNIQUE INDEX [UX_cmp_Suppliers_4] ON [cmp].[Suppliers] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_Suppliers_5' AND object_id = OBJECT_ID(N'cmp.Suppliers')
)
    CREATE UNIQUE INDEX [UX_cmp_Suppliers_5] ON [cmp].[Suppliers] ([TenantId], [CTR]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_SupplierCategories_1' AND object_id = OBJECT_ID(N'cmp.SupplierCategories')
)
    CREATE UNIQUE INDEX [UX_cmp_SupplierCategories_1] ON [cmp].[SupplierCategories] ([TenantId], [Kind], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_PurchaseConcepts_1' AND object_id = OBJECT_ID(N'cmp.PurchaseConcepts')
)
    CREATE UNIQUE INDEX [UX_cmp_PurchaseConcepts_1] ON [cmp].[PurchaseConcepts] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_PurchaseLookups_1' AND object_id = OBJECT_ID(N'cmp.PurchaseLookups')
)
    CREATE UNIQUE INDEX [UX_cmp_PurchaseLookups_1] ON [cmp].[PurchaseLookups] ([TenantId], [Kind], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_SupplyRequests_1' AND object_id = OBJECT_ID(N'cmp.SupplyRequests')
)
    CREATE UNIQUE INDEX [UX_cmp_SupplyRequests_1] ON [cmp].[SupplyRequests] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_QuoteRequests_1' AND object_id = OBJECT_ID(N'cmp.QuoteRequests')
)
    CREATE UNIQUE INDEX [UX_cmp_QuoteRequests_1] ON [cmp].[QuoteRequests] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_SourcingEvents_1' AND object_id = OBJECT_ID(N'cmp.SourcingEvents')
)
    CREATE UNIQUE INDEX [UX_cmp_SourcingEvents_1] ON [cmp].[SourcingEvents] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_PurchaseOrders_1' AND object_id = OBJECT_ID(N'cmp.PurchaseOrders')
)
    CREATE UNIQUE INDEX [UX_cmp_PurchaseOrders_1] ON [cmp].[PurchaseOrders] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_SupplierInvoices_1' AND object_id = OBJECT_ID(N'cmp.SupplierInvoices')
)
    CREATE UNIQUE INDEX [UX_cmp_SupplierInvoices_1] ON [cmp].[SupplierInvoices] ([TenantId], [SupplierId], [DocumentType], [PointOfSale], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_PaymentOrders_1' AND object_id = OBJECT_ID(N'cmp.PaymentOrders')
)
    CREATE UNIQUE INDEX [UX_cmp_PaymentOrders_1] ON [cmp].[PaymentOrders] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_SupplierPortalSubmissions_1' AND object_id = OBJECT_ID(N'cmp.SupplierPortalSubmissions')
)
    CREATE UNIQUE INDEX [UX_cmp_SupplierPortalSubmissions_1] ON [cmp].[SupplierPortalSubmissions] ([TenantId], [TaxId], [DocumentType], [PointOfSale], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_SupplyBalances_1' AND object_id = OBJECT_ID(N'cmp.SupplyBalances')
)
    CREATE UNIQUE INDEX [UX_cmp_SupplyBalances_1] ON [cmp].[SupplyBalances] ([TenantId], [Kind], [ServiceId], [ZoneId], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_cmp_SignalRightsSettlements_1' AND object_id = OBJECT_ID(N'cmp.SignalRightsSettlements')
)
    CREATE UNIQUE INDEX [UX_cmp_SignalRightsSettlements_1] ON [cmp].[SignalRightsSettlements] ([TenantId], [ContractId], [Period], [AdjustsSettlementId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ItemTypes_1' AND object_id = OBJECT_ID(N'stk.ItemTypes')
)
    CREATE UNIQUE INDEX [UX_stk_ItemTypes_1] ON [stk].[ItemTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ItemClassifications_1' AND object_id = OBJECT_ID(N'stk.ItemClassifications')
)
    CREATE UNIQUE INDEX [UX_stk_ItemClassifications_1] ON [stk].[ItemClassifications] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ItemGroups_1' AND object_id = OBJECT_ID(N'stk.ItemGroups')
)
    CREATE UNIQUE INDEX [UX_stk_ItemGroups_1] ON [stk].[ItemGroups] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ItemDepartments_1' AND object_id = OBJECT_ID(N'stk.ItemDepartments')
)
    CREATE UNIQUE INDEX [UX_stk_ItemDepartments_1] ON [stk].[ItemDepartments] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_InventoryItems_1' AND object_id = OBJECT_ID(N'stk.InventoryItems')
)
    CREATE UNIQUE INDEX [UX_stk_InventoryItems_1] ON [stk].[InventoryItems] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_InventoryItems_2' AND object_id = OBJECT_ID(N'stk.InventoryItems')
)
    CREATE UNIQUE INDEX [UX_stk_InventoryItems_2] ON [stk].[InventoryItems] ([TenantId], [RegistrationNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ItemKits_1' AND object_id = OBJECT_ID(N'stk.ItemKits')
)
    CREATE UNIQUE INDEX [UX_stk_ItemKits_1] ON [stk].[ItemKits] ([TenantId], [KitItemId], [ComponentItemId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_Warehouses_1' AND object_id = OBJECT_ID(N'stk.Warehouses')
)
    CREATE UNIQUE INDEX [UX_stk_Warehouses_1] ON [stk].[Warehouses] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_WarehouseLocations_1' AND object_id = OBJECT_ID(N'stk.WarehouseLocations')
)
    CREATE UNIQUE INDEX [UX_stk_WarehouseLocations_1] ON [stk].[WarehouseLocations] ([TenantId], [WarehouseId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ItemLocationDefaults_1' AND object_id = OBJECT_ID(N'stk.ItemLocationDefaults')
)
    CREATE UNIQUE INDEX [UX_stk_ItemLocationDefaults_1] ON [stk].[ItemLocationDefaults] ([TenantId], [InventoryItemId], [WarehouseId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_StockDocuments_1' AND object_id = OBJECT_ID(N'stk.StockDocuments')
)
    CREATE UNIQUE INDEX [UX_stk_StockDocuments_1] ON [stk].[StockDocuments] ([TenantId], [DocType], [NumberDisplay]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_StockBalances_1' AND object_id = OBJECT_ID(N'stk.StockBalances')
)
    CREATE UNIQUE INDEX [UX_stk_StockBalances_1] ON [stk].[StockBalances] ([TenantId], [InventoryItemId], [WarehouseId], [LocationId], [LotId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_SerialUnits_1' AND object_id = OBJECT_ID(N'stk.SerialUnits')
)
    CREATE UNIQUE INDEX [UX_stk_SerialUnits_1] ON [stk].[SerialUnits] ([TenantId], [InventoryItemId], [SerialNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_SerialUnits_2' AND object_id = OBJECT_ID(N'stk.SerialUnits')
)
    CREATE UNIQUE INDEX [UX_stk_SerialUnits_2] ON [stk].[SerialUnits] ([TenantId], [SecondaryIdsType], [SecondaryIdsValue]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_LotTypes_1' AND object_id = OBJECT_ID(N'stk.LotTypes')
)
    CREATE UNIQUE INDEX [UX_stk_LotTypes_1] ON [stk].[LotTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_Lots_1' AND object_id = OBJECT_ID(N'stk.Lots')
)
    CREATE UNIQUE INDEX [UX_stk_Lots_1] ON [stk].[Lots] ([TenantId], [InventoryItemId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_CrewSettlements_1' AND object_id = OBJECT_ID(N'stk.CrewSettlements')
)
    CREATE UNIQUE INDEX [UX_stk_CrewSettlements_1] ON [stk].[CrewSettlements] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_PhysicalCounts_1' AND object_id = OBJECT_ID(N'stk.PhysicalCounts')
)
    CREATE UNIQUE INDEX [UX_stk_PhysicalCounts_1] ON [stk].[PhysicalCounts] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ItemCostStates_1' AND object_id = OBJECT_ID(N'stk.ItemCostStates')
)
    CREATE UNIQUE INDEX [UX_stk_ItemCostStates_1] ON [stk].[ItemCostStates] ([TenantId], [InventoryItemId], [WarehouseId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_Revaluations_1' AND object_id = OBJECT_ID(N'stk.Revaluations')
)
    CREATE UNIQUE INDEX [UX_stk_Revaluations_1] ON [stk].[Revaluations] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ExpenseUnits_1' AND object_id = OBJECT_ID(N'stk.ExpenseUnits')
)
    CREATE UNIQUE INDEX [UX_stk_ExpenseUnits_1] ON [stk].[ExpenseUnits] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_FixedAssets_1' AND object_id = OBJECT_ID(N'stk.FixedAssets')
)
    CREATE UNIQUE INDEX [UX_stk_FixedAssets_1] ON [stk].[FixedAssets] ([TenantId], [AssetNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_DepreciationRuns_1' AND object_id = OBJECT_ID(N'stk.DepreciationRuns')
)
    CREATE UNIQUE INDEX [UX_stk_DepreciationRuns_1] ON [stk].[DepreciationRuns] ([TenantId], [FiscalYearId], [Period]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_FixedAssetDepreciations_1' AND object_id = OBJECT_ID(N'stk.FixedAssetDepreciations')
)
    CREATE UNIQUE INDEX [UX_stk_FixedAssetDepreciations_1] ON [stk].[FixedAssetDepreciations] ([TenantId], [DepreciationRunId], [FixedAssetId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_RmaCases_1' AND object_id = OBJECT_ID(N'stk.RmaCases')
)
    CREATE UNIQUE INDEX [UX_stk_RmaCases_1] ON [stk].[RmaCases] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ReceptionStatuses_1' AND object_id = OBJECT_ID(N'stk.ReceptionStatuses')
)
    CREATE UNIQUE INDEX [UX_stk_ReceptionStatuses_1] ON [stk].[ReceptionStatuses] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ServiceReceptions_1' AND object_id = OBJECT_ID(N'stk.ServiceReceptions')
)
    CREATE UNIQUE INDEX [UX_stk_ServiceReceptions_1] ON [stk].[ServiceReceptions] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_BomStructures_1' AND object_id = OBJECT_ID(N'stk.BomStructures')
)
    CREATE UNIQUE INDEX [UX_stk_BomStructures_1] ON [stk].[BomStructures] ([TenantId], [InventoryItemId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_BomStructureVersions_1' AND object_id = OBJECT_ID(N'stk.BomStructureVersions')
)
    CREATE UNIQUE INDEX [UX_stk_BomStructureVersions_1] ON [stk].[BomStructureVersions] ([TenantId], [BomStructureId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ProductDivisions_1' AND object_id = OBJECT_ID(N'stk.ProductDivisions')
)
    CREATE UNIQUE INDEX [UX_stk_ProductDivisions_1] ON [stk].[ProductDivisions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ManufacturingStages_1' AND object_id = OBJECT_ID(N'stk.ManufacturingStages')
)
    CREATE UNIQUE INDEX [UX_stk_ManufacturingStages_1] ON [stk].[ManufacturingStages] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ManufacturingOrders_1' AND object_id = OBJECT_ID(N'stk.ManufacturingOrders')
)
    CREATE UNIQUE INDEX [UX_stk_ManufacturingOrders_1] ON [stk].[ManufacturingOrders] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_stk_ProductionReports_1' AND object_id = OBJECT_ID(N'stk.ProductionReports')
)
    CREATE UNIQUE INDEX [UX_stk_ProductionReports_1] ON [stk].[ProductionReports] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_FinancialInstitutions_1' AND object_id = OBJECT_ID(N'tes.FinancialInstitutions')
)
    CREATE UNIQUE INDEX [UX_tes_FinancialInstitutions_1] ON [tes].[FinancialInstitutions] ([TenantId], [BcraCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_BankBranches_1' AND object_id = OBJECT_ID(N'tes.BankBranches')
)
    CREATE UNIQUE INDEX [UX_tes_BankBranches_1] ON [tes].[BankBranches] ([TenantId], [InstitutionId], [BranchCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_TreasuryAccounts_1' AND object_id = OBJECT_ID(N'tes.TreasuryAccounts')
)
    CREATE UNIQUE INDEX [UX_tes_TreasuryAccounts_1] ON [tes].[TreasuryAccounts] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_TreasuryAccounts_2' AND object_id = OBJECT_ID(N'tes.TreasuryAccounts')
)
    CREATE UNIQUE INDEX [UX_tes_TreasuryAccounts_2] ON [tes].[TreasuryAccounts] ([TenantId], [Cbu]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_TreasuryAccountSigners_1' AND object_id = OBJECT_ID(N'tes.TreasuryAccountSigners')
)
    CREATE UNIQUE INDEX [UX_tes_TreasuryAccountSigners_1] ON [tes].[TreasuryAccountSigners] ([TenantId], [TreasuryAccountId], [PersonId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_TreasuryCategories_1' AND object_id = OBJECT_ID(N'tes.TreasuryCategories')
)
    CREATE UNIQUE INDEX [UX_tes_TreasuryCategories_1] ON [tes].[TreasuryCategories] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_TreasuryConcepts_1' AND object_id = OBJECT_ID(N'tes.TreasuryConcepts')
)
    CREATE UNIQUE INDEX [UX_tes_TreasuryConcepts_1] ON [tes].[TreasuryConcepts] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_InstrumentTypes_1' AND object_id = OBJECT_ID(N'tes.InstrumentTypes')
)
    CREATE UNIQUE INDEX [UX_tes_InstrumentTypes_1] ON [tes].[InstrumentTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_CheckDrawerAccounts_1' AND object_id = OBJECT_ID(N'tes.CheckDrawerAccounts')
)
    CREATE UNIQUE INDEX [UX_tes_CheckDrawerAccounts_1] ON [tes].[CheckDrawerAccounts] ([TenantId], [InstitutionId], [BankBranchId], [AccountNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_TreasuryOperations_1' AND object_id = OBJECT_ID(N'tes.TreasuryOperations')
)
    CREATE UNIQUE INDEX [UX_tes_TreasuryOperations_1] ON [tes].[TreasuryOperations] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_TreasuryOperations_2' AND object_id = OBJECT_ID(N'tes.TreasuryOperations')
)
    CREATE UNIQUE INDEX [UX_tes_TreasuryOperations_2] ON [tes].[TreasuryOperations] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_BankDeposits_1' AND object_id = OBJECT_ID(N'tes.BankDeposits')
)
    CREATE UNIQUE INDEX [UX_tes_BankDeposits_1] ON [tes].[BankDeposits] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_StatementImportProfiles_1' AND object_id = OBJECT_ID(N'tes.StatementImportProfiles')
)
    CREATE UNIQUE INDEX [UX_tes_StatementImportProfiles_1] ON [tes].[StatementImportProfiles] ([TenantId], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_BankStatementImports_1' AND object_id = OBJECT_ID(N'tes.BankStatementImports')
)
    CREATE UNIQUE INDEX [UX_tes_BankStatementImports_1] ON [tes].[BankStatementImports] ([TenantId], [StoredFileId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_BankStatementImports_2' AND object_id = OBJECT_ID(N'tes.BankStatementImports')
)
    CREATE UNIQUE INDEX [UX_tes_BankStatementImports_2] ON [tes].[BankStatementImports] ([TenantId], [Antes]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_BankStatementLines_1' AND object_id = OBJECT_ID(N'tes.BankStatementLines')
)
    CREATE UNIQUE INDEX [UX_tes_BankStatementLines_1] ON [tes].[BankStatementLines] ([TenantId], [TreasuryAccountId], [Fingerprint]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_BankStatementLines_2' AND object_id = OBJECT_ID(N'tes.BankStatementLines')
)
    CREATE UNIQUE INDEX [UX_tes_BankStatementLines_2] ON [tes].[BankStatementLines] ([TenantId], [AccountId], [Fingerprint]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_Reconciliations_1' AND object_id = OBJECT_ID(N'tes.Reconciliations')
)
    CREATE UNIQUE INDEX [UX_tes_Reconciliations_1] ON [tes].[Reconciliations] ([TenantId], [AccountId], [CutoffDate]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_ReconciliationRules_1' AND object_id = OBJECT_ID(N'tes.ReconciliationRules')
)
    CREATE UNIQUE INDEX [UX_tes_ReconciliationRules_1] ON [tes].[ReconciliationRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_InterbankingConnections_1' AND object_id = OBJECT_ID(N'tes.InterbankingConnections')
)
    CREATE UNIQUE INDEX [UX_tes_InterbankingConnections_1] ON [tes].[InterbankingConnections] ([TenantId], [LegalEntityId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_InterbankingBalanceSnapshots_1' AND object_id = OBJECT_ID(N'tes.InterbankingBalanceSnapshots')
)
    CREATE UNIQUE INDEX [UX_tes_InterbankingBalanceSnapshots_1] ON [tes].[InterbankingBalanceSnapshots] ([TenantId], [AccountId], [At]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_PaymentFiles_1' AND object_id = OBJECT_ID(N'tes.PaymentFiles')
)
    CREATE UNIQUE INDEX [UX_tes_PaymentFiles_1] ON [tes].[PaymentFiles] ([TenantId], [OriginTreasuryAccountId], [Sequence]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_PaymentFiles_2' AND object_id = OBJECT_ID(N'tes.PaymentFiles')
)
    CREATE UNIQUE INDEX [UX_tes_PaymentFiles_2] ON [tes].[PaymentFiles] ([TenantId], [AccountId], [Sequence]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_ThirdPartyChecks_1' AND object_id = OBJECT_ID(N'tes.ThirdPartyChecks')
)
    CREATE UNIQUE INDEX [UX_tes_ThirdPartyChecks_1] ON [tes].[ThirdPartyChecks] ([TenantId], [InstitutionId], [BankBranchId], [AccountNumber], [CheckNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_ThirdPartyChecks_2' AND object_id = OBJECT_ID(N'tes.ThirdPartyChecks')
)
    CREATE UNIQUE INDEX [UX_tes_ThirdPartyChecks_2] ON [tes].[ThirdPartyChecks] ([TenantId], [InstitutionId], [BranchId], [AccountNumber], [CheckNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_Checkbooks_1' AND object_id = OBJECT_ID(N'tes.Checkbooks')
)
    CREATE UNIQUE INDEX [UX_tes_Checkbooks_1] ON [tes].[Checkbooks] ([TenantId], [AccountId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_OwnChecks_1' AND object_id = OBJECT_ID(N'tes.OwnChecks')
)
    CREATE UNIQUE INDEX [UX_tes_OwnChecks_1] ON [tes].[OwnChecks] ([TenantId], [AccountId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_CardVouchers_1' AND object_id = OBJECT_ID(N'tes.CardVouchers')
)
    CREATE UNIQUE INDEX [UX_tes_CardVouchers_1] ON [tes].[CardVouchers] ([TenantId], [CardPlanId], [VoucherNumber], [AuthorizationCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_CardPresentations_1' AND object_id = OBJECT_ID(N'tes.CardPresentations')
)
    CREATE UNIQUE INDEX [UX_tes_CardPresentations_1] ON [tes].[CardPresentations] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_CardSettlements_1' AND object_id = OBJECT_ID(N'tes.CardSettlements')
)
    CREATE UNIQUE INDEX [UX_tes_CardSettlements_1] ON [tes].[CardSettlements] ([TenantId], [CardPlanId], [SettlementNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_ReceivedWithholdings_1' AND object_id = OBJECT_ID(N'tes.ReceivedWithholdings')
)
    CREATE UNIQUE INDEX [UX_tes_ReceivedWithholdings_1] ON [tes].[ReceivedWithholdings] ([TenantId], [AgentCuit], [WithholdingType], [CertificateNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_WithholdingPresentations_1' AND object_id = OBJECT_ID(N'tes.WithholdingPresentations')
)
    CREATE UNIQUE INDEX [UX_tes_WithholdingPresentations_1] ON [tes].[WithholdingPresentations] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_PaymentCashSessions_1' AND object_id = OBJECT_ID(N'tes.PaymentCashSessions')
)
    CREATE UNIQUE INDEX [UX_tes_PaymentCashSessions_1] ON [tes].[PaymentCashSessions] ([TenantId], [AccountId], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_CashRemittances_1' AND object_id = OBJECT_ID(N'tes.CashRemittances')
)
    CREATE UNIQUE INDEX [UX_tes_CashRemittances_1] ON [tes].[CashRemittances] ([TenantId], [CashSessionId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_TreasuryCashClosings_1' AND object_id = OBJECT_ID(N'tes.TreasuryCashClosings')
)
    CREATE UNIQUE INDEX [UX_tes_TreasuryCashClosings_1] ON [tes].[TreasuryCashClosings] ([TenantId], [AccountId], [Date]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_PaymentExecutions_1' AND object_id = OBJECT_ID(N'tes.PaymentExecutions')
)
    CREATE UNIQUE INDEX [UX_tes_PaymentExecutions_1] ON [tes].[PaymentExecutions] ([TenantId], [SourceRefModule], [SourceRefDocId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_TenantCurrencySettings_1' AND object_id = OBJECT_ID(N'tes.TenantCurrencySettings')
)
    CREATE UNIQUE INDEX [UX_tes_TenantCurrencySettings_1] ON [tes].[TenantCurrencySettings] ([TenantId], [Currency]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_ExchangeRates_1' AND object_id = OBJECT_ID(N'tes.ExchangeRates')
)
    CREATE UNIQUE INDEX [UX_tes_ExchangeRates_1] ON [tes].[ExchangeRates] ([TenantId], [Currency], [Source], [QuotedAt]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_FundCommitments_1' AND object_id = OBJECT_ID(N'tes.FundCommitments')
)
    CREATE UNIQUE INDEX [UX_tes_FundCommitments_1] ON [tes].[FundCommitments] ([TenantId], [SourceRefModule], [SourceRefDocId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_CashFlowScenarios_1' AND object_id = OBJECT_ID(N'tes.CashFlowScenarios')
)
    CREATE UNIQUE INDEX [UX_tes_CashFlowScenarios_1] ON [tes].[CashFlowScenarios] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_PayrollPaymentBatches_1' AND object_id = OBJECT_ID(N'tes.PayrollPaymentBatches')
)
    CREATE UNIQUE INDEX [UX_tes_PayrollPaymentBatches_1] ON [tes].[PayrollPaymentBatches] ([TenantId], [PayrollRunId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_tes_PayrollPaymentBatches_2' AND object_id = OBJECT_ID(N'tes.PayrollPaymentBatches')
)
    CREATE UNIQUE INDEX [UX_tes_PayrollPaymentBatches_2] ON [tes].[PayrollPaymentBatches] ([TenantId], [Antes]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_ChartOfAccounts_1' AND object_id = OBJECT_ID(N'con.ChartOfAccounts')
)
    CREATE UNIQUE INDEX [UX_con_ChartOfAccounts_1] ON [con].[ChartOfAccounts] ([TenantId], [Code], [VersionNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_AccountRubrics_1' AND object_id = OBJECT_ID(N'con.AccountRubrics')
)
    CREATE UNIQUE INDEX [UX_con_AccountRubrics_1] ON [con].[AccountRubrics] ([TenantId], [ChartId], [Kind], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_LedgerAccounts_1' AND object_id = OBJECT_ID(N'con.LedgerAccounts')
)
    CREATE UNIQUE INDEX [UX_con_LedgerAccounts_1] ON [con].[LedgerAccounts] ([TenantId], [ChartId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_AccountRoles_1' AND object_id = OBJECT_ID(N'con.AccountRoles')
)
    CREATE UNIQUE INDEX [UX_con_AccountRoles_1] ON [con].[AccountRoles] ([TenantId], [ChartId], [RoleKey], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_PostingRules_1' AND object_id = OBJECT_ID(N'con.PostingRules')
)
    CREATE UNIQUE INDEX [UX_con_PostingRules_1] ON [con].[PostingRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_AccountingEvents_1' AND object_id = OBJECT_ID(N'con.AccountingEvents')
)
    CREATE UNIQUE INDEX [UX_con_AccountingEvents_1] ON [con].[AccountingEvents] ([TenantId], [SourceEventId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_JournalEntries_1' AND object_id = OBJECT_ID(N'con.JournalEntries')
)
    CREATE UNIQUE INDEX [UX_con_JournalEntries_1] ON [con].[JournalEntries] ([TenantId], [FiscalYearId], [EntryNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_JournalLines_1' AND object_id = OBJECT_ID(N'con.JournalLines')
)
    CREATE UNIQUE INDEX [UX_con_JournalLines_1] ON [con].[JournalLines] ([TenantId], [EntryId], [LineNo]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_EntryTemplates_1' AND object_id = OBJECT_ID(N'con.EntryTemplates')
)
    CREATE UNIQUE INDEX [UX_con_EntryTemplates_1] ON [con].[EntryTemplates] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_PostingBatches_1' AND object_id = OBJECT_ID(N'con.PostingBatches')
)
    CREATE UNIQUE INDEX [UX_con_PostingBatches_1] ON [con].[PostingBatches] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_FiscalYears_1' AND object_id = OBJECT_ID(N'con.FiscalYears')
)
    CREATE UNIQUE INDEX [UX_con_FiscalYears_1] ON [con].[FiscalYears] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_AccountingPeriods_1' AND object_id = OBJECT_ID(N'con.AccountingPeriods')
)
    CREATE UNIQUE INDEX [UX_con_AccountingPeriods_1] ON [con].[AccountingPeriods] ([TenantId], [Year], [Month]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_ResultTargets_1' AND object_id = OBJECT_ID(N'con.ResultTargets')
)
    CREATE UNIQUE INDEX [UX_con_ResultTargets_1] ON [con].[ResultTargets] ([TenantId], [S]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_CostCenters_1' AND object_id = OBJECT_ID(N'con.CostCenters')
)
    CREATE UNIQUE INDEX [UX_con_CostCenters_1] ON [con].[CostCenters] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_CostCenterGroups_1' AND object_id = OBJECT_ID(N'con.CostCenterGroups')
)
    CREATE UNIQUE INDEX [UX_con_CostCenterGroups_1] ON [con].[CostCenterGroups] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_CostAllocationRules_1' AND object_id = OBJECT_ID(N'con.CostAllocationRules')
)
    CREATE UNIQUE INDEX [UX_con_CostAllocationRules_1] ON [con].[CostAllocationRules] ([TenantId], [OperationType], [ElementType], [ElementId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_DistributionModels_1' AND object_id = OBJECT_ID(N'con.DistributionModels')
)
    CREATE UNIQUE INDEX [UX_con_DistributionModels_1] ON [con].[DistributionModels] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_CostDistributionRuns_1' AND object_id = OBJECT_ID(N'con.CostDistributionRuns')
)
    CREATE UNIQUE INDEX [UX_con_CostDistributionRuns_1] ON [con].[CostDistributionRuns] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_AccountMappings_1' AND object_id = OBJECT_ID(N'con.AccountMappings')
)
    CREATE UNIQUE INDEX [UX_con_AccountMappings_1] ON [con].[AccountMappings] ([TenantId], [SourceChartId], [TargetChartId], [SourceAccountId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_SimulationScenarios_1' AND object_id = OBJECT_ID(N'con.SimulationScenarios')
)
    CREATE UNIQUE INDEX [UX_con_SimulationScenarios_1] ON [con].[SimulationScenarios] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_LedgerBalances_1' AND object_id = OBJECT_ID(N'con.LedgerBalances')
)
    CREATE UNIQUE INDEX [UX_con_LedgerBalances_1] ON [con].[LedgerBalances] ([TenantId], [ChartId], [LedgerAccountId], [PeriodId], [CostCenterId], [ServiceId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_LedgerBalances_2' AND object_id = OBJECT_ID(N'con.LedgerBalances')
)
    CREATE UNIQUE INDEX [UX_con_LedgerBalances_2] ON [con].[LedgerBalances] ([TenantId], [ChartId], [AccountId], [PeriodId], [CostCenterId], [ServiceId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_Budgets_1' AND object_id = OBJECT_ID(N'con.Budgets')
)
    CREATE UNIQUE INDEX [UX_con_Budgets_1] ON [con].[Budgets] ([TenantId], [FiscalYearId], [Code], [VersionNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_BudgetLines_1' AND object_id = OBJECT_ID(N'con.BudgetLines')
)
    CREATE UNIQUE INDEX [UX_con_BudgetLines_1] ON [con].[BudgetLines] ([TenantId], [BudgetId], [LedgerAccountId], [CostCenterId], [ServiceId], [Month]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_BudgetLines_2' AND object_id = OBJECT_ID(N'con.BudgetLines')
)
    CREATE UNIQUE INDEX [UX_con_BudgetLines_2] ON [con].[BudgetLines] ([TenantId], [BudgetId], [AccountId], [CostCenterId], [ServiceId], [Month]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_Commitments_1' AND object_id = OBJECT_ID(N'con.Commitments')
)
    CREATE UNIQUE INDEX [UX_con_Commitments_1] ON [con].[Commitments] ([TenantId], [SourceDocumentType], [SourceDocumentId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_InflationAdjustmentRuns_1' AND object_id = OBJECT_ID(N'con.InflationAdjustmentRuns')
)
    CREATE UNIQUE INDEX [UX_con_InflationAdjustmentRuns_1] ON [con].[InflationAdjustmentRuns] ([TenantId], [FiscalYearId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_RubricatedBooks_1' AND object_id = OBJECT_ID(N'con.RubricatedBooks')
)
    CREATE UNIQUE INDEX [UX_con_RubricatedBooks_1] ON [con].[RubricatedBooks] ([TenantId], [BookType], [FiscalYearId], [Volume]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_StatementTemplates_1' AND object_id = OBJECT_ID(N'con.StatementTemplates')
)
    CREATE UNIQUE INDEX [UX_con_StatementTemplates_1] ON [con].[StatementTemplates] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_ExternalLedgerMappings_1' AND object_id = OBJECT_ID(N'con.ExternalLedgerMappings')
)
    CREATE UNIQUE INDEX [UX_con_ExternalLedgerMappings_1] ON [con].[ExternalLedgerMappings] ([TenantId], [ExternalSystem], [OperationCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_ExternalLedgerTransfers_1' AND object_id = OBJECT_ID(N'con.ExternalLedgerTransfers')
)
    CREATE UNIQUE INDEX [UX_con_ExternalLedgerTransfers_1] ON [con].[ExternalLedgerTransfers] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_EntityAccountAssignments_1' AND object_id = OBJECT_ID(N'con.EntityAccountAssignments')
)
    CREATE UNIQUE INDEX [UX_con_EntityAccountAssignments_1] ON [con].[EntityAccountAssignments] ([TenantId], [ChartId], [EntityType], [EntityId], [Usage], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_con_CostCenterModels_1' AND object_id = OBJECT_ID(N'con.CostCenterModels')
)
    CREATE UNIQUE INDEX [UX_con_CostCenterModels_1] ON [con].[CostCenterModels] ([TenantId], [Code], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_Employees_1' AND object_id = OBJECT_ID(N'sue.Employees')
)
    CREATE UNIQUE INDEX [UX_sue_Employees_1] ON [sue].[Employees] ([TenantId], [LegalEntityId], [FileNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_Employees_2' AND object_id = OBJECT_ID(N'sue.Employees')
)
    CREATE UNIQUE INDEX [UX_sue_Employees_2] ON [sue].[Employees] ([TenantId], [PersonId], [LegalEntityId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_EmployeeAssignments_1' AND object_id = OBJECT_ID(N'sue.EmployeeAssignments')
)
    CREATE UNIQUE INDEX [UX_sue_EmployeeAssignments_1] ON [sue].[EmployeeAssignments] ([TenantId], [EmployeeId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_EmployeeCostAllocations_1' AND object_id = OBJECT_ID(N'sue.EmployeeCostAllocations')
)
    CREATE UNIQUE INDEX [UX_sue_EmployeeCostAllocations_1] ON [sue].[EmployeeCostAllocations] ([TenantId], [EmployeeId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_EmployeeFamilyMembers_1' AND object_id = OBJECT_ID(N'sue.EmployeeFamilyMembers')
)
    CREATE UNIQUE INDEX [UX_sue_EmployeeFamilyMembers_1] ON [sue].[EmployeeFamilyMembers] ([TenantId], [EmployeeId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_EmployeePayAccounts_1' AND object_id = OBJECT_ID(N'sue.EmployeePayAccounts')
)
    CREATE UNIQUE INDEX [UX_sue_EmployeePayAccounts_1] ON [sue].[EmployeePayAccounts] ([TenantId], [EmployeeId], [CbuHmac]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_EmployeePayAccounts_2' AND object_id = OBJECT_ID(N'sue.EmployeePayAccounts')
)
    CREATE UNIQUE INDEX [UX_sue_EmployeePayAccounts_2] ON [sue].[EmployeePayAccounts] ([TenantId], [EmployeeId], [CbuHmac]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_EmployeePayAccounts_3' AND object_id = OBJECT_ID(N'sue.EmployeePayAccounts')
)
    CREATE UNIQUE INDEX [UX_sue_EmployeePayAccounts_3] ON [sue].[EmployeePayAccounts] ([TenantId], [EmployeeId], [CbuHmac]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_SupervisionLinks_1' AND object_id = OBJECT_ID(N'sue.SupervisionLinks')
)
    CREATE UNIQUE INDEX [UX_sue_SupervisionLinks_1] ON [sue].[SupervisionLinks] ([TenantId], [SupervisorEmployeeId], [EmployeeId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_Shifts_1' AND object_id = OBJECT_ID(N'sue.Shifts')
)
    CREATE UNIQUE INDEX [UX_sue_Shifts_1] ON [sue].[Shifts] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_EmployeeShiftAssignments_1' AND object_id = OBJECT_ID(N'sue.EmployeeShiftAssignments')
)
    CREATE UNIQUE INDEX [UX_sue_EmployeeShiftAssignments_1] ON [sue].[EmployeeShiftAssignments] ([TenantId], [EmployeeId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_EmploymentStatusPeriods_1' AND object_id = OBJECT_ID(N'sue.EmploymentStatusPeriods')
)
    CREATE UNIQUE INDEX [UX_sue_EmploymentStatusPeriods_1] ON [sue].[EmploymentStatusPeriods] ([TenantId], [EmployeeId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_ExtraGroups_1' AND object_id = OBJECT_ID(N'sue.ExtraGroups')
)
    CREATE UNIQUE INDEX [UX_sue_ExtraGroups_1] ON [sue].[ExtraGroups] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_ExtraItems_1' AND object_id = OBJECT_ID(N'sue.ExtraItems')
)
    CREATE UNIQUE INDEX [UX_sue_ExtraItems_1] ON [sue].[ExtraItems] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_EmployeeExtras_1' AND object_id = OBJECT_ID(N'sue.EmployeeExtras')
)
    CREATE UNIQUE INDEX [UX_sue_EmployeeExtras_1] ON [sue].[EmployeeExtras] ([TenantId], [EmployeeId], [ExtraItemId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_Unions_1' AND object_id = OBJECT_ID(N'sue.Unions')
)
    CREATE UNIQUE INDEX [UX_sue_Unions_1] ON [sue].[Unions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_LaborAgreements_1' AND object_id = OBJECT_ID(N'sue.LaborAgreements')
)
    CREATE UNIQUE INDEX [UX_sue_LaborAgreements_1] ON [sue].[LaborAgreements] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_SalaryCategories_1' AND object_id = OBJECT_ID(N'sue.SalaryCategories')
)
    CREATE UNIQUE INDEX [UX_sue_SalaryCategories_1] ON [sue].[SalaryCategories] ([TenantId], [LaborAgreementId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_SalaryScales_1' AND object_id = OBJECT_ID(N'sue.SalaryScales')
)
    CREATE UNIQUE INDEX [UX_sue_SalaryScales_1] ON [sue].[SalaryScales] ([TenantId], [SalaryCategoryId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_SeniorityScales_1' AND object_id = OBJECT_ID(N'sue.SeniorityScales')
)
    CREATE UNIQUE INDEX [UX_sue_SeniorityScales_1] ON [sue].[SeniorityScales] ([TenantId], [LaborAgreementId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_Positions_1' AND object_id = OBJECT_ID(N'sue.Positions')
)
    CREATE UNIQUE INDEX [UX_sue_Positions_1] ON [sue].[Positions] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_WorkAreas_1' AND object_id = OBJECT_ID(N'sue.WorkAreas')
)
    CREATE UNIQUE INDEX [UX_sue_WorkAreas_1] ON [sue].[WorkAreas] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_HealthInsurerAdoptions_1' AND object_id = OBJECT_ID(N'sue.HealthInsurerAdoptions')
)
    CREATE UNIQUE INDEX [UX_sue_HealthInsurerAdoptions_1] ON [sue].[HealthInsurerAdoptions] ([TenantId], [OfficialCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_TerminationReasons_1' AND object_id = OBJECT_ID(N'sue.TerminationReasons')
)
    CREATE UNIQUE INDEX [UX_sue_TerminationReasons_1] ON [sue].[TerminationReasons] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PayrollVariables_1' AND object_id = OBJECT_ID(N'sue.PayrollVariables')
)
    CREATE UNIQUE INDEX [UX_sue_PayrollVariables_1] ON [sue].[PayrollVariables] ([TenantId], [ConfigVersionId], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PayrollConcepts_1' AND object_id = OBJECT_ID(N'sue.PayrollConcepts')
)
    CREATE UNIQUE INDEX [UX_sue_PayrollConcepts_1] ON [sue].[PayrollConcepts] ([TenantId], [ConfigVersionId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PayrollTypes_1' AND object_id = OBJECT_ID(N'sue.PayrollTypes')
)
    CREATE UNIQUE INDEX [UX_sue_PayrollTypes_1] ON [sue].[PayrollTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PayrollConfigVersions_1' AND object_id = OBJECT_ID(N'sue.PayrollConfigVersions')
)
    CREATE UNIQUE INDEX [UX_sue_PayrollConfigVersions_1] ON [sue].[PayrollConfigVersions] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_NoveltyTypes_1' AND object_id = OBJECT_ID(N'sue.NoveltyTypes')
)
    CREATE UNIQUE INDEX [UX_sue_NoveltyTypes_1] ON [sue].[NoveltyTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_Novelties_1' AND object_id = OBJECT_ID(N'sue.Novelties')
)
    CREATE UNIQUE INDEX [UX_sue_Novelties_1] ON [sue].[Novelties] ([TenantId], [SourceRef]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_NoveltyImportBatches_1' AND object_id = OBJECT_ID(N'sue.NoveltyImportBatches')
)
    CREATE UNIQUE INDEX [UX_sue_NoveltyImportBatches_1] ON [sue].[NoveltyImportBatches] ([TenantId], [FileHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_TimePunches_1' AND object_id = OBJECT_ID(N'sue.TimePunches')
)
    CREATE UNIQUE INDEX [UX_sue_TimePunches_1] ON [sue].[TimePunches] ([TenantId], [EmployeeId], [At]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_LeaveCauses_1' AND object_id = OBJECT_ID(N'sue.LeaveCauses')
)
    CREATE UNIQUE INDEX [UX_sue_LeaveCauses_1] ON [sue].[LeaveCauses] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_VacationBalances_1' AND object_id = OBJECT_ID(N'sue.VacationBalances')
)
    CREATE UNIQUE INDEX [UX_sue_VacationBalances_1] ON [sue].[VacationBalances] ([TenantId], [EmployeeId], [VacationYear]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PayPeriods_1' AND object_id = OBJECT_ID(N'sue.PayPeriods')
)
    CREATE UNIQUE INDEX [UX_sue_PayPeriods_1] ON [sue].[PayPeriods] ([TenantId], [LegalEntityId], [PeriodKey], [Frequency]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PayrollRuns_1' AND object_id = OBJECT_ID(N'sue.PayrollRuns')
)
    CREATE UNIQUE INDEX [UX_sue_PayrollRuns_1] ON [sue].[PayrollRuns] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_Payslips_1' AND object_id = OBJECT_ID(N'sue.Payslips')
)
    CREATE UNIQUE INDEX [UX_sue_Payslips_1] ON [sue].[Payslips] ([TenantId], [EmployeeId], [PeriodKey], [PayrollTypeId], [LegalEntityId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_IncomeTaxDeclarations_1' AND object_id = OBJECT_ID(N'sue.IncomeTaxDeclarations')
)
    CREATE UNIQUE INDEX [UX_sue_IncomeTaxDeclarations_1] ON [sue].[IncomeTaxDeclarations] ([TenantId], [EmployeeId], [FiscalYear], [FormVersion]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_StatutoryFilings_1' AND object_id = OBJECT_ID(N'sue.StatutoryFilings')
)
    CREATE UNIQUE INDEX [UX_sue_StatutoryFilings_1] ON [sue].[StatutoryFilings] ([TenantId], [LegalEntityId], [Kind], [PeriodKey], [RectificationNo]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PayrollPaymentRequests_1' AND object_id = OBJECT_ID(N'sue.PayrollPaymentRequests')
)
    CREATE UNIQUE INDEX [UX_sue_PayrollPaymentRequests_1] ON [sue].[PayrollPaymentRequests] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PayrollAccountingRules_1' AND object_id = OBJECT_ID(N'sue.PayrollAccountingRules')
)
    CREATE UNIQUE INDEX [UX_sue_PayrollAccountingRules_1] ON [sue].[PayrollAccountingRules] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_Terminations_1' AND object_id = OBJECT_ID(N'sue.Terminations')
)
    CREATE UNIQUE INDEX [UX_sue_Terminations_1] ON [sue].[Terminations] ([TenantId], [EmployeeId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PayslipNotifications_1' AND object_id = OBJECT_ID(N'sue.PayslipNotifications')
)
    CREATE UNIQUE INDEX [UX_sue_PayslipNotifications_1] ON [sue].[PayslipNotifications] ([TenantId], [PayslipId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PerformanceTemplates_1' AND object_id = OBJECT_ID(N'sue.PerformanceTemplates')
)
    CREATE UNIQUE INDEX [UX_sue_PerformanceTemplates_1] ON [sue].[PerformanceTemplates] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PerformanceCycles_1' AND object_id = OBJECT_ID(N'sue.PerformanceCycles')
)
    CREATE UNIQUE INDEX [UX_sue_PerformanceCycles_1] ON [sue].[PerformanceCycles] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_PerformanceReviews_1' AND object_id = OBJECT_ID(N'sue.PerformanceReviews')
)
    CREATE UNIQUE INDEX [UX_sue_PerformanceReviews_1] ON [sue].[PerformanceReviews] ([TenantId], [CycleId], [EmployeeId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_AdministrativeInquiries_1' AND object_id = OBJECT_ID(N'sue.AdministrativeInquiries')
)
    CREATE UNIQUE INDEX [UX_sue_AdministrativeInquiries_1] ON [sue].[AdministrativeInquiries] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_WorkAccidents_1' AND object_id = OBJECT_ID(N'sue.WorkAccidents')
)
    CREATE UNIQUE INDEX [UX_sue_WorkAccidents_1] ON [sue].[WorkAccidents] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_LaborLawsuits_1' AND object_id = OBJECT_ID(N'sue.LaborLawsuits')
)
    CREATE UNIQUE INDEX [UX_sue_LaborLawsuits_1] ON [sue].[LaborLawsuits] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_ReportGroups_1' AND object_id = OBJECT_ID(N'sue.ReportGroups')
)
    CREATE UNIQUE INDEX [UX_sue_ReportGroups_1] ON [sue].[ReportGroups] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_SalaryIncreaseBatches_1' AND object_id = OBJECT_ID(N'sue.SalaryIncreaseBatches')
)
    CREATE UNIQUE INDEX [UX_sue_SalaryIncreaseBatches_1] ON [sue].[SalaryIncreaseBatches] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_ExternalPayrollImports_1' AND object_id = OBJECT_ID(N'sue.ExternalPayrollImports')
)
    CREATE UNIQUE INDEX [UX_sue_ExternalPayrollImports_1] ON [sue].[ExternalPayrollImports] ([TenantId], [LegalEntityId], [PeriodKey], [PayrollKind], [Reference]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_sue_ExternalPayrollLayouts_1' AND object_id = OBJECT_ID(N'sue.ExternalPayrollLayouts')
)
    CREATE UNIQUE INDEX [UX_sue_ExternalPayrollLayouts_1] ON [sue].[ExternalPayrollLayouts] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_AssociateMemberships_1' AND object_id = OBJECT_ID(N'ins.AssociateMemberships')
)
    CREATE UNIQUE INDEX [UX_ins_AssociateMemberships_1] ON [ins].[AssociateMemberships] ([TenantId], [LegalEntityId], [MemberNumber]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_AssociateMemberships_2' AND object_id = OBJECT_ID(N'ins.AssociateMemberships')
)
    CREATE UNIQUE INDEX [UX_ins_AssociateMemberships_2] ON [ins].[AssociateMemberships] ([TenantId], [LegalEntityId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_ElectoralDistricts_1' AND object_id = OBJECT_ID(N'ins.ElectoralDistricts')
)
    CREATE UNIQUE INDEX [UX_ins_ElectoralDistricts_1] ON [ins].[ElectoralDistricts] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_CapitalItems_1' AND object_id = OBJECT_ID(N'ins.CapitalItems')
)
    CREATE UNIQUE INDEX [UX_ins_CapitalItems_1] ON [ins].[CapitalItems] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_CapitalItems_2' AND object_id = OBJECT_ID(N'ins.CapitalItems')
)
    CREATE UNIQUE INDEX [UX_ins_CapitalItems_2] ON [ins].[CapitalItems] ([TenantId], [ProductGroupIds]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_CapitalShareValues_1' AND object_id = OBJECT_ID(N'ins.CapitalShareValues')
)
    CREATE UNIQUE INDEX [UX_ins_CapitalShareValues_1] ON [ins].[CapitalShareValues] ([TenantId], [LegalEntityId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_CapitalMovements_1' AND object_id = OBJECT_ID(N'ins.CapitalMovements')
)
    CREATE UNIQUE INDEX [UX_ins_CapitalMovements_1] ON [ins].[CapitalMovements] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_CapitalRefunds_1' AND object_id = OBJECT_ID(N'ins.CapitalRefunds')
)
    CREATE UNIQUE INDEX [UX_ins_CapitalRefunds_1] ON [ins].[CapitalRefunds] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_CapitalClosings_1' AND object_id = OBJECT_ID(N'ins.CapitalClosings')
)
    CREATE UNIQUE INDEX [UX_ins_CapitalClosings_1] ON [ins].[CapitalClosings] ([TenantId], [LegalEntityId], [ClosingDate]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_ShareCertificates_1' AND object_id = OBJECT_ID(N'ins.ShareCertificates')
)
    CREATE UNIQUE INDEX [UX_ins_ShareCertificates_1] ON [ins].[ShareCertificates] ([TenantId], [LegalEntityId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_SurplusDistributions_1' AND object_id = OBJECT_ID(N'ins.SurplusDistributions')
)
    CREATE UNIQUE INDEX [UX_ins_SurplusDistributions_1] ON [ins].[SurplusDistributions] ([TenantId], [LegalEntityId], [FiscalYear]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_MeetingAgendaItems_1' AND object_id = OBJECT_ID(N'ins.MeetingAgendaItems')
)
    CREATE UNIQUE INDEX [UX_ins_MeetingAgendaItems_1] ON [ins].[MeetingAgendaItems] ([TenantId], [MeetingId], [Order]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_MeetingParticipants_1' AND object_id = OBJECT_ID(N'ins.MeetingParticipants')
)
    CREATE UNIQUE INDEX [UX_ins_MeetingParticipants_1] ON [ins].[MeetingParticipants] ([TenantId], [MeetingId], [AssociateMembershipId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_MeetingPermissions_1' AND object_id = OBJECT_ID(N'ins.MeetingPermissions')
)
    CREATE UNIQUE INDEX [UX_ins_MeetingPermissions_1] ON [ins].[MeetingPermissions] ([TenantId], [MeetingId], [UserId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_Minutes_1' AND object_id = OBJECT_ID(N'ins.Minutes')
)
    CREATE UNIQUE INDEX [UX_ins_Minutes_1] ON [ins].[Minutes] ([TenantId], [LegalEntityId], [BookType], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_Minutes_2' AND object_id = OBJECT_ID(N'ins.Minutes')
)
    CREATE UNIQUE INDEX [UX_ins_Minutes_2] ON [ins].[Minutes] ([TenantId], [BookType], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_Resolutions_1' AND object_id = OBJECT_ID(N'ins.Resolutions')
)
    CREATE UNIQUE INDEX [UX_ins_Resolutions_1] ON [ins].[Resolutions] ([TenantId], [S]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_Rosters_1' AND object_id = OBJECT_ID(N'ins.Rosters')
)
    CREATE UNIQUE INDEX [UX_ins_Rosters_1] ON [ins].[Rosters] ([TenantId], [MeetingId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_Proxies_1' AND object_id = OBJECT_ID(N'ins.Proxies')
)
    CREATE UNIQUE INDEX [UX_ins_Proxies_1] ON [ins].[Proxies] ([TenantId], [MeetingId], [GrantorAssociateMembershipId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_InaesCategories_1' AND object_id = OBJECT_ID(N'ins.InaesCategories')
)
    CREATE UNIQUE INDEX [UX_ins_InaesCategories_1] ON [ins].[InaesCategories] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_MemberCredentials_1' AND object_id = OBJECT_ID(N'ins.MemberCredentials')
)
    CREATE UNIQUE INDEX [UX_ins_MemberCredentials_1] ON [ins].[MemberCredentials] ([TenantId], [QrTokenHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_CapitalBalances_1' AND object_id = OBJECT_ID(N'ins.CapitalBalances')
)
    CREATE UNIQUE INDEX [UX_ins_CapitalBalances_1] ON [ins].[CapitalBalances] ([TenantId], [LegalEntityId], [AssociateMembershipId], [CapitalItemId], [AccountId], [ContractId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_ins_CapitalBalances_2' AND object_id = OBJECT_ID(N'ins.CapitalBalances')
)
    CREATE UNIQUE INDEX [UX_ins_CapitalBalances_2] ON [ins].[CapitalBalances] ([TenantId], [AssociateMembershipId], [CapitalItemId], [AccountId], [ContractId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_ServiceDependents_1' AND object_id = OBJECT_ID(N'soc.ServiceDependents')
)
    CREATE UNIQUE INDEX [UX_soc_ServiceDependents_1] ON [soc].[ServiceDependents] ([TenantId], [ContractId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_MedicalSpecialties_1' AND object_id = OBJECT_ID(N'soc.MedicalSpecialties')
)
    CREATE UNIQUE INDEX [UX_soc_MedicalSpecialties_1] ON [soc].[MedicalSpecialties] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_MedicalProfessionals_1' AND object_id = OBJECT_ID(N'soc.MedicalProfessionals')
)
    CREATE UNIQUE INDEX [UX_soc_MedicalProfessionals_1] ON [soc].[MedicalProfessionals] ([TenantId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_MedicalProfessionals_2' AND object_id = OBJECT_ID(N'soc.MedicalProfessionals')
)
    CREATE UNIQUE INDEX [UX_soc_MedicalProfessionals_2] ON [soc].[MedicalProfessionals] ([TenantId], [Antes]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_BenefitRequests_1' AND object_id = OBJECT_ID(N'soc.BenefitRequests')
)
    CREATE UNIQUE INDEX [UX_soc_BenefitRequests_1] ON [soc].[BenefitRequests] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_TransportTrips_1' AND object_id = OBJECT_ID(N'soc.TransportTrips')
)
    CREATE UNIQUE INDEX [UX_soc_TransportTrips_1] ON [soc].[TransportTrips] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_TripLegs_1' AND object_id = OBJECT_ID(N'soc.TripLegs')
)
    CREATE UNIQUE INDEX [UX_soc_TripLegs_1] ON [soc].[TripLegs] ([TenantId], [TripId], [Order]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_TripCharacteristics_1' AND object_id = OBJECT_ID(N'soc.TripCharacteristics')
)
    CREATE UNIQUE INDEX [UX_soc_TripCharacteristics_1] ON [soc].[TripCharacteristics] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_Cemeteries_1' AND object_id = OBJECT_ID(N'soc.Cemeteries')
)
    CREATE UNIQUE INDEX [UX_soc_Cemeteries_1] ON [soc].[Cemeteries] ([TenantId], [Name]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_CemeteryRegulations_1' AND object_id = OBJECT_ID(N'soc.CemeteryRegulations')
)
    CREATE UNIQUE INDEX [UX_soc_CemeteryRegulations_1] ON [soc].[CemeteryRegulations] ([TenantId], [CemeteryId], [ValidFrom]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_BurialUnits_1' AND object_id = OBJECT_ID(N'soc.BurialUnits')
)
    CREATE UNIQUE INDEX [UX_soc_BurialUnits_1] ON [soc].[BurialUnits] ([TenantId], [CemeteryId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_CemeteryActs_1' AND object_id = OBJECT_ID(N'soc.CemeteryActs')
)
    CREATE UNIQUE INDEX [UX_soc_CemeteryActs_1] ON [soc].[CemeteryActs] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_OrthopedicItems_1' AND object_id = OBJECT_ID(N'soc.OrthopedicItems')
)
    CREATE UNIQUE INDEX [UX_soc_OrthopedicItems_1] ON [soc].[OrthopedicItems] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_HousingUnits_1' AND object_id = OBJECT_ID(N'soc.HousingUnits')
)
    CREATE UNIQUE INDEX [UX_soc_HousingUnits_1] ON [soc].[HousingUnits] ([TenantId], [ContractId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_HousingStages_1' AND object_id = OBJECT_ID(N'soc.HousingStages')
)
    CREATE UNIQUE INDEX [UX_soc_HousingStages_1] ON [soc].[HousingStages] ([TenantId], [CategoryId], [Order]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_HousingActivities_1' AND object_id = OBJECT_ID(N'soc.HousingActivities')
)
    CREATE UNIQUE INDEX [UX_soc_HousingActivities_1] ON [soc].[HousingActivities] ([TenantId], [StageId], [Order]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_HousingActivityMaterials_1' AND object_id = OBJECT_ID(N'soc.HousingActivityMaterials')
)
    CREATE UNIQUE INDEX [UX_soc_HousingActivityMaterials_1] ON [soc].[HousingActivityMaterials] ([TenantId], [ActivityId], [InventoryItemId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_HousingCertificates_1' AND object_id = OBJECT_ID(N'soc.HousingCertificates')
)
    CREATE UNIQUE INDEX [UX_soc_HousingCertificates_1] ON [soc].[HousingCertificates] ([TenantId], [Number]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_FleetVehicles_1' AND object_id = OBJECT_ID(N'soc.FleetVehicles')
)
    CREATE UNIQUE INDEX [UX_soc_FleetVehicles_1] ON [soc].[FleetVehicles] ([TenantId], [Plate]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_Drivers_1' AND object_id = OBJECT_ID(N'soc.Drivers')
)
    CREATE UNIQUE INDEX [UX_soc_Drivers_1] ON [soc].[Drivers] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_Drivers_2' AND object_id = OBJECT_ID(N'soc.Drivers')
)
    CREATE UNIQUE INDEX [UX_soc_Drivers_2] ON [soc].[Drivers] ([TenantId], [PersonId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_FuelTypes_1' AND object_id = OBJECT_ID(N'soc.FuelTypes')
)
    CREATE UNIQUE INDEX [UX_soc_FuelTypes_1] ON [soc].[FuelTypes] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_TripSettlements_1' AND object_id = OBJECT_ID(N'soc.TripSettlements')
)
    CREATE UNIQUE INDEX [UX_soc_TripSettlements_1] ON [soc].[TripSettlements] ([TenantId], [SourceKind], [SourceId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_GpsDevices_1' AND object_id = OBJECT_ID(N'soc.GpsDevices')
)
    CREATE UNIQUE INDEX [UX_soc_GpsDevices_1] ON [soc].[GpsDevices] ([TenantId], [ProviderAdapter], [ExternalUnitId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_soc_GpsPositions_1' AND object_id = OBJECT_ID(N'soc.GpsPositions')
)
    CREATE UNIQUE INDEX [UX_soc_GpsPositions_1] ON [soc].[GpsPositions] ([TenantId], [MetaTenantId], [MetaVehicleId], [At]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_LandingPages_1' AND object_id = OBJECT_ID(N'por.LandingPages')
)
    CREATE UNIQUE INDEX [UX_por_LandingPages_1] ON [por].[LandingPages] ([TenantId], [Locale]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_LandingPages_2' AND object_id = OBJECT_ID(N'por.LandingPages')
)
    CREATE UNIQUE INDEX [UX_por_LandingPages_2] ON [por].[LandingPages] ([TenantId], [Slug]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_LandingPages_3' AND object_id = OBJECT_ID(N'por.LandingPages')
)
    CREATE UNIQUE INDEX [UX_por_LandingPages_3] ON [por].[LandingPages] ([TenantId], [CustomDomain]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_LandingPageVersions_1' AND object_id = OBJECT_ID(N'por.LandingPageVersions')
)
    CREATE UNIQUE INDEX [UX_por_LandingPageVersions_1] ON [por].[LandingPageVersions] ([TenantId], [LandingPageId], [Version]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_PortalAccountAccess_1' AND object_id = OBJECT_ID(N'por.PortalAccountAccess')
)
    CREATE UNIQUE INDEX [UX_por_PortalAccountAccess_1] ON [por].[PortalAccountAccess] ([TenantId], [UserId], [AccountId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_PortalDelegationInvites_1' AND object_id = OBJECT_ID(N'por.PortalDelegationInvites')
)
    CREATE UNIQUE INDEX [UX_por_PortalDelegationInvites_1] ON [por].[PortalDelegationInvites] ([TenantId], [TokenHash]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_PortalForms_1' AND object_id = OBJECT_ID(N'por.PortalForms')
)
    CREATE UNIQUE INDEX [UX_por_PortalForms_1] ON [por].[PortalForms] ([TenantId], [Code]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_PortalFormSubmissions_1' AND object_id = OBJECT_ID(N'por.PortalFormSubmissions')
)
    CREATE UNIQUE INDEX [UX_por_PortalFormSubmissions_1] ON [por].[PortalFormSubmissions] ([TenantId], [IdempotencyKey]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_PublicSubmissions_1' AND object_id = OBJECT_ID(N'por.PublicSubmissions')
)
    CREATE UNIQUE INDEX [UX_por_PublicSubmissions_1] ON [por].[PublicSubmissions] ([TenantId], [PublicCode]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_PortalUserPreferences_1' AND object_id = OBJECT_ID(N'por.PortalUserPreferences')
)
    CREATE UNIQUE INDEX [UX_por_PortalUserPreferences_1] ON [por].[PortalUserPreferences] ([TenantId], [UserId]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_LegacyPortalUserMap_1' AND object_id = OBJECT_ID(N'por.LegacyPortalUserMap')
)
    CREATE UNIQUE INDEX [UX_por_LegacyPortalUserMap_1] ON [por].[LegacyPortalUserMap] ([TenantId], [LegacyCodUser]);
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = N'UX_por_KioskDevices_1' AND object_id = OBJECT_ID(N'por.KioskDevices')
)
    CREATE UNIQUE INDEX [UX_por_KioskDevices_1] ON [por].[KioskDevices] ([TenantId], [Code]);
GO

