-- crm.CrmHourBanks — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmHourBanks', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmHourBanks] (
        [CrmHourBankId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AccountId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [MinutesGranted] INT NOT NULL,
        [Period] NVARCHAR(512) NULL,
        [SaleRefId] UNIQUEIDENTIFIER NULL,
        [MinutesUsed] INT NOT NULL,
        [HourlyRate] DECIMAL(18,4) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmHourBanks_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmHourBanks_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmHourBanks] PRIMARY KEY ([CrmHourBankId]),
        CONSTRAINT [FK_crm_CrmHourBanks_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmHourBanks_Tenant] ON [crm].[CrmHourBanks] ([TenantId]);
END;
GO
