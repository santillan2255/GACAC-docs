-- crm.CrmSlaPolicies — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmSlaPolicies', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmSlaPolicies] (
        [CrmSlaPolicyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Scope] NVARCHAR(MAX) NOT NULL,
        [Targets] NVARCHAR(MAX) NOT NULL,
        [PauseOnBaseStatuses] VARCHAR(64) NOT NULL,
        [WarnAtPercent] INT NOT NULL,
        [Escalation] NVARCHAR(MAX) NULL,
        [BusinessCalendarId] UNIQUEIDENTIFIER NULL,
        [Regulatory] BIT NULL,
        [PolicyVersion] INT NOT NULL,
        [TemplateCode] NVARCHAR(512) NULL,
        [LegalValidation] NVARCHAR(MAX) NULL,
        [Continuous] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmSlaPolicies_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmSlaPolicies_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmSlaPolicies] PRIMARY KEY ([CrmSlaPolicyId]),
        CONSTRAINT [FK_crm_CrmSlaPolicies_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmSlaPolicies_Tenant] ON [crm].[CrmSlaPolicies] ([TenantId]);
END;
GO
