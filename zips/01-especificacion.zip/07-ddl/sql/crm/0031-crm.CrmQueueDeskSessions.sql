-- crm.CrmQueueDeskSessions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmQueueDeskSessions', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmQueueDeskSessions] (
        [CrmQueueDeskSessionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [DeskId] NVARCHAR(512) NULL,
        [UserId] NVARCHAR(512) NULL,
        [OpenedAt] DATETIME2(7) NULL,
        [FEC_APER] NVARCHAR(512) NULL,
        [ClosedAt] DATETIME2(7) NULL,
        [FEC_CIERRE] NVARCHAR(512) NULL,
        [AreaIds] NVARCHAR(512) NULL,
        [{tenantId, deskId}] NVARCHAR(512) NULL,
        [ClosedAt = null] NVARCHAR(512) NULL,
        [TUR_BOX_HISTORIAL] NVARCHAR(512) NULL,
        [AreaIdsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueDeskSessions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueDeskSessions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmQueueDeskSessions] PRIMARY KEY ([CrmQueueDeskSessionId]),
        CONSTRAINT [FK_crm_CrmQueueDeskSessions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmQueueDeskSessions_Tenant] ON [crm].[CrmQueueDeskSessions] ([TenantId]);
END;
GO
