-- crm.CrmMessages — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmMessages', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmMessages] (
        [CrmMessageId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ConversationId] UNIQUEIDENTIFIER NULL,
        [CrmCaseId] UNIQUEIDENTIFIER NULL,
        [Direction] VARCHAR(64) NOT NULL,
        [Visibility] VARCHAR(64) NOT NULL,
        [AuthorKind] VARCHAR(64) NOT NULL,
        [AuthorUserId] UNIQUEIDENTIFIER NULL,
        [Body] NVARCHAR(512) NULL,
        [Format] VARCHAR(64) NOT NULL,
        [TemplateRef] NVARCHAR(MAX) NULL,
        [Attachments] NVARCHAR(MAX) NULL,
        [ProviderMessageId] NVARCHAR(512) NULL,
        [Delivery] NVARCHAR(MAX) NULL,
        [IsAutomatic] BIT NULL,
        [WorkLogId] UNIQUEIDENTIFIER NULL,
        [Flags] NVARCHAR(MAX) NULL,
        [AiSuggestionId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmMessages_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmMessages_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmMessages] PRIMARY KEY ([CrmMessageId]),
        CONSTRAINT [FK_crm_CrmMessages_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmMessages_Tenant] ON [crm].[CrmMessages] ([TenantId]);
END;
GO
