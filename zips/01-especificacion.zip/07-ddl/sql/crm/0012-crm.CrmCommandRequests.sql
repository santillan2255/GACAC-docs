-- crm.CrmCommandRequests — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmCommandRequests', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmCommandRequests] (
        [CrmCommandRequestId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CrmCaseId] UNIQUEIDENTIFIER NOT NULL,
        [TargetModule] VARCHAR(64) NOT NULL,
        [Command] NVARCHAR(512) NOT NULL,
        [Payload] NVARCHAR(MAX) NOT NULL,
        [IdempotencyKey] NVARCHAR(512) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Result] NVARCHAR(MAX) NULL,
        [Attempts] INT NOT NULL,
        [DependsOnCommandId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCommandRequests_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCommandRequests_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmCommandRequests] PRIMARY KEY ([CrmCommandRequestId]),
        CONSTRAINT [FK_crm_CrmCommandRequests_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmCommandRequests_Tenant] ON [crm].[CrmCommandRequests] ([TenantId]);
END;
GO
