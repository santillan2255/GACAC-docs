-- crm.CrmIncidents — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmIncidents', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmIncidents] (
        [CrmIncidentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] NVARCHAR(512) NOT NULL,
        [IncidentClassId] UNIQUEIDENTIFIER NOT NULL,
        [IncidentCategoryId] UNIQUEIDENTIFIER NULL,
        [FailureTypeId] UNIQUEIDENTIFIER NULL,
        [ServiceId] UNIQUEIDENTIFIER NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Scheduled] BIT NULL,
        [Scope] NVARCHAR(MAX) NOT NULL,
        [Affected] NVARCHAR(MAX) NULL,
        [EstimatedRestoreAt] DATETIME2(7) NULL,
        [WorkOrderIdsId] UNIQUEIDENTIFIER NULL,
        [Participants] NVARCHAR(MAX) NULL,
        [CaseCount] INT NOT NULL,
        [Communications] NVARCHAR(MAX) NULL,
        [ResolutionCode] NVARCHAR(512) NULL,
        [RegulatoryReportable] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmIncidents_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmIncidents_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmIncidents] PRIMARY KEY ([CrmIncidentId]),
        CONSTRAINT [FK_crm_CrmIncidents_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmIncidents_Tenant] ON [crm].[CrmIncidents] ([TenantId]);
END;
GO
