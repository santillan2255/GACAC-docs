-- crm.CrmQueueDeskTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmQueueDeskTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmQueueDeskTypes] (
        [CrmQueueDeskTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NULL,
        [NOM_BOX] NVARCHAR(512) NULL,
        [Icon] NVARCHAR(512) NULL,
        [TUR_TIPO_BOX] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueDeskTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueDeskTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmQueueDeskTypes] PRIMARY KEY ([CrmQueueDeskTypeId]),
        CONSTRAINT [FK_crm_CrmQueueDeskTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmQueueDeskTypes_Tenant] ON [crm].[CrmQueueDeskTypes] ([TenantId]);
END;
GO
