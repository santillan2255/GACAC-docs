-- crm.CrmActivities — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmActivities', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmActivities] (
        [CrmActivityId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ActivityTypeId] NVARCHAR(512) NULL,
        [COD_TIPO] NVARCHAR(512) NULL,
        [RubroId] NVARCHAR(512) NULL,
        [ResponsibleUserId] NVARCHAR(512) NULL,
        [COD_RES] NVARCHAR(512) NULL,
        [Description] NVARCHAR(512) NULL,
        [DES_ACT] NVARCHAR(512) NULL,
        [ExtraRecipients] NVARCHAR(512) NULL,
        [MAILSEXTRA] NVARCHAR(512) NULL,
        [Generation] NVARCHAR(512) NULL,
        [Automatic] NVARCHAR(512) NULL,
        [TIP_GEN 1] NVARCHAR(512) NULL,
        [Manual] NVARCHAR(512) NULL,
        [DateMode] NVARCHAR(512) NULL,
        [TIP_FEC] NVARCHAR(512) NULL,
        [FirstDueDate] NVARCHAR(512) NULL,
        [ValidUntil] NVARCHAR(512) NULL,
        [FEC_HASTA] NVARCHAR(512) NULL,
        [Prerequisites] NVARCHAR(512) NULL,
        [{ activityId, mandatory }] NVARCHAR(512) NULL,
        [ACTIPREV] NVARCHAR(512) NULL,
        [LinkedEntity] NVARCHAR(512) NULL,
        [{ type] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [ACTIV] NVARCHAR(512) NULL,
        [ExtraRecipientsJson] NVARCHAR(MAX) NULL,
        [PrerequisitesJson] NVARCHAR(MAX) NULL,
        [LinkedEntityJson] NVARCHAR(MAX) NULL,
        [TypeId] UNIQUEIDENTIFIER NULL,
        [FrequencyId] UNIQUEIDENTIFIER NULL,
        [Code] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmActivities_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmActivities_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmActivities] PRIMARY KEY ([CrmActivityId]),
        CONSTRAINT [FK_crm_CrmActivities_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmActivities_Tenant] ON [crm].[CrmActivities] ([TenantId]);
END;
GO
