-- crm.CrmCaseEvents — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmCaseEvents', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmCaseEvents] (
        [CrmCaseEventId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CrmCaseId] UNIQUEIDENTIFIER NOT NULL,
        [Seq] INT NOT NULL,
        [Type] VARCHAR(64) NOT NULL,
        [At] DATETIME2(7) NOT NULL,
        [Actor] NVARCHAR(MAX) NOT NULL,
        [Reason] NVARCHAR(512) NULL,
        [Refs] NVARCHAR(MAX) NULL,
        [VisibleToCustomer] BIT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCaseEvents_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCaseEvents_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmCaseEvents] PRIMARY KEY ([CrmCaseEventId]),
        CONSTRAINT [FK_crm_CrmCaseEvents_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmCaseEvents_Tenant] ON [crm].[CrmCaseEvents] ([TenantId]);
END;
GO
