-- crm.CrmAreas — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmAreas', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmAreas] (
        [CrmAreaId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Roles] VARCHAR(64) NOT NULL,
        [BranchIdsId] UNIQUEIDENTIFIER NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NULL,
        [ManagerUserId] UNIQUEIDENTIFIER NULL,
        [Members] NVARCHAR(MAX) NULL,
        [ExtraRecipients] NVARCHAR(MAX) NULL,
        [ReminderWeekday] INT NULL,
        [BusinessCalendarId] UNIQUEIDENTIFIER NULL,
        [Queue] NVARCHAR(MAX) NULL,
        [OnCallSchedule] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmAreas_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmAreas_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmAreas] PRIMARY KEY ([CrmAreaId]),
        CONSTRAINT [FK_crm_CrmAreas_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmAreas_Tenant] ON [crm].[CrmAreas] ([TenantId]);
END;
GO
