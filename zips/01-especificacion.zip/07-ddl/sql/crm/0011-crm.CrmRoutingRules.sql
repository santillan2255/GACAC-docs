-- crm.CrmRoutingRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmRoutingRules', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmRoutingRules] (
        [CrmRoutingRuleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Purpose] VARCHAR(64) NOT NULL,
        [Conditions] NVARCHAR(MAX) NOT NULL,
        [Trigger] VARCHAR(64) NOT NULL,
        [Target] NVARCHAR(MAX) NOT NULL,
        [Priority] INT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmRoutingRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmRoutingRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmRoutingRules] PRIMARY KEY ([CrmRoutingRuleId]),
        CONSTRAINT [FK_crm_CrmRoutingRules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmRoutingRules_Tenant] ON [crm].[CrmRoutingRules] ([TenantId]);
END;
GO
