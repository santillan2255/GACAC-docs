-- crm.CrmIncidentClasses — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmIncidentClasses', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmIncidentClasses] (
        [CrmIncidentClassId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Prefix] NVARCHAR(512) NOT NULL,
        [CounterKey] NVARCHAR(512) NOT NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmIncidentClasses_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmIncidentClasses_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmIncidentClasses] PRIMARY KEY ([CrmIncidentClassId]),
        CONSTRAINT [FK_crm_CrmIncidentClasses_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmIncidentClasses_Tenant] ON [crm].[CrmIncidentClasses] ([TenantId]);
END;
GO
