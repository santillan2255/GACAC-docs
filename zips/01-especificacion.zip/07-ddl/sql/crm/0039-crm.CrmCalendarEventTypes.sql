-- crm.CrmCalendarEventTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmCalendarEventTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmCalendarEventTypes] (
        [CrmCalendarEventTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Description] NVARCHAR(512) NULL,
        [Color] NVARCHAR(512) NULL,
        [CALENDARIO_TIPO] NVARCHAR(512) NULL,
        [TIP_EVEN] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCalendarEventTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCalendarEventTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmCalendarEventTypes] PRIMARY KEY ([CrmCalendarEventTypeId]),
        CONSTRAINT [FK_crm_CrmCalendarEventTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmCalendarEventTypes_Tenant] ON [crm].[CrmCalendarEventTypes] ([TenantId]);
END;
GO
