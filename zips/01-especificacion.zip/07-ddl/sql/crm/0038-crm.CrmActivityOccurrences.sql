-- crm.CrmActivityOccurrences — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmActivityOccurrences', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmActivityOccurrences] (
        [CrmActivityOccurrenceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ActivityId] NVARCHAR(512) NULL,
        [COD_ACT] NVARCHAR(512) NULL,
        [Seq] NVARCHAR(512) NULL,
        [DueDate] NVARCHAR(512) NULL,
        [FEC_ACT] NVARCHAR(512) NULL,
        [GeneratedAt] DATETIME2(7) NULL,
        [FEC_ALTA] NVARCHAR(512) NULL,
        [Manual] NVARCHAR(512) NULL,
        [MANUAL_ACT] NVARCHAR(512) NULL,
        [ResponsibleUserId] NVARCHAR(512) NULL,
        [COD_RES] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Pending] NVARCHAR(512) NULL,
        [DueSoon] NVARCHAR(512) NULL,
        [Overdue] NVARCHAR(512) NULL,
        [ClosedOnTime] NVARCHAR(512) NULL,
        [ClosedLate] NVARCHAR(512) NULL,
        [ClosedWithReview] NVARCHAR(512) NULL,
        [Voided] NVARCHAR(512) NULL,
        [ClosedAt] DATETIME2(7) NULL,
        [FEC_CIERRE] NVARCHAR(512) NULL,
        [RealClosedAt] DATETIME2(7) NULL,
        [FEC_REALCI] NVARCHAR(512) NULL,
        [ClosedByResponsibleId] NVARCHAR(512) NULL,
        [CODRES_CIE] NVARCHAR(512) NULL,
        [ClosedByUserId] NVARCHAR(512) NULL,
        [COD_US_CIE] NVARCHAR(512) NULL,
        [Review] NVARCHAR(512) NULL,
        [REV_ACT] NVARCHAR(512) NULL,
        [Observation] NVARCHAR(512) NULL,
        [OBS_ACT] NVARCHAR(512) NULL,
        [EvidenceDocumentIds] NVARCHAR(512) NULL,
        [Approval] NVARCHAR(512) NULL,
        [{ approvedBy, approvedAt }] NVARCHAR(512) NULL,
        [CalendarEventId] NVARCHAR(512) NULL,
        [{tenantId, activityId, dueDate}] NVARCHAR(512) NULL,
        [{tenantId, status, dueDate}] NVARCHAR(512) NULL,
        [ACTIV_SEG] NVARCHAR(512) NULL,
        [EvidenceDocumentIdsJson] NVARCHAR(MAX) NULL,
        [ApprovalJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmActivityOccurrences_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmActivityOccurrences_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmActivityOccurrences] PRIMARY KEY ([CrmActivityOccurrenceId]),
        CONSTRAINT [FK_crm_CrmActivityOccurrences_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmActivityOccurrences_Tenant] ON [crm].[CrmActivityOccurrences] ([TenantId]);
END;
GO
