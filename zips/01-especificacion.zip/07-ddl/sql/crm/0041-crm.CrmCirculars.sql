-- crm.CrmCirculars — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmCirculars', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmCirculars] (
        [CrmCircularId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NULL,
        [DES_CIR] NVARCHAR(512) NULL,
        [BodyTemplateKey] NVARCHAR(512) NULL,
        [TEXTO] NVARCHAR(512) NULL,
        [DebtFilter] NVARCHAR(512) NULL,
        [{ debtKind] NVARCHAR(512) NULL,
        [), minAmount Decimal128] NVARCHAR(512) NULL,
        [) }] NVARCHAR(512) NULL,
        [EnrollmentFilter] NVARCHAR(512) NULL,
        [ADHER] NVARCHAR(512) NULL,
        [Signatures] NVARCHAR(512) NULL,
        [{ manager] NVARCHAR(512) NULL,
        [), auditor] NVARCHAR(512) NULL,
        [IncludeServiceDetail] NVARCHAR(512) NULL,
        [DET_SER] NVARCHAR(512) NULL,
        [ServiceId] NVARCHAR(512) NULL,
        [COD_SER] NVARCHAR(512) NULL,
        [Channels] NVARCHAR(512) NULL,
        [Print] NVARCHAR(512) NULL,
        [Email] NVARCHAR(512) NULL,
        [Sms] NVARCHAR(512) NULL,
        [SMS] NVARCHAR(512) NULL,
        [Whatsapp] NVARCHAR(512) NULL,
        [TemplateKey] NVARCHAR(512) NULL,
        [PLANTILLA] NVARCHAR(512) NULL,
        [AudienceDefinition] NVARCHAR(512) NULL,
        [RequiresApproval] NVARCHAR(512) NULL,
        [CIRCULAR] NVARCHAR(512) NULL,
        [CIRCUPRO] NVARCHAR(512) NULL,
        [DebtFilterJson] NVARCHAR(MAX) NULL,
        [SignaturesJson] NVARCHAR(MAX) NULL,
        [TemplateVersionId] UNIQUEIDENTIFIER NULL,
        [Code] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCirculars_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCirculars_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmCirculars] PRIMARY KEY ([CrmCircularId]),
        CONSTRAINT [FK_crm_CrmCirculars_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmCirculars_Tenant] ON [crm].[CrmCirculars] ([TenantId]);
END;
GO
