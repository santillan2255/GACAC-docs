-- crm.CrmQueueTicketEvents — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmQueueTicketEvents', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmQueueTicketEvents] (
        [CrmQueueTicketEventId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [QueueTicketId] NVARCHAR(512) NULL,
        [Action] NVARCHAR(512) NULL,
        [Received] NVARCHAR(512) NULL,
        [Waiting] NVARCHAR(512) NULL,
        [Called] NVARCHAR(512) NULL,
        [Recalled] NVARCHAR(512) NULL,
        [Served] NVARCHAR(512) NULL,
        [Derived] NVARCHAR(512) NULL,
        [FinishedSolved] NVARCHAR(512) NULL,
        [FinishedUnsolved] NVARCHAR(512) NULL,
        [FinishedNoShow] NVARCHAR(512) NULL,
        [Cancelled] NVARCHAR(512) NULL,
        [AreaId] NVARCHAR(512) NULL,
        [DeskId] NVARCHAR(512) NULL,
        [DeskSessionId] NVARCHAR(512) NULL,
        [UserId] NVARCHAR(512) NULL,
        [At] DATETIME2(7) NULL,
        [Note] NVARCHAR(512) NULL,
        [{tenantId, queueTicketId, at}] NVARCHAR(512) NULL,
        [TURNOS_HISTORIAL] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueTicketEvents_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueTicketEvents_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmQueueTicketEvents] PRIMARY KEY ([CrmQueueTicketEventId]),
        CONSTRAINT [FK_crm_CrmQueueTicketEvents_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmQueueTicketEvents_Tenant] ON [crm].[CrmQueueTicketEvents] ([TenantId]);
END;
GO
