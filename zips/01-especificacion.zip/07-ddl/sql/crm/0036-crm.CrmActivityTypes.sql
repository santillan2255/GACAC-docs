-- crm.CrmActivityTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmActivityTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmActivityTypes] (
        [CrmActivityTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AreaId] NVARCHAR(512) NULL,
        [COD_AREA] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [DES_TIPO] NVARCHAR(512) NULL,
        [MarginBeforeDays] NVARCHAR(512) NULL,
        [MARGEN_ANT] NVARCHAR(512) NULL,
        [MarginAfterDays] NVARCHAR(512) NULL,
        [MARGEN_POS] NVARCHAR(512) NULL,
        [FrequencyId] NVARCHAR(512) NULL,
        [COD_FREC] NVARCHAR(512) NULL,
        [TemplateKey] NVARCHAR(512) NULL,
        [PLANTILLA] NVARCHAR(512) NULL,
        [ReminderWeekday] NVARCHAR(512) NULL,
        [DIAS_ENVIO] NVARCHAR(512) NULL,
        [RequiresApproval] NVARCHAR(512) NULL,
        [RequiresEvidence] NVARCHAR(512) NULL,
        [EscalateAfterDays] NVARCHAR(512) NULL,
        [ACT_TIPOS] NVARCHAR(512) NULL,
        [RubroId] UNIQUEIDENTIFIER NULL,
        [Code] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmActivityTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmActivityTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmActivityTypes] PRIMARY KEY ([CrmActivityTypeId]),
        CONSTRAINT [FK_crm_CrmActivityTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmActivityTypes_Tenant] ON [crm].[CrmActivityTypes] ([TenantId]);
END;
GO
