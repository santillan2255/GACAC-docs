-- crm.CrmCaseTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmCaseTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmCaseTypes] (
        [CrmCaseTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [RequestAction] VARCHAR(64) NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NULL,
        [StatusSetId] UNIQUEIDENTIFIER NOT NULL,
        [WorkflowDefinitionId] UNIQUEIDENTIFIER NULL,
        [RequirementsTemplate] NVARCHAR(MAX) NULL,
        [CustomFieldsSchema] NVARCHAR(MAX) NULL,
        [CommandsOnApproval] NVARCHAR(MAX) NULL,
        [DefaultAreaId] UNIQUEIDENTIFIER NULL,
        [DefaultPriority] INT NULL,
        [SlaPolicyId] UNIQUEIDENTIFIER NULL,
        [NumberingPolicy] NVARCHAR(MAX) NULL,
        [PublicIntake] BIT NULL,
        [CustomerVisible] BIT NOT NULL,
        [RequiresAccount] BIT NOT NULL,
        [AllowsAnonymous] BIT NULL,
        [SurveyTemplateId] UNIQUEIDENTIFIER NULL,
        [AutoCloseDays] INT NULL,
        [ReopenWindowDays] INT NULL,
        [RegulatorCode] NVARCHAR(512) NULL,
        [Sensitive] BIT NULL,
        [TemplateKeys] NVARCHAR(MAX) NULL,
        [BillingMode] VARCHAR(64) NULL,
        [ProjectId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCaseTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCaseTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmCaseTypes] PRIMARY KEY ([CrmCaseTypeId]),
        CONSTRAINT [FK_crm_CrmCaseTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmCaseTypes_Tenant] ON [crm].[CrmCaseTypes] ([TenantId]);
END;
GO
