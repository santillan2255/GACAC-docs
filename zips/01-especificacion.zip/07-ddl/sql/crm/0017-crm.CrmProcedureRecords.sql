-- crm.CrmProcedureRecords — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmProcedureRecords', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmProcedureRecords] (
        [CrmProcedureRecordId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ProcedureTypeId] UNIQUEIDENTIFIER NOT NULL,
        [Date] DATETIME2(7) NOT NULL,
        [ExpiresAt] DATETIME2(7) NULL,
        [Presented] BIT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Notes] NVARCHAR(512) NULL,
        [DocumentIdsId] UNIQUEIDENTIFIER NULL,
        [ActionsExecuted] NVARCHAR(MAX) NULL,
        [CrmCaseId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmProcedureRecords_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmProcedureRecords_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmProcedureRecords] PRIMARY KEY ([CrmProcedureRecordId]),
        CONSTRAINT [FK_crm_CrmProcedureRecords_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmProcedureRecords_Tenant] ON [crm].[CrmProcedureRecords] ([TenantId]);
END;
GO
