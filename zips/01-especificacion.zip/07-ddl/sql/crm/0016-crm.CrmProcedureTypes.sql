-- crm.CrmProcedureTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmProcedureTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmProcedureTypes] (
        [CrmProcedureTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [EntityLevel] VARCHAR(64) NOT NULL,
        [ExpiryDays] INT NULL,
        [Kind] NVARCHAR(512) NULL,
        [IsDefault] BIT NULL,
        [TemplateKey] NVARCHAR(512) NULL,
        [Actions] NVARCHAR(MAX) NULL,
        [RequiredForServiceIdsId] UNIQUEIDENTIFIER NULL,
        [IntakeRouteCodes] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmProcedureTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmProcedureTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmProcedureTypes] PRIMARY KEY ([CrmProcedureTypeId]),
        CONSTRAINT [FK_crm_CrmProcedureTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmProcedureTypes_Tenant] ON [crm].[CrmProcedureTypes] ([TenantId]);
END;
GO
