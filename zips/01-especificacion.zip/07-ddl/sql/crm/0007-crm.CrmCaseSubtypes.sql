-- crm.CrmCaseSubtypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmCaseSubtypes', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmCaseSubtypes] (
        [CrmCaseSubtypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CaseTypeId] UNIQUEIDENTIFIER NOT NULL,
        [DefaultStatus] NVARCHAR(512) NULL,
        [DefaultPriority] INT NULL,
        [UrgentSafety] BIT NULL,
        [SlaPolicyId] UNIQUEIDENTIFIER NULL,
        [RegistersCause] BIT NOT NULL,
        [CauseCodes] NVARCHAR(512) NULL,
        [BlockClosure] BIT NOT NULL,
        [IsDefault] BIT NULL,
        [ProductId] UNIQUEIDENTIFIER NULL,
        [IncidentCategoryId] UNIQUEIDENTIFIER NULL,
        [WorkOrderOperationCode] NVARCHAR(512) NULL,
        [QuickReplyIdsId] UNIQUEIDENTIFIER NULL,
        [DuplicateWindowDays] INT NULL,
        [IncidentDetection] NVARCHAR(MAX) NULL,
        [ClaimTypeKey] NVARCHAR(512) NULL,
        [ExternalDerivation] NVARCHAR(MAX) NULL,
        [RegulatoryReasonCode] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCaseSubtypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCaseSubtypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmCaseSubtypes] PRIMARY KEY ([CrmCaseSubtypeId]),
        CONSTRAINT [FK_crm_CrmCaseSubtypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmCaseSubtypes_Tenant] ON [crm].[CrmCaseSubtypes] ([TenantId]);
END;
GO
