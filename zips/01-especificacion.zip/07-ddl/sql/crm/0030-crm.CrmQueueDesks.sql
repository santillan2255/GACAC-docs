-- crm.CrmQueueDesks — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmQueueDesks', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmQueueDesks] (
        [CrmQueueDeskId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [BranchId] NVARCHAR(512) NULL,
        [DeskTypeId] NVARCHAR(512) NULL,
        [COD_TBOX] NVARCHAR(512) NULL,
        [Number] NVARCHAR(512) NULL,
        [NUM_BOX] NVARCHAR(512) NULL,
        [Label] NVARCHAR(512) NULL,
        [IsAutoGeneration] NVARCHAR(512) NULL,
        [AreaIds] NVARCHAR(512) NULL,
        [{tenantId, branchId, number}] NVARCHAR(512) NULL,
        [TUR_BOX] NVARCHAR(512) NULL,
        [AreaIdsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueDesks_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueDesks_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmQueueDesks] PRIMARY KEY ([CrmQueueDeskId]),
        CONSTRAINT [FK_crm_CrmQueueDesks_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmQueueDesks_Tenant] ON [crm].[CrmQueueDesks] ([TenantId]);
END;
GO
