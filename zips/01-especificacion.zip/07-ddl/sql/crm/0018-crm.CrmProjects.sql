-- crm.CrmProjects — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmProjects', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmProjects] (
        [CrmProjectId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AccountId] UNIQUEIDENTIFIER NULL,
        [Components] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [OwnerUserId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmProjects_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmProjects_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmProjects] PRIMARY KEY ([CrmProjectId]),
        CONSTRAINT [FK_crm_CrmProjects_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmProjects_Tenant] ON [crm].[CrmProjects] ([TenantId]);
END;
GO
