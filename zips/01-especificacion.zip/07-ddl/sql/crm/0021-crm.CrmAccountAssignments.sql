-- crm.CrmAccountAssignments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmAccountAssignments', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmAccountAssignments] (
        [CrmAccountAssignmentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AccountId] UNIQUEIDENTIFIER NOT NULL,
        [UserId] UNIQUEIDENTIFIER NOT NULL,
        [ProjectId] UNIQUEIDENTIFIER NULL,
        [Role] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmAccountAssignments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmAccountAssignments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmAccountAssignments] PRIMARY KEY ([CrmAccountAssignmentId]),
        CONSTRAINT [FK_crm_CrmAccountAssignments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmAccountAssignments_Tenant] ON [crm].[CrmAccountAssignments] ([TenantId]);
END;
GO
