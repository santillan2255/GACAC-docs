-- crm.CrmCalendarEvents — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmCalendarEvents', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmCalendarEvents] (
        [CrmCalendarEventId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [UserId] NVARCHAR(512) NULL,
        [COD_USER] NVARCHAR(512) NULL,
        [AllDay] NVARCHAR(512) NULL,
        [TODOELDIA] NVARCHAR(512) NULL,
        [Start] NVARCHAR(512) NULL,
        [End] NVARCHAR(512) NULL,
        [CAL_START] NVARCHAR(512) NULL,
        [CAL_END] NVARCHAR(512) NULL,
        [Subject] NVARCHAR(512) NULL,
        [CAL_ASUNTO] NVARCHAR(512) NULL,
        [Description] NVARCHAR(512) NULL,
        [CAL_DES] NVARCHAR(512) NULL,
        [Location] NVARCHAR(512) NULL,
        [CAL_UBICA] NVARCHAR(512) NULL,
        [Label] NVARCHAR(512) NULL,
        [ETIQUETA] NVARCHAR(512) NULL,
        [Recurrence] NVARCHAR(512) NULL,
        [INFO_RECUR] NVARCHAR(512) NULL,
        [Reminders] NVARCHAR(512) NULL,
        [INFO_RECOR] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [ESTADO] NVARCHAR(512) NULL,
        [EventTypeId] NVARCHAR(512) NULL,
        [TIPO] NVARCHAR(512) NULL,
        [Source] NVARCHAR(512) NULL,
        [{ type] NVARCHAR(512) NULL,
        [{tenantId, userId, start}] NVARCHAR(512) NULL,
        [CALENDARIO] NVARCHAR(512) NULL,
        [RemindersJson] NVARCHAR(MAX) NULL,
        [SourceJson] NVARCHAR(MAX) NULL,
        [TypeId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCalendarEvents_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCalendarEvents_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmCalendarEvents] PRIMARY KEY ([CrmCalendarEventId]),
        CONSTRAINT [FK_crm_CrmCalendarEvents_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmCalendarEvents_Tenant] ON [crm].[CrmCalendarEvents] ([TenantId]);
END;
GO
