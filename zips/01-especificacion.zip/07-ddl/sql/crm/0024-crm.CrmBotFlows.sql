-- crm.CrmBotFlows — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmBotFlows', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmBotFlows] (
        [CrmBotFlowId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Intents] NVARCHAR(MAX) NOT NULL,
        [Handoff] NVARCHAR(MAX) NOT NULL,
        [Faq] NVARCHAR(MAX) NULL,
        [Version] INT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmBotFlows_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmBotFlows_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmBotFlows] PRIMARY KEY ([CrmBotFlowId]),
        CONSTRAINT [FK_crm_CrmBotFlows_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmBotFlows_Tenant] ON [crm].[CrmBotFlows] ([TenantId]);
END;
GO
