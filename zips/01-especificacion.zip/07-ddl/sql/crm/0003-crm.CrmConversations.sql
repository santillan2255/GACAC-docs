-- crm.CrmConversations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmConversations', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmConversations] (
        [CrmConversationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ChannelId] UNIQUEIDENTIFIER NOT NULL,
        [ChannelKind] VARCHAR(64) NOT NULL,
        [ExternalThreadId] NVARCHAR(512) NULL,
        [Participant] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [AssignedUserId] UNIQUEIDENTIFIER NULL,
        [CaseIdsId] UNIQUEIDENTIFIER NULL,
        [WindowExpiresAt] DATETIME2(7) NULL,
        [BotSessionId] UNIQUEIDENTIFIER NULL,
        [OptOut] BIT NULL,
        [LastMessageAt] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmConversations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmConversations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmConversations] PRIMARY KEY ([CrmConversationId]),
        CONSTRAINT [FK_crm_CrmConversations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmConversations_Tenant] ON [crm].[CrmConversations] ([TenantId]);
END;
GO
