-- crm.CrmActivityFrequencies — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmActivityFrequencies', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmActivityFrequencies] (
        [CrmActivityFrequencyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] NVARCHAR(512) NULL,
        [Weekly] NVARCHAR(512) NULL,
        [Monthly] NVARCHAR(512) NULL,
        [Bimonthly] NVARCHAR(512) NULL,
        [Quarterly] NVARCHAR(512) NULL,
        [FourMonthly] NVARCHAR(512) NULL,
        [Semiannual] NVARCHAR(512) NULL,
        [Annual] NVARCHAR(512) NULL,
        [EveryNDays] NVARCHAR(512) NULL,
        [Days] NVARCHAR(512) NULL,
        [{tenantId, kind, days}] NVARCHAR(512) NULL,
        [ACT_FREC] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmActivityFrequencies_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmActivityFrequencies_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmActivityFrequencies] PRIMARY KEY ([CrmActivityFrequencyId]),
        CONSTRAINT [FK_crm_CrmActivityFrequencies_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmActivityFrequencies_Tenant] ON [crm].[CrmActivityFrequencies] ([TenantId]);
END;
GO
