-- crm.CrmContacts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmContacts', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmContacts] (
        [CrmContactId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [DisplayName] NVARCHAR(512) NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [RelatedAccountIdsId] UNIQUEIDENTIFIER NULL,
        [Relation] VARCHAR(64) NULL,
        [Notes] NVARCHAR(512) NULL,
        [DoNotNotify] BIT NULL,
        [MergedIntoId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmContacts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmContacts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmContacts] PRIMARY KEY ([CrmContactId]),
        CONSTRAINT [FK_crm_CrmContacts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmContacts_Tenant] ON [crm].[CrmContacts] ([TenantId]);
END;
GO
