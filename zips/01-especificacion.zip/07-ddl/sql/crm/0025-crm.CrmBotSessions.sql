-- crm.CrmBotSessions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmBotSessions', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmBotSessions] (
        [CrmBotSessionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ConversationId] NVARCHAR(512) NULL,
        [FlowId] NVARCHAR(512) NULL,
        [FlowVersion] NVARCHAR(512) NULL,
        [CurrentIntent] NVARCHAR(512) NULL,
        [Step] NVARCHAR(512) NULL,
        [Slots{}] NVARCHAR(512) NULL,
        [Verification] NVARCHAR(512) NULL,
        [{ method] NVARCHAR(512) NULL,
        [StartedAt] DATETIME2(7) NULL,
        [EndedAt] DATETIME2(7) NULL,
        [Outcome] NVARCHAR(512) NULL,
        [SelfServed] NVARCHAR(512) NULL,
        [CaseCreated] NVARCHAR(512) NULL,
        [HandedOff] NVARCHAR(512) NULL,
        [Abandoned] NVARCHAR(512) NULL,
        [CrmCaseId?] NVARCHAR(512) NULL,
        [{tenantId, conversationId, startedAt}] NVARCHAR(512) NULL,
        [VerificationJson] NVARCHAR(MAX) NULL,
        [CrmCaseId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmBotSessions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmBotSessions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmBotSessions] PRIMARY KEY ([CrmBotSessionId]),
        CONSTRAINT [FK_crm_CrmBotSessions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmBotSessions_Tenant] ON [crm].[CrmBotSessions] ([TenantId]);
END;
GO
