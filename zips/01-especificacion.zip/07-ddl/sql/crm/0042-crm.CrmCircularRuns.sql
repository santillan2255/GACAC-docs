-- crm.CrmCircularRuns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmCircularRuns', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmCircularRuns] (
        [CrmCircularRunId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CircularId] NVARCHAR(512) NULL,
        [AudienceSnapshotRef] NVARCHAR(512) NULL,
        [RecipientCount] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [PendingApproval] NVARCHAR(512) NULL,
        [Approved] NVARCHAR(512) NULL,
        [Generating] NVARCHAR(512) NULL,
        [Sent] NVARCHAR(512) NULL,
        [PartiallyFailed] NVARCHAR(512) NULL,
        [Cancelled] NVARCHAR(512) NULL,
        [CommunicationRunIds] NVARCHAR(512) NULL,
        [PrintDocumentId?] NVARCHAR(512) NULL,
        [LabelsDocumentId?] NVARCHAR(512) NULL,
        [WorkOrderCommandIds] NVARCHAR(512) NULL,
        [ApprovedBy] NVARCHAR(512) NULL,
        [ApprovedAt] DATETIME2(7) NULL,
        [Results] NVARCHAR(512) NULL,
        [{ delivered, failed, printed }] NVARCHAR(512) NULL,
        [AudienceSnapshotId] NVARCHAR(512) NULL,
        [CommunicationRunIdsJson] NVARCHAR(MAX) NULL,
        [PrintDocumentId] UNIQUEIDENTIFIER NULL,
        [LabelsDocumentId] UNIQUEIDENTIFIER NULL,
        [WorkOrderCommandIdsJson] NVARCHAR(MAX) NULL,
        [ApprovedById] UNIQUEIDENTIFIER NULL,
        [ResultsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCircularRuns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmCircularRuns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmCircularRuns] PRIMARY KEY ([CrmCircularRunId]),
        CONSTRAINT [FK_crm_CrmCircularRuns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmCircularRuns_Tenant] ON [crm].[CrmCircularRuns] ([TenantId]);
END;
GO
