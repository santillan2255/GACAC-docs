-- crm.CrmQueueDisplays — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmQueueDisplays', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmQueueDisplays] (
        [CrmQueueDisplayId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [BranchId] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [Mode] NVARCHAR(512) NULL,
        [HighlightLast] NVARCHAR(512) NULL,
        [AllEqual] NVARCHAR(512) NULL,
        [HighlightLastLarge] NVARCHAR(512) NULL,
        [GroupBy] NVARCHAR(512) NULL,
        [LastCalls] NVARCHAR(512) NULL,
        [ByDesk] NVARCHAR(512) NULL,
        [ShowName] NVARCHAR(512) NULL,
        [Voice] NVARCHAR(512) NULL,
        [{ enabled, voiceName, rate }] NVARCHAR(512) NULL,
        [AreaIds] NVARCHAR(512) NULL,
        [AccessTokenHash] NVARCHAR(512) NULL,
        [LocalAgentId?] NVARCHAR(512) NULL,
        [VoiceJson] NVARCHAR(MAX) NULL,
        [AreaIdsJson] NVARCHAR(MAX) NULL,
        [LocalAgentId] UNIQUEIDENTIFIER NULL,
        [Code] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueDisplays_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueDisplays_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmQueueDisplays] PRIMARY KEY ([CrmQueueDisplayId]),
        CONSTRAINT [FK_crm_CrmQueueDisplays_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmQueueDisplays_Tenant] ON [crm].[CrmQueueDisplays] ([TenantId]);
END;
GO
