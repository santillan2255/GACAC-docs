-- crm.CrmInteractions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmInteractions', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmInteractions] (
        [CrmInteractionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [ChannelKind] VARCHAR(64) NOT NULL,
        [Direction] VARCHAR(64) NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [ReasonCode] NVARCHAR(512) NULL,
        [Outcome] VARCHAR(64) NULL,
        [UserId] UNIQUEIDENTIFIER NULL,
        [Summary] NVARCHAR(512) NULL,
        [Call] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmInteractions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmInteractions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmInteractions] PRIMARY KEY ([CrmInteractionId]),
        CONSTRAINT [FK_crm_CrmInteractions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmInteractions_Tenant] ON [crm].[CrmInteractions] ([TenantId]);
END;
GO
