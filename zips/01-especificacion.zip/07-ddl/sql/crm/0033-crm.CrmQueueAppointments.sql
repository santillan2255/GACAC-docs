-- crm.CrmQueueAppointments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmQueueAppointments', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmQueueAppointments] (
        [CrmQueueAppointmentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [BranchId] NVARCHAR(512) NULL,
        [AreaId] NVARCHAR(512) NULL,
        [SlotStart] NVARCHAR(512) NULL,
        [SlotEnd] NVARCHAR(512) NULL,
        [PersonId?] NVARCHAR(512) NULL,
        [Contact] NVARCHAR(512) NULL,
        [{ name, phone, email }] NVARCHAR(512) NULL,
        [ReasonCode] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Booked] NVARCHAR(512) NULL,
        [Confirmed] NVARCHAR(512) NULL,
        [CheckedIn] NVARCHAR(512) NULL,
        [NoShow] NVARCHAR(512) NULL,
        [Cancelled] NVARCHAR(512) NULL,
        [QueueTicketId?] NVARCHAR(512) NULL,
        [Channel] NVARCHAR(512) NULL,
        [ReminderSentAt?] NVARCHAR(512) NULL,
        [{tenantId, areaId, slotStart}] NVARCHAR(512) NULL,
        [CrmAreasQueueSlots] NVARCHAR(512) NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [ContactJson] NVARCHAR(MAX) NULL,
        [QueueTicketId] UNIQUEIDENTIFIER NULL,
        [ReminderSentAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueAppointments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueAppointments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmQueueAppointments] PRIMARY KEY ([CrmQueueAppointmentId]),
        CONSTRAINT [FK_crm_CrmQueueAppointments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmQueueAppointments_Tenant] ON [crm].[CrmQueueAppointments] ([TenantId]);
END;
GO
