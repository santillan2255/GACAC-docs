-- crm.CrmStatusSets — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmStatusSets', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmStatusSets] (
        [CrmStatusSetId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [States] NVARCHAR(MAX) NOT NULL,
        [Transitions] NVARCHAR(MAX) NULL,
        [WorkflowRefId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmStatusSets_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmStatusSets_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmStatusSets] PRIMARY KEY ([CrmStatusSetId]),
        CONSTRAINT [FK_crm_CrmStatusSets_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmStatusSets_Tenant] ON [crm].[CrmStatusSets] ([TenantId]);
END;
GO
