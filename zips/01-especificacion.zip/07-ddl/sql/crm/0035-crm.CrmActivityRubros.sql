-- crm.CrmActivityRubros — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmActivityRubros', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmActivityRubros] (
        [CrmActivityRubroId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [NameKey] NVARCHAR(512) NULL,
        [ACT_RBR] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmActivityRubros_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmActivityRubros_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmActivityRubros] PRIMARY KEY ([CrmActivityRubroId]),
        CONSTRAINT [FK_crm_CrmActivityRubros_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmActivityRubros_Tenant] ON [crm].[CrmActivityRubros] ([TenantId]);
END;
GO
