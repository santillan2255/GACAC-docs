-- crm.CrmQuickReplies — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmQuickReplies', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmQuickReplies] (
        [CrmQuickReplyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Title] NVARCHAR(512) NULL,
        [Body] NVARCHAR(512) NULL,
        [{{caseNumber}}] NVARCHAR(512) NULL,
        [{{personFirstName}}] NVARCHAR(512) NULL,
        [ChannelKinds] NVARCHAR(512) NULL,
        [CaseTypeIds] NVARCHAR(512) NULL,
        [CaseSubtypeIds] NVARCHAR(512) NULL,
        [Visibility] NVARCHAR(512) NULL,
        [All] NVARCHAR(512) NULL,
        [Area] NVARCHAR(512) NULL,
        [Personal] NVARCHAR(512) NULL,
        [OwnerUserId?] NVARCHAR(512) NULL,
        [AreaId?] NVARCHAR(512) NULL,
        [TICKETS_TIPOS] NVARCHAR(512) NULL,
        [TICKETS_SUBTIPOS] NVARCHAR(512) NULL,
        [ChannelKindsJson] NVARCHAR(MAX) NULL,
        [CaseTypeIdsJson] NVARCHAR(MAX) NULL,
        [CaseSubtypeIdsJson] NVARCHAR(MAX) NULL,
        [OwnerUserId] UNIQUEIDENTIFIER NULL,
        [AreaId] UNIQUEIDENTIFIER NULL,
        [Code] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQuickReplies_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQuickReplies_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmQuickReplies] PRIMARY KEY ([CrmQuickReplyId]),
        CONSTRAINT [FK_crm_CrmQuickReplies_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmQuickReplies_Tenant] ON [crm].[CrmQuickReplies] ([TenantId]);
END;
GO
