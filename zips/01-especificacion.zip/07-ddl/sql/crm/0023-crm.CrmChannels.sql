-- crm.CrmChannels — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmChannels', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmChannels] (
        [CrmChannelId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [IntakeRouteCode] NVARCHAR(512) NOT NULL,
        [ProviderConnectionId] UNIQUEIDENTIFIER NULL,
        [Address] NVARCHAR(512) NULL,
        [BusinessHours] NVARCHAR(MAX) NULL,
        [BotFlowId] UNIQUEIDENTIFIER NULL,
        [DefaultAreaId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [TemplatesSyncedAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmChannels_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmChannels_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmChannels] PRIMARY KEY ([CrmChannelId]),
        CONSTRAINT [FK_crm_CrmChannels_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmChannels_Tenant] ON [crm].[CrmChannels] ([TenantId]);
END;
GO
