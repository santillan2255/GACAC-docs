-- crm.CrmWorkLogs — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmWorkLogs', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmWorkLogs] (
        [CrmWorkLogId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CrmCaseId] UNIQUEIDENTIFIER NOT NULL,
        [UserId] UNIQUEIDENTIFIER NOT NULL,
        [Minutes] INT NOT NULL,
        [BillableMinutes] INT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [AutoPaused] BIT NULL,
        [BillingStatus] VARCHAR(64) NOT NULL,
        [HourBankId] UNIQUEIDENTIFIER NULL,
        [InvoiceRefId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmWorkLogs_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmWorkLogs_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmWorkLogs] PRIMARY KEY ([CrmWorkLogId]),
        CONSTRAINT [FK_crm_CrmWorkLogs_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmWorkLogs_Tenant] ON [crm].[CrmWorkLogs] ([TenantId]);
END;
GO
