-- crm.CrmQueueTickets — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmQueueTickets', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmQueueTickets] (
        [CrmQueueTicketId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [BranchId] UNIQUEIDENTIFIER NOT NULL,
        [ServiceDate] NVARCHAR(512) NOT NULL,
        [Seq] INT NOT NULL,
        [DisplayCode] NVARCHAR(512) NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [DisplayName] NVARCHAR(512) NULL,
        [Priority] BIT NOT NULL,
        [PriorityReason] NVARCHAR(512) NULL,
        [Origin] VARCHAR(64) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Outcome] VARCHAR(64) NULL,
        [IssuedAt] DATETIME2(7) NOT NULL,
        [ReasonCode] NVARCHAR(512) NULL,
        [EstimatedWaitMinutes] INT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueTickets_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmQueueTickets_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmQueueTickets] PRIMARY KEY ([CrmQueueTicketId]),
        CONSTRAINT [FK_crm_CrmQueueTickets_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmQueueTickets_Tenant] ON [crm].[CrmQueueTickets] ([TenantId]);
END;
GO
