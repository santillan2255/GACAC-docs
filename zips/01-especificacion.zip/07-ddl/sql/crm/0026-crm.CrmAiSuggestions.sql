-- crm.CrmAiSuggestions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'crm.CrmAiSuggestions', N'U') IS NULL
BEGIN
    CREATE TABLE [crm].[CrmAiSuggestions] (
        [CrmAiSuggestionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Function] VARCHAR(64) NOT NULL,
        [InputRefs] NVARCHAR(MAX) NOT NULL,
        [Output] NVARCHAR(MAX) NOT NULL,
        [Confidence] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Decision] NVARCHAR(MAX) NULL,
        [SafetyFlags] NVARCHAR(512) NULL,
        [TargetType] VARCHAR(64) NULL,
        [TargetId] UNIQUEIDENTIFIER NULL,
        [AiUsageLogId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmAiSuggestions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_crm_CrmAiSuggestions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_crm_CrmAiSuggestions] PRIMARY KEY ([CrmAiSuggestionId]),
        CONSTRAINT [FK_crm_CrmAiSuggestions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_crm_CrmAiSuggestions_Tenant] ON [crm].[CrmAiSuggestions] ([TenantId]);
END;
GO
