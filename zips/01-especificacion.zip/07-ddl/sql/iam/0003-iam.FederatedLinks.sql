-- iam.FederatedLinks — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'iam.FederatedLinks', N'U') IS NULL
BEGIN
    CREATE TABLE [iam].[FederatedLinks] (
        [FederatedLinkId] UNIQUEIDENTIFIER NOT NULL,
        [IdentityId] UNIQUEIDENTIFIER NOT NULL,
        [Provider] VARCHAR(64) NOT NULL,
        [Issuer] NVARCHAR(512) NOT NULL,
        [Subject] NVARCHAR(512) NOT NULL,
        [ScopeTenantId] UNIQUEIDENTIFIER NULL,
        [IdpConfigId] UNIQUEIDENTIFIER NULL,
        [EmailAtLink] NVARCHAR(512) NULL,
        [AssuranceLevel] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_FederatedLinks_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_FederatedLinks_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_iam_FederatedLinks] PRIMARY KEY ([FederatedLinkId])
    );
END;
GO
