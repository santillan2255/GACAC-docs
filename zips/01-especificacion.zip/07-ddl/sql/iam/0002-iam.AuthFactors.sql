-- iam.AuthFactors — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'iam.AuthFactors', N'U') IS NULL
BEGIN
    CREATE TABLE [iam].[AuthFactors] (
        [AuthFactorId] UNIQUEIDENTIFIER NOT NULL,
        [IdentityId] UNIQUEIDENTIFIER NOT NULL,
        [Type] VARCHAR(64) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Label] NVARCHAR(512) NULL,
        [DestinationMasked] NVARCHAR(512) NULL,
        [TotpSecretEnc] NVARCHAR(MAX) NULL,
        [WebauthnJson] NVARCHAR(MAX) NULL,
        [RecoveryCodeHashesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_AuthFactors_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_AuthFactors_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_iam_AuthFactors] PRIMARY KEY ([AuthFactorId])
    );
END;
GO
