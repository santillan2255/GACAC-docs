-- iam.Memberships — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'iam.Memberships', N'U') IS NULL
BEGIN
    CREATE TABLE [iam].[Memberships] (
        [MembershipId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [IdentityId] UNIQUEIDENTIFIER NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Staff] NVARCHAR(MAX) NULL,
        [Portal] NVARCHAR(MAX) NULL,
        [SessionEpoch] INT NOT NULL,
        [AuthzVersion] INT NOT NULL,
        [LastAccessAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_Memberships_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_Memberships_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_iam_Memberships] PRIMARY KEY ([MembershipId]),
        CONSTRAINT [FK_iam_Memberships_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_iam_Memberships_Tenant] ON [iam].[Memberships] ([TenantId]);
END;
GO
