-- iam.Roles — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'iam.Roles', N'U') IS NULL
BEGIN
    CREATE TABLE [iam].[Roles] (
        [RoleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [NameKey] NVARCHAR(512) NOT NULL,
        [Description] NVARCHAR(512) NULL,
        [Space] VARCHAR(64) NOT NULL,
        [Origin] VARCHAR(64) NOT NULL,
        [Capabilities] NVARCHAR(512) NOT NULL,
        [DenyCapabilities] NVARCHAR(512) NULL,
        [DefaultScopeMode] VARCHAR(64) NULL,
        [RequiresMfa] BIT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_Roles_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_Roles_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_iam_Roles] PRIMARY KEY ([RoleId]),
        CONSTRAINT [FK_iam_Roles_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_iam_Roles_Tenant] ON [iam].[Roles] ([TenantId]);
END;
GO
