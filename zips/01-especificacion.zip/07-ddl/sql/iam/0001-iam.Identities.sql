-- iam.Identities — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'iam.Identities', N'U') IS NULL
BEGIN
    CREATE TABLE [iam].[Identities] (
        [IdentityId] UNIQUEIDENTIFIER NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [PrimaryEmail] NVARCHAR(512) NOT NULL,
        [EmailVerifiedAt] DATETIME2(7) NULL,
        [PhoneE164] NVARCHAR(512) NULL,
        [PhoneVerifiedAt] DATETIME2(7) NULL,
        [DisplayName] NVARCHAR(512) NOT NULL,
        [Locale] NVARCHAR(512) NULL,
        [PasswordHash] NVARCHAR(512) NULL,
        [PasswordAlgo] VARCHAR(64) NULL,
        [PasswordChangedAt] DATETIME2(7) NULL,
        [PasswordCompromised] BIT NULL,
        [FailedLoginCount] INT NOT NULL,
        [FailedWindowStartedAt] DATETIME2(7) NULL,
        [LockedUntil] DATETIME2(7) NULL,
        [LastLoginAt] DATETIME2(7) NULL,
        [SessionEpoch] INT NOT NULL,
        [MfaId] UNIQUEIDENTIFIER NOT NULL,
        [PlatformMember] BIT NOT NULL,
        [DeletedAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_Identities_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_Identities_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_iam_Identities] PRIMARY KEY ([IdentityId])
    );
END;
GO
