-- iam.ScreenProfiles — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'iam.ScreenProfiles', N'U') IS NULL
BEGIN
    CREATE TABLE [iam].[ScreenProfiles] (
        [ScreenProfileId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Apps] VARCHAR(64) NOT NULL,
        [Screens] NVARCHAR(512) NOT NULL,
        [TimeWindowsJson] NVARCHAR(MAX) NULL,
        [OutsideWindowBehavior] VARCHAR(64) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_ScreenProfiles_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_iam_ScreenProfiles_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_iam_ScreenProfiles] PRIMARY KEY ([ScreenProfileId]),
        CONSTRAINT [FK_iam_ScreenProfiles_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_iam_ScreenProfiles_Tenant] ON [iam].[ScreenProfiles] ([TenantId]);
END;
GO
