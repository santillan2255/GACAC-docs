-- con.ExternalLedgerMappings — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.ExternalLedgerMappings', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[ExternalLedgerMappings] (
        [ExternalLedgerMappingId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ExternalSystem] NVARCHAR(512) NULL,
        [OperationCode] NVARCHAR(512) NULL,
        [OperationName] NVARCHAR(512) NULL,
        [LedgerAccountId] NVARCHAR(512) NULL,
        [ExternalAccountCode] NVARCHAR(512) NULL,
        [ExternalRubric] NVARCHAR(512) NULL,
        [Notes] NVARCHAR(512) NULL,
        [ExternalLedgerTransfers] NVARCHAR(512) NULL,
        [Direction] NVARCHAR(512) NULL,
        [Export] NVARCHAR(512) NULL,
        [Import] NVARCHAR(512) NULL,
        [DateFrom] NVARCHAR(512) NULL,
        [DateTo] NVARCHAR(512) NULL,
        [LayoutId] NVARCHAR(512) NULL,
        [StoredFileId] NVARCHAR(512) NULL,
        [EntryIds] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Running] NVARCHAR(512) NULL,
        [Completed] NVARCHAR(512) NULL,
        [Failed] NVARCHAR(512) NULL,
        [Partially] NVARCHAR(512) NULL,
        [Errors] NVARCHAR(512) NULL,
        [IdempotencyKey] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_ExternalLedgerMappings_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_ExternalLedgerMappings_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_ExternalLedgerMappings] PRIMARY KEY ([ExternalLedgerMappingId]),
        CONSTRAINT [FK_con_ExternalLedgerMappings_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_ExternalLedgerMappings_Tenant] ON [con].[ExternalLedgerMappings] ([TenantId]);
END;
GO
