-- con.AccountingEvents — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.AccountingEvents', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[AccountingEvents] (
        [AccountingEventId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SourceEventId] NVARCHAR(512) NOT NULL,
        [EventType] NVARCHAR(512) NOT NULL,
        [SourceModule] VARCHAR(64) NOT NULL,
        [SourceDocumentJson] NVARCHAR(MAX) NOT NULL,
        [AccountingDate] DATETIME2(7) NOT NULL,
        [Lines] DECIMAL(18,4) NOT NULL,
        [ReversesEventId] NVARCHAR(512) NULL,
        [OriginalAccountingDate] DATETIME2(7) NULL,
        [Status] VARCHAR(64) NULL,
        [IssuesJson] NVARCHAR(MAX) NULL,
        [PostingBatchId] UNIQUEIDENTIFIER NULL,
        [Attempts] INT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountingEvents_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountingEvents_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_AccountingEvents] PRIMARY KEY ([AccountingEventId]),
        CONSTRAINT [FK_con_AccountingEvents_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_AccountingEvents_Tenant] ON [con].[AccountingEvents] ([TenantId]);
END;
GO
