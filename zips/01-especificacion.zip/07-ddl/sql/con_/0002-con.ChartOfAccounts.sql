-- con.ChartOfAccounts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.ChartOfAccounts', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[ChartOfAccounts] (
        [ChartOfAccountId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [SharedWithLegalEntityIdsId] UNIQUEIDENTIFIER NULL,
        [Purpose] VARCHAR(64) NULL,
        [Status] VARCHAR(64) NULL,
        [VersionNumber] INT NOT NULL,
        [CopiedFromChartId] UNIQUEIDENTIFIER NULL,
        [CodeMask] NVARCHAR(512) NOT NULL,
        [RegulatoryTarget] VARCHAR(64) NULL,
        [ScenarioId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_ChartOfAccounts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_ChartOfAccounts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_ChartOfAccounts] PRIMARY KEY ([ChartOfAccountId]),
        CONSTRAINT [FK_con_ChartOfAccounts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_ChartOfAccounts_Tenant] ON [con].[ChartOfAccounts] ([TenantId]);
END;
GO
