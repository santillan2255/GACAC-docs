-- con.CostAllocationRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.CostAllocationRules', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[CostAllocationRules] (
        [CostAllocationRuleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [OperationType] VARCHAR(64) NULL,
        [ElementType] VARCHAR(64) NULL,
        [ElementId] UNIQUEIDENTIFIER NOT NULL,
        [ModelId] UNIQUEIDENTIFIER NULL,
        [SplitsJson] NVARCHAR(MAX) NOT NULL,
        [LegacyVariable] INT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_CostAllocationRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_CostAllocationRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_CostAllocationRules] PRIMARY KEY ([CostAllocationRuleId]),
        CONSTRAINT [FK_con_CostAllocationRules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_CostAllocationRules_Tenant] ON [con].[CostAllocationRules] ([TenantId]);
END;
GO
