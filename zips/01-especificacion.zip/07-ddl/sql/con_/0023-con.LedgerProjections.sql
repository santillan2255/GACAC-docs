-- con.LedgerProjections — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.LedgerProjections', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[LedgerProjections] (
        [LedgerProjectionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ChartId] UNIQUEIDENTIFIER NULL,
        [SourceLineId] UNIQUEIDENTIFIER NULL,
        [LedgerAccountId] UNIQUEIDENTIFIER NULL,
        [Debit] NVARCHAR(MAX) NULL,
        [Credit] NVARCHAR(MAX) NULL,
        [EntryDate] DATETIME2(7) NULL,
        [CostAllocations] DECIMAL(18,4) NULL,
        [MappingId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_LedgerProjections_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_LedgerProjections_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_LedgerProjections] PRIMARY KEY ([LedgerProjectionId]),
        CONSTRAINT [FK_con_LedgerProjections_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_LedgerProjections_Tenant] ON [con].[LedgerProjections] ([TenantId]);
END;
GO
