-- con.ExternalLedgerTransfers — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.ExternalLedgerTransfers', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[ExternalLedgerTransfers] (
        [ExternalLedgerTransferId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Direction] VARCHAR(64) NULL,
        [DateFrom] DATETIME2(7) NULL,
        [DateTo] DATETIME2(7) NULL,
        [FileLayoutId] UNIQUEIDENTIFIER NULL,
        [StoredFileId] UNIQUEIDENTIFIER NOT NULL,
        [EntryIdsId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ErrorsJson] NVARCHAR(MAX) NULL,
        [IdempotencyKey] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_ExternalLedgerTransfers_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_ExternalLedgerTransfers_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_ExternalLedgerTransfers] PRIMARY KEY ([ExternalLedgerTransferId]),
        CONSTRAINT [FK_con_ExternalLedgerTransfers_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_ExternalLedgerTransfers_Tenant] ON [con].[ExternalLedgerTransfers] ([TenantId]);
END;
GO
