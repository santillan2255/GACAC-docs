-- con.RubricatedBooks — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.RubricatedBooks', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[RubricatedBooks] (
        [RubricatedBookId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [BookType] VARCHAR(64) NULL,
        [Registry] NVARCHAR(512) NOT NULL,
        [LinesPerSheet] INT NOT NULL,
        [FiscalYearId] UNIQUEIDENTIFIER NOT NULL,
        [Volume] INT NOT NULL,
        [StoredFileId] UNIQUEIDENTIFIER NULL,
        [Format] VARCHAR(64) NOT NULL,
        [TranscriptionsJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_RubricatedBooks_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_RubricatedBooks_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_RubricatedBooks] PRIMARY KEY ([RubricatedBookId]),
        CONSTRAINT [FK_con_RubricatedBooks_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_RubricatedBooks_Tenant] ON [con].[RubricatedBooks] ([TenantId]);
END;
GO
