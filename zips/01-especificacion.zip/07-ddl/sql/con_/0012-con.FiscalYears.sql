-- con.FiscalYears — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.FiscalYears', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[FiscalYears] (
        [FiscalYearId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [Number] INT NOT NULL,
        [Status] VARCHAR(64) NULL,
        [Irregular] BIT NOT NULL,
        [ClosingEntriesJson] NVARCHAR(MAX) NULL,
        [HistoryJson] NVARCHAR(MAX) NOT NULL,
        [NextEntryNumber] INT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_FiscalYears_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_FiscalYears_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_FiscalYears] PRIMARY KEY ([FiscalYearId]),
        CONSTRAINT [FK_con_FiscalYears_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_FiscalYears_Tenant] ON [con].[FiscalYears] ([TenantId]);
END;
GO
