-- con.BudgetLines — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.BudgetLines', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[BudgetLines] (
        [BudgetLineId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [BudgetId] NVARCHAR(512) NULL,
        [LedgerAccountId] NVARCHAR(512) NULL,
        [CostCenterId] NVARCHAR(512) NULL,
        [ServiceId] NVARCHAR(512) NULL,
        [Month] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [YYYY-MM] NVARCHAR(512) NULL,
        [Amount] NVARCHAR(512) NULL,
        [SeasonalityKey] NVARCHAR(512) NULL,
        [Notes] NVARCHAR(512) NULL,
        [Source] NVARCHAR(512) NULL,
        [Manual] NVARCHAR(512) NULL,
        [Import] NVARCHAR(512) NULL,
        [Copy] NVARCHAR(512) NULL,
        [PayrollProjection] NVARCHAR(512) NULL,
        [{ tenantId, budgetId, ledgerAccountId, costCenterId, serviceId, month }] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_BudgetLines_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_BudgetLines_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_BudgetLines] PRIMARY KEY ([BudgetLineId]),
        CONSTRAINT [FK_con_BudgetLines_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_BudgetLines_Tenant] ON [con].[BudgetLines] ([TenantId]);
END;
GO
