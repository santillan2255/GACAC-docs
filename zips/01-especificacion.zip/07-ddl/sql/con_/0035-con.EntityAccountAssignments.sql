-- con.EntityAccountAssignments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.EntityAccountAssignments', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[EntityAccountAssignments] (
        [EntityAccountAssignmentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ChartId] UNIQUEIDENTIFIER NOT NULL,
        [EntityType] VARCHAR(64) NOT NULL,
        [EntityId] UNIQUEIDENTIFIER NOT NULL,
        [Usage] VARCHAR(64) NOT NULL,
        [LedgerAccountId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_EntityAccountAssignments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_EntityAccountAssignments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_EntityAccountAssignments] PRIMARY KEY ([EntityAccountAssignmentId]),
        CONSTRAINT [FK_con_EntityAccountAssignments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_EntityAccountAssignments_Tenant] ON [con].[EntityAccountAssignments] ([TenantId]);
END;
GO
