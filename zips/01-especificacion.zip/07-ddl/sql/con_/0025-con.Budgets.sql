-- con.Budgets — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.Budgets', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[Budgets] (
        [BudgetId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [FiscalYearId] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [VersionNumber] NVARCHAR(512) NULL,
        [VersionKind] NVARCHAR(512) NULL,
        [Original] NVARCHAR(512) NULL,
        [Reformulation] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [BaseBudgetId] NVARCHAR(512) NULL,
        [AdjustmentPct] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Submitted] NVARCHAR(512) NULL,
        [Approved] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Closed] NVARCHAR(512) NULL,
        [Superseded] NVARCHAR(512) NULL,
        [ApprovedBy] NVARCHAR(512) NULL,
        [ApprovedAt] DATETIME2(7) NULL,
        [Currency] NVARCHAR(512) NULL,
        [{ tenantId, fiscalYearId, code, versionNumber }] NVARCHAR(512) NULL,
        [ApprovedById] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_Budgets_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_Budgets_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_Budgets] PRIMARY KEY ([BudgetId]),
        CONSTRAINT [FK_con_Budgets_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_Budgets_Tenant] ON [con].[Budgets] ([TenantId]);
END;
GO
