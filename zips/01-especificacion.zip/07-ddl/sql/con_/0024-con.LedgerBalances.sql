-- con.LedgerBalances — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.LedgerBalances', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[LedgerBalances] (
        [LedgerBalanceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ChartId] UNIQUEIDENTIFIER NOT NULL,
        [LedgerAccountId] UNIQUEIDENTIFIER NOT NULL,
        [FiscalYearId] UNIQUEIDENTIFIER NULL,
        [PeriodId] UNIQUEIDENTIFIER NOT NULL,
        [CostCenterId] UNIQUEIDENTIFIER NOT NULL,
        [ServiceId] UNIQUEIDENTIFIER NOT NULL,
        [OpeningDebit] NVARCHAR(MAX) NULL,
        [OpeningCredit] NVARCHAR(MAX) NULL,
        [PeriodDebit] NVARCHAR(512) NULL,
        [PeriodCredit] NVARCHAR(512) NULL,
        [ClosingBalance] DECIMAL(18,4) NULL,
        [RebuiltAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_LedgerBalances_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_LedgerBalances_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_LedgerBalances] PRIMARY KEY ([LedgerBalanceId]),
        CONSTRAINT [FK_con_LedgerBalances_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_LedgerBalances_Tenant] ON [con].[LedgerBalances] ([TenantId]);
END;
GO
