-- con.CostCenterGroups — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.CostCenterGroups', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[CostCenterGroups] (
        [CostCenterGroupId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CTSECCION_GRUPOS] NVARCHAR(512) NULL,
        [ID_GRUPO_CTSECCION] NVARCHAR(512) NULL,
        [DES_GRUPO_CTSECCION] NVARCHAR(512) NULL,
        [CTSECCION_GP_ASIGNA] NVARCHAR(512) NULL,
        [COD_CGA] NVARCHAR(512) NULL,
        [COD_SEC] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [CostCenterIds] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [{ tenantId, code }] NVARCHAR(512) NULL,
        [CostCenterIdsId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_CostCenterGroups_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_CostCenterGroups_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_CostCenterGroups] PRIMARY KEY ([CostCenterGroupId]),
        CONSTRAINT [FK_con_CostCenterGroups_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_CostCenterGroups_Tenant] ON [con].[CostCenterGroups] ([TenantId]);
END;
GO
