-- con.EntryTemplates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.EntryTemplates', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[EntryTemplates] (
        [EntryTemplateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ChartId] UNIQUEIDENTIFIER NOT NULL,
        [Usage] VARCHAR(64) NULL,
        [LinesJson] NVARCHAR(MAX) NULL,
        [Recurrence] BIT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_EntryTemplates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_EntryTemplates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_EntryTemplates] PRIMARY KEY ([EntryTemplateId]),
        CONSTRAINT [FK_con_EntryTemplates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_EntryTemplates_Tenant] ON [con].[EntryTemplates] ([TenantId]);
END;
GO
