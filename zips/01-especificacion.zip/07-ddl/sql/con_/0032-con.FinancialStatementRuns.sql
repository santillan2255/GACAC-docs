-- con.FinancialStatementRuns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.FinancialStatementRuns', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[FinancialStatementRuns] (
        [FinancialStatementRunId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [FiscalYearId] UNIQUEIDENTIFIER NOT NULL,
        [TemplateIdsId] UNIQUEIDENTIFIER NULL,
        [ComparativeFiscalYearId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [SnapshotJson] NVARCHAR(MAX) NULL,
        [StoredFileIdsId] UNIQUEIDENTIFIER NULL,
        [ApprovedById] UNIQUEIDENTIFIER NULL,
        [IssuedAt] DATETIME2(7) NULL,
        [Hash] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_FinancialStatementRuns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_FinancialStatementRuns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_FinancialStatementRuns] PRIMARY KEY ([FinancialStatementRunId]),
        CONSTRAINT [FK_con_FinancialStatementRuns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_FinancialStatementRuns_Tenant] ON [con].[FinancialStatementRuns] ([TenantId]);
END;
GO
