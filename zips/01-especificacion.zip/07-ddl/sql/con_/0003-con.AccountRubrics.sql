-- con.AccountRubrics — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.AccountRubrics', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[AccountRubrics] (
        [AccountRubricId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ChartId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [ParentRubricId] UNIQUEIDENTIFIER NULL,
        [RubricType] VARCHAR(64) NULL,
        [StatementLine] NVARCHAR(512) NULL,
        [CurrentNonCurrent] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountRubrics_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountRubrics_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_AccountRubrics] PRIMARY KEY ([AccountRubricId]),
        CONSTRAINT [FK_con_AccountRubrics_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_AccountRubrics_Tenant] ON [con].[AccountRubrics] ([TenantId]);
END;
GO
