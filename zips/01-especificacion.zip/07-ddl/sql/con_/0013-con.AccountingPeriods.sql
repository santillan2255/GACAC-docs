-- con.AccountingPeriods — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.AccountingPeriods', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[AccountingPeriods] (
        [AccountingPeriodId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [FiscalYearId] UNIQUEIDENTIFIER NOT NULL,
        [Period] NVARCHAR(512) NOT NULL,
        [Sequence] INT NOT NULL,
        [Status] VARCHAR(64) NULL,
        [ModuleLocks] VARCHAR(64) NULL,
        [ChecklistJson] NVARCHAR(MAX) NULL,
        [HistoryJson] NVARCHAR(MAX) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountingPeriods_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountingPeriods_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_AccountingPeriods] PRIMARY KEY ([AccountingPeriodId]),
        CONSTRAINT [FK_con_AccountingPeriods_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_AccountingPeriods_Tenant] ON [con].[AccountingPeriods] ([TenantId]);
END;
GO
