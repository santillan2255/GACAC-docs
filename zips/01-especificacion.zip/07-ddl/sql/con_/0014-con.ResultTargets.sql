-- con.ResultTargets — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.ResultTargets', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[ResultTargets] (
        [ResultTargetId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ChartId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [MatchJson] NVARCHAR(MAX) NULL,
        [LedgerAccountId] UNIQUEIDENTIFIER NOT NULL,
        [AppliesTo] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_ResultTargets_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_ResultTargets_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_ResultTargets] PRIMARY KEY ([ResultTargetId]),
        CONSTRAINT [FK_con_ResultTargets_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_ResultTargets_Tenant] ON [con].[ResultTargets] ([TenantId]);
END;
GO
