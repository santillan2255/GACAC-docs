-- con.StatementTemplates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.StatementTemplates', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[StatementTemplates] (
        [StatementTemplateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [Framework] NVARCHAR(512) NULL,
        [INAES-RT] NVARCHAR(512) NULL,
        [Regulator] NVARCHAR(512) NULL,
        [Custom] NVARCHAR(512) NULL,
        [Statement] NVARCHAR(512) NULL,
        [BalanceSheet] NVARCHAR(512) NULL,
        [IncomeStatement] NVARCHAR(512) NULL,
        [EquityChanges] NVARCHAR(512) NULL,
        [CashFlow] NVARCHAR(512) NULL,
        [Notes] NVARCHAR(512) NULL,
        [AnnexFixedAssets] NVARCHAR(512) NULL,
        [AnnexExpenses] NVARCHAR(512) NULL,
        [ResultsBySection] NVARCHAR(512) NULL,
        [SurplusDistribution] NVARCHAR(512) NULL,
        [Lines] NVARCHAR(512) NULL,
        [Version] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [FinancialStatementRuns] NVARCHAR(512) NULL,
        [FiscalYearId] NVARCHAR(512) NULL,
        [TemplateIds] NVARCHAR(512) NULL,
        [ComparativeFiscalYearId] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [Approved] NVARCHAR(512) NULL,
        [Issued] NVARCHAR(512) NULL,
        [Snapshot] NVARCHAR(512) NULL,
        [StoredFileIds] NVARCHAR(512) NULL,
        [ApprovedBy] NVARCHAR(512) NULL,
        [IssuedAt] DATETIME2(7) NULL,
        [Hash] NVARCHAR(512) NULL,
        [LinesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_StatementTemplates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_StatementTemplates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_StatementTemplates] PRIMARY KEY ([StatementTemplateId]),
        CONSTRAINT [FK_con_StatementTemplates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_StatementTemplates_Tenant] ON [con].[StatementTemplates] ([TenantId]);
END;
GO
