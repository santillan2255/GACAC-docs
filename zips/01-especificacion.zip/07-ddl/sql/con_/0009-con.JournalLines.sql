-- con.JournalLines — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.JournalLines', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[JournalLines] (
        [JournalLineId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [EntryId] UNIQUEIDENTIFIER NOT NULL,
        [LineNo] INT NOT NULL,
        [Memo] NVARCHAR(512) NULL,
        [DimensionsJson] NVARCHAR(MAX) NULL,
        [CostAllocations] DECIMAL(18,4) NULL,
        [ResolutionJson] NVARCHAR(MAX) NULL,
        [SourceEventIds] NVARCHAR(512) NULL,
        [SourceDocumentRefsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_JournalLines_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_JournalLines_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_JournalLines] PRIMARY KEY ([JournalLineId]),
        CONSTRAINT [FK_con_JournalLines_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_JournalLines_Tenant] ON [con].[JournalLines] ([TenantId]);
END;
GO
