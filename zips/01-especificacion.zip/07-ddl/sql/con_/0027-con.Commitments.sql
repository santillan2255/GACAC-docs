-- con.Commitments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.Commitments', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[Commitments] (
        [CommitmentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SourceDocumentJson] NVARCHAR(MAX) NULL,
        [BudgetId] UNIQUEIDENTIFIER NOT NULL,
        [LinesJson] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NULL,
        [ExceedAuthorizationJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_Commitments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_Commitments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_Commitments] PRIMARY KEY ([CommitmentId]),
        CONSTRAINT [FK_con_Commitments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_Commitments_Tenant] ON [con].[Commitments] ([TenantId]);
END;
GO
