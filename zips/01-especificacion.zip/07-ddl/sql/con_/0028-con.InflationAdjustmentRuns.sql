-- con.InflationAdjustmentRuns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.InflationAdjustmentRuns', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[InflationAdjustmentRuns] (
        [InflationAdjustmentRunId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [FiscalYearId] UNIQUEIDENTIFIER NOT NULL,
        [PeriodTo] DATETIME2(7) NULL,
        [SeriesId] UNIQUEIDENTIFIER NULL,
        [Version] INT NOT NULL,
        [Method] VARCHAR(64) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LinesJson] NVARCHAR(MAX) NULL,
        [RecpamTotal] DECIMAL(18,4) NULL,
        [EntryId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_InflationAdjustmentRuns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_InflationAdjustmentRuns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_InflationAdjustmentRuns] PRIMARY KEY ([InflationAdjustmentRunId]),
        CONSTRAINT [FK_con_InflationAdjustmentRuns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_InflationAdjustmentRuns_Tenant] ON [con].[InflationAdjustmentRuns] ([TenantId]);
END;
GO
