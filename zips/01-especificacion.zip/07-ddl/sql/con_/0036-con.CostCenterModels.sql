-- con.CostCenterModels — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.CostCenterModels', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[CostCenterModels] (
        [CostCenterModelId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [SplitsJson] NVARCHAR(MAX) NULL,
        [DistributionModelId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Version] INT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_CostCenterModels_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_CostCenterModels_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_CostCenterModels] PRIMARY KEY ([CostCenterModelId]),
        CONSTRAINT [FK_con_CostCenterModels_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_CostCenterModels_Tenant] ON [con].[CostCenterModels] ([TenantId]);
END;
GO
