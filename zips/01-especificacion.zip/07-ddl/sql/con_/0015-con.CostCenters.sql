-- con.CostCenters — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.CostCenters', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[CostCenters] (
        [CostCenterId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ParentId] UNIQUEIDENTIFIER NULL,
        [Kind] VARCHAR(64) NULL,
        [VatCreditablePct] DECIMAL(18,4) NOT NULL,
        [GroupIdsId] UNIQUEIDENTIFIER NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [SharedWithLegalEntityIdsId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_CostCenters_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_CostCenters_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_CostCenters] PRIMARY KEY ([CostCenterId]),
        CONSTRAINT [FK_con_CostCenters_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_CostCenters_Tenant] ON [con].[CostCenters] ([TenantId]);
END;
GO
