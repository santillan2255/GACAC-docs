-- con.PostingBatches — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.PostingBatches', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[PostingBatches] (
        [PostingBatcheId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] INT NOT NULL,
        [Modules] VARCHAR(64) NULL,
        [OptionsId] UNIQUEIDENTIFIER NOT NULL,
        [Status] VARCHAR(64) NULL,
        [ProgressJson] NVARCHAR(MAX) NOT NULL,
        [WarningsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_PostingBatches_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_PostingBatches_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_PostingBatches] PRIMARY KEY ([PostingBatcheId]),
        CONSTRAINT [FK_con_PostingBatches_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_PostingBatches_Tenant] ON [con].[PostingBatches] ([TenantId]);
END;
GO
