-- con.AccountingSettings — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.AccountingSettings', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[AccountingSettings] (
        [AccountingSettingId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [OperativeChartByFiscalYearJson] NVARCHAR(MAX) NOT NULL,
        [FunctionalCurrency] NVARCHAR(512) NOT NULL,
        [EntryNumberFormatJson] NVARCHAR(MAX) NOT NULL,
        [CostCenters] BIT NOT NULL,
        [Rounding] DECIMAL(18,4) NOT NULL,
        [PostingModes] VARCHAR(64) NULL,
        [ReceivableGrouping] VARCHAR(64) NULL,
        [UseCollectionAccountingGroups] BIT NOT NULL,
        [SplitRefinancingDebtorsByType] BIT NOT NULL,
        [UnpostablePolicy] VARCHAR(64) NULL,
        [CashPostingTrigger] VARCHAR(64) NOT NULL,
        [VoidPolicy] VARCHAR(64) NULL,
        [ManualEntryApproval] DECIMAL(18,4) NULL,
        [PeriodCloseChecklistJson] NVARCHAR(MAX) NOT NULL,
        [ClosingJson] NVARCHAR(MAX) NOT NULL,
        [InflationJson] NVARCHAR(MAX) NULL,
        [BudgetControlJson] NVARCHAR(MAX) NULL,
        [ExternalLedgerJson] NVARCHAR(MAX) NULL,
        [LateEventPolicy] VARCHAR(64) NOT NULL,
        [FxRevaluationJson] NVARCHAR(MAX) NOT NULL,
        [PublicationPolicyOnMissingRule] VARCHAR(64) NOT NULL,
        [SuspenseTolerance] DECIMAL(18,4) NOT NULL,
        [HealthCheckSchedule] NVARCHAR(512) NOT NULL,
        [ConfigVersionId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountingSettings_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountingSettings_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_AccountingSettings] PRIMARY KEY ([AccountingSettingId]),
        CONSTRAINT [FK_con_AccountingSettings_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_AccountingSettings_Tenant] ON [con].[AccountingSettings] ([TenantId]);
END;
GO
