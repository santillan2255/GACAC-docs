-- con.AccountMappings — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.AccountMappings', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[AccountMappings] (
        [AccountMappingId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SourceAccountId] UNIQUEIDENTIFIER NOT NULL,
        [TargetsJson] NVARCHAR(MAX) NOT NULL,
        [ConditionsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountMappings_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountMappings_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_AccountMappings] PRIMARY KEY ([AccountMappingId]),
        CONSTRAINT [FK_con_AccountMappings_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_AccountMappings_Tenant] ON [con].[AccountMappings] ([TenantId]);
END;
GO
