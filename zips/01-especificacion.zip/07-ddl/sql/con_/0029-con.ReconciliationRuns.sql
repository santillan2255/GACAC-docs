-- con.ReconciliationRuns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.ReconciliationRuns', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[ReconciliationRuns] (
        [ReconciliationRunId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [FiscalYearId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NULL,
        [CutoffAt] DATETIME2(7) NOT NULL,
        [DimensionBreakdown] VARCHAR(64) NULL,
        [DifferencesJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_ReconciliationRuns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_ReconciliationRuns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_ReconciliationRuns] PRIMARY KEY ([ReconciliationRunId]),
        CONSTRAINT [FK_con_ReconciliationRuns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_ReconciliationRuns_Tenant] ON [con].[ReconciliationRuns] ([TenantId]);
END;
GO
