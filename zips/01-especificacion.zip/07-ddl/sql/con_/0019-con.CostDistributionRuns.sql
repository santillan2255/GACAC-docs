-- con.CostDistributionRuns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.CostDistributionRuns', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[CostDistributionRuns] (
        [CostDistributionRunId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] INT NOT NULL,
        [DistributionModelId] UNIQUEIDENTIFIER NULL,
        [Scope] VARCHAR(64) NOT NULL,
        [ScenarioId] UNIQUEIDENTIFIER NULL,
        [RulesJson] NVARCHAR(MAX) NOT NULL,
        [ResultsJson] NVARCHAR(MAX) NOT NULL,
        [UnallocatedJson] NVARCHAR(MAX) NULL,
        [TotalsJson] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NULL,
        [ReclassificationEntryId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_CostDistributionRuns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_CostDistributionRuns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_CostDistributionRuns] PRIMARY KEY ([CostDistributionRunId]),
        CONSTRAINT [FK_con_CostDistributionRuns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_CostDistributionRuns_Tenant] ON [con].[CostDistributionRuns] ([TenantId]);
END;
GO
