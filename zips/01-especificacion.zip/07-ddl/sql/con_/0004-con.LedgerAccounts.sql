-- con.LedgerAccounts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.LedgerAccounts', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[LedgerAccounts] (
        [LedgerAccountId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ChartId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [CodeHistoryJson] NVARCHAR(MAX) NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [ParentId] UNIQUEIDENTIFIER NULL,
        [PathId] UNIQUEIDENTIFIER NOT NULL,
        [Level] INT NOT NULL,
        [Postable] BIT NOT NULL,
        [Nature] VARCHAR(64) NULL,
        [NormalBalance] VARCHAR(64) NOT NULL,
        [InflationAdjustable] BIT NOT NULL,
        [Monetary] BIT NOT NULL,
        [Currency] NVARCHAR(512) NOT NULL,
        [CostCenterPolicy] VARCHAR(64) NULL,
        [AllowedCostCenterIdsId] UNIQUEIDENTIFIER NULL,
        [DefaultAllocationJson] NVARCHAR(MAX) NULL,
        [RequiredDimensions] VARCHAR(64) NULL,
        [ControlAccountOf] VARCHAR(64) NULL,
        [SubaccountCode] NVARCHAR(512) NULL,
        [CheckDigit] NVARCHAR(512) NULL,
        [StatementLinesJson] NVARCHAR(MAX) NULL,
        [InaesCategoryId] UNIQUEIDENTIFIER NULL,
        [MergedIntoAccountId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_LedgerAccounts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_LedgerAccounts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_LedgerAccounts] PRIMARY KEY ([LedgerAccountId]),
        CONSTRAINT [FK_con_LedgerAccounts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_LedgerAccounts_Tenant] ON [con].[LedgerAccounts] ([TenantId]);
END;
GO
