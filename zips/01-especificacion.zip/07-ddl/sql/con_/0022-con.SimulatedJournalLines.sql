-- con.SimulatedJournalLines — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.SimulatedJournalLines', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[SimulatedJournalLines] (
        [SimulatedJournalLineId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [EntryId] UNIQUEIDENTIFIER NOT NULL,
        [LineNo] INT NOT NULL,
        [Memo] NVARCHAR(512) NULL,
        [DimensionsJson] NVARCHAR(MAX) NULL,
        [CostAllocations] DECIMAL(18,4) NULL,
        [ResolutionJson] NVARCHAR(MAX) NULL,
        [SourceEventIds] NVARCHAR(512) NULL,
        [SourceDocumentRefsJson] NVARCHAR(MAX) NULL,
        [ScenarioId] UNIQUEIDENTIFIER NOT NULL,
        [SimulatedEntryKey] NVARCHAR(512) NULL,
        [OriginRealLineId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_SimulatedJournalLines_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_SimulatedJournalLines_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_SimulatedJournalLines] PRIMARY KEY ([SimulatedJournalLineId]),
        CONSTRAINT [FK_con_SimulatedJournalLines_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_SimulatedJournalLines_Tenant] ON [con].[SimulatedJournalLines] ([TenantId]);
END;
GO
