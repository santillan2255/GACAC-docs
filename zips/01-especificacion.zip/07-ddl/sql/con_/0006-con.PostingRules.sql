-- con.PostingRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.PostingRules', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[PostingRules] (
        [PostingRuleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ChartId] UNIQUEIDENTIFIER NOT NULL,
        [EventType] NVARCHAR(512) NOT NULL,
        [AmountRole] NVARCHAR(512) NOT NULL,
        [Side] VARCHAR(64) NULL,
        [ConditionsJson] NVARCHAR(MAX) NOT NULL,
        [LedgerAccountId] UNIQUEIDENTIFIER NOT NULL,
        [Priority] INT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [RuleVersion] INT NOT NULL,
        [LegacySourceJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_PostingRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_PostingRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_PostingRules] PRIMARY KEY ([PostingRuleId]),
        CONSTRAINT [FK_con_PostingRules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_PostingRules_Tenant] ON [con].[PostingRules] ([TenantId]);
END;
GO
