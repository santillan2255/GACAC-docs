-- con.JournalEntries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.JournalEntries', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[JournalEntries] (
        [JournalEntryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [InternalNumber] NVARCHAR(MAX) NOT NULL,
        [EntryNumber] INT NOT NULL,
        [EntryDate] DATETIME2(7) NOT NULL,
        [RecordedAt] DATETIME2(7) NOT NULL,
        [Description] NVARCHAR(512) NOT NULL,
        [Type] VARCHAR(64) NULL,
        [SourceType] VARCHAR(64) NULL,
        [Status] VARCHAR(64) NULL,
        [SourceEventIds] NVARCHAR(512) NULL,
        [SourceDocumentsJson] NVARCHAR(MAX) NULL,
        [PostingBatchId] UNIQUEIDENTIFIER NULL,
        [TemplateId] UNIQUEIDENTIFIER NULL,
        [AutoReverseOn] DATETIME2(7) NULL,
        [OriginalAccountingDate] DATETIME2(7) NULL,
        [ApprovalRequestId] UNIQUEIDENTIFIER NULL,
        [AttachmentsId] UNIQUEIDENTIFIER NULL,
        [RubricatedBookId] UNIQUEIDENTIFIER NULL,
        [Folio] INT NULL,
        [VoidReason] NVARCHAR(512) NULL,
        [ConfigVersionId] UNIQUEIDENTIFIER NOT NULL,
        [ExportedJson] NVARCHAR(MAX) NULL,
        [ImportSourceJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_JournalEntries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_JournalEntries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_JournalEntries] PRIMARY KEY ([JournalEntryId]),
        CONSTRAINT [FK_con_JournalEntries_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_JournalEntries_Tenant] ON [con].[JournalEntries] ([TenantId]);
END;
GO
