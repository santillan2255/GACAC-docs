-- con.AccountRoles — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.AccountRoles', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[AccountRoles] (
        [AccountRoleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ChartId] UNIQUEIDENTIFIER NOT NULL,
        [RoleKey] NVARCHAR(512) NOT NULL,
        [LedgerAccountId] UNIQUEIDENTIFIER NULL,
        [CostCenterModelId] UNIQUEIDENTIFIER NULL,
        [Overrides] VARCHAR(64) NULL,
        [LegacyVariable] INT NULL,
        [PrmId] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountRoles_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_AccountRoles_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_AccountRoles] PRIMARY KEY ([AccountRoleId]),
        CONSTRAINT [FK_con_AccountRoles_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_AccountRoles_Tenant] ON [con].[AccountRoles] ([TenantId]);
END;
GO
