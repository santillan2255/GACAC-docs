-- con.SimulationScenarios — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'con.SimulationScenarios', N'U') IS NULL
BEGIN
    CREATE TABLE [con].[SimulationScenarios] (
        [SimulationScenarioId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NULL,
        [ChartId] UNIQUEIDENTIFIER NOT NULL,
        [BaseScenarioId] UNIQUEIDENTIFIER NULL,
        [UniverseJson] NVARCHAR(MAX) NOT NULL,
        [AssumptionsJson] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NULL,
        [Comparable] BIT NOT NULL,
        [ChecksJson] NVARCHAR(MAX) NULL,
        [ResultsJson] NVARCHAR(MAX) NULL,
        [RunHash] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_SimulationScenarios_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_con_SimulationScenarios_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_con_SimulationScenarios] PRIMARY KEY ([SimulationScenarioId]),
        CONSTRAINT [FK_con_SimulationScenarios_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_con_SimulationScenarios_Tenant] ON [con].[SimulationScenarios] ([TenantId]);
END;
GO
