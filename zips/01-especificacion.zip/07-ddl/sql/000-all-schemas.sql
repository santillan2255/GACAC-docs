-- Esquemas de módulo

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'bia')
    EXEC(N'CREATE SCHEMA [bia] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'cat')
    EXEC(N'CREATE SCHEMA [cat] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'cfg')
    EXEC(N'CREATE SCHEMA [cfg] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'cmp')
    EXEC(N'CREATE SCHEMA [cmp] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'cob')
    EXEC(N'CREATE SCHEMA [cob] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'com')
    EXEC(N'CREATE SCHEMA [com] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'con')
    EXEC(N'CREATE SCHEMA [con] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'crm')
    EXEC(N'CREATE SCHEMA [crm] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'fac')
    EXEC(N'CREATE SCHEMA [fac] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'fis')
    EXEC(N'CREATE SCHEMA [fis] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'iam')
    EXEC(N'CREATE SCHEMA [iam] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'ins')
    EXEC(N'CREATE SCHEMA [ins] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'int')
    EXEC(N'CREATE SCHEMA [int] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'med')
    EXEC(N'CREATE SCHEMA [med] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'mig')
    EXEC(N'CREATE SCHEMA [mig] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'mor')
    EXEC(N'CREATE SCHEMA [mor] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'nfr')
    EXEC(N'CREATE SCHEMA [nfr] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'per')
    EXEC(N'CREATE SCHEMA [per] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'pla')
    EXEC(N'CREATE SCHEMA [pla] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'por')
    EXEC(N'CREATE SCHEMA [por] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'soc')
    EXEC(N'CREATE SCHEMA [soc] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'stk')
    EXEC(N'CREATE SCHEMA [stk] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'sue')
    EXEC(N'CREATE SCHEMA [sue] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'tar')
    EXEC(N'CREATE SCHEMA [tar] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'tec')
    EXEC(N'CREATE SCHEMA [tec] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'tes')
    EXEC(N'CREATE SCHEMA [tes] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'uxd')
    EXEC(N'CREATE SCHEMA [uxd] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'ven')
    EXEC(N'CREATE SCHEMA [ven] AUTHORIZATION [dbo];');
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'wfl')
    EXEC(N'CREATE SCHEMA [wfl] AUTHORIZATION [dbo];');
GO
