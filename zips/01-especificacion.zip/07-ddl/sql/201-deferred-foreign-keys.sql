-- FK diferidas (completo, orden topológico) — 2026-11-19
-- Después de 200-all-unique-indexes.sql
-- Bloque 1: T05 | Bloque 2: anexos §7 Referencia
-- Ciclos: WITH NOCHECK (ver FK-CYCLES.md)

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_CustomReports_DatasetId_AnalyticsDatasets'
)
BEGIN
    ALTER TABLE [bia].[CustomReports]
        ADD CONSTRAINT [FK_bia_CustomReports_DatasetId_AnalyticsDatasets]
        FOREIGN KEY ([DatasetId]) REFERENCES [bia].[AnalyticsDatasets] ([AnalyticsDatasetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_DashboardUserPrefs_DashboardId_Dashboards'
)
BEGIN
    ALTER TABLE [bia].[DashboardUserPrefs]
        ADD CONSTRAINT [FK_bia_DashboardUserPrefs_DashboardId_Dashboards]
        FOREIGN KEY ([DashboardId]) REFERENCES [bia].[Dashboards] ([DashboardId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportExports_LayoutId_ExportLayouts'
)
BEGIN
    ALTER TABLE [bia].[ReportExports]
        ADD CONSTRAINT [FK_bia_ReportExports_LayoutId_ExportLayouts]
        FOREIGN KEY ([LayoutId]) REFERENCES [bia].[ExportLayouts] ([ExportLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_KpiAlertRules_IndicatorId_IndicatorDefinitions'
)
BEGIN
    ALTER TABLE [bia].[KpiAlertRules]
        ADD CONSTRAINT [FK_bia_KpiAlertRules_IndicatorId_IndicatorDefinitions]
        FOREIGN KEY ([IndicatorId]) REFERENCES [bia].[IndicatorDefinitions] ([IndicatorDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_IndicatorSnapshots_IndicatorId_IndicatorDefinitions'
)
BEGIN
    ALTER TABLE [bia].[IndicatorSnapshots]
        ADD CONSTRAINT [FK_bia_IndicatorSnapshots_IndicatorId_IndicatorDefinitions]
        FOREIGN KEY ([IndicatorId]) REFERENCES [bia].[IndicatorDefinitions] ([IndicatorDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_KpiAlerts_KpiAlertRuleId_KpiAlertRules'
)
BEGIN
    ALTER TABLE [bia].[KpiAlerts]
        ADD CONSTRAINT [FK_bia_KpiAlerts_KpiAlertRuleId_KpiAlertRules]
        FOREIGN KEY ([KpiAlertRuleId]) REFERENCES [bia].[KpiAlertRules] ([KpiAlertRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportAccessLogs_ReportDefinitionId_ReportDefinitions'
)
BEGIN
    ALTER TABLE [bia].[ReportAccessLogs]
        ADD CONSTRAINT [FK_bia_ReportAccessLogs_ReportDefinitionId_ReportDefinitions]
        FOREIGN KEY ([ReportDefinitionId]) REFERENCES [bia].[ReportDefinitions] ([ReportDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportSchedules_ReportDefinitionId_ReportDefinitions'
)
BEGIN
    ALTER TABLE [bia].[ReportSchedules]
        ADD CONSTRAINT [FK_bia_ReportSchedules_ReportDefinitionId_ReportDefinitions]
        FOREIGN KEY ([ReportDefinitionId]) REFERENCES [bia].[ReportDefinitions] ([ReportDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportSchedules_PresetId_ReportPresets'
)
BEGIN
    ALTER TABLE [bia].[ReportSchedules]
        ADD CONSTRAINT [FK_bia_ReportSchedules_PresetId_ReportPresets]
        FOREIGN KEY ([PresetId]) REFERENCES [bia].[ReportPresets] ([ReportPresetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportRunResults_ReportRunId_ReportRuns'
)
BEGIN
    ALTER TABLE [bia].[ReportRunResults]
        ADD CONSTRAINT [FK_bia_ReportRunResults_ReportRunId_ReportRuns]
        FOREIGN KEY ([ReportRunId]) REFERENCES [bia].[ReportRuns] ([ReportRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportAccessLogs_RunId_ReportRuns'
)
BEGIN
    ALTER TABLE [bia].[ReportAccessLogs]
        ADD CONSTRAINT [FK_bia_ReportAccessLogs_RunId_ReportRuns]
        FOREIGN KEY ([RunId]) REFERENCES [bia].[ReportRuns] ([ReportRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportExports_ReportRunId_ReportRuns'
)
BEGIN
    ALTER TABLE [bia].[ReportExports]
        ADD CONSTRAINT [FK_bia_ReportExports_ReportRunId_ReportRuns]
        FOREIGN KEY ([ReportRunId]) REFERENCES [bia].[ReportRuns] ([ReportRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportDeliveries_RunId_ReportRuns'
)
BEGIN
    ALTER TABLE [bia].[ReportDeliveries]
        ADD CONSTRAINT [FK_bia_ReportDeliveries_RunId_ReportRuns]
        FOREIGN KEY ([RunId]) REFERENCES [bia].[ReportRuns] ([ReportRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportSchedules_LastRunId_ReportRuns'
)
BEGIN
    ALTER TABLE [bia].[ReportSchedules]
        ADD CONSTRAINT [FK_bia_ReportSchedules_LastRunId_ReportRuns]
        FOREIGN KEY ([LastRunId]) REFERENCES [bia].[ReportRuns] ([ReportRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusDistributions_ResultRefId_ReportRunResults'
)
BEGIN
    ALTER TABLE [ins].[SurplusDistributions]
        ADD CONSTRAINT [FK_ins_SurplusDistributions_ResultRefId_ReportRunResults]
        FOREIGN KEY ([ResultRefId]) REFERENCES [bia].[ReportRunResults] ([ReportRunResultId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceTemplates_CapabilityId_ServiceCapabilities'
)
BEGIN
    ALTER TABLE [cat].[ServiceTemplates]
        ADD CONSTRAINT [FK_cat_ServiceTemplates_CapabilityId_ServiceCapabilities]
        FOREIGN KEY ([CapabilityId]) REFERENCES [cat].[ServiceCapabilities] ([ServiceCapabilityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_TenantServices_CapabilityId_ServiceCapabilities'
)
BEGIN
    ALTER TABLE [cat].[TenantServices]
        ADD CONSTRAINT [FK_cat_TenantServices_CapabilityId_ServiceCapabilities]
        FOREIGN KEY ([CapabilityId]) REFERENCES [cat].[ServiceCapabilities] ([ServiceCapabilityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_plan_PlanVersionId_ServicePlanVersions'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_plan]
        ADD CONSTRAINT [FK_bia_Bi_dim_plan_PlanVersionId_ServicePlanVersions]
        FOREIGN KEY ([PlanVersionId]) REFERENCES [cat].[ServicePlanVersions] ([ServicePlanVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceBundles_PlanVersionIdsId_ServicePlanVersions'
)
BEGIN
    ALTER TABLE [cat].[ServiceBundles]
        ADD CONSTRAINT [FK_cat_ServiceBundles_PlanVersionIdsId_ServicePlanVersions]
        FOREIGN KEY ([PlanVersionIdsId]) REFERENCES [cat].[ServicePlanVersions] ([ServicePlanVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServicePlans_CurrentVersionId_ServicePlanVersions'
)
BEGIN
    ALTER TABLE [cat].[ServicePlans]
        ADD CONSTRAINT [FK_cat_ServicePlans_CurrentVersionId_ServicePlanVersions]
        FOREIGN KEY ([CurrentVersionId]) REFERENCES [cat].[ServicePlanVersions] ([ServicePlanVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BundleSubscriptions_BundleId_ServiceBundles'
)
BEGIN
    ALTER TABLE [cat].[BundleSubscriptions]
        ADD CONSTRAINT [FK_cat_BundleSubscriptions_BundleId_ServiceBundles]
        FOREIGN KEY ([BundleId]) REFERENCES [cat].[ServiceBundles] ([ServiceBundleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_product_ServiceProductId_ServiceProducts'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_product]
        ADD CONSTRAINT [FK_bia_Bi_dim_product_ServiceProductId_ServiceProducts]
        FOREIGN KEY ([ServiceProductId]) REFERENCES [cat].[ServiceProducts] ([ServiceProductId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServicePlans_ServiceProductId_ServiceProducts'
)
BEGIN
    ALTER TABLE [cat].[ServicePlans]
        ADD CONSTRAINT [FK_cat_ServicePlans_ServiceProductId_ServiceProducts]
        FOREIGN KEY ([ServiceProductId]) REFERENCES [cat].[ServiceProducts] ([ServiceProductId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionReportSchemes_ProductIdsId_ServiceProducts'
)
BEGIN
    ALTER TABLE [cob].[CollectionReportSchemes]
        ADD CONSTRAINT [FK_cob_CollectionReportSchemes_ProductIdsId_ServiceProducts]
        FOREIGN KEY ([ProductIdsId]) REFERENCES [cat].[ServiceProducts] ([ServiceProductId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_ProductPrices_ServiceProductId_ServiceProducts'
)
BEGIN
    ALTER TABLE [tar].[ProductPrices]
        ADD CONSTRAINT [FK_tar_ProductPrices_ServiceProductId_ServiceProducts]
        FOREIGN KEY ([ServiceProductId]) REFERENCES [cat].[ServiceProducts] ([ServiceProductId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesDiscountRules_BonusProductId_ServiceProducts'
)
BEGIN
    ALTER TABLE [ven].[SalesDiscountRules]
        ADD CONSTRAINT [FK_ven_SalesDiscountRules_BonusProductId_ServiceProducts]
        FOREIGN KEY ([BonusProductId]) REFERENCES [cat].[ServiceProducts] ([ServiceProductId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesDiscountRules_ProductId_ServiceProducts'
)
BEGIN
    ALTER TABLE [ven].[SalesDiscountRules]
        ADD CONSTRAINT [FK_ven_SalesDiscountRules_ProductId_ServiceProducts]
        FOREIGN KEY ([ProductId]) REFERENCES [cat].[ServiceProducts] ([ServiceProductId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyBillers_ProductId_ServiceProducts'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyBillers]
        ADD CONSTRAINT [FK_cob_ThirdPartyBillers_ProductId_ServiceProducts]
        FOREIGN KEY ([ProductId]) REFERENCES [cat].[ServiceProducts] ([ServiceProductId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CardPlans_SurchargeProductId_ServiceProducts'
)
BEGIN
    ALTER TABLE [cob].[CardPlans]
        ADD CONSTRAINT [FK_cob_CardPlans_SurchargeProductId_ServiceProducts]
        FOREIGN KEY ([SurchargeProductId]) REFERENCES [cat].[ServiceProducts] ([ServiceProductId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_OperationalStatusId_ServiceStatuses'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts]
        ADD CONSTRAINT [FK_cat_ServiceContracts_OperationalStatusId_ServiceStatuses]
        FOREIGN KEY ([OperationalStatusId]) REFERENCES [cat].[ServiceStatuses] ([ServiceStatusId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_ResultingServiceStatusId_ServiceStatuses'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes]
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_ResultingServiceStatusId_ServiceStatuses]
        FOREIGN KEY ([ResultingServiceStatusId]) REFERENCES [cat].[ServiceStatuses] ([ServiceStatusId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Holidays_CalendarId_Calendars'
)
BEGIN
    ALTER TABLE [cfg].[Holidays]
        ADD CONSTRAINT [FK_cfg_Holidays_CalendarId_Calendars]
        FOREIGN KEY ([CalendarId]) REFERENCES [cfg].[Calendars] ([CalendarId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_FormCustomizations_ConfigVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [cfg].[FormCustomizations]
        ADD CONSTRAINT [FK_cfg_FormCustomizations_ConfigVersionId_ConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountingSettings_ConfigVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [con].[AccountingSettings]
        ADD CONSTRAINT [FK_con_AccountingSettings_ConfigVersionId_ConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestPolicies_PublishedVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [mor].[InterestPolicies]
        ADD CONSTRAINT [FK_mor_InterestPolicies_PublishedVersionId_ConfigVersions]
        FOREIGN KEY ([PublishedVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollConcepts_ConfigVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [sue].[PayrollConcepts]
        ADD CONSTRAINT [FK_sue_PayrollConcepts_ConfigVersionId_ConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_MasterImportJobs_ConfigVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [cfg].[MasterImportJobs]
        ADD CONSTRAINT [FK_cfg_MasterImportJobs_ConfigVersionId_ConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_SeedApplications_ConfigVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [cfg].[SeedApplications]
        ADD CONSTRAINT [FK_cfg_SeedApplications_ConfigVersionId_ConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalEntries_ConfigVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [con].[JournalEntries]
        ADD CONSTRAINT [FK_con_JournalEntries_ConfigVersionId_ConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollRuns_ConfigVersionId_ConfigVersions'
)
BEGIN
    ALTER TABLE [sue].[PayrollRuns]
        ADD CONSTRAINT [FK_sue_PayrollRuns_ConfigVersionId_ConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [cfg].[ConfigVersions] ([ConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Provinces_CountryId_Countries'
)
BEGIN
    ALTER TABLE [cfg].[Provinces]
        ADD CONSTRAINT [FK_cfg_Provinces_CountryId_Countries]
        FOREIGN KEY ([CountryId]) REFERENCES [cfg].[Countries] ([CountryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_EconomicIndexValues_SeriesId_EconomicIndexSeries'
)
BEGIN
    ALTER TABLE [cfg].[EconomicIndexValues]
        ADD CONSTRAINT [FK_cfg_EconomicIndexValues_SeriesId_EconomicIndexSeries]
        FOREIGN KEY ([SeriesId]) REFERENCES [cfg].[EconomicIndexSeries] ([EconomicIndexSeryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_PlatformTableAdoptions_SeriesId_EconomicIndexSeries'
)
BEGIN
    ALTER TABLE [cfg].[PlatformTableAdoptions]
        ADD CONSTRAINT [FK_cfg_PlatformTableAdoptions_SeriesId_EconomicIndexSeries]
        FOREIGN KEY ([SeriesId]) REFERENCES [cfg].[EconomicIndexSeries] ([EconomicIndexSeryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_InflationAdjustmentRuns_SeriesId_EconomicIndexSeries'
)
BEGIN
    ALTER TABLE [con].[InflationAdjustmentRuns]
        ADD CONSTRAINT [FK_con_InflationAdjustmentRuns_SeriesId_EconomicIndexSeries]
        FOREIGN KEY ([SeriesId]) REFERENCES [cfg].[EconomicIndexSeries] ([EconomicIndexSeryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_PlatformTableReleases_SeriesId_EconomicIndexSeries'
)
BEGIN
    ALTER TABLE [cfg].[PlatformTableReleases]
        ADD CONSTRAINT [FK_cfg_PlatformTableReleases_SeriesId_EconomicIndexSeries]
        FOREIGN KEY ([SeriesId]) REFERENCES [cfg].[EconomicIndexSeries] ([EconomicIndexSeryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_EnumerationItems_EnumerationId_Enumerations'
)
BEGIN
    ALTER TABLE [cfg].[EnumerationItems]
        ADD CONSTRAINT [FK_cfg_EnumerationItems_EnumerationId_Enumerations]
        FOREIGN KEY ([EnumerationId]) REFERENCES [cfg].[Enumerations] ([EnumerationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceConcessions_AuthorityIdsId_EnumerationItems'
)
BEGIN
    ALTER TABLE [cat].[ServiceConcessions]
        ADD CONSTRAINT [FK_cat_ServiceConcessions_AuthorityIdsId_EnumerationItems]
        FOREIGN KEY ([AuthorityIdsId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Notes_NoteTypeId_EnumerationItems'
)
BEGIN
    ALTER TABLE [per].[Notes]
        ADD CONSTRAINT [FK_per_Notes_NoteTypeId_EnumerationItems]
        FOREIGN KEY ([NoteTypeId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Persons_MaritalStatusId_EnumerationItems'
)
BEGIN
    ALTER TABLE [per].[Persons]
        ADD CONSTRAINT [FK_per_Persons_MaritalStatusId_EnumerationItems]
        FOREIGN KEY ([MaritalStatusId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Persons_OccupationId_EnumerationItems'
)
BEGIN
    ALTER TABLE [per].[Persons]
        ADD CONSTRAINT [FK_per_Persons_OccupationId_EnumerationItems]
        FOREIGN KEY ([OccupationId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Holders_CloseReasonId_EnumerationItems'
)
BEGIN
    ALTER TABLE [per].[Holders]
        ADD CONSTRAINT [FK_per_Holders_CloseReasonId_EnumerationItems]
        FOREIGN KEY ([CloseReasonId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Premises_StateId_EnumerationItems'
)
BEGIN
    ALTER TABLE [per].[Premises]
        ADD CONSTRAINT [FK_per_Premises_StateId_EnumerationItems]
        FOREIGN KEY ([StateId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Premises_UsageId_EnumerationItems'
)
BEGIN
    ALTER TABLE [per].[Premises]
        ADD CONSTRAINT [FK_per_Premises_UsageId_EnumerationItems]
        FOREIGN KEY ([UsageId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Relationships_RelationshipTypeId_EnumerationItems'
)
BEGIN
    ALTER TABLE [per].[Relationships]
        ADD CONSTRAINT [FK_per_Relationships_RelationshipTypeId_EnumerationItems]
        FOREIGN KEY ([RelationshipTypeId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceDependents_RelationshipTypeId_EnumerationItems'
)
BEGIN
    ALTER TABLE [soc].[ServiceDependents]
        ADD CONSTRAINT [FK_soc_ServiceDependents_RelationshipTypeId_EnumerationItems]
        FOREIGN KEY ([RelationshipTypeId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_AdherentRates_OccupationTypeId_EnumerationItems'
)
BEGIN
    ALTER TABLE [tar].[AdherentRates]
        ADD CONSTRAINT [FK_tar_AdherentRates_OccupationTypeId_EnumerationItems]
        FOREIGN KEY ([OccupationTypeId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_AdherentRates_RelationshipTypeId_EnumerationItems'
)
BEGIN
    ALTER TABLE [tar].[AdherentRates]
        ADD CONSTRAINT [FK_tar_AdherentRates_RelationshipTypeId_EnumerationItems]
        FOREIGN KEY ([RelationshipTypeId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceBeneficiaries_RelationshipTypeId_EnumerationItems'
)
BEGIN
    ALTER TABLE [soc].[ServiceBeneficiaries]
        ADD CONSTRAINT [FK_soc_ServiceBeneficiaries_RelationshipTypeId_EnumerationItems]
        FOREIGN KEY ([RelationshipTypeId]) REFERENCES [cfg].[EnumerationItems] ([EnumerationItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_PersonIdentifierIndex_DocumentTypeId_IdentityDocumentTypes'
)
BEGIN
    ALTER TABLE [per].[PersonIdentifierIndex]
        ADD CONSTRAINT [FK_per_PersonIdentifierIndex_DocumentTypeId_IdentityDocumentTypes]
        FOREIGN KEY ([DocumentTypeId]) REFERENCES [cfg].[IdentityDocumentTypes] ([IdentityDocumentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Branches_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [cfg].[Branches]
        ADD CONSTRAINT [FK_cfg_Branches_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PaymentOrders_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [cmp].[PaymentOrders]
        ADD CONSTRAINT [FK_cmp_PaymentOrders_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_FiscalYears_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [con].[FiscalYears]
        ADD CONSTRAINT [FK_con_FiscalYears_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountingPeriods_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [con].[AccountingPeriods]
        ADD CONSTRAINT [FK_con_AccountingPeriods_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDrafts_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDrafts]
        ADD CONSTRAINT [FK_fac_InvoiceDrafts_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_TenantServices_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [cat].[TenantServices]
        ADD CONSTRAINT [FK_cat_TenantServices_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_Invoices_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fac].[Invoices]
        ADD CONSTRAINT [FK_fac_Invoices_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_CaeaPeriods_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[CaeaPeriods]
        ADD CONSTRAINT [FK_fis_CaeaPeriods_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_FiscalSurveys_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[FiscalSurveys]
        ADD CONSTRAINT [FK_fis_FiscalSurveys_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_PointsOfSale_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[PointsOfSale]
        ADD CONSTRAINT [FK_fis_PointsOfSale_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_NumberSequences_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fac].[NumberSequences]
        ADD CONSTRAINT [FK_fac_NumberSequences_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_CespAuthorizations_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[CespAuthorizations]
        ADD CONSTRAINT [FK_fis_CespAuthorizations_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_RegimeFilings_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[RegimeFilings]
        ADD CONSTRAINT [FK_fis_RegimeFilings_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxAgentRegistrations_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[TaxAgentRegistrations]
        ADD CONSTRAINT [FK_fis_TaxAgentRegistrations_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatLedgers_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[VatLedgers]
        ADD CONSTRAINT [FK_fis_VatLedgers_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditLogs_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [iam].[AuditLogs]
        ADD CONSTRAINT [FK_iam_AuditLogs_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditReads_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [iam].[AuditReads]
        ADD CONSTRAINT [FK_iam_AuditReads_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_GovernanceBodies_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[GovernanceBodies]
        ADD CONSTRAINT [FK_ins_GovernanceBodies_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationConnections_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [int].[IntegrationConnections]
        ADD CONSTRAINT [FK_int_IntegrationConnections_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaCredentials_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[ArcaCredentials]
        ADD CONSTRAINT [FK_fis_ArcaCredentials_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CurrentAccounts_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [cob].[CurrentAccounts]
        ADD CONSTRAINT [FK_cob_CurrentAccounts_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_PaymentSlips_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fac].[PaymentSlips]
        ADD CONSTRAINT [FK_fac_PaymentSlips_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaReceivedImports_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[ArcaReceivedImports]
        ADD CONSTRAINT [FK_fis_ArcaReceivedImports_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_FiscalProfiles_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[FiscalProfiles]
        ADD CONSTRAINT [FK_fis_FiscalProfiles_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxpayerRegistries_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[TaxpayerRegistries]
        ADD CONSTRAINT [FK_fis_TaxpayerRegistries_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_AssociateRegisterEditions_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[AssociateRegisterEditions]
        ADD CONSTRAINT [FK_ins_AssociateRegisterEditions_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_NoveltyImportBatches_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [sue].[NoveltyImportBatches]
        ADD CONSTRAINT [FK_sue_NoveltyImportBatches_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_InterbankingConnections_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [tes].[InterbankingConnections]
        ADD CONSTRAINT [FK_tes_InterbankingConnections_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryAccounts_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [tes].[TreasuryAccounts]
        ADD CONSTRAINT [FK_tes_TreasuryAccounts_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Resolutions_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[Resolutions]
        ADD CONSTRAINT [FK_ins_Resolutions_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExternalPayrollImports_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [sue].[ExternalPayrollImports]
        ADD CONSTRAINT [FK_sue_ExternalPayrollImports_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_TreasuryHandovers_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [cob].[TreasuryHandovers]
        ADD CONSTRAINT [FK_cob_TreasuryHandovers_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_AssociateMemberships_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[AssociateMemberships]
        ADD CONSTRAINT [FK_ins_AssociateMemberships_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts]
        ADD CONSTRAINT [FK_cat_ServiceContracts_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalRefunds_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[CapitalRefunds]
        ADD CONSTRAINT [FK_ins_CapitalRefunds_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ChartOfAccounts_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [con].[ChartOfAccounts]
        ADD CONSTRAINT [FK_con_ChartOfAccounts_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ChartOfAccounts_SharedWithLegalEntityIdsId_LegalEntities'
)
BEGIN
    ALTER TABLE [con].[ChartOfAccounts]
        ADD CONSTRAINT [FK_con_ChartOfAccounts_SharedWithLegalEntityIdsId_LegalEntities]
        FOREIGN KEY ([SharedWithLegalEntityIdsId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_costCenter_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_costCenter]
        ADD CONSTRAINT [FK_bia_Bi_dim_costCenter_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryMovements_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [tes].[TreasuryMovements]
        ADD CONSTRAINT [FK_tes_TreasuryMovements_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryAccountSigners_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [tes].[TreasuryAccountSigners]
        ADD CONSTRAINT [FK_tes_TreasuryAccountSigners_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Rosters_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[Rosters]
        ADD CONSTRAINT [FK_ins_Rosters_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_BodyMandates_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[BodyMandates]
        ADD CONSTRAINT [FK_ins_BodyMandates_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_member_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_member]
        ADD CONSTRAINT [FK_bia_Bi_fact_member_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryOperations_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [tes].[TreasuryOperations]
        ADD CONSTRAINT [FK_tes_TreasuryOperations_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingsApplied_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[WithholdingsApplied]
        ADD CONSTRAINT [FK_fis_WithholdingsApplied_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxObligations_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[TaxObligations]
        ADD CONSTRAINT [FK_fis_TaxObligations_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_OwnTaxObligations_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[OwnTaxObligations]
        ADD CONSTRAINT [FK_fis_OwnTaxObligations_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusDistributions_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[SurplusDistributions]
        ADD CONSTRAINT [FK_ins_SurplusDistributions_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_IncomeTaxDeclarations_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [sue].[IncomeTaxDeclarations]
        ADD CONSTRAINT [FK_sue_IncomeTaxDeclarations_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_ShareCertificates_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[ShareCertificates]
        ADD CONSTRAINT [FK_ins_ShareCertificates_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Meetings_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[Meetings]
        ADD CONSTRAINT [FK_ins_Meetings_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InaesReports_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[InaesReports]
        ADD CONSTRAINT [FK_ins_InaesReports_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PayrollPaymentBatches_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [tes].[PayrollPaymentBatches]
        ADD CONSTRAINT [FK_tes_PayrollPaymentBatches_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFeeSettlements_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFeeSettlements]
        ADD CONSTRAINT [FK_ins_InstitutionalFeeSettlements_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollPaymentRequests_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [sue].[PayrollPaymentRequests]
        ADD CONSTRAINT [FK_sue_PayrollPaymentRequests_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalShareValues_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[CapitalShareValues]
        ADD CONSTRAINT [FK_ins_CapitalShareValues_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalTransfers_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[CapitalTransfers]
        ADD CONSTRAINT [FK_ins_CapitalTransfers_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalBalances_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[CapitalBalances]
        ADD CONSTRAINT [FK_ins_CapitalBalances_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalEntries_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [con].[JournalEntries]
        ADD CONSTRAINT [FK_con_JournalEntries_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_StatutoryFilings_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [sue].[StatutoryFilings]
        ADD CONSTRAINT [FK_sue_StatutoryFilings_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders]
        ADD CONSTRAINT [FK_ven_SalesOrders_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalMovements_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[CapitalMovements]
        ADD CONSTRAINT [FK_ins_CapitalMovements_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Employees_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [sue].[Employees]
        ADD CONSTRAINT [FK_sue_Employees_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaSubmissions_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [fis].[ArcaSubmissions]
        ADD CONSTRAINT [FK_fis_ArcaSubmissions_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostCenters_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [con].[CostCenters]
        ADD CONSTRAINT [FK_con_CostCenters_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostCenters_SharedWithLegalEntityIdsId_LegalEntities'
)
BEGIN
    ALTER TABLE [con].[CostCenters]
        ADD CONSTRAINT [FK_con_CostCenters_SharedWithLegalEntityIdsId_LegalEntities]
        FOREIGN KEY ([SharedWithLegalEntityIdsId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalClosings_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[CapitalClosings]
        ADD CONSTRAINT [FK_ins_CapitalClosings_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Receipts_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [cob].[Receipts]
        ADD CONSTRAINT [FK_cob_Receipts_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollRuns_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [sue].[PayrollRuns]
        ADD CONSTRAINT [FK_sue_PayrollRuns_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentCoupons_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [cob].[PaymentCoupons]
        ADD CONSTRAINT [FK_cob_PaymentCoupons_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalSubscriptionRules_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[CapitalSubscriptionRules]
        ADD CONSTRAINT [FK_ins_CapitalSubscriptionRules_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayPeriods_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [sue].[PayPeriods]
        ADD CONSTRAINT [FK_sue_PayPeriods_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Minutes_LegalEntityId_LegalEntities'
)
BEGIN
    ALTER TABLE [ins].[Minutes]
        ADD CONSTRAINT [FK_ins_Minutes_LegalEntityId_LegalEntities]
        FOREIGN KEY ([LegalEntityId]) REFERENCES [cfg].[LegalEntities] ([LegalEntityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Departments_ProvinceId_Provinces'
)
BEGIN
    ALTER TABLE [cfg].[Departments]
        ADD CONSTRAINT [FK_cfg_Departments_ProvinceId_Provinces]
        FOREIGN KEY ([ProvinceId]) REFERENCES [cfg].[Provinces] ([ProvinceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberingPlan_ProvinceId_Provinces'
)
BEGIN
    ALTER TABLE [tec].[NumberingPlan]
        ADD CONSTRAINT [FK_tec_NumberingPlan_ProvinceId_Provinces]
        FOREIGN KEY ([ProvinceId]) REFERENCES [cfg].[Provinces] ([ProvinceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Localities_DepartmentId_Departments'
)
BEGIN
    ALTER TABLE [cfg].[Localities]
        ADD CONSTRAINT [FK_cfg_Localities_DepartmentId_Departments]
        FOREIGN KEY ([DepartmentId]) REFERENCES [cfg].[Departments] ([DepartmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Branches_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[Branches]
        ADD CONSTRAINT [FK_cfg_Branches_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_CadastralDistricts_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[CadastralDistricts]
        ADD CONSTRAINT [FK_cfg_CadastralDistricts_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Neighborhoods_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[Neighborhoods]
        ADD CONSTRAINT [FK_cfg_Neighborhoods_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_PostalCodes_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[PostalCodes]
        ADD CONSTRAINT [FK_cfg_PostalCodes_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Streets_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[Streets]
        ADD CONSTRAINT [FK_cfg_Streets_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CareProviders_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [soc].[CareProviders]
        ADD CONSTRAINT [FK_soc_CareProviders_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_StreetProposals_LocalityId_Localities'
)
BEGIN
    ALTER TABLE [cfg].[StreetProposals]
        ADD CONSTRAINT [FK_cfg_StreetProposals_LocalityId_Localities]
        FOREIGN KEY ([LocalityId]) REFERENCES [cfg].[Localities] ([LocalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_branch_BranchId_Branches'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_branch]
        ADD CONSTRAINT [FK_bia_Bi_dim_branch_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Zones_BranchId_Branches'
)
BEGIN
    ALTER TABLE [cfg].[Zones]
        ADD CONSTRAINT [FK_cfg_Zones_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueDesks_BranchId_Branches'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueDesks]
        ADD CONSTRAINT [FK_crm_CrmQueueDesks_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatLedgerLines_BranchId_Branches'
)
BEGIN
    ALTER TABLE [fis].[VatLedgerLines]
        ADD CONSTRAINT [FK_fis_VatLedgerLines_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueAppointments_BranchId_Branches'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueAppointments]
        ADD CONSTRAINT [FK_crm_CrmQueueAppointments_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_OrthopedicItems_BranchId_Branches'
)
BEGIN
    ALTER TABLE [soc].[OrthopedicItems]
        ADD CONSTRAINT [FK_soc_OrthopedicItems_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryAccounts_BranchId_Branches'
)
BEGIN
    ALTER TABLE [tes].[TreasuryAccounts]
        ADD CONSTRAINT [FK_tes_TreasuryAccounts_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Workstations_BranchId_Branches'
)
BEGIN
    ALTER TABLE [cfg].[Workstations]
        ADD CONSTRAINT [FK_cfg_Workstations_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueDisplays_BranchId_Branches'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueDisplays]
        ADD CONSTRAINT [FK_crm_CrmQueueDisplays_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DispenserWithdrawals_BranchId_Branches'
)
BEGIN
    ALTER TABLE [soc].[DispenserWithdrawals]
        ADD CONSTRAINT [FK_soc_DispenserWithdrawals_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PaymentCashSessions_BranchId_Branches'
)
BEGIN
    ALTER TABLE [tes].[PaymentCashSessions]
        ADD CONSTRAINT [FK_tes_PaymentCashSessions_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryOperations_BranchId_Branches'
)
BEGIN
    ALTER TABLE [tes].[TreasuryOperations]
        ADD CONSTRAINT [FK_tes_TreasuryOperations_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_KioskDevices_BranchId_Branches'
)
BEGIN
    ALTER TABLE [por].[KioskDevices]
        ADD CONSTRAINT [FK_por_KioskDevices_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_LocalAgents_BranchId_Branches'
)
BEGIN
    ALTER TABLE [int].[LocalAgents]
        ADD CONSTRAINT [FK_int_LocalAgents_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_BranchId_Branches'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters]
        ADD CONSTRAINT [FK_cob_CashRegisters_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosTerminals_BranchId_Branches'
)
BEGIN
    ALTER TABLE [ven].[PosTerminals]
        ADD CONSTRAINT [FK_ven_PosTerminals_BranchId_Branches]
        FOREIGN KEY ([BranchId]) REFERENCES [cfg].[Branches] ([BrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Accounts_DistrictSectionId_CadastralDistricts'
)
BEGIN
    ALTER TABLE [per].[Accounts]
        ADD CONSTRAINT [FK_per_Accounts_DistrictSectionId_CadastralDistricts]
        FOREIGN KEY ([DistrictSectionId]) REFERENCES [cfg].[CadastralDistricts] ([CadastralDistrictId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_SeedApplications_SeedPackId_SeedPacks'
)
BEGIN
    ALTER TABLE [cfg].[SeedApplications]
        ADD CONSTRAINT [FK_cfg_SeedApplications_SeedPackId_SeedPacks]
        FOREIGN KEY ([SeedPackId]) REFERENCES [cfg].[SeedPacks] ([SeedPackId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_StreetAliases_StreetId_Streets'
)
BEGIN
    ALTER TABLE [cfg].[StreetAliases]
        ADD CONSTRAINT [FK_cfg_StreetAliases_StreetId_Streets]
        FOREIGN KEY ([StreetId]) REFERENCES [cfg].[Streets] ([StreetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_StreetProposals_PlatformStreetId_Streets'
)
BEGIN
    ALTER TABLE [cfg].[StreetProposals]
        ADD CONSTRAINT [FK_cfg_StreetProposals_PlatformStreetId_Streets]
        FOREIGN KEY ([PlatformStreetId]) REFERENCES [cfg].[Streets] ([StreetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_StreetProposals_StreetId_Streets'
)
BEGIN
    ALTER TABLE [cfg].[StreetProposals]
        ADD CONSTRAINT [FK_cfg_StreetProposals_StreetId_Streets]
        FOREIGN KEY ([StreetId]) REFERENCES [cfg].[Streets] ([StreetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_zone_ZoneId_Zones'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_zone]
        ADD CONSTRAINT [FK_bia_Bi_dim_zone_ZoneId_Zones]
        FOREIGN KEY ([ZoneId]) REFERENCES [cfg].[Zones] ([ZoneId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_OutageNotices_ZoneIdsId_Zones'
)
BEGIN
    ALTER TABLE [com].[OutageNotices]
        ADD CONSTRAINT [FK_com_OutageNotices_ZoneIdsId_Zones]
        FOREIGN KEY ([ZoneIdsId]) REFERENCES [cfg].[Zones] ([ZoneId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_GasCalorificFactors_ZoneId_Zones'
)
BEGIN
    ALTER TABLE [tar].[GasCalorificFactors]
        ADD CONSTRAINT [FK_tar_GasCalorificFactors_ZoneId_Zones]
        FOREIGN KEY ([ZoneId]) REFERENCES [cfg].[Zones] ([ZoneId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_SchedulingZones_ZoneIdsId_Zones'
)
BEGIN
    ALTER TABLE [tec].[SchedulingZones]
        ADD CONSTRAINT [FK_tec_SchedulingZones_ZoneIdsId_Zones]
        FOREIGN KEY ([ZoneIdsId]) REFERENCES [cfg].[Zones] ([ZoneId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplyBalances_ZoneId_Zones'
)
BEGIN
    ALTER TABLE [cmp].[SupplyBalances]
        ADD CONSTRAINT [FK_cmp_SupplyBalances_ZoneId_Zones]
        FOREIGN KEY ([ZoneId]) REFERENCES [cfg].[Zones] ([ZoneId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierAdvances_PaymentOrderId_PaymentOrders'
)
BEGIN
    ALTER TABLE [cmp].[SupplierAdvances]
        ADD CONSTRAINT [FK_cmp_SupplierAdvances_PaymentOrderId_PaymentOrders]
        FOREIGN KEY ([PaymentOrderId]) REFERENCES [cmp].[PaymentOrders] ([PaymentOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalRefunds_PaymentOrderRefId_PaymentOrders'
)
BEGIN
    ALTER TABLE [ins].[CapitalRefunds]
        ADD CONSTRAINT [FK_ins_CapitalRefunds_PaymentOrderRefId_PaymentOrders]
        FOREIGN KEY ([PaymentOrderRefId]) REFERENCES [cmp].[PaymentOrders] ([PaymentOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyRemittances_PaymentOrderId_PaymentOrders'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyRemittances]
        ADD CONSTRAINT [FK_fis_ThirdPartyRemittances_PaymentOrderId_PaymentOrders]
        FOREIGN KEY ([PaymentOrderId]) REFERENCES [cmp].[PaymentOrders] ([PaymentOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingsApplied_PaymentOrderId_PaymentOrders'
)
BEGIN
    ALTER TABLE [fis].[WithholdingsApplied]
        ADD CONSTRAINT [FK_fis_WithholdingsApplied_PaymentOrderId_PaymentOrders]
        FOREIGN KEY ([PaymentOrderId]) REFERENCES [cmp].[PaymentOrders] ([PaymentOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFeeSettlements_PaymentOrderRefId_PaymentOrders'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFeeSettlements]
        ADD CONSTRAINT [FK_ins_InstitutionalFeeSettlements_PaymentOrderRefId_PaymentOrders]
        FOREIGN KEY ([PaymentOrderRefId]) REFERENCES [cmp].[PaymentOrders] ([PaymentOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusAllocations_PaymentOrderRefId_PaymentOrders'
)
BEGIN
    ALTER TABLE [ins].[SurplusAllocations]
        ADD CONSTRAINT [FK_ins_SurplusAllocations_PaymentOrderRefId_PaymentOrders]
        FOREIGN KEY ([PaymentOrderRefId]) REFERENCES [cmp].[PaymentOrders] ([PaymentOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_RefundCases_PaymentOrderId_PaymentOrders'
)
BEGIN
    ALTER TABLE [cob].[RefundCases]
        ADD CONSTRAINT [FK_cob_RefundCases_PaymentOrderId_PaymentOrders]
        FOREIGN KEY ([PaymentOrderId]) REFERENCES [cmp].[PaymentOrders] ([PaymentOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseDocumentLinks_OriginId_SupplyRequests'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseDocumentLinks]
        ADD CONSTRAINT [FK_cmp_PurchaseDocumentLinks_OriginId_SupplyRequests]
        FOREIGN KEY ([OriginId]) REFERENCES [cmp].[SupplyRequests] ([SupplyRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseDocumentLinks_TargetId_SupplyRequests'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseDocumentLinks]
        ADD CONSTRAINT [FK_cmp_PurchaseDocumentLinks_TargetId_SupplyRequests]
        FOREIGN KEY ([TargetId]) REFERENCES [cmp].[SupplyRequests] ([SupplyRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_MrpRuns_RequisitionIdsId_SupplyRequests'
)
BEGIN
    ALTER TABLE [stk].[MrpRuns]
        ADD CONSTRAINT [FK_stk_MrpRuns_RequisitionIdsId_SupplyRequests]
        FOREIGN KEY ([RequisitionIdsId]) REFERENCES [cmp].[SupplyRequests] ([SupplyRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ReorderSuggestions_RequisitionId_SupplyRequests'
)
BEGIN
    ALTER TABLE [stk].[ReorderSuggestions]
        ADD CONSTRAINT [FK_stk_ReorderSuggestions_RequisitionId_SupplyRequests]
        FOREIGN KEY ([RequisitionId]) REFERENCES [cmp].[SupplyRequests] ([SupplyRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ReorderSuggestions_SupplyRequestId_SupplyRequests'
)
BEGIN
    ALTER TABLE [stk].[ReorderSuggestions]
        ADD CONSTRAINT [FK_stk_ReorderSuggestions_SupplyRequestId_SupplyRequests]
        FOREIGN KEY ([SupplyRequestId]) REFERENCES [cmp].[SupplyRequests] ([SupplyRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_ReversalAllocationIdsId_Allocations'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_ReversalAllocationIdsId_Allocations]
        FOREIGN KEY ([ReversalAllocationIdsId]) REFERENCES [cob].[Allocations] ([AllocationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_allocation_AllocationId_Allocations'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_allocation]
        ADD CONSTRAINT [FK_bia_Bi_fact_allocation_AllocationId_Allocations]
        FOREIGN KEY ([AllocationId]) REFERENCES [cob].[Allocations] ([AllocationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Accounts_AccountingGroupId_CollectionAccountingGroups'
)
BEGIN
    ALTER TABLE [per].[Accounts]
        ADD CONSTRAINT [FK_per_Accounts_AccountingGroupId_CollectionAccountingGroups]
        FOREIGN KEY ([AccountingGroupId]) REFERENCES [cob].[CollectionAccountingGroups] ([CollectionAccountingGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_ledgerEntry_LedgerEntryId_LedgerEntries'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_ledgerEntry]
        ADD CONSTRAINT [FK_bia_Bi_fact_ledgerEntry_LedgerEntryId_LedgerEntries]
        FOREIGN KEY ([LedgerEntryId]) REFERENCES [cob].[LedgerEntries] ([LedgerEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentReferences_TargetId_Obligations'
)
BEGIN
    ALTER TABLE [cob].[PaymentReferences]
        ADD CONSTRAINT [FK_cob_PaymentReferences_TargetId_Obligations]
        FOREIGN KEY ([TargetId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_UnidentifiedReceipts_CandidateObligationIdsId_Obligations'
)
BEGIN
    ALTER TABLE [cob].[UnidentifiedReceipts]
        ADD CONSTRAINT [FK_cob_UnidentifiedReceipts_CandidateObligationIdsId_Obligations]
        FOREIGN KEY ([CandidateObligationIdsId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_ChargeObligationIdsId_Obligations'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_ChargeObligationIdsId_Obligations]
        FOREIGN KEY ([ChargeObligationIdsId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementObligations_ObligationId_Obligations'
)
BEGIN
    ALTER TABLE [mor].[AgreementObligations]
        ADD CONSTRAINT [FK_mor_AgreementObligations_ObligationId_Obligations]
        FOREIGN KEY ([ObligationId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_WriteOffs_ObligationIdsId_Obligations'
)
BEGIN
    ALTER TABLE [mor].[WriteOffs]
        ADD CONSTRAINT [FK_mor_WriteOffs_ObligationIdsId_Obligations]
        FOREIGN KEY ([ObligationIdsId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyCollections_ObligationId_Obligations'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyCollections]
        ADD CONSTRAINT [FK_cob_ThirdPartyCollections_ObligationId_Obligations]
        FOREIGN KEY ([ObligationId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentCoupons_ObligationIdsId_Obligations'
)
BEGIN
    ALTER TABLE [cob].[PaymentCoupons]
        ADD CONSTRAINT [FK_cob_PaymentCoupons_ObligationIdsId_Obligations]
        FOREIGN KEY ([ObligationIdsId]) REFERENCES [cob].[Obligations] ([ObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AccountStatements_PaymentReferenceIdsId_PaymentReferences'
)
BEGIN
    ALTER TABLE [cob].[AccountStatements]
        ADD CONSTRAINT [FK_cob_AccountStatements_PaymentReferenceIdsId_PaymentReferences]
        FOREIGN KEY ([PaymentReferenceIdsId]) REFERENCES [cob].[PaymentReferences] ([PaymentReferenceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentCoupons_PaymentReferenceId_PaymentReferences'
)
BEGIN
    ALTER TABLE [cob].[PaymentCoupons]
        ADD CONSTRAINT [FK_cob_PaymentCoupons_PaymentReferenceId_PaymentReferences]
        FOREIGN KEY ([PaymentReferenceId]) REFERENCES [cob].[PaymentReferences] ([PaymentReferenceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_MessageTemplates_CommunicationTypeId_CommunicationTypes'
)
BEGIN
    ALTER TABLE [com].[MessageTemplates]
        ADD CONSTRAINT [FK_com_MessageTemplates_CommunicationTypeId_CommunicationTypes]
        FOREIGN KEY ([CommunicationTypeId]) REFERENCES [com].[CommunicationTypes] ([CommunicationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ModerationPolicies_CurrentGuidelinesId_CommunityGuidelines'
)
BEGIN
    ALTER TABLE [com].[ModerationPolicies]
        ADD CONSTRAINT [FK_com_ModerationPolicies_CurrentGuidelinesId_CommunityGuidelines]
        FOREIGN KEY ([CurrentGuidelinesId]) REFERENCES [com].[CommunityGuidelines] ([CommunityGuidelineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunitySanctions_CaseIdsId_ModerationCases'
)
BEGIN
    ALTER TABLE [com].[CommunitySanctions]
        ADD CONSTRAINT [FK_com_CommunitySanctions_CaseIdsId_ModerationCases]
        FOREIGN KEY ([CaseIdsId]) REFERENCES [com].[ModerationCases] ([ModerationCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Newsletters_RuleId_NewsletterRules'
)
BEGIN
    ALTER TABLE [com].[Newsletters]
        ADD CONSTRAINT [FK_com_Newsletters_RuleId_NewsletterRules]
        FOREIGN KEY ([RuleId]) REFERENCES [com].[NewsletterRules] ([NewsletterRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ModerationRules_CategoryIdsId_PostCategories'
)
BEGIN
    ALTER TABLE [com].[ModerationRules]
        ADD CONSTRAINT [FK_com_ModerationRules_CategoryIdsId_PostCategories]
        FOREIGN KEY ([CategoryIdsId]) REFERENCES [com].[PostCategories] ([PostCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Posts_CategoryId_PostCategories'
)
BEGIN
    ALTER TABLE [com].[Posts]
        ADD CONSTRAINT [FK_com_Posts_CategoryId_PostCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [com].[PostCategories] ([PostCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_GreetingRules_PostTemplateId_PostTemplates'
)
BEGIN
    ALTER TABLE [com].[GreetingRules]
        ADD CONSTRAINT [FK_com_GreetingRules_PostTemplateId_PostTemplates]
        FOREIGN KEY ([PostTemplateId]) REFERENCES [com].[PostTemplates] ([PostTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostCenterModels_DistributionModelId_DistributionModels'
)
BEGIN
    ALTER TABLE [con].[CostCenterModels]
        ADD CONSTRAINT [FK_con_CostCenterModels_DistributionModelId_DistributionModels]
        FOREIGN KEY ([DistributionModelId]) REFERENCES [con].[DistributionModels] ([DistributionModelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostDistributionRuns_DistributionModelId_DistributionModels'
)
BEGIN
    ALTER TABLE [con].[CostDistributionRuns]
        ADD CONSTRAINT [FK_con_CostDistributionRuns_DistributionModelId_DistributionModels]
        FOREIGN KEY ([DistributionModelId]) REFERENCES [con].[DistributionModels] ([DistributionModelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostAllocationRules_ModelId_DistributionModels'
)
BEGIN
    ALTER TABLE [con].[CostAllocationRules]
        ADD CONSTRAINT [FK_con_CostAllocationRules_ModelId_DistributionModels]
        FOREIGN KEY ([ModelId]) REFERENCES [con].[DistributionModels] ([DistributionModelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountRoles_CostCenterModelId_CostCenterModels'
)
BEGIN
    ALTER TABLE [con].[AccountRoles]
        ADD CONSTRAINT [FK_con_AccountRoles_CostCenterModelId_CostCenterModels]
        FOREIGN KEY ([CostCenterModelId]) REFERENCES [con].[CostCenterModels] ([CostCenterModelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountingPeriods_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[AccountingPeriods]
        ADD CONSTRAINT [FK_con_AccountingPeriods_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ReconciliationRuns_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[ReconciliationRuns]
        ADD CONSTRAINT [FK_con_ReconciliationRuns_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_RubricatedBooks_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[RubricatedBooks]
        ADD CONSTRAINT [FK_con_RubricatedBooks_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_DepreciationRuns_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [stk].[DepreciationRuns]
        ADD CONSTRAINT [FK_stk_DepreciationRuns_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_InflationAdjustmentRuns_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[InflationAdjustmentRuns]
        ADD CONSTRAINT [FK_con_InflationAdjustmentRuns_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_Budgets_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[Budgets]
        ADD CONSTRAINT [FK_con_Budgets_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_FinancialStatementRuns_ComparativeFiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[FinancialStatementRuns]
        ADD CONSTRAINT [FK_con_FinancialStatementRuns_ComparativeFiscalYearId_FiscalYears]
        FOREIGN KEY ([ComparativeFiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_FinancialStatementRuns_FiscalYearId_FiscalYears'
)
BEGIN
    ALTER TABLE [con].[FinancialStatementRuns]
        ADD CONSTRAINT [FK_con_FinancialStatementRuns_FiscalYearId_FiscalYears]
        FOREIGN KEY ([FiscalYearId]) REFERENCES [con].[FiscalYears] ([FiscalYearId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_PeriodId_AccountingPeriods'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_PeriodId_AccountingPeriods]
        FOREIGN KEY ([PeriodId]) REFERENCES [con].[AccountingPeriods] ([AccountingPeriodId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountingEvents_PostingBatchId_PostingBatches'
)
BEGIN
    ALTER TABLE [con].[AccountingEvents]
        ADD CONSTRAINT [FK_con_AccountingEvents_PostingBatchId_PostingBatches]
        FOREIGN KEY ([PostingBatchId]) REFERENCES [con].[PostingBatches] ([PostingBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalEntries_PostingBatchId_PostingBatches'
)
BEGIN
    ALTER TABLE [con].[JournalEntries]
        ADD CONSTRAINT [FK_con_JournalEntries_PostingBatchId_PostingBatches]
        FOREIGN KEY ([PostingBatchId]) REFERENCES [con].[PostingBatches] ([PostingBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetValueChanges_EventId_AccountingEvents'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetValueChanges]
        ADD CONSTRAINT [FK_stk_FixedAssetValueChanges_EventId_AccountingEvents]
        FOREIGN KEY ([EventId]) REFERENCES [con].[AccountingEvents] ([AccountingEventId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_WriteOffs_AccountingEventIdsId_AccountingEvents'
)
BEGIN
    ALTER TABLE [mor].[WriteOffs]
        ADD CONSTRAINT [FK_mor_WriteOffs_AccountingEventIdsId_AccountingEvents]
        FOREIGN KEY ([AccountingEventIdsId]) REFERENCES [con].[AccountingEvents] ([AccountingEventId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_FinancialStatementRuns_TemplateIdsId_StatementTemplates'
)
BEGIN
    ALTER TABLE [con].[FinancialStatementRuns]
        ADD CONSTRAINT [FK_con_FinancialStatementRuns_TemplateIdsId_StatementTemplates]
        FOREIGN KEY ([TemplateIdsId]) REFERENCES [con].[StatementTemplates] ([StatementTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityTypes_FrequencyId_CrmActivityFrequencies'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityTypes]
        ADD CONSTRAINT [FK_crm_CrmActivityTypes_FrequencyId_CrmActivityFrequencies]
        FOREIGN KEY ([FrequencyId]) REFERENCES [crm].[CrmActivityFrequencies] ([CrmActivityFrequencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivities_FrequencyId_CrmActivityFrequencies'
)
BEGIN
    ALTER TABLE [crm].[CrmActivities]
        ADD CONSTRAINT [FK_crm_CrmActivities_FrequencyId_CrmActivityFrequencies]
        FOREIGN KEY ([FrequencyId]) REFERENCES [crm].[CrmActivityFrequencies] ([CrmActivityFrequencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityTypes_RubroId_CrmActivityRubros'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityTypes]
        ADD CONSTRAINT [FK_crm_CrmActivityTypes_RubroId_CrmActivityRubros]
        FOREIGN KEY ([RubroId]) REFERENCES [crm].[CrmActivityRubros] ([CrmActivityRubroId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivities_RubroId_CrmActivityRubros'
)
BEGIN
    ALTER TABLE [crm].[CrmActivities]
        ADD CONSTRAINT [FK_crm_CrmActivities_RubroId_CrmActivityRubros]
        FOREIGN KEY ([RubroId]) REFERENCES [crm].[CrmActivityRubros] ([CrmActivityRubroId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityTypes_AreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityTypes]
        ADD CONSTRAINT [FK_crm_CrmActivityTypes_AreaId_CrmAreas]
        FOREIGN KEY ([AreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueAppointments_AreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueAppointments]
        ADD CONSTRAINT [FK_crm_CrmQueueAppointments_AreaId_CrmAreas]
        FOREIGN KEY ([AreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_Dossiers_ResponsibleAreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [wfl].[Dossiers]
        ADD CONSTRAINT [FK_wfl_Dossiers_ResponsibleAreaId_CrmAreas]
        FOREIGN KEY ([ResponsibleAreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_AreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_AreaId_CrmAreas]
        FOREIGN KEY ([AreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueTicketEvents_AreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueTicketEvents]
        ADD CONSTRAINT [FK_crm_CrmQueueTicketEvents_AreaId_CrmAreas]
        FOREIGN KEY ([AreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQuickReplies_AreaId_CrmAreas'
)
BEGIN
    ALTER TABLE [crm].[CrmQuickReplies]
        ADD CONSTRAINT [FK_crm_CrmQuickReplies_AreaId_CrmAreas]
        FOREIGN KEY ([AreaId]) REFERENCES [crm].[CrmAreas] ([CrmAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivities_ActivityTypeId_CrmActivityTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmActivities]
        ADD CONSTRAINT [FK_crm_CrmActivities_ActivityTypeId_CrmActivityTypes]
        FOREIGN KEY ([ActivityTypeId]) REFERENCES [crm].[CrmActivityTypes] ([CrmActivityTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivities_TypeId_CrmActivityTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmActivities]
        ADD CONSTRAINT [FK_crm_CrmActivities_TypeId_CrmActivityTypes]
        FOREIGN KEY ([TypeId]) REFERENCES [crm].[CrmActivityTypes] ([CrmActivityTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmBotSessions_FlowId_CrmBotFlows'
)
BEGIN
    ALTER TABLE [crm].[CrmBotSessions]
        ADD CONSTRAINT [FK_crm_CrmBotSessions_FlowId_CrmBotFlows]
        FOREIGN KEY ([FlowId]) REFERENCES [crm].[CrmBotFlows] ([CrmBotFlowId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCalendarEvents_EventTypeId_CrmCalendarEventTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmCalendarEvents]
        ADD CONSTRAINT [FK_crm_CrmCalendarEvents_EventTypeId_CrmCalendarEventTypes]
        FOREIGN KEY ([EventTypeId]) REFERENCES [crm].[CrmCalendarEventTypes] ([CrmCalendarEventTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCalendarEvents_TypeId_CrmCalendarEventTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmCalendarEvents]
        ADD CONSTRAINT [FK_crm_CrmCalendarEvents_TypeId_CrmCalendarEventTypes]
        FOREIGN KEY ([TypeId]) REFERENCES [crm].[CrmCalendarEventTypes] ([CrmCalendarEventTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_CaseSubtypeId_CrmCaseSubtypes'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_CaseSubtypeId_CrmCaseSubtypes]
        FOREIGN KEY ([CaseSubtypeId]) REFERENCES [crm].[CrmCaseSubtypes] ([CrmCaseSubtypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_CaseTypeId_CrmCaseTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_CaseTypeId_CrmCaseTypes]
        FOREIGN KEY ([CaseTypeId]) REFERENCES [crm].[CrmCaseTypes] ([CrmCaseTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmConversations_ChannelId_CrmChannels'
)
BEGIN
    ALTER TABLE [crm].[CrmConversations]
        ADD CONSTRAINT [FK_crm_CrmConversations_ChannelId_CrmChannels]
        FOREIGN KEY ([ChannelId]) REFERENCES [crm].[CrmChannels] ([CrmChannelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrders_IntakeChannelId_CrmChannels'
)
BEGIN
    ALTER TABLE [tec].[WorkOrders]
        ADD CONSTRAINT [FK_tec_WorkOrders_IntakeChannelId_CrmChannels]
        FOREIGN KEY ([IntakeChannelId]) REFERENCES [crm].[CrmChannels] ([CrmChannelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ChainedOrderRules_TargetIntakeChannelId_CrmChannels'
)
BEGIN
    ALTER TABLE [tec].[ChainedOrderRules]
        ADD CONSTRAINT [FK_tec_ChainedOrderRules_TargetIntakeChannelId_CrmChannels]
        FOREIGN KEY ([TargetIntakeChannelId]) REFERENCES [crm].[CrmChannels] ([CrmChannelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmBotSessions_ConversationId_CrmConversations'
)
BEGIN
    ALTER TABLE [crm].[CrmBotSessions]
        ADD CONSTRAINT [FK_crm_CrmBotSessions_ConversationId_CrmConversations]
        FOREIGN KEY ([ConversationId]) REFERENCES [crm].[CrmConversations] ([CrmConversationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmIncidents_IncidentClassId_CrmIncidentClasses'
)
BEGIN
    ALTER TABLE [crm].[CrmIncidents]
        ADD CONSTRAINT [FK_crm_CrmIncidents_IncidentClassId_CrmIncidentClasses]
        FOREIGN KEY ([IncidentClassId]) REFERENCES [crm].[CrmIncidentClasses] ([CrmIncidentClassId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_ProjectId_CrmProjects'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_ProjectId_CrmProjects]
        FOREIGN KEY ([ProjectId]) REFERENCES [crm].[CrmProjects] ([CrmProjectId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesQuotes_ProjectId_CrmProjects'
)
BEGIN
    ALTER TABLE [ven].[SalesQuotes]
        ADD CONSTRAINT [FK_ven_SalesQuotes_ProjectId_CrmProjects]
        FOREIGN KEY ([ProjectId]) REFERENCES [crm].[CrmProjects] ([CrmProjectId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueDesks_DeskTypeId_CrmQueueDeskTypes'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueDesks]
        ADD CONSTRAINT [FK_crm_CrmQueueDesks_DeskTypeId_CrmQueueDeskTypes]
        FOREIGN KEY ([DeskTypeId]) REFERENCES [crm].[CrmQueueDeskTypes] ([CrmQueueDeskTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueTicketEvents_DeskId_CrmQueueDesks'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueTicketEvents]
        ADD CONSTRAINT [FK_crm_CrmQueueTicketEvents_DeskId_CrmQueueDesks]
        FOREIGN KEY ([DeskId]) REFERENCES [crm].[CrmQueueDesks] ([CrmQueueDeskId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueDeskSessions_DeskId_CrmQueueDesks'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueDeskSessions]
        ADD CONSTRAINT [FK_crm_CrmQueueDeskSessions_DeskId_CrmQueueDesks]
        FOREIGN KEY ([DeskId]) REFERENCES [crm].[CrmQueueDesks] ([CrmQueueDeskId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_turn_CrmQueueTicketId_CrmQueueTickets'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_turn]
        ADD CONSTRAINT [FK_bia_Bi_fact_turn_CrmQueueTicketId_CrmQueueTickets]
        FOREIGN KEY ([CrmQueueTicketId]) REFERENCES [crm].[CrmQueueTickets] ([CrmQueueTicketId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueAppointments_QueueTicketId_CrmQueueTickets'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueAppointments]
        ADD CONSTRAINT [FK_crm_CrmQueueAppointments_QueueTicketId_CrmQueueTickets]
        FOREIGN KEY ([QueueTicketId]) REFERENCES [crm].[CrmQueueTickets] ([CrmQueueTicketId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueTicketEvents_QueueTicketId_CrmQueueTickets'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueTicketEvents]
        ADD CONSTRAINT [FK_crm_CrmQueueTicketEvents_QueueTicketId_CrmQueueTickets]
        FOREIGN KEY ([QueueTicketId]) REFERENCES [crm].[CrmQueueTickets] ([CrmQueueTicketId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BarcodeAssignments_FormatId_BarcodeFormats'
)
BEGIN
    ALTER TABLE [fac].[BarcodeAssignments]
        ADD CONSTRAINT [FK_fac_BarcodeAssignments_FormatId_BarcodeFormats]
        FOREIGN KEY ([FormatId]) REFERENCES [fac].[BarcodeFormats] ([BarcodeFormatId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingExceptions_ReprocessRunId_BillingRuns'
)
BEGIN
    ALTER TABLE [fac].[BillingExceptions]
        ADD CONSTRAINT [FK_fac_BillingExceptions_ReprocessRunId_BillingRuns]
        FOREIGN KEY ([ReprocessRunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingRunItems_CarriedOverToRunId_BillingRuns'
)
BEGIN
    ALTER TABLE [fac].[BillingRunItems]
        ADD CONSTRAINT [FK_fac_BillingRunItems_CarriedOverToRunId_BillingRuns]
        FOREIGN KEY ([CarriedOverToRunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_DistributionRuns_BillingRunId_BillingRuns'
)
BEGIN
    ALTER TABLE [fac].[DistributionRuns]
        ADD CONSTRAINT [FK_fac_DistributionRuns_BillingRunId_BillingRuns]
        FOREIGN KEY ([BillingRunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingRunNumberRanges_RunId_BillingRuns'
)
BEGIN
    ALTER TABLE [fac].[BillingRunNumberRanges]
        ADD CONSTRAINT [FK_fac_BillingRunNumberRanges_RunId_BillingRuns]
        FOREIGN KEY ([RunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_CalculationRuns_BillingRunId_BillingRuns'
)
BEGIN
    ALTER TABLE [tar].[CalculationRuns]
        ADD CONSTRAINT [FK_tar_CalculationRuns_BillingRunId_BillingRuns]
        FOREIGN KEY ([BillingRunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BilledPeriods_RunId_BillingRuns'
)
BEGIN
    ALTER TABLE [fac].[BilledPeriods]
        ADD CONSTRAINT [FK_fac_BilledPeriods_RunId_BillingRuns]
        FOREIGN KEY ([RunId]) REFERENCES [fac].[BillingRuns] ([BillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingCycles_UniverseId_BillingUniverses'
)
BEGIN
    ALTER TABLE [fac].[BillingCycles]
        ADD CONSTRAINT [FK_fac_BillingCycles_UniverseId_BillingUniverses]
        FOREIGN KEY ([UniverseId]) REFERENCES [fac].[BillingUniverses] ([BillingUniversId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDeliveries_DistributionRunId_DistributionRuns'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDeliveries]
        ADD CONSTRAINT [FK_fac_InvoiceDeliveries_DistributionRunId_DistributionRuns]
        FOREIGN KEY ([DistributionRunId]) REFERENCES [fac].[DistributionRuns] ([DistributionRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingTemplates_PrintTemplateId_InvoiceTemplates'
)
BEGIN
    ALTER TABLE [fac].[BillingTemplates]
        ADD CONSTRAINT [FK_fac_BillingTemplates_PrintTemplateId_InvoiceTemplates]
        FOREIGN KEY ([PrintTemplateId]) REFERENCES [fac].[InvoiceTemplates] ([InvoiceTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingCycles_TemplateId_BillingTemplates'
)
BEGIN
    ALTER TABLE [fac].[BillingCycles]
        ADD CONSTRAINT [FK_fac_BillingCycles_TemplateId_BillingTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [fac].[BillingTemplates] ([BillingTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Accounts_PostalCompanyId_PostalCarriers'
)
BEGIN
    ALTER TABLE [per].[Accounts]
        ADD CONSTRAINT [FK_per_Accounts_PostalCompanyId_PostalCarriers]
        FOREIGN KEY ([PostalCompanyId]) REFERENCES [fac].[PostalCarriers] ([PostalCarrierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_DistributionRoutes_PostalCarrierId_PostalCarriers'
)
BEGIN
    ALTER TABLE [fac].[DistributionRoutes]
        ADD CONSTRAINT [FK_fac_DistributionRoutes_PostalCarrierId_PostalCarriers]
        FOREIGN KEY ([PostalCarrierId]) REFERENCES [fac].[PostalCarriers] ([PostalCarrierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingGroups_VoucherTypeOverrideId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fac].[BillingGroups]
        ADD CONSTRAINT [FK_fac_BillingGroups_VoucherTypeOverrideId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeOverrideId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_Invoices_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fac].[Invoices]
        ADD CONSTRAINT [FK_fac_Invoices_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingRunNumberRanges_NumberingVoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fac].[BillingRunNumberRanges]
        ADD CONSTRAINT [FK_fac_BillingRunNumberRanges_NumberingVoucherTypeId_VoucherTypes]
        FOREIGN KEY ([NumberingVoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingRunNumberRanges_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fac].[BillingRunNumberRanges]
        ADD CONSTRAINT [FK_fac_BillingRunNumberRanges_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_NumberSequences_NumberingVoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fac].[NumberSequences]
        ADD CONSTRAINT [FK_fac_NumberSequences_NumberingVoucherTypeId_VoucherTypes]
        FOREIGN KEY ([NumberingVoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_CespAuthorizations_VoucherTypeIdsId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fis].[CespAuthorizations]
        ADD CONSTRAINT [FK_fis_CespAuthorizations_VoucherTypeIdsId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeIdsId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ProvincialValidationCodes_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [fis].[ProvincialValidationCodes]
        ADD CONSTRAINT [FK_fis_ProvincialValidationCodes_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollTypes_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [sue].[PayrollTypes]
        ADD CONSTRAINT [FK_sue_PayrollTypes_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_RoundingCarryEntries_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [tar].[RoundingCarryEntries]
        ADD CONSTRAINT [FK_tar_RoundingCarryEntries_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_RoundingPolicies_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [tar].[RoundingPolicies]
        ADD CONSTRAINT [FK_tar_RoundingPolicies_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_TariffCategoryRates_ForcedVoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [tar].[TariffCategoryRates]
        ADD CONSTRAINT [FK_tar_TariffCategoryRates_ForcedVoucherTypeId_VoucherTypes]
        FOREIGN KEY ([ForcedVoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyBillers_BillingTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyBillers]
        ADD CONSTRAINT [FK_cob_ThirdPartyBillers_BillingTypeId_VoucherTypes]
        FOREIGN KEY ([BillingTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyBillers_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyBillers]
        ADD CONSTRAINT [FK_cob_ThirdPartyBillers_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Receipts_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [cob].[Receipts]
        ADD CONSTRAINT [FK_cob_Receipts_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_EarlyPaymentDiscountRules_VoucherTypeId_VoucherTypes'
)
BEGIN
    ALTER TABLE [mor].[EarlyPaymentDiscountRules]
        ADD CONSTRAINT [FK_mor_EarlyPaymentDiscountRules_VoucherTypeId_VoucherTypes]
        FOREIGN KEY ([VoucherTypeId]) REFERENCES [fac].[VoucherTypes] ([VoucherTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_TenantServices_DefaultBillingGroupId_BillingGroups'
)
BEGIN
    ALTER TABLE [cat].[TenantServices]
        ADD CONSTRAINT [FK_cat_TenantServices_DefaultBillingGroupId_BillingGroups]
        FOREIGN KEY ([DefaultBillingGroupId]) REFERENCES [fac].[BillingGroups] ([BillingGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_NumberSequences_BillingGroupId_BillingGroups'
)
BEGIN
    ALTER TABLE [fac].[NumberSequences]
        ADD CONSTRAINT [FK_fac_NumberSequences_BillingGroupId_BillingGroups]
        FOREIGN KEY ([BillingGroupId]) REFERENCES [fac].[BillingGroups] ([BillingGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_DeliveryPreferences_BillingGroupId_BillingGroups'
)
BEGIN
    ALTER TABLE [fac].[DeliveryPreferences]
        ADD CONSTRAINT [FK_fac_DeliveryPreferences_BillingGroupId_BillingGroups]
        FOREIGN KEY ([BillingGroupId]) REFERENCES [fac].[BillingGroups] ([BillingGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesInstallments_BillingGroupId_BillingGroups'
)
BEGIN
    ALTER TABLE [ven].[SalesInstallments]
        ADD CONSTRAINT [FK_ven_SalesInstallments_BillingGroupId_BillingGroups]
        FOREIGN KEY ([BillingGroupId]) REFERENCES [fac].[BillingGroups] ([BillingGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AccountStatements_BillingGroupId_BillingGroups'
)
BEGIN
    ALTER TABLE [cob].[AccountStatements]
        ADD CONSTRAINT [FK_cob_AccountStatements_BillingGroupId_BillingGroups]
        FOREIGN KEY ([BillingGroupId]) REFERENCES [fac].[BillingGroups] ([BillingGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_service_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_service]
        ADD CONSTRAINT [FK_bia_Bi_dim_service_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ApplianceTypes_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ApplianceTypes]
        ADD CONSTRAINT [FK_cat_ApplianceTypes_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceCategoryGroups_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ServiceCategoryGroups]
        ADD CONSTRAINT [FK_cat_ServiceCategoryGroups_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceClasses_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ServiceClasses]
        ADD CONSTRAINT [FK_cat_ServiceClasses_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceConcessions_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ServiceConcessions]
        ADD CONSTRAINT [FK_cat_ServiceConcessions_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServicePlans_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ServicePlans]
        ADD CONSTRAINT [FK_cat_ServicePlans_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceProperties_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cat].[ServiceProperties]
        ADD CONSTRAINT [FK_cat_ServiceProperties_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_OutageNotices_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [com].[OutageNotices]
        ADD CONSTRAINT [FK_com_OutageNotices_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyTemplates_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [com].[SurveyTemplates]
        ADD CONSTRAINT [FK_com_SurveyTemplates_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionReportSchemes_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [cob].[CollectionReportSchemes]
        ADD CONSTRAINT [FK_cob_CollectionReportSchemes_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatLedgerLines_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [fis].[VatLedgerLines]
        ADD CONSTRAINT [FK_fis_VatLedgerLines_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_GuaranteeRequirementRules_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [mor].[GuaranteeRequirementRules]
        ADD CONSTRAINT [FK_mor_GuaranteeRequirementRules_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CreditBalances_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cob].[CreditBalances]
        ADD CONSTRAINT [FK_cob_CreditBalances_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalForms_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [por].[PortalForms]
        ADD CONSTRAINT [FK_por_PortalForms_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingPlans_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [soc].[HousingPlans]
        ADD CONSTRAINT [FK_soc_HousingPlans_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ReorderSuggestions_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [stk].[ReorderSuggestions]
        ADD CONSTRAINT [FK_stk_ReorderSuggestions_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterruptionChargeRules_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [mor].[InterruptionChargeRules]
        ADD CONSTRAINT [FK_mor_InterruptionChargeRules_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_GasCalorificFactors_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tar].[GasCalorificFactors]
        ADD CONSTRAINT [FK_tar_GasCalorificFactors_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_PhoneRatePlans_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tar].[PhoneRatePlans]
        ADD CONSTRAINT [FK_tar_PhoneRatePlans_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_GisExportTemplates_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[GisExportTemplates]
        ADD CONSTRAINT [FK_tec_GisExportTemplates_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Networks_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[Networks]
        ADD CONSTRAINT [FK_tec_Networks_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TaskCatalog_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[TaskCatalog]
        ADD CONSTRAINT [FK_tec_TaskCatalog_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ResolutionCodes_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[ResolutionCodes]
        ADD CONSTRAINT [FK_tec_ResolutionCodes_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitMandates_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitMandates]
        ADD CONSTRAINT [FK_cob_DirectDebitMandates_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_WorkAreas_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [sue].[WorkAreas]
        ADD CONSTRAINT [FK_sue_WorkAreas_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_IncidentCategories_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[IncidentCategories]
        ADD CONSTRAINT [FK_tec_IncidentCategories_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ExternalKeyAliases_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cob].[ExternalKeyAliases]
        ADD CONSTRAINT [FK_cob_ExternalKeyAliases_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BilledPeriods_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [fac].[BilledPeriods]
        ADD CONSTRAINT [FK_fac_BilledPeriods_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceTechnicalProfiles_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[ServiceTechnicalProfiles]
        ADD CONSTRAINT [FK_tec_ServiceTechnicalProfiles_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNoticeModels_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNoticeModels]
        ADD CONSTRAINT [FK_mor_DelinquencyNoticeModels_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ExpenseUnits_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [stk].[ExpenseUnits]
        ADD CONSTRAINT [FK_stk_ExpenseUnits_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderPrintTemplates_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderPrintTemplates]
        ADD CONSTRAINT [FK_tec_WorkOrderPrintTemplates_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_EventChargeBonuses_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tar].[EventChargeBonuses]
        ADD CONSTRAINT [FK_tar_EventChargeBonuses_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_OperationCharges_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [ven].[OperationCharges]
        ADD CONSTRAINT [FK_ven_OperationCharges_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_PrescriptionRules_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [mor].[PrescriptionRules]
        ADD CONSTRAINT [FK_mor_PrescriptionRules_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_MobileUsageImports_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[MobileUsageImports]
        ADD CONSTRAINT [FK_tec_MobileUsageImports_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TechnicalProcedures_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[TechnicalProcedures]
        ADD CONSTRAINT [FK_tec_TechnicalProcedures_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCirculars_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [crm].[CrmCirculars]
        ADD CONSTRAINT [FK_crm_CrmCirculars_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_BudgetLines_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [con].[BudgetLines]
        ADD CONSTRAINT [FK_con_BudgetLines_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ChainedOrderRules_SourceServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[ChainedOrderRules]
        ADD CONSTRAINT [FK_tec_ChainedOrderRules_SourceServiceId_TenantServices]
        FOREIGN KEY ([SourceServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ChainedOrderRules_TargetServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[ChainedOrderRules]
        ADD CONSTRAINT [FK_tec_ChainedOrderRules_TargetServiceId_TenantServices]
        FOREIGN KEY ([TargetServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplyBalances_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [cmp].[SupplyBalances]
        ADD CONSTRAINT [FK_cmp_SupplyBalances_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_InspectionCases_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[InspectionCases]
        ADD CONSTRAINT [FK_tec_InspectionCases_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ResponsibleNotificationRules_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[ResponsibleNotificationRules]
        ADD CONSTRAINT [FK_tec_ResponsibleNotificationRules_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_InvoiceMessages_ServiceIdsId_TenantServices'
)
BEGIN
    ALTER TABLE [com].[InvoiceMessages]
        ADD CONSTRAINT [FK_com_InvoiceMessages_ServiceIdsId_TenantServices]
        FOREIGN KEY ([ServiceIdsId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Works_ServiceId_TenantServices'
)
BEGIN
    ALTER TABLE [tec].[Works]
        ADD CONSTRAINT [FK_tec_Works_ServiceId_TenantServices]
        FOREIGN KEY ([ServiceId]) REFERENCES [cat].[TenantServices] ([TenantServiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractDeclaredAppliances_ApplianceTypeId_ApplianceTypes'
)
BEGIN
    ALTER TABLE [cat].[ContractDeclaredAppliances]
        ADD CONSTRAINT [FK_cat_ContractDeclaredAppliances_ApplianceTypeId_ApplianceTypes]
        FOREIGN KEY ([ApplianceTypeId]) REFERENCES [cat].[ApplianceTypes] ([ApplianceTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceCategories_GroupId_ServiceCategoryGroups'
)
BEGIN
    ALTER TABLE [cat].[ServiceCategories]
        ADD CONSTRAINT [FK_cat_ServiceCategories_GroupId_ServiceCategoryGroups]
        FOREIGN KEY ([GroupId]) REFERENCES [cat].[ServiceCategoryGroups] ([ServiceCategoryGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_category_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_category]
        ADD CONSTRAINT [FK_bia_Bi_dim_category_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseConcepts_AccountingCategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseConcepts]
        ADD CONSTRAINT [FK_cmp_PurchaseConcepts_AccountingCategoryId_ServiceCategories]
        FOREIGN KEY ([AccountingCategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_GuaranteeRequirementRules_CategoryIdsId_ServiceCategories'
)
BEGIN
    ALTER TABLE [mor].[GuaranteeRequirementRules]
        ADD CONSTRAINT [FK_mor_GuaranteeRequirementRules_CategoryIdsId_ServiceCategories]
        FOREIGN KEY ([CategoryIdsId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingStages_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [soc].[HousingStages]
        ADD CONSTRAINT [FK_soc_HousingStages_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_CategoryCoefficients_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [tar].[CategoryCoefficients]
        ADD CONSTRAINT [FK_tar_CategoryCoefficients_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_ProductPrices_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [tar].[ProductPrices]
        ADD CONSTRAINT [FK_tar_ProductPrices_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingPrices_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [soc].[HousingPrices]
        ADD CONSTRAINT [FK_soc_HousingPrices_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryMovements_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [tes].[TreasuryMovements]
        ADD CONSTRAINT [FK_tes_TreasuryMovements_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationRules_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationRules]
        ADD CONSTRAINT [FK_tes_ReconciliationRules_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingPlanChanges_FromCategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [soc].[HousingPlanChanges]
        ADD CONSTRAINT [FK_soc_HousingPlanChanges_FromCategoryId_ServiceCategories]
        FOREIGN KEY ([FromCategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingPlanChanges_ToCategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [soc].[HousingPlanChanges]
        ADD CONSTRAINT [FK_soc_HousingPlanChanges_ToCategoryId_ServiceCategories]
        FOREIGN KEY ([ToCategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceDependents_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [soc].[ServiceDependents]
        ADD CONSTRAINT [FK_soc_ServiceDependents_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingUnits_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [soc].[HousingUnits]
        ADD CONSTRAINT [FK_soc_HousingUnits_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_EventChargeBonuses_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [tar].[EventChargeBonuses]
        ADD CONSTRAINT [FK_tar_EventChargeBonuses_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SeniorityScales_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [sue].[SeniorityScales]
        ADD CONSTRAINT [FK_sue_SeniorityScales_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_AdherentRates_AutoCategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [tar].[AdherentRates]
        ADD CONSTRAINT [FK_tar_AdherentRates_AutoCategoryId_ServiceCategories]
        FOREIGN KEY ([AutoCategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_AdherentRates_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [tar].[AdherentRates]
        ADD CONSTRAINT [FK_tar_AdherentRates_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeAssignments_PreviousCategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [sue].[EmployeeAssignments]
        ADD CONSTRAINT [FK_sue_EmployeeAssignments_PreviousCategoryId_ServiceCategories]
        FOREIGN KEY ([PreviousCategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SimulationResults_CategoryId_ServiceCategories'
)
BEGIN
    ALTER TABLE [tar].[SimulationResults]
        ADD CONSTRAINT [FK_tar_SimulationResults_CategoryId_ServiceCategories]
        FOREIGN KEY ([CategoryId]) REFERENCES [cat].[ServiceCategories] ([ServiceCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingStages_PlanId_ServicePlans'
)
BEGIN
    ALTER TABLE [soc].[HousingStages]
        ADD CONSTRAINT [FK_soc_HousingStages_PlanId_ServicePlans]
        FOREIGN KEY ([PlanId]) REFERENCES [cat].[ServicePlans] ([ServicePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvisioningProfiles_PlanId_ServicePlans'
)
BEGIN
    ALTER TABLE [tec].[ProvisioningProfiles]
        ADD CONSTRAINT [FK_tec_ProvisioningProfiles_PlanId_ServicePlans]
        FOREIGN KEY ([PlanId]) REFERENCES [cat].[ServicePlans] ([ServicePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingPrices_PlanId_ServicePlans'
)
BEGIN
    ALTER TABLE [soc].[HousingPrices]
        ADD CONSTRAINT [FK_soc_HousingPrices_PlanId_ServicePlans]
        FOREIGN KEY ([PlanId]) REFERENCES [cat].[ServicePlans] ([ServicePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementSimulations_PlanId_ServicePlans'
)
BEGIN
    ALTER TABLE [mor].[AgreementSimulations]
        ADD CONSTRAINT [FK_mor_AgreementSimulations_PlanId_ServicePlans]
        FOREIGN KEY ([PlanId]) REFERENCES [cat].[ServicePlans] ([ServicePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingUnits_PlanId_ServicePlans'
)
BEGIN
    ALTER TABLE [soc].[HousingUnits]
        ADD CONSTRAINT [FK_soc_HousingUnits_PlanId_ServicePlans]
        FOREIGN KEY ([PlanId]) REFERENCES [cat].[ServicePlans] ([ServicePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneLines_TariffPlanId_ServicePlans'
)
BEGIN
    ALTER TABLE [tec].[PhoneLines]
        ADD CONSTRAINT [FK_tec_PhoneLines_TariffPlanId_ServicePlans]
        FOREIGN KEY ([TariffPlanId]) REFERENCES [cat].[ServicePlans] ([ServicePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ProviderAgreements_PlanIdsId_ServicePlans'
)
BEGIN
    ALTER TABLE [soc].[ProviderAgreements]
        ADD CONSTRAINT [FK_soc_ProviderAgreements_PlanIdsId_ServicePlans]
        FOREIGN KEY ([PlanIdsId]) REFERENCES [cat].[ServicePlans] ([ServicePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollAccountingRules_AccountingPlanId_ServicePlans'
)
BEGIN
    ALTER TABLE [sue].[PayrollAccountingRules]
        ADD CONSTRAINT [FK_sue_PayrollAccountingRules_AccountingPlanId_ServicePlans]
        FOREIGN KEY ([AccountingPlanId]) REFERENCES [cat].[ServicePlans] ([ServicePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_OutagePlans_OutageNoticeId_OutageNotices'
)
BEGIN
    ALTER TABLE [tec].[OutagePlans]
        ADD CONSTRAINT [FK_tec_OutagePlans_OutageNoticeId_OutageNotices]
        FOREIGN KEY ([OutageNoticeId]) REFERENCES [com].[OutageNotices] ([OutageNoticeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_invoice_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_invoice]
        ADD CONSTRAINT [FK_bia_Bi_fact_invoice_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmHourBanks_SaleRefId_Invoices'
)
BEGIN
    ALTER TABLE [crm].[CrmHourBanks]
        ADD CONSTRAINT [FK_crm_CrmHourBanks_SaleRefId_Invoices]
        FOREIGN KEY ([SaleRefId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_PaymentSlips_InvoiceIdsId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[PaymentSlips]
        ADD CONSTRAINT [FK_fac_PaymentSlips_InvoiceIdsId_Invoices]
        FOREIGN KEY ([InvoiceIdsId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_invoiceLine_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_invoiceLine]
        ADD CONSTRAINT [FK_bia_Bi_fact_invoiceLine_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_RoundingCarryEntries_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [tar].[RoundingCarryEntries]
        ADD CONSTRAINT [FK_tar_RoundingCarryEntries_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BilledPeriods_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[BilledPeriods]
        ADD CONSTRAINT [FK_fac_BilledPeriods_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyCharges_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyCharges]
        ADD CONSTRAINT [FK_fis_ThirdPartyCharges_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDocuments_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDocuments]
        ADD CONSTRAINT [FK_fac_InvoiceDocuments_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceAnnulmentRequests_InvoiceIdsId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[InvoiceAnnulmentRequests]
        ADD CONSTRAINT [FK_fac_InvoiceAnnulmentRequests_InvoiceIdsId_Invoices]
        FOREIGN KEY ([InvoiceIdsId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDeliveries_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDeliveries]
        ADD CONSTRAINT [FK_fac_InvoiceDeliveries_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceExternalData_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [fac].[InvoiceExternalData]
        ADD CONSTRAINT [FK_fac_InvoiceExternalData_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingContributions_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [soc].[HousingContributions]
        ADD CONSTRAINT [FK_soc_HousingContributions_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_allocation_InvoiceId_Invoices'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_allocation]
        ADD CONSTRAINT [FK_bia_Bi_fact_allocation_InvoiceId_Invoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_PurchaseInvoiceRefId_Invoices'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_PurchaseInvoiceRefId_Invoices]
        FOREIGN KEY ([PurchaseInvoiceRefId]) REFERENCES [fac].[Invoices] ([InvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BillableConcepts_FiscalClassId_FiscalClasses'
)
BEGIN
    ALTER TABLE [cat].[BillableConcepts]
        ADD CONSTRAINT [FK_cat_BillableConcepts_FiscalClassId_FiscalClasses]
        FOREIGN KEY ([FiscalClassId]) REFERENCES [fis].[FiscalClasses] ([FiscalClassId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ConceptFiscalCases_NormativeVersionId_NormativeTableVersions'
)
BEGIN
    ALTER TABLE [fis].[ConceptFiscalCases]
        ADD CONSTRAINT [FK_fis_ConceptFiscalCases_NormativeVersionId_NormativeTableVersions]
        FOREIGN KEY ([NormativeVersionId]) REFERENCES [fis].[NormativeTableVersions] ([NormativeTableVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_NormativeAdoptions_PlatformVersionId_NormativeTableVersions'
)
BEGIN
    ALTER TABLE [fis].[NormativeAdoptions]
        ADD CONSTRAINT [FK_fis_NormativeAdoptions_PlatformVersionId_NormativeTableVersions]
        FOREIGN KEY ([PlatformVersionId]) REFERENCES [fis].[NormativeTableVersions] ([NormativeTableVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatRates_ArcaVatId_NormativeTables'
)
BEGIN
    ALTER TABLE [fis].[VatRates]
        ADD CONSTRAINT [FK_fis_VatRates_ArcaVatId_NormativeTables]
        FOREIGN KEY ([ArcaVatId]) REFERENCES [fis].[NormativeTables] ([NormativeTableId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_ActivityId_NormativeTables'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts]
        ADD CONSTRAINT [FK_cat_ServiceContracts_ActivityId_NormativeTables]
        FOREIGN KEY ([ActivityId]) REFERENCES [fis].[NormativeTables] ([NormativeTableId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingRunNumberRanges_PointOfSaleId_PointsOfSale'
)
BEGIN
    ALTER TABLE [fac].[BillingRunNumberRanges]
        ADD CONSTRAINT [FK_fac_BillingRunNumberRanges_PointOfSaleId_PointsOfSale]
        FOREIGN KEY ([PointOfSaleId]) REFERENCES [fis].[PointsOfSale] ([PointsOfSaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_NumberSequences_PointOfSaleId_PointsOfSale'
)
BEGIN
    ALTER TABLE [fac].[NumberSequences]
        ADD CONSTRAINT [FK_fac_NumberSequences_PointOfSaleId_PointsOfSale]
        FOREIGN KEY ([PointOfSaleId]) REFERENCES [fis].[PointsOfSale] ([PointsOfSaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_CespAuthorizations_PointOfSaleId_PointsOfSale'
)
BEGIN
    ALTER TABLE [fis].[CespAuthorizations]
        ADD CONSTRAINT [FK_fis_CespAuthorizations_PointOfSaleId_PointsOfSale]
        FOREIGN KEY ([PointOfSaleId]) REFERENCES [fis].[PointsOfSale] ([PointsOfSaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ProvincialValidationCodes_PointOfSaleId_PointsOfSale'
)
BEGIN
    ALTER TABLE [fis].[ProvincialValidationCodes]
        ADD CONSTRAINT [FK_fis_ProvincialValidationCodes_PointOfSaleId_PointsOfSale]
        FOREIGN KEY ([PointOfSaleId]) REFERENCES [fis].[PointsOfSale] ([PointsOfSaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_FiscalAuthorizations_PointOfSaleId_PointsOfSale'
)
BEGIN
    ALTER TABLE [fis].[FiscalAuthorizations]
        ADD CONSTRAINT [FK_fis_FiscalAuthorizations_PointOfSaleId_PointsOfSale]
        FOREIGN KEY ([PointOfSaleId]) REFERENCES [fis].[PointsOfSale] ([PointsOfSaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosTerminals_PointOfSaleId_PointsOfSale'
)
BEGIN
    ALTER TABLE [ven].[PosTerminals]
        ADD CONSTRAINT [FK_ven_PosTerminals_PointOfSaleId_PointsOfSale]
        FOREIGN KEY ([PointOfSaleId]) REFERENCES [fis].[PointsOfSale] ([PointsOfSaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_FiscalDeadlines_FilingId_RegimeFilings'
)
BEGIN
    ALTER TABLE [fis].[FiscalDeadlines]
        ADD CONSTRAINT [FK_fis_FiscalDeadlines_FilingId_RegimeFilings]
        FOREIGN KEY ([FilingId]) REFERENCES [fis].[RegimeFilings] ([RegimeFilingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingsApplied_FilingId_RegimeFilings'
)
BEGIN
    ALTER TABLE [fis].[WithholdingsApplied]
        ADD CONSTRAINT [FK_fis_WithholdingsApplied_FilingId_RegimeFilings]
        FOREIGN KEY ([FilingId]) REFERENCES [fis].[RegimeFilings] ([RegimeFilingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxObligations_TaxAgentRegistrationId_TaxAgentRegistrations'
)
BEGIN
    ALTER TABLE [fis].[TaxObligations]
        ADD CONSTRAINT [FK_fis_TaxObligations_TaxAgentRegistrationId_TaxAgentRegistrations]
        FOREIGN KEY ([TaxAgentRegistrationId]) REFERENCES [fis].[TaxAgentRegistrations] ([TaxAgentRegistrationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingTypes_TaxAgentRegistrationId_TaxAgentRegistrations'
)
BEGIN
    ALTER TABLE [fis].[WithholdingTypes]
        ADD CONSTRAINT [FK_fis_WithholdingTypes_TaxAgentRegistrationId_TaxAgentRegistrations]
        FOREIGN KEY ([TaxAgentRegistrationId]) REFERENCES [fis].[TaxAgentRegistrations] ([TaxAgentRegistrationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionReportSchemes_TaxIdsId_TaxDefinitions'
)
BEGIN
    ALTER TABLE [cob].[CollectionReportSchemes]
        ADD CONSTRAINT [FK_cob_CollectionReportSchemes_TaxIdsId_TaxDefinitions]
        FOREIGN KEY ([TaxIdsId]) REFERENCES [fis].[TaxDefinitions] ([TaxDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatRateMatrix_PerceptionTaxId_TaxDefinitions'
)
BEGIN
    ALTER TABLE [fis].[VatRateMatrix]
        ADD CONSTRAINT [FK_fis_VatRateMatrix_PerceptionTaxId_TaxDefinitions]
        FOREIGN KEY ([PerceptionTaxId]) REFERENCES [fis].[TaxDefinitions] ([TaxDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestPolicies_BaseExcludedTaxIdsId_TaxDefinitions'
)
BEGIN
    ALTER TABLE [mor].[InterestPolicies]
        ADD CONSTRAINT [FK_mor_InterestPolicies_BaseExcludedTaxIdsId_TaxDefinitions]
        FOREIGN KEY ([BaseExcludedTaxIdsId]) REFERENCES [fis].[TaxDefinitions] ([TaxDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestPolicies_BaseTaxIdsId_TaxDefinitions'
)
BEGIN
    ALTER TABLE [mor].[InterestPolicies]
        ADD CONSTRAINT [FK_mor_InterestPolicies_BaseTaxIdsId_TaxDefinitions]
        FOREIGN KEY ([BaseTaxIdsId]) REFERENCES [fis].[TaxDefinitions] ([TaxDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_TariffCategoryRates_TaxIdsId_TaxDefinitions'
)
BEGIN
    ALTER TABLE [tar].[TariffCategoryRates]
        ADD CONSTRAINT [FK_tar_TariffCategoryRates_TaxIdsId_TaxDefinitions]
        FOREIGN KEY ([TaxIdsId]) REFERENCES [fis].[TaxDefinitions] ([TaxDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_TariffRows_TaxIdsId_TaxDefinitions'
)
BEGIN
    ALTER TABLE [tar].[TariffRows]
        ADD CONSTRAINT [FK_tar_TariffRows_TaxIdsId_TaxDefinitions]
        FOREIGN KEY ([TaxIdsId]) REFERENCES [fis].[TaxDefinitions] ([TaxDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_ProductPrices_TaxIdsId_TaxDefinitions'
)
BEGIN
    ALTER TABLE [tar].[ProductPrices]
        ADD CONSTRAINT [FK_tar_ProductPrices_TaxIdsId_TaxDefinitions]
        FOREIGN KEY ([TaxIdsId]) REFERENCES [fis].[TaxDefinitions] ([TaxDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_VoucherResolutionRules_VatConditionSettingId_VatConditionSettings'
)
BEGIN
    ALTER TABLE [fac].[VoucherResolutionRules]
        ADD CONSTRAINT [FK_fac_VoucherResolutionRules_VatConditionSettingId_VatConditionSettings]
        FOREIGN KEY ([VatConditionSettingId]) REFERENCES [fis].[VatConditionSettings] ([VatConditionSettingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatRateMatrix_VatConditionSettingId_VatConditionSettings'
)
BEGIN
    ALTER TABLE [fis].[VatRateMatrix]
        ADD CONSTRAINT [FK_fis_VatRateMatrix_VatConditionSettingId_VatConditionSettings]
        FOREIGN KEY ([VatConditionSettingId]) REFERENCES [fis].[VatConditionSettings] ([VatConditionSettingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestPolicies_FiscalDefaultVatSituationId_VatConditionSettings'
)
BEGIN
    ALTER TABLE [mor].[InterestPolicies]
        ADD CONSTRAINT [FK_mor_InterestPolicies_FiscalDefaultVatSituationId_VatConditionSettings]
        FOREIGN KEY ([FiscalDefaultVatSituationId]) REFERENCES [fis].[VatConditionSettings] ([VatConditionSettingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatLedgerLines_LedgerId_VatLedgers'
)
BEGIN
    ALTER TABLE [fis].[VatLedgerLines]
        ADD CONSTRAINT [FK_fis_VatLedgerLines_LedgerId_VatLedgers]
        FOREIGN KEY ([LedgerId]) REFERENCES [fis].[VatLedgers] ([VatLedgerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatReconciliations_LedgerId_VatLedgers'
)
BEGIN
    ALTER TABLE [fis].[VatReconciliations]
        ADD CONSTRAINT [FK_fis_VatReconciliations_LedgerId_VatLedgers]
        FOREIGN KEY ([LedgerId]) REFERENCES [fis].[VatLedgers] ([VatLedgerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseConcepts_VatRateId_VatRates'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseConcepts]
        ADD CONSTRAINT [FK_cmp_PurchaseConcepts_VatRateId_VatRates]
        FOREIGN KEY ([VatRateId]) REFERENCES [fis].[VatRates] ([VatRateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatRateMatrix_VatRateId_VatRates'
)
BEGIN
    ALTER TABLE [fis].[VatRateMatrix]
        ADD CONSTRAINT [FK_fis_VatRateMatrix_VatRateId_VatRates]
        FOREIGN KEY ([VatRateId]) REFERENCES [fis].[VatRates] ([VatRateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FuelTypes_VatRateId_VatRates'
)
BEGIN
    ALTER TABLE [soc].[FuelTypes]
        ADD CONSTRAINT [FK_soc_FuelTypes_VatRateId_VatRates]
        FOREIGN KEY ([VatRateId]) REFERENCES [fis].[VatRates] ([VatRateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_ProductPrices_TaxRateIdsId_VatRates'
)
BEGIN
    ALTER TABLE [tar].[ProductPrices]
        ADD CONSTRAINT [FK_tar_ProductPrices_TaxRateIdsId_VatRates]
        FOREIGN KEY ([TaxRateIdsId]) REFERENCES [fis].[VatRates] ([VatRateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_EntityAccountAssignments_EntityId_VatRates'
)
BEGIN
    ALTER TABLE [con].[EntityAccountAssignments]
        ADD CONSTRAINT [FK_con_EntityAccountAssignments_EntityId_VatRates]
        FOREIGN KEY ([EntityId]) REFERENCES [fis].[VatRates] ([VatRateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierAdvances_ConceptId_PurchaseConcepts'
)
BEGIN
    ALTER TABLE [cmp].[SupplierAdvances]
        ADD CONSTRAINT [FK_cmp_SupplierAdvances_ConceptId_PurchaseConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cmp].[PurchaseConcepts] ([PurchaseConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_FederatedLinks_IdpConfigId_IdentityProviderConfigs'
)
BEGIN
    ALTER TABLE [iam].[FederatedLinks]
        ADD CONSTRAINT [FK_iam_FederatedLinks_IdpConfigId_IdentityProviderConfigs]
        FOREIGN KEY ([IdpConfigId]) REFERENCES [iam].[IdentityProviderConfigs] ([IdentityProviderConfigId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_uxd_PwaNavConfigs_ScreenProfileId_ScreenProfiles'
)
BEGIN
    ALTER TABLE [uxd].[PwaNavConfigs]
        ADD CONSTRAINT [FK_uxd_PwaNavConfigs_ScreenProfileId_ScreenProfiles]
        FOREIGN KEY ([ScreenProfileId]) REFERENCES [iam].[ScreenProfiles] ([ScreenProfileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ProfileAssignments_ScreenProfileId_ScreenProfiles'
)
BEGIN
    ALTER TABLE [iam].[ProfileAssignments]
        ADD CONSTRAINT [FK_iam_ProfileAssignments_ScreenProfileId_ScreenProfiles]
        FOREIGN KEY ([ScreenProfileId]) REFERENCES [iam].[ScreenProfiles] ([ScreenProfileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_SodExceptions_SodRuleId_SodRules'
)
BEGIN
    ALTER TABLE [iam].[SodExceptions]
        ADD CONSTRAINT [FK_iam_SodExceptions_SodRuleId_SodRules]
        FOREIGN KEY ([SodRuleId]) REFERENCES [iam].[SodRules] ([SodRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_Sessions_SupportGrantId_SupportAccessGrants'
)
BEGIN
    ALTER TABLE [iam].[Sessions]
        ADD CONSTRAINT [FK_iam_Sessions_SupportGrantId_SupportAccessGrants]
        FOREIGN KEY ([SupportGrantId]) REFERENCES [iam].[SupportAccessGrants] ([SupportAccessGrantId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_AssociateMemberships_ElectoralDistrictId_ElectoralDistricts'
)
BEGIN
    ALTER TABLE [ins].[AssociateMemberships]
        ADD CONSTRAINT [FK_ins_AssociateMemberships_ElectoralDistrictId_ElectoralDistricts]
        FOREIGN KEY ([ElectoralDistrictId]) REFERENCES [ins].[ElectoralDistricts] ([ElectoralDistrictId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_RosterEntries_DistrictId_ElectoralDistricts'
)
BEGIN
    ALTER TABLE [ins].[RosterEntries]
        ADD CONSTRAINT [FK_ins_RosterEntries_DistrictId_ElectoralDistricts]
        FOREIGN KEY ([DistrictId]) REFERENCES [ins].[ElectoralDistricts] ([ElectoralDistrictId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFees_BodyId_GovernanceBodies'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFees]
        ADD CONSTRAINT [FK_ins_InstitutionalFees_BodyId_GovernanceBodies]
        FOREIGN KEY ([BodyId]) REFERENCES [ins].[GovernanceBodies] ([GovernanceBodyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_BodyMandates_BodyId_GovernanceBodies'
)
BEGIN
    ALTER TABLE [ins].[BodyMandates]
        ADD CONSTRAINT [FK_ins_BodyMandates_BodyId_GovernanceBodies]
        FOREIGN KEY ([BodyId]) REFERENCES [ins].[GovernanceBodies] ([GovernanceBodyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Meetings_BodyId_GovernanceBodies'
)
BEGIN
    ALTER TABLE [ins].[Meetings]
        ADD CONSTRAINT [FK_ins_Meetings_BodyId_GovernanceBodies]
        FOREIGN KEY ([BodyId]) REFERENCES [ins].[GovernanceBodies] ([GovernanceBodyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_AssociateMemberships_InaesCategoryId_InaesCategories'
)
BEGIN
    ALTER TABLE [ins].[AssociateMemberships]
        ADD CONSTRAINT [FK_ins_AssociateMemberships_InaesCategoryId_InaesCategories]
        FOREIGN KEY ([InaesCategoryId]) REFERENCES [ins].[InaesCategories] ([InaesCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerAccounts_InaesCategoryId_InaesCategories'
)
BEGIN
    ALTER TABLE [con].[LedgerAccounts]
        ADD CONSTRAINT [FK_con_LedgerAccounts_InaesCategoryId_InaesCategories]
        FOREIGN KEY ([InaesCategoryId]) REFERENCES [ins].[InaesCategories] ([InaesCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_InformationRegimes_FileLayoutId_FileLayouts'
)
BEGIN
    ALTER TABLE [fis].[InformationRegimes]
        ADD CONSTRAINT [FK_fis_InformationRegimes_FileLayoutId_FileLayouts]
        FOREIGN KEY ([FileLayoutId]) REFERENCES [int].[FileLayouts] ([FileLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExternalPayrollLayouts_FileLayoutId_FileLayouts'
)
BEGIN
    ALTER TABLE [sue].[ExternalPayrollLayouts]
        ADD CONSTRAINT [FK_sue_ExternalPayrollLayouts_FileLayoutId_FileLayouts]
        FOREIGN KEY ([FileLayoutId]) REFERENCES [int].[FileLayouts] ([FileLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ExternalLedgerTransfers_FileLayoutId_FileLayouts'
)
BEGIN
    ALTER TABLE [con].[ExternalLedgerTransfers]
        ADD CONSTRAINT [FK_con_ExternalLedgerTransfers_FileLayoutId_FileLayouts]
        FOREIGN KEY ([FileLayoutId]) REFERENCES [int].[FileLayouts] ([FileLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Unions_FileLayoutId_FileLayouts'
)
BEGIN
    ALTER TABLE [sue].[Unions]
        ADD CONSTRAINT [FK_sue_Unions_FileLayoutId_FileLayouts]
        FOREIGN KEY ([FileLayoutId]) REFERENCES [int].[FileLayouts] ([FileLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionAgencies_ControlLayoutId_FileLayouts'
)
BEGIN
    ALTER TABLE [cob].[CollectionAgencies]
        ADD CONSTRAINT [FK_cob_CollectionAgencies_ControlLayoutId_FileLayouts]
        FOREIGN KEY ([ControlLayoutId]) REFERENCES [int].[FileLayouts] ([FileLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionAgencies_ExportLayoutId_FileLayouts'
)
BEGIN
    ALTER TABLE [cob].[CollectionAgencies]
        ADD CONSTRAINT [FK_cob_CollectionAgencies_ExportLayoutId_FileLayouts]
        FOREIGN KEY ([ExportLayoutId]) REFERENCES [int].[FileLayouts] ([FileLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionAgencies_FileLayoutIdsId_FileLayouts'
)
BEGIN
    ALTER TABLE [cob].[CollectionAgencies]
        ADD CONSTRAINT [FK_cob_CollectionAgencies_FileLayoutIdsId_FileLayouts]
        FOREIGN KEY ([FileLayoutIdsId]) REFERENCES [int].[FileLayouts] ([FileLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionAgencies_ImportLayoutId_FileLayouts'
)
BEGIN
    ALTER TABLE [cob].[CollectionAgencies]
        ADD CONSTRAINT [FK_cob_CollectionAgencies_ImportLayoutId_FileLayouts]
        FOREIGN KEY ([ImportLayoutId]) REFERENCES [int].[FileLayouts] ([FileLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationFileExchanges_FileLayoutId_FileLayouts'
)
BEGIN
    ALTER TABLE [int].[IntegrationFileExchanges]
        ADD CONSTRAINT [FK_int_IntegrationFileExchanges_FileLayoutId_FileLayouts]
        FOREIGN KEY ([FileLayoutId]) REFERENCES [int].[FileLayouts] ([FileLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ChannelSettings_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [com].[ChannelSettings]
        ADD CONSTRAINT [FK_com_ChannelSettings_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ModerationPolicies_AiConnectorId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [com].[ModerationPolicies]
        ADD CONSTRAINT [FK_com_ModerationPolicies_AiConnectorId_IntegrationConnections]
        FOREIGN KEY ([AiConnectorId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SenderIdentities_ConnectorId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [com].[SenderIdentities]
        ADD CONSTRAINT [FK_com_SenderIdentities_ConnectorId_IntegrationConnections]
        FOREIGN KEY ([ConnectorId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationTokens_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[IntegrationTokens]
        ADD CONSTRAINT [FK_int_IntegrationTokens_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_WebhookEndpoints_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[WebhookEndpoints]
        ADD CONSTRAINT [FK_int_WebhookEndpoints_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_WebhookInbox_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[WebhookInbox]
        ADD CONSTRAINT [FK_int_WebhookInbox_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeteringSystems_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [med].[MeteringSystems]
        ADD CONSTRAINT [FK_med_MeteringSystems_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunicationAttempts_ConnectorId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [com].[CommunicationAttempts]
        ADD CONSTRAINT [FK_com_CommunicationAttempts_ConnectorId_IntegrationConnections]
        FOREIGN KEY ([ConnectorId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvisioningSystems_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [tec].[ProvisioningSystems]
        ADD CONSTRAINT [FK_tec_ProvisioningSystems_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvisioningSystems_ConnectorId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [tec].[ProvisioningSystems]
        ADD CONSTRAINT [FK_tec_ProvisioningSystems_ConnectorId_IntegrationConnections]
        FOREIGN KEY ([ConnectorId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureProfiles_ProviderConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [wfl].[SignatureProfiles]
        ADD CONSTRAINT [FK_wfl_SignatureProfiles_ProviderConnectionId_IntegrationConnections]
        FOREIGN KEY ([ProviderConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_AiUsageLogs_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[AiUsageLogs]
        ADD CONSTRAINT [FK_int_AiUsageLogs_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationAlerts_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[IntegrationAlerts]
        ADD CONSTRAINT [FK_int_IntegrationAlerts_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayConnectors_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [cob].[GatewayConnectors]
        ADD CONSTRAINT [FK_cob_GatewayConnectors_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationContingencies_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[IntegrationContingencies]
        ADD CONSTRAINT [FK_int_IntegrationContingencies_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationReconciliations_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[IntegrationReconciliations]
        ADD CONSTRAINT [FK_int_IntegrationReconciliations_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationFileExchanges_ConnectionId_IntegrationConnections'
)
BEGIN
    ALTER TABLE [int].[IntegrationFileExchanges]
        ADD CONSTRAINT [FK_int_IntegrationFileExchanges_ConnectionId_IntegrationConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [int].[IntegrationConnections] ([IntegrationConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ModerationRules_PolicyId_ModerationPolicies'
)
BEGIN
    ALTER TABLE [com].[ModerationRules]
        ADD CONSTRAINT [FK_com_ModerationRules_PolicyId_ModerationPolicies]
        FOREIGN KEY ([PolicyId]) REFERENCES [com].[ModerationPolicies] ([ModerationPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_RemoteMeterOperations_IntegrationOperationId_IntegrationOperations'
)
BEGIN
    ALTER TABLE [med].[RemoteMeterOperations]
        ADD CONSTRAINT [FK_med_RemoteMeterOperations_IntegrationOperationId_IntegrationOperations]
        FOREIGN KEY ([IntegrationOperationId]) REFERENCES [int].[IntegrationOperations] ([IntegrationOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunicationAttempts_IntOperationId_IntegrationOperations'
)
BEGIN
    ALTER TABLE [com].[CommunicationAttempts]
        ADD CONSTRAINT [FK_com_CommunicationAttempts_IntOperationId_IntegrationOperations]
        FOREIGN KEY ([IntOperationId]) REFERENCES [int].[IntegrationOperations] ([IntegrationOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaSubmissions_IntegrationOperationId_IntegrationOperations'
)
BEGIN
    ALTER TABLE [fis].[ArcaSubmissions]
        ADD CONSTRAINT [FK_fis_ArcaSubmissions_IntegrationOperationId_IntegrationOperations]
        FOREIGN KEY ([IntegrationOperationId]) REFERENCES [int].[IntegrationOperations] ([IntegrationOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaCredentials_CredentialRefId_IntegrationSecrets'
)
BEGIN
    ALTER TABLE [fis].[ArcaCredentials]
        ADD CONSTRAINT [FK_fis_ArcaCredentials_CredentialRefId_IntegrationSecrets]
        FOREIGN KEY ([CredentialRefId]) REFERENCES [int].[IntegrationSecrets] ([IntegrationSecretId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationCertificates_PrivateKeySecretId_IntegrationSecrets'
)
BEGIN
    ALTER TABLE [int].[IntegrationCertificates]
        ADD CONSTRAINT [FK_int_IntegrationCertificates_PrivateKeySecretId_IntegrationSecrets]
        FOREIGN KEY ([PrivateKeySecretId]) REFERENCES [int].[IntegrationSecrets] ([IntegrationSecretId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeteringSystems_CredentialRefId_IntegrationSecrets'
)
BEGIN
    ALTER TABLE [med].[MeteringSystems]
        ADD CONSTRAINT [FK_med_MeteringSystems_CredentialRefId_IntegrationSecrets]
        FOREIGN KEY ([CredentialRefId]) REFERENCES [int].[IntegrationSecrets] ([IntegrationSecretId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaAccessTickets_ArcaCredentialId_ArcaCredentials'
)
BEGIN
    ALTER TABLE [fis].[ArcaAccessTickets]
        ADD CONSTRAINT [FK_fis_ArcaAccessTickets_ArcaCredentialId_ArcaCredentials]
        FOREIGN KEY ([ArcaCredentialId]) REFERENCES [fis].[ArcaCredentials] ([ArcaCredentialId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_WebhookInbox_EndpointId_WebhookEndpoints'
)
BEGIN
    ALTER TABLE [int].[WebhookInbox]
        ADD CONSTRAINT [FK_int_WebhookInbox_EndpointId_WebhookEndpoints]
        FOREIGN KEY ([EndpointId]) REFERENCES [int].[WebhookEndpoints] ([WebhookEndpointId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeterTypes_BrandId_MeterBrands'
)
BEGIN
    ALTER TABLE [med].[MeterTypes]
        ADD CONSTRAINT [FK_med_MeterTypes_BrandId_MeterBrands]
        FOREIGN KEY ([BrandId]) REFERENCES [med].[MeterBrands] ([MeterBrandId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_Meters_BrandId_MeterBrands'
)
BEGIN
    ALTER TABLE [med].[Meters]
        ADD CONSTRAINT [FK_med_Meters_BrandId_MeterBrands]
        FOREIGN KEY ([BrandId]) REFERENCES [med].[MeterBrands] ([MeterBrandId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_Meters_CurrentInstallationId_MeterInstallations'
)
BEGIN
    ALTER TABLE [med].[Meters]
        ADD CONSTRAINT [FK_med_Meters_CurrentInstallationId_MeterInstallations]
        FOREIGN KEY ([CurrentInstallationId]) REFERENCES [med].[MeterInstallations] ([MeterInstallationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeterTypes_MeteringSystemId_MeteringSystems'
)
BEGIN
    ALTER TABLE [med].[MeterTypes]
        ADD CONSTRAINT [FK_med_MeterTypes_MeteringSystemId_MeteringSystems]
        FOREIGN KEY ([MeteringSystemId]) REFERENCES [med].[MeteringSystems] ([MeteringSystemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_Meters_MeterTypeId_MeterTypes'
)
BEGIN
    ALTER TABLE [med].[Meters]
        ADD CONSTRAINT [FK_med_Meters_MeterTypeId_MeterTypes]
        FOREIGN KEY ([MeterTypeId]) REFERENCES [med].[MeterTypes] ([MeterTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ReadingImportJobs_BatchId_ReadingBatches'
)
BEGIN
    ALTER TABLE [med].[ReadingImportJobs]
        ADD CONSTRAINT [FK_med_ReadingImportJobs_BatchId_ReadingBatches]
        FOREIGN KEY ([BatchId]) REFERENCES [med].[ReadingBatches] ([ReadingBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ReadingImportJobs_ProfileId_ReadingImportProfiles'
)
BEGIN
    ALTER TABLE [med].[ReadingImportJobs]
        ADD CONSTRAINT [FK_med_ReadingImportJobs_ProfileId_ReadingImportProfiles]
        FOREIGN KEY ([ProfileId]) REFERENCES [med].[ReadingImportProfiles] ([ReadingImportProfileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_CutoverPlans_FinalSnapshotId_LegacySnapshots'
)
BEGIN
    ALTER TABLE [mig].[CutoverPlans]
        ADD CONSTRAINT [FK_mig_CutoverPlans_FinalSnapshotId_LegacySnapshots]
        FOREIGN KEY ([FinalSnapshotId]) REFERENCES [mig].[LegacySnapshots] ([LegacySnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationIssues_SnapshotId_LegacySnapshots'
)
BEGIN
    ALTER TABLE [mig].[MigrationIssues]
        ADD CONSTRAINT [FK_mig_MigrationIssues_SnapshotId_LegacySnapshots]
        FOREIGN KEY ([SnapshotId]) REFERENCES [mig].[LegacySnapshots] ([LegacySnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationMappingRules_MappingSetId_MigrationMappingSets'
)
BEGIN
    ALTER TABLE [mig].[MigrationMappingRules]
        ADD CONSTRAINT [FK_mig_MigrationMappingRules_MappingSetId_MigrationMappingSets]
        FOREIGN KEY ([MappingSetId]) REFERENCES [mig].[MigrationMappingSets] ([MigrationMappingSetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationValueMaps_MappingSetId_MigrationMappingSets'
)
BEGIN
    ALTER TABLE [mig].[MigrationValueMaps]
        ADD CONSTRAINT [FK_mig_MigrationValueMaps_MappingSetId_MigrationMappingSets]
        FOREIGN KEY ([MappingSetId]) REFERENCES [mig].[MigrationMappingSets] ([MigrationMappingSetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationIssues_RuleId_MigrationMappingRules'
)
BEGIN
    ALTER TABLE [mig].[MigrationIssues]
        ADD CONSTRAINT [FK_mig_MigrationIssues_RuleId_MigrationMappingRules]
        FOREIGN KEY ([RuleId]) REFERENCES [mig].[MigrationMappingRules] ([MigrationMappingRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationBatches_RunId_MigrationRuns'
)
BEGIN
    ALTER TABLE [mig].[MigrationBatches]
        ADD CONSTRAINT [FK_mig_MigrationBatches_RunId_MigrationRuns]
        FOREIGN KEY ([RunId]) REFERENCES [mig].[MigrationRuns] ([MigrationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LegacyPortalImports_MigrationRunId_MigrationRuns'
)
BEGIN
    ALTER TABLE [por].[LegacyPortalImports]
        ADD CONSTRAINT [FK_por_LegacyPortalImports_MigrationRunId_MigrationRuns]
        FOREIGN KEY ([MigrationRunId]) REFERENCES [mig].[MigrationRuns] ([MigrationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_RollbackJournal_RunId_MigrationRuns'
)
BEGIN
    ALTER TABLE [mig].[RollbackJournal]
        ADD CONSTRAINT [FK_mig_RollbackJournal_RunId_MigrationRuns]
        FOREIGN KEY ([RunId]) REFERENCES [mig].[MigrationRuns] ([MigrationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationIssues_RunId_MigrationRuns'
)
BEGIN
    ALTER TABLE [mig].[MigrationIssues]
        ADD CONSTRAINT [FK_mig_MigrationIssues_RunId_MigrationRuns]
        FOREIGN KEY ([RunId]) REFERENCES [mig].[MigrationRuns] ([MigrationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_LegacyAuditRecords_ImportBatchId_MigrationBatches'
)
BEGIN
    ALTER TABLE [iam].[LegacyAuditRecords]
        ADD CONSTRAINT [FK_iam_LegacyAuditRecords_ImportBatchId_MigrationBatches]
        FOREIGN KEY ([ImportBatchId]) REFERENCES [mig].[MigrationBatches] ([MigrationBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_ImportBatchId_MigrationBatches'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders]
        ADD CONSTRAINT [FK_ven_SalesOrders_ImportBatchId_MigrationBatches]
        FOREIGN KEY ([ImportBatchId]) REFERENCES [mig].[MigrationBatches] ([MigrationBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyStages_PolicyId_DelinquencyPolicies'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyStages]
        ADD CONSTRAINT [FK_mor_DelinquencyStages_PolicyId_DelinquencyPolicies]
        FOREIGN KEY ([PolicyId]) REFERENCES [mor].[DelinquencyPolicies] ([DelinquencyPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyBatches_PolicyId_DelinquencyPolicies'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyBatches]
        ADD CONSTRAINT [FK_mor_DelinquencyBatches_PolicyId_DelinquencyPolicies]
        FOREIGN KEY ([PolicyId]) REFERENCES [mor].[DelinquencyPolicies] ([DelinquencyPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyExceptions_ReasonId_DelinquencyReasons'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyExceptions]
        ADD CONSTRAINT [FK_mor_DelinquencyExceptions_ReasonId_DelinquencyReasons]
        FOREIGN KEY ([ReasonId]) REFERENCES [mor].[DelinquencyReasons] ([DelinquencyReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyBatches_StageId_DelinquencyStages'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyBatches]
        ADD CONSTRAINT [FK_mor_DelinquencyBatches_StageId_DelinquencyStages]
        FOREIGN KEY ([StageId]) REFERENCES [mor].[DelinquencyStages] ([DelinquencyStageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNoticeModels_StageIdsId_DelinquencyStages'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNoticeModels]
        ADD CONSTRAINT [FK_mor_DelinquencyNoticeModels_StageIdsId_DelinquencyStages]
        FOREIGN KEY ([StageIdsId]) REFERENCES [mor].[DelinquencyStages] ([DelinquencyStageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_StageId_DelinquencyStages'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_StageId_DelinquencyStages]
        FOREIGN KEY ([StageId]) REFERENCES [mor].[DelinquencyStages] ([DelinquencyStageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_Guarantees_RequirementRuleId_GuaranteeRequirementRules'
)
BEGIN
    ALTER TABLE [mor].[Guarantees]
        ADD CONSTRAINT [FK_mor_Guarantees_RequirementRuleId_GuaranteeRequirementRules]
        FOREIGN KEY ([RequirementRuleId]) REFERENCES [mor].[GuaranteeRequirementRules] ([GuaranteeRequirementRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Blocks_HoldReasonId_HoldReasons'
)
BEGIN
    ALTER TABLE [per].[Blocks]
        ADD CONSTRAINT [FK_per_Blocks_HoldReasonId_HoldReasons]
        FOREIGN KEY ([HoldReasonId]) REFERENCES [mor].[HoldReasons] ([HoldReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DocumentHolds_HoldReasonId_HoldReasons'
)
BEGIN
    ALTER TABLE [mor].[DocumentHolds]
        ADD CONSTRAINT [FK_mor_DocumentHolds_HoldReasonId_HoldReasons]
        FOREIGN KEY ([HoldReasonId]) REFERENCES [mor].[HoldReasons] ([HoldReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DocumentHolds_ReasonId_HoldReasons'
)
BEGIN
    ALTER TABLE [mor].[DocumentHolds]
        ADD CONSTRAINT [FK_mor_DocumentHolds_ReasonId_HoldReasons]
        FOREIGN KEY ([ReasonId]) REFERENCES [mor].[HoldReasons] ([HoldReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestPolicies_LateInterestIndexTableId_InterestIndexTables'
)
BEGIN
    ALTER TABLE [mor].[InterestPolicies]
        ADD CONSTRAINT [FK_mor_InterestPolicies_LateInterestIndexTableId_InterestIndexTables]
        FOREIGN KEY ([LateInterestIndexTableId]) REFERENCES [mor].[InterestIndexTables] ([InterestIndexTableId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestIndexValues_TableId_InterestIndexTables'
)
BEGIN
    ALTER TABLE [mor].[InterestIndexValues]
        ADD CONSTRAINT [FK_mor_InterestIndexValues_TableId_InterestIndexTables]
        FOREIGN KEY ([TableId]) REFERENCES [mor].[InterestIndexTables] ([InterestIndexTableId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestPolicies_LateInterestRateTableId_InterestRateTables'
)
BEGIN
    ALTER TABLE [mor].[InterestPolicies]
        ADD CONSTRAINT [FK_mor_InterestPolicies_LateInterestRateTableId_InterestRateTables]
        FOREIGN KEY ([LateInterestRateTableId]) REFERENCES [mor].[InterestRateTables] ([InterestRateTableId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestCalculations_PolicyId_InterestPolicies'
)
BEGIN
    ALTER TABLE [mor].[InterestCalculations]
        ADD CONSTRAINT [FK_mor_InterestCalculations_PolicyId_InterestPolicies]
        FOREIGN KEY ([PolicyId]) REFERENCES [mor].[InterestPolicies] ([InterestPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_ConsentRecords_NoticeId_PrivacyNotices'
)
BEGIN
    ALTER TABLE [nfr].[ConsentRecords]
        ADD CONSTRAINT [FK_nfr_ConsentRecords_NoticeId_PrivacyNotices]
        FOREIGN KEY ([NoticeId]) REFERENCES [nfr].[PrivacyNotices] ([PrivacyNoticeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_DataCatalogEntries_RetentionPolicyId_RetentionPolicies'
)
BEGIN
    ALTER TABLE [nfr].[DataCatalogEntries]
        ADD CONSTRAINT [FK_nfr_DataCatalogEntries_RetentionPolicyId_RetentionPolicies]
        FOREIGN KEY ([RetentionPolicyId]) REFERENCES [nfr].[RetentionPolicies] ([RetentionPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_RetentionRuns_RetentionPolicyId_RetentionPolicies'
)
BEGIN
    ALTER TABLE [nfr].[RetentionRuns]
        ADD CONSTRAINT [FK_nfr_RetentionRuns_RetentionPolicyId_RetentionPolicies]
        FOREIGN KEY ([RetentionPolicyId]) REFERENCES [nfr].[RetentionPolicies] ([RetentionPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyExceptions_NoteId_Notes'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyExceptions]
        ADD CONSTRAINT [FK_mor_DelinquencyExceptions_NoteId_Notes]
        FOREIGN KEY ([NoteId]) REFERENCES [per].[Notes] ([NoteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_MassOperationItems_NoteId_Notes'
)
BEGIN
    ALTER TABLE [fac].[MassOperationItems]
        ADD CONSTRAINT [FK_fac_MassOperationItems_NoteId_Notes]
        FOREIGN KEY ([NoteId]) REFERENCES [per].[Notes] ([NoteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_person_PersonId_Persons'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_person]
        ADD CONSTRAINT [FK_bia_Bi_dim_person_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_Suppliers_PersonId_Persons'
)
BEGIN
    ALTER TABLE [cmp].[Suppliers]
        ADD CONSTRAINT [FK_cmp_Suppliers_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Communications_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[Communications]
        ADD CONSTRAINT [FK_com_Communications_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmContacts_PersonId_Persons'
)
BEGIN
    ALTER TABLE [crm].[CrmContacts]
        ADD CONSTRAINT [FK_crm_CrmContacts_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmInteractions_PersonId_Persons'
)
BEGIN
    ALTER TABLE [crm].[CrmInteractions]
        ADD CONSTRAINT [FK_crm_CrmInteractions_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueAppointments_PersonId_Persons'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueAppointments]
        ADD CONSTRAINT [FK_crm_CrmQueueAppointments_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_DataSubjectRequests_PersonId_Persons'
)
BEGIN
    ALTER TABLE [nfr].[DataSubjectRequests]
        ADD CONSTRAINT [FK_nfr_DataSubjectRequests_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Holders_PersonId_Persons'
)
BEGIN
    ALTER TABLE [per].[Holders]
        ADD CONSTRAINT [FK_per_Holders_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_PersonSensitiveData_PersonId_Persons'
)
BEGIN
    ALTER TABLE [per].[PersonSensitiveData]
        ADD CONSTRAINT [FK_per_PersonSensitiveData_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_MedicalProfessionals_PersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[MedicalProfessionals]
        ADD CONSTRAINT [FK_soc_MedicalProfessionals_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CertifiedInstallers_PersonId_Persons'
)
BEGIN
    ALTER TABLE [tec].[CertifiedInstallers]
        ADD CONSTRAINT [FK_tec_CertifiedInstallers_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_PersonIdentifierIndex_PersonId_Persons'
)
BEGIN
    ALTER TABLE [per].[PersonIdentifierIndex]
        ADD CONSTRAINT [FK_per_PersonIdentifierIndex_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_NewsletterRecipients_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[NewsletterRecipients]
        ADD CONSTRAINT [FK_com_NewsletterRecipients_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_AssociateMemberships_PersonId_Persons'
)
BEGIN
    ALTER TABLE [ins].[AssociateMemberships]
        ADD CONSTRAINT [FK_ins_AssociateMemberships_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_ExternalClientId_Persons'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts]
        ADD CONSTRAINT [FK_cat_ServiceContracts_ExternalClientId_Persons]
        FOREIGN KEY ([ExternalClientId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DispenserWithdrawals_PersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[DispenserWithdrawals]
        ADD CONSTRAINT [FK_soc_DispenserWithdrawals_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceImportRows_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[AudienceImportRows]
        ADD CONSTRAINT [FK_com_AudienceImportRows_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalAccountAccess_PersonId_Persons'
)
BEGIN
    ALTER TABLE [por].[PortalAccountAccess]
        ADD CONSTRAINT [FK_por_PortalAccountAccess_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryAccountSigners_PersonId_Persons'
)
BEGIN
    ALTER TABLE [tes].[TreasuryAccountSigners]
        ADD CONSTRAINT [FK_tes_TreasuryAccountSigners_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DeathSubsidyCases_DeceasedPersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[DeathSubsidyCases]
        ADD CONSTRAINT [FK_soc_DeathSubsidyCases_DeceasedPersonId_Persons]
        FOREIGN KEY ([DeceasedPersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialRights_ContractorPersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[BurialRights]
        ADD CONSTRAINT [FK_soc_BurialRights_ContractorPersonId_Persons]
        FOREIGN KEY ([ContractorPersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_EventRegistrations_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[EventRegistrations]
        ADD CONSTRAINT [FK_com_EventRegistrations_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryActs_DeceasedPersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[CemeteryActs]
        ADD CONSTRAINT [FK_soc_CemeteryActs_DeceasedPersonId_Persons]
        FOREIGN KEY ([DeceasedPersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_BodyMandates_PersonId_Persons'
)
BEGIN
    ALTER TABLE [ins].[BodyMandates]
        ADD CONSTRAINT [FK_ins_BodyMandates_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSnapshotMembers_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[AudienceSnapshotMembers]
        ADD CONSTRAINT [FK_com_AudienceSnapshotMembers_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AppNotifications_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[AppNotifications]
        ADD CONSTRAINT [FK_com_AppNotifications_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceDependents_PersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[ServiceDependents]
        ADD CONSTRAINT [FK_soc_ServiceDependents_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeFamilyMembers_PersonId_Persons'
)
BEGIN
    ALTER TABLE [sue].[EmployeeFamilyMembers]
        ADD CONSTRAINT [FK_sue_EmployeeFamilyMembers_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_OrthopedicLoans_BorrowerPersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[OrthopedicLoans]
        ADD CONSTRAINT [FK_soc_OrthopedicLoans_BorrowerPersonId_Persons]
        FOREIGN KEY ([BorrowerPersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BenefitRequests_BeneficiaryPersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[BenefitRequests]
        ADD CONSTRAINT [FK_soc_BenefitRequests_BeneficiaryPersonId_Persons]
        FOREIGN KEY ([BeneficiaryPersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BenefitRequests_RequesterPersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[BenefitRequests]
        ADD CONSTRAINT [FK_soc_BenefitRequests_RequesterPersonId_Persons]
        FOREIGN KEY ([RequesterPersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_BenefitRedemptions_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[BenefitRedemptions]
        ADD CONSTRAINT [FK_com_BenefitRedemptions_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFeeSettlements_PersonId_Persons'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFeeSettlements]
        ADD CONSTRAINT [FK_ins_InstitutionalFeeSettlements_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialOccupancies_DeceasedPersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[BurialOccupancies]
        ADD CONSTRAINT [FK_soc_BurialOccupancies_DeceasedPersonId_Persons]
        FOREIGN KEY ([DeceasedPersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_ConsentRecords_PersonId_Persons'
)
BEGIN
    ALTER TABLE [nfr].[ConsentRecords]
        ADD CONSTRAINT [FK_nfr_ConsentRecords_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_ConsentRecords_RepresentativePersonId_Persons'
)
BEGIN
    ALTER TABLE [nfr].[ConsentRecords]
        ADD CONSTRAINT [FK_nfr_ConsentRecords_RepresentativePersonId_Persons]
        FOREIGN KEY ([RepresentativePersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_Guarantees_PersonId_Persons'
)
BEGIN
    ALTER TABLE [mor].[Guarantees]
        ADD CONSTRAINT [FK_mor_Guarantees_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalBalances_PersonId_Persons'
)
BEGIN
    ALTER TABLE [ins].[CapitalBalances]
        ADD CONSTRAINT [FK_ins_CapitalBalances_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesReps_PersonId_Persons'
)
BEGIN
    ALTER TABLE [ven].[SalesReps]
        ADD CONSTRAINT [FK_ven_SalesReps_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalMovements_PersonId_Persons'
)
BEGIN
    ALTER TABLE [ins].[CapitalMovements]
        ADD CONSTRAINT [FK_ins_CapitalMovements_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Employees_PersonId_Persons'
)
BEGIN
    ALTER TABLE [sue].[Employees]
        ADD CONSTRAINT [FK_sue_Employees_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunitySanctions_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[CommunitySanctions]
        ADD CONSTRAINT [FK_com_CommunitySanctions_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunicationPreferences_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[CommunicationPreferences]
        ADD CONSTRAINT [FK_com_CommunicationPreferences_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialServiceCases_DeceasedPersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[BurialServiceCases]
        ADD CONSTRAINT [FK_soc_BurialServiceCases_DeceasedPersonId_Persons]
        FOREIGN KEY ([DeceasedPersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_Drivers_PersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[Drivers]
        ADD CONSTRAINT [FK_soc_Drivers_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyResponses_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[SurveyResponses]
        ADD CONSTRAINT [FK_com_SurveyResponses_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyInvitations_PersonId_Persons'
)
BEGIN
    ALTER TABLE [com].[SurveyInvitations]
        ADD CONSTRAINT [FK_com_SurveyInvitations_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceBeneficiaries_PersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[ServiceBeneficiaries]
        ADD CONSTRAINT [FK_soc_ServiceBeneficiaries_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Collectors_PersonId_Persons'
)
BEGIN
    ALTER TABLE [cob].[Collectors]
        ADD CONSTRAINT [FK_cob_Collectors_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DonationAppointments_PersonId_Persons'
)
BEGIN
    ALTER TABLE [soc].[DonationAppointments]
        ADD CONSTRAINT [FK_soc_DonationAppointments_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SubsidyEnrollments_PersonId_Persons'
)
BEGIN
    ALTER TABLE [tar].[SubsidyEnrollments]
        ADD CONSTRAINT [FK_tar_SubsidyEnrollments_PersonId_Persons]
        FOREIGN KEY ([PersonId]) REFERENCES [per].[Persons] ([PersonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_supplier_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_supplier]
        ADD CONSTRAINT [FK_bia_Bi_dim_supplier_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseOrders_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseOrders]
        ADD CONSTRAINT [FK_cmp_PurchaseOrders_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsContracts_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsContracts]
        ADD CONSTRAINT [FK_cmp_SignalRightsContracts_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierAdvances_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierAdvances]
        ADD CONSTRAINT [FK_cmp_SupplierAdvances_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierInvoices_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierInvoices]
        ADD CONSTRAINT [FK_cmp_SupplierInvoices_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DebtCollectionAgencies_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [mor].[DebtCollectionAgencies]
        ADD CONSTRAINT [FK_mor_DebtCollectionAgencies_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CareProviders_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [soc].[CareProviders]
        ADD CONSTRAINT [FK_soc_CareProviders_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ReorderSuggestions_PreferredSupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [stk].[ReorderSuggestions]
        ADD CONSTRAINT [FK_stk_ReorderSuggestions_PreferredSupplierId_Suppliers]
        FOREIGN KEY ([PreferredSupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryAccounts_BankAsSupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [tes].[TreasuryAccounts]
        ADD CONSTRAINT [FK_tes_TreasuryAccounts_BankAsSupplierId_Suppliers]
        FOREIGN KEY ([BankAsSupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleMaintenances_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [soc].[VehicleMaintenances]
        ADD CONSTRAINT [FK_soc_VehicleMaintenances_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierEvaluations_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierEvaluations]
        ADD CONSTRAINT [FK_cmp_SupplierEvaluations_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_LotTypes_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [stk].[LotTypes]
        ADD CONSTRAINT [FK_stk_LotTypes_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_QuoteRequests_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[QuoteRequests]
        ADD CONSTRAINT [FK_cmp_QuoteRequests_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_QuoteRequests_SupplierIdsId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[QuoteRequests]
        ADD CONSTRAINT [FK_cmp_QuoteRequests_SupplierIdsId_Suppliers]
        FOREIGN KEY ([SupplierIdsId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Lots_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [stk].[Lots]
        ADD CONSTRAINT [FK_stk_Lots_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierPortalSubmissions_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierPortalSubmissions]
        ADD CONSTRAINT [FK_cmp_SupplierPortalSubmissions_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierLedgerEntries_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierLedgerEntries]
        ADD CONSTRAINT [FK_cmp_SupplierLedgerEntries_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_AiInvoiceExtractions_ProposedSupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[AiInvoiceExtractions]
        ADD CONSTRAINT [FK_cmp_AiInvoiceExtractions_ProposedSupplierId_Suppliers]
        FOREIGN KEY ([ProposedSupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierReceipts_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SupplierReceipts]
        ADD CONSTRAINT [FK_cmp_SupplierReceipts_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingCertificates_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [soc].[HousingCertificates]
        ADD CONSTRAINT [FK_soc_HousingCertificates_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseForecasts_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseForecasts]
        ADD CONSTRAINT [FK_cmp_PurchaseForecasts_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsSettlements_SupplierId_Suppliers'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsSettlements]
        ADD CONSTRAINT [FK_cmp_SignalRightsSettlements_SupplierId_Suppliers]
        FOREIGN KEY ([SupplierId]) REFERENCES [cmp].[Suppliers] ([SupplierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_MatchExceptions_PurchaseOrderId_PurchaseOrders'
)
BEGIN
    ALTER TABLE [cmp].[MatchExceptions]
        ADD CONSTRAINT [FK_cmp_MatchExceptions_PurchaseOrderId_PurchaseOrders]
        FOREIGN KEY ([PurchaseOrderId]) REFERENCES [cmp].[PurchaseOrders] ([PurchaseOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsSettlements_ContractId_SignalRightsContracts'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsSettlements]
        ADD CONSTRAINT [FK_cmp_SignalRightsSettlements_ContractId_SignalRightsContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cmp].[SignalRightsContracts] ([SignalRightsContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_purchase_SupplierInvoiceId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_purchase]
        ADD CONSTRAINT [FK_bia_Bi_fact_purchase_SupplierInvoiceId_SupplierInvoices]
        FOREIGN KEY ([SupplierInvoiceId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleMaintenances_PurchaseRefId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [soc].[VehicleMaintenances]
        ADD CONSTRAINT [FK_soc_VehicleMaintenances_PurchaseRefId_SupplierInvoices]
        FOREIGN KEY ([PurchaseRefId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_MatchExceptions_InvoiceId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [cmp].[MatchExceptions]
        ADD CONSTRAINT [FK_cmp_MatchExceptions_InvoiceId_SupplierInvoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_MatchExceptions_InvoiceItemId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [cmp].[MatchExceptions]
        ADD CONSTRAINT [FK_cmp_MatchExceptions_InvoiceItemId_SupplierInvoices]
        FOREIGN KEY ([InvoiceItemId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FuelLoads_SupplierInvoiceId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [soc].[FuelLoads]
        ADD CONSTRAINT [FK_soc_FuelLoads_SupplierInvoiceId_SupplierInvoices]
        FOREIGN KEY ([SupplierInvoiceId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_AiInvoiceExtractions_InvoiceId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [cmp].[AiInvoiceExtractions]
        ADD CONSTRAINT [FK_cmp_AiInvoiceExtractions_InvoiceId_SupplierInvoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardSettlements_ExpenseDocumentRefId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [tes].[CardSettlements]
        ADD CONSTRAINT [FK_tes_CardSettlements_ExpenseDocumentRefId_SupplierInvoices]
        FOREIGN KEY ([ExpenseDocumentRefId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingCertificates_PurchaseRefId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [soc].[HousingCertificates]
        ADD CONSTRAINT [FK_soc_HousingCertificates_PurchaseRefId_SupplierInvoices]
        FOREIGN KEY ([PurchaseRefId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsSettlements_InvoiceId_SupplierInvoices'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsSettlements]
        ADD CONSTRAINT [FK_cmp_SignalRightsSettlements_InvoiceId_SupplierInvoices]
        FOREIGN KEY ([InvoiceId]) REFERENCES [cmp].[SupplierInvoices] ([SupplierInvoiceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_communication_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_communication]
        ADD CONSTRAINT [FK_bia_Bi_fact_communication_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunicationAttempts_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [com].[CommunicationAttempts]
        ADD CONSTRAINT [FK_com_CommunicationAttempts_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_NewsletterRecipients_CommunicationIdsId_Communications'
)
BEGIN
    ALTER TABLE [com].[NewsletterRecipients]
        ADD CONSTRAINT [FK_com_NewsletterRecipients_CommunicationIdsId_Communications]
        FOREIGN KEY ([CommunicationIdsId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunicationEvents_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [com].[CommunicationEvents]
        ADD CONSTRAINT [FK_com_CommunicationEvents_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AppNotifications_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [com].[AppNotifications]
        ADD CONSTRAINT [FK_com_AppNotifications_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_TrackedLinks_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [com].[TrackedLinks]
        ADD CONSTRAINT [FK_com_TrackedLinks_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditMessages_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [iam].[AuditMessages]
        ADD CONSTRAINT [FK_iam_AuditMessages_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierCorrespondence_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [cmp].[SupplierCorrespondence]
        ADD CONSTRAINT [FK_cmp_SupplierCorrespondence_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SuppressionEntries_SourceCommunicationId_Communications'
)
BEGIN
    ALTER TABLE [com].[SuppressionEntries]
        ADD CONSTRAINT [FK_com_SuppressionEntries_SourceCommunicationId_Communications]
        FOREIGN KEY ([SourceCommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDeliveries_CommunicationId_Communications'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDeliveries]
        ADD CONSTRAINT [FK_fac_InvoiceDeliveries_CommunicationId_Communications]
        FOREIGN KEY ([CommunicationId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyInvitations_CommunicationIdsId_Communications'
)
BEGIN
    ALTER TABLE [com].[SurveyInvitations]
        ADD CONSTRAINT [FK_com_SurveyInvitations_CommunicationIdsId_Communications]
        FOREIGN KEY ([CommunicationIdsId]) REFERENCES [com].[Communications] ([CommunicationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_ContactIdsId_CrmContacts'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_ContactIdsId_CrmContacts]
        FOREIGN KEY ([ContactIdsId]) REFERENCES [crm].[CrmContacts] ([CrmContactId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_CollectionCases_DebtCollectionAgencyId_DebtCollectionAgencies'
)
BEGIN
    ALTER TABLE [mor].[CollectionCases]
        ADD CONSTRAINT [FK_mor_CollectionCases_DebtCollectionAgencyId_DebtCollectionAgencies]
        FOREIGN KEY ([DebtCollectionAgencyId]) REFERENCES [mor].[DebtCollectionAgencies] ([DebtCollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_ErasureLedger_RequestId_DataSubjectRequests'
)
BEGIN
    ALTER TABLE [nfr].[ErasureLedger]
        ADD CONSTRAINT [FK_nfr_ErasureLedger_RequestId_DataSubjectRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [nfr].[DataSubjectRequests] ([DataSubjectRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CurrentAccounts_HolderId_Holders'
)
BEGIN
    ALTER TABLE [cob].[CurrentAccounts]
        ADD CONSTRAINT [FK_cob_CurrentAccounts_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CreditBalances_HolderId_Holders'
)
BEGIN
    ALTER TABLE [cob].[CreditBalances]
        ADD CONSTRAINT [FK_cob_CreditBalances_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Accounts_HolderId_Holders'
)
BEGIN
    ALTER TABLE [per].[Accounts]
        ADD CONSTRAINT [FK_per_Accounts_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_DeliveryPreferences_HolderId_Holders'
)
BEGIN
    ALTER TABLE [fac].[DeliveryPreferences]
        ADD CONSTRAINT [FK_fac_DeliveryPreferences_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkBeneficiaries_HolderId_Holders'
)
BEGIN
    ALTER TABLE [tec].[WorkBeneficiaries]
        ADD CONSTRAINT [FK_tec_WorkBeneficiaries_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_HolderId_Holders'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts]
        ADD CONSTRAINT [FK_cat_ServiceContracts_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_CollectionCases_HolderId_Holders'
)
BEGIN
    ALTER TABLE [mor].[CollectionCases]
        ADD CONSTRAINT [FK_mor_CollectionCases_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceDependents_HolderId_Holders'
)
BEGIN
    ALTER TABLE [soc].[ServiceDependents]
        ADD CONSTRAINT [FK_soc_ServiceDependents_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingUnits_HolderId_Holders'
)
BEGIN
    ALTER TABLE [soc].[HousingUnits]
        ADD CONSTRAINT [FK_soc_HousingUnits_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Receipts_HolderId_Holders'
)
BEGIN
    ALTER TABLE [cob].[Receipts]
        ADD CONSTRAINT [FK_cob_Receipts_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BundleSubscriptions_HolderId_Holders'
)
BEGIN
    ALTER TABLE [cat].[BundleSubscriptions]
        ADD CONSTRAINT [FK_cat_BundleSubscriptions_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceBeneficiaries_HolderId_Holders'
)
BEGIN
    ALTER TABLE [soc].[ServiceBeneficiaries]
        ADD CONSTRAINT [FK_soc_ServiceBeneficiaries_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_RefundCases_HolderId_Holders'
)
BEGIN
    ALTER TABLE [cob].[RefundCases]
        ADD CONSTRAINT [FK_cob_RefundCases_HolderId_Holders]
        FOREIGN KEY ([HolderId]) REFERENCES [per].[Holders] ([HolderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_snap_balance_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [bia].[Bi_snap_balance]
        ADD CONSTRAINT [FK_bia_Bi_snap_balance_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CreditBalances_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[CreditBalances]
        ADD CONSTRAINT [FK_cob_CreditBalances_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitMandates_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitMandates]
        ADD CONSTRAINT [FK_cob_DirectDebitMandates_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ExternalKeyAliases_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[ExternalKeyAliases]
        ADD CONSTRAINT [FK_cob_ExternalKeyAliases_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AccountStatements_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[AccountStatements]
        ADD CONSTRAINT [FK_cob_AccountStatements_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Receipts_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[Receipts]
        ADD CONSTRAINT [FK_cob_Receipts_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentCoupons_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[PaymentCoupons]
        ADD CONSTRAINT [FK_cob_PaymentCoupons_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_RefundCases_CurrentAccountId_CurrentAccounts'
)
BEGIN
    ALTER TABLE [cob].[RefundCases]
        ADD CONSTRAINT [FK_cob_RefundCases_CurrentAccountId_CurrentAccounts]
        FOREIGN KEY ([CurrentAccountId]) REFERENCES [cob].[CurrentAccounts] ([CurrentAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusAllocations_CreditRefId_CreditBalances'
)
BEGIN
    ALTER TABLE [ins].[SurplusAllocations]
        ADD CONSTRAINT [FK_ins_SurplusAllocations_CreditRefId_CreditBalances]
        FOREIGN KEY ([CreditRefId]) REFERENCES [cob].[CreditBalances] ([CreditBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Receipts_CreditBalanceIdsId_CreditBalances'
)
BEGIN
    ALTER TABLE [cob].[Receipts]
        ADD CONSTRAINT [FK_cob_Receipts_CreditBalanceIdsId_CreditBalances]
        FOREIGN KEY ([CreditBalanceIdsId]) REFERENCES [cob].[CreditBalances] ([CreditBalanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_account_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_account]
        ADD CONSTRAINT [FK_bia_Bi_dim_account_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_arrears_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_arrears]
        ADD CONSTRAINT [FK_bia_Bi_fact_arrears_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmAccountAssignments_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [crm].[CrmAccountAssignments]
        ADD CONSTRAINT [FK_crm_CrmAccountAssignments_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmHourBanks_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [crm].[CrmHourBanks]
        ADD CONSTRAINT [FK_crm_CrmHourBanks_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_DeliveryPreferences_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [fac].[DeliveryPreferences]
        ADD CONSTRAINT [FK_fac_DeliveryPreferences_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_PaymentSlips_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [fac].[PaymentSlips]
        ADD CONSTRAINT [FK_fac_PaymentSlips_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyEvaluations_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyEvaluations]
        ADD CONSTRAINT [FK_mor_DelinquencyEvaluations_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxpayerRegistryEntries_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [fis].[TaxpayerRegistryEntries]
        ADD CONSTRAINT [FK_fis_TaxpayerRegistryEntries_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ReceptionStatuses_AccountIdsId_Accounts'
)
BEGIN
    ALTER TABLE [stk].[ReceptionStatuses]
        ADD CONSTRAINT [FK_stk_ReceptionStatuses_AccountIdsId_Accounts]
        FOREIGN KEY ([AccountIdsId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollConcepts_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [sue].[PayrollConcepts]
        ADD CONSTRAINT [FK_sue_PayrollConcepts_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_RoundingCarryEntries_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [tar].[RoundingCarryEntries]
        ADD CONSTRAINT [FK_tar_RoundingCarryEntries_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TelecomOperators_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [tec].[TelecomOperators]
        ADD CONSTRAINT [FK_tec_TelecomOperators_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestCalculations_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [mor].[InterestCalculations]
        ADD CONSTRAINT [FK_mor_InterestCalculations_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeteringPoints_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [med].[MeteringPoints]
        ADD CONSTRAINT [FK_med_MeteringPoints_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitMandates_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitMandates]
        ADD CONSTRAINT [FK_cob_DirectDebitMandates_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementSimulations_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [mor].[AgreementSimulations]
        ADD CONSTRAINT [FK_mor_AgreementSimulations_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxExemptions_PartyId_Accounts'
)
BEGIN
    ALTER TABLE [fis].[TaxExemptions]
        ADD CONSTRAINT [FK_fis_TaxExemptions_PartyId_Accounts]
        FOREIGN KEY ([PartyId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyBillers_LinkedAccountId_Accounts'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyBillers]
        ADD CONSTRAINT [FK_cob_ThirdPartyBillers_LinkedAccountId_Accounts]
        FOREIGN KEY ([LinkedAccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Unions_GeneralAccountId_Accounts'
)
BEGIN
    ALTER TABLE [sue].[Unions]
        ADD CONSTRAINT [FK_sue_Unions_GeneralAccountId_Accounts]
        FOREIGN KEY ([GeneralAccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_BlockedAccountIdsId_Accounts'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_BlockedAccountIdsId_Accounts]
        FOREIGN KEY ([BlockedAccountIdsId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkBeneficiaries_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [tec].[WorkBeneficiaries]
        ADD CONSTRAINT [FK_tec_WorkBeneficiaries_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts]
        ADD CONSTRAINT [FK_cat_ServiceContracts_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_CollectionCases_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [mor].[CollectionCases]
        ADD CONSTRAINT [FK_mor_CollectionCases_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceImportRows_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [com].[AudienceImportRows]
        ADD CONSTRAINT [FK_com_AudienceImportRows_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalUserPreferences_DefaultAccountId_Accounts'
)
BEGIN
    ALTER TABLE [por].[PortalUserPreferences]
        ADD CONSTRAINT [FK_por_PortalUserPreferences_DefaultAccountId_Accounts]
        FOREIGN KEY ([DefaultAccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ExternalKeyAliases_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [cob].[ExternalKeyAliases]
        ADD CONSTRAINT [FK_cob_ExternalKeyAliases_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalAccountAccess_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [por].[PortalAccountAccess]
        ADD CONSTRAINT [FK_por_PortalAccountAccess_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ServiceReceptions_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [stk].[ServiceReceptions]
        ADD CONSTRAINT [FK_stk_ServiceReceptions_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ServiceReceptions_AccountIdsId_Accounts'
)
BEGIN
    ALTER TABLE [stk].[ServiceReceptions]
        ADD CONSTRAINT [FK_stk_ServiceReceptions_AccountIdsId_Accounts]
        FOREIGN KEY ([AccountIdsId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_ledgerEntry_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_ledgerEntry]
        ADD CONSTRAINT [FK_bia_Bi_fact_ledgerEntry_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialRights_PayerAccountId_Accounts'
)
BEGIN
    ALTER TABLE [soc].[BurialRights]
        ADD CONSTRAINT [FK_soc_BurialRights_PayerAccountId_Accounts]
        FOREIGN KEY ([PayerAccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestBillingRunItems_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [mor].[InterestBillingRunItems]
        ADD CONSTRAINT [FK_mor_InterestBillingRunItems_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSnapshotMembers_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [com].[AudienceSnapshotMembers]
        ADD CONSTRAINT [FK_com_AudienceSnapshotMembers_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyCharges_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyCharges]
        ADD CONSTRAINT [FK_fis_ThirdPartyCharges_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingUnits_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [soc].[HousingUnits]
        ADD CONSTRAINT [FK_soc_HousingUnits_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_EventChargeBonuses_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [tar].[EventChargeBonuses]
        ADD CONSTRAINT [FK_tar_EventChargeBonuses_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalLinkAttempts_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [por].[PortalLinkAttempts]
        ADD CONSTRAINT [FK_por_PortalLinkAttempts_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_WriteOffs_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [mor].[WriteOffs]
        ADD CONSTRAINT [FK_mor_WriteOffs_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_Agreements_TargetAccountId_Accounts'
)
BEGIN
    ALTER TABLE [mor].[Agreements]
        ADD CONSTRAINT [FK_mor_Agreements_TargetAccountId_Accounts]
        FOREIGN KEY ([TargetAccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalDelegationInvites_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [por].[PortalDelegationInvites]
        ADD CONSTRAINT [FK_por_PortalDelegationInvites_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExtraTasks_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [sue].[ExtraTasks]
        ADD CONSTRAINT [FK_sue_ExtraTasks_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceExternalData_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [fac].[InvoiceExternalData]
        ADD CONSTRAINT [FK_fac_InvoiceExternalData_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SimulationResults_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [tar].[SimulationResults]
        ADD CONSTRAINT [FK_tar_SimulationResults_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BundleSubscriptions_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [cat].[BundleSubscriptions]
        ADD CONSTRAINT [FK_cat_BundleSubscriptions_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DeferredInterests_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [mor].[DeferredInterests]
        ADD CONSTRAINT [FK_mor_DeferredInterests_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosTerminals_DefaultAccountId_Accounts'
)
BEGIN
    ALTER TABLE [ven].[PosTerminals]
        ADD CONSTRAINT [FK_ven_PosTerminals_DefaultAccountId_Accounts]
        FOREIGN KEY ([DefaultAccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_DeterminedRates_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [fis].[DeterminedRates]
        ADD CONSTRAINT [FK_fis_DeterminedRates_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_CollectionFollowUps_AccountId_Accounts'
)
BEGIN
    ALTER TABLE [mor].[CollectionFollowUps]
        ADD CONSTRAINT [FK_mor_CollectionFollowUps_AccountId_Accounts]
        FOREIGN KEY ([AccountId]) REFERENCES [per].[Accounts] ([AccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_ServiceProtections_PersonSensitiveDataId_PersonSensitiveData'
)
BEGIN
    ALTER TABLE [mor].[ServiceProtections]
        ADD CONSTRAINT [FK_mor_ServiceProtections_PersonSensitiveDataId_PersonSensitiveData]
        FOREIGN KEY ([PersonSensitiveDataId]) REFERENCES [per].[PersonSensitiveData] ([PersonSensitiveDataId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkBeneficiaries_PremiseId_Premises'
)
BEGIN
    ALTER TABLE [tec].[WorkBeneficiaries]
        ADD CONSTRAINT [FK_tec_WorkBeneficiaries_PremiseId_Premises]
        FOREIGN KEY ([PremiseId]) REFERENCES [per].[Premises] ([PremisId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeteringPoints_ServicePointId_ServicePoints'
)
BEGIN
    ALTER TABLE [med].[MeteringPoints]
        ADD CONSTRAINT [FK_med_MeteringPoints_ServicePointId_ServicePoints]
        FOREIGN KEY ([ServicePointId]) REFERENCES [per].[ServicePoints] ([ServicePointId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_ServicePointId_ServicePoints'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts]
        ADD CONSTRAINT [FK_cat_ServiceContracts_ServicePointId_ServicePoints]
        FOREIGN KEY ([ServicePointId]) REFERENCES [per].[ServicePoints] ([ServicePointId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_MassOperations_JobId_JobRuns'
)
BEGIN
    ALTER TABLE [fac].[MassOperations]
        ADD CONSTRAINT [FK_fac_MassOperations_JobId_JobRuns]
        FOREIGN KEY ([JobId]) REFERENCES [pla].[JobRuns] ([JobRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyBatches_JobId_JobRuns'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyBatches]
        ADD CONSTRAINT [FK_mor_DelinquencyBatches_JobId_JobRuns]
        FOREIGN KEY ([JobId]) REFERENCES [pla].[JobRuns] ([JobRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_NoveltyImportBatches_JobId_JobRuns'
)
BEGIN
    ALTER TABLE [sue].[NoveltyImportBatches]
        ADD CONSTRAINT [FK_sue_NoveltyImportBatches_JobId_JobRuns]
        FOREIGN KEY ([JobId]) REFERENCES [pla].[JobRuns] ([JobRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_CalculationRuns_JobId_JobRuns'
)
BEGIN
    ALTER TABLE [tar].[CalculationRuns]
        ADD CONSTRAINT [FK_tar_CalculationRuns_JobId_JobRuns]
        FOREIGN KEY ([JobId]) REFERENCES [pla].[JobRuns] ([JobRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestBillingRuns_JobId_JobRuns'
)
BEGIN
    ALTER TABLE [mor].[InterestBillingRuns]
        ADD CONSTRAINT [FK_mor_InterestBillingRuns_JobId_JobRuns]
        FOREIGN KEY ([JobId]) REFERENCES [pla].[JobRuns] ([JobRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BulkContractOperations_JobId_JobRuns'
)
BEGIN
    ALTER TABLE [cat].[BulkContractOperations]
        ADD CONSTRAINT [FK_cat_BulkContractOperations_JobId_JobRuns]
        FOREIGN KEY ([JobId]) REFERENCES [pla].[JobRuns] ([JobRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaSubmissions_JobId_JobRuns'
)
BEGIN
    ALTER TABLE [fis].[ArcaSubmissions]
        ADD CONSTRAINT [FK_fis_ArcaSubmissions_JobId_JobRuns]
        FOREIGN KEY ([JobId]) REFERENCES [pla].[JobRuns] ([JobRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_MassOperationItems_OperationId_MassOperations'
)
BEGIN
    ALTER TABLE [fac].[MassOperationItems]
        ADD CONSTRAINT [FK_fac_MassOperationItems_OperationId_MassOperations]
        FOREIGN KEY ([OperationId]) REFERENCES [fac].[MassOperations] ([MassOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_DelinquencyBatchId_DelinquencyBatches'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_DelinquencyBatchId_DelinquencyBatches]
        FOREIGN KEY ([DelinquencyBatchId]) REFERENCES [mor].[DelinquencyBatches] ([DelinquencyBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_SecurityIncidents_PlatformIncidentId_PlatformIncidents'
)
BEGIN
    ALTER TABLE [nfr].[SecurityIncidents]
        ADD CONSTRAINT [FK_nfr_SecurityIncidents_PlatformIncidentId_PlatformIncidents]
        FOREIGN KEY ([PlatformIncidentId]) REFERENCES [pla].[PlatformIncidents] ([PlatformIncidentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_StatusNotices_PlatformIncidentId_PlatformIncidents'
)
BEGIN
    ALTER TABLE [nfr].[StatusNotices]
        ADD CONSTRAINT [FK_nfr_StatusNotices_PlatformIncidentId_PlatformIncidents]
        FOREIGN KEY ([PlatformIncidentId]) REFERENCES [pla].[PlatformIncidents] ([PlatformIncidentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_StatusNotices_IncidentId_SecurityIncidents'
)
BEGIN
    ALTER TABLE [nfr].[StatusNotices]
        ADD CONSTRAINT [FK_nfr_StatusNotices_IncidentId_SecurityIncidents]
        FOREIGN KEY ([IncidentId]) REFERENCES [nfr].[SecurityIncidents] ([SecurityIncidentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ExternalObligationImports_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[ExternalObligationImports]
        ADD CONSTRAINT [FK_cob_ExternalObligationImports_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_UnidentifiedReceipts_EvidenceStoredFileIdsId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[UnidentifiedReceipts]
        ADD CONSTRAINT [FK_cob_UnidentifiedReceipts_EvidenceStoredFileIdsId_StoredFiles]
        FOREIGN KEY ([EvidenceStoredFileIdsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_RubricatedBooks_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [con].[RubricatedBooks]
        ADD CONSTRAINT [FK_con_RubricatedBooks_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaReceivedImports_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [fis].[ArcaReceivedImports]
        ADD CONSTRAINT [FK_fis_ArcaReceivedImports_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_FiscalProfiles_FiscalLogoStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [fis].[FiscalProfiles]
        ADD CONSTRAINT [FK_fis_FiscalProfiles_FiscalLogoStoredFileId_StoredFiles]
        FOREIGN KEY ([FiscalLogoStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxpayerRegistries_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [fis].[TaxpayerRegistries]
        ADD CONSTRAINT [FK_fis_TaxpayerRegistries_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_AssociateRegisterEditions_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [ins].[AssociateRegisterEditions]
        ADD CONSTRAINT [FK_ins_AssociateRegisterEditions_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeterReadings_PhotoIdsId_StoredFiles'
)
BEGIN
    ALTER TABLE [med].[MeterReadings]
        ADD CONSTRAINT [FK_med_MeterReadings_PhotoIdsId_StoredFiles]
        FOREIGN KEY ([PhotoIdsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ReadingImportJobs_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [med].[ReadingImportJobs]
        ADD CONSTRAINT [FK_med_ReadingImportJobs_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LegacyPortalImports_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [por].[LegacyPortalImports]
        ADD CONSTRAINT [FK_por_LegacyPortalImports_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalForms_PdfStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [por].[PortalForms]
        ADD CONSTRAINT [FK_por_PortalForms_PdfStoredFileId_StoredFiles]
        FOREIGN KEY ([PdfStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_NoveltyImportBatches_FileRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[NoveltyImportBatches]
        ADD CONSTRAINT [FK_sue_NoveltyImportBatches_FileRefId_StoredFiles]
        FOREIGN KEY ([FileRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_NormativeDocuments_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [tar].[NormativeDocuments]
        ADD CONSTRAINT [FK_tar_NormativeDocuments_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SubsidyRollImports_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [tar].[SubsidyRollImports]
        ADD CONSTRAINT [FK_tar_SubsidyRollImports_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PaymentFiles_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [tes].[PaymentFiles]
        ADD CONSTRAINT [FK_tes_PaymentFiles_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_BulkRuns_ResultStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [wfl].[BulkRuns]
        ADD CONSTRAINT [FK_wfl_BulkRuns_ResultStoredFileId_StoredFiles]
        FOREIGN KEY ([ResultStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalFormSubmissions_ReceiptStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [por].[PortalFormSubmissions]
        ADD CONSTRAINT [FK_por_PortalFormSubmissions_ReceiptStoredFileId_StoredFiles]
        FOREIGN KEY ([ReceiptStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalFormSubmissions_StoredFileIdsId_StoredFiles'
)
BEGIN
    ALTER TABLE [por].[PortalFormSubmissions]
        ADD CONSTRAINT [FK_por_PortalFormSubmissions_StoredFileIdsId_StoredFiles]
        FOREIGN KEY ([StoredFileIdsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExternalPayrollImports_FileRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[ExternalPayrollImports]
        ADD CONSTRAINT [FK_sue_ExternalPayrollImports_FileRefId_StoredFiles]
        FOREIGN KEY ([FileRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ExternalLedgerTransfers_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [con].[ExternalLedgerTransfers]
        ADD CONSTRAINT [FK_con_ExternalLedgerTransfers_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_TemplateVersions_AssetsId_StoredFiles'
)
BEGIN
    ALTER TABLE [wfl].[TemplateVersions]
        ADD CONSTRAINT [FK_wfl_TemplateVersions_AssetsId_StoredFiles]
        FOREIGN KEY ([AssetsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_TemplateVersions_PreviewStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [wfl].[TemplateVersions]
        ADD CONSTRAINT [FK_wfl_TemplateVersions_PreviewStoredFileId_StoredFiles]
        FOREIGN KEY ([PreviewStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_TreasuryHandovers_ReportStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[TreasuryHandovers]
        ADD CONSTRAINT [FK_cob_TreasuryHandovers_ReportStoredFileId_StoredFiles]
        FOREIGN KEY ([ReportStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_EvidenceStoredFileIdsId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_EvidenceStoredFileIdsId_StoredFiles]
        FOREIGN KEY ([EvidenceStoredFileIdsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleDocuments_DocumentId_StoredFiles'
)
BEGIN
    ALTER TABLE [soc].[VehicleDocuments]
        ADD CONSTRAINT [FK_soc_VehicleDocuments_DocumentId_StoredFiles]
        FOREIGN KEY ([DocumentId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentChannels_IconStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[PaymentChannels]
        ADD CONSTRAINT [FK_cob_PaymentChannels_IconStoredFileId_StoredFiles]
        FOREIGN KEY ([IconStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyDebtExports_ControlStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[AgencyDebtExports]
        ADD CONSTRAINT [FK_cob_AgencyDebtExports_ControlStoredFileId_StoredFiles]
        FOREIGN KEY ([ControlStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyDebtExports_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[AgencyDebtExports]
        ADD CONSTRAINT [FK_cob_AgencyDebtExports_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayTransactions_EvidenceStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[GatewayTransactions]
        ADD CONSTRAINT [FK_cob_GatewayTransactions_EvidenceStoredFileId_StoredFiles]
        FOREIGN KEY ([EvidenceStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeDocuments_FileRefsId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[EmployeeDocuments]
        ADD CONSTRAINT [FK_sue_EmployeeDocuments_FileRefsId_StoredFiles]
        FOREIGN KEY ([FileRefsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollConfigVersions_DiffReportRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[PayrollConfigVersions]
        ADD CONSTRAINT [FK_sue_PayrollConfigVersions_DiffReportRefId_StoredFiles]
        FOREIGN KEY ([DiffReportRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialRights_InstrumentDocumentId_StoredFiles'
)
BEGIN
    ALTER TABLE [soc].[BurialRights]
        ADD CONSTRAINT [FK_soc_BurialRights_InstrumentDocumentId_StoredFiles]
        FOREIGN KEY ([InstrumentDocumentId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LeaveRequests_AttachmentsId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[LeaveRequests]
        ADD CONSTRAINT [FK_sue_LeaveRequests_AttachmentsId_StoredFiles]
        FOREIGN KEY ([AttachmentsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_MasterImportJobs_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cfg].[MasterImportJobs]
        ADD CONSTRAINT [FK_cfg_MasterImportJobs_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Terminations_CertificatesIdsId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[Terminations]
        ADD CONSTRAINT [FK_sue_Terminations_CertificatesIdsId_StoredFiles]
        FOREIGN KEY ([CertificatesIdsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmploymentCertificates_FileRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[EmploymentCertificates]
        ADD CONSTRAINT [FK_sue_EmploymentCertificates_FileRefId_StoredFiles]
        FOREIGN KEY ([FileRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SourcingEvents_DossierCoverStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cmp].[SourcingEvents]
        ADD CONSTRAINT [FK_cmp_SourcingEvents_DossierCoverStoredFileId_StoredFiles]
        FOREIGN KEY ([DossierCoverStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyRemittances_ReportStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyRemittances]
        ADD CONSTRAINT [FK_fis_ThirdPartyRemittances_ReportStoredFileId_StoredFiles]
        FOREIGN KEY ([ReportStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlements_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlements]
        ADD CONSTRAINT [FK_cob_AgencySettlements_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Proxies_DocumentId_StoredFiles'
)
BEGIN
    ALTER TABLE [ins].[Proxies]
        ADD CONSTRAINT [FK_ins_Proxies_DocumentId_StoredFiles]
        FOREIGN KEY ([DocumentId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureEvidences_SignatureImageStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [wfl].[SignatureEvidences]
        ADD CONSTRAINT [FK_wfl_SignatureEvidences_SignatureImageStoredFileId_StoredFiles]
        FOREIGN KEY ([SignatureImageStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationReconciliations_ActStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [int].[IntegrationReconciliations]
        ADD CONSTRAINT [FK_int_IntegrationReconciliations_ActStoredFileId_StoredFiles]
        FOREIGN KEY ([ActStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDocuments_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDocuments]
        ADD CONSTRAINT [FK_fac_InvoiceDocuments_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_IncomeTaxDeclarations_FileRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[IncomeTaxDeclarations]
        ADD CONSTRAINT [FK_sue_IncomeTaxDeclarations_FileRefId_StoredFiles]
        FOREIGN KEY ([FileRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_DisciplinaryActions_DocumentRefsId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[DisciplinaryActions]
        ADD CONSTRAINT [FK_sue_DisciplinaryActions_DocumentRefsId_StoredFiles]
        FOREIGN KEY ([DocumentRefsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_ShareCertificates_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [ins].[ShareCertificates]
        ADD CONSTRAINT [FK_ins_ShareCertificates_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportExports_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [bia].[ReportExports]
        ADD CONSTRAINT [FK_bia_ReportExports_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReceivedWithholdings_AttachmentRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [tes].[ReceivedWithholdings]
        ADD CONSTRAINT [FK_tes_ReceivedWithholdings_AttachmentRefId_StoredFiles]
        FOREIGN KEY ([AttachmentRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingImports_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [fac].[BillingImports]
        ADD CONSTRAINT [FK_fac_BillingImports_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesDeliveries_SignatureFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [ven].[SalesDeliveries]
        ADD CONSTRAINT [FK_ven_SalesDeliveries_SignatureFileId_StoredFiles]
        FOREIGN KEY ([SignatureFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalDrafts_StoredFileIdsId_StoredFiles'
)
BEGIN
    ALTER TABLE [por].[PortalDrafts]
        ADD CONSTRAINT [FK_por_PortalDrafts_StoredFileIdsId_StoredFiles]
        FOREIGN KEY ([StoredFileIdsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InaesReports_AcknowledgementRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [ins].[InaesReports]
        ADD CONSTRAINT [FK_ins_InaesReports_AcknowledgementRefId_StoredFiles]
        FOREIGN KEY ([AcknowledgementRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InaesReports_StoredFileIdsId_StoredFiles'
)
BEGIN
    ALTER TABLE [ins].[InaesReports]
        ADD CONSTRAINT [FK_ins_InaesReports_StoredFileIdsId_StoredFiles]
        FOREIGN KEY ([StoredFileIdsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryRegulations_DocumentId_StoredFiles'
)
BEGIN
    ALTER TABLE [soc].[CemeteryRegulations]
        ADD CONSTRAINT [FK_soc_CemeteryRegulations_DocumentId_StoredFiles]
        FOREIGN KEY ([DocumentId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayslipNotifications_PdfRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[PayslipNotifications]
        ADD CONSTRAINT [FK_sue_PayslipNotifications_PdfRefId_StoredFiles]
        FOREIGN KEY ([PdfRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionReconciliations_MinutesStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[CollectionReconciliations]
        ADD CONSTRAINT [FK_cob_CollectionReconciliations_MinutesStoredFileId_StoredFiles]
        FOREIGN KEY ([MinutesStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldEvidence_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [tec].[FieldEvidence]
        ADD CONSTRAINT [FK_tec_FieldEvidence_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AccountStatements_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[AccountStatements]
        ADD CONSTRAINT [FK_cob_AccountStatements_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyNoveltyFiles_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[AgencyNoveltyFiles]
        ADD CONSTRAINT [FK_cob_AgencyNoveltyFiles_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationFileExchanges_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [int].[IntegrationFileExchanges]
        ADD CONSTRAINT [FK_int_IntegrationFileExchanges_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_StatutoryFilings_AcknowledgementRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[StatutoryFilings]
        ADD CONSTRAINT [FK_sue_StatutoryFilings_AcknowledgementRefId_StoredFiles]
        FOREIGN KEY ([AcknowledgementRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_StatutoryFilings_FileRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [sue].[StatutoryFilings]
        ADD CONSTRAINT [FK_sue_StatutoryFilings_FileRefId_StoredFiles]
        FOREIGN KEY ([FileRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementImports_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [tes].[BankStatementImports]
        ADD CONSTRAINT [FK_tes_BankStatementImports_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FuelLoads_TicketStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [soc].[FuelLoads]
        ADD CONSTRAINT [FK_soc_FuelLoads_TicketStoredFileId_StoredFiles]
        FOREIGN KEY ([TicketStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierPortalSubmissions_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cmp].[SupplierPortalSubmissions]
        ADD CONSTRAINT [FK_cmp_SupplierPortalSubmissions_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_AiInvoiceExtractions_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cmp].[AiInvoiceExtractions]
        ADD CONSTRAINT [FK_cmp_AiInvoiceExtractions_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_StaticQrCodes_ImageStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[StaticQrCodes]
        ADD CONSTRAINT [FK_cob_StaticQrCodes_ImageStoredFileId_StoredFiles]
        FOREIGN KEY ([ImageStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_FinancialStatementRuns_StoredFileIdsId_StoredFiles'
)
BEGIN
    ALTER TABLE [con].[FinancialStatementRuns]
        ADD CONSTRAINT [FK_con_FinancialStatementRuns_StoredFileIdsId_StoredFiles]
        FOREIGN KEY ([StoredFileIdsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Receipts_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cob].[Receipts]
        ADD CONSTRAINT [FK_cob_Receipts_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialServiceCases_DeathCertificateDocumentId_StoredFiles'
)
BEGIN
    ALTER TABLE [soc].[BurialServiceCases]
        ADD CONSTRAINT [FK_soc_BurialServiceCases_DeathCertificateDocumentId_StoredFiles]
        FOREIGN KEY ([DeathCertificateDocumentId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ProviderAgreements_DocumentId_StoredFiles'
)
BEGIN
    ALTER TABLE [soc].[ProviderAgreements]
        ADD CONSTRAINT [FK_soc_ProviderAgreements_DocumentId_StoredFiles]
        FOREIGN KEY ([DocumentId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialRightEvents_DocumentIdsId_StoredFiles'
)
BEGIN
    ALTER TABLE [soc].[BurialRightEvents]
        ADD CONSTRAINT [FK_soc_BurialRightEvents_DocumentIdsId_StoredFiles]
        FOREIGN KEY ([DocumentIdsId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsSettlements_DeclarationStoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsSettlements]
        ADD CONSTRAINT [FK_cmp_SignalRightsSettlements_DeclarationStoredFileId_StoredFiles]
        FOREIGN KEY ([DeclarationStoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingTerminations_DocumentRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [soc].[HousingTerminations]
        ADD CONSTRAINT [FK_soc_HousingTerminations_DocumentRefId_StoredFiles]
        FOREIGN KEY ([DocumentRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Minutes_StoredFileId_StoredFiles'
)
BEGIN
    ALTER TABLE [ins].[Minutes]
        ADD CONSTRAINT [FK_ins_Minutes_StoredFileId_StoredFiles]
        FOREIGN KEY ([StoredFileId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_Reconciliations_ReportRefId_StoredFiles'
)
BEGIN
    ALTER TABLE [tes].[Reconciliations]
        ADD CONSTRAINT [FK_tes_Reconciliations_ReportRefId_StoredFiles]
        FOREIGN KEY ([ReportRefId]) REFERENCES [pla].[StoredFiles] ([StoredFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementLines_UnidentifiedCaseId_UnidentifiedReceipts'
)
BEGIN
    ALTER TABLE [tes].[BankStatementLines]
        ADD CONSTRAINT [FK_tes_BankStatementLines_UnidentifiedCaseId_UnidentifiedReceipts]
        FOREIGN KEY ([UnidentifiedCaseId]) REFERENCES [cob].[UnidentifiedReceipts] ([UnidentifiedReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlementLines_UnidentifiedId_UnidentifiedReceipts'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlementLines]
        ADD CONSTRAINT [FK_cob_AgencySettlementLines_UnidentifiedId_UnidentifiedReceipts]
        FOREIGN KEY ([UnidentifiedId]) REFERENCES [cob].[UnidentifiedReceipts] ([UnidentifiedReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalEntries_RubricatedBookId_RubricatedBooks'
)
BEGIN
    ALTER TABLE [con].[JournalEntries]
        ADD CONSTRAINT [FK_con_JournalEntries_RubricatedBookId_RubricatedBooks]
        FOREIGN KEY ([RubricatedBookId]) REFERENCES [con].[RubricatedBooks] ([RubricatedBookId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_VatReconciliations_ImportId_ArcaReceivedImports'
)
BEGIN
    ALTER TABLE [fis].[VatReconciliations]
        ADD CONSTRAINT [FK_fis_VatReconciliations_ImportId_ArcaReceivedImports]
        FOREIGN KEY ([ImportId]) REFERENCES [fis].[ArcaReceivedImports] ([ArcaReceivedImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxpayerRegistryEntries_RegistryId_TaxpayerRegistries'
)
BEGIN
    ALTER TABLE [fis].[TaxpayerRegistryEntries]
        ADD CONSTRAINT [FK_fis_TaxpayerRegistryEntries_RegistryId_TaxpayerRegistries]
        FOREIGN KEY ([RegistryId]) REFERENCES [fis].[TaxpayerRegistries] ([TaxpayerRegistryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_reading_MeterReadingId_MeterReadings'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_reading]
        ADD CONSTRAINT [FK_bia_Bi_fact_reading_MeterReadingId_MeterReadings]
        FOREIGN KEY ([MeterReadingId]) REFERENCES [med].[MeterReadings] ([MeterReadingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ReadingTasks_CapturedReadingId_MeterReadings'
)
BEGIN
    ALTER TABLE [med].[ReadingTasks]
        ADD CONSTRAINT [FK_med_ReadingTasks_CapturedReadingId_MeterReadings]
        FOREIGN KEY ([CapturedReadingId]) REFERENCES [med].[MeterReadings] ([MeterReadingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LegacyPortalUserMap_ImportId_LegacyPortalImports'
)
BEGIN
    ALTER TABLE [por].[LegacyPortalUserMap]
        ADD CONSTRAINT [FK_por_LegacyPortalUserMap_ImportId_LegacyPortalImports]
        FOREIGN KEY ([ImportId]) REFERENCES [por].[LegacyPortalImports] ([LegacyPortalImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalUserPreferences_DismissedBannerIdsId_PortalBanners'
)
BEGIN
    ALTER TABLE [por].[PortalUserPreferences]
        ADD CONSTRAINT [FK_por_PortalUserPreferences_DismissedBannerIdsId_PortalBanners]
        FOREIGN KEY ([DismissedBannerIdsId]) REFERENCES [por].[PortalBanners] ([PortalBannerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_MedicalProfessionals_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[MedicalProfessionals]
        ADD CONSTRAINT [FK_soc_MedicalProfessionals_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleMaintenances_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[VehicleMaintenances]
        ADD CONSTRAINT [FK_soc_VehicleMaintenances_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TransportTrips_CompanyProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[TransportTrips]
        ADD CONSTRAINT [FK_soc_TransportTrips_CompanyProviderId_CareProviders]
        FOREIGN KEY ([CompanyProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FleetVehicles_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[FleetVehicles]
        ADD CONSTRAINT [FK_soc_FleetVehicles_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BloodCoverageRequests_FacilityId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[BloodCoverageRequests]
        ADD CONSTRAINT [FK_soc_BloodCoverageRequests_FacilityId_CareProviders]
        FOREIGN KEY ([FacilityId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BenefitRequests_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[BenefitRequests]
        ADD CONSTRAINT [FK_soc_BenefitRequests_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialWithdrawals_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialWithdrawals]
        ADD CONSTRAINT [FK_soc_HousingMaterialWithdrawals_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialServiceCases_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[BurialServiceCases]
        ADD CONSTRAINT [FK_soc_BurialServiceCases_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingCertificates_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[HousingCertificates]
        ADD CONSTRAINT [FK_soc_HousingCertificates_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ProviderAgreements_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[ProviderAgreements]
        ADD CONSTRAINT [FK_soc_ProviderAgreements_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HealthAuthorizations_ProviderId_CareProviders'
)
BEGIN
    ALTER TABLE [soc].[HealthAuthorizations]
        ADD CONSTRAINT [FK_soc_HealthAuthorizations_ProviderId_CareProviders]
        FOREIGN KEY ([ProviderId]) REFERENCES [soc].[CareProviders] ([CareProviderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryRegulations_CemeteryId_Cemeteries'
)
BEGIN
    ALTER TABLE [soc].[CemeteryRegulations]
        ADD CONSTRAINT [FK_soc_CemeteryRegulations_CemeteryId_Cemeteries]
        FOREIGN KEY ([CemeteryId]) REFERENCES [soc].[Cemeteries] ([CemeteryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialUnits_CemeteryId_Cemeteries'
)
BEGIN
    ALTER TABLE [soc].[BurialUnits]
        ADD CONSTRAINT [FK_soc_BurialUnits_CemeteryId_Cemeteries]
        FOREIGN KEY ([CemeteryId]) REFERENCES [soc].[Cemeteries] ([CemeteryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FleetVehicles_FuelTypeId_FuelTypes'
)
BEGIN
    ALTER TABLE [soc].[FleetVehicles]
        ADD CONSTRAINT [FK_soc_FleetVehicles_FuelTypeId_FuelTypes]
        FOREIGN KEY ([FuelTypeId]) REFERENCES [soc].[FuelTypes] ([FuelTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FuelLoads_FuelTypeId_FuelTypes'
)
BEGIN
    ALTER TABLE [soc].[FuelLoads]
        ADD CONSTRAINT [FK_soc_FuelLoads_FuelTypeId_FuelTypes]
        FOREIGN KEY ([FuelTypeId]) REFERENCES [soc].[FuelTypes] ([FuelTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingActivities_StageId_HousingStages'
)
BEGIN
    ALTER TABLE [soc].[HousingActivities]
        ADD CONSTRAINT [FK_soc_HousingActivities_StageId_HousingStages]
        FOREIGN KEY ([StageId]) REFERENCES [soc].[HousingStages] ([HousingStageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialWithdrawals_StageId_HousingStages'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialWithdrawals]
        ADD CONSTRAINT [FK_soc_HousingMaterialWithdrawals_StageId_HousingStages]
        FOREIGN KEY ([StageId]) REFERENCES [soc].[HousingStages] ([HousingStageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingActivityMaterials_ActivityId_HousingActivities'
)
BEGIN
    ALTER TABLE [soc].[HousingActivityMaterials]
        ADD CONSTRAINT [FK_soc_HousingActivityMaterials_ActivityId_HousingActivities]
        FOREIGN KEY ([ActivityId]) REFERENCES [soc].[HousingActivities] ([HousingActivityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_ActivityId_HousingActivities'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_ActivityId_HousingActivities]
        FOREIGN KEY ([ActivityId]) REFERENCES [soc].[HousingActivities] ([HousingActivityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_MedicalProfessionals_SpecialtyId_MedicalSpecialties'
)
BEGIN
    ALTER TABLE [soc].[MedicalProfessionals]
        ADD CONSTRAINT [FK_soc_MedicalProfessionals_SpecialtyId_MedicalSpecialties]
        FOREIGN KEY ([SpecialtyId]) REFERENCES [soc].[MedicalSpecialties] ([MedicalSpecialtyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TransportTrips_ProfessionalIdsId_MedicalProfessionals'
)
BEGIN
    ALTER TABLE [soc].[TransportTrips]
        ADD CONSTRAINT [FK_soc_TransportTrips_ProfessionalIdsId_MedicalProfessionals]
        FOREIGN KEY ([ProfessionalIdsId]) REFERENCES [soc].[MedicalProfessionals] ([MedicalProfessionalId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TransportTrips_CharacteristicId_TripCharacteristics'
)
BEGIN
    ALTER TABLE [soc].[TransportTrips]
        ADD CONSTRAINT [FK_soc_TransportTrips_CharacteristicId_TripCharacteristics]
        FOREIGN KEY ([CharacteristicId]) REFERENCES [soc].[TripCharacteristics] ([TripCharacteristicId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_OrthopedicItems_FixedAssetId_FixedAssets'
)
BEGIN
    ALTER TABLE [soc].[OrthopedicItems]
        ADD CONSTRAINT [FK_soc_OrthopedicItems_FixedAssetId_FixedAssets]
        FOREIGN KEY ([FixedAssetId]) REFERENCES [stk].[FixedAssets] ([FixedAssetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_DepreciationRuns_FixedAssetId_FixedAssets'
)
BEGIN
    ALTER TABLE [stk].[DepreciationRuns]
        ADD CONSTRAINT [FK_stk_DepreciationRuns_FixedAssetId_FixedAssets]
        FOREIGN KEY ([FixedAssetId]) REFERENCES [stk].[FixedAssets] ([FixedAssetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetDepreciations_FixedAssetId_FixedAssets'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetDepreciations]
        ADD CONSTRAINT [FK_stk_FixedAssetDepreciations_FixedAssetId_FixedAssets]
        FOREIGN KEY ([FixedAssetId]) REFERENCES [stk].[FixedAssets] ([FixedAssetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetValueChanges_FixedAssetId_FixedAssets'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetValueChanges]
        ADD CONSTRAINT [FK_stk_FixedAssetValueChanges_FixedAssetId_FixedAssets]
        FOREIGN KEY ([FixedAssetId]) REFERENCES [stk].[FixedAssets] ([FixedAssetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FleetVehicles_FixedAssetId_FixedAssets'
)
BEGIN
    ALTER TABLE [soc].[FleetVehicles]
        ADD CONSTRAINT [FK_soc_FleetVehicles_FixedAssetId_FixedAssets]
        FOREIGN KEY ([FixedAssetId]) REFERENCES [stk].[FixedAssets] ([FixedAssetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetHistory_FixedAssetId_FixedAssets'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetHistory]
        ADD CONSTRAINT [FK_stk_FixedAssetHistory_FixedAssetId_FixedAssets]
        FOREIGN KEY ([FixedAssetId]) REFERENCES [stk].[FixedAssets] ([FixedAssetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_OrthopedicLoans_ItemId_OrthopedicItems'
)
BEGIN
    ALTER TABLE [soc].[OrthopedicLoans]
        ADD CONSTRAINT [FK_soc_OrthopedicLoans_ItemId_OrthopedicItems]
        FOREIGN KEY ([ItemId]) REFERENCES [soc].[OrthopedicItems] ([OrthopedicItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetDepreciations_DepreciationRunId_DepreciationRuns'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetDepreciations]
        ADD CONSTRAINT [FK_stk_FixedAssetDepreciations_DepreciationRunId_DepreciationRuns]
        FOREIGN KEY ([DepreciationRunId]) REFERENCES [stk].[DepreciationRuns] ([DepreciationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetDepreciations_RunId_DepreciationRuns'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetDepreciations]
        ADD CONSTRAINT [FK_stk_FixedAssetDepreciations_RunId_DepreciationRuns]
        FOREIGN KEY ([RunId]) REFERENCES [stk].[DepreciationRuns] ([DepreciationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingActivityMaterials_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [soc].[HousingActivityMaterials]
        ADD CONSTRAINT [FK_soc_HousingActivityMaterials_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemKits_ComponentItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ItemKits]
        ADD CONSTRAINT [FK_stk_ItemKits_ComponentItemId_InventoryItems]
        FOREIGN KEY ([ComponentItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemKits_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ItemKits]
        ADD CONSTRAINT [FK_stk_ItemKits_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemKits_KitItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ItemKits]
        ADD CONSTRAINT [FK_stk_ItemKits_KitItemId_InventoryItems]
        FOREIGN KEY ([KitItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ManufacturingStages_ItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ManufacturingStages]
        ADD CONSTRAINT [FK_stk_ManufacturingStages_ItemId_InventoryItems]
        FOREIGN KEY ([ItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_CostLayers_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[CostLayers]
        ADD CONSTRAINT [FK_stk_CostLayers_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemCostStates_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ItemCostStates]
        ADD CONSTRAINT [FK_stk_ItemCostStates_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ReorderSuggestions_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ReorderSuggestions]
        ADD CONSTRAINT [FK_stk_ReorderSuggestions_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockReservations_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[StockReservations]
        ADD CONSTRAINT [FK_stk_StockReservations_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemLocationDefaults_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[ItemLocationDefaults]
        ADD CONSTRAINT [FK_stk_ItemLocationDefaults_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderMaterials_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderMaterials]
        ADD CONSTRAINT [FK_tec_WorkOrderMaterials_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialAllocations_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialAllocations]
        ADD CONSTRAINT [FK_soc_HousingMaterialAllocations_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_BomStructureVersions_ItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[BomStructureVersions]
        ADD CONSTRAINT [FK_stk_BomStructureVersions_ItemId_InventoryItems]
        FOREIGN KEY ([ItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_BomStructures_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[BomStructures]
        ADD CONSTRAINT [FK_stk_BomStructures_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockBalances_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[StockBalances]
        ADD CONSTRAINT [FK_stk_StockBalances_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Lots_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[Lots]
        ADD CONSTRAINT [FK_stk_Lots_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgressMaterials_InventoryItemId_InventoryItems'
)
BEGIN
    ALTER TABLE [soc].[HousingProgressMaterials]
        ADD CONSTRAINT [FK_soc_HousingProgressMaterials_InventoryItemId_InventoryItems]
        FOREIGN KEY ([InventoryItemId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseForecasts_ProductId_InventoryItems'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseForecasts]
        ADD CONSTRAINT [FK_cmp_PurchaseForecasts_ProductId_InventoryItems]
        FOREIGN KEY ([ProductId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Revaluations_InventoryItemIdsId_InventoryItems'
)
BEGIN
    ALTER TABLE [stk].[Revaluations]
        ADD CONSTRAINT [FK_stk_Revaluations_InventoryItemIdsId_InventoryItems]
        FOREIGN KEY ([InventoryItemIdsId]) REFERENCES [stk].[InventoryItems] ([InventoryItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_MrpRuns_ManufacturingOrderIdsId_ManufacturingOrders'
)
BEGIN
    ALTER TABLE [stk].[MrpRuns]
        ADD CONSTRAINT [FK_stk_MrpRuns_ManufacturingOrderIdsId_ManufacturingOrders]
        FOREIGN KEY ([ManufacturingOrderIdsId]) REFERENCES [stk].[ManufacturingOrders] ([ManufacturingOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ProductionReports_ManufacturingOrderId_ManufacturingOrders'
)
BEGIN
    ALTER TABLE [stk].[ProductionReports]
        ADD CONSTRAINT [FK_stk_ProductionReports_ManufacturingOrderId_ManufacturingOrders]
        FOREIGN KEY ([ManufacturingOrderId]) REFERENCES [stk].[ManufacturingOrders] ([ManufacturingOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_SerialUnitEvents_RmaCaseId_RmaCases'
)
BEGIN
    ALTER TABLE [stk].[SerialUnitEvents]
        ADD CONSTRAINT [FK_stk_SerialUnitEvents_RmaCaseId_RmaCases]
        FOREIGN KEY ([RmaCaseId]) REFERENCES [stk].[RmaCases] ([RmaCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockReservations_SerialUnitId_SerialUnits'
)
BEGIN
    ALTER TABLE [stk].[StockReservations]
        ADD CONSTRAINT [FK_stk_StockReservations_SerialUnitId_SerialUnits]
        FOREIGN KEY ([SerialUnitId]) REFERENCES [stk].[SerialUnits] ([SerialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ServiceReceptions_SerialUnitId_SerialUnits'
)
BEGIN
    ALTER TABLE [stk].[ServiceReceptions]
        ADD CONSTRAINT [FK_stk_ServiceReceptions_SerialUnitId_SerialUnits]
        FOREIGN KEY ([SerialUnitId]) REFERENCES [stk].[SerialUnits] ([SerialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractEquipmentAssignments_SerialUnitId_SerialUnits'
)
BEGIN
    ALTER TABLE [cat].[ContractEquipmentAssignments]
        ADD CONSTRAINT [FK_cat_ContractEquipmentAssignments_SerialUnitId_SerialUnits]
        FOREIGN KEY ([SerialUnitId]) REFERENCES [stk].[SerialUnits] ([SerialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_SerialUnitEvents_SerialUnitId_SerialUnits'
)
BEGIN
    ALTER TABLE [stk].[SerialUnitEvents]
        ADD CONSTRAINT [FK_stk_SerialUnitEvents_SerialUnitId_SerialUnits]
        FOREIGN KEY ([SerialUnitId]) REFERENCES [stk].[SerialUnits] ([SerialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkDevices_SerialUnitId_SerialUnits'
)
BEGIN
    ALTER TABLE [tec].[NetworkDevices]
        ADD CONSTRAINT [FK_tec_NetworkDevices_SerialUnitId_SerialUnits]
        FOREIGN KEY ([SerialUnitId]) REFERENCES [stk].[SerialUnits] ([SerialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_stockMovement_StockMovementId_StockMovements'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_stockMovement]
        ADD CONSTRAINT [FK_bia_Bi_fact_stockMovement_StockMovementId_StockMovements]
        FOREIGN KEY ([StockMovementId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_CostLayers_InMovementId_StockMovements'
)
BEGIN
    ALTER TABLE [stk].[CostLayers]
        ADD CONSTRAINT [FK_stk_CostLayers_InMovementId_StockMovements]
        FOREIGN KEY ([InMovementId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_CostLayers_StockMovementId_StockMovements'
)
BEGIN
    ALTER TABLE [stk].[CostLayers]
        ADD CONSTRAINT [FK_stk_CostLayers_StockMovementId_StockMovements]
        FOREIGN KEY ([StockMovementId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemCostStates_InMovementId_StockMovements'
)
BEGIN
    ALTER TABLE [stk].[ItemCostStates]
        ADD CONSTRAINT [FK_stk_ItemCostStates_InMovementId_StockMovements]
        FOREIGN KEY ([InMovementId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialAllocations_StockMovementRefId_StockMovements'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialAllocations]
        ADD CONSTRAINT [FK_soc_HousingMaterialAllocations_StockMovementRefId_StockMovements]
        FOREIGN KEY ([StockMovementRefId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_SerialUnitEvents_MovementId_StockMovements'
)
BEGIN
    ALTER TABLE [stk].[SerialUnitEvents]
        ADD CONSTRAINT [FK_stk_SerialUnitEvents_MovementId_StockMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialWithdrawals_StockMovementRefId_StockMovements'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialWithdrawals]
        ADD CONSTRAINT [FK_soc_HousingMaterialWithdrawals_StockMovementRefId_StockMovements]
        FOREIGN KEY ([StockMovementRefId]) REFERENCES [stk].[StockMovements] ([StockMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemCostStates_ScopeWarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[ItemCostStates]
        ADD CONSTRAINT [FK_stk_ItemCostStates_ScopeWarehouseId_Warehouses]
        FOREIGN KEY ([ScopeWarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemCostStates_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[ItemCostStates]
        ADD CONSTRAINT [FK_stk_ItemCostStates_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ReorderSuggestions_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[ReorderSuggestions]
        ADD CONSTRAINT [FK_stk_ReorderSuggestions_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockReservations_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[StockReservations]
        ADD CONSTRAINT [FK_stk_StockReservations_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_WarehouseLocations_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[WarehouseLocations]
        ADD CONSTRAINT [FK_stk_WarehouseLocations_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemLocationDefaults_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[ItemLocationDefaults]
        ADD CONSTRAINT [FK_stk_ItemLocationDefaults_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldResources_CustodyWarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [tec].[FieldResources]
        ADD CONSTRAINT [FK_tec_FieldResources_CustodyWarehouseId_Warehouses]
        FOREIGN KEY ([CustodyWarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockBalances_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[StockBalances]
        ADD CONSTRAINT [FK_stk_StockBalances_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesDeliveries_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [ven].[SalesDeliveries]
        ADD CONSTRAINT [FK_ven_SalesDeliveries_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Crews_CustodyWarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [tec].[Crews]
        ADD CONSTRAINT [FK_tec_Crews_CustodyWarehouseId_Warehouses]
        FOREIGN KEY ([CustodyWarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Crews_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [tec].[Crews]
        ADD CONSTRAINT [FK_tec_Crews_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierReceipts_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [cmp].[SupplierReceipts]
        ADD CONSTRAINT [FK_cmp_SupplierReceipts_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_CrewSettlements_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[CrewSettlements]
        ADD CONSTRAINT [FK_stk_CrewSettlements_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialWithdrawals_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialWithdrawals]
        ADD CONSTRAINT [FK_soc_HousingMaterialWithdrawals_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosTerminals_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [ven].[PosTerminals]
        ADD CONSTRAINT [FK_ven_PosTerminals_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_PhysicalCounts_WarehouseId_Warehouses'
)
BEGIN
    ALTER TABLE [stk].[PhysicalCounts]
        ADD CONSTRAINT [FK_stk_PhysicalCounts_WarehouseId_Warehouses]
        FOREIGN KEY ([WarehouseId]) REFERENCES [stk].[Warehouses] ([WarehousId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesQuotes_StockReservationIdsId_StockReservations'
)
BEGIN
    ALTER TABLE [ven].[SalesQuotes]
        ADD CONSTRAINT [FK_ven_SalesQuotes_StockReservationIdsId_StockReservations]
        FOREIGN KEY ([StockReservationIdsId]) REFERENCES [stk].[StockReservations] ([StockReservationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ItemLocationDefaults_WarehouseLocationId_WarehouseLocations'
)
BEGIN
    ALTER TABLE [stk].[ItemLocationDefaults]
        ADD CONSTRAINT [FK_stk_ItemLocationDefaults_WarehouseLocationId_WarehouseLocations]
        FOREIGN KEY ([WarehouseLocationId]) REFERENCES [stk].[WarehouseLocations] ([WarehouseLocationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockBalances_LocationId_WarehouseLocations'
)
BEGIN
    ALTER TABLE [stk].[StockBalances]
        ADD CONSTRAINT [FK_stk_StockBalances_LocationId_WarehouseLocations]
        FOREIGN KEY ([LocationId]) REFERENCES [stk].[WarehouseLocations] ([WarehouseLocationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExternalPayrollImports_LayoutId_ExternalPayrollLayouts'
)
BEGIN
    ALTER TABLE [sue].[ExternalPayrollImports]
        ADD CONSTRAINT [FK_sue_ExternalPayrollImports_LayoutId_ExternalPayrollLayouts]
        FOREIGN KEY ([LayoutId]) REFERENCES [sue].[ExternalPayrollLayouts] ([ExternalPayrollLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_StatutoryFilings_LayoutId_ExternalPayrollLayouts'
)
BEGIN
    ALTER TABLE [sue].[StatutoryFilings]
        ADD CONSTRAINT [FK_sue_StatutoryFilings_LayoutId_ExternalPayrollLayouts]
        FOREIGN KEY ([LayoutId]) REFERENCES [sue].[ExternalPayrollLayouts] ([ExternalPayrollLayoutId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExtraItems_GroupId_ExtraGroups'
)
BEGIN
    ALTER TABLE [sue].[ExtraItems]
        ADD CONSTRAINT [FK_sue_ExtraItems_GroupId_ExtraGroups]
        FOREIGN KEY ([GroupId]) REFERENCES [sue].[ExtraGroups] ([ExtraGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_TimePunches_ImportBatchId_NoveltyImportBatches'
)
BEGIN
    ALTER TABLE [sue].[TimePunches]
        ADD CONSTRAINT [FK_sue_TimePunches_ImportBatchId_NoveltyImportBatches]
        FOREIGN KEY ([ImportBatchId]) REFERENCES [sue].[NoveltyImportBatches] ([NoveltyImportBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LeaveCauses_NoveltyTypeId_NoveltyTypes'
)
BEGIN
    ALTER TABLE [sue].[LeaveCauses]
        ADD CONSTRAINT [FK_sue_LeaveCauses_NoveltyTypeId_NoveltyTypes]
        FOREIGN KEY ([NoveltyTypeId]) REFERENCES [sue].[NoveltyTypes] ([NoveltyTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Novelties_NoveltyTypeId_NoveltyTypes'
)
BEGIN
    ALTER TABLE [sue].[Novelties]
        ADD CONSTRAINT [FK_sue_Novelties_NoveltyTypeId_NoveltyTypes]
        FOREIGN KEY ([NoveltyTypeId]) REFERENCES [sue].[NoveltyTypes] ([NoveltyTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LeaveRequests_LeaveCauseId_LeaveCauses'
)
BEGIN
    ALTER TABLE [sue].[LeaveRequests]
        ADD CONSTRAINT [FK_sue_LeaveRequests_LeaveCauseId_LeaveCauses]
        FOREIGN KEY ([LeaveCauseId]) REFERENCES [sue].[LeaveCauses] ([LeaveCausId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollAccountingRules_PayrollConceptId_PayrollConcepts'
)
BEGIN
    ALTER TABLE [sue].[PayrollAccountingRules]
        ADD CONSTRAINT [FK_sue_PayrollAccountingRules_PayrollConceptId_PayrollConcepts]
        FOREIGN KEY ([PayrollConceptId]) REFERENCES [sue].[PayrollConcepts] ([PayrollConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollRuns_PayrollTypeId_PayrollTypes'
)
BEGIN
    ALTER TABLE [sue].[PayrollRuns]
        ADD CONSTRAINT [FK_sue_PayrollRuns_PayrollTypeId_PayrollTypes]
        FOREIGN KEY ([PayrollTypeId]) REFERENCES [sue].[PayrollTypes] ([PayrollTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PerformanceCycles_TemplateId_PerformanceTemplates'
)
BEGIN
    ALTER TABLE [sue].[PerformanceCycles]
        ADD CONSTRAINT [FK_sue_PerformanceCycles_TemplateId_PerformanceTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [sue].[PerformanceTemplates] ([PerformanceTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PerformanceReviews_CycleId_PerformanceCycles'
)
BEGIN
    ALTER TABLE [sue].[PerformanceReviews]
        ADD CONSTRAINT [FK_sue_PerformanceReviews_CycleId_PerformanceCycles]
        FOREIGN KEY ([CycleId]) REFERENCES [sue].[PerformanceCycles] ([PerformanceCycleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Objectives_CycleId_PerformanceCycles'
)
BEGIN
    ALTER TABLE [sue].[Objectives]
        ADD CONSTRAINT [FK_sue_Objectives_CycleId_PerformanceCycles]
        FOREIGN KEY ([CycleId]) REFERENCES [sue].[PerformanceCycles] ([PerformanceCycleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeShiftAssignments_ShiftId_Shifts'
)
BEGIN
    ALTER TABLE [sue].[EmployeeShiftAssignments]
        ADD CONSTRAINT [FK_sue_EmployeeShiftAssignments_ShiftId_Shifts]
        FOREIGN KEY ([ShiftId]) REFERENCES [sue].[Shifts] ([ShiftId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Terminations_TerminationReasonId_TerminationReasons'
)
BEGIN
    ALTER TABLE [sue].[Terminations]
        ADD CONSTRAINT [FK_sue_Terminations_TerminationReasonId_TerminationReasons]
        FOREIGN KEY ([TerminationReasonId]) REFERENCES [sue].[TerminationReasons] ([TerminationReasonId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_BenefitGroupMembers_GroupId_BenefitGroups'
)
BEGIN
    ALTER TABLE [tar].[BenefitGroupMembers]
        ADD CONSTRAINT [FK_tar_BenefitGroupMembers_GroupId_BenefitGroups]
        FOREIGN KEY ([GroupId]) REFERENCES [tar].[BenefitGroups] ([BenefitGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillableItems_CalculationId_Calculations'
)
BEGIN
    ALTER TABLE [fac].[BillableItems]
        ADD CONSTRAINT [FK_fac_BillableItems_CalculationId_Calculations]
        FOREIGN KEY ([CalculationId]) REFERENCES [tar].[Calculations] ([CalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_RoundingCarryEntries_CalculationId_Calculations'
)
BEGIN
    ALTER TABLE [tar].[RoundingCarryEntries]
        ADD CONSTRAINT [FK_tar_RoundingCarryEntries_CalculationId_Calculations]
        FOREIGN KEY ([CalculationId]) REFERENCES [tar].[Calculations] ([CalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_invoiceLine_LineId_BillableItems'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_invoiceLine]
        ADD CONSTRAINT [FK_bia_Bi_fact_invoiceLine_LineId_BillableItems]
        FOREIGN KEY ([LineId]) REFERENCES [fac].[BillableItems] ([BillableItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryActs_BillingRefId_BillableItems'
)
BEGIN
    ALTER TABLE [soc].[CemeteryActs]
        ADD CONSTRAINT [FK_soc_CemeteryActs_BillingRefId_BillableItems]
        FOREIGN KEY ([BillingRefId]) REFERENCES [fac].[BillableItems] ([BillableItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestBillingRunItems_ChargeRequestId_BillableItems'
)
BEGIN
    ALTER TABLE [mor].[InterestBillingRunItems]
        ADD CONSTRAINT [FK_mor_InterestBillingRunItems_ChargeRequestId_BillableItems]
        FOREIGN KEY ([ChargeRequestId]) REFERENCES [fac].[BillableItems] ([BillableItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TransportTrips_BillingRefId_BillableItems'
)
BEGIN
    ALTER TABLE [soc].[TransportTrips]
        ADD CONSTRAINT [FK_soc_TransportTrips_BillingRefId_BillableItems]
        FOREIGN KEY ([BillingRefId]) REFERENCES [fac].[BillableItems] ([BillableItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementInstallments_BillableItemId_BillableItems'
)
BEGIN
    ALTER TABLE [mor].[AgreementInstallments]
        ADD CONSTRAINT [FK_mor_AgreementInstallments_BillableItemId_BillableItems]
        FOREIGN KEY ([BillableItemId]) REFERENCES [fac].[BillableItems] ([BillableItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_CostChargeRequestId_BillableItems'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_CostChargeRequestId_BillableItems]
        FOREIGN KEY ([CostChargeRequestId]) REFERENCES [fac].[BillableItems] ([BillableItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DeferredInterests_BillableItemId_BillableItems'
)
BEGIN
    ALTER TABLE [mor].[DeferredInterests]
        ADD CONSTRAINT [FK_mor_DeferredInterests_BillableItemId_BillableItems]
        FOREIGN KEY ([BillableItemId]) REFERENCES [fac].[BillableItems] ([BillableItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterruptionChargeRules_EventChargeId_EventCharges'
)
BEGIN
    ALTER TABLE [mor].[InterruptionChargeRules]
        ADD CONSTRAINT [FK_mor_InterruptionChargeRules_EventChargeId_EventCharges]
        FOREIGN KEY ([EventChargeId]) REFERENCES [tar].[EventCharges] ([EventChargeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_EventChargeBonuses_EventChargeId_EventCharges'
)
BEGIN
    ALTER TABLE [tar].[EventChargeBonuses]
        ADD CONSTRAINT [FK_tar_EventChargeBonuses_EventChargeId_EventCharges]
        FOREIGN KEY ([EventChargeId]) REFERENCES [tar].[EventCharges] ([EventChargeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_PhoneRates_RatePlanId_PhoneRatePlans'
)
BEGIN
    ALTER TABLE [tar].[PhoneRates]
        ADD CONSTRAINT [FK_tar_PhoneRates_RatePlanId_PhoneRatePlans]
        FOREIGN KEY ([RatePlanId]) REFERENCES [tar].[PhoneRatePlans] ([PhoneRatePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_PhoneBandAssignments_RatePlanId_PhoneRatePlans'
)
BEGIN
    ALTER TABLE [tar].[PhoneBandAssignments]
        ADD CONSTRAINT [FK_tar_PhoneBandAssignments_RatePlanId_PhoneRatePlans]
        FOREIGN KEY ([RatePlanId]) REFERENCES [tar].[PhoneRatePlans] ([PhoneRatePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_PhoneBandAssignments_BandId_PhoneTimeBands'
)
BEGIN
    ALTER TABLE [tar].[PhoneBandAssignments]
        ADD CONSTRAINT [FK_tar_PhoneBandAssignments_BandId_PhoneTimeBands]
        FOREIGN KEY ([BandId]) REFERENCES [tar].[PhoneTimeBands] ([PhoneTimeBandId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SubsidyRollImports_RegimeId_SubsidyRegimes'
)
BEGIN
    ALTER TABLE [tar].[SubsidyRollImports]
        ADD CONSTRAINT [FK_tar_SubsidyRollImports_RegimeId_SubsidyRegimes]
        FOREIGN KEY ([RegimeId]) REFERENCES [tar].[SubsidyRegimes] ([SubsidyRegimeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SubsidyEnrollments_RegimeId_SubsidyRegimes'
)
BEGIN
    ALTER TABLE [tar].[SubsidyEnrollments]
        ADD CONSTRAINT [FK_tar_SubsidyEnrollments_RegimeId_SubsidyRegimes]
        FOREIGN KEY ([RegimeId]) REFERENCES [tar].[SubsidyRegimes] ([SubsidyRegimeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SubsidyEnrollments_RollImportId_SubsidyRollImports'
)
BEGIN
    ALTER TABLE [tar].[SubsidyEnrollments]
        ADD CONSTRAINT [FK_tar_SubsidyEnrollments_RollImportId_SubsidyRollImports]
        FOREIGN KEY ([RollImportId]) REFERENCES [tar].[SubsidyRollImports] ([SubsidyRollImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceDependents_AssignedTariffId_TariffCategoryRates'
)
BEGIN
    ALTER TABLE [soc].[ServiceDependents]
        ADD CONSTRAINT [FK_soc_ServiceDependents_AssignedTariffId_TariffCategoryRates]
        FOREIGN KEY ([AssignedTariffId]) REFERENCES [tar].[TariffCategoryRates] ([TariffCategoryRateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_CategoryCoefficients_ScheduleId_TariffSchedules'
)
BEGIN
    ALTER TABLE [tar].[CategoryCoefficients]
        ADD CONSTRAINT [FK_tar_CategoryCoefficients_ScheduleId_TariffSchedules]
        FOREIGN KEY ([ScheduleId]) REFERENCES [tar].[TariffSchedules] ([TariffScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_ProductPrices_ScheduleId_TariffSchedules'
)
BEGIN
    ALTER TABLE [tar].[ProductPrices]
        ADD CONSTRAINT [FK_tar_ProductPrices_ScheduleId_TariffSchedules]
        FOREIGN KEY ([ScheduleId]) REFERENCES [tar].[TariffSchedules] ([TariffScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SimulationRuns_LinkedScheduleId_TariffSchedules'
)
BEGIN
    ALTER TABLE [tar].[SimulationRuns]
        ADD CONSTRAINT [FK_tar_SimulationRuns_LinkedScheduleId_TariffSchedules]
        FOREIGN KEY ([LinkedScheduleId]) REFERENCES [tar].[TariffSchedules] ([TariffScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_AdherentRates_ScheduleId_TariffSchedules'
)
BEGIN
    ALTER TABLE [tar].[AdherentRates]
        ADD CONSTRAINT [FK_tar_AdherentRates_ScheduleId_TariffSchedules]
        FOREIGN KEY ([ScheduleId]) REFERENCES [tar].[TariffSchedules] ([TariffScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_RetroactiveDiffRuns_ScheduleId_TariffSchedules'
)
BEGIN
    ALTER TABLE [tar].[RetroactiveDiffRuns]
        ADD CONSTRAINT [FK_tar_RetroactiveDiffRuns_ScheduleId_TariffSchedules]
        FOREIGN KEY ([ScheduleId]) REFERENCES [tar].[TariffSchedules] ([TariffScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollConfigVersions_SimulationRunId_SimulationRuns'
)
BEGIN
    ALTER TABLE [sue].[PayrollConfigVersions]
        ADD CONSTRAINT [FK_sue_PayrollConfigVersions_SimulationRunId_SimulationRuns]
        FOREIGN KEY ([SimulationRunId]) REFERENCES [tar].[SimulationRuns] ([SimulationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SimulationResults_SimulationRunId_SimulationRuns'
)
BEGIN
    ALTER TABLE [tar].[SimulationResults]
        ADD CONSTRAINT [FK_tar_SimulationResults_SimulationRunId_SimulationRuns]
        FOREIGN KEY ([SimulationRunId]) REFERENCES [tar].[SimulationRuns] ([SimulationRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TechnicalProcedures_InstallerId_CertifiedInstallers'
)
BEGIN
    ALTER TABLE [tec].[TechnicalProcedures]
        ADD CONSTRAINT [FK_tec_TechnicalProcedures_InstallerId_CertifiedInstallers]
        FOREIGN KEY ([InstallerId]) REFERENCES [tec].[CertifiedInstallers] ([CertifiedInstallerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FeasibilityRequests_EstimateId_ConnectionEstimates'
)
BEGIN
    ALTER TABLE [tec].[FeasibilityRequests]
        ADD CONSTRAINT [FK_tec_FeasibilityRequests_EstimateId_ConnectionEstimates]
        FOREIGN KEY ([EstimateId]) REFERENCES [tec].[ConnectionEstimates] ([ConnectionEstimateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkLayers_NetworkId_Networks'
)
BEGIN
    ALTER TABLE [tec].[NetworkLayers]
        ADD CONSTRAINT [FK_tec_NetworkLayers_NetworkId_Networks]
        FOREIGN KEY ([NetworkId]) REFERENCES [tec].[Networks] ([NetworkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentTypes_NetworkId_Networks'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentTypes]
        ADD CONSTRAINT [FK_tec_NetworkComponentTypes_NetworkId_Networks]
        FOREIGN KEY ([NetworkId]) REFERENCES [tec].[Networks] ([NetworkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentRelations_NetworkId_Networks'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentRelations]
        ADD CONSTRAINT [FK_tec_NetworkComponentRelations_NetworkId_Networks]
        FOREIGN KEY ([NetworkId]) REFERENCES [tec].[Networks] ([NetworkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkElements_NetworkId_Networks'
)
BEGIN
    ALTER TABLE [tec].[NetworkElements]
        ADD CONSTRAINT [FK_tec_NetworkElements_NetworkId_Networks]
        FOREIGN KEY ([NetworkId]) REFERENCES [tec].[Networks] ([NetworkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentTypes_LayerId_NetworkLayers'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentTypes]
        ADD CONSTRAINT [FK_tec_NetworkComponentTypes_LayerId_NetworkLayers]
        FOREIGN KEY ([LayerId]) REFERENCES [tec].[NetworkLayers] ([NetworkLayerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentRelations_LayerId_NetworkLayers'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentRelations]
        ADD CONSTRAINT [FK_tec_NetworkComponentRelations_LayerId_NetworkLayers]
        FOREIGN KEY ([LayerId]) REFERENCES [tec].[NetworkLayers] ([NetworkLayerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkElements_LayerId_NetworkLayers'
)
BEGIN
    ALTER TABLE [tec].[NetworkElements]
        ADD CONSTRAINT [FK_tec_NetworkElements_LayerId_NetworkLayers]
        FOREIGN KEY ([LayerId]) REFERENCES [tec].[NetworkLayers] ([NetworkLayerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkAttributeDefs_ComponentTypeId_NetworkComponentTypes'
)
BEGIN
    ALTER TABLE [tec].[NetworkAttributeDefs]
        ADD CONSTRAINT [FK_tec_NetworkAttributeDefs_ComponentTypeId_NetworkComponentTypes]
        FOREIGN KEY ([ComponentTypeId]) REFERENCES [tec].[NetworkComponentTypes] ([NetworkComponentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentRelations_ChildTypeId_NetworkComponentTypes'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentRelations]
        ADD CONSTRAINT [FK_tec_NetworkComponentRelations_ChildTypeId_NetworkComponentTypes]
        FOREIGN KEY ([ChildTypeId]) REFERENCES [tec].[NetworkComponentTypes] ([NetworkComponentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkComponentRelations_ParentTypeId_NetworkComponentTypes'
)
BEGIN
    ALTER TABLE [tec].[NetworkComponentRelations]
        ADD CONSTRAINT [FK_tec_NetworkComponentRelations_ParentTypeId_NetworkComponentTypes]
        FOREIGN KEY ([ParentTypeId]) REFERENCES [tec].[NetworkComponentTypes] ([NetworkComponentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkElements_ComponentTypeId_NetworkComponentTypes'
)
BEGIN
    ALTER TABLE [tec].[NetworkElements]
        ADD CONSTRAINT [FK_tec_NetworkElements_ComponentTypeId_NetworkComponentTypes]
        FOREIGN KEY ([ComponentTypeId]) REFERENCES [tec].[NetworkComponentTypes] ([NetworkComponentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneNumbers_PrefixId_PhonePrefixes'
)
BEGIN
    ALTER TABLE [tec].[PhoneNumbers]
        ADD CONSTRAINT [FK_tec_PhoneNumbers_PrefixId_PhonePrefixes]
        FOREIGN KEY ([PrefixId]) REFERENCES [tec].[PhonePrefixes] ([PhonePrefixeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneExchanges_PrefixId_PhonePrefixes'
)
BEGIN
    ALTER TABLE [tec].[PhoneExchanges]
        ADD CONSTRAINT [FK_tec_PhoneExchanges_PrefixId_PhonePrefixes]
        FOREIGN KEY ([PrefixId]) REFERENCES [tec].[PhonePrefixes] ([PhonePrefixeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvisioningProfiles_ProvisioningSystemId_ProvisioningSystems'
)
BEGIN
    ALTER TABLE [tec].[ProvisioningProfiles]
        ADD CONSTRAINT [FK_tec_ProvisioningProfiles_ProvisioningSystemId_ProvisioningSystems]
        FOREIGN KEY ([ProvisioningSystemId]) REFERENCES [tec].[ProvisioningSystems] ([ProvisioningSystemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvisioningCommands_ProvisioningSystemId_ProvisioningSystems'
)
BEGIN
    ALTER TABLE [tec].[ProvisioningCommands]
        ADD CONSTRAINT [FK_tec_ProvisioningCommands_ProvisioningSystemId_ProvisioningSystems]
        FOREIGN KEY ([ProvisioningSystemId]) REFERENCES [tec].[ProvisioningSystems] ([ProvisioningSystemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkDevices_ProvisioningSystemId_ProvisioningSystems'
)
BEGIN
    ALTER TABLE [tec].[NetworkDevices]
        ADD CONSTRAINT [FK_tec_NetworkDevices_ProvisioningSystemId_ProvisioningSystems]
        FOREIGN KEY ([ProvisioningSystemId]) REFERENCES [tec].[ProvisioningSystems] ([ProvisioningSystemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Visits_ZoneId_SchedulingZones'
)
BEGIN
    ALTER TABLE [tec].[Visits]
        ADD CONSTRAINT [FK_tec_Visits_ZoneId_SchedulingZones]
        FOREIGN KEY ([ZoneId]) REFERENCES [tec].[SchedulingZones] ([SchedulingZoneId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_SyncConflicts_SyncMutationId_SyncMutations'
)
BEGIN
    ALTER TABLE [tec].[SyncConflicts]
        ADD CONSTRAINT [FK_tec_SyncConflicts_SyncMutationId_SyncMutations]
        FOREIGN KEY ([SyncMutationId]) REFERENCES [tec].[SyncMutations] ([SyncMutationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TaskCatalog_TaskGroupId_TaskGroups'
)
BEGIN
    ALTER TABLE [tec].[TaskCatalog]
        ADD CONSTRAINT [FK_tec_TaskCatalog_TaskGroupId_TaskGroups]
        FOREIGN KEY ([TaskGroupId]) REFERENCES [tec].[TaskGroups] ([TaskGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_RequiredTaskIdsId_TaskCatalog'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes]
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_RequiredTaskIdsId_TaskCatalog]
        FOREIGN KEY ([RequiredTaskIdsId]) REFERENCES [tec].[TaskCatalog] ([TaskCatalogId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberingPlan_ModalityId_TelecomModalities'
)
BEGIN
    ALTER TABLE [tec].[NumberingPlan]
        ADD CONSTRAINT [FK_tec_NumberingPlan_ModalityId_TelecomModalities]
        FOREIGN KEY ([ModalityId]) REFERENCES [tec].[TelecomModalities] ([TelecomModalityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CallRecords_OperatorId_TelecomOperators'
)
BEGIN
    ALTER TABLE [tec].[CallRecords]
        ADD CONSTRAINT [FK_tec_CallRecords_OperatorId_TelecomOperators]
        FOREIGN KEY ([OperatorId]) REFERENCES [tec].[TelecomOperators] ([TelecomOperatorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberPortings_CounterpartOperatorId_TelecomOperators'
)
BEGIN
    ALTER TABLE [tec].[NumberPortings]
        ADD CONSTRAINT [FK_tec_NumberPortings_CounterpartOperatorId_TelecomOperators]
        FOREIGN KEY ([CounterpartOperatorId]) REFERENCES [tec].[TelecomOperators] ([TelecomOperatorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberingPlan_ServiceTypeId_TelecomServiceTypes'
)
BEGIN
    ALTER TABLE [tec].[NumberingPlan]
        ADD CONSTRAINT [FK_tec_NumberingPlan_ServiceTypeId_TelecomServiceTypes]
        FOREIGN KEY ([ServiceTypeId]) REFERENCES [tec].[TelecomServiceTypes] ([TelecomServiceTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Visits_BookingId_VisitBookings'
)
BEGIN
    ALTER TABLE [tec].[Visits]
        ADD CONSTRAINT [FK_tec_Visits_BookingId_VisitBookings]
        FOREIGN KEY ([BookingId]) REFERENCES [tec].[VisitBookings] ([VisitBookingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_VisitTypeId_VisitTypes'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes]
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_VisitTypeId_VisitTypes]
        FOREIGN KEY ([VisitTypeId]) REFERENCES [tec].[VisitTypes] ([VisitTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Visits_VisitTypeId_VisitTypes'
)
BEGIN
    ALTER TABLE [tec].[Visits]
        ADD CONSTRAINT [FK_tec_Visits_VisitTypeId_VisitTypes]
        FOREIGN KEY ([VisitTypeId]) REFERENCES [tec].[VisitTypes] ([VisitTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankBranches_InstitutionId_FinancialInstitutions'
)
BEGIN
    ALTER TABLE [tes].[BankBranches]
        ADD CONSTRAINT [FK_tes_BankBranches_InstitutionId_FinancialInstitutions]
        FOREIGN KEY ([InstitutionId]) REFERENCES [tes].[FinancialInstitutions] ([FinancialInstitutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_StatementImportProfiles_InstitutionId_FinancialInstitutions'
)
BEGIN
    ALTER TABLE [tes].[StatementImportProfiles]
        ADD CONSTRAINT [FK_tes_StatementImportProfiles_InstitutionId_FinancialInstitutions]
        FOREIGN KEY ([InstitutionId]) REFERENCES [tes].[FinancialInstitutions] ([FinancialInstitutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckDrawerAccounts_InstitutionId_FinancialInstitutions'
)
BEGIN
    ALTER TABLE [tes].[CheckDrawerAccounts]
        ADD CONSTRAINT [FK_tes_CheckDrawerAccounts_InstitutionId_FinancialInstitutions]
        FOREIGN KEY ([InstitutionId]) REFERENCES [tes].[FinancialInstitutions] ([FinancialInstitutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckDrawerAccounts_BankBranchId_BankBranches'
)
BEGIN
    ALTER TABLE [tes].[CheckDrawerAccounts]
        ADD CONSTRAINT [FK_tes_CheckDrawerAccounts_BankBranchId_BankBranches]
        FOREIGN KEY ([BankBranchId]) REFERENCES [tes].[BankBranches] ([BankBrancheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ThirdPartyChecks_InstrumentTypeId_InstrumentTypes'
)
BEGIN
    ALTER TABLE [tes].[ThirdPartyChecks]
        ADD CONSTRAINT [FK_tes_ThirdPartyChecks_InstrumentTypeId_InstrumentTypes]
        FOREIGN KEY ([InstrumentTypeId]) REFERENCES [tes].[InstrumentTypes] ([InstrumentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_InterbankingSyncRuns_ConnectionId_InterbankingConnections'
)
BEGIN
    ALTER TABLE [tes].[InterbankingSyncRuns]
        ADD CONSTRAINT [FK_tes_InterbankingSyncRuns_ConnectionId_InterbankingConnections]
        FOREIGN KEY ([ConnectionId]) REFERENCES [tes].[InterbankingConnections] ([InterbankingConnectionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementImports_ProfileId_StatementImportProfiles'
)
BEGIN
    ALTER TABLE [tes].[BankStatementImports]
        ADD CONSTRAINT [FK_tes_BankStatementImports_ProfileId_StatementImportProfiles]
        FOREIGN KEY ([ProfileId]) REFERENCES [tes].[StatementImportProfiles] ([StatementImportProfileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_InterbankingBalanceSnapshots_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[InterbankingBalanceSnapshots]
        ADD CONSTRAINT [FK_tes_InterbankingBalanceSnapshots_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_InterbankingSyncRuns_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[InterbankingSyncRuns]
        ADD CONSTRAINT [FK_tes_InterbankingSyncRuns_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PaymentFiles_OriginTreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[PaymentFiles]
        ADD CONSTRAINT [FK_tes_PaymentFiles_OriginTreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([OriginTreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckEvents_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[CheckEvents]
        ADD CONSTRAINT [FK_tes_CheckEvents_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryMovements_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[TreasuryMovements]
        ADD CONSTRAINT [FK_tes_TreasuryMovements_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationRules_AccountIdsId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationRules]
        ADD CONSTRAINT [FK_tes_ReconciliationRules_AccountIdsId_TreasuryAccounts]
        FOREIGN KEY ([AccountIdsId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryAccountSigners_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[TreasuryAccountSigners]
        ADD CONSTRAINT [FK_tes_TreasuryAccountSigners_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PaymentCashSessions_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[PaymentCashSessions]
        ADD CONSTRAINT [FK_tes_PaymentCashSessions_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_OwnChecks_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[OwnChecks]
        ADD CONSTRAINT [FK_tes_OwnChecks_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PlannedCashItems_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[PlannedCashItems]
        ADD CONSTRAINT [FK_tes_PlannedCashItems_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ThirdPartyChecks_CustodyAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[ThirdPartyChecks]
        ADD CONSTRAINT [FK_tes_ThirdPartyChecks_CustodyAccountId_TreasuryAccounts]
        FOREIGN KEY ([CustodyAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PayrollPaymentBatches_OriginTreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[PayrollPaymentBatches]
        ADD CONSTRAINT [FK_tes_PayrollPaymentBatches_OriginTreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([OriginTreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementImports_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[BankStatementImports]
        ADD CONSTRAINT [FK_tes_BankStatementImports_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryCashClosings_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[TreasuryCashClosings]
        ADD CONSTRAINT [FK_tes_TreasuryCashClosings_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_Checkbooks_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[Checkbooks]
        ADD CONSTRAINT [FK_tes_Checkbooks_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardSettlements_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[CardSettlements]
        ADD CONSTRAINT [FK_tes_CardSettlements_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankDeposits_SourceAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[BankDeposits]
        ADD CONSTRAINT [FK_tes_BankDeposits_SourceAccountId_TreasuryAccounts]
        FOREIGN KEY ([SourceAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankDeposits_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[BankDeposits]
        ADD CONSTRAINT [FK_tes_BankDeposits_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_FundCommitments_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[FundCommitments]
        ADD CONSTRAINT [FK_tes_FundCommitments_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_Reconciliations_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[Reconciliations]
        ADD CONSTRAINT [FK_tes_Reconciliations_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CashRemittances_TreasuryAccountId_TreasuryAccounts'
)
BEGIN
    ALTER TABLE [tes].[CashRemittances]
        ADD CONSTRAINT [FK_tes_CashRemittances_TreasuryAccountId_TreasuryAccounts]
        FOREIGN KEY ([TreasuryAccountId]) REFERENCES [tes].[TreasuryAccounts] ([TreasuryAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementImports_SyncRunId_InterbankingSyncRuns'
)
BEGIN
    ALTER TABLE [tes].[BankStatementImports]
        ADD CONSTRAINT [FK_tes_BankStatementImports_SyncRunId_InterbankingSyncRuns]
        FOREIGN KEY ([SyncRunId]) REFERENCES [tes].[InterbankingSyncRuns] ([InterbankingSyncRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PayrollPaymentBatches_PaymentFileIdsId_PaymentFiles'
)
BEGIN
    ALTER TABLE [tes].[PayrollPaymentBatches]
        ADD CONSTRAINT [FK_tes_PayrollPaymentBatches_PaymentFileIdsId_PaymentFiles]
        FOREIGN KEY ([PaymentFileIdsId]) REFERENCES [tes].[PaymentFiles] ([PaymentFileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementLines_SuggestedCategoryId_TreasuryCategories'
)
BEGIN
    ALTER TABLE [tes].[BankStatementLines]
        ADD CONSTRAINT [FK_tes_BankStatementLines_SuggestedCategoryId_TreasuryCategories]
        FOREIGN KEY ([SuggestedCategoryId]) REFERENCES [tes].[TreasuryCategories] ([TreasuryCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_StatementLineIdsId_BankStatementLines'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_StatementLineIdsId_BankStatementLines]
        FOREIGN KEY ([StatementLineIdsId]) REFERENCES [tes].[BankStatementLines] ([BankStatementLineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankDeposits_StatementLineIdsId_BankStatementLines'
)
BEGIN
    ALTER TABLE [tes].[BankDeposits]
        ADD CONSTRAINT [FK_tes_BankDeposits_StatementLineIdsId_BankStatementLines]
        FOREIGN KEY ([StatementLineIdsId]) REFERENCES [tes].[BankStatementLines] ([BankStatementLineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PlannedCashItems_ConceptRefId_TreasuryConcepts'
)
BEGIN
    ALTER TABLE [tes].[PlannedCashItems]
        ADD CONSTRAINT [FK_tes_PlannedCashItems_ConceptRefId_TreasuryConcepts]
        FOREIGN KEY ([ConceptRefId]) REFERENCES [tes].[TreasuryConcepts] ([TreasuryConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LandingPages_TenantBrandingId_TenantBrandings'
)
BEGIN
    ALTER TABLE [por].[LandingPages]
        ADD CONSTRAINT [FK_por_LandingPages_TenantBrandingId_TenantBrandings]
        FOREIGN KEY ([TenantBrandingId]) REFERENCES [uxd].[TenantBrandings] ([TenantBrandingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesQuotes_ConditionIdsId_SalesConditions'
)
BEGIN
    ALTER TABLE [ven].[SalesQuotes]
        ADD CONSTRAINT [FK_ven_SalesQuotes_ConditionIdsId_SalesConditions]
        FOREIGN KEY ([ConditionIdsId]) REFERENCES [ven].[SalesConditions] ([SalesConditionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_OperationCharges_FinancingPlanId_SalesFinancingPlans'
)
BEGIN
    ALTER TABLE [ven].[OperationCharges]
        ADD CONSTRAINT [FK_ven_OperationCharges_FinancingPlanId_SalesFinancingPlans]
        FOREIGN KEY ([FinancingPlanId]) REFERENCES [ven].[SalesFinancingPlans] ([SalesFinancingPlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_PriceListId_SalesPriceLists'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders]
        ADD CONSTRAINT [FK_ven_SalesOrders_PriceListId_SalesPriceLists]
        FOREIGN KEY ([PriceListId]) REFERENCES [ven].[SalesPriceLists] ([SalesPriceListId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosTerminals_PriceListId_SalesPriceLists'
)
BEGIN
    ALTER TABLE [ven].[PosTerminals]
        ADD CONSTRAINT [FK_ven_PosTerminals_PriceListId_SalesPriceLists]
        FOREIGN KEY ([PriceListId]) REFERENCES [ven].[SalesPriceLists] ([SalesPriceListId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ConsumptionClassReviews_ApprovalRequestId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [med].[ConsumptionClassReviews]
        ADD CONSTRAINT [FK_med_ConsumptionClassReviews_ApprovalRequestId_ApprovalRequests]
        FOREIGN KEY ([ApprovalRequestId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_PersonIdentifierIndex_ExceptionId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [per].[PersonIdentifierIndex]
        ADD CONSTRAINT [FK_per_PersonIdentifierIndex_ExceptionId_ApprovalRequests]
        FOREIGN KEY ([ExceptionId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingPrices_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [soc].[HousingPrices]
        ADD CONSTRAINT [FK_soc_HousingPrices_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalSteps_ApprovalRequestId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalSteps]
        ADD CONSTRAINT [FK_wfl_ApprovalSteps_ApprovalRequestId_ApprovalRequests]
        FOREIGN KEY ([ApprovalRequestId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_TemplateVersions_ApprovalRequestId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [wfl].[TemplateVersions]
        ADD CONSTRAINT [FK_wfl_TemplateVersions_ApprovalRequestId_ApprovalRequests]
        FOREIGN KEY ([ApprovalRequestId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalDecisions_ApprovalRequestId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalDecisions]
        ADD CONSTRAINT [FK_wfl_ApprovalDecisions_ApprovalRequestId_ApprovalRequests]
        FOREIGN KEY ([ApprovalRequestId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingPlanChanges_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [soc].[HousingPlanChanges]
        ADD CONSTRAINT [FK_soc_HousingPlanChanges_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractEquipmentAssignments_ChargeProposalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [cat].[ContractEquipmentAssignments]
        ADD CONSTRAINT [FK_cat_ContractEquipmentAssignments_ChargeProposalId_ApprovalRequests]
        FOREIGN KEY ([ChargeProposalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DeathSubsidyCases_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [soc].[DeathSubsidyCases]
        ADD CONSTRAINT [FK_soc_DeathSubsidyCases_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Terminations_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [sue].[Terminations]
        ADD CONSTRAINT [FK_sue_Terminations_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryScales_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [sue].[SalaryScales]
        ADD CONSTRAINT [FK_sue_SalaryScales_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesReturns_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [ven].[SalesReturns]
        ADD CONSTRAINT [FK_ven_SalesReturns_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_OperationCharges_DiscountApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [ven].[OperationCharges]
        ADD CONSTRAINT [FK_ven_OperationCharges_DiscountApprovalId_ApprovalRequests]
        FOREIGN KEY ([DiscountApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryRegulations_ApprovalRefId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [soc].[CemeteryRegulations]
        ADD CONSTRAINT [FK_soc_CemeteryRegulations_ApprovalRefId_ApprovalRequests]
        FOREIGN KEY ([ApprovalRefId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeAssignments_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [sue].[EmployeeAssignments]
        ADD CONSTRAINT [FK_sue_EmployeeAssignments_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalMovements_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [ins].[CapitalMovements]
        ADD CONSTRAINT [FK_ins_CapitalMovements_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalClosings_ReopenApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [ins].[CapitalClosings]
        ADD CONSTRAINT [FK_ins_CapitalClosings_ReopenApprovalId_ApprovalRequests]
        FOREIGN KEY ([ReopenApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialRightEvents_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [soc].[BurialRightEvents]
        ADD CONSTRAINT [FK_soc_BurialRightEvents_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollRuns_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [sue].[PayrollRuns]
        ADD CONSTRAINT [FK_sue_PayrollRuns_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingTerminations_ApprovalId_ApprovalRequests'
)
BEGIN
    ALTER TABLE [soc].[HousingTerminations]
        ADD CONSTRAINT [FK_soc_HousingTerminations_ApprovalId_ApprovalRequests]
        FOREIGN KEY ([ApprovalId]) REFERENCES [wfl].[ApprovalRequests] ([ApprovalRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_BulkRunItems_BulkRunId_BulkRuns'
)
BEGIN
    ALTER TABLE [wfl].[BulkRunItems]
        ADD CONSTRAINT [FK_wfl_BulkRunItems_BulkRunId_BulkRuns]
        FOREIGN KEY ([BulkRunId]) REFERENCES [wfl].[BulkRuns] ([BulkRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_BulkRunItems_ReprocessRunId_BulkRuns'
)
BEGIN
    ALTER TABLE [wfl].[BulkRunItems]
        ADD CONSTRAINT [FK_wfl_BulkRunItems_ReprocessRunId_BulkRuns]
        FOREIGN KEY ([ReprocessRunId]) REFERENCES [wfl].[BulkRuns] ([BulkRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_RenderRequests_BulkRunId_BulkRuns'
)
BEGIN
    ALTER TABLE [wfl].[RenderRequests]
        ADD CONSTRAINT [FK_wfl_RenderRequests_BulkRunId_BulkRuns]
        FOREIGN KEY ([BulkRunId]) REFERENCES [wfl].[BulkRuns] ([BulkRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_Documents_DocumentTypeId_DocumentTypes'
)
BEGIN
    ALTER TABLE [wfl].[Documents]
        ADD CONSTRAINT [FK_wfl_Documents_DocumentTypeId_DocumentTypes]
        FOREIGN KEY ([DocumentTypeId]) REFERENCES [wfl].[DocumentTypes] ([DocumentTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyInvitations_SourceEventId_EventTypes'
)
BEGIN
    ALTER TABLE [com].[SurveyInvitations]
        ADD CONSTRAINT [FK_com_SurveyInvitations_SourceEventId_EventTypes]
        FOREIGN KEY ([SourceEventId]) REFERENCES [wfl].[EventTypes] ([EventTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_NumberingAssignments_NumberingSequenceId_NumberingSequences'
)
BEGIN
    ALTER TABLE [wfl].[NumberingAssignments]
        ADD CONSTRAINT [FK_wfl_NumberingAssignments_NumberingSequenceId_NumberingSequences]
        FOREIGN KEY ([NumberingSequenceId]) REFERENCES [wfl].[NumberingSequences] ([NumberingSequenceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ResolutionCodes_OperationTypeId_OperationTypes'
)
BEGIN
    ALTER TABLE [tec].[ResolutionCodes]
        ADD CONSTRAINT [FK_tec_ResolutionCodes_OperationTypeId_OperationTypes]
        FOREIGN KEY ([OperationTypeId]) REFERENCES [wfl].[OperationTypes] ([OperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_DefaultResolutionIdsId_ResolutionCodes'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes]
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_DefaultResolutionIdsId_ResolutionCodes]
        FOREIGN KEY ([DefaultResolutionIdsId]) REFERENCES [tec].[ResolutionCodes] ([ResolutionCodeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestCalculations_OperationRefId_Operations'
)
BEGIN
    ALTER TABLE [mor].[InterestCalculations]
        ADD CONSTRAINT [FK_mor_InterestCalculations_OperationRefId_Operations]
        FOREIGN KEY ([OperationRefId]) REFERENCES [wfl].[Operations] ([OperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PaymentExecutions_OperationId_Operations'
)
BEGIN
    ALTER TABLE [tes].[PaymentExecutions]
        ADD CONSTRAINT [FK_tes_PaymentExecutions_OperationId_Operations]
        FOREIGN KEY ([OperationId]) REFERENCES [wfl].[Operations] ([OperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_OperationSteps_OperationId_Operations'
)
BEGIN
    ALTER TABLE [wfl].[OperationSteps]
        ADD CONSTRAINT [FK_wfl_OperationSteps_OperationId_Operations]
        FOREIGN KEY ([OperationId]) REFERENCES [wfl].[Operations] ([OperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryMovements_OperationId_Operations'
)
BEGIN
    ALTER TABLE [tes].[TreasuryMovements]
        ADD CONSTRAINT [FK_tes_TreasuryMovements_OperationId_Operations]
        FOREIGN KEY ([OperationId]) REFERENCES [wfl].[Operations] ([OperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CashRemittances_OperationId_Operations'
)
BEGIN
    ALTER TABLE [tes].[CashRemittances]
        ADD CONSTRAINT [FK_tes_CashRemittances_OperationId_Operations]
        FOREIGN KEY ([OperationId]) REFERENCES [wfl].[Operations] ([OperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementSimulations_CalculationIdsId_InterestCalculations'
)
BEGIN
    ALTER TABLE [mor].[AgreementSimulations]
        ADD CONSTRAINT [FK_mor_AgreementSimulations_CalculationIdsId_InterestCalculations]
        FOREIGN KEY ([CalculationIdsId]) REFERENCES [mor].[InterestCalculations] ([InterestCalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DocumentHolds_ReleaseCalculationId_InterestCalculations'
)
BEGIN
    ALTER TABLE [mor].[DocumentHolds]
        ADD CONSTRAINT [FK_mor_DocumentHolds_ReleaseCalculationId_InterestCalculations]
        FOREIGN KEY ([ReleaseCalculationId]) REFERENCES [mor].[InterestCalculations] ([InterestCalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DeferredInterests_CalculationId_InterestCalculations'
)
BEGIN
    ALTER TABLE [mor].[DeferredInterests]
        ADD CONSTRAINT [FK_mor_DeferredInterests_CalculationId_InterestCalculations]
        FOREIGN KEY ([CalculationId]) REFERENCES [mor].[InterestCalculations] ([InterestCalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_OwnChecks_PaymentExecutionId_PaymentExecutions'
)
BEGIN
    ALTER TABLE [tes].[OwnChecks]
        ADD CONSTRAINT [FK_tes_OwnChecks_PaymentExecutionId_PaymentExecutions]
        FOREIGN KEY ([PaymentExecutionId]) REFERENCES [tes].[PaymentExecutions] ([PaymentExecutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_StatutoryFilings_VepRefId_PaymentExecutions'
)
BEGIN
    ALTER TABLE [sue].[StatutoryFilings]
        ADD CONSTRAINT [FK_sue_StatutoryFilings_VepRefId_PaymentExecutions]
        FOREIGN KEY ([VepRefId]) REFERENCES [tes].[PaymentExecutions] ([PaymentExecutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureRequests_SignatureProfileId_SignatureProfiles'
)
BEGIN
    ALTER TABLE [wfl].[SignatureRequests]
        ADD CONSTRAINT [FK_wfl_SignatureRequests_SignatureProfileId_SignatureProfiles]
        FOREIGN KEY ([SignatureProfileId]) REFERENCES [wfl].[SignatureProfiles] ([SignatureProfileId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SlaTimers_SlaPolicyId_SlaPolicies'
)
BEGIN
    ALTER TABLE [wfl].[SlaTimers]
        ADD CONSTRAINT [FK_wfl_SlaTimers_SlaPolicyId_SlaPolicies]
        FOREIGN KEY ([SlaPolicyId]) REFERENCES [wfl].[SlaPolicies] ([SlaPolicyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalSteps_SlaTimerId_SlaTimers'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalSteps]
        ADD CONSTRAINT [FK_wfl_ApprovalSteps_SlaTimerId_SlaTimers]
        FOREIGN KEY ([SlaTimerId]) REFERENCES [wfl].[SlaTimers] ([SlaTimerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalDecisions_ApprovalStepId_ApprovalSteps'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalDecisions]
        ADD CONSTRAINT [FK_wfl_ApprovalDecisions_ApprovalStepId_ApprovalSteps]
        FOREIGN KEY ([ApprovalStepId]) REFERENCES [wfl].[ApprovalSteps] ([ApprovalStepId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmStatusSets_WorkflowRefId_WorkflowDefinitions'
)
BEGIN
    ALTER TABLE [crm].[CrmStatusSets]
        ADD CONSTRAINT [FK_crm_CrmStatusSets_WorkflowRefId_WorkflowDefinitions]
        FOREIGN KEY ([WorkflowRefId]) REFERENCES [wfl].[WorkflowDefinitions] ([WorkflowDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_StatusSetId_CrmStatusSets'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_StatusSetId_CrmStatusSets]
        FOREIGN KEY ([StatusSetId]) REFERENCES [crm].[CrmStatusSets] ([CrmStatusSetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_WorkflowInstanceEvents_WorkflowInstanceId_WorkflowInstances'
)
BEGIN
    ALTER TABLE [wfl].[WorkflowInstanceEvents]
        ADD CONSTRAINT [FK_wfl_WorkflowInstanceEvents_WorkflowInstanceId_WorkflowInstances]
        FOREIGN KEY ([WorkflowInstanceId]) REFERENCES [wfl].[WorkflowInstances] ([WorkflowInstanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_MatchExceptions_WorkflowInstanceId_WorkflowInstances'
)
BEGIN
    ALTER TABLE [cmp].[MatchExceptions]
        ADD CONSTRAINT [FK_cmp_MatchExceptions_WorkflowInstanceId_WorkflowInstances]
        FOREIGN KEY ([WorkflowInstanceId]) REFERENCES [wfl].[WorkflowInstances] ([WorkflowInstanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceAnnulmentRequests_WorkflowInstanceId_WorkflowInstances'
)
BEGIN
    ALTER TABLE [fac].[InvoiceAnnulmentRequests]
        ADD CONSTRAINT [FK_fac_InvoiceAnnulmentRequests_WorkflowInstanceId_WorkflowInstances]
        FOREIGN KEY ([WorkflowInstanceId]) REFERENCES [wfl].[WorkflowInstances] ([WorkflowInstanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalEntries_ApprovalRequestId_WorkflowInstances'
)
BEGIN
    ALTER TABLE [con].[JournalEntries]
        ADD CONSTRAINT [FK_con_JournalEntries_ApprovalRequestId_WorkflowInstances]
        FOREIGN KEY ([ApprovalRequestId]) REFERENCES [wfl].[WorkflowInstances] ([WorkflowInstanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_FormSubmissions_WorkflowInstanceId_WorkflowInstances'
)
BEGIN
    ALTER TABLE [wfl].[FormSubmissions]
        ADD CONSTRAINT [FK_wfl_FormSubmissions_WorkflowInstanceId_WorkflowInstances]
        FOREIGN KEY ([WorkflowInstanceId]) REFERENCES [wfl].[WorkflowInstances] ([WorkflowInstanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_RefundCases_WorkflowInstanceId_WorkflowInstances'
)
BEGIN
    ALTER TABLE [cob].[RefundCases]
        ADD CONSTRAINT [FK_cob_RefundCases_WorkflowInstanceId_WorkflowInstances]
        FOREIGN KEY ([WorkflowInstanceId]) REFERENCES [wfl].[WorkflowInstances] ([WorkflowInstanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSnapshotMembers_SnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[AudienceSnapshotMembers]
        ADD CONSTRAINT [FK_com_AudienceSnapshotMembers_SnapshotId_AudienceSnapshots]
        FOREIGN KEY ([SnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Posts_AudienceSnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[Posts] WITH NOCHECK
        ADD CONSTRAINT [FK_com_Posts_AudienceSnapshotId_AudienceSnapshots]
        FOREIGN KEY ([AudienceSnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSegments_LastSnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[AudienceSegments] WITH NOCHECK
        ADD CONSTRAINT [FK_com_AudienceSegments_LastSnapshotId_AudienceSnapshots]
        FOREIGN KEY ([LastSnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Campaigns_AudienceSnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[Campaigns]
        ADD CONSTRAINT [FK_com_Campaigns_AudienceSnapshotId_AudienceSnapshots]
        FOREIGN KEY ([AudienceSnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Newsletters_AudienceSnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[Newsletters]
        ADD CONSTRAINT [FK_com_Newsletters_AudienceSnapshotId_AudienceSnapshots]
        FOREIGN KEY ([AudienceSnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Surveys_AudienceSnapshotId_AudienceSnapshots'
)
BEGIN
    ALTER TABLE [com].[Surveys]
        ADD CONSTRAINT [FK_com_Surveys_AudienceSnapshotId_AudienceSnapshots]
        FOREIGN KEY ([AudienceSnapshotId]) REFERENCES [com].[AudienceSnapshots] ([AudienceSnapshotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingCycles_DueDateSchemeId_DueDateSchemes'
)
BEGIN
    ALTER TABLE [fac].[BillingCycles]
        ADD CONSTRAINT [FK_fac_BillingCycles_DueDateSchemeId_DueDateSchemes]
        FOREIGN KEY ([DueDateSchemeId]) REFERENCES [fac].[DueDateSchemes] ([DueDateSchemeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ConsumptionDistributions_ParentPointId_MeteringPoints'
)
BEGIN
    ALTER TABLE [med].[ConsumptionDistributions]
        ADD CONSTRAINT [FK_med_ConsumptionDistributions_ParentPointId_MeteringPoints]
        FOREIGN KEY ([ParentPointId]) REFERENCES [med].[MeteringPoints] ([MeteringPointId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_InspectionCases_MeteringPointId_MeteringPoints'
)
BEGIN
    ALTER TABLE [tec].[InspectionCases]
        ADD CONSTRAINT [FK_tec_InspectionCases_MeteringPointId_MeteringPoints]
        FOREIGN KEY ([MeteringPointId]) REFERENCES [med].[MeteringPoints] ([MeteringPointId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentIntents_MandateId_DirectDebitMandates'
)
BEGIN
    ALTER TABLE [cob].[PaymentIntents]
        ADD CONSTRAINT [FK_cob_PaymentIntents_MandateId_DirectDebitMandates]
        FOREIGN KEY ([MandateId]) REFERENCES [cob].[DirectDebitMandates] ([DirectDebitMandateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditAccess_WorkstationId_Workstations'
)
BEGIN
    ALTER TABLE [iam].[AuditAccess]
        ADD CONSTRAINT [FK_iam_AuditAccess_WorkstationId_Workstations]
        FOREIGN KEY ([WorkstationId]) REFERENCES [cfg].[Workstations] ([WorkstationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_LocalAgents_WorkstationId_Workstations'
)
BEGIN
    ALTER TABLE [int].[LocalAgents] WITH NOCHECK
        ADD CONSTRAINT [FK_int_LocalAgents_WorkstationId_Workstations]
        FOREIGN KEY ([WorkstationId]) REFERENCES [cfg].[Workstations] ([WorkstationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_WorkstationId_Workstations'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters]
        ADD CONSTRAINT [FK_cob_CashRegisters_WorkstationId_Workstations]
        FOREIGN KEY ([WorkstationId]) REFERENCES [cfg].[Workstations] ([WorkstationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalRefunds_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[CapitalRefunds]
        ADD CONSTRAINT [FK_ins_CapitalRefunds_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFees_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFees]
        ADD CONSTRAINT [FK_ins_InstitutionalFees_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingAgendaItems_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[MeetingAgendaItems] WITH NOCHECK
        ADD CONSTRAINT [FK_ins_MeetingAgendaItems_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_BodyMandates_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[BodyMandates]
        ADD CONSTRAINT [FK_ins_BodyMandates_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusDistributions_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[SurplusDistributions]
        ADD CONSTRAINT [FK_ins_SurplusDistributions_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalShareValues_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[CapitalShareValues]
        ADD CONSTRAINT [FK_ins_CapitalShareValues_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalTransfers_ResolutionId_Resolutions'
)
BEGIN
    ALTER TABLE [ins].[CapitalTransfers]
        ADD CONSTRAINT [FK_ins_CapitalTransfers_ResolutionId_Resolutions]
        FOREIGN KEY ([ResolutionId]) REFERENCES [ins].[Resolutions] ([ResolutionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_consumption_ConsumptionId_Consumptions'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_consumption]
        ADD CONSTRAINT [FK_bia_Bi_fact_consumption_ConsumptionId_Consumptions]
        FOREIGN KEY ([ConsumptionId]) REFERENCES [med].[Consumptions] ([ConsumptionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_BenefitRedemptions_BenefitId_Benefits'
)
BEGIN
    ALTER TABLE [com].[BenefitRedemptions]
        ADD CONSTRAINT [FK_com_BenefitRedemptions_BenefitId_Benefits]
        FOREIGN KEY ([BenefitId]) REFERENCES [com].[Benefits] ([BenefitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollPaymentRequests_ExternalImportId_ExternalPayrollImports'
)
BEGIN
    ALTER TABLE [sue].[PayrollPaymentRequests] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_PayrollPaymentRequests_ExternalImportId_ExternalPayrollImports]
        FOREIGN KEY ([ExternalImportId]) REFERENCES [sue].[ExternalPayrollImports] ([ExternalPayrollImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardPresentations_VoucherIdsId_CardVouchers'
)
BEGIN
    ALTER TABLE [tes].[CardPresentations] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_CardPresentations_VoucherIdsId_CardVouchers]
        FOREIGN KEY ([VoucherIdsId]) REFERENCES [tes].[CardVouchers] ([CardVoucherId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardSettlements_VoucherIdsId_CardVouchers'
)
BEGIN
    ALTER TABLE [tes].[CardSettlements] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_CardSettlements_VoucherIdsId_CardVouchers]
        FOREIGN KEY ([VoucherIdsId]) REFERENCES [tes].[CardVouchers] ([CardVoucherId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingParticipants_SignatureRefId_SignatureRequests'
)
BEGIN
    ALTER TABLE [ins].[MeetingParticipants]
        ADD CONSTRAINT [FK_ins_MeetingParticipants_SignatureRefId_SignatureRequests]
        FOREIGN KEY ([SignatureRefId]) REFERENCES [wfl].[SignatureRequests] ([SignatureRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentVersions_SignaturesId_SignatureRequests'
)
BEGIN
    ALTER TABLE [wfl].[DocumentVersions]
        ADD CONSTRAINT [FK_wfl_DocumentVersions_SignaturesId_SignatureRequests]
        FOREIGN KEY ([SignaturesId]) REFERENCES [wfl].[SignatureRequests] ([SignatureRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceConformities_SignatureRequestId_SignatureRequests'
)
BEGIN
    ALTER TABLE [tec].[ServiceConformities]
        ADD CONSTRAINT [FK_tec_ServiceConformities_SignatureRequestId_SignatureRequests]
        FOREIGN KEY ([SignatureRequestId]) REFERENCES [wfl].[SignatureRequests] ([SignatureRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayslipNotifications_SignatureRequestId_SignatureRequests'
)
BEGIN
    ALTER TABLE [sue].[PayslipNotifications]
        ADD CONSTRAINT [FK_sue_PayslipNotifications_SignatureRequestId_SignatureRequests]
        FOREIGN KEY ([SignatureRequestId]) REFERENCES [wfl].[SignatureRequests] ([SignatureRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_Agreements_SignatureRequestId_SignatureRequests'
)
BEGIN
    ALTER TABLE [mor].[Agreements]
        ADD CONSTRAINT [FK_mor_Agreements_SignatureRequestId_SignatureRequests]
        FOREIGN KEY ([SignatureRequestId]) REFERENCES [wfl].[SignatureRequests] ([SignatureRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureParticipants_SignatureRequestId_SignatureRequests'
)
BEGIN
    ALTER TABLE [wfl].[SignatureParticipants]
        ADD CONSTRAINT [FK_wfl_SignatureParticipants_SignatureRequestId_SignatureRequests]
        FOREIGN KEY ([SignatureRequestId]) REFERENCES [wfl].[SignatureRequests] ([SignatureRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Minutes_SignatureRequestRefId_SignatureRequests'
)
BEGIN
    ALTER TABLE [ins].[Minutes]
        ADD CONSTRAINT [FK_ins_Minutes_SignatureRequestRefId_SignatureRequests]
        FOREIGN KEY ([SignatureRequestRefId]) REFERENCES [wfl].[SignatureRequests] ([SignatureRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingsApplied_SupplierPersonId_TaxExemptions'
)
BEGIN
    ALTER TABLE [fis].[WithholdingsApplied]
        ADD CONSTRAINT [FK_fis_WithholdingsApplied_SupplierPersonId_TaxExemptions]
        FOREIGN KEY ([SupplierPersonId]) REFERENCES [fis].[TaxExemptions] ([TaxExemptionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Crews_LeaderId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[Crews]
        ADD CONSTRAINT [FK_tec_Crews_LeaderId_FieldResources]
        FOREIGN KEY ([LeaderId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ResponsibleNotificationRules_FieldResourceId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[ResponsibleNotificationRules]
        ADD CONSTRAINT [FK_tec_ResponsibleNotificationRules_FieldResourceId_FieldResources]
        FOREIGN KEY ([FieldResourceId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_OnCallShifts_BackupResourceId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[OnCallShifts]
        ADD CONSTRAINT [FK_tec_OnCallShifts_BackupResourceId_FieldResources]
        FOREIGN KEY ([BackupResourceId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_OnCallShifts_ChiefResourceId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[OnCallShifts]
        ADD CONSTRAINT [FK_tec_OnCallShifts_ChiefResourceId_FieldResources]
        FOREIGN KEY ([ChiefResourceId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_OnCallShifts_PrimaryResourceId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[OnCallShifts]
        ADD CONSTRAINT [FK_tec_OnCallShifts_PrimaryResourceId_FieldResources]
        FOREIGN KEY ([PrimaryResourceId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FeasibilityRequests_TechnicalResponsibleId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[FeasibilityRequests]
        ADD CONSTRAINT [FK_tec_FeasibilityRequests_TechnicalResponsibleId_FieldResources]
        FOREIGN KEY ([TechnicalResponsibleId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Visits_AssignedResourceIdsId_FieldResources'
)
BEGIN
    ALTER TABLE [tec].[Visits]
        ADD CONSTRAINT [FK_tec_Visits_AssignedResourceIdsId_FieldResources]
        FOREIGN KEY ([AssignedResourceIdsId]) REFERENCES [tec].[FieldResources] ([FieldResourceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityOccurrences_CalendarEventId_CrmCalendarEvents'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityOccurrences]
        ADD CONSTRAINT [FK_crm_CrmActivityOccurrences_CalendarEventId_CrmCalendarEvents]
        FOREIGN KEY ([CalendarEventId]) REFERENCES [crm].[CrmCalendarEvents] ([CrmCalendarEventId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_RenderRequests_TemplateVersionId_TemplateVersions'
)
BEGIN
    ALTER TABLE [wfl].[RenderRequests]
        ADD CONSTRAINT [FK_wfl_RenderRequests_TemplateVersionId_TemplateVersions]
        FOREIGN KEY ([TemplateVersionId]) REFERENCES [wfl].[TemplateVersions] ([TemplateVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNoticeModels_TemplateVersionId_TemplateVersions'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNoticeModels]
        ADD CONSTRAINT [FK_mor_DelinquencyNoticeModels_TemplateVersionId_TemplateVersions]
        FOREIGN KEY ([TemplateVersionId]) REFERENCES [wfl].[TemplateVersions] ([TemplateVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderPrintTemplates_TemplateVersionId_TemplateVersions'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderPrintTemplates]
        ADD CONSTRAINT [FK_tec_WorkOrderPrintTemplates_TemplateVersionId_TemplateVersions]
        FOREIGN KEY ([TemplateVersionId]) REFERENCES [wfl].[TemplateVersions] ([TemplateVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentTemplates_CurrentVersionId_TemplateVersions'
)
BEGIN
    ALTER TABLE [wfl].[DocumentTemplates] WITH NOCHECK
        ADD CONSTRAINT [FK_wfl_DocumentTemplates_CurrentVersionId_TemplateVersions]
        FOREIGN KEY ([CurrentVersionId]) REFERENCES [wfl].[TemplateVersions] ([TemplateVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCirculars_TemplateVersionId_TemplateVersions'
)
BEGIN
    ALTER TABLE [crm].[CrmCirculars]
        ADD CONSTRAINT [FK_crm_CrmCirculars_TemplateVersionId_TemplateVersions]
        FOREIGN KEY ([TemplateVersionId]) REFERENCES [wfl].[TemplateVersions] ([TemplateVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Benefits_BenefitPartnerId_BenefitPartners'
)
BEGIN
    ALTER TABLE [com].[Benefits]
        ADD CONSTRAINT [FK_com_Benefits_BenefitPartnerId_BenefitPartners]
        FOREIGN KEY ([BenefitPartnerId]) REFERENCES [com].[BenefitPartners] ([BenefitPartnerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_BenefitRedemptions_PartnerId_BenefitPartners'
)
BEGIN
    ALTER TABLE [com].[BenefitRedemptions]
        ADD CONSTRAINT [FK_com_BenefitRedemptions_PartnerId_BenefitPartners]
        FOREIGN KEY ([PartnerId]) REFERENCES [com].[BenefitPartners] ([BenefitPartnerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_CollectionCases_DossierId_Dossiers'
)
BEGIN
    ALTER TABLE [mor].[CollectionCases]
        ADD CONSTRAINT [FK_mor_CollectionCases_DossierId_Dossiers]
        FOREIGN KEY ([DossierId]) REFERENCES [wfl].[Dossiers] ([DossierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DossierEntries_DossierId_Dossiers'
)
BEGIN
    ALTER TABLE [wfl].[DossierEntries]
        ADD CONSTRAINT [FK_wfl_DossierEntries_DossierId_Dossiers]
        FOREIGN KEY ([DossierId]) REFERENCES [wfl].[Dossiers] ([DossierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Meetings_DossierId_Dossiers'
)
BEGIN
    ALTER TABLE [ins].[Meetings]
        ADD CONSTRAINT [FK_ins_Meetings_DossierId_Dossiers]
        FOREIGN KEY ([DossierId]) REFERENCES [wfl].[Dossiers] ([DossierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TechnicalProcedures_DossierId_Dossiers'
)
BEGIN
    ALTER TABLE [tec].[TechnicalProcedures]
        ADD CONSTRAINT [FK_tec_TechnicalProcedures_DossierId_Dossiers]
        FOREIGN KEY ([DossierId]) REFERENCES [wfl].[Dossiers] ([DossierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DossierTimeline_DossierId_Dossiers'
)
BEGIN
    ALTER TABLE [wfl].[DossierTimeline]
        ADD CONSTRAINT [FK_wfl_DossierTimeline_DossierId_Dossiers]
        FOREIGN KEY ([DossierId]) REFERENCES [wfl].[Dossiers] ([DossierId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyCollections_ThirdPartyBillerId_ThirdPartyBillers'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyCollections]
        ADD CONSTRAINT [FK_cob_ThirdPartyCollections_ThirdPartyBillerId_ThirdPartyBillers]
        FOREIGN KEY ([ThirdPartyBillerId]) REFERENCES [cob].[ThirdPartyBillers] ([ThirdPartyBillerId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_HandoverId_TreasuryHandovers'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_HandoverId_TreasuryHandovers]
        FOREIGN KEY ([HandoverId]) REFERENCES [cob].[TreasuryHandovers] ([TreasuryHandoverId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashSessions_HandoverId_TreasuryHandovers'
)
BEGIN
    ALTER TABLE [cob].[CashSessions] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CashSessions_HandoverId_TreasuryHandovers]
        FOREIGN KEY ([HandoverId]) REFERENCES [cob].[TreasuryHandovers] ([TreasuryHandoverId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CashRemittances_TreasuryHandoverId_TreasuryHandovers'
)
BEGIN
    ALTER TABLE [tes].[CashRemittances]
        ADD CONSTRAINT [FK_tes_CashRemittances_TreasuryHandoverId_TreasuryHandovers]
        FOREIGN KEY ([TreasuryHandoverId]) REFERENCES [cob].[TreasuryHandovers] ([TreasuryHandoverId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SeniorityScales_UnionId_Unions'
)
BEGIN
    ALTER TABLE [sue].[SeniorityScales]
        ADD CONSTRAINT [FK_sue_SeniorityScales_UnionId_Unions]
        FOREIGN KEY ([UnionId]) REFERENCES [sue].[Unions] ([UnionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LaborAgreements_UnionId_Unions'
)
BEGIN
    ALTER TABLE [sue].[LaborAgreements]
        ADD CONSTRAINT [FK_sue_LaborAgreements_UnionId_Unions]
        FOREIGN KEY ([UnionId]) REFERENCES [sue].[Unions] ([UnionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Objectives_WorkAreaId_WorkAreas'
)
BEGIN
    ALTER TABLE [sue].[Objectives]
        ADD CONSTRAINT [FK_sue_Objectives_WorkAreaId_WorkAreas]
        FOREIGN KEY ([WorkAreaId]) REFERENCES [sue].[WorkAreas] ([WorkAreaId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalRefunds_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalRefunds]
        ADD CONSTRAINT [FK_ins_CapitalRefunds_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MemberCredentials_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[MemberCredentials]
        ADD CONSTRAINT [FK_ins_MemberCredentials_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_BodyMandates_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[BodyMandates]
        ADD CONSTRAINT [FK_ins_BodyMandates_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingParticipants_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[MeetingParticipants]
        ADD CONSTRAINT [FK_ins_MeetingParticipants_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_member_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_member]
        ADD CONSTRAINT [FK_bia_Bi_fact_member_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Proxies_GrantorAssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[Proxies]
        ADD CONSTRAINT [FK_ins_Proxies_GrantorAssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([GrantorAssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Proxies_ProxyAssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[Proxies]
        ADD CONSTRAINT [FK_ins_Proxies_ProxyAssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([ProxyAssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_RosterEntries_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[RosterEntries]
        ADD CONSTRAINT [FK_ins_RosterEntries_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_ShareCertificates_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[ShareCertificates]
        ADD CONSTRAINT [FK_ins_ShareCertificates_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MembershipEvents_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[MembershipEvents]
        ADD CONSTRAINT [FK_ins_MembershipEvents_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalTransfers_FromAssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalTransfers]
        ADD CONSTRAINT [FK_ins_CapitalTransfers_FromAssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([FromAssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalTransfers_ToAssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalTransfers]
        ADD CONSTRAINT [FK_ins_CapitalTransfers_ToAssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([ToAssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalBalances_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalBalances]
        ADD CONSTRAINT [FK_ins_CapitalBalances_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalMovements_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalMovements]
        ADD CONSTRAINT [FK_ins_CapitalMovements_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalReserves_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalReserves]
        ADD CONSTRAINT [FK_ins_CapitalReserves_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusAllocations_AssociateMembershipId_AssociateMemberships'
)
BEGIN
    ALTER TABLE [ins].[SurplusAllocations]
        ADD CONSTRAINT [FK_ins_SurplusAllocations_AssociateMembershipId_AssociateMemberships]
        FOREIGN KEY ([AssociateMembershipId]) REFERENCES [ins].[AssociateMemberships] ([AssociateMembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyPublishedDebts_ExportId_AgencyDebtExports'
)
BEGIN
    ALTER TABLE [cob].[AgencyPublishedDebts]
        ADD CONSTRAINT [FK_cob_AgencyPublishedDebts_ExportId_AgencyDebtExports]
        FOREIGN KEY ([ExportId]) REFERENCES [cob].[AgencyDebtExports] ([AgencyDebtExportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitBatches_ExportId_AgencyDebtExports'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitBatches]
        ADD CONSTRAINT [FK_cob_DirectDebitBatches_ExportId_AgencyDebtExports]
        FOREIGN KEY ([ExportId]) REFERENCES [cob].[AgencyDebtExports] ([AgencyDebtExportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeteringPoints_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [med].[MeteringPoints]
        ADD CONSTRAINT [FK_med_MeteringPoints_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_Consumptions_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [med].[Consumptions]
        ADD CONSTRAINT [FK_med_Consumptions_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CallRecords_AttributedContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tec].[CallRecords]
        ADD CONSTRAINT [FK_tec_CallRecords_AttributedContractId_ServiceContracts]
        FOREIGN KEY ([AttributedContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DispenserWithdrawals_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [soc].[DispenserWithdrawals]
        ADD CONSTRAINT [FK_soc_DispenserWithdrawals_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvisioningCommands_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tec].[ProvisioningCommands]
        ADD CONSTRAINT [FK_tec_ProvisioningCommands_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStripPositions_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tec].[PhoneStripPositions]
        ADD CONSTRAINT [FK_tec_PhoneStripPositions_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_PromotionAssignments_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tar].[PromotionAssignments]
        ADD CONSTRAINT [FK_tar_PromotionAssignments_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalAccountAccess_ContractIdsId_ServiceContracts'
)
BEGIN
    ALTER TABLE [por].[PortalAccountAccess]
        ADD CONSTRAINT [FK_por_PortalAccountAccess_ContractIdsId_ServiceContracts]
        FOREIGN KEY ([ContractIdsId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BilledPeriods_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [fac].[BilledPeriods]
        ADD CONSTRAINT [FK_fac_BilledPeriods_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_ledgerEntry_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_ledgerEntry]
        ADD CONSTRAINT [FK_bia_Bi_fact_ledgerEntry_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractEquipmentAssignments_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[ContractEquipmentAssignments]
        ADD CONSTRAINT [FK_cat_ContractEquipmentAssignments_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialRights_MaintenanceContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [soc].[BurialRights]
        ADD CONSTRAINT [FK_soc_BurialRights_MaintenanceContractId_ServiceContracts]
        FOREIGN KEY ([MaintenanceContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceTechnicalProfiles_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tec].[ServiceTechnicalProfiles]
        ADD CONSTRAINT [FK_tec_ServiceTechnicalProfiles_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_WorksInstallmentPlans_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tar].[WorksInstallmentPlans]
        ADD CONSTRAINT [FK_tar_WorksInstallmentPlans_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSnapshotMembers_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [com].[AudienceSnapshotMembers]
        ADD CONSTRAINT [FK_com_AudienceSnapshotMembers_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceDependents_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [soc].[ServiceDependents]
        ADD CONSTRAINT [FK_soc_ServiceDependents_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterruptionCases_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [mor].[InterruptionCases]
        ADD CONSTRAINT [FK_mor_InterruptionCases_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_BenefitGroupMembers_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tar].[BenefitGroupMembers]
        ADD CONSTRAINT [FK_tar_BenefitGroupMembers_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingUnits_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [soc].[HousingUnits]
        ADD CONSTRAINT [FK_soc_HousingUnits_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BulkContractOperations_ContractIdsId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[BulkContractOperations]
        ADD CONSTRAINT [FK_cat_BulkContractOperations_ContractIdsId_ServiceContracts]
        FOREIGN KEY ([ContractIdsId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceNetworkConnections_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tec].[ServiceNetworkConnections]
        ADD CONSTRAINT [FK_tec_ServiceNetworkConnections_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockBalances_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [stk].[StockBalances]
        ADD CONSTRAINT [FK_stk_StockBalances_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BenefitRequests_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [soc].[BenefitRequests]
        ADD CONSTRAINT [FK_soc_BenefitRequests_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvidedMailboxes_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tec].[ProvidedMailboxes]
        ADD CONSTRAINT [FK_tec_ProvidedMailboxes_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_MobileUsageImports_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tec].[MobileUsageImports]
        ADD CONSTRAINT [FK_tec_MobileUsageImports_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneLines_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tec].[PhoneLines]
        ADD CONSTRAINT [FK_tec_PhoneLines_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalTransfers_ContractIdsId_ServiceContracts'
)
BEGIN
    ALTER TABLE [ins].[CapitalTransfers]
        ADD CONSTRAINT [FK_ins_CapitalTransfers_ContractIdsId_ServiceContracts]
        FOREIGN KEY ([ContractIdsId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberPortings_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tec].[NumberPortings]
        ADD CONSTRAINT [FK_tec_NumberPortings_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContractHistory_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[ServiceContractHistory]
        ADD CONSTRAINT [FK_cat_ServiceContractHistory_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalDelegationInvites_ContractIdsId_ServiceContracts'
)
BEGIN
    ALTER TABLE [por].[PortalDelegationInvites]
        ADD CONSTRAINT [FK_por_PortalDelegationInvites_ContractIdsId_ServiceContracts]
        FOREIGN KEY ([ContractIdsId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_SerialUnitEvents_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [stk].[SerialUnitEvents]
        ADD CONSTRAINT [FK_stk_SerialUnitEvents_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ContractRegistrations_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [soc].[ContractRegistrations]
        ADD CONSTRAINT [FK_soc_ContractRegistrations_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SimulationResults_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tar].[SimulationResults]
        ADD CONSTRAINT [FK_tar_SimulationResults_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractSpecialConditions_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[ContractSpecialConditions]
        ADD CONSTRAINT [FK_cat_ContractSpecialConditions_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_InspectionCases_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tec].[InspectionCases]
        ADD CONSTRAINT [FK_tec_InspectionCases_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BundleSubscriptions_ContractIdsId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[BundleSubscriptions] WITH NOCHECK
        ADD CONSTRAINT [FK_cat_BundleSubscriptions_ContractIdsId_ServiceContracts]
        FOREIGN KEY ([ContractIdsId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsSettlements_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsSettlements]
        ADD CONSTRAINT [FK_cmp_SignalRightsSettlements_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceBeneficiaries_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [soc].[ServiceBeneficiaries]
        ADD CONSTRAINT [FK_soc_ServiceBeneficiaries_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DeferredInterests_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [mor].[DeferredInterests]
        ADD CONSTRAINT [FK_mor_DeferredInterests_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SubsidyEnrollments_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [tar].[SubsidyEnrollments]
        ADD CONSTRAINT [FK_tar_SubsidyEnrollments_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractDeclaredAppliances_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [cat].[ContractDeclaredAppliances]
        ADD CONSTRAINT [FK_cat_ContractDeclaredAppliances_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_contract_ContractId_ServiceContracts'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_contract]
        ADD CONSTRAINT [FK_bia_Bi_dim_contract_ContractId_ServiceContracts]
        FOREIGN KEY ([ContractId]) REFERENCES [cat].[ServiceContracts] ([ServiceContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LaborLawsuits_JudicialCaseId_CollectionCases'
)
BEGIN
    ALTER TABLE [sue].[LaborLawsuits]
        ADD CONSTRAINT [FK_sue_LaborLawsuits_JudicialCaseId_CollectionCases]
        FOREIGN KEY ([JudicialCaseId]) REFERENCES [mor].[CollectionCases] ([CollectionCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceTechnicalProfiles_LastCommandId_ProvisioningCommands'
)
BEGIN
    ALTER TABLE [tec].[ServiceTechnicalProfiles]
        ADD CONSTRAINT [FK_tec_ServiceTechnicalProfiles_LastCommandId_ProvisioningCommands]
        FOREIGN KEY ([LastCommandId]) REFERENCES [tec].[ProvisioningCommands] ([ProvisioningCommandId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountRoles_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[AccountRoles]
        ADD CONSTRAINT [FK_con_AccountRoles_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerAccounts_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[LedgerAccounts]
        ADD CONSTRAINT [FK_con_LedgerAccounts_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountRubrics_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[AccountRubrics]
        ADD CONSTRAINT [FK_con_AccountRubrics_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ResultTargets_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[ResultTargets]
        ADD CONSTRAINT [FK_con_ResultTargets_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_PostingRules_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[PostingRules]
        ADD CONSTRAINT [FK_con_PostingRules_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_EntryTemplates_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[EntryTemplates]
        ADD CONSTRAINT [FK_con_EntryTemplates_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerProjections_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[LedgerProjections]
        ADD CONSTRAINT [FK_con_LedgerProjections_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_EntityAccountAssignments_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[EntityAccountAssignments]
        ADD CONSTRAINT [FK_con_EntityAccountAssignments_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_SimulationScenarios_ChartId_ChartOfAccounts'
)
BEGIN
    ALTER TABLE [con].[SimulationScenarios] WITH NOCHECK
        ADD CONSTRAINT [FK_con_SimulationScenarios_ChartId_ChartOfAccounts]
        FOREIGN KEY ([ChartId]) REFERENCES [con].[ChartOfAccounts] ([ChartOfAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditAi_AiUsageLogId_AiUsageLogs'
)
BEGIN
    ALTER TABLE [iam].[AuditAi]
        ADD CONSTRAINT [FK_iam_AuditAi_AiUsageLogId_AiUsageLogs]
        FOREIGN KEY ([AiUsageLogId]) REFERENCES [int].[AiUsageLogs] ([AiUsageLogId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_AiQuestions_AiUsageLogId_AiUsageLogs'
)
BEGIN
    ALTER TABLE [bia].[AiQuestions]
        ADD CONSTRAINT [FK_bia_AiQuestions_AiUsageLogId_AiUsageLogs]
        FOREIGN KEY ([AiUsageLogId]) REFERENCES [int].[AiUsageLogs] ([AiUsageLogId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_AiInvoiceExtractions_AiUsageLogId_AiUsageLogs'
)
BEGIN
    ALTER TABLE [cmp].[AiInvoiceExtractions]
        ADD CONSTRAINT [FK_cmp_AiInvoiceExtractions_AiUsageLogId_AiUsageLogs]
        FOREIGN KEY ([AiUsageLogId]) REFERENCES [int].[AiUsageLogs] ([AiUsageLogId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmAiSuggestions_AiUsageLogId_AiUsageLogs'
)
BEGIN
    ALTER TABLE [crm].[CrmAiSuggestions]
        ADD CONSTRAINT [FK_crm_CrmAiSuggestions_AiUsageLogId_AiUsageLogs]
        FOREIGN KEY ([AiUsageLogId]) REFERENCES [int].[AiUsageLogs] ([AiUsageLogId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmIncidents_FailureTypeId_IncidentCategories'
)
BEGIN
    ALTER TABLE [crm].[CrmIncidents]
        ADD CONSTRAINT [FK_crm_CrmIncidents_FailureTypeId_IncidentCategories]
        FOREIGN KEY ([FailureTypeId]) REFERENCES [tec].[IncidentCategories] ([IncidentCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmIncidents_IncidentCategoryId_IncidentCategories'
)
BEGIN
    ALTER TABLE [crm].[CrmIncidents]
        ADD CONSTRAINT [FK_crm_CrmIncidents_IncidentCategoryId_IncidentCategories]
        FOREIGN KEY ([IncidentCategoryId]) REFERENCES [tec].[IncidentCategories] ([IncidentCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFeeSettlements_FeeId_InstitutionalFees'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFeeSettlements]
        ADD CONSTRAINT [FK_ins_InstitutionalFeeSettlements_FeeId_InstitutionalFees]
        FOREIGN KEY ([FeeId]) REFERENCES [ins].[InstitutionalFees] ([InstitutionalFeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_GatewayTransactionId_GatewayTransactions'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_GatewayTransactionId_GatewayTransactions]
        FOREIGN KEY ([GatewayTransactionId]) REFERENCES [cob].[GatewayTransactions] ([GatewayTransactionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_GatewayTransactionId_GatewayTransactions'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_GatewayTransactionId_GatewayTransactions]
        FOREIGN KEY ([GatewayTransactionId]) REFERENCES [cob].[GatewayTransactions] ([GatewayTransactionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentIntents_TransactionIdsId_GatewayTransactions'
)
BEGIN
    ALTER TABLE [cob].[PaymentIntents] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_PaymentIntents_TransactionIdsId_GatewayTransactions]
        FOREIGN KEY ([TransactionIdsId]) REFERENCES [cob].[GatewayTransactions] ([GatewayTransactionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Unions_ChargesAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [sue].[Unions]
        ADD CONSTRAINT [FK_sue_Unions_ChargesAccountId_LedgerAccounts]
        FOREIGN KEY ([ChargesAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountRoles_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[AccountRoles]
        ADD CONSTRAINT [FK_con_AccountRoles_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_IncidentCategories_CreditAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [tec].[IncidentCategories]
        ADD CONSTRAINT [FK_tec_IncidentCategories_CreditAccountId_LedgerAccounts]
        FOREIGN KEY ([CreditAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_IncidentCategories_DebitAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [tec].[IncidentCategories]
        ADD CONSTRAINT [FK_tec_IncidentCategories_DebitAccountId_LedgerAccounts]
        FOREIGN KEY ([DebitAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentMethods_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [cob].[PaymentMethods]
        ADD CONSTRAINT [FK_cob_PaymentMethods_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ResultTargets_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[ResultTargets]
        ADD CONSTRAINT [FK_con_ResultTargets_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_PostingRules_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[PostingRules]
        ADD CONSTRAINT [FK_con_PostingRules_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkGroups_CreditAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [tec].[WorkGroups]
        ADD CONSTRAINT [FK_tec_WorkGroups_CreditAccountId_LedgerAccounts]
        FOREIGN KEY ([CreditAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkGroups_DebitAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [tec].[WorkGroups]
        ADD CONSTRAINT [FK_tec_WorkGroups_DebitAccountId_LedgerAccounts]
        FOREIGN KEY ([DebitAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ExternalLedgerMappings_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[ExternalLedgerMappings]
        ADD CONSTRAINT [FK_con_ExternalLedgerMappings_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_AccountMappings_SourceAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[AccountMappings]
        ADD CONSTRAINT [FK_con_AccountMappings_SourceAccountId_LedgerAccounts]
        FOREIGN KEY ([SourceAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_PrescriptionRules_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [mor].[PrescriptionRules]
        ADD CONSTRAINT [FK_mor_PrescriptionRules_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalItems_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [ins].[CapitalItems]
        ADD CONSTRAINT [FK_ins_CapitalItems_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_glAccount_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_glAccount]
        ADD CONSTRAINT [FK_bia_Bi_dim_glAccount_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyAgreements_LiabilityLedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyAgreements]
        ADD CONSTRAINT [FK_fis_ThirdPartyAgreements_LiabilityLedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LiabilityLedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerProjections_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[LedgerProjections]
        ADD CONSTRAINT [FK_con_LedgerProjections_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_BudgetLines_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[BudgetLines]
        ADD CONSTRAINT [FK_con_BudgetLines_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_EntityAccountAssignments_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [con].[EntityAccountAssignments]
        ADD CONSTRAINT [FK_con_EntityAccountAssignments_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingSufferedTypes_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [fis].[WithholdingSufferedTypes]
        ADD CONSTRAINT [FK_fis_WithholdingSufferedTypes_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollAccountingRules_CreditAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [sue].[PayrollAccountingRules]
        ADD CONSTRAINT [FK_sue_PayrollAccountingRules_CreditAccountId_LedgerAccounts]
        FOREIGN KEY ([CreditAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollAccountingRules_DebitAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [sue].[PayrollAccountingRules]
        ADD CONSTRAINT [FK_sue_PayrollAccountingRules_DebitAccountId_LedgerAccounts]
        FOREIGN KEY ([DebitAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingTypes_LedgerAccountId_LedgerAccounts'
)
BEGIN
    ALTER TABLE [fis].[WithholdingTypes]
        ADD CONSTRAINT [FK_fis_WithholdingTypes_LedgerAccountId_LedgerAccounts]
        FOREIGN KEY ([LedgerAccountId]) REFERENCES [con].[LedgerAccounts] ([LedgerAccountId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneLines_PhoneNumberId_PhoneNumbers'
)
BEGIN
    ALTER TABLE [tec].[PhoneLines]
        ADD CONSTRAINT [FK_tec_PhoneLines_PhoneNumberId_PhoneNumbers]
        FOREIGN KEY ([PhoneNumberId]) REFERENCES [tec].[PhoneNumbers] ([PhoneNumberId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberPortings_PhoneNumberId_PhoneNumbers'
)
BEGIN
    ALTER TABLE [tec].[NumberPortings]
        ADD CONSTRAINT [FK_tec_NumberPortings_PhoneNumberId_PhoneNumbers]
        FOREIGN KEY ([PhoneNumberId]) REFERENCES [tec].[PhoneNumbers] ([PhoneNumberId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LandingPageVersions_LandingPageId_LandingPages'
)
BEGIN
    ALTER TABLE [por].[LandingPageVersions] WITH NOCHECK
        ADD CONSTRAINT [FK_por_LandingPageVersions_LandingPageId_LandingPages]
        FOREIGN KEY ([LandingPageId]) REFERENCES [por].[LandingPages] ([LandingPageId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckEvents_MovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[CheckEvents]
        ADD CONSTRAINT [FK_tes_CheckEvents_MovementId_TreasuryMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_WithholdingPresentations_MovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[WithholdingPresentations]
        ADD CONSTRAINT [FK_tes_WithholdingPresentations_MovementId_TreasuryMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_OwnChecks_MovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[OwnChecks]
        ADD CONSTRAINT [FK_tes_OwnChecks_MovementId_TreasuryMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxObligations_TreasuryMovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [fis].[TaxObligations]
        ADD CONSTRAINT [FK_fis_TaxObligations_TreasuryMovementId_TreasuryMovements]
        FOREIGN KEY ([TreasuryMovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_DifferenceMovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_DifferenceMovementId_TreasuryMovements]
        FOREIGN KEY ([DifferenceMovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_MovementIdsId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_MovementIdsId_TreasuryMovements]
        FOREIGN KEY ([MovementIdsId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ThirdPartyChecks_TreasuryMovementIdsId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[ThirdPartyChecks]
        ADD CONSTRAINT [FK_tes_ThirdPartyChecks_TreasuryMovementIdsId_TreasuryMovements]
        FOREIGN KEY ([TreasuryMovementIdsId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardPresentations_MovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[CardPresentations]
        ADD CONSTRAINT [FK_tes_CardPresentations_MovementId_TreasuryMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PayrollPaymentBatches_MovementIdsId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[PayrollPaymentBatches]
        ADD CONSTRAINT [FK_tes_PayrollPaymentBatches_MovementIdsId_TreasuryMovements]
        FOREIGN KEY ([MovementIdsId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionReconciliations_TreasuryMovementIdsId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [cob].[CollectionReconciliations]
        ADD CONSTRAINT [FK_cob_CollectionReconciliations_TreasuryMovementIdsId_TreasuryMovements]
        FOREIGN KEY ([TreasuryMovementIdsId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_DeductionPlans_TreasuryPaymentRefId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [sue].[DeductionPlans]
        ADD CONSTRAINT [FK_sue_DeductionPlans_TreasuryPaymentRefId_TreasuryMovements]
        FOREIGN KEY ([TreasuryPaymentRefId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryCashClosings_ShortageMovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[TreasuryCashClosings]
        ADD CONSTRAINT [FK_tes_TreasuryCashClosings_ShortageMovementId_TreasuryMovements]
        FOREIGN KEY ([ShortageMovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardSettlements_TreasuryMovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[CardSettlements]
        ADD CONSTRAINT [FK_tes_CardSettlements_TreasuryMovementId_TreasuryMovements]
        FOREIGN KEY ([TreasuryMovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_treasury_TreasuryMovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_treasury]
        ADD CONSTRAINT [FK_bia_Bi_fact_treasury_TreasuryMovementId_TreasuryMovements]
        FOREIGN KEY ([TreasuryMovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CashRemittances_ShortageMovementId_TreasuryMovements'
)
BEGIN
    ALTER TABLE [tes].[CashRemittances]
        ADD CONSTRAINT [FK_tes_CashRemittances_ShortageMovementId_TreasuryMovements]
        FOREIGN KEY ([ShortageMovementId]) REFERENCES [tes].[TreasuryMovements] ([TreasuryMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_Dossiers_LegalHoldIdsId_LegalHolds'
)
BEGIN
    ALTER TABLE [wfl].[Dossiers]
        ADD CONSTRAINT [FK_wfl_Dossiers_LegalHoldIdsId_LegalHolds]
        FOREIGN KEY ([LegalHoldIdsId]) REFERENCES [nfr].[LegalHolds] ([LegalHoldId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_Documents_LegalHoldIdsId_LegalHolds'
)
BEGIN
    ALTER TABLE [wfl].[Documents]
        ADD CONSTRAINT [FK_wfl_Documents_LegalHoldIdsId_LegalHolds]
        FOREIGN KEY ([LegalHoldIdsId]) REFERENCES [nfr].[LegalHolds] ([LegalHoldId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalDelegationInvites_AccessId_PortalAccountAccess'
)
BEGIN
    ALTER TABLE [por].[PortalDelegationInvites]
        ADD CONSTRAINT [FK_por_PortalDelegationInvites_AccessId_PortalAccountAccess]
        FOREIGN KEY ([AccessId]) REFERENCES [por].[PortalAccountAccess] ([PortalAccountAccesId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FleetVehicles_GpsDeviceId_GpsDevices'
)
BEGIN
    ALTER TABLE [soc].[FleetVehicles] WITH NOCHECK
        ADD CONSTRAINT [FK_soc_FleetVehicles_GpsDeviceId_GpsDevices]
        FOREIGN KEY ([GpsDeviceId]) REFERENCES [soc].[GpsDevices] ([GpsDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_RuleId_ReconciliationRules'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_RuleId_ReconciliationRules]
        FOREIGN KEY ([RuleId]) REFERENCES [tes].[ReconciliationRules] ([ReconciliationRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DueDateSurchargeSchemes_ScopeCycleIdsId_BillingCycles'
)
BEGIN
    ALTER TABLE [mor].[DueDateSurchargeSchemes]
        ADD CONSTRAINT [FK_mor_DueDateSurchargeSchemes_ScopeCycleIdsId_BillingCycles]
        FOREIGN KEY ([ScopeCycleIdsId]) REFERENCES [fac].[BillingCycles] ([BillingCycleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalDecisions_DelegationId_Delegations'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalDecisions]
        ADD CONSTRAINT [FK_wfl_ApprovalDecisions_DelegationId_Delegations]
        FOREIGN KEY ([DelegationId]) REFERENCES [wfl].[Delegations] ([DelegationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_RollbackJournal_CutoverId_CutoverPlans'
)
BEGIN
    ALTER TABLE [mig].[RollbackJournal]
        ADD CONSTRAINT [FK_mig_RollbackJournal_CutoverId_CutoverPlans]
        FOREIGN KEY ([CutoverId]) REFERENCES [mig].[CutoverPlans] ([CutoverPlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditAccess_DeviceId_TrustedDevices'
)
BEGIN
    ALTER TABLE [iam].[AuditAccess]
        ADD CONSTRAINT [FK_iam_AuditAccess_DeviceId_TrustedDevices]
        FOREIGN KEY ([DeviceId]) REFERENCES [iam].[TrustedDevices] ([TrustedDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestBillingRunItems_RunId_InterestBillingRuns'
)
BEGIN
    ALTER TABLE [mor].[InterestBillingRunItems]
        ADD CONSTRAINT [FK_mor_InterestBillingRunItems_RunId_InterestBillingRuns]
        FOREIGN KEY ([RunId]) REFERENCES [mor].[InterestBillingRuns] ([InterestBillingRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitMandates_GatewayConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitMandates]
        ADD CONSTRAINT [FK_cob_DirectDebitMandates_GatewayConnectorId_GatewayConnectors]
        FOREIGN KEY ([GatewayConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayWebhookEvents_ConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[GatewayWebhookEvents]
        ADD CONSTRAINT [FK_cob_GatewayWebhookEvents_ConnectorId_GatewayConnectors]
        FOREIGN KEY ([ConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyBillers_SummaryServiceConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyBillers]
        ADD CONSTRAINT [FK_cob_ThirdPartyBillers_SummaryServiceConnectorId_GatewayConnectors]
        FOREIGN KEY ([SummaryServiceConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_ConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_ConnectorId_GatewayConnectors]
        FOREIGN KEY ([ConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentChannels_GatewayConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[PaymentChannels]
        ADD CONSTRAINT [FK_cob_PaymentChannels_GatewayConnectorId_GatewayConnectors]
        FOREIGN KEY ([GatewayConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayTransactions_ConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[GatewayTransactions]
        ADD CONSTRAINT [FK_cob_GatewayTransactions_ConnectorId_GatewayConnectors]
        FOREIGN KEY ([ConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentIntents_GatewayConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[PaymentIntents]
        ADD CONSTRAINT [FK_cob_PaymentIntents_GatewayConnectorId_GatewayConnectors]
        FOREIGN KEY ([GatewayConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_ConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters]
        ADD CONSTRAINT [FK_cob_CashRegisters_ConnectorId_GatewayConnectors]
        FOREIGN KEY ([ConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_StaticQrCodes_GatewayConnectorId_GatewayConnectors'
)
BEGIN
    ALTER TABLE [cob].[StaticQrCodes] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_StaticQrCodes_GatewayConnectorId_GatewayConnectors]
        FOREIGN KEY ([GatewayConnectorId]) REFERENCES [cob].[GatewayConnectors] ([GatewayConnectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCases_IncidentId_CrmIncidents'
)
BEGIN
    ALTER TABLE [crm].[CrmCases]
        ADD CONSTRAINT [FK_crm_CrmCases_IncidentId_CrmIncidents]
        FOREIGN KEY ([IncidentId]) REFERENCES [crm].[CrmIncidents] ([CrmIncidentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostCenters_GroupIdsId_CostCenterGroups'
)
BEGIN
    ALTER TABLE [con].[CostCenters] WITH NOCHECK
        ADD CONSTRAINT [FK_con_CostCenters_GroupIdsId_CostCenterGroups]
        FOREIGN KEY ([GroupIdsId]) REFERENCES [con].[CostCenterGroups] ([CostCenterGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalFormSubmissions_UserId_Memberships'
)
BEGIN
    ALTER TABLE [por].[PortalFormSubmissions]
        ADD CONSTRAINT [FK_por_PortalFormSubmissions_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckDrawerAccounts_BlockedById_Memberships'
)
BEGIN
    ALTER TABLE [tes].[CheckDrawerAccounts]
        ADD CONSTRAINT [FK_tes_CheckDrawerAccounts_BlockedById_Memberships]
        FOREIGN KEY ([BlockedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Resolutions_ResponsibleUserId_Memberships'
)
BEGIN
    ALTER TABLE [ins].[Resolutions]
        ADD CONSTRAINT [FK_ins_Resolutions_ResponsibleUserId_Memberships]
        FOREIGN KEY ([ResponsibleUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ExtBulkExports_UserId_Memberships'
)
BEGIN
    ALTER TABLE [bia].[ExtBulkExports]
        ADD CONSTRAINT [FK_bia_ExtBulkExports_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementSimulations_RequestedById_Memberships'
)
BEGIN
    ALTER TABLE [mor].[AgreementSimulations]
        ADD CONSTRAINT [FK_mor_AgreementSimulations_RequestedById_Memberships]
        FOREIGN KEY ([RequestedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExternalPayrollImports_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [sue].[ExternalPayrollImports]
        ADD CONSTRAINT [FK_sue_ExternalPayrollImports_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureRequests_RequestedById_Memberships'
)
BEGIN
    ALTER TABLE [wfl].[SignatureRequests]
        ADD CONSTRAINT [FK_wfl_SignatureRequests_RequestedById_Memberships]
        FOREIGN KEY ([RequestedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_EditPresence_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[EditPresence]
        ADD CONSTRAINT [FK_iam_EditPresence_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_NewsletterRecipients_UserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[NewsletterRecipients]
        ADD CONSTRAINT [FK_com_NewsletterRecipients_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldResources_UserId_Memberships'
)
BEGIN
    ALTER TABLE [tec].[FieldResources]
        ADD CONSTRAINT [FK_tec_FieldResources_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCalendarEvents_UserId_Memberships'
)
BEGIN
    ALTER TABLE [crm].[CrmCalendarEvents]
        ADD CONSTRAINT [FK_crm_CrmCalendarEvents_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_BenefitPartners_ValidatorUserIdsId_Memberships'
)
BEGIN
    ALTER TABLE [com].[BenefitPartners]
        ADD CONSTRAINT [FK_com_BenefitPartners_ValidatorUserIdsId_Memberships]
        FOREIGN KEY ([ValidatorUserIdsId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_MaintenancePlans_ResponsibleId_Memberships'
)
BEGIN
    ALTER TABLE [tec].[MaintenancePlans]
        ADD CONSTRAINT [FK_tec_MaintenancePlans_ResponsibleId_Memberships]
        FOREIGN KEY ([ResponsibleId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_TreasuryHandovers_DeliveredById_Memberships'
)
BEGIN
    ALTER TABLE [cob].[TreasuryHandovers]
        ADD CONSTRAINT [FK_cob_TreasuryHandovers_DeliveredById_Memberships]
        FOREIGN KEY ([DeliveredById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_TreasuryHandovers_ReceivedById_Memberships'
)
BEGIN
    ALTER TABLE [cob].[TreasuryHandovers]
        ADD CONSTRAINT [FK_cob_TreasuryHandovers_ReceivedById_Memberships]
        FOREIGN KEY ([ReceivedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportAccessLogs_UserId_Memberships'
)
BEGIN
    ALTER TABLE [bia].[ReportAccessLogs]
        ADD CONSTRAINT [FK_bia_ReportAccessLogs_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Comments_MentionsId_Memberships'
)
BEGIN
    ALTER TABLE [com].[Comments]
        ADD CONSTRAINT [FK_com_Comments_MentionsId_Memberships]
        FOREIGN KEY ([MentionsId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DispenserWithdrawals_OperatorId_Memberships'
)
BEGIN
    ALTER TABLE [soc].[DispenserWithdrawals]
        ADD CONSTRAINT [FK_soc_DispenserWithdrawals_OperatorId_Memberships]
        FOREIGN KEY ([OperatorId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_DashboardUserPrefs_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [bia].[DashboardUserPrefs]
        ADD CONSTRAINT [FK_bia_DashboardUserPrefs_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_AiUsageLogs_ActorId_Memberships'
)
BEGIN
    ALTER TABLE [int].[AiUsageLogs]
        ADD CONSTRAINT [FK_int_AiUsageLogs_ActorId_Memberships]
        FOREIGN KEY ([ActorId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_GuidelineAcceptances_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [com].[GuidelineAcceptances]
        ADD CONSTRAINT [FK_com_GuidelineAcceptances_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_SyncConflicts_AssigneeId_Memberships'
)
BEGIN
    ALTER TABLE [tec].[SyncConflicts]
        ADD CONSTRAINT [FK_tec_SyncConflicts_AssigneeId_Memberships]
        FOREIGN KEY ([AssigneeId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_SyncConflicts_ResolvedById_Memberships'
)
BEGIN
    ALTER TABLE [tec].[SyncConflicts]
        ADD CONSTRAINT [FK_tec_SyncConflicts_ResolvedById_Memberships]
        FOREIGN KEY ([ResolvedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationAlerts_AckById_Memberships'
)
BEGIN
    ALTER TABLE [int].[IntegrationAlerts]
        ADD CONSTRAINT [FK_int_IntegrationAlerts_AckById_Memberships]
        FOREIGN KEY ([AckById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationAlerts_ResolvedById_Memberships'
)
BEGIN
    ALTER TABLE [int].[IntegrationAlerts]
        ADD CONSTRAINT [FK_int_IntegrationAlerts_ResolvedById_Memberships]
        FOREIGN KEY ([ResolvedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ReaderWorkSessions_ReaderId_Memberships'
)
BEGIN
    ALTER TABLE [med].[ReaderWorkSessions]
        ADD CONSTRAINT [FK_med_ReaderWorkSessions_ReaderId_Memberships]
        FOREIGN KEY ([ReaderId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalUserPreferences_UserId_Memberships'
)
BEGIN
    ALTER TABLE [por].[PortalUserPreferences]
        ADD CONSTRAINT [FK_por_PortalUserPreferences_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberingPlan_OperatorId_Memberships'
)
BEGIN
    ALTER TABLE [tec].[NumberingPlan]
        ADD CONSTRAINT [FK_tec_NumberingPlan_OperatorId_Memberships]
        FOREIGN KEY ([OperatorId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierEvaluations_UserId_Memberships'
)
BEGIN
    ALTER TABLE [cmp].[SupplierEvaluations]
        ADD CONSTRAINT [FK_cmp_SupplierEvaluations_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckEvents_UserId_Memberships'
)
BEGIN
    ALTER TABLE [tes].[CheckEvents]
        ADD CONSTRAINT [FK_tes_CheckEvents_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_LegalHolds_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [nfr].[LegalHolds]
        ADD CONSTRAINT [FK_nfr_LegalHolds_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_LegalHolds_RequestedById_Memberships'
)
BEGIN
    ALTER TABLE [nfr].[LegalHolds]
        ADD CONSTRAINT [FK_nfr_LegalHolds_RequestedById_Memberships]
        FOREIGN KEY ([RequestedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalAccountAccess_GrantedByUserId_Memberships'
)
BEGIN
    ALTER TABLE [por].[PortalAccountAccess]
        ADD CONSTRAINT [FK_por_PortalAccountAccess_GrantedByUserId_Memberships]
        FOREIGN KEY ([GrantedByUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalAccountAccess_RevokedById_Memberships'
)
BEGIN
    ALTER TABLE [por].[PortalAccountAccess]
        ADD CONSTRAINT [FK_por_PortalAccountAccess_RevokedById_Memberships]
        FOREIGN KEY ([RevokedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalAccountAccess_UserId_Memberships'
)
BEGIN
    ALTER TABLE [por].[PortalAccountAccess]
        ADD CONSTRAINT [FK_por_PortalAccountAccess_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ShareLinks_CreatedById_Memberships'
)
BEGIN
    ALTER TABLE [wfl].[ShareLinks]
        ADD CONSTRAINT [FK_wfl_ShareLinks_CreatedById_Memberships]
        FOREIGN KEY ([CreatedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_Delegations_CreatedById_Memberships'
)
BEGIN
    ALTER TABLE [wfl].[Delegations]
        ADD CONSTRAINT [FK_wfl_Delegations_CreatedById_Memberships]
        FOREIGN KEY ([CreatedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryAccountSigners_UserId_Memberships'
)
BEGIN
    ALTER TABLE [tes].[TreasuryAccountSigners]
        ADD CONSTRAINT [FK_tes_TreasuryAccountSigners_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestBillingRuns_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [mor].[InterestBillingRuns]
        ADD CONSTRAINT [FK_mor_InterestBillingRuns_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ServiceReceptions_RegisteredById_Memberships'
)
BEGIN
    ALTER TABLE [stk].[ServiceReceptions]
        ADD CONSTRAINT [FK_stk_ServiceReceptions_RegisteredById_Memberships]
        FOREIGN KEY ([RegisteredById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ServiceReceptions_RequestedById_Memberships'
)
BEGIN
    ALTER TABLE [stk].[ServiceReceptions]
        ADD CONSTRAINT [FK_stk_ServiceReceptions_RequestedById_Memberships]
        FOREIGN KEY ([RequestedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditAccess_ActorId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[AuditAccess]
        ADD CONSTRAINT [FK_iam_AuditAccess_ActorId_Memberships]
        FOREIGN KEY ([ActorId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DependentEvents_ActorUserId_Memberships'
)
BEGIN
    ALTER TABLE [soc].[DependentEvents]
        ADD CONSTRAINT [FK_soc_DependentEvents_ActorUserId_Memberships]
        FOREIGN KEY ([ActorUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_MessageTemplateVersions_PublishedById_Memberships'
)
BEGIN
    ALTER TABLE [com].[MessageTemplateVersions]
        ADD CONSTRAINT [FK_com_MessageTemplateVersions_PublishedById_Memberships]
        FOREIGN KEY ([PublishedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Rosters_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [ins].[Rosters]
        ADD CONSTRAINT [FK_ins_Rosters_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeDocuments_ReviewedById_Memberships'
)
BEGIN
    ALTER TABLE [sue].[EmployeeDocuments]
        ADD CONSTRAINT [FK_sue_EmployeeDocuments_ReviewedById_Memberships]
        FOREIGN KEY ([ReviewedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollConfigVersions_PublishedById_Memberships'
)
BEGIN
    ALTER TABLE [sue].[PayrollConfigVersions]
        ADD CONSTRAINT [FK_sue_PayrollConfigVersions_PublishedById_Memberships]
        FOREIGN KEY ([PublishedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollConfigVersions_ReviewedById_Memberships'
)
BEGIN
    ALTER TABLE [sue].[PayrollConfigVersions]
        ADD CONSTRAINT [FK_sue_PayrollConfigVersions_ReviewedById_Memberships]
        FOREIGN KEY ([ReviewedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_OpenDataPublications_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [bia].[OpenDataPublications]
        ADD CONSTRAINT [FK_bia_OpenDataPublications_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_EventRegistrations_CheckedInById_Memberships'
)
BEGIN
    ALTER TABLE [com].[EventRegistrations]
        ADD CONSTRAINT [FK_com_EventRegistrations_CheckedInById_Memberships]
        FOREIGN KEY ([CheckedInById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_EventRegistrations_UserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[EventRegistrations]
        ADD CONSTRAINT [FK_com_EventRegistrations_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_OutagePlans_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [tec].[OutagePlans]
        ADD CONSTRAINT [FK_tec_OutagePlans_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationContingencies_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [int].[IntegrationContingencies]
        ADD CONSTRAINT [FK_int_IntegrationContingencies_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationContingencies_DeclaredById_Memberships'
)
BEGIN
    ALTER TABLE [int].[IntegrationContingencies]
        ADD CONSTRAINT [FK_int_IntegrationContingencies_DeclaredById_Memberships]
        FOREIGN KEY ([DeclaredById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationContingencies_EndedById_Memberships'
)
BEGIN
    ALTER TABLE [int].[IntegrationContingencies]
        ADD CONSTRAINT [FK_int_IntegrationContingencies_EndedById_Memberships]
        FOREIGN KEY ([EndedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PaymentCashSessions_UserId_Memberships'
)
BEGIN
    ALTER TABLE [tes].[PaymentCashSessions]
        ADD CONSTRAINT [FK_tes_PaymentCashSessions_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_PlatformTableAdoptions_AcknowledgedById_Memberships'
)
BEGIN
    ALTER TABLE [cfg].[PlatformTableAdoptions]
        ADD CONSTRAINT [FK_cfg_PlatformTableAdoptions_AcknowledgedById_Memberships]
        FOREIGN KEY ([AcknowledgedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AccessReviews_ReviewerMembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[AccessReviews]
        ADD CONSTRAINT [FK_iam_AccessReviews_ReviewerMembershipId_Memberships]
        FOREIGN KEY ([ReviewerMembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueTicketEvents_UserId_Memberships'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueTicketEvents]
        ADD CONSTRAINT [FK_crm_CrmQueueTicketEvents_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_OwnChecks_GeneratedById_Memberships'
)
BEGIN
    ALTER TABLE [tes].[OwnChecks]
        ADD CONSTRAINT [FK_tes_OwnChecks_GeneratedById_Memberships]
        FOREIGN KEY ([GeneratedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmploymentCertificates_RequestedById_Memberships'
)
BEGIN
    ALTER TABLE [sue].[EmploymentCertificates]
        ADD CONSTRAINT [FK_sue_EmploymentCertificates_RequestedById_Memberships]
        FOREIGN KEY ([RequestedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSnapshotMembers_UserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[AudienceSnapshotMembers]
        ADD CONSTRAINT [FK_com_AudienceSnapshotMembers_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlements_ConfirmedById_Memberships'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlements]
        ADD CONSTRAINT [FK_cob_AgencySettlements_ConfirmedById_Memberships]
        FOREIGN KEY ([ConfirmedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Proxies_ValidatedById_Memberships'
)
BEGIN
    ALTER TABLE [ins].[Proxies]
        ADD CONSTRAINT [FK_ins_Proxies_ValidatedById_Memberships]
        FOREIGN KEY ([ValidatedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ExchangeRates_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [tes].[ExchangeRates]
        ADD CONSTRAINT [FK_tes_ExchangeRates_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AppNotifications_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [com].[AppNotifications]
        ADD CONSTRAINT [FK_com_AppNotifications_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AppNotifications_SenderUserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[AppNotifications]
        ADD CONSTRAINT [FK_com_AppNotifications_SenderUserId_Memberships]
        FOREIGN KEY ([SenderUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_CustomReports_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [bia].[CustomReports]
        ADD CONSTRAINT [FK_bia_CustomReports_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_CustomReports_OwnerUserId_Memberships'
)
BEGIN
    ALTER TABLE [bia].[CustomReports]
        ADD CONSTRAINT [FK_bia_CustomReports_OwnerUserId_Memberships]
        FOREIGN KEY ([OwnerUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_StreetProposals_DecisionById_Memberships'
)
BEGIN
    ALTER TABLE [cfg].[StreetProposals]
        ADD CONSTRAINT [FK_cfg_StreetProposals_DecisionById_Memberships]
        FOREIGN KEY ([DecisionById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_StreetProposals_ProposedById_Memberships'
)
BEGIN
    ALTER TABLE [cfg].[StreetProposals]
        ADD CONSTRAINT [FK_cfg_StreetProposals_ProposedById_Memberships]
        FOREIGN KEY ([ProposedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ContentReports_ReporterUserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[ContentReports]
        ADD CONSTRAINT [FK_com_ContentReports_ReporterUserId_Memberships]
        FOREIGN KEY ([ReporterUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostViews_UserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[PostViews]
        ADD CONSTRAINT [FK_com_PostViews_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSegments_OwnerUserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[AudienceSegments]
        ADD CONSTRAINT [FK_com_AudienceSegments_OwnerUserId_Memberships]
        FOREIGN KEY ([OwnerUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationReconciliations_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [int].[IntegrationReconciliations]
        ADD CONSTRAINT [FK_int_IntegrationReconciliations_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationIssues_ResolvedById_Memberships'
)
BEGIN
    ALTER TABLE [mig].[MigrationIssues]
        ADD CONSTRAINT [FK_mig_MigrationIssues_ResolvedById_Memberships]
        FOREIGN KEY ([ResolvedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_TaskComments_MentionsId_Memberships'
)
BEGIN
    ALTER TABLE [wfl].[TaskComments]
        ADD CONSTRAINT [FK_wfl_TaskComments_MentionsId_Memberships]
        FOREIGN KEY ([MentionsId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditMessages_TriggeredById_Memberships'
)
BEGIN
    ALTER TABLE [iam].[AuditMessages]
        ADD CONSTRAINT [FK_iam_AuditMessages_TriggeredById_Memberships]
        FOREIGN KEY ([TriggeredById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WaterSamples_TakenById_Memberships'
)
BEGIN
    ALTER TABLE [tec].[WaterSamples]
        ADD CONSTRAINT [FK_tec_WaterSamples_TakenById_Memberships]
        FOREIGN KEY ([TakenById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_DistributionRoutes_CourierUserId_Memberships'
)
BEGIN
    ALTER TABLE [fac].[DistributionRoutes]
        ADD CONSTRAINT [FK_fac_DistributionRoutes_CourierUserId_Memberships]
        FOREIGN KEY ([CourierUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldDevices_UserId_Memberships'
)
BEGIN
    ALTER TABLE [tec].[FieldDevices]
        ADD CONSTRAINT [FK_tec_FieldDevices_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_LocalAgentCommands_AgentId_Memberships'
)
BEGIN
    ALTER TABLE [int].[LocalAgentCommands]
        ADD CONSTRAINT [FK_int_LocalAgentCommands_AgentId_Memberships]
        FOREIGN KEY ([AgentId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_BenchmarkParticipations_ConsentById_Memberships'
)
BEGIN
    ALTER TABLE [bia].[BenchmarkParticipations]
        ADD CONSTRAINT [FK_bia_BenchmarkParticipations_ConsentById_Memberships]
        FOREIGN KEY ([ConsentById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_SeedApplications_AppliedById_Memberships'
)
BEGIN
    ALTER TABLE [cfg].[SeedApplications]
        ADD CONSTRAINT [FK_cfg_SeedApplications_AppliedById_Memberships]
        FOREIGN KEY ([AppliedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostReactions_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [com].[PostReactions]
        ADD CONSTRAINT [FK_com_PostReactions_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_uxd_DictionaryReleases_PublishedById_Memberships'
)
BEGIN
    ALTER TABLE [uxd].[DictionaryReleases]
        ADD CONSTRAINT [FK_uxd_DictionaryReleases_PublishedById_Memberships]
        FOREIGN KEY ([PublishedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_AiQuestions_UserId_Memberships'
)
BEGIN
    ALTER TABLE [bia].[AiQuestions]
        ADD CONSTRAINT [FK_bia_AiQuestions_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_UndoneById_Memberships'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_UndoneById_Memberships]
        FOREIGN KEY ([UndoneById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CashFlowScenarios_OwnerUserId_Memberships'
)
BEGIN
    ALTER TABLE [tes].[CashFlowScenarios]
        ADD CONSTRAINT [FK_tes_CashFlowScenarios_OwnerUserId_Memberships]
        FOREIGN KEY ([OwnerUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SuppressionEntries_LiftedById_Memberships'
)
BEGIN
    ALTER TABLE [com].[SuppressionEntries]
        ADD CONSTRAINT [FK_com_SuppressionEntries_LiftedById_Memberships]
        FOREIGN KEY ([LiftedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DocumentHolds_AppliedById_Memberships'
)
BEGIN
    ALTER TABLE [mor].[DocumentHolds]
        ADD CONSTRAINT [FK_mor_DocumentHolds_AppliedById_Memberships]
        FOREIGN KEY ([AppliedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DocumentHolds_ReleasedById_Memberships'
)
BEGIN
    ALTER TABLE [mor].[DocumentHolds]
        ADD CONSTRAINT [FK_mor_DocumentHolds_ReleasedById_Memberships]
        FOREIGN KEY ([ReleasedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportExports_RequestedById_Memberships'
)
BEGIN
    ALTER TABLE [bia].[ReportExports]
        ADD CONSTRAINT [FK_bia_ReportExports_RequestedById_Memberships]
        FOREIGN KEY ([RequestedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_AdministrativeInquiries_InvestigatorUserId_Memberships'
)
BEGIN
    ALTER TABLE [sue].[AdministrativeInquiries]
        ADD CONSTRAINT [FK_sue_AdministrativeInquiries_InvestigatorUserId_Memberships]
        FOREIGN KEY ([InvestigatorUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_AgendaFeeds_UserId_Memberships'
)
BEGIN
    ALTER TABLE [wfl].[AgendaFeeds]
        ADD CONSTRAINT [FK_wfl_AgendaFeeds_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_MatchExceptions_DecidedById_Memberships'
)
BEGIN
    ALTER TABLE [cmp].[MatchExceptions]
        ADD CONSTRAINT [FK_cmp_MatchExceptions_DecidedById_Memberships]
        FOREIGN KEY ([DecidedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeNotes_AuthorId_Memberships'
)
BEGIN
    ALTER TABLE [sue].[EmployeeNotes]
        ADD CONSTRAINT [FK_sue_EmployeeNotes_AuthorId_Memberships]
        FOREIGN KEY ([AuthorId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MembershipEvents_ActorUserId_Memberships'
)
BEGIN
    ALTER TABLE [ins].[MembershipEvents]
        ADD CONSTRAINT [FK_ins_MembershipEvents_ActorUserId_Memberships]
        FOREIGN KEY ([ActorUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvidedMailboxes_UserId_Memberships'
)
BEGIN
    ALTER TABLE [tec].[ProvidedMailboxes]
        ADD CONSTRAINT [FK_tec_ProvidedMailboxes_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_VoteTallies_TalliedById_Memberships'
)
BEGIN
    ALTER TABLE [ins].[VoteTallies]
        ADD CONSTRAINT [FK_ins_VoteTallies_TalliedById_Memberships]
        FOREIGN KEY ([TalliedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Meetings_CreatedByUserId_Memberships'
)
BEGIN
    ALTER TABLE [ins].[Meetings]
        ADD CONSTRAINT [FK_ins_Meetings_CreatedByUserId_Memberships]
        FOREIGN KEY ([CreatedByUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalDrafts_UserId_Memberships'
)
BEGIN
    ALTER TABLE [por].[PortalDrafts]
        ADD CONSTRAINT [FK_por_PortalDrafts_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalLinkAttempts_UserId_Memberships'
)
BEGIN
    ALTER TABLE [por].[PortalLinkAttempts]
        ADD CONSTRAINT [FK_por_PortalLinkAttempts_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_uxd_DataTableViews_OwnerId_Memberships'
)
BEGIN
    ALTER TABLE [uxd].[DataTableViews]
        ADD CONSTRAINT [FK_uxd_DataTableViews_OwnerId_Memberships]
        FOREIGN KEY ([OwnerId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_BenefitRedemptions_RedeemedById_Memberships'
)
BEGIN
    ALTER TABLE [com].[BenefitRedemptions]
        ADD CONSTRAINT [FK_com_BenefitRedemptions_RedeemedById_Memberships]
        FOREIGN KEY ([RedeemedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_BenefitRedemptions_UserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[BenefitRedemptions]
        ADD CONSTRAINT [FK_com_BenefitRedemptions_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_MobileUsageImports_OperatorId_Memberships'
)
BEGIN
    ALTER TABLE [tec].[MobileUsageImports]
        ADD CONSTRAINT [FK_tec_MobileUsageImports_OperatorId_Memberships]
        FOREIGN KEY ([OperatorId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ApiClients_OwnerMembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[ApiClients]
        ADD CONSTRAINT [FK_iam_ApiClients_OwnerMembershipId_Memberships]
        FOREIGN KEY ([OwnerMembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InaesReports_SubmittedById_Memberships'
)
BEGIN
    ALTER TABLE [ins].[InaesReports]
        ADD CONSTRAINT [FK_ins_InaesReports_SubmittedById_Memberships]
        FOREIGN KEY ([SubmittedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TechnicalNotes_AuthorUserId_Memberships'
)
BEGIN
    ALTER TABLE [tec].[TechnicalNotes]
        ADD CONSTRAINT [FK_tec_TechnicalNotes_AuthorUserId_Memberships]
        FOREIGN KEY ([AuthorUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TechnicalNotes_ResponsibleId_Memberships'
)
BEGIN
    ALTER TABLE [tec].[TechnicalNotes]
        ADD CONSTRAINT [FK_tec_TechnicalNotes_ResponsibleId_Memberships]
        FOREIGN KEY ([ResponsibleId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CdrImports_OperatorId_Memberships'
)
BEGIN
    ALTER TABLE [tec].[CdrImports]
        ADD CONSTRAINT [FK_tec_CdrImports_OperatorId_Memberships]
        FOREIGN KEY ([OperatorId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostUserStates_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [com].[PostUserStates]
        ADD CONSTRAINT [FK_com_PostUserStates_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionReconciliations_ClosedById_Memberships'
)
BEGIN
    ALTER TABLE [cob].[CollectionReconciliations]
        ADD CONSTRAINT [FK_cob_CollectionReconciliations_ClosedById_Memberships]
        FOREIGN KEY ([ClosedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_ReadingRoutes_DefaultReaderIdsId_Memberships'
)
BEGIN
    ALTER TABLE [med].[ReadingRoutes]
        ADD CONSTRAINT [FK_med_ReadingRoutes_DefaultReaderIdsId_Memberships]
        FOREIGN KEY ([DefaultReaderIdsId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNoticeEvents_UserId_Memberships'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNoticeEvents]
        ADD CONSTRAINT [FK_mor_DelinquencyNoticeEvents_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_ConsentRecords_UserId_Memberships'
)
BEGIN
    ALTER TABLE [nfr].[ConsentRecords]
        ADD CONSTRAINT [FK_nfr_ConsentRecords_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingPermissions_UserId_Memberships'
)
BEGIN
    ALTER TABLE [ins].[MeetingPermissions]
        ADD CONSTRAINT [FK_ins_MeetingPermissions_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportSchedules_OwnerUserId_Memberships'
)
BEGIN
    ALTER TABLE [bia].[ReportSchedules]
        ADD CONSTRAINT [FK_bia_ReportSchedules_OwnerUserId_Memberships]
        FOREIGN KEY ([OwnerUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LegacyPortalUserMap_UserId_Memberships'
)
BEGIN
    ALTER TABLE [por].[LegacyPortalUserMap]
        ADD CONSTRAINT [FK_por_LegacyPortalUserMap_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQuickReplies_OwnerUserId_Memberships'
)
BEGIN
    ALTER TABLE [crm].[CrmQuickReplies]
        ADD CONSTRAINT [FK_crm_CrmQuickReplies_OwnerUserId_Memberships]
        FOREIGN KEY ([OwnerUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesReps_UserId_Memberships'
)
BEGIN
    ALTER TABLE [ven].[SalesReps]
        ADD CONSTRAINT [FK_ven_SalesReps_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_RetentionRuns_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [nfr].[RetentionRuns]
        ADD CONSTRAINT [FK_nfr_RetentionRuns_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_KpiAlerts_AcknowledgedById_Memberships'
)
BEGIN
    ALTER TABLE [bia].[KpiAlerts]
        ADD CONSTRAINT [FK_bia_KpiAlerts_AcknowledgedById_Memberships]
        FOREIGN KEY ([AcknowledgedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_KpiAlerts_ResolvedById_Memberships'
)
BEGIN
    ALTER TABLE [bia].[KpiAlerts]
        ADD CONSTRAINT [FK_bia_KpiAlerts_ResolvedById_Memberships]
        FOREIGN KEY ([ResolvedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceImportLists_ImportedById_Memberships'
)
BEGIN
    ALTER TABLE [com].[AudienceImportLists]
        ADD CONSTRAINT [FK_com_AudienceImportLists_ImportedById_Memberships]
        FOREIGN KEY ([ImportedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationFileExchanges_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [int].[IntegrationFileExchanges]
        ADD CONSTRAINT [FK_int_IntegrationFileExchanges_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueDeskSessions_UserId_Memberships'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueDeskSessions]
        ADD CONSTRAINT [FK_crm_CrmQueueDeskSessions_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_StatutoryFilings_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [sue].[StatutoryFilings]
        ADD CONSTRAINT [FK_sue_StatutoryFilings_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_StatutoryFilings_GeneratedById_Memberships'
)
BEGIN
    ALTER TABLE [sue].[StatutoryFilings]
        ADD CONSTRAINT [FK_sue_StatutoryFilings_GeneratedById_Memberships]
        FOREIGN KEY ([GeneratedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_FixedUserId_Memberships'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters]
        ADD CONSTRAINT [FK_cob_CashRegisters_FixedUserId_Memberships]
        FOREIGN KEY ([FixedUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityOccurrences_ClosedByResponsibleId_Memberships'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityOccurrences]
        ADD CONSTRAINT [FK_crm_CrmActivityOccurrences_ClosedByResponsibleId_Memberships]
        FOREIGN KEY ([ClosedByResponsibleId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityOccurrences_ClosedByUserId_Memberships'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityOccurrences]
        ADD CONSTRAINT [FK_crm_CrmActivityOccurrences_ClosedByUserId_Memberships]
        FOREIGN KEY ([ClosedByUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityOccurrences_ResponsibleUserId_Memberships'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityOccurrences]
        ADD CONSTRAINT [FK_crm_CrmActivityOccurrences_ResponsibleUserId_Memberships]
        FOREIGN KEY ([ResponsibleUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalDelegationInvites_GrantorUserId_Memberships'
)
BEGIN
    ALTER TABLE [por].[PortalDelegationInvites]
        ADD CONSTRAINT [FK_por_PortalDelegationInvites_GrantorUserId_Memberships]
        FOREIGN KEY ([GrantorUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalDelegationInvites_InviteeUserId_Memberships'
)
BEGIN
    ALTER TABLE [por].[PortalDelegationInvites]
        ADD CONSTRAINT [FK_por_PortalDelegationInvites_InviteeUserId_Memberships]
        FOREIGN KEY ([InviteeUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankStatementImports_ImportedById_Memberships'
)
BEGIN
    ALTER TABLE [tes].[BankStatementImports]
        ADD CONSTRAINT [FK_tes_BankStatementImports_ImportedById_Memberships]
        FOREIGN KEY ([ImportedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosSessions_ClosedById_Memberships'
)
BEGIN
    ALTER TABLE [ven].[PosSessions]
        ADD CONSTRAINT [FK_ven_PosSessions_ClosedById_Memberships]
        FOREIGN KEY ([ClosedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosSessions_OpenedById_Memberships'
)
BEGIN
    ALTER TABLE [ven].[PosSessions]
        ADD CONSTRAINT [FK_ven_PosSessions_OpenedById_Memberships]
        FOREIGN KEY ([OpenedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_Budgets_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [con].[Budgets]
        ADD CONSTRAINT [FK_con_Budgets_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_SerialUnitEvents_ActorId_Memberships'
)
BEGIN
    ALTER TABLE [stk].[SerialUnitEvents]
        ADD CONSTRAINT [FK_stk_SerialUnitEvents_ActorId_Memberships]
        FOREIGN KEY ([ActorId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Employees_UserAccountId_Memberships'
)
BEGIN
    ALTER TABLE [sue].[Employees]
        ADD CONSTRAINT [FK_sue_Employees_UserAccountId_Memberships]
        FOREIGN KEY ([UserAccountId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryCashClosings_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [tes].[TreasuryCashClosings]
        ADD CONSTRAINT [FK_tes_TreasuryCashClosings_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryCashClosings_ClosedById_Memberships'
)
BEGIN
    ALTER TABLE [tes].[TreasuryCashClosings]
        ADD CONSTRAINT [FK_tes_TreasuryCashClosings_ClosedById_Memberships]
        FOREIGN KEY ([ClosedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierPortalSubmissions_SubmittedById_Memberships'
)
BEGIN
    ALTER TABLE [cmp].[SupplierPortalSubmissions]
        ADD CONSTRAINT [FK_cmp_SupplierPortalSubmissions_SubmittedById_Memberships]
        FOREIGN KEY ([SubmittedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_AiInvoiceExtractions_RequestedById_Memberships'
)
BEGIN
    ALTER TABLE [cmp].[AiInvoiceExtractions]
        ADD CONSTRAINT [FK_cmp_AiInvoiceExtractions_RequestedById_Memberships]
        FOREIGN KEY ([RequestedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCircularRuns_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [crm].[CrmCircularRuns]
        ADD CONSTRAINT [FK_crm_CrmCircularRuns_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunitySanctions_AppliedById_Memberships'
)
BEGIN
    ALTER TABLE [com].[CommunitySanctions]
        ADD CONSTRAINT [FK_com_CommunitySanctions_AppliedById_Memberships]
        FOREIGN KEY ([AppliedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunitySanctions_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [com].[CommunitySanctions]
        ADD CONSTRAINT [FK_com_CommunitySanctions_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunitySanctions_RevokedById_Memberships'
)
BEGIN
    ALTER TABLE [com].[CommunitySanctions]
        ADD CONSTRAINT [FK_com_CommunitySanctions_RevokedById_Memberships]
        FOREIGN KEY ([RevokedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_SodExceptions_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [iam].[SodExceptions]
        ADD CONSTRAINT [FK_iam_SodExceptions_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_SodExceptions_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[SodExceptions]
        ADD CONSTRAINT [FK_iam_SodExceptions_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_SodExceptions_RequestedById_Memberships'
)
BEGIN
    ALTER TABLE [iam].[SodExceptions]
        ADD CONSTRAINT [FK_iam_SodExceptions_RequestedById_Memberships]
        FOREIGN KEY ([RequestedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_ProcessingActivities_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [nfr].[ProcessingActivities]
        ADD CONSTRAINT [FK_nfr_ProcessingActivities_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ProfileAssignments_GrantedById_Memberships'
)
BEGIN
    ALTER TABLE [iam].[ProfileAssignments]
        ADD CONSTRAINT [FK_iam_ProfileAssignments_GrantedById_Memberships]
        FOREIGN KEY ([GrantedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ProfileAssignments_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[ProfileAssignments]
        ADD CONSTRAINT [FK_iam_ProfileAssignments_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_FinancialStatementRuns_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [con].[FinancialStatementRuns]
        ADD CONSTRAINT [FK_con_FinancialStatementRuns_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_QualityEvidence_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [nfr].[QualityEvidence]
        ADD CONSTRAINT [FK_nfr_QualityEvidence_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierReceipts_ReceiverId_Memberships'
)
BEGIN
    ALTER TABLE [cmp].[SupplierReceipts]
        ADD CONSTRAINT [FK_cmp_SupplierReceipts_ReceiverId_Memberships]
        FOREIGN KEY ([ReceiverId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunicationPreferences_UserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[CommunicationPreferences]
        ADD CONSTRAINT [FK_com_CommunicationPreferences_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_Checkbooks_CreatedById_Memberships'
)
BEGIN
    ALTER TABLE [tes].[Checkbooks]
        ADD CONSTRAINT [FK_tes_Checkbooks_CreatedById_Memberships]
        FOREIGN KEY ([CreatedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PlatformNoticeReads_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [com].[PlatformNoticeReads]
        ADD CONSTRAINT [FK_com_PlatformNoticeReads_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalClosings_ClosedById_Memberships'
)
BEGIN
    ALTER TABLE [ins].[CapitalClosings]
        ADD CONSTRAINT [FK_ins_CapitalClosings_ClosedById_Memberships]
        FOREIGN KEY ([ClosedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_CrewSettlements_SupervisorId_Memberships'
)
BEGIN
    ALTER TABLE [stk].[CrewSettlements]
        ADD CONSTRAINT [FK_stk_CrewSettlements_SupervisorId_Memberships]
        FOREIGN KEY ([SupervisorId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialWithdrawals_ResponsibleId_Memberships'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialWithdrawals]
        ADD CONSTRAINT [FK_soc_HousingMaterialWithdrawals_ResponsibleId_Memberships]
        FOREIGN KEY ([ResponsibleId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplyBalances_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [cmp].[SupplyBalances]
        ADD CONSTRAINT [FK_cmp_SupplyBalances_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_RecordedById_Memberships'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_RecordedById_Memberships]
        FOREIGN KEY ([RecordedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ProductionReports_ResponsibleId_Memberships'
)
BEGIN
    ALTER TABLE [stk].[ProductionReports]
        ADD CONSTRAINT [FK_stk_ProductionReports_ResponsibleId_Memberships]
        FOREIGN KEY ([ResponsibleId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ProductionReports_UserId_Memberships'
)
BEGIN
    ALTER TABLE [stk].[ProductionReports]
        ADD CONSTRAINT [FK_stk_ProductionReports_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyResponses_UserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[SurveyResponses]
        ADD CONSTRAINT [FK_com_SurveyResponses_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyInvitations_UserId_Memberships'
)
BEGIN
    ALTER TABLE [com].[SurveyInvitations]
        ADD CONSTRAINT [FK_com_SurveyInvitations_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PushSubscriptions_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [com].[PushSubscriptions]
        ADD CONSTRAINT [FK_com_PushSubscriptions_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_InvoiceMessages_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [com].[InvoiceMessages]
        ADD CONSTRAINT [FK_com_InvoiceMessages_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_ExternalReferences_SupersededById_Memberships'
)
BEGIN
    ALTER TABLE [int].[ExternalReferences]
        ADD CONSTRAINT [FK_int_ExternalReferences_SupersededById_Memberships]
        FOREIGN KEY ([SupersededById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SignalRightsSettlements_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [cmp].[SignalRightsSettlements]
        ADD CONSTRAINT [FK_cmp_SignalRightsSettlements_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashSessions_UserId_Memberships'
)
BEGIN
    ALTER TABLE [cob].[CashSessions]
        ADD CONSTRAINT [FK_cob_CashSessions_UserId_Memberships]
        FOREIGN KEY ([UserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivities_ResponsibleUserId_Memberships'
)
BEGIN
    ALTER TABLE [crm].[CrmActivities]
        ADD CONSTRAINT [FK_crm_CrmActivities_ResponsibleUserId_Memberships]
        FOREIGN KEY ([ResponsibleUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayPeriods_ClosedById_Memberships'
)
BEGIN
    ALTER TABLE [sue].[PayPeriods]
        ADD CONSTRAINT [FK_sue_PayPeriods_ClosedById_Memberships]
        FOREIGN KEY ([ClosedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Revaluations_ResponsibleId_Memberships'
)
BEGIN
    ALTER TABLE [stk].[Revaluations]
        ADD CONSTRAINT [FK_stk_Revaluations_ResponsibleId_Memberships]
        FOREIGN KEY ([ResponsibleId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ActionTokens_MembershipId_Memberships'
)
BEGIN
    ALTER TABLE [iam].[ActionTokens]
        ADD CONSTRAINT [FK_iam_ActionTokens_MembershipId_Memberships]
        FOREIGN KEY ([MembershipId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_Reconciliations_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [tes].[Reconciliations]
        ADD CONSTRAINT [FK_tes_Reconciliations_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_Reconciliations_ClosedById_Memberships'
)
BEGIN
    ALTER TABLE [tes].[Reconciliations]
        ADD CONSTRAINT [FK_tes_Reconciliations_ClosedById_Memberships]
        FOREIGN KEY ([ClosedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_CollectionFollowUps_AssignedToUserId_Memberships'
)
BEGIN
    ALTER TABLE [mor].[CollectionFollowUps]
        ADD CONSTRAINT [FK_mor_CollectionFollowUps_AssignedToUserId_Memberships]
        FOREIGN KEY ([AssignedToUserId]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetHistory_ChangedById_Memberships'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetHistory]
        ADD CONSTRAINT [FK_stk_FixedAssetHistory_ChangedById_Memberships]
        FOREIGN KEY ([ChangedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_PlatformTableReleases_PublishedById_Memberships'
)
BEGIN
    ALTER TABLE [cfg].[PlatformTableReleases]
        ADD CONSTRAINT [FK_cfg_PlatformTableReleases_PublishedById_Memberships]
        FOREIGN KEY ([PublishedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_RefundCases_ApprovedById_Memberships'
)
BEGIN
    ALTER TABLE [cob].[RefundCases]
        ADD CONSTRAINT [FK_cob_RefundCases_ApprovedById_Memberships]
        FOREIGN KEY ([ApprovedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_RefundCases_RequestedById_Memberships'
)
BEGIN
    ALTER TABLE [cob].[RefundCases]
        ADD CONSTRAINT [FK_cob_RefundCases_RequestedById_Memberships]
        FOREIGN KEY ([RequestedById]) REFERENCES [iam].[Memberships] ([MembershipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_MessageTemplates_CurrentVersionId_MessageTemplateVersions'
)
BEGIN
    ALTER TABLE [com].[MessageTemplates] WITH NOCHECK
        ADD CONSTRAINT [FK_com_MessageTemplates_CurrentVersionId_MessageTemplateVersions]
        FOREIGN KEY ([CurrentVersionId]) REFERENCES [com].[MessageTemplateVersions] ([MessageTemplateVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_RosterEntries_RosterId_Rosters'
)
BEGIN
    ALTER TABLE [ins].[RosterEntries]
        ADD CONSTRAINT [FK_ins_RosterEntries_RosterId_Rosters]
        FOREIGN KEY ([RosterId]) REFERENCES [ins].[Rosters] ([RosterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Resolutions_AgendaItemId_MeetingAgendaItems'
)
BEGIN
    ALTER TABLE [ins].[Resolutions] WITH NOCHECK
        ADD CONSTRAINT [FK_ins_Resolutions_AgendaItemId_MeetingAgendaItems]
        FOREIGN KEY ([AgendaItemId]) REFERENCES [ins].[MeetingAgendaItems] ([MeetingAgendaItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_VotingSessions_AgendaItemId_MeetingAgendaItems'
)
BEGIN
    ALTER TABLE [ins].[VotingSessions] WITH NOCHECK
        ADD CONSTRAINT [FK_ins_VotingSessions_AgendaItemId_MeetingAgendaItems]
        FOREIGN KEY ([AgendaItemId]) REFERENCES [ins].[MeetingAgendaItems] ([MeetingAgendaItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollVariables_ConfigVersionId_PayrollConfigVersions'
)
BEGIN
    ALTER TABLE [sue].[PayrollVariables]
        ADD CONSTRAINT [FK_sue_PayrollVariables_ConfigVersionId_PayrollConfigVersions]
        FOREIGN KEY ([ConfigVersionId]) REFERENCES [sue].[PayrollConfigVersions] ([PayrollConfigVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryActs_RightId_BurialRights'
)
BEGIN
    ALTER TABLE [soc].[CemeteryActs]
        ADD CONSTRAINT [FK_soc_CemeteryActs_RightId_BurialRights]
        FOREIGN KEY ([RightId]) REFERENCES [soc].[BurialRights] ([BurialRightId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialUnits_CurrentRightId_BurialRights'
)
BEGIN
    ALTER TABLE [soc].[BurialUnits] WITH NOCHECK
        ADD CONSTRAINT [FK_soc_BurialUnits_CurrentRightId_BurialRights]
        FOREIGN KEY ([CurrentRightId]) REFERENCES [soc].[BurialRights] ([BurialRightId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialRightEvents_RightId_BurialRights'
)
BEGIN
    ALTER TABLE [soc].[BurialRightEvents]
        ADD CONSTRAINT [FK_soc_BurialRightEvents_RightId_BurialRights]
        FOREIGN KEY ([RightId]) REFERENCES [soc].[BurialRights] ([BurialRightId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalFormSubmissions_CrmCaseId_CrmCases'
)
BEGIN
    ALTER TABLE [por].[PortalFormSubmissions]
        ADD CONSTRAINT [FK_por_PortalFormSubmissions_CrmCaseId_CrmCases]
        FOREIGN KEY ([CrmCaseId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_DamageAssessments_CrmCaseId_CrmCases'
)
BEGIN
    ALTER TABLE [tec].[DamageAssessments]
        ADD CONSTRAINT [FK_tec_DamageAssessments_CrmCaseId_CrmCases]
        FOREIGN KEY ([CrmCaseId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PublicSubmissions_CrmCaseId_CrmCases'
)
BEGIN
    ALTER TABLE [por].[PublicSubmissions]
        ADD CONSTRAINT [FK_por_PublicSubmissions_CrmCaseId_CrmCases]
        FOREIGN KEY ([CrmCaseId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ContentReports_CrmCaseId_CrmCases'
)
BEGIN
    ALTER TABLE [com].[ContentReports]
        ADD CONSTRAINT [FK_com_ContentReports_CrmCaseId_CrmCases]
        FOREIGN KEY ([CrmCaseId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_OperationCharges_SourceId_CrmCases'
)
BEGIN
    ALTER TABLE [ven].[OperationCharges]
        ADD CONSTRAINT [FK_ven_OperationCharges_SourceId_CrmCases]
        FOREIGN KEY ([SourceId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmBotSessions_CrmCaseId_CrmCases'
)
BEGIN
    ALTER TABLE [crm].[CrmBotSessions]
        ADD CONSTRAINT [FK_crm_CrmBotSessions_CrmCaseId_CrmCases]
        FOREIGN KEY ([CrmCaseId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmAiSuggestions_TargetId_CrmCases'
)
BEGIN
    ALTER TABLE [crm].[CrmAiSuggestions]
        ADD CONSTRAINT [FK_crm_CrmAiSuggestions_TargetId_CrmCases]
        FOREIGN KEY ([TargetId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_ticket_CrmCaseId_CrmCases'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_ticket]
        ADD CONSTRAINT [FK_bia_Bi_fact_ticket_CrmCaseId_CrmCases]
        FOREIGN KEY ([CrmCaseId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_CollectionFollowUps_CrmCaseId_CrmCases'
)
BEGIN
    ALTER TABLE [mor].[CollectionFollowUps]
        ADD CONSTRAINT [FK_mor_CollectionFollowUps_CrmCaseId_CrmCases]
        FOREIGN KEY ([CrmCaseId]) REFERENCES [crm].[CrmCases] ([CrmCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReceivedWithholdings_PresentationId_WithholdingPresentations'
)
BEGIN
    ALTER TABLE [tes].[ReceivedWithholdings] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_ReceivedWithholdings_PresentationId_WithholdingPresentations]
        FOREIGN KEY ([PresentationId]) REFERENCES [tes].[WithholdingPresentations] ([WithholdingPresentationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgressMaterials_AllocationId_HousingMaterialAllocations'
)
BEGIN
    ALTER TABLE [soc].[HousingProgressMaterials]
        ADD CONSTRAINT [FK_soc_HousingProgressMaterials_AllocationId_HousingMaterialAllocations]
        FOREIGN KEY ([AllocationId]) REFERENCES [soc].[HousingMaterialAllocations] ([HousingMaterialAllocationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_WorkAccidents_LeaveRequestIdsId_LeaveRequests'
)
BEGIN
    ALTER TABLE [sue].[WorkAccidents]
        ADD CONSTRAINT [FK_sue_WorkAccidents_LeaveRequestIdsId_LeaveRequests]
        FOREIGN KEY ([LeaveRequestIdsId]) REFERENCES [sue].[LeaveRequests] ([LeaveRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmploymentStatusPeriods_SourceRefId_LeaveRequests'
)
BEGIN
    ALTER TABLE [sue].[EmploymentStatusPeriods]
        ADD CONSTRAINT [FK_sue_EmploymentStatusPeriods_SourceRefId_LeaveRequests]
        FOREIGN KEY ([SourceRefId]) REFERENCES [sue].[LeaveRequests] ([LeaveRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialOccupancies_EndActId_CemeteryActs'
)
BEGIN
    ALTER TABLE [soc].[BurialOccupancies]
        ADD CONSTRAINT [FK_soc_BurialOccupancies_EndActId_CemeteryActs]
        FOREIGN KEY ([EndActId]) REFERENCES [soc].[CemeteryActs] ([CemeteryActId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialOccupancies_IntermentActId_CemeteryActs'
)
BEGIN
    ALTER TABLE [soc].[BurialOccupancies]
        ADD CONSTRAINT [FK_soc_BurialOccupancies_IntermentActId_CemeteryActs]
        FOREIGN KEY ([IntermentActId]) REFERENCES [soc].[CemeteryActs] ([CemeteryActId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialServiceCases_CemeteryActId_CemeteryActs'
)
BEGIN
    ALTER TABLE [soc].[BurialServiceCases]
        ADD CONSTRAINT [FK_soc_BurialServiceCases_CemeteryActId_CemeteryActs]
        FOREIGN KEY ([CemeteryActId]) REFERENCES [soc].[CemeteryActs] ([CemeteryActId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_DueDateSchemes_InterestConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [fac].[DueDateSchemes]
        ADD CONSTRAINT [FK_fac_DueDateSchemes_InterestConceptId_BillableConcepts]
        FOREIGN KEY ([InterestConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_concept_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_concept]
        ADD CONSTRAINT [FK_bia_Bi_dim_concept_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryMovements_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [tes].[TreasuryMovements]
        ADD CONSTRAINT [FK_tes_TreasuryMovements_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationRules_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationRules]
        ADD CONSTRAINT [FK_tes_ReconciliationRules_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ReportGroups_ConceptIdsId_BillableConcepts'
)
BEGIN
    ALTER TABLE [sue].[ReportGroups]
        ADD CONSTRAINT [FK_sue_ReportGroups_ConceptIdsId_BillableConcepts]
        FOREIGN KEY ([ConceptIdsId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_WorksInstallmentPlans_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [tar].[WorksInstallmentPlans]
        ADD CONSTRAINT [FK_tar_WorksInstallmentPlans_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryOperations_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [tes].[TreasuryOperations]
        ADD CONSTRAINT [FK_tes_TreasuryOperations_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_Promotions_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [tar].[Promotions]
        ADD CONSTRAINT [FK_tar_Promotions_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_EventChargeBonuses_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [tar].[EventChargeBonuses]
        ADD CONSTRAINT [FK_tar_EventChargeBonuses_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExtraItems_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [sue].[ExtraItems]
        ADD CONSTRAINT [FK_sue_ExtraItems_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_AdherentRates_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [tar].[AdherentRates]
        ADD CONSTRAINT [FK_tar_AdherentRates_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingImports_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [fac].[BillingImports]
        ADD CONSTRAINT [FK_fac_BillingImports_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_OperationCharges_ConceptVersionId_BillableConcepts'
)
BEGIN
    ALTER TABLE [ven].[OperationCharges]
        ADD CONSTRAINT [FK_ven_OperationCharges_ConceptVersionId_BillableConcepts]
        FOREIGN KEY ([ConceptVersionId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_PrescriptionRules_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [mor].[PrescriptionRules]
        ADD CONSTRAINT [FK_mor_PrescriptionRules_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CardPlans_SurchargeConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [cob].[CardPlans]
        ADD CONSTRAINT [FK_cob_CardPlans_SurchargeConceptId_BillableConcepts]
        FOREIGN KEY ([SurchargeConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalReserves_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [ins].[CapitalReserves]
        ADD CONSTRAINT [FK_ins_CapitalReserves_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_EarlyPaymentDiscountRules_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [mor].[EarlyPaymentDiscountRules]
        ADD CONSTRAINT [FK_mor_EarlyPaymentDiscountRules_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingCertificates_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [soc].[HousingCertificates]
        ADD CONSTRAINT [FK_soc_HousingCertificates_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseForecasts_ConceptId_BillableConcepts'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseForecasts]
        ADD CONSTRAINT [FK_cmp_PurchaseForecasts_ConceptId_BillableConcepts]
        FOREIGN KEY ([ConceptId]) REFERENCES [cat].[BillableConcepts] ([BillableConceptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_InterestIndexValues_ImportBatchId_MasterImportJobs'
)
BEGIN
    ALTER TABLE [mor].[InterestIndexValues]
        ADD CONSTRAINT [FK_mor_InterestIndexValues_ImportBatchId_MasterImportJobs]
        FOREIGN KEY ([ImportBatchId]) REFERENCES [cfg].[MasterImportJobs] ([MasterImportJobId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeExtras_TerminationId_Terminations'
)
BEGIN
    ALTER TABLE [sue].[EmployeeExtras]
        ADD CONSTRAINT [FK_sue_EmployeeExtras_TerminationId_Terminations]
        FOREIGN KEY ([TerminationId]) REFERENCES [sue].[Terminations] ([TerminationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_BomStructures_CurrentVersionId_BomStructureVersions'
)
BEGIN
    ALTER TABLE [stk].[BomStructures] WITH NOCHECK
        ADD CONSTRAINT [FK_stk_BomStructures_CurrentVersionId_BomStructureVersions]
        FOREIGN KEY ([CurrentVersionId]) REFERENCES [stk].[BomStructureVersions] ([BomStructureVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingParticipants_MandateId_BodyMandates'
)
BEGIN
    ALTER TABLE [ins].[MeetingParticipants]
        ADD CONSTRAINT [FK_ins_MeetingParticipants_MandateId_BodyMandates]
        FOREIGN KEY ([MandateId]) REFERENCES [ins].[BodyMandates] ([BodyMandateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFeeSettlements_MandateId_BodyMandates'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFeeSettlements]
        ADD CONSTRAINT [FK_ins_InstitutionalFeeSettlements_MandateId_BodyMandates]
        FOREIGN KEY ([MandateId]) REFERENCES [ins].[BodyMandates] ([BodyMandateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_OperationCharges_InstallmentIdsId_SalesInstallments'
)
BEGIN
    ALTER TABLE [ven].[OperationCharges]
        ADD CONSTRAINT [FK_ven_OperationCharges_InstallmentIdsId_SalesInstallments]
        FOREIGN KEY ([InstallmentIdsId]) REFERENCES [ven].[SalesInstallments] ([SalesInstallmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_InstallmentIdsId_SalesInstallments'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders] WITH NOCHECK
        ADD CONSTRAINT [FK_ven_SalesOrders_InstallmentIdsId_SalesInstallments]
        FOREIGN KEY ([InstallmentIdsId]) REFERENCES [ven].[SalesInstallments] ([SalesInstallmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BillableConcepts_AccountingRubricId_AccountRubrics'
)
BEGIN
    ALTER TABLE [cat].[BillableConcepts]
        ADD CONSTRAINT [FK_cat_BillableConcepts_AccountingRubricId_AccountRubrics]
        FOREIGN KEY ([AccountingRubricId]) REFERENCES [con].[AccountRubrics] ([AccountRubricId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalItems_ProductGroupIdsId_AccountRubrics'
)
BEGIN
    ALTER TABLE [ins].[CapitalItems]
        ADD CONSTRAINT [FK_ins_CapitalItems_ProductGroupIdsId_AccountRubrics]
        FOREIGN KEY ([ProductGroupIdsId]) REFERENCES [con].[AccountRubrics] ([AccountRubricId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingAgendaItems_VotingSessionId_VotingSessions'
)
BEGIN
    ALTER TABLE [ins].[MeetingAgendaItems] WITH NOCHECK
        ADD CONSTRAINT [FK_ins_MeetingAgendaItems_VotingSessionId_VotingSessions]
        FOREIGN KEY ([VotingSessionId]) REFERENCES [ins].[VotingSessions] ([VotingSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_VoteTallies_VotingSessionId_VotingSessions'
)
BEGIN
    ALTER TABLE [ins].[VoteTallies]
        ADD CONSTRAINT [FK_ins_VoteTallies_VotingSessionId_VotingSessions]
        FOREIGN KEY ([VotingSessionId]) REFERENCES [ins].[VotingSessions] ([VotingSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_BankDeposits_OperationId_TreasuryOperations'
)
BEGIN
    ALTER TABLE [tes].[BankDeposits]
        ADD CONSTRAINT [FK_tes_BankDeposits_OperationId_TreasuryOperations]
        FOREIGN KEY ([OperationId]) REFERENCES [tes].[TreasuryOperations] ([TreasuryOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_QuoteRequests_SourcingEventId_SourcingEvents'
)
BEGIN
    ALTER TABLE [cmp].[QuoteRequests] WITH NOCHECK
        ADD CONSTRAINT [FK_cmp_QuoteRequests_SourcingEventId_SourcingEvents]
        FOREIGN KEY ([SourcingEventId]) REFERENCES [cmp].[SourcingEvents] ([SourcingEventId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryScales_SalaryCategoryId_SalaryCategories'
)
BEGIN
    ALTER TABLE [sue].[SalaryScales]
        ADD CONSTRAINT [FK_sue_SalaryScales_SalaryCategoryId_SalaryCategories]
        FOREIGN KEY ([SalaryCategoryId]) REFERENCES [sue].[SalaryCategories] ([SalaryCategoryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyCharges_RemittanceId_ThirdPartyRemittances'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyCharges]
        ADD CONSTRAINT [FK_fis_ThirdPartyCharges_RemittanceId_ThirdPartyRemittances]
        FOREIGN KEY ([RemittanceId]) REFERENCES [fis].[ThirdPartyRemittances] ([ThirdPartyRemittanceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DonationAppointments_CampaignId_DonationCampaigns'
)
BEGIN
    ALTER TABLE [soc].[DonationAppointments]
        ADD CONSTRAINT [FK_soc_DonationAppointments_CampaignId_DonationCampaigns]
        FOREIGN KEY ([CampaignId]) REFERENCES [soc].[DonationCampaigns] ([DonationCampaignId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_FundCommitments_CommitmentRefId_Commitments'
)
BEGIN
    ALTER TABLE [tes].[FundCommitments]
        ADD CONSTRAINT [FK_tes_FundCommitments_CommitmentRefId_Commitments]
        FOREIGN KEY ([CommitmentRefId]) REFERENCES [con].[Commitments] ([CommitmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_SettlementId_AgencySettlements'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_SettlementId_AgencySettlements]
        FOREIGN KEY ([SettlementId]) REFERENCES [cob].[AgencySettlements] ([AgencySettlementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlementLines_SettlementId_AgencySettlements'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlementLines]
        ADD CONSTRAINT [FK_cob_AgencySettlementLines_SettlementId_AgencySettlements]
        FOREIGN KEY ([SettlementId]) REFERENCES [cob].[AgencySettlements] ([AgencySettlementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingParticipants_ProxyIdsId_Proxies'
)
BEGIN
    ALTER TABLE [ins].[MeetingParticipants]
        ADD CONSTRAINT [FK_ins_MeetingParticipants_ProxyIdsId_Proxies]
        FOREIGN KEY ([ProxyIdsId]) REFERENCES [ins].[Proxies] ([ProxyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_NoticeModelId_DelinquencyNoticeModels'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_NoticeModelId_DelinquencyNoticeModels]
        FOREIGN KEY ([NoticeModelId]) REFERENCES [mor].[DelinquencyNoticeModels] ([DelinquencyNoticeModelId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitMandates_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitMandates]
        ADD CONSTRAINT [FK_cob_DirectDebitMandates_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyDebtExports_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[AgencyDebtExports]
        ADD CONSTRAINT [FK_cob_AgencyDebtExports_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ExternalKeyAliases_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[ExternalKeyAliases]
        ADD CONSTRAINT [FK_cob_ExternalKeyAliases_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayConnectors_SettlementAgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[GatewayConnectors] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_GatewayConnectors_SettlementAgencyId_CollectionAgencies]
        FOREIGN KEY ([SettlementAgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlements_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlements]
        ADD CONSTRAINT [FK_cob_AgencySettlements_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_FinancingInstitutionPlans_CollectionEntityId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [mor].[FinancingInstitutionPlans]
        ADD CONSTRAINT [FK_mor_FinancingInstitutionPlans_CollectionEntityId_CollectionAgencies]
        FOREIGN KEY ([CollectionEntityId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionReconciliations_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[CollectionReconciliations]
        ADD CONSTRAINT [FK_cob_CollectionReconciliations_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyNoveltyFiles_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[AgencyNoveltyFiles]
        ADD CONSTRAINT [FK_cob_AgencyNoveltyFiles_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters]
        ADD CONSTRAINT [FK_cob_CashRegisters_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyPublishedDebts_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[AgencyPublishedDebts]
        ADD CONSTRAINT [FK_cob_AgencyPublishedDebts_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_DirectDebitBatches_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[DirectDebitBatches]
        ADD CONSTRAINT [FK_cob_DirectDebitBatches_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashOperations_AgencyId_CollectionAgencies'
)
BEGIN
    ALTER TABLE [cob].[CashOperations]
        ADD CONSTRAINT [FK_cob_CashOperations_AgencyId_CollectionAgencies]
        FOREIGN KEY ([AgencyId]) REFERENCES [cob].[CollectionAgencies] ([CollectionAgencyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesDeliveries_FreightSettlementId_TripSettlements'
)
BEGIN
    ALTER TABLE [ven].[SalesDeliveries]
        ADD CONSTRAINT [FK_ven_SalesDeliveries_FreightSettlementId_TripSettlements]
        FOREIGN KEY ([FreightSettlementId]) REFERENCES [soc].[TripSettlements] ([TripSettlementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FuelLoads_TripSettlementId_TripSettlements'
)
BEGIN
    ALTER TABLE [soc].[FuelLoads]
        ADD CONSTRAINT [FK_soc_FuelLoads_TripSettlementId_TripSettlements]
        FOREIGN KEY ([TripSettlementId]) REFERENCES [soc].[TripSettlements] ([TripSettlementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_CommunicationEvents_LinkId_TrackedLinks'
)
BEGIN
    ALTER TABLE [com].[CommunicationEvents]
        ADD CONSTRAINT [FK_com_CommunicationEvents_LinkId_TrackedLinks]
        FOREIGN KEY ([LinkId]) REFERENCES [com].[TrackedLinks] ([TrackedLinkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DependentEvents_DependentId_ServiceDependents'
)
BEGIN
    ALTER TABLE [soc].[DependentEvents]
        ADD CONSTRAINT [FK_soc_DependentEvents_DependentId_ServiceDependents]
        FOREIGN KEY ([DependentId]) REFERENCES [soc].[ServiceDependents] ([ServiceDependentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Lots_LotTypeId_LotTypes'
)
BEGIN
    ALTER TABLE [stk].[Lots]
        ADD CONSTRAINT [FK_stk_Lots_LotTypeId_LotTypes]
        FOREIGN KEY ([LotTypeId]) REFERENCES [stk].[LotTypes] ([LotTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_per_Addresses_StreetRequestId_StreetProposals'
)
BEGIN
    ALTER TABLE [per].[Addresses]
        ADD CONSTRAINT [FK_per_Addresses_StreetRequestId_StreetProposals]
        FOREIGN KEY ([StreetRequestId]) REFERENCES [cfg].[StreetProposals] ([StreetProposalId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSnapshots_OwnerId_Posts'
)
BEGIN
    ALTER TABLE [com].[AudienceSnapshots] WITH NOCHECK
        ADD CONSTRAINT [FK_com_AudienceSnapshots_OwnerId_Posts]
        FOREIGN KEY ([OwnerId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Benefits_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[Benefits]
        ADD CONSTRAINT [FK_com_Benefits_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_NewsletterRecipients_PostIdsId_Posts'
)
BEGIN
    ALTER TABLE [com].[NewsletterRecipients]
        ADD CONSTRAINT [FK_com_NewsletterRecipients_PostIdsId_Posts]
        FOREIGN KEY ([PostIdsId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_ContentReports_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[ContentReports]
        ADD CONSTRAINT [FK_com_ContentReports_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostViews_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[PostViews]
        ADD CONSTRAINT [FK_com_PostViews_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostReactions_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[PostReactions]
        ADD CONSTRAINT [FK_com_PostReactions_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Events_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[Events]
        ADD CONSTRAINT [FK_com_Events_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostDailyStats_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[PostDailyStats]
        ADD CONSTRAINT [FK_com_PostDailyStats_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PostUserStates_PostId_Posts'
)
BEGIN
    ALTER TABLE [com].[PostUserStates]
        ADD CONSTRAINT [FK_com_PostUserStates_PostId_Posts]
        FOREIGN KEY ([PostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Newsletters_FeaturedPostId_Posts'
)
BEGIN
    ALTER TABLE [com].[Newsletters]
        ADD CONSTRAINT [FK_com_Newsletters_FeaturedPostId_Posts]
        FOREIGN KEY ([FeaturedPostId]) REFERENCES [com].[Posts] ([PostId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_CutoverPlans_ProjectId_MigrationProjects'
)
BEGIN
    ALTER TABLE [mig].[CutoverPlans]
        ADD CONSTRAINT [FK_mig_CutoverPlans_ProjectId_MigrationProjects]
        FOREIGN KEY ([ProjectId]) REFERENCES [mig].[MigrationProjects] ([MigrationProjectId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_BypassPlans_ProjectId_MigrationProjects'
)
BEGIN
    ALTER TABLE [mig].[BypassPlans]
        ADD CONSTRAINT [FK_mig_BypassPlans_ProjectId_MigrationProjects]
        FOREIGN KEY ([ProjectId]) REFERENCES [mig].[MigrationProjects] ([MigrationProjectId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryIncreaseBatches_ResultingScaleId_SalaryScales'
)
BEGIN
    ALTER TABLE [sue].[SalaryIncreaseBatches] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_SalaryIncreaseBatches_ResultingScaleId_SalaryScales]
        FOREIGN KEY ([ResultingScaleId]) REFERENCES [sue].[SalaryScales] ([SalaryScaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryIncreaseBatches_SalaryScaleIdsId_SalaryScales'
)
BEGIN
    ALTER TABLE [sue].[SalaryIncreaseBatches]
        ADD CONSTRAINT [FK_sue_SalaryIncreaseBatches_SalaryScaleIdsId_SalaryScales]
        FOREIGN KEY ([SalaryScaleIdsId]) REFERENCES [sue].[SalaryScales] ([SalaryScaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceSnapshots_SegmentId_AudienceSegments'
)
BEGIN
    ALTER TABLE [com].[AudienceSnapshots] WITH NOCHECK
        ADD CONSTRAINT [FK_com_AudienceSnapshots_SegmentId_AudienceSegments]
        FOREIGN KEY ([SegmentId]) REFERENCES [com].[AudienceSegments] ([AudienceSegmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_Posts_AudienceSegmentId_AudienceSegments'
)
BEGIN
    ALTER TABLE [com].[Posts] WITH NOCHECK
        ADD CONSTRAINT [FK_com_Posts_AudienceSegmentId_AudienceSegments]
        FOREIGN KEY ([AudienceSegmentId]) REFERENCES [com].[AudienceSegments] ([AudienceSegmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_InvoiceMessages_SegmentId_AudienceSegments'
)
BEGIN
    ALTER TABLE [com].[InvoiceMessages]
        ADD CONSTRAINT [FK_com_InvoiceMessages_SegmentId_AudienceSegments]
        FOREIGN KEY ([SegmentId]) REFERENCES [com].[AudienceSegments] ([AudienceSegmentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkTypes_PrintTemplateId_WorkOrderPrintTemplates'
)
BEGIN
    ALTER TABLE [tec].[WorkTypes] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_WorkTypes_PrintTemplateId_WorkOrderPrintTemplates]
        FOREIGN KEY ([PrintTemplateId]) REFERENCES [tec].[WorkOrderPrintTemplates] ([WorkOrderPrintTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_IntegrationContingencies_ClosingReconciliationId_IntegrationReconciliations'
)
BEGIN
    ALTER TABLE [int].[IntegrationContingencies]
        ADD CONSTRAINT [FK_int_IntegrationContingencies_ClosingReconciliationId_IntegrationReconciliations]
        FOREIGN KEY ([ClosingReconciliationId]) REFERENCES [int].[IntegrationReconciliations] ([IntegrationReconciliationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_InterruptionCaseIdsId_InterruptionCases'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_InterruptionCaseIdsId_InterruptionCases]
        FOREIGN KEY ([InterruptionCaseIdsId]) REFERENCES [mor].[InterruptionCases] ([InterruptionCasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigStagingRecords_IssuesId_MigrationIssues'
)
BEGIN
    ALTER TABLE [mig].[MigStagingRecords] WITH NOCHECK
        ADD CONSTRAINT [FK_mig_MigStagingRecords_IssuesId_MigrationIssues]
        FOREIGN KEY ([IssuesId]) REFERENCES [mig].[MigrationIssues] ([MigrationIssueId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFeeSettlements_WithholdingRefId_WithholdingsApplied'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFeeSettlements]
        ADD CONSTRAINT [FK_ins_InstitutionalFeeSettlements_WithholdingRefId_WithholdingsApplied]
        FOREIGN KEY ([WithholdingRefId]) REFERENCES [fis].[WithholdingsApplied] ([WithholdingsAppliedId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TripLegs_TripId_TransportTrips'
)
BEGIN
    ALTER TABLE [soc].[TripLegs]
        ADD CONSTRAINT [FK_soc_TripLegs_TripId_TransportTrips]
        FOREIGN KEY ([TripId]) REFERENCES [soc].[TransportTrips] ([TransportTripId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialServiceCases_TripId_TransportTrips'
)
BEGIN
    ALTER TABLE [soc].[BurialServiceCases]
        ADD CONSTRAINT [FK_soc_BurialServiceCases_TripId_TransportTrips]
        FOREIGN KEY ([TripId]) REFERENCES [soc].[TransportTrips] ([TransportTripId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDeliveries_RouteId_DistributionRoutes'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDeliveries]
        ADD CONSTRAINT [FK_fac_InvoiceDeliveries_RouteId_DistributionRoutes]
        FOREIGN KEY ([RouteId]) REFERENCES [fac].[DistributionRoutes] ([DistributionRouteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Payslips_IncomeTaxCalculationId_IncomeTaxCalculations'
)
BEGIN
    ALTER TABLE [sue].[Payslips] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_Payslips_IncomeTaxCalculationId_IncomeTaxCalculations]
        FOREIGN KEY ([IncomeTaxCalculationId]) REFERENCES [sue].[IncomeTaxCalculations] ([IncomeTaxCalculationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentAccessLogs_VersionId_DocumentVersions'
)
BEGIN
    ALTER TABLE [wfl].[DocumentAccessLogs]
        ADD CONSTRAINT [FK_wfl_DocumentAccessLogs_VersionId_DocumentVersions]
        FOREIGN KEY ([VersionId]) REFERENCES [wfl].[DocumentVersions] ([DocumentVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ShareLinks_VersionId_DocumentVersions'
)
BEGIN
    ALTER TABLE [wfl].[ShareLinks]
        ADD CONSTRAINT [FK_wfl_ShareLinks_VersionId_DocumentVersions]
        FOREIGN KEY ([VersionId]) REFERENCES [wfl].[DocumentVersions] ([DocumentVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldEvidence_DeviceId_FieldDevices'
)
BEGIN
    ALTER TABLE [tec].[FieldEvidence]
        ADD CONSTRAINT [FK_tec_FieldEvidence_DeviceId_FieldDevices]
        FOREIGN KEY ([DeviceId]) REFERENCES [tec].[FieldDevices] ([FieldDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Collectors_DeviceIdsId_FieldDevices'
)
BEGIN
    ALTER TABLE [cob].[Collectors]
        ADD CONSTRAINT [FK_cob_Collectors_DeviceIdsId_FieldDevices]
        FOREIGN KEY ([DeviceIdsId]) REFERENCES [tec].[FieldDevices] ([FieldDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_DefaultWorkTypeId_WorkTypes'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_DefaultWorkTypeId_WorkTypes]
        FOREIGN KEY ([DefaultWorkTypeId]) REFERENCES [tec].[WorkTypes] ([WorkTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingPlanChanges_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingPlanChanges]
        ADD CONSTRAINT [FK_soc_HousingPlanChanges_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialAllocations_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialAllocations]
        ADD CONSTRAINT [FK_soc_HousingMaterialAllocations_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingContributions_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingContributions]
        ADD CONSTRAINT [FK_soc_HousingContributions_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingMaterialWithdrawals_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingMaterialWithdrawals]
        ADD CONSTRAINT [FK_soc_HousingMaterialWithdrawals_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingCertificates_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingCertificates]
        ADD CONSTRAINT [FK_soc_HousingCertificates_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingTerminations_UnitId_HousingUnits'
)
BEGIN
    ALTER TABLE [soc].[HousingTerminations]
        ADD CONSTRAINT [FK_soc_HousingTerminations_UnitId_HousingUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[HousingUnits] ([HousingUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_TrackedLinks_CampaignId_Campaigns'
)
BEGIN
    ALTER TABLE [com].[TrackedLinks]
        ADD CONSTRAINT [FK_com_TrackedLinks_CampaignId_Campaigns]
        FOREIGN KEY ([CampaignId]) REFERENCES [com].[Campaigns] ([CampaignId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_InvoiceMessages_CampaignId_Campaigns'
)
BEGIN
    ALTER TABLE [com].[InvoiceMessages]
        ADD CONSTRAINT [FK_com_InvoiceMessages_CampaignId_Campaigns]
        FOREIGN KEY ([CampaignId]) REFERENCES [com].[Campaigns] ([CampaignId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingsApplied_ObligationId_TaxObligations'
)
BEGIN
    ALTER TABLE [fis].[WithholdingsApplied]
        ADD CONSTRAINT [FK_fis_WithholdingsApplied_ObligationId_TaxObligations]
        FOREIGN KEY ([ObligationId]) REFERENCES [fis].[TaxObligations] ([TaxObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxObligations_OwnTaxObligationId_OwnTaxObligations'
)
BEGIN
    ALTER TABLE [fis].[TaxObligations]
        ADD CONSTRAINT [FK_fis_TaxObligations_OwnTaxObligationId_OwnTaxObligations]
        FOREIGN KEY ([OwnTaxObligationId]) REFERENCES [fis].[OwnTaxObligations] ([OwnTaxObligationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusAllocations_DistributionId_SurplusDistributions'
)
BEGIN
    ALTER TABLE [ins].[SurplusAllocations]
        ADD CONSTRAINT [FK_ins_SurplusAllocations_DistributionId_SurplusDistributions]
        FOREIGN KEY ([DistributionId]) REFERENCES [ins].[SurplusDistributions] ([SurplusDistributionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_BomStructureVersions_BomStructureId_BomStructures'
)
BEGIN
    ALTER TABLE [stk].[BomStructureVersions] WITH NOCHECK
        ADD CONSTRAINT [FK_stk_BomStructureVersions_BomStructureId_BomStructures]
        FOREIGN KEY ([BomStructureId]) REFERENCES [stk].[BomStructures] ([BomStructureId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ProductDivisions_BomStructureId_BomStructures'
)
BEGIN
    ALTER TABLE [stk].[ProductDivisions]
        ADD CONSTRAINT [FK_stk_ProductDivisions_BomStructureId_BomStructures]
        FOREIGN KEY ([BomStructureId]) REFERENCES [stk].[BomStructures] ([BomStructureId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_AdministrativeInquiries_ResultingActionIdsId_DisciplinaryActions'
)
BEGIN
    ALTER TABLE [sue].[AdministrativeInquiries] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_AdministrativeInquiries_ResultingActionIdsId_DisciplinaryActions]
        FOREIGN KEY ([ResultingActionIdsId]) REFERENCES [sue].[DisciplinaryActions] ([DisciplinaryActionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Works_GroupId_WorkGroups'
)
BEGIN
    ALTER TABLE [tec].[Works] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_Works_GroupId_WorkGroups]
        FOREIGN KEY ([GroupId]) REFERENCES [tec].[WorkGroups] ([WorkGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_FiscalAuthorizations_DocumentRefId_GatewayDocuments'
)
BEGIN
    ALTER TABLE [fis].[FiscalAuthorizations] WITH NOCHECK
        ADD CONSTRAINT [FK_fis_FiscalAuthorizations_DocumentRefId_GatewayDocuments]
        FOREIGN KEY ([DocumentRefId]) REFERENCES [fis].[GatewayDocuments] ([GatewayDocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_PromotionAssignments_PromotionId_Promotions'
)
BEGIN
    ALTER TABLE [tar].[PromotionAssignments]
        ADD CONSTRAINT [FK_tar_PromotionAssignments_PromotionId_Promotions]
        FOREIGN KEY ([PromotionId]) REFERENCES [tar].[Promotions] ([PromotionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_BonusRecalcRuns_M02ChangeIdsId_BulkContractOperations'
)
BEGIN
    ALTER TABLE [tar].[BonusRecalcRuns]
        ADD CONSTRAINT [FK_tar_BonusRecalcRuns_M02ChangeIdsId_BulkContractOperations]
        FOREIGN KEY ([M02ChangeIdsId]) REFERENCES [cat].[BulkContractOperations] ([BulkContractOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeExtras_ExtraItemId_ExtraItems'
)
BEGIN
    ALTER TABLE [sue].[EmployeeExtras]
        ADD CONSTRAINT [FK_sue_EmployeeExtras_ExtraItemId_ExtraItems]
        FOREIGN KEY ([ExtraItemId]) REFERENCES [sue].[ExtraItems] ([ExtraItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CashFlowSnapshots_ScenarioId_CashFlowScenarios'
)
BEGIN
    ALTER TABLE [tes].[CashFlowSnapshots]
        ADD CONSTRAINT [FK_tes_CashFlowSnapshots_ScenarioId_CashFlowScenarios]
        FOREIGN KEY ([ScenarioId]) REFERENCES [tes].[CashFlowScenarios] ([CashFlowScenarioId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PlannedCashItems_ScenarioId_CashFlowScenarios'
)
BEGIN
    ALTER TABLE [tes].[PlannedCashItems]
        ADD CONSTRAINT [FK_tes_PlannedCashItems_ScenarioId_CashFlowScenarios]
        FOREIGN KEY ([ScenarioId]) REFERENCES [tes].[CashFlowScenarios] ([CashFlowScenarioId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_ThirdPartyCheckId_ThirdPartyChecks'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_ThirdPartyCheckId_ThirdPartyChecks]
        FOREIGN KEY ([ThirdPartyCheckId]) REFERENCES [tes].[ThirdPartyChecks] ([ThirdPartyCheckId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CheckEvents_CheckId_ThirdPartyChecks'
)
BEGIN
    ALTER TABLE [tes].[CheckEvents]
        ADD CONSTRAINT [FK_tes_CheckEvents_CheckId_ThirdPartyChecks]
        FOREIGN KEY ([CheckId]) REFERENCES [tes].[ThirdPartyChecks] ([ThirdPartyCheckId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNotices_HoldIdsId_DocumentHolds'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNotices]
        ADD CONSTRAINT [FK_mor_DelinquencyNotices_HoldIdsId_DocumentHolds]
        FOREIGN KEY ([HoldIdsId]) REFERENCES [mor].[DocumentHolds] ([DocumentHoldId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportAccessLogs_ExportId_ReportExports'
)
BEGIN
    ALTER TABLE [bia].[ReportAccessLogs]
        ADD CONSTRAINT [FK_bia_ReportAccessLogs_ExportId_ReportExports]
        FOREIGN KEY ([ExportId]) REFERENCES [bia].[ReportExports] ([ReportExportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_DisciplinaryActions_InquiryId_AdministrativeInquiries'
)
BEGIN
    ALTER TABLE [sue].[DisciplinaryActions] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_DisciplinaryActions_InquiryId_AdministrativeInquiries]
        FOREIGN KEY ([InquiryId]) REFERENCES [sue].[AdministrativeInquiries] ([AdministrativeInquiryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_Identities_MfaId_AuthFactors'
)
BEGIN
    ALTER TABLE [iam].[Identities] WITH NOCHECK
        ADD CONSTRAINT [FK_iam_Identities_MfaId_AuthFactors]
        FOREIGN KEY ([MfaId]) REFERENCES [iam].[AuthFactors] ([AuthFactorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_WithholdingPresentations_ReceivedWithholdingIdsId_ReceivedWithholdings'
)
BEGIN
    ALTER TABLE [tes].[WithholdingPresentations] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_WithholdingPresentations_ReceivedWithholdingIdsId_ReceivedWithholdings]
        FOREIGN KEY ([ReceivedWithholdingIdsId]) REFERENCES [tes].[ReceivedWithholdings] ([ReceivedWithholdingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayWebhookEvents_RelatedIntentId_PaymentIntents'
)
BEGIN
    ALTER TABLE [cob].[GatewayWebhookEvents]
        ADD CONSTRAINT [FK_cob_GatewayWebhookEvents_RelatedIntentId_PaymentIntents]
        FOREIGN KEY ([RelatedIntentId]) REFERENCES [cob].[PaymentIntents] ([PaymentIntentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_IntentId_PaymentIntents'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_IntentId_PaymentIntents]
        FOREIGN KEY ([IntentId]) REFERENCES [cob].[PaymentIntents] ([PaymentIntentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayTransactions_IntentId_PaymentIntents'
)
BEGIN
    ALTER TABLE [cob].[GatewayTransactions] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_GatewayTransactions_IntentId_PaymentIntents]
        FOREIGN KEY ([IntentId]) REFERENCES [cob].[PaymentIntents] ([PaymentIntentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LaborAgreements_SeniorityScaleId_SeniorityScales'
)
BEGIN
    ALTER TABLE [sue].[LaborAgreements] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_LaborAgreements_SeniorityScaleId_SeniorityScales]
        FOREIGN KEY ([SeniorityScaleId]) REFERENCES [sue].[SeniorityScales] ([SeniorityScaleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_TemplateVersions_DocumentTemplateId_DocumentTemplates'
)
BEGIN
    ALTER TABLE [wfl].[TemplateVersions] WITH NOCHECK
        ADD CONSTRAINT [FK_wfl_TemplateVersions_DocumentTemplateId_DocumentTemplates]
        FOREIGN KEY ([DocumentTemplateId]) REFERENCES [wfl].[DocumentTemplates] ([DocumentTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MemberCredentials_TemplateId_DocumentTemplates'
)
BEGIN
    ALTER TABLE [ins].[MemberCredentials]
        ADD CONSTRAINT [FK_ins_MemberCredentials_TemplateId_DocumentTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [wfl].[DocumentTemplates] ([DocumentTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingPlanChanges_TemplateId_DocumentTemplates'
)
BEGIN
    ALTER TABLE [soc].[HousingPlanChanges]
        ADD CONSTRAINT [FK_soc_HousingPlanChanges_TemplateId_DocumentTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [wfl].[DocumentTemplates] ([DocumentTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SourcingEvents_InvitationTemplateId_DocumentTemplates'
)
BEGIN
    ALTER TABLE [cmp].[SourcingEvents]
        ADD CONSTRAINT [FK_cmp_SourcingEvents_InvitationTemplateId_DocumentTemplates]
        FOREIGN KEY ([InvitationTemplateId]) REFERENCES [wfl].[DocumentTemplates] ([DocumentTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceDocuments_TemplateId_DocumentTemplates'
)
BEGIN
    ALTER TABLE [fac].[InvoiceDocuments]
        ADD CONSTRAINT [FK_fac_InvoiceDocuments_TemplateId_DocumentTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [wfl].[DocumentTemplates] ([DocumentTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_Agreements_TemplateId_DocumentTemplates'
)
BEGIN
    ALTER TABLE [mor].[Agreements]
        ADD CONSTRAINT [FK_mor_Agreements_TemplateId_DocumentTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [wfl].[DocumentTemplates] ([DocumentTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingTerminations_TemplateId_DocumentTemplates'
)
BEGIN
    ALTER TABLE [soc].[HousingTerminations]
        ADD CONSTRAINT [FK_soc_HousingTerminations_TemplateId_DocumentTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [wfl].[DocumentTemplates] ([DocumentTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_BillingImportRows_ImportId_BillingImports'
)
BEGIN
    ALTER TABLE [fac].[BillingImportRows]
        ADD CONSTRAINT [FK_fac_BillingImportRows_ImportId_BillingImports]
        FOREIGN KEY ([ImportId]) REFERENCES [fac].[BillingImports] ([BillingImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceExternalData_ImportId_BillingImports'
)
BEGIN
    ALTER TABLE [fac].[InvoiceExternalData]
        ADD CONSTRAINT [FK_fac_InvoiceExternalData_ImportId_BillingImports]
        FOREIGN KEY ([ImportId]) REFERENCES [fac].[BillingImports] ([BillingImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerProjections_MappingId_AccountMappings'
)
BEGIN
    ALTER TABLE [con].[LedgerProjections]
        ADD CONSTRAINT [FK_con_LedgerProjections_MappingId_AccountMappings]
        FOREIGN KEY ([MappingId]) REFERENCES [con].[AccountMappings] ([AccountMappingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_FormVersions_FormDefinitionId_FormDefinitions'
)
BEGIN
    ALTER TABLE [wfl].[FormVersions] WITH NOCHECK
        ADD CONSTRAINT [FK_wfl_FormVersions_FormDefinitionId_FormDefinitions]
        FOREIGN KEY ([FormDefinitionId]) REFERENCES [wfl].[FormDefinitions] ([FormDefinitionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PlatformNoticeReads_NoticeId_PlatformNotices'
)
BEGIN
    ALTER TABLE [com].[PlatformNoticeReads]
        ADD CONSTRAINT [FK_com_PlatformNoticeReads_NoticeId_PlatformNotices]
        FOREIGN KEY ([NoticeId]) REFERENCES [com].[PlatformNotices] ([PlatformNoticeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrders_ConformityId_ServiceConformities'
)
BEGIN
    ALTER TABLE [tec].[WorkOrders] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_WorkOrders_ConformityId_ServiceConformities]
        FOREIGN KEY ([ConformityId]) REFERENCES [tec].[ServiceConformities] ([ServiceConformityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldResources_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [tec].[FieldResources]
        ADD CONSTRAINT [FK_tec_FieldResources_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleMaintenances_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[VehicleMaintenances]
        ADD CONSTRAINT [FK_soc_VehicleMaintenances_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleUsages_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[VehicleUsages]
        ADD CONSTRAINT [FK_soc_VehicleUsages_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleDocuments_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[VehicleDocuments]
        ADD CONSTRAINT [FK_soc_VehicleDocuments_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_GpsDevices_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[GpsDevices] WITH NOCHECK
        ADD CONSTRAINT [FK_soc_GpsDevices_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TripSettlements_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[TripSettlements]
        ADD CONSTRAINT [FK_soc_TripSettlements_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FuelLoads_VehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [soc].[FuelLoads]
        ADD CONSTRAINT [FK_soc_FuelLoads_VehicleId_FleetVehicles]
        FOREIGN KEY ([VehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Crews_DefaultVehicleId_FleetVehicles'
)
BEGIN
    ALTER TABLE [tec].[Crews]
        ADD CONSTRAINT [FK_tec_Crews_DefaultVehicleId_FleetVehicles]
        FOREIGN KEY ([DefaultVehicleId]) REFERENCES [soc].[FleetVehicles] ([FleetVehicleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_PrescriptionRuns_PrescriptionRuleIdsId_PrescriptionRules'
)
BEGIN
    ALTER TABLE [mor].[PrescriptionRuns]
        ADD CONSTRAINT [FK_mor_PrescriptionRuns_PrescriptionRuleIdsId_PrescriptionRules]
        FOREIGN KEY ([PrescriptionRuleIdsId]) REFERENCES [mor].[PrescriptionRules] ([PrescriptionRuleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DeathSubsidyCases_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[DeathSubsidyCases]
        ADD CONSTRAINT [FK_soc_DeathSubsidyCases_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TransportTrips_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[TransportTrips]
        ADD CONSTRAINT [FK_soc_TransportTrips_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_OrthopedicLoans_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[OrthopedicLoans]
        ADD CONSTRAINT [FK_soc_OrthopedicLoans_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BloodCoverageRequests_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[BloodCoverageRequests]
        ADD CONSTRAINT [FK_soc_BloodCoverageRequests_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialServiceCases_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[BurialServiceCases]
        ADD CONSTRAINT [FK_soc_BurialServiceCases_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HealthAuthorizations_RequestId_BenefitRequests'
)
BEGIN
    ALTER TABLE [soc].[HealthAuthorizations]
        ADD CONSTRAINT [FK_soc_HealthAuthorizations_RequestId_BenefitRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [soc].[BenefitRequests] ([BenefitRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalBalances_CapitalItemId_CapitalItems'
)
BEGIN
    ALTER TABLE [ins].[CapitalBalances]
        ADD CONSTRAINT [FK_ins_CapitalBalances_CapitalItemId_CapitalItems]
        FOREIGN KEY ([CapitalItemId]) REFERENCES [ins].[CapitalItems] ([CapitalItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalMovements_CapitalItemId_CapitalItems'
)
BEGIN
    ALTER TABLE [ins].[CapitalMovements]
        ADD CONSTRAINT [FK_ins_CapitalMovements_CapitalItemId_CapitalItems]
        FOREIGN KEY ([CapitalItemId]) REFERENCES [ins].[CapitalItems] ([CapitalItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalSubscriptionRules_CapitalItemId_CapitalItems'
)
BEGIN
    ALTER TABLE [ins].[CapitalSubscriptionRules]
        ADD CONSTRAINT [FK_ins_CapitalSubscriptionRules_CapitalItemId_CapitalItems]
        FOREIGN KEY ([CapitalItemId]) REFERENCES [ins].[CapitalItems] ([CapitalItemId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectorSettlements_RoundIdsId_CollectionRounds'
)
BEGIN
    ALTER TABLE [cob].[CollectorSettlements]
        ADD CONSTRAINT [FK_cob_CollectorSettlements_RoundIdsId_CollectionRounds]
        FOREIGN KEY ([RoundIdsId]) REFERENCES [cob].[CollectionRounds] ([CollectionRoundId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SourcingEvents_QuoteRequestId_QuoteRequests'
)
BEGIN
    ALTER TABLE [cmp].[SourcingEvents] WITH NOCHECK
        ADD CONSTRAINT [FK_cmp_SourcingEvents_QuoteRequestId_QuoteRequests]
        FOREIGN KEY ([QuoteRequestId]) REFERENCES [cmp].[QuoteRequests] ([QuoteRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Resolutions_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[Resolutions]
        ADD CONSTRAINT [FK_ins_Resolutions_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Rosters_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[Rosters]
        ADD CONSTRAINT [FK_ins_Rosters_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingAgendaItems_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[MeetingAgendaItems]
        ADD CONSTRAINT [FK_ins_MeetingAgendaItems_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_BodyMandates_ElectedAtMeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[BodyMandates]
        ADD CONSTRAINT [FK_ins_BodyMandates_ElectedAtMeetingId_Meetings]
        FOREIGN KEY ([ElectedAtMeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingParticipants_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[MeetingParticipants]
        ADD CONSTRAINT [FK_ins_MeetingParticipants_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_VotingSessions_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[VotingSessions]
        ADD CONSTRAINT [FK_ins_VotingSessions_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Proxies_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[Proxies]
        ADD CONSTRAINT [FK_ins_Proxies_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingPermissions_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[MeetingPermissions]
        ADD CONSTRAINT [FK_ins_MeetingPermissions_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_ElectoralLists_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[ElectoralLists]
        ADD CONSTRAINT [FK_ins_ElectoralLists_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Minutes_MeetingId_Meetings'
)
BEGIN
    ALTER TABLE [ins].[Minutes]
        ADD CONSTRAINT [FK_ins_Minutes_MeetingId_Meetings]
        FOREIGN KEY ([MeetingId]) REFERENCES [ins].[Meetings] ([MeetingId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryScales_IncreaseBatchId_SalaryIncreaseBatches'
)
BEGIN
    ALTER TABLE [sue].[SalaryScales] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_SalaryScales_IncreaseBatchId_SalaryIncreaseBatches]
        FOREIGN KEY ([IncreaseBatchId]) REFERENCES [sue].[SalaryIncreaseBatches] ([SalaryIncreaseBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Rosters_SavedFilterSetId_DataTableViews'
)
BEGIN
    ALTER TABLE [ins].[Rosters]
        ADD CONSTRAINT [FK_ins_Rosters_SavedFilterSetId_DataTableViews]
        FOREIGN KEY ([SavedFilterSetId]) REFERENCES [uxd].[DataTableViews] ([DataTableViewId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_Workstations_LocalAgentId_LocalAgents'
)
BEGIN
    ALTER TABLE [cfg].[Workstations] WITH NOCHECK
        ADD CONSTRAINT [FK_cfg_Workstations_LocalAgentId_LocalAgents]
        FOREIGN KEY ([LocalAgentId]) REFERENCES [int].[LocalAgents] ([LocalAgentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueDisplays_LocalAgentId_LocalAgents'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueDisplays]
        ADD CONSTRAINT [FK_crm_CrmQueueDisplays_LocalAgentId_LocalAgents]
        FOREIGN KEY ([LocalAgentId]) REFERENCES [int].[LocalAgents] ([LocalAgentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_int_LocalAgentCommands_LocalAgentId_LocalAgents'
)
BEGIN
    ALTER TABLE [int].[LocalAgentCommands]
        ADD CONSTRAINT [FK_int_LocalAgentCommands_LocalAgentId_LocalAgents]
        FOREIGN KEY ([LocalAgentId]) REFERENCES [int].[LocalAgents] ([LocalAgentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_KioskDevices_LocalAgentId_LocalAgents'
)
BEGIN
    ALTER TABLE [por].[KioskDevices]
        ADD CONSTRAINT [FK_por_KioskDevices_LocalAgentId_LocalAgents]
        FOREIGN KEY ([LocalAgentId]) REFERENCES [int].[LocalAgents] ([LocalAgentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardVouchers_PresentationId_CardPresentations'
)
BEGIN
    ALTER TABLE [tes].[CardVouchers] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_CardVouchers_PresentationId_CardPresentations]
        FOREIGN KEY ([PresentationId]) REFERENCES [tes].[CardPresentations] ([CardPresentationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_apiUsage_ApiClientId_ApiClients'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_apiUsage]
        ADD CONSTRAINT [FK_bia_Bi_fact_apiUsage_ApiClientId_ApiClients]
        FOREIGN KEY ([ApiClientId]) REFERENCES [iam].[ApiClients] ([ApiClientId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ExtBulkExports_ApiClientId_ApiClients'
)
BEGIN
    ALTER TABLE [bia].[ExtBulkExports]
        ADD CONSTRAINT [FK_bia_ExtBulkExports_ApiClientId_ApiClients]
        FOREIGN KEY ([ApiClientId]) REFERENCES [iam].[ApiClients] ([ApiClientId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportAccessLogs_ApiClientId_ApiClients'
)
BEGIN
    ALTER TABLE [bia].[ReportAccessLogs]
        ADD CONSTRAINT [FK_bia_ReportAccessLogs_ApiClientId_ApiClients]
        FOREIGN KEY ([ApiClientId]) REFERENCES [iam].[ApiClients] ([ApiClientId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_ApiCredentials_ApiClientId_ApiClients'
)
BEGIN
    ALTER TABLE [iam].[ApiCredentials]
        ADD CONSTRAINT [FK_iam_ApiCredentials_ApiClientId_ApiClients]
        FOREIGN KEY ([ApiClientId]) REFERENCES [iam].[ApiClients] ([ApiClientId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_GatewayDocuments_ApiClientId_ApiClients'
)
BEGIN
    ALTER TABLE [fis].[GatewayDocuments]
        ADD CONSTRAINT [FK_fis_GatewayDocuments_ApiClientId_ApiClients]
        FOREIGN KEY ([ApiClientId]) REFERENCES [iam].[ApiClients] ([ApiClientId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_GatewayDocuments_ExternalSystemId_ApiClients'
)
BEGIN
    ALTER TABLE [fis].[GatewayDocuments]
        ADD CONSTRAINT [FK_fis_GatewayDocuments_ExternalSystemId_ApiClients]
        FOREIGN KEY ([ExternalSystemId]) REFERENCES [iam].[ApiClients] ([ApiClientId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ApiUsageDaily_ApiClientId_ApiClients'
)
BEGIN
    ALTER TABLE [bia].[ApiUsageDaily]
        ADD CONSTRAINT [FK_bia_ApiUsageDaily_ApiClientId_ApiClients]
        FOREIGN KEY ([ApiClientId]) REFERENCES [iam].[ApiClients] ([ApiClientId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ExtWebhookSubscriptions_ApiClientId_ApiClients'
)
BEGIN
    ALTER TABLE [bia].[ExtWebhookSubscriptions]
        ADD CONSTRAINT [FK_bia_ExtWebhookSubscriptions_ApiClientId_ApiClients]
        FOREIGN KEY ([ApiClientId]) REFERENCES [iam].[ApiClients] ([ApiClientId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LeaveRequests_NoveltyIdsId_Novelties'
)
BEGIN
    ALTER TABLE [sue].[LeaveRequests]
        ADD CONSTRAINT [FK_sue_LeaveRequests_NoveltyIdsId_Novelties]
        FOREIGN KEY ([NoveltyIdsId]) REFERENCES [sue].[Novelties] ([NoveltyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_IncomeTaxCalculations_OverrideNoveltyId_Novelties'
)
BEGIN
    ALTER TABLE [sue].[IncomeTaxCalculations] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_IncomeTaxCalculations_OverrideNoveltyId_Novelties]
        FOREIGN KEY ([OverrideNoveltyId]) REFERENCES [sue].[Novelties] ([NoveltyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExtraTasks_NoveltyIdsId_Novelties'
)
BEGIN
    ALTER TABLE [sue].[ExtraTasks]
        ADD CONSTRAINT [FK_sue_ExtraTasks_NoveltyIdsId_Novelties]
        FOREIGN KEY ([NoveltyIdsId]) REFERENCES [sue].[Novelties] ([NoveltyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollPaymentRequests_TreasuryRequestId_PayrollPaymentBatches'
)
BEGIN
    ALTER TABLE [sue].[PayrollPaymentRequests] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_PayrollPaymentRequests_TreasuryRequestId_PayrollPaymentBatches]
        FOREIGN KEY ([TreasuryRequestId]) REFERENCES [tes].[PayrollPaymentBatches] ([PayrollPaymentBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CallRecords_AttributedLineId_PhoneLines'
)
BEGIN
    ALTER TABLE [tec].[CallRecords]
        ADD CONSTRAINT [FK_tec_CallRecords_AttributedLineId_PhoneLines]
        FOREIGN KEY ([AttributedLineId]) REFERENCES [tec].[PhoneLines] ([PhoneLineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_EventRegistrations_EventId_Events'
)
BEGIN
    ALTER TABLE [com].[EventRegistrations]
        ADD CONSTRAINT [FK_com_EventRegistrations_EventId_Events]
        FOREIGN KEY ([EventId]) REFERENCES [com].[Events] ([EventId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderOperationTypes_ChecklistFormIdsId_FieldForms'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderOperationTypes]
        ADD CONSTRAINT [FK_tec_WorkOrderOperationTypes_ChecklistFormIdsId_FieldForms]
        FOREIGN KEY ([ChecklistFormIdsId]) REFERENCES [tec].[FieldForms] ([FieldFormId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExternalPayrollImports_PaymentRequestId_PayrollPaymentRequests'
)
BEGIN
    ALTER TABLE [sue].[ExternalPayrollImports] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_ExternalPayrollImports_PaymentRequestId_PayrollPaymentRequests]
        FOREIGN KEY ([PaymentRequestId]) REFERENCES [sue].[PayrollPaymentRequests] ([PayrollPaymentRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollRuns_PaymentRequestId_PayrollPaymentRequests'
)
BEGIN
    ALTER TABLE [sue].[PayrollRuns] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_PayrollRuns_PaymentRequestId_PayrollPaymentRequests]
        FOREIGN KEY ([PaymentRequestId]) REFERENCES [sue].[PayrollPaymentRequests] ([PayrollPaymentRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStripPositions_StripId_PhoneStrips'
)
BEGIN
    ALTER TABLE [tec].[PhoneStripPositions]
        ADD CONSTRAINT [FK_tec_PhoneStripPositions_StripId_PhoneStrips]
        FOREIGN KEY ([StripId]) REFERENCES [tec].[PhoneStrips] ([PhoneStripId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LandingPages_DraftVersionId_LandingPageVersions'
)
BEGIN
    ALTER TABLE [por].[LandingPages] WITH NOCHECK
        ADD CONSTRAINT [FK_por_LandingPages_DraftVersionId_LandingPageVersions]
        FOREIGN KEY ([DraftVersionId]) REFERENCES [por].[LandingPageVersions] ([LandingPageVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_LandingPages_PublishedVersionId_LandingPageVersions'
)
BEGIN
    ALTER TABLE [por].[LandingPages]
        ADD CONSTRAINT [FK_por_LandingPages_PublishedVersionId_LandingPageVersions]
        FOREIGN KEY ([PublishedVersionId]) REFERENCES [por].[LandingPageVersions] ([LandingPageVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryCategories_LaborAgreementId_LaborAgreements'
)
BEGIN
    ALTER TABLE [sue].[SalaryCategories]
        ADD CONSTRAINT [FK_sue_SalaryCategories_LaborAgreementId_LaborAgreements]
        FOREIGN KEY ([LaborAgreementId]) REFERENCES [sue].[LaborAgreements] ([LaborAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SalaryScales_LaborAgreementId_LaborAgreements'
)
BEGIN
    ALTER TABLE [sue].[SalaryScales]
        ADD CONSTRAINT [FK_sue_SalaryScales_LaborAgreementId_LaborAgreements]
        FOREIGN KEY ([LaborAgreementId]) REFERENCES [sue].[LaborAgreements] ([LaborAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SeniorityScales_LaborAgreementId_LaborAgreements'
)
BEGIN
    ALTER TABLE [sue].[SeniorityScales] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_SeniorityScales_LaborAgreementId_LaborAgreements]
        FOREIGN KEY ([LaborAgreementId]) REFERENCES [sue].[LaborAgreements] ([LaborAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalEntries_TemplateId_EntryTemplates'
)
BEGIN
    ALTER TABLE [con].[JournalEntries]
        ADD CONSTRAINT [FK_con_JournalEntries_TemplateId_EntryTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [con].[EntryTemplates] ([EntryTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CallRecords_CdrImportId_CdrImports'
)
BEGIN
    ALTER TABLE [tec].[CallRecords]
        ADD CONSTRAINT [FK_tec_CallRecords_CdrImportId_CdrImports]
        FOREIGN KEY ([CdrImportId]) REFERENCES [tec].[CdrImports] ([CdrImportId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_StockBalances_LotId_Lots'
)
BEGIN
    ALTER TABLE [stk].[StockBalances]
        ADD CONSTRAINT [FK_stk_StockBalances_LotId_Lots]
        FOREIGN KEY ([LotId]) REFERENCES [stk].[Lots] ([LotId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_RefundCases_ReconciliationId_CollectionReconciliations'
)
BEGIN
    ALTER TABLE [cob].[RefundCases]
        ADD CONSTRAINT [FK_cob_RefundCases_ReconciliationId_CollectionReconciliations]
        FOREIGN KEY ([ReconciliationId]) REFERENCES [cob].[CollectionReconciliations] ([CollectionReconciliationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementSimulations_ConvertedAgreementId_Agreements'
)
BEGIN
    ALTER TABLE [mor].[AgreementSimulations]
        ADD CONSTRAINT [FK_mor_AgreementSimulations_ConvertedAgreementId_Agreements]
        FOREIGN KEY ([ConvertedAgreementId]) REFERENCES [mor].[Agreements] ([AgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementObligations_AgreementId_Agreements'
)
BEGIN
    ALTER TABLE [mor].[AgreementObligations]
        ADD CONSTRAINT [FK_mor_AgreementObligations_AgreementId_Agreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [mor].[Agreements] ([AgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_agreement_AgreementId_Agreements'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_agreement]
        ADD CONSTRAINT [FK_bia_Bi_fact_agreement_AgreementId_Agreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [mor].[Agreements] ([AgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_AgreementInstallments_AgreementId_Agreements'
)
BEGIN
    ALTER TABLE [mor].[AgreementInstallments]
        ADD CONSTRAINT [FK_mor_AgreementInstallments_AgreementId_Agreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [mor].[Agreements] ([AgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_Guarantees_AgreementId_Agreements'
)
BEGIN
    ALTER TABLE [mor].[Guarantees] WITH NOCHECK
        ADD CONSTRAINT [FK_mor_Guarantees_AgreementId_Agreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [mor].[Agreements] ([AgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CoveragePlans_AgreementIdsId_Agreements'
)
BEGIN
    ALTER TABLE [soc].[CoveragePlans]
        ADD CONSTRAINT [FK_soc_CoveragePlans_AgreementIdsId_Agreements]
        FOREIGN KEY ([AgreementIdsId]) REFERENCES [mor].[Agreements] ([AgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceConformities_SignatureEvidenceId_FieldEvidence'
)
BEGIN
    ALTER TABLE [tec].[ServiceConformities] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_ServiceConformities_SignatureEvidenceId_FieldEvidence]
        FOREIGN KEY ([SignatureEvidenceId]) REFERENCES [tec].[FieldEvidence] ([FieldEvidenceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_MeteringPoints_ReadingId_ReadingRoutes'
)
BEGIN
    ALTER TABLE [med].[MeteringPoints]
        ADD CONSTRAINT [FK_med_MeteringPoints_ReadingId_ReadingRoutes]
        FOREIGN KEY ([ReadingId]) REFERENCES [med].[ReadingRoutes] ([ReadingRouteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesReturns_CreditNoteRequestId_InvoiceAnnulmentRequests'
)
BEGIN
    ALTER TABLE [ven].[SalesReturns]
        ADD CONSTRAINT [FK_ven_SalesReturns_CreditNoteRequestId_InvoiceAnnulmentRequests]
        FOREIGN KEY ([CreditNoteRequestId]) REFERENCES [fac].[InvoiceAnnulmentRequests] ([InvoiceAnnulmentRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceRelations_RequestId_InvoiceAnnulmentRequests'
)
BEGIN
    ALTER TABLE [fac].[InvoiceRelations]
        ADD CONSTRAINT [FK_fac_InvoiceRelations_RequestId_InvoiceAnnulmentRequests]
        FOREIGN KEY ([RequestId]) REFERENCES [fac].[InvoiceAnnulmentRequests] ([InvoiceAnnulmentRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_RetroactiveDiffRuns_AdjustmentRequestIdsId_InvoiceAnnulmentRequests'
)
BEGIN
    ALTER TABLE [tar].[RetroactiveDiffRuns]
        ADD CONSTRAINT [FK_tar_RetroactiveDiffRuns_AdjustmentRequestIdsId_InvoiceAnnulmentRequests]
        FOREIGN KEY ([AdjustmentRequestIdsId]) REFERENCES [fac].[InvoiceAnnulmentRequests] ([InvoiceAnnulmentRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ReportDeliveries_ScheduleId_ReportSchedules'
)
BEGIN
    ALTER TABLE [bia].[ReportDeliveries]
        ADD CONSTRAINT [FK_bia_ReportDeliveries_ScheduleId_ReportSchedules]
        FOREIGN KEY ([ScheduleId]) REFERENCES [bia].[ReportSchedules] ([ReportScheduleId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_Agreements_GuaranteeIdsId_Guarantees'
)
BEGIN
    ALTER TABLE [mor].[Agreements] WITH NOCHECK
        ADD CONSTRAINT [FK_mor_Agreements_GuaranteeIdsId_Guarantees]
        FOREIGN KEY ([GuaranteeIdsId]) REFERENCES [mor].[Guarantees] ([GuaranteeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_NewsletterRecipients_NewsletterId_Newsletters'
)
BEGIN
    ALTER TABLE [com].[NewsletterRecipients]
        ADD CONSTRAINT [FK_com_NewsletterRecipients_NewsletterId_Newsletters]
        FOREIGN KEY ([NewsletterId]) REFERENCES [com].[Newsletters] ([NewsletterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_BillableConcepts_ThirdPartyId_ThirdPartyAgreements'
)
BEGIN
    ALTER TABLE [cat].[BillableConcepts]
        ADD CONSTRAINT [FK_cat_BillableConcepts_ThirdPartyId_ThirdPartyAgreements]
        FOREIGN KEY ([ThirdPartyId]) REFERENCES [fis].[ThirdPartyAgreements] ([ThirdPartyAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyRemittances_AgreementId_ThirdPartyAgreements'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyRemittances]
        ADD CONSTRAINT [FK_fis_ThirdPartyRemittances_AgreementId_ThirdPartyAgreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [fis].[ThirdPartyAgreements] ([ThirdPartyAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ThirdPartyCharges_AgreementId_ThirdPartyAgreements'
)
BEGIN
    ALTER TABLE [fis].[ThirdPartyCharges]
        ADD CONSTRAINT [FK_fis_ThirdPartyCharges_AgreementId_ThirdPartyAgreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [fis].[ThirdPartyAgreements] ([ThirdPartyAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExternalPayrollImports_AccountingEntryRefId_JournalEntries'
)
BEGIN
    ALTER TABLE [sue].[ExternalPayrollImports]
        ADD CONSTRAINT [FK_sue_ExternalPayrollImports_AccountingEntryRefId_JournalEntries]
        FOREIGN KEY ([AccountingEntryRefId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ExternalLedgerTransfers_EntryIdsId_JournalEntries'
)
BEGIN
    ALTER TABLE [con].[ExternalLedgerTransfers]
        ADD CONSTRAINT [FK_con_ExternalLedgerTransfers_EntryIdsId_JournalEntries]
        FOREIGN KEY ([EntryIdsId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryMovements_JournalEntryId_JournalEntries'
)
BEGIN
    ALTER TABLE [tes].[TreasuryMovements]
        ADD CONSTRAINT [FK_tes_TreasuryMovements_JournalEntryId_JournalEntries]
        FOREIGN KEY ([JournalEntryId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostDistributionRuns_ReclassificationEntryId_JournalEntries'
)
BEGIN
    ALTER TABLE [con].[CostDistributionRuns]
        ADD CONSTRAINT [FK_con_CostDistributionRuns_ReclassificationEntryId_JournalEntries]
        FOREIGN KEY ([ReclassificationEntryId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_InflationAdjustmentRuns_EntryId_JournalEntries'
)
BEGIN
    ALTER TABLE [con].[InflationAdjustmentRuns]
        ADD CONSTRAINT [FK_con_InflationAdjustmentRuns_EntryId_JournalEntries]
        FOREIGN KEY ([EntryId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_FixedAssetValueChanges_JournalEntryId_JournalEntries'
)
BEGIN
    ALTER TABLE [stk].[FixedAssetValueChanges]
        ADD CONSTRAINT [FK_stk_FixedAssetValueChanges_JournalEntryId_JournalEntries]
        FOREIGN KEY ([JournalEntryId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxObligations_JournalEntryId_JournalEntries'
)
BEGIN
    ALTER TABLE [fis].[TaxObligations]
        ADD CONSTRAINT [FK_fis_TaxObligations_JournalEntryId_JournalEntries]
        FOREIGN KEY ([JournalEntryId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_WriteOffs_JournalEntryId_JournalEntries'
)
BEGIN
    ALTER TABLE [mor].[WriteOffs]
        ADD CONSTRAINT [FK_mor_WriteOffs_JournalEntryId_JournalEntries]
        FOREIGN KEY ([JournalEntryId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_InstitutionalFeeSettlements_JournalEntryRefId_JournalEntries'
)
BEGIN
    ALTER TABLE [ins].[InstitutionalFeeSettlements]
        ADD CONSTRAINT [FK_ins_InstitutionalFeeSettlements_JournalEntryRefId_JournalEntries]
        FOREIGN KEY ([JournalEntryRefId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalMovements_JournalEntryRefId_JournalEntries'
)
BEGIN
    ALTER TABLE [ins].[CapitalMovements]
        ADD CONSTRAINT [FK_ins_CapitalMovements_JournalEntryRefId_JournalEntries]
        FOREIGN KEY ([JournalEntryRefId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalLines_EntryId_JournalEntries'
)
BEGIN
    ALTER TABLE [con].[JournalLines]
        ADD CONSTRAINT [FK_con_JournalLines_EntryId_JournalEntries]
        FOREIGN KEY ([EntryId]) REFERENCES [con].[JournalEntries] ([JournalEntryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentCoupons_StatementId_AccountStatements'
)
BEGIN
    ALTER TABLE [cob].[PaymentCoupons] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_PaymentCoupons_StatementId_AccountStatements]
        FOREIGN KEY ([StatementId]) REFERENCES [cob].[AccountStatements] ([AccountStatementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_SalesRepId_SalesReps'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders]
        ADD CONSTRAINT [FK_ven_SalesOrders_SalesRepId_SalesReps]
        FOREIGN KEY ([SalesRepId]) REFERENCES [ven].[SalesReps] ([SalesRepId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesQuotes_SalesRepId_SalesReps'
)
BEGIN
    ALTER TABLE [ven].[SalesQuotes]
        ADD CONSTRAINT [FK_ven_SalesQuotes_SalesRepId_SalesReps]
        FOREIGN KEY ([SalesRepId]) REFERENCES [ven].[SalesReps] ([SalesRepId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosTerminals_DefaultSalesRepId_SalesReps'
)
BEGIN
    ALTER TABLE [ven].[PosTerminals]
        ADD CONSTRAINT [FK_ven_PosTerminals_DefaultSalesRepId_SalesReps]
        FOREIGN KEY ([DefaultSalesRepId]) REFERENCES [ven].[SalesReps] ([SalesRepId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ServiceDependents_CoveragePlanId_CoveragePlans'
)
BEGIN
    ALTER TABLE [soc].[ServiceDependents]
        ADD CONSTRAINT [FK_soc_ServiceDependents_CoveragePlanId_CoveragePlans]
        FOREIGN KEY ([CoveragePlanId]) REFERENCES [soc].[CoveragePlans] ([CoveragePlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_AudienceImportRows_ListId_AudienceImportLists'
)
BEGIN
    ALTER TABLE [com].[AudienceImportRows]
        ADD CONSTRAINT [FK_com_AudienceImportRows_ListId_AudienceImportLists]
        FOREIGN KEY ([ListId]) REFERENCES [com].[AudienceImportLists] ([AudienceImportListId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmQueueTicketEvents_DeskSessionId_CrmQueueDeskSessions'
)
BEGIN
    ALTER TABLE [crm].[CrmQueueTicketEvents]
        ADD CONSTRAINT [FK_crm_CrmQueueTicketEvents_DeskSessionId_CrmQueueDeskSessions]
        FOREIGN KEY ([DeskSessionId]) REFERENCES [crm].[CrmQueueDeskSessions] ([CrmQueueDeskSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionAgencies_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [cob].[CollectionAgencies] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CollectionAgencies_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_KioskDevices_CashboxId_CashRegisters'
)
BEGIN
    ALTER TABLE [por].[KioskDevices]
        ADD CONSTRAINT [FK_por_KioskDevices_CashboxId_CashRegisters]
        FOREIGN KEY ([CashboxId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_StaticQrCodes_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [cob].[StaticQrCodes] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_StaticQrCodes_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashOperations_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [cob].[CashOperations]
        ADD CONSTRAINT [FK_cob_CashOperations_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_cashbox_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_cashbox]
        ADD CONSTRAINT [FK_bia_Bi_dim_cashbox_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashSessions_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [cob].[CashSessions]
        ADD CONSTRAINT [FK_cob_CashSessions_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Collectors_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [cob].[Collectors] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_Collectors_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosTerminals_CashRegisterId_CashRegisters'
)
BEGIN
    ALTER TABLE [ven].[PosTerminals]
        ADD CONSTRAINT [FK_ven_PosTerminals_CashRegisterId_CashRegisters]
        FOREIGN KEY ([CashRegisterId]) REFERENCES [cob].[CashRegisters] ([CashRegisterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_CdrImports_ExchangeId_PhoneExchanges'
)
BEGIN
    ALTER TABLE [tec].[CdrImports]
        ADD CONSTRAINT [FK_tec_CdrImports_ExchangeId_PhoneExchanges]
        FOREIGN KEY ([ExchangeId]) REFERENCES [tec].[PhoneExchanges] ([PhoneExchangeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Dslams_ExchangeId_PhoneExchanges'
)
BEGIN
    ALTER TABLE [tec].[Dslams]
        ADD CONSTRAINT [FK_tec_Dslams_ExchangeId_PhoneExchanges]
        FOREIGN KEY ([ExchangeId]) REFERENCES [tec].[PhoneExchanges] ([PhoneExchangeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneFrames_ExchangeId_PhoneExchanges'
)
BEGIN
    ALTER TABLE [tec].[PhoneFrames]
        ADD CONSTRAINT [FK_tec_PhoneFrames_ExchangeId_PhoneExchanges]
        FOREIGN KEY ([ExchangeId]) REFERENCES [tec].[PhoneExchanges] ([PhoneExchangeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhonePorts_OwnerId_PhoneExchanges'
)
BEGIN
    ALTER TABLE [tec].[PhonePorts]
        ADD CONSTRAINT [FK_tec_PhonePorts_OwnerId_PhoneExchanges]
        FOREIGN KEY ([OwnerId]) REFERENCES [tec].[PhoneExchanges] ([PhoneExchangeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WaterSamples_SamplingPointId_WaterSamplingPoints'
)
BEGIN
    ALTER TABLE [tec].[WaterSamples]
        ADD CONSTRAINT [FK_tec_WaterSamples_SamplingPointId_WaterSamplingPoints]
        FOREIGN KEY ([SamplingPointId]) REFERENCES [tec].[WaterSamplingPoints] ([WaterSamplingPointId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesInstallments_OriginId_SalesOrders'
)
BEGIN
    ALTER TABLE [ven].[SalesInstallments] WITH NOCHECK
        ADD CONSTRAINT [FK_ven_SalesInstallments_OriginId_SalesOrders]
        FOREIGN KEY ([OriginId]) REFERENCES [ven].[SalesOrders] ([SalesOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesReturns_SalesOrderId_SalesOrders'
)
BEGIN
    ALTER TABLE [ven].[SalesReturns]
        ADD CONSTRAINT [FK_ven_SalesReturns_SalesOrderId_SalesOrders]
        FOREIGN KEY ([SalesOrderId]) REFERENCES [ven].[SalesOrders] ([SalesOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesDeliveries_SalesOrderId_SalesOrders'
)
BEGIN
    ALTER TABLE [ven].[SalesDeliveries]
        ADD CONSTRAINT [FK_ven_SalesDeliveries_SalesOrderId_SalesOrders]
        FOREIGN KEY ([SalesOrderId]) REFERENCES [ven].[SalesOrders] ([SalesOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_GatewayDocuments_FiscalAuthorizationId_FiscalAuthorizations'
)
BEGIN
    ALTER TABLE [fis].[GatewayDocuments] WITH NOCHECK
        ADD CONSTRAINT [FK_fis_GatewayDocuments_FiscalAuthorizationId_FiscalAuthorizations]
        FOREIGN KEY ([FiscalAuthorizationId]) REFERENCES [fis].[FiscalAuthorizations] ([FiscalAuthorizationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_ArcaSubmissions_AuthorizationIdsId_FiscalAuthorizations'
)
BEGIN
    ALTER TABLE [fis].[ArcaSubmissions]
        ADD CONSTRAINT [FK_fis_ArcaSubmissions_AuthorizationIdsId_FiscalAuthorizations]
        FOREIGN KEY ([AuthorizationIdsId]) REFERENCES [fis].[FiscalAuthorizations] ([FiscalAuthorizationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesQuoteAcceptances_QuoteId_SalesQuotes'
)
BEGIN
    ALTER TABLE [ven].[SalesQuoteAcceptances]
        ADD CONSTRAINT [FK_ven_SalesQuoteAcceptances_QuoteId_SalesQuotes]
        FOREIGN KEY ([QuoteId]) REFERENCES [ven].[SalesQuotes] ([SalesQuoteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_QuoteId_SalesQuotes'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders]
        ADD CONSTRAINT [FK_ven_SalesOrders_QuoteId_SalesQuotes]
        FOREIGN KEY ([QuoteId]) REFERENCES [ven].[SalesQuotes] ([SalesQuoteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mor_DelinquencyNoticeEvents_NoticeId_DelinquencyNotices'
)
BEGIN
    ALTER TABLE [mor].[DelinquencyNoticeEvents]
        ADD CONSTRAINT [FK_mor_DelinquencyNoticeEvents_NoticeId_DelinquencyNotices]
        FOREIGN KEY ([NoticeId]) REFERENCES [mor].[DelinquencyNotices] ([DelinquencyNoticeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalTransfers_MovementIdsId_CapitalMovements'
)
BEGIN
    ALTER TABLE [ins].[CapitalTransfers]
        ADD CONSTRAINT [FK_ins_CapitalTransfers_MovementIdsId_CapitalMovements]
        FOREIGN KEY ([MovementIdsId]) REFERENCES [ins].[CapitalMovements] ([CapitalMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalBalances_LastMovementId_CapitalMovements'
)
BEGIN
    ALTER TABLE [ins].[CapitalBalances]
        ADD CONSTRAINT [FK_ins_CapitalBalances_LastMovementId_CapitalMovements]
        FOREIGN KEY ([LastMovementId]) REFERENCES [ins].[CapitalMovements] ([CapitalMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_CapitalReserves_MovementIdsId_CapitalMovements'
)
BEGIN
    ALTER TABLE [ins].[CapitalReserves]
        ADD CONSTRAINT [FK_ins_CapitalReserves_MovementIdsId_CapitalMovements]
        FOREIGN KEY ([MovementIdsId]) REFERENCES [ins].[CapitalMovements] ([CapitalMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_SurplusAllocations_MovementId_CapitalMovements'
)
BEGIN
    ALTER TABLE [ins].[SurplusAllocations]
        ADD CONSTRAINT [FK_ins_SurplusAllocations_MovementId_CapitalMovements]
        FOREIGN KEY ([MovementId]) REFERENCES [ins].[CapitalMovements] ([CapitalMovementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardVouchers_CardPlanId_CardPlans'
)
BEGIN
    ALTER TABLE [tes].[CardVouchers]
        ADD CONSTRAINT [FK_tes_CardVouchers_CardPlanId_CardPlans]
        FOREIGN KEY ([CardPlanId]) REFERENCES [cob].[CardPlans] ([CardPlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardPresentations_CardPlanId_CardPlans'
)
BEGIN
    ALTER TABLE [tes].[CardPresentations]
        ADD CONSTRAINT [FK_tes_CardPresentations_CardPlanId_CardPlans]
        FOREIGN KEY ([CardPlanId]) REFERENCES [cob].[CardPlans] ([CardPlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardSettlements_CardPlanId_CardPlans'
)
BEGIN
    ALTER TABLE [tes].[CardSettlements]
        ADD CONSTRAINT [FK_tes_CardSettlements_CardPlanId_CardPlans]
        FOREIGN KEY ([CardPlanId]) REFERENCES [cob].[CardPlans] ([CardPlanId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesOrders_PosSessionId_PosSessions'
)
BEGIN
    ALTER TABLE [ven].[SalesOrders]
        ADD CONSTRAINT [FK_ven_SalesOrders_PosSessionId_PosSessions]
        FOREIGN KEY ([PosSessionId]) REFERENCES [ven].[PosSessions] ([PosSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_MaintenancePlans_LastGeneratedWorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[MaintenancePlans]
        ADD CONSTRAINT [FK_tec_MaintenancePlans_LastGeneratedWorkOrderId_WorkOrders]
        FOREIGN KEY ([LastGeneratedWorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ProvisioningCommands_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[ProvisioningCommands]
        ADD CONSTRAINT [FK_tec_ProvisioningCommands_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_SyncConflicts_FollowUpWorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[SyncConflicts]
        ADD CONSTRAINT [FK_tec_SyncConflicts_FollowUpWorkOrderId_WorkOrders]
        FOREIGN KEY ([FollowUpWorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_SyncConflicts_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[SyncConflicts]
        ADD CONSTRAINT [FK_tec_SyncConflicts_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneNumbers_ReservedByWorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[PhoneNumbers]
        ADD CONSTRAINT [FK_tec_PhoneNumbers_ReservedByWorkOrderId_WorkOrders]
        FOREIGN KEY ([ReservedByWorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_DamageAssessments_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[DamageAssessments]
        ADD CONSTRAINT [FK_tec_DamageAssessments_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_workOrder_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_workOrder]
        ADD CONSTRAINT [FK_bia_Bi_fact_workOrder_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WaterSamples_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[WaterSamples]
        ADD CONSTRAINT [FK_tec_WaterSamples_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceNetworkConnections_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[ServiceNetworkConnections]
        ADD CONSTRAINT [FK_tec_ServiceNetworkConnections_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneLines_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[PhoneLines]
        ADD CONSTRAINT [FK_tec_PhoneLines_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldEvidence_EntityId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[FieldEvidence] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_FieldEvidence_EntityId_WorkOrders]
        FOREIGN KEY ([EntityId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberPortings_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [tec].[NumberPortings]
        ADD CONSTRAINT [FK_tec_NumberPortings_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_SerialUnitEvents_WorkOrderId_WorkOrders'
)
BEGIN
    ALTER TABLE [stk].[SerialUnitEvents]
        ADD CONSTRAINT [FK_stk_SerialUnitEvents_WorkOrderId_WorkOrders]
        FOREIGN KEY ([WorkOrderId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExtraTasks_SourceRefId_WorkOrders'
)
BEGIN
    ALTER TABLE [sue].[ExtraTasks]
        ADD CONSTRAINT [FK_sue_ExtraTasks_SourceRefId_WorkOrders]
        FOREIGN KEY ([SourceRefId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyResponses_FieldAssignmentId_WorkOrders'
)
BEGIN
    ALTER TABLE [com].[SurveyResponses]
        ADD CONSTRAINT [FK_com_SurveyResponses_FieldAssignmentId_WorkOrders]
        FOREIGN KEY ([FieldAssignmentId]) REFERENCES [tec].[WorkOrders] ([WorkOrderId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_MaintenancePlans_OperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[MaintenancePlans]
        ADD CONSTRAINT [FK_tec_MaintenancePlans_OperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([OperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_IncidentCategories_DefaultOperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[IncidentCategories]
        ADD CONSTRAINT [FK_tec_IncidentCategories_DefaultOperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([DefaultOperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkOrderPrintTemplates_OperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[WorkOrderPrintTemplates] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_WorkOrderPrintTemplates_OperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([OperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ChainedOrderRules_OperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[ChainedOrderRules]
        ADD CONSTRAINT [FK_tec_ChainedOrderRules_OperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([OperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ChainedOrderRules_SourceOperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[ChainedOrderRules]
        ADD CONSTRAINT [FK_tec_ChainedOrderRules_SourceOperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([SourceOperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ChainedOrderRules_TargetOperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[ChainedOrderRules]
        ADD CONSTRAINT [FK_tec_ChainedOrderRules_TargetOperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([TargetOperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FeasibilityRequests_OperationTypeId_WorkOrderOperationTypes'
)
BEGIN
    ALTER TABLE [tec].[FeasibilityRequests]
        ADD CONSTRAINT [FK_tec_FeasibilityRequests_OperationTypeId_WorkOrderOperationTypes]
        FOREIGN KEY ([OperationTypeId]) REFERENCES [tec].[WorkOrderOperationTypes] ([WorkOrderOperationTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_Commitments_BudgetId_Budgets'
)
BEGIN
    ALTER TABLE [con].[Commitments]
        ADD CONSTRAINT [FK_con_Commitments_BudgetId_Budgets]
        FOREIGN KEY ([BudgetId]) REFERENCES [con].[Budgets] ([BudgetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_BudgetLines_BudgetId_Budgets'
)
BEGIN
    ALTER TABLE [con].[BudgetLines]
        ADD CONSTRAINT [FK_con_BudgetLines_BudgetId_Budgets]
        FOREIGN KEY ([BudgetId]) REFERENCES [con].[Budgets] ([BudgetId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_TimePunches_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[TimePunches]
        ADD CONSTRAINT [FK_sue_TimePunches_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldResources_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [tec].[FieldResources]
        ADD CONSTRAINT [FK_tec_FieldResources_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PerformanceReviews_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[PerformanceReviews]
        ADD CONSTRAINT [FK_sue_PerformanceReviews_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_WorkAreas_ManagerEmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[WorkAreas]
        ADD CONSTRAINT [FK_sue_WorkAreas_ManagerEmployeeId_Employees]
        FOREIGN KEY ([ManagerEmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_WorkAccidents_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[WorkAccidents]
        ADD CONSTRAINT [FK_sue_WorkAccidents_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeePayAccounts_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeePayAccounts]
        ADD CONSTRAINT [FK_sue_EmployeePayAccounts_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmploymentStatusPeriods_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmploymentStatusPeriods]
        ADD CONSTRAINT [FK_sue_EmploymentStatusPeriods_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_TreasuryAccountSigners_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [tes].[TreasuryAccountSigners]
        ADD CONSTRAINT [FK_tes_TreasuryAccountSigners_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeDocuments_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeDocuments]
        ADD CONSTRAINT [FK_sue_EmployeeDocuments_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LeaveRequests_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[LeaveRequests]
        ADD CONSTRAINT [FK_sue_LeaveRequests_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryActs_ResponsibleEmployeeId_Employees'
)
BEGIN
    ALTER TABLE [soc].[CemeteryActs]
        ADD CONSTRAINT [FK_soc_CemeteryActs_ResponsibleEmployeeId_Employees]
        FOREIGN KEY ([ResponsibleEmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Terminations_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[Terminations]
        ADD CONSTRAINT [FK_sue_Terminations_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_MeetingParticipants_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [ins].[MeetingParticipants]
        ADD CONSTRAINT [FK_ins_MeetingParticipants_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmploymentCertificates_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmploymentCertificates]
        ADD CONSTRAINT [FK_sue_EmploymentCertificates_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeCostAllocations_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeCostAllocations]
        ADD CONSTRAINT [FK_sue_EmployeeCostAllocations_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeFamilyMembers_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeFamilyMembers]
        ADD CONSTRAINT [FK_sue_EmployeeFamilyMembers_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_IncomeTaxCalculations_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[IncomeTaxCalculations]
        ADD CONSTRAINT [FK_sue_IncomeTaxCalculations_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_IncomeTaxDeclarations_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[IncomeTaxDeclarations]
        ADD CONSTRAINT [FK_sue_IncomeTaxDeclarations_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_DisciplinaryActions_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[DisciplinaryActions]
        ADD CONSTRAINT [FK_sue_DisciplinaryActions_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_AdministrativeInquiries_EmployeeIdsId_Employees'
)
BEGIN
    ALTER TABLE [sue].[AdministrativeInquiries]
        ADD CONSTRAINT [FK_sue_AdministrativeInquiries_EmployeeIdsId_Employees]
        FOREIGN KEY ([EmployeeIdsId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LaborLawsuits_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[LaborLawsuits]
        ADD CONSTRAINT [FK_sue_LaborLawsuits_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeNotes_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeNotes]
        ADD CONSTRAINT [FK_sue_EmployeeNotes_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Novelties_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[Novelties]
        ADD CONSTRAINT [FK_sue_Novelties_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeShiftAssignments_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeShiftAssignments]
        ADD CONSTRAINT [FK_sue_EmployeeShiftAssignments_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayslipNotifications_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[PayslipNotifications]
        ADD CONSTRAINT [FK_sue_PayslipNotifications_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesReps_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [ven].[SalesReps]
        ADD CONSTRAINT [FK_ven_SalesReps_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeAssignments_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeAssignments]
        ADD CONSTRAINT [FK_sue_EmployeeAssignments_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_DeductionPlans_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[DeductionPlans]
        ADD CONSTRAINT [FK_sue_DeductionPlans_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_ExtraTasks_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[ExtraTasks]
        ADD CONSTRAINT [FK_sue_ExtraTasks_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_VacationBalances_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[VacationBalances]
        ADD CONSTRAINT [FK_sue_VacationBalances_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeExtras_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[EmployeeExtras]
        ADD CONSTRAINT [FK_sue_EmployeeExtras_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Crews_EmployeeIdsId_Employees'
)
BEGIN
    ALTER TABLE [tec].[Crews]
        ADD CONSTRAINT [FK_tec_Crews_EmployeeIdsId_Employees]
        FOREIGN KEY ([EmployeeIdsId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_employee_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_employee]
        ADD CONSTRAINT [FK_bia_Bi_dim_employee_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_Drivers_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [soc].[Drivers]
        ADD CONSTRAINT [FK_soc_Drivers_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Objectives_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[Objectives]
        ADD CONSTRAINT [FK_sue_Objectives_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SupervisionLinks_EmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[SupervisionLinks]
        ADD CONSTRAINT [FK_sue_SupervisionLinks_EmployeeId_Employees]
        FOREIGN KEY ([EmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_SupervisionLinks_SupervisorEmployeeId_Employees'
)
BEGIN
    ALTER TABLE [sue].[SupervisionLinks]
        ADD CONSTRAINT [FK_sue_SupervisionLinks_SupervisorEmployeeId_Employees]
        FOREIGN KEY ([SupervisorEmployeeId]) REFERENCES [sue].[Employees] ([EmployeeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_MaintenancePlans_NetworkElementIdsId_NetworkElements'
)
BEGIN
    ALTER TABLE [tec].[MaintenancePlans]
        ADD CONSTRAINT [FK_tec_MaintenancePlans_NetworkElementIdsId_NetworkElements]
        FOREIGN KEY ([NetworkElementIdsId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostAllocationRules_ElementId_NetworkElements'
)
BEGIN
    ALTER TABLE [con].[CostAllocationRules]
        ADD CONSTRAINT [FK_con_CostAllocationRules_ElementId_NetworkElements]
        FOREIGN KEY ([ElementId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_ServiceNetworkConnections_NetworkElementId_NetworkElements'
)
BEGIN
    ALTER TABLE [tec].[ServiceNetworkConnections]
        ADD CONSTRAINT [FK_tec_ServiceNetworkConnections_NetworkElementId_NetworkElements]
        FOREIGN KEY ([NetworkElementId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WaterSamplingPoints_NetworkElementId_NetworkElements'
)
BEGIN
    ALTER TABLE [tec].[WaterSamplingPoints]
        ADD CONSTRAINT [FK_tec_WaterSamplingPoints_NetworkElementId_NetworkElements]
        FOREIGN KEY ([NetworkElementId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneBoxes_NetworkElementId_NetworkElements'
)
BEGIN
    ALTER TABLE [tec].[PhoneBoxes]
        ADD CONSTRAINT [FK_tec_PhoneBoxes_NetworkElementId_NetworkElements]
        FOREIGN KEY ([NetworkElementId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkDevices_NetworkElementId_NetworkElements'
)
BEGIN
    ALTER TABLE [tec].[NetworkDevices] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_NetworkDevices_NetworkElementId_NetworkElements]
        FOREIGN KEY ([NetworkElementId]) REFERENCES [tec].[NetworkElements] ([NetworkElementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhonePorts_DslamId_Dslams'
)
BEGIN
    ALTER TABLE [tec].[PhonePorts]
        ADD CONSTRAINT [FK_tec_PhonePorts_DslamId_Dslams]
        FOREIGN KEY ([DslamId]) REFERENCES [tec].[Dslams] ([DslamId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialRights_UnitId_BurialUnits'
)
BEGIN
    ALTER TABLE [soc].[BurialRights] WITH NOCHECK
        ADD CONSTRAINT [FK_soc_BurialRights_UnitId_BurialUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[BurialUnits] ([BurialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryActs_TargetUnitId_BurialUnits'
)
BEGIN
    ALTER TABLE [soc].[CemeteryActs]
        ADD CONSTRAINT [FK_soc_CemeteryActs_TargetUnitId_BurialUnits]
        FOREIGN KEY ([TargetUnitId]) REFERENCES [soc].[BurialUnits] ([BurialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryActs_UnitId_BurialUnits'
)
BEGIN
    ALTER TABLE [soc].[CemeteryActs]
        ADD CONSTRAINT [FK_soc_CemeteryActs_UnitId_BurialUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[BurialUnits] ([BurialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BurialOccupancies_UnitId_BurialUnits'
)
BEGIN
    ALTER TABLE [soc].[BurialOccupancies]
        ADD CONSTRAINT [FK_soc_BurialOccupancies_UnitId_BurialUnits]
        FOREIGN KEY ([UnitId]) REFERENCES [soc].[BurialUnits] ([BurialUnitId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_DirectDebitBatchId_DirectDebitBatches'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_DirectDebitBatchId_DirectDebitBatches]
        FOREIGN KEY ([DirectDebitBatchId]) REFERENCES [cob].[DirectDebitBatches] ([DirectDebitBatcheId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCircularRuns_CircularId_CrmCirculars'
)
BEGIN
    ALTER TABLE [crm].[CrmCircularRuns]
        ADD CONSTRAINT [FK_crm_CrmCircularRuns_CircularId_CrmCirculars]
        FOREIGN KEY ([CircularId]) REFERENCES [crm].[CrmCirculars] ([CrmCircularId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_nfr_DataCatalogEntries_PurposesId_ProcessingActivities'
)
BEGIN
    ALTER TABLE [nfr].[DataCatalogEntries]
        ADD CONSTRAINT [FK_nfr_DataCatalogEntries_PurposesId_ProcessingActivities]
        FOREIGN KEY ([PurposesId]) REFERENCES [nfr].[ProcessingActivities] ([ProcessingActivityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleUsages_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [soc].[VehicleUsages]
        ADD CONSTRAINT [FK_soc_VehicleUsages_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_WorkAreas_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [sue].[WorkAreas]
        ADD CONSTRAINT [FK_sue_WorkAreas_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerAccounts_AllowedCostCenterIdsId_CostCenters'
)
BEGIN
    ALTER TABLE [con].[LedgerAccounts]
        ADD CONSTRAINT [FK_con_LedgerAccounts_AllowedCostCenterIdsId_CostCenters]
        FOREIGN KEY ([AllowedCostCenterIdsId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_costCenter_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_costCenter]
        ADD CONSTRAINT [FK_bia_Bi_dim_costCenter_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostCenterGroups_CostCenterIdsId_CostCenters'
)
BEGIN
    ALTER TABLE [con].[CostCenterGroups] WITH NOCHECK
        ADD CONSTRAINT [FK_con_CostCenterGroups_CostCenterIdsId_CostCenters]
        FOREIGN KEY ([CostCenterIdsId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_ExpenseUnits_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [stk].[ExpenseUnits]
        ADD CONSTRAINT [FK_stk_ExpenseUnits_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeCostAllocations_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [sue].[EmployeeCostAllocations]
        ADD CONSTRAINT [FK_sue_EmployeeCostAllocations_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_FleetVehicles_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [soc].[FleetVehicles]
        ADD CONSTRAINT [FK_soc_FleetVehicles_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerBalances_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [con].[LedgerBalances]
        ADD CONSTRAINT [FK_con_LedgerBalances_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_BudgetLines_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [con].[BudgetLines]
        ADD CONSTRAINT [FK_con_BudgetLines_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_PurchaseForecasts_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [cmp].[PurchaseForecasts]
        ADD CONSTRAINT [FK_cmp_PurchaseForecasts_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Works_CostCenterId_CostCenters'
)
BEGIN
    ALTER TABLE [tec].[Works]
        ADD CONSTRAINT [FK_tec_Works_CostCenterId_CostCenters]
        FOREIGN KEY ([CostCenterId]) REFERENCES [con].[CostCenters] ([CostCenterId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_StaticQrCodeId_StaticQrCodes'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CashRegisters_StaticQrCodeId_StaticQrCodes]
        FOREIGN KEY ([StaticQrCodeId]) REFERENCES [cob].[StaticQrCodes] ([StaticQrCodeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneExchanges_NetworkDeviceId_NetworkDevices'
)
BEGIN
    ALTER TABLE [tec].[PhoneExchanges]
        ADD CONSTRAINT [FK_tec_PhoneExchanges_NetworkDeviceId_NetworkDevices]
        FOREIGN KEY ([NetworkDeviceId]) REFERENCES [tec].[NetworkDevices] ([NetworkDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NetworkElements_NetworkDeviceId_NetworkDevices'
)
BEGIN
    ALTER TABLE [tec].[NetworkElements] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_NetworkElements_NetworkDeviceId_NetworkDevices]
        FOREIGN KEY ([NetworkDeviceId]) REFERENCES [tec].[NetworkDevices] ([NetworkDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Dslams_NetworkDeviceId_NetworkDevices'
)
BEGIN
    ALTER TABLE [tec].[Dslams]
        ADD CONSTRAINT [FK_tec_Dslams_NetworkDeviceId_NetworkDevices]
        FOREIGN KEY ([NetworkDeviceId]) REFERENCES [tec].[NetworkDevices] ([NetworkDeviceId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_dim_crew_CrewId_Crews'
)
BEGIN
    ALTER TABLE [bia].[Bi_dim_crew]
        ADD CONSTRAINT [FK_bia_Bi_dim_crew_CrewId_Crews]
        FOREIGN KEY ([CrewId]) REFERENCES [tec].[Crews] ([CrewId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_CrewSettlements_CrewId_Crews'
)
BEGIN
    ALTER TABLE [stk].[CrewSettlements]
        ADD CONSTRAINT [FK_stk_CrewSettlements_CrewId_Crews]
        FOREIGN KEY ([CrewId]) REFERENCES [tec].[Crews] ([CrewId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_Visits_AssignedCrewId_Crews'
)
BEGIN
    ALTER TABLE [tec].[Visits]
        ADD CONSTRAINT [FK_tec_Visits_AssignedCrewId_Crews]
        FOREIGN KEY ([AssignedCrewId]) REFERENCES [tec].[Crews] ([CrewId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_PaymentTenders_CashOperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[PaymentTenders]
        ADD CONSTRAINT [FK_cob_PaymentTenders_CashOperationId_CashOperations]
        FOREIGN KEY ([CashOperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencyDebtExports_OperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[AgencyDebtExports]
        ADD CONSTRAINT [FK_cob_AgencyDebtExports_OperationId_CashOperations]
        FOREIGN KEY ([OperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_GatewayTransactions_CashOperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[GatewayTransactions]
        ADD CONSTRAINT [FK_cob_GatewayTransactions_CashOperationId_CashOperations]
        FOREIGN KEY ([CashOperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlements_CashOperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlements]
        ADD CONSTRAINT [FK_cob_AgencySettlements_CashOperationId_CashOperations]
        FOREIGN KEY ([CashOperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyCollections_CashOperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyCollections]
        ADD CONSTRAINT [FK_cob_ThirdPartyCollections_CashOperationId_CashOperations]
        FOREIGN KEY ([CashOperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_payment_PaymentId_CashOperations'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_payment]
        ADD CONSTRAINT [FK_bia_Bi_fact_payment_PaymentId_CashOperations]
        FOREIGN KEY ([PaymentId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Receipts_CashOperationId_CashOperations'
)
BEGIN
    ALTER TABLE [cob].[Receipts] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_Receipts_CashOperationId_CashOperations]
        FOREIGN KEY ([CashOperationId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_allocation_PaymentId_CashOperations'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_allocation]
        ADD CONSTRAINT [FK_bia_Bi_fact_allocation_PaymentId_CashOperations]
        FOREIGN KEY ([PaymentId]) REFERENCES [cob].[CashOperations] ([CashOperationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_LotTypes_PurchaseReceiptId_SupplierReceipts'
)
BEGIN
    ALTER TABLE [stk].[LotTypes]
        ADD CONSTRAINT [FK_stk_LotTypes_PurchaseReceiptId_SupplierReceipts]
        FOREIGN KEY ([PurchaseReceiptId]) REFERENCES [cmp].[SupplierReceipts] ([SupplierReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_MatchExceptions_ReceiptId_SupplierReceipts'
)
BEGIN
    ALTER TABLE [cmp].[MatchExceptions]
        ADD CONSTRAINT [FK_cmp_MatchExceptions_ReceiptId_SupplierReceipts]
        FOREIGN KEY ([ReceiptId]) REFERENCES [cmp].[SupplierReceipts] ([SupplierReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Lots_PurchaseReceiptId_SupplierReceipts'
)
BEGIN
    ALTER TABLE [stk].[Lots]
        ADD CONSTRAINT [FK_stk_Lots_PurchaseReceiptId_SupplierReceipts]
        FOREIGN KEY ([PurchaseReceiptId]) REFERENCES [cmp].[SupplierReceipts] ([SupplierReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_OwnChecks_CheckbookId_Checkbooks'
)
BEGIN
    ALTER TABLE [tes].[OwnChecks]
        ADD CONSTRAINT [FK_tes_OwnChecks_CheckbookId_Checkbooks]
        FOREIGN KEY ([CheckbookId]) REFERENCES [tes].[Checkbooks] ([CheckbookId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReceivedWithholdings_WithholdingSufferedTypeId_WithholdingSufferedTypes'
)
BEGIN
    ALTER TABLE [tes].[ReceivedWithholdings]
        ADD CONSTRAINT [FK_tes_ReceivedWithholdings_WithholdingSufferedTypeId_WithholdingSufferedTypes]
        FOREIGN KEY ([WithholdingSufferedTypeId]) REFERENCES [fis].[WithholdingSufferedTypes] ([WithholdingSufferedTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureEvidences_SignatureParticipantId_SignatureParticipants'
)
BEGIN
    ALTER TABLE [wfl].[SignatureEvidences]
        ADD CONSTRAINT [FK_wfl_SignatureEvidences_SignatureParticipantId_SignatureParticipants]
        FOREIGN KEY ([SignatureParticipantId]) REFERENCES [wfl].[SignatureParticipants] ([SignatureParticipantId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CardVouchers_SettlementId_CardSettlements'
)
BEGIN
    ALTER TABLE [tes].[CardVouchers] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_CardVouchers_SettlementId_CardSettlements]
        FOREIGN KEY ([SettlementId]) REFERENCES [tes].[CardSettlements] ([CardSettlementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_Chargebacks_ReceiptId_Receipts'
)
BEGIN
    ALTER TABLE [cob].[Chargebacks]
        ADD CONSTRAINT [FK_cob_Chargebacks_ReceiptId_Receipts]
        FOREIGN KEY ([ReceiptId]) REFERENCES [cob].[Receipts] ([ReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AgencySettlementLines_ReceiptId_Receipts'
)
BEGIN
    ALTER TABLE [cob].[AgencySettlementLines]
        ADD CONSTRAINT [FK_cob_AgencySettlementLines_ReceiptId_Receipts]
        FOREIGN KEY ([ReceiptId]) REFERENCES [cob].[Receipts] ([ReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_ThirdPartyCollections_ReceiptId_Receipts'
)
BEGIN
    ALTER TABLE [cob].[ThirdPartyCollections]
        ADD CONSTRAINT [FK_cob_ThirdPartyCollections_ReceiptId_Receipts]
        FOREIGN KEY ([ReceiptId]) REFERENCES [cob].[Receipts] ([ReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_payment_ReceiptId_Receipts'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_payment]
        ADD CONSTRAINT [FK_bia_Bi_fact_payment_ReceiptId_Receipts]
        FOREIGN KEY ([ReceiptId]) REFERENCES [cob].[Receipts] ([ReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashOperations_ReceiptIdsId_Receipts'
)
BEGIN
    ALTER TABLE [cob].[CashOperations] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CashOperations_ReceiptIdsId_Receipts]
        FOREIGN KEY ([ReceiptIdsId]) REFERENCES [cob].[Receipts] ([ReceiptId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgressMaterials_ProgressId_HousingProgress'
)
BEGIN
    ALTER TABLE [soc].[HousingProgressMaterials]
        ADD CONSTRAINT [FK_soc_HousingProgressMaterials_ProgressId_HousingProgress]
        FOREIGN KEY ([ProgressId]) REFERENCES [soc].[HousingProgress] ([HousingProgresId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_ChartOfAccounts_ScenarioId_SimulationScenarios'
)
BEGIN
    ALTER TABLE [con].[ChartOfAccounts] WITH NOCHECK
        ADD CONSTRAINT [FK_con_ChartOfAccounts_ScenarioId_SimulationScenarios]
        FOREIGN KEY ([ScenarioId]) REFERENCES [con].[SimulationScenarios] ([SimulationScenarioId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_CostDistributionRuns_ScenarioId_SimulationScenarios'
)
BEGIN
    ALTER TABLE [con].[CostDistributionRuns]
        ADD CONSTRAINT [FK_con_CostDistributionRuns_ScenarioId_SimulationScenarios]
        FOREIGN KEY ([ScenarioId]) REFERENCES [con].[SimulationScenarios] ([SimulationScenarioId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_IndicatorSnapshots_ScenarioId_SimulationScenarios'
)
BEGIN
    ALTER TABLE [bia].[IndicatorSnapshots]
        ADD CONSTRAINT [FK_bia_IndicatorSnapshots_ScenarioId_SimulationScenarios]
        FOREIGN KEY ([ScenarioId]) REFERENCES [con].[SimulationScenarios] ([SimulationScenarioId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleUsages_DriverId_Drivers'
)
BEGIN
    ALTER TABLE [soc].[VehicleUsages]
        ADD CONSTRAINT [FK_soc_VehicleUsages_DriverId_Drivers]
        FOREIGN KEY ([DriverId]) REFERENCES [soc].[Drivers] ([DriverId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_TripSettlements_DriverId_Drivers'
)
BEGIN
    ALTER TABLE [soc].[TripSettlements]
        ADD CONSTRAINT [FK_soc_TripSettlements_DriverId_Drivers]
        FOREIGN KEY ([DriverId]) REFERENCES [soc].[Drivers] ([DriverId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_LedgerProjections_SourceLineId_JournalLines'
)
BEGIN
    ALTER TABLE [con].[LedgerProjections]
        ADD CONSTRAINT [FK_con_LedgerProjections_SourceLineId_JournalLines]
        FOREIGN KEY ([SourceLineId]) REFERENCES [con].[JournalLines] ([JournalLineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_journalLine_JournalLineId_JournalLines'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_journalLine]
        ADD CONSTRAINT [FK_bia_Bi_fact_journalLine_JournalLineId_JournalLines]
        FOREIGN KEY ([JournalLineId]) REFERENCES [con].[JournalLines] ([JournalLineId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_HousingProgress_CertificateId_HousingCertificates'
)
BEGIN
    ALTER TABLE [soc].[HousingProgress]
        ADD CONSTRAINT [FK_soc_HousingProgress_CertificateId_HousingCertificates]
        FOREIGN KEY ([CertificateId]) REFERENCES [soc].[HousingCertificates] ([HousingCertificateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyResponses_InvitationId_SurveyInvitations'
)
BEGIN
    ALTER TABLE [com].[SurveyResponses]
        ADD CONSTRAINT [FK_com_SurveyResponses_InvitationId_SurveyInvitations]
        FOREIGN KEY ([InvitationId]) REFERENCES [com].[SurveyInvitations] ([SurveyInvitationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_PlatformNotices_SurveyId_Surveys'
)
BEGIN
    ALTER TABLE [com].[PlatformNotices]
        ADD CONSTRAINT [FK_com_PlatformNotices_SurveyId_Surveys]
        FOREIGN KEY ([SurveyId]) REFERENCES [com].[Surveys] ([SurveyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyResponses_SurveyId_Surveys'
)
BEGIN
    ALTER TABLE [com].[SurveyResponses]
        ADD CONSTRAINT [FK_com_SurveyResponses_SurveyId_Surveys]
        FOREIGN KEY ([SurveyId]) REFERENCES [com].[Surveys] ([SurveyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_SurveyInvitations_SurveyId_Surveys'
)
BEGIN
    ALTER TABLE [com].[SurveyInvitations]
        ADD CONSTRAINT [FK_com_SurveyInvitations_SurveyId_Surveys]
        FOREIGN KEY ([SurveyId]) REFERENCES [com].[Surveys] ([SurveyId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DonationCampaigns_AgreementId_ProviderAgreements'
)
BEGIN
    ALTER TABLE [soc].[DonationCampaigns]
        ADD CONSTRAINT [FK_soc_DonationCampaigns_AgreementId_ProviderAgreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [soc].[ProviderAgreements] ([ProviderAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BloodCoverageRequests_AgreementId_ProviderAgreements'
)
BEGIN
    ALTER TABLE [soc].[BloodCoverageRequests]
        ADD CONSTRAINT [FK_soc_BloodCoverageRequests_AgreementId_ProviderAgreements]
        FOREIGN KEY ([AgreementId]) REFERENCES [soc].[ProviderAgreements] ([ProviderAgreementId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationIssues_StagingRecordId_MigStagingRecords'
)
BEGIN
    ALTER TABLE [mig].[MigrationIssues] WITH NOCHECK
        ADD CONSTRAINT [FK_mig_MigrationIssues_StagingRecordId_MigStagingRecords]
        FOREIGN KEY ([StagingRecordId]) REFERENCES [mig].[MigStagingRecords] ([MigStagingRecordId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingsApplied_WithholdingTypeId_WithholdingTypes'
)
BEGIN
    ALTER TABLE [fis].[WithholdingsApplied]
        ADD CONSTRAINT [FK_fis_WithholdingsApplied_WithholdingTypeId_WithholdingTypes]
        FOREIGN KEY ([WithholdingTypeId]) REFERENCES [fis].[WithholdingTypes] ([WithholdingTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingScales_WithholdingTypeId_WithholdingTypes'
)
BEGIN
    ALTER TABLE [fis].[WithholdingScales]
        ADD CONSTRAINT [FK_fis_WithholdingScales_WithholdingTypeId_WithholdingTypes]
        FOREIGN KEY ([WithholdingTypeId]) REFERENCES [fis].[WithholdingTypes] ([WithholdingTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_WithholdingAssignments_WithholdingTypeId_WithholdingTypes'
)
BEGIN
    ALTER TABLE [fis].[WithholdingAssignments]
        ADD CONSTRAINT [FK_fis_WithholdingAssignments_WithholdingTypeId_WithholdingTypes]
        FOREIGN KEY ([WithholdingTypeId]) REFERENCES [fis].[WithholdingTypes] ([WithholdingTypeId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_BundleSubscriptionId_BundleSubscriptions'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts] WITH NOCHECK
        ADD CONSTRAINT [FK_cat_ServiceContracts_BundleSubscriptionId_BundleSubscriptions]
        FOREIGN KEY ([BundleSubscriptionId]) REFERENCES [cat].[BundleSubscriptions] ([BundleSubscriptionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_IncomeTaxCalculations_PayslipId_Payslips'
)
BEGIN
    ALTER TABLE [sue].[IncomeTaxCalculations] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_IncomeTaxCalculations_PayslipId_Payslips]
        FOREIGN KEY ([PayslipId]) REFERENCES [sue].[Payslips] ([PayslipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Novelties_SettledPayslipId_Payslips'
)
BEGIN
    ALTER TABLE [sue].[Novelties] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_Novelties_SettledPayslipId_Payslips]
        FOREIGN KEY ([SettledPayslipId]) REFERENCES [sue].[Payslips] ([PayslipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayslipNotifications_PayslipId_Payslips'
)
BEGIN
    ALTER TABLE [sue].[PayslipNotifications]
        ADD CONSTRAINT [FK_sue_PayslipNotifications_PayslipId_Payslips]
        FOREIGN KEY ([PayslipId]) REFERENCES [sue].[Payslips] ([PayslipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_Bi_fact_payroll_PayslipId_Payslips'
)
BEGIN
    ALTER TABLE [bia].[Bi_fact_payroll]
        ADD CONSTRAINT [FK_bia_Bi_fact_payroll_PayslipId_Payslips]
        FOREIGN KEY ([PayslipId]) REFERENCES [sue].[Payslips] ([PayslipId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_Terminations_FinalPayrollRunId_PayrollRuns'
)
BEGIN
    ALTER TABLE [sue].[Terminations]
        ADD CONSTRAINT [FK_sue_Terminations_FinalPayrollRunId_PayrollRuns]
        FOREIGN KEY ([FinalPayrollRunId]) REFERENCES [sue].[PayrollRuns] ([PayrollRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_PayrollPaymentBatches_PayrollRunId_PayrollRuns'
)
BEGIN
    ALTER TABLE [tes].[PayrollPaymentBatches] WITH NOCHECK
        ADD CONSTRAINT [FK_tes_PayrollPaymentBatches_PayrollRunId_PayrollRuns]
        FOREIGN KEY ([PayrollRunId]) REFERENCES [sue].[PayrollRuns] ([PayrollRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_PayrollPaymentRequests_PayrollRunId_PayrollRuns'
)
BEGIN
    ALTER TABLE [sue].[PayrollPaymentRequests] WITH NOCHECK
        ADD CONSTRAINT [FK_sue_PayrollPaymentRequests_PayrollRunId_PayrollRuns]
        FOREIGN KEY ([PayrollRunId]) REFERENCES [sue].[PayrollRuns] ([PayrollRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_StatutoryFilings_PayrollRunIdsId_PayrollRuns'
)
BEGIN
    ALTER TABLE [sue].[StatutoryFilings]
        ADD CONSTRAINT [FK_sue_StatutoryFilings_PayrollRunIdsId_PayrollRuns]
        FOREIGN KEY ([PayrollRunIdsId]) REFERENCES [sue].[PayrollRuns] ([PayrollRunId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_InjectionBalances_DistributedGenerationContractId_DistributedGenerationContracts'
)
BEGIN
    ALTER TABLE [med].[InjectionBalances]
        ADD CONSTRAINT [FK_med_InjectionBalances_DistributedGenerationContractId_DistributedGenerationContracts]
        FOREIGN KEY ([DistributedGenerationContractId]) REFERENCES [med].[DistributedGenerationContracts] ([DistributedGenerationContractId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_DependentEvents_BeneficiaryId_ServiceBeneficiaries'
)
BEGIN
    ALTER TABLE [soc].[DependentEvents]
        ADD CONSTRAINT [FK_soc_DependentEvents_BeneficiaryId_ServiceBeneficiaries]
        FOREIGN KEY ([BeneficiaryId]) REFERENCES [soc].[ServiceBeneficiaries] ([ServiceBeneficiaryId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_TreasuryHandovers_CashSessionIdsId_CashSessions'
)
BEGIN
    ALTER TABLE [cob].[TreasuryHandovers] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_TreasuryHandovers_CashSessionIdsId_CashSessions]
        FOREIGN KEY ([CashSessionIdsId]) REFERENCES [cob].[CashSessions] ([CashSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_TreasuryHandovers_SessionIdsId_CashSessions'
)
BEGIN
    ALTER TABLE [cob].[TreasuryHandovers]
        ADD CONSTRAINT [FK_cob_TreasuryHandovers_SessionIdsId_CashSessions]
        FOREIGN KEY ([SessionIdsId]) REFERENCES [cob].[CashSessions] ([CashSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectorSettlements_CashSessionId_CashSessions'
)
BEGIN
    ALTER TABLE [cob].[CollectorSettlements]
        ADD CONSTRAINT [FK_cob_CollectorSettlements_CashSessionId_CashSessions]
        FOREIGN KEY ([CashSessionId]) REFERENCES [cob].[CashSessions] ([CashSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosSessions_CashSessionId_CashSessions'
)
BEGIN
    ALTER TABLE [ven].[PosSessions]
        ADD CONSTRAINT [FK_ven_PosSessions_CashSessionId_CashSessions]
        FOREIGN KEY ([CashSessionId]) REFERENCES [cob].[CashSessions] ([CashSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashOperations_CashSessionId_CashSessions'
)
BEGIN
    ALTER TABLE [cob].[CashOperations]
        ADD CONSTRAINT [FK_cob_CashOperations_CashSessionId_CashSessions]
        FOREIGN KEY ([CashSessionId]) REFERENCES [cob].[CashSessions] ([CashSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_CashRemittances_CashSessionId_CashSessions'
)
BEGIN
    ALTER TABLE [tes].[CashRemittances]
        ADD CONSTRAINT [FK_tes_CashRemittances_CashSessionId_CashSessions]
        FOREIGN KEY ([CashSessionId]) REFERENCES [cob].[CashSessions] ([CashSessionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_AccountStatements_PaymentCouponId_PaymentCoupons'
)
BEGIN
    ALTER TABLE [cob].[AccountStatements] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_AccountStatements_PaymentCouponId_PaymentCoupons]
        FOREIGN KEY ([PaymentCouponId]) REFERENCES [cob].[PaymentCoupons] ([PaymentCouponId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectionRounds_CollectorId_Collectors'
)
BEGIN
    ALTER TABLE [cob].[CollectionRounds]
        ADD CONSTRAINT [FK_cob_CollectionRounds_CollectorId_Collectors]
        FOREIGN KEY ([CollectorId]) REFERENCES [cob].[Collectors] ([CollectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CollectorSettlements_CollectorId_Collectors'
)
BEGIN
    ALTER TABLE [cob].[CollectorSettlements]
        ADD CONSTRAINT [FK_cob_CollectorSettlements_CollectorId_Collectors]
        FOREIGN KEY ([CollectorId]) REFERENCES [cob].[Collectors] ([CollectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_CashRegisters_CollectorId_Collectors'
)
BEGIN
    ALTER TABLE [cob].[CashRegisters] WITH NOCHECK
        ADD CONSTRAINT [FK_cob_CashRegisters_CollectorId_Collectors]
        FOREIGN KEY ([CollectorId]) REFERENCES [cob].[Collectors] ([CollectorId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_SignatureRequests_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[SignatureRequests]
        ADD CONSTRAINT [FK_wfl_SignatureRequests_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_TaxExemptions_EvidenceId_Documents'
)
BEGIN
    ALTER TABLE [fis].[TaxExemptions]
        ADD CONSTRAINT [FK_fis_TaxExemptions_EvidenceId_Documents]
        FOREIGN KEY ([EvidenceId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_Dossiers_CoverDocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[Dossiers]
        ADD CONSTRAINT [FK_wfl_Dossiers_CoverDocumentId_Documents]
        FOREIGN KEY ([CoverDocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_VehicleDocuments_DocumentRefId_Documents'
)
BEGIN
    ALTER TABLE [soc].[VehicleDocuments]
        ADD CONSTRAINT [FK_soc_VehicleDocuments_DocumentRefId_Documents]
        FOREIGN KEY ([DocumentRefId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_DeclaredAffidavitRefId_Documents'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts]
        ADD CONSTRAINT [FK_cat_ServiceContracts_DeclaredAffidavitRefId_Documents]
        FOREIGN KEY ([DeclaredAffidavitRefId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentAccessLogs_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[DocumentAccessLogs]
        ADD CONSTRAINT [FK_wfl_DocumentAccessLogs_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ApprovalDecisions_EvidenceDocumentIdsId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[ApprovalDecisions]
        ADD CONSTRAINT [FK_wfl_ApprovalDecisions_EvidenceDocumentIdsId_Documents]
        FOREIGN KEY ([EvidenceDocumentIdsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_ShareLinks_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[ShareLinks]
        ADD CONSTRAINT [FK_wfl_ShareLinks_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_EmployeeDocuments_DocumentRefId_Documents'
)
BEGIN
    ALTER TABLE [sue].[EmployeeDocuments]
        ADD CONSTRAINT [FK_sue_EmployeeDocuments_DocumentRefId_Documents]
        FOREIGN KEY ([DocumentRefId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_mig_MigrationProjects_AcceptanceActId_Documents'
)
BEGIN
    ALTER TABLE [mig].[MigrationProjects]
        ADD CONSTRAINT [FK_mig_MigrationProjects_AcceptanceActId_Documents]
        FOREIGN KEY ([AcceptanceActId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_TaskComments_DocumentIdsId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[TaskComments]
        ADD CONSTRAINT [FK_wfl_TaskComments_DocumentIdsId_Documents]
        FOREIGN KEY ([DocumentIdsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_BenefitGroupMembers_EvidenceDocIdsId_Documents'
)
BEGIN
    ALTER TABLE [tar].[BenefitGroupMembers]
        ADD CONSTRAINT [FK_tar_BenefitGroupMembers_EvidenceDocIdsId_Documents]
        FOREIGN KEY ([EvidenceDocIdsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WaterSamples_LabReportDocumentId_Documents'
)
BEGIN
    ALTER TABLE [tec].[WaterSamples]
        ADD CONSTRAINT [FK_tec_WaterSamples_LabReportDocumentId_Documents]
        FOREIGN KEY ([LabReportDocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentVersions_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[DocumentVersions]
        ADD CONSTRAINT [FK_wfl_DocumentVersions_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_OwnTaxObligations_EvidenceIdsId_Documents'
)
BEGIN
    ALTER TABLE [fis].[OwnTaxObligations]
        ADD CONSTRAINT [FK_fis_OwnTaxObligations_EvidenceIdsId_Documents]
        FOREIGN KEY ([EvidenceIdsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_Meters_DocumentsId_Documents'
)
BEGIN
    ALTER TABLE [med].[Meters]
        ADD CONSTRAINT [FK_med_Meters_DocumentsId_Documents]
        FOREIGN KEY ([DocumentsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_sue_LaborLawsuits_DossierId_Documents'
)
BEGIN
    ALTER TABLE [sue].[LaborLawsuits]
        ADD CONSTRAINT [FK_sue_LaborLawsuits_DossierId_Documents]
        FOREIGN KEY ([DossierId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_BenefitRequests_DocumentsId_Documents'
)
BEGIN
    ALTER TABLE [soc].[BenefitRequests]
        ADD CONSTRAINT [FK_soc_BenefitRequests_DocumentsId_Documents]
        FOREIGN KEY ([DocumentsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CemeteryRegulations_DocumentRefId_Documents'
)
BEGIN
    ALTER TABLE [soc].[CemeteryRegulations]
        ADD CONSTRAINT [FK_soc_CemeteryRegulations_DocumentRefId_Documents]
        FOREIGN KEY ([DocumentRefId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fac_InvoiceAnnulmentRequests_EvidenceIdsId_Documents'
)
BEGIN
    ALTER TABLE [fac].[InvoiceAnnulmentRequests]
        ADD CONSTRAINT [FK_fac_InvoiceAnnulmentRequests_EvidenceIdsId_Documents]
        FOREIGN KEY ([EvidenceIdsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_con_JournalEntries_AttachmentsId_Documents'
)
BEGIN
    ALTER TABLE [con].[JournalEntries]
        ADD CONSTRAINT [FK_con_JournalEntries_AttachmentsId_Documents]
        FOREIGN KEY ([AttachmentsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_CoveragePlans_RegulationDocumentId_Documents'
)
BEGIN
    ALTER TABLE [soc].[CoveragePlans]
        ADD CONSTRAINT [FK_soc_CoveragePlans_RegulationDocumentId_Documents]
        FOREIGN KEY ([RegulationDocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_DocumentLinks_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[DocumentLinks]
        ADD CONSTRAINT [FK_wfl_DocumentLinks_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_SerialUnitEvents_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [stk].[SerialUnitEvents]
        ADD CONSTRAINT [FK_stk_SerialUnitEvents_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_FormSubmissions_DocumentIdsId_Documents'
)
BEGIN
    ALTER TABLE [wfl].[FormSubmissions]
        ADD CONSTRAINT [FK_wfl_FormSubmissions_DocumentIdsId_Documents]
        FOREIGN KEY ([DocumentIdsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierLedgerEntries_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [cmp].[SupplierLedgerEntries]
        ADD CONSTRAINT [FK_cmp_SupplierLedgerEntries_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCircularRuns_LabelsDocumentId_Documents'
)
BEGIN
    ALTER TABLE [crm].[CrmCircularRuns]
        ADD CONSTRAINT [FK_crm_CrmCircularRuns_LabelsDocumentId_Documents]
        FOREIGN KEY ([LabelsDocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmCircularRuns_PrintDocumentId_Documents'
)
BEGIN
    ALTER TABLE [crm].[CrmCircularRuns]
        ADD CONSTRAINT [FK_crm_CrmCircularRuns_PrintDocumentId_Documents]
        FOREIGN KEY ([PrintDocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_soc_ProviderAgreements_DocumentRefId_Documents'
)
BEGIN
    ALTER TABLE [soc].[ProviderAgreements]
        ADD CONSTRAINT [FK_soc_ProviderAgreements_DocumentRefId_Documents]
        FOREIGN KEY ([DocumentRefId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_med_DistributedGenerationContracts_DocumentsId_Documents'
)
BEGIN
    ALTER TABLE [med].[DistributedGenerationContracts]
        ADD CONSTRAINT [FK_med_DistributedGenerationContracts_DocumentsId_Documents]
        FOREIGN KEY ([DocumentsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tar_SubsidyEnrollments_EvidenceDocIdsId_Documents'
)
BEGIN
    ALTER TABLE [tar].[SubsidyEnrollments]
        ADD CONSTRAINT [FK_tar_SubsidyEnrollments_EvidenceDocIdsId_Documents]
        FOREIGN KEY ([EvidenceDocIdsId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Revaluations_DocumentId_Documents'
)
BEGIN
    ALTER TABLE [stk].[Revaluations]
        ADD CONSTRAINT [FK_stk_Revaluations_DocumentId_Documents]
        FOREIGN KEY ([DocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_fis_DeterminedRates_EvidenceId_Documents'
)
BEGIN
    ALTER TABLE [fis].[DeterminedRates]
        ADD CONSTRAINT [FK_fis_DeterminedRates_EvidenceId_Documents]
        FOREIGN KEY ([EvidenceId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ContractDeclaredAppliances_DeclarationDocId_Documents'
)
BEGIN
    ALTER TABLE [cat].[ContractDeclaredAppliances]
        ADD CONSTRAINT [FK_cat_ContractDeclaredAppliances_DeclarationDocId_Documents]
        FOREIGN KEY ([DeclarationDocId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_PhysicalCounts_AdjustmentDocumentId_Documents'
)
BEGIN
    ALTER TABLE [stk].[PhysicalCounts]
        ADD CONSTRAINT [FK_stk_PhysicalCounts_AdjustmentDocumentId_Documents]
        FOREIGN KEY ([AdjustmentDocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cob_RefundCases_CorrectiveDocumentId_Documents'
)
BEGIN
    ALTER TABLE [cob].[RefundCases]
        ADD CONSTRAINT [FK_cob_RefundCases_CorrectiveDocumentId_Documents]
        FOREIGN KEY ([CorrectiveDocumentId]) REFERENCES [wfl].[Documents] ([DocumentId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_crm_CrmActivityOccurrences_ActivityId_CrmActivities'
)
BEGIN
    ALTER TABLE [crm].[CrmActivityOccurrences]
        ADD CONSTRAINT [FK_crm_CrmActivityOccurrences_ActivityId_CrmActivities]
        FOREIGN KEY ([ActivityId]) REFERENCES [crm].[CrmActivities] ([CrmActivityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_Resolutions_MinuteId_Minutes'
)
BEGIN
    ALTER TABLE [ins].[Resolutions]
        ADD CONSTRAINT [FK_ins_Resolutions_MinuteId_Minutes]
        FOREIGN KEY ([MinuteId]) REFERENCES [ins].[Minutes] ([MinuteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ins_AssociateMemberships_ExitMinuteId_Minutes'
)
BEGIN
    ALTER TABLE [ins].[AssociateMemberships]
        ADD CONSTRAINT [FK_ins_AssociateMemberships_ExitMinuteId_Minutes]
        FOREIGN KEY ([ExitMinuteId]) REFERENCES [ins].[Minutes] ([MinuteId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneBoxes_FrameId_PhoneFrames'
)
BEGIN
    ALTER TABLE [tec].[PhoneBoxes]
        ADD CONSTRAINT [FK_tec_PhoneBoxes_FrameId_PhoneFrames]
        FOREIGN KEY ([FrameId]) REFERENCES [tec].[PhoneFrames] ([PhoneFrameId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneFrameGroups_FrameId_PhoneFrames'
)
BEGIN
    ALTER TABLE [tec].[PhoneFrameGroups]
        ADD CONSTRAINT [FK_tec_PhoneFrameGroups_FrameId_PhoneFrames]
        FOREIGN KEY ([FrameId]) REFERENCES [tec].[PhoneFrames] ([PhoneFrameId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStripPositions_DslamPortId_PhonePorts'
)
BEGIN
    ALTER TABLE [tec].[PhoneStripPositions]
        ADD CONSTRAINT [FK_tec_PhoneStripPositions_DslamPortId_PhonePorts]
        FOREIGN KEY ([DslamPortId]) REFERENCES [tec].[PhonePorts] ([PhonePortId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStripPositions_ExchangePortId_PhonePorts'
)
BEGIN
    ALTER TABLE [tec].[PhoneStripPositions]
        ADD CONSTRAINT [FK_tec_PhoneStripPositions_ExchangePortId_PhonePorts]
        FOREIGN KEY ([ExchangePortId]) REFERENCES [tec].[PhonePorts] ([PhonePortId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_NumberPortings_PortId_PhonePorts'
)
BEGIN
    ALTER TABLE [tec].[NumberPortings]
        ADD CONSTRAINT [FK_tec_NumberPortings_PortId_PhonePorts]
        FOREIGN KEY ([PortId]) REFERENCES [tec].[PhonePorts] ([PhonePortId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalFormSubmissions_FormVersionId_FormVersions'
)
BEGIN
    ALTER TABLE [por].[PortalFormSubmissions]
        ADD CONSTRAINT [FK_por_PortalFormSubmissions_FormVersionId_FormVersions]
        FOREIGN KEY ([FormVersionId]) REFERENCES [wfl].[FormVersions] ([FormVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_FormDefinitions_FormDefinitionId_FormVersions'
)
BEGIN
    ALTER TABLE [wfl].[FormDefinitions] WITH NOCHECK
        ADD CONSTRAINT [FK_wfl_FormDefinitions_FormDefinitionId_FormVersions]
        FOREIGN KEY ([FormDefinitionId]) REFERENCES [wfl].[FormVersions] ([FormVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_por_PortalDrafts_FormVersionId_FormVersions'
)
BEGIN
    ALTER TABLE [por].[PortalDrafts]
        ADD CONSTRAINT [FK_por_PortalDrafts_FormVersionId_FormVersions]
        FOREIGN KEY ([FormVersionId]) REFERENCES [wfl].[FormVersions] ([FormVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_FieldForms_FormVersionId_FormVersions'
)
BEGIN
    ALTER TABLE [tec].[FieldForms]
        ADD CONSTRAINT [FK_tec_FieldForms_FormVersionId_FormVersions]
        FOREIGN KEY ([FormVersionId]) REFERENCES [wfl].[FormVersions] ([FormVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_wfl_FormSubmissions_FormVersionId_FormVersions'
)
BEGIN
    ALTER TABLE [wfl].[FormSubmissions]
        ADD CONSTRAINT [FK_wfl_FormSubmissions_FormVersionId_FormVersions]
        FOREIGN KEY ([FormVersionId]) REFERENCES [wfl].[FormVersions] ([FormVersionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_PosSessions_PosTerminalId_PosTerminals'
)
BEGIN
    ALTER TABLE [ven].[PosSessions]
        ADD CONSTRAINT [FK_ven_PosSessions_PosTerminalId_PosTerminals]
        FOREIGN KEY ([PosTerminalId]) REFERENCES [ven].[PosTerminals] ([PosTerminalId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tes_ReconciliationMatches_ReconciliationId_Reconciliations'
)
BEGIN
    ALTER TABLE [tes].[ReconciliationMatches]
        ADD CONSTRAINT [FK_tes_ReconciliationMatches_ReconciliationId_Reconciliations]
        FOREIGN KEY ([ReconciliationId]) REFERENCES [tes].[Reconciliations] ([ReconciliationId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkBeneficiaries_WorkId_Works'
)
BEGIN
    ALTER TABLE [tec].[WorkBeneficiaries]
        ADD CONSTRAINT [FK_tec_WorkBeneficiaries_WorkId_Works]
        FOREIGN KEY ([WorkId]) REFERENCES [tec].[Works] ([WorkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_WorkGroups_WorkId_Works'
)
BEGIN
    ALTER TABLE [tec].[WorkGroups] WITH NOCHECK
        ADD CONSTRAINT [FK_tec_WorkGroups_WorkId_Works]
        FOREIGN KEY ([WorkId]) REFERENCES [tec].[Works] ([WorkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_stk_Revaluations_ProjectId_Works'
)
BEGIN
    ALTER TABLE [stk].[Revaluations]
        ADD CONSTRAINT [FK_stk_Revaluations_ProjectId_Works]
        FOREIGN KEY ([ProjectId]) REFERENCES [tec].[Works] ([WorkId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_PlatformTableAdoptions_ReleaseId_PlatformTableReleases'
)
BEGIN
    ALTER TABLE [cfg].[PlatformTableAdoptions]
        ADD CONSTRAINT [FK_cfg_PlatformTableAdoptions_ReleaseId_PlatformTableReleases]
        FOREIGN KEY ([ReleaseId]) REFERENCES [cfg].[PlatformTableReleases] ([PlatformTableReleasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cfg_MasterImportJobs_PlatformTableReleaseId_PlatformTableReleases'
)
BEGIN
    ALTER TABLE [cfg].[MasterImportJobs]
        ADD CONSTRAINT [FK_cfg_MasterImportJobs_PlatformTableReleaseId_PlatformTableReleases]
        FOREIGN KEY ([PlatformTableReleaseId]) REFERENCES [cfg].[PlatformTableReleases] ([PlatformTableReleasId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_FederatedLinks_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[FederatedLinks]
        ADD CONSTRAINT [FK_iam_FederatedLinks_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_TrustedDevices_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[TrustedDevices]
        ADD CONSTRAINT [FK_iam_TrustedDevices_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditAccess_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[AuditAccess]
        ADD CONSTRAINT [FK_iam_AuditAccess_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_Memberships_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[Memberships]
        ADD CONSTRAINT [FK_iam_Memberships_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_OtpChallenges_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[OtpChallenges]
        ADD CONSTRAINT [FK_iam_OtpChallenges_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuthFactors_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[AuthFactors] WITH NOCHECK
        ADD CONSTRAINT [FK_iam_AuthFactors_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuthTransactions_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[AuthTransactions]
        ADD CONSTRAINT [FK_iam_AuthTransactions_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_SecurityAlerts_IdentityId_Identities'
)
BEGIN
    ALTER TABLE [iam].[SecurityAlerts]
        ADD CONSTRAINT [FK_iam_SecurityAlerts_IdentityId_Identities]
        FOREIGN KEY ([IdentityId]) REFERENCES [iam].[Identities] ([IdentityId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cat_ServiceContracts_FeasibilityRefId_FeasibilityRequests'
)
BEGIN
    ALTER TABLE [cat].[ServiceContracts]
        ADD CONSTRAINT [FK_cat_ServiceContracts_FeasibilityRefId_FeasibilityRequests]
        FOREIGN KEY ([FeasibilityRefId]) REFERENCES [tec].[FeasibilityRequests] ([FeasibilityRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_TechnicalNotes_EntityId_FeasibilityRequests'
)
BEGIN
    ALTER TABLE [tec].[TechnicalNotes]
        ADD CONSTRAINT [FK_tec_TechnicalNotes_EntityId_FeasibilityRequests]
        FOREIGN KEY ([EntityId]) REFERENCES [tec].[FeasibilityRequests] ([FeasibilityRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesQuotes_FeasibilityId_FeasibilityRequests'
)
BEGIN
    ALTER TABLE [ven].[SalesQuotes]
        ADD CONSTRAINT [FK_ven_SalesQuotes_FeasibilityId_FeasibilityRequests]
        FOREIGN KEY ([FeasibilityId]) REFERENCES [tec].[FeasibilityRequests] ([FeasibilityRequestId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStrips_FrameGroupId_PhoneFrameGroups'
)
BEGIN
    ALTER TABLE [tec].[PhoneStrips]
        ADD CONSTRAINT [FK_tec_PhoneStrips_FrameGroupId_PhoneFrameGroups]
        FOREIGN KEY ([FrameGroupId]) REFERENCES [tec].[PhoneFrameGroups] ([PhoneFrameGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_tec_PhoneStrips_OwnerId_PhoneFrameGroups'
)
BEGIN
    ALTER TABLE [tec].[PhoneStrips]
        ADD CONSTRAINT [FK_tec_PhoneStrips_OwnerId_PhoneFrameGroups]
        FOREIGN KEY ([OwnerId]) REFERENCES [tec].[PhoneFrameGroups] ([PhoneFrameGroupId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_bia_ExtWebhookDeliveries_SubscriptionId_ExtWebhookSubscriptions'
)
BEGIN
    ALTER TABLE [bia].[ExtWebhookDeliveries]
        ADD CONSTRAINT [FK_bia_ExtWebhookDeliveries_SubscriptionId_ExtWebhookSubscriptions]
        FOREIGN KEY ([SubscriptionId]) REFERENCES [bia].[ExtWebhookSubscriptions] ([ExtWebhookSubscriptionId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ven_SalesQuotes_PremiseAddressId_Addresses'
)
BEGIN
    ALTER TABLE [ven].[SalesQuotes]
        ADD CONSTRAINT [FK_ven_SalesQuotes_PremiseAddressId_Addresses]
        FOREIGN KEY ([PremiseAddressId]) REFERENCES [per].[Addresses] ([AddressId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_com_MessageTemplateVersions_TemplateId_MessageTemplates'
)
BEGIN
    ALTER TABLE [com].[MessageTemplateVersions] WITH NOCHECK
        ADD CONSTRAINT [FK_com_MessageTemplateVersions_TemplateId_MessageTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [com].[MessageTemplates] ([MessageTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_iam_AuditMessages_TemplateId_MessageTemplates'
)
BEGIN
    ALTER TABLE [iam].[AuditMessages]
        ADD CONSTRAINT [FK_iam_AuditMessages_TemplateId_MessageTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [com].[MessageTemplates] ([MessageTemplateId]);
END;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_cmp_SupplierCorrespondence_TemplateId_MessageTemplates'
)
BEGIN
    ALTER TABLE [cmp].[SupplierCorrespondence]
        ADD CONSTRAINT [FK_cmp_SupplierCorrespondence_TemplateId_MessageTemplates]
        FOREIGN KEY ([TemplateId]) REFERENCES [com].[MessageTemplates] ([MessageTemplateId]);
END;
GO

