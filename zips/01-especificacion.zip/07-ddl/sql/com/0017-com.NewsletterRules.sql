-- com.NewsletterRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.NewsletterRules', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[NewsletterRules] (
        [NewsletterRuleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [ScheduleMode] VARCHAR(64) NULL,
        [IntervalHours] INT NULL,
        [CalendarWeekdays] INT NULL,
        [CalendarTime] NVARCHAR(512) NULL,
        [Timezone] NVARCHAR(512) NULL,
        [Format] VARCHAR(64) NULL,
        [GreetingTemplate] NVARCHAR(512) NULL,
        [RequireReview] BIT NULL,
        [PostCount] INT NULL,
        [SelectMode] VARCHAR(64) NULL,
        [Types] VARCHAR(64) NULL,
        [MaxAgeHours] INT NULL,
        [AvoidRepeats] BIT NULL,
        [Audience] NVARCHAR(MAX) NULL,
        [Channels] VARCHAR(64) NULL,
        [Enabled] BIT NULL,
        [LastRunAt] DATETIME2(7) NOT NULL,
        [NextRunAt] DATETIME2(7) NOT NULL,
        [LastRunKey] NVARCHAR(512) NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_NewsletterRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_NewsletterRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_NewsletterRules] PRIMARY KEY ([NewsletterRuleId]),
        CONSTRAINT [FK_com_NewsletterRules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_NewsletterRules_Tenant] ON [com].[NewsletterRules] ([TenantId]);
END;
GO
