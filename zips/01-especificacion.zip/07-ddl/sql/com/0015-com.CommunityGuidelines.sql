-- com.CommunityGuidelines — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.CommunityGuidelines', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[CommunityGuidelines] (
        [CommunityGuidelineId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Version] NVARCHAR(512) NULL,
        [Title] NVARCHAR(512) NOT NULL,
        [Body] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [PublishedAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunityGuidelines_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunityGuidelines_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_CommunityGuidelines] PRIMARY KEY ([CommunityGuidelineId]),
        CONSTRAINT [FK_com_CommunityGuidelines_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_CommunityGuidelines_Tenant] ON [com].[CommunityGuidelines] ([TenantId]);
END;
GO
