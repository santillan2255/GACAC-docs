-- com.AudienceImportRows — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.AudienceImportRows', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[AudienceImportRows] (
        [AudienceImportRowId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ListId] UNIQUEIDENTIFIER NOT NULL,
        [RowNumber] INT NULL,
        [Raw] NVARCHAR(MAX) NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [AccountId] UNIQUEIDENTIFIER NULL,
        [MatchStatus] VARCHAR(64) NULL,
        [Error] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AudienceImportRows_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AudienceImportRows_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_AudienceImportRows] PRIMARY KEY ([AudienceImportRowId]),
        CONSTRAINT [FK_com_AudienceImportRows_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_AudienceImportRows_Tenant] ON [com].[AudienceImportRows] ([TenantId]);
END;
GO
