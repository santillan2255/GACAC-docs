-- com.ChannelSettings — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.ChannelSettings', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[ChannelSettings] (
        [ChannelSettingId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Enabled] BIT NULL,
        [ConnectionId] UNIQUEIDENTIFIER NULL,
        [ProviderKind] VARCHAR(64) NULL,
        [Throttle] NVARCHAR(MAX) NULL,
        [MaxAttempts] INT NULL,
        [TtlHours] INT NULL,
        [CircuitBreaker] NVARCHAR(MAX) NULL,
        [QuietHours] NVARCHAR(MAX) NULL,
        [DailyCapPerRecipient] INT NULL,
        [MonthlyBudget] DECIMAL(18,4) NULL,
        [BccForBulk] NVARCHAR(512) NULL,
        [AllowEditTemplateOnSingleSend] BIT NULL,
        [SmsMaxChars] INT NULL,
        [WhatsappSessionOnlyFromCrm] BIT NULL,
        [Health] NVARCHAR(MAX) NOT NULL,
        [Channel] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_ChannelSettings_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_ChannelSettings_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_ChannelSettings] PRIMARY KEY ([ChannelSettingId]),
        CONSTRAINT [FK_com_ChannelSettings_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_ChannelSettings_Tenant] ON [com].[ChannelSettings] ([TenantId]);
END;
GO
