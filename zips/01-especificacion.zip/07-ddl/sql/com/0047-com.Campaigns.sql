-- com.Campaigns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.Campaigns', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[Campaigns] (
        [CampaignId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Purpose] VARCHAR(64) NOT NULL,
        [Audience] NVARCHAR(MAX) NOT NULL,
        [ChannelsJson] NVARCHAR(MAX) NOT NULL,
        [AdhocContentJson] NVARCHAR(MAX) NULL,
        [AbTestJson] NVARCHAR(MAX) NULL,
        [LinkJson] NVARCHAR(MAX) NULL,
        [ScheduleJson] NVARCHAR(MAX) NOT NULL,
        [ThrottleOverrideJson] NVARCHAR(MAX) NULL,
        [CostCap] DECIMAL(18,4) NULL,
        [TestRecipients] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ApprovalJson] NVARCHAR(MAX) NULL,
        [AudienceSnapshotId] UNIQUEIDENTIFIER NOT NULL,
        [MetricsJson] NVARCHAR(MAX) NOT NULL,
        [RunsJson] NVARCHAR(MAX) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Campaigns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Campaigns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_Campaigns] PRIMARY KEY ([CampaignId]),
        CONSTRAINT [FK_com_Campaigns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_Campaigns_Tenant] ON [com].[Campaigns] ([TenantId]);
END;
GO
