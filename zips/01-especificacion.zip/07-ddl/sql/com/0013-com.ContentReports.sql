-- com.ContentReports — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.ContentReports', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[ContentReports] (
        [ContentReportId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TargetRefJson] NVARCHAR(MAX) NOT NULL,
        [PostId] UNIQUEIDENTIFIER NULL,
        [ReporterUserId] UNIQUEIDENTIFIER NOT NULL,
        [ReasonCode] VARCHAR(64) NULL,
        [Text] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [CrmCaseId] UNIQUEIDENTIFIER NULL,
        [ResolvedAt] DATETIME2(7) NULL,
        [ReporterNotifiedAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_ContentReports_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_ContentReports_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_ContentReports] PRIMARY KEY ([ContentReportId]),
        CONSTRAINT [FK_com_ContentReports_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_ContentReports_Tenant] ON [com].[ContentReports] ([TenantId]);
END;
GO
