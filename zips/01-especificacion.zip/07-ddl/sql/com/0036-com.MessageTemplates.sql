-- com.MessageTemplates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.MessageTemplates', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[MessageTemplates] (
        [MessageTemplateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CommunicationTypeId] UNIQUEIDENTIFIER NOT NULL,
        [Channel] VARCHAR(64) NOT NULL,
        [Locale] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [CurrentVersionId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [PlatformTemplateId] UNIQUEIDENTIFIER NULL,
        [Whatsapp] NVARCHAR(MAX) NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_MessageTemplates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_MessageTemplates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_MessageTemplates] PRIMARY KEY ([MessageTemplateId]),
        CONSTRAINT [FK_com_MessageTemplates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_MessageTemplates_Tenant] ON [com].[MessageTemplates] ([TenantId]);
END;
GO
