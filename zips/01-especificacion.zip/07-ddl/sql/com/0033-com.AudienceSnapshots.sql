-- com.AudienceSnapshots — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.AudienceSnapshots', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[AudienceSnapshots] (
        [AudienceSnapshotId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [OwnerType] VARCHAR(64) NULL,
        [OwnerId] UNIQUEIDENTIFIER NULL,
        [DefinitionHash] NVARCHAR(512) NULL,
        [Definition] NVARCHAR(MAX) NULL,
        [GrantHash] NVARCHAR(512) NULL,
        [CapturedAt] DATETIME2(7) NULL,
        [Counts] NVARCHAR(MAX) NOT NULL,
        [EstimatedCost] NVARCHAR(MAX) NOT NULL,
        [SegmentId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AudienceSnapshots_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AudienceSnapshots_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_AudienceSnapshots] PRIMARY KEY ([AudienceSnapshotId]),
        CONSTRAINT [FK_com_AudienceSnapshots_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_AudienceSnapshots_Tenant] ON [com].[AudienceSnapshots] ([TenantId]);
END;
GO
