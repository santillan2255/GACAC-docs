-- com.InternalNotificationRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.InternalNotificationRules', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[InternalNotificationRules] (
        [InternalNotificationRuleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [CommunicationTypeCode] NVARCHAR(512) NULL,
        [Filters] NVARCHAR(MAX) NULL,
        [Moment] VARCHAR(64) NULL,
        [Recipients] NVARCHAR(MAX) NULL,
        [Channels] VARCHAR(64) NULL,
        [Schedule] NVARCHAR(MAX) NULL,
        [Active] BIT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_InternalNotificationRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_InternalNotificationRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_InternalNotificationRules] PRIMARY KEY ([InternalNotificationRuleId]),
        CONSTRAINT [FK_com_InternalNotificationRules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_InternalNotificationRules_Tenant] ON [com].[InternalNotificationRules] ([TenantId]);
END;
GO
