-- com.Benefits — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.Benefits', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[Benefits] (
        [BenefitId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Title] NVARCHAR(512) NOT NULL,
        [Description] NVARCHAR(512) NULL,
        [BenefitPartnerId] UNIQUEIDENTIFIER NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [Value] DECIMAL(18,4) NULL,
        [Currency] NVARCHAR(512) NULL,
        [Conditions] NVARCHAR(512) NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [ValidTo] DATETIME2(7) NULL,
        [Audience] NVARCHAR(MAX) NULL,
        [TotalQuota] INT NULL,
        [PerPersonQuota] INT NULL,
        [RedemptionMode] VARCHAR(64) NULL,
        [GenericCode] NVARCHAR(512) NULL,
        [Cover] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Counters] NVARCHAR(MAX) NOT NULL,
        [PostId] UNIQUEIDENTIFIER NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Benefits_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Benefits_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_Benefits] PRIMARY KEY ([BenefitId]),
        CONSTRAINT [FK_com_Benefits_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_Benefits_Tenant] ON [com].[Benefits] ([TenantId]);
END;
GO
