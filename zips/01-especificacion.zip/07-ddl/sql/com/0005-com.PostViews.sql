-- com.PostViews — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.PostViews', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[PostViews] (
        [PostViewId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [PostId] UNIQUEIDENTIFIER NOT NULL,
        [UserId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [Channel] VARCHAR(64) NOT NULL,
        [DayKey] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PostViews_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PostViews_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_PostViews] PRIMARY KEY ([PostViewId]),
        CONSTRAINT [FK_com_PostViews_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_PostViews_Tenant] ON [com].[PostViews] ([TenantId]);
END;
GO
