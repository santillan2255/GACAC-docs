-- com.PostCategories — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.PostCategories', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[PostCategories] (
        [PostCategoryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Slug] NVARCHAR(512) NULL,
        [Icon] NVARCHAR(512) NULL,
        [Color] NVARCHAR(512) NULL,
        [ParentId] UNIQUEIDENTIFIER NULL,
        [Order] INT NULL,
        [Active] BIT NULL,
        [System] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PostCategories_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PostCategories_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_PostCategories] PRIMARY KEY ([PostCategoryId]),
        CONSTRAINT [FK_com_PostCategories_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_PostCategories_Tenant] ON [com].[PostCategories] ([TenantId]);
END;
GO
