-- com.PostTemplates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.PostTemplates', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[PostTemplates] (
        [PostTemplateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Type] VARCHAR(64) NULL,
        [Title] NVARCHAR(512) NOT NULL,
        [Body] NVARCHAR(512) NULL,
        [Layout] VARCHAR(64) NULL,
        [Section] NVARCHAR(512) NULL,
        [Cover] NVARCHAR(MAX) NULL,
        [Pinned] BIT NULL,
        [DefaultAudience] NVARCHAR(MAX) NULL,
        [DefaultChannels] VARCHAR(64) NULL,
        [Active] BIT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PostTemplates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PostTemplates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_PostTemplates] PRIMARY KEY ([PostTemplateId]),
        CONSTRAINT [FK_com_PostTemplates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_PostTemplates_Tenant] ON [com].[PostTemplates] ([TenantId]);
END;
GO
