-- com.GreetingRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.GreetingRules', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[GreetingRules] (
        [GreetingRuleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [EventType] VARCHAR(64) NULL,
        [Audience] NVARCHAR(MAX) NULL,
        [PostTemplateId] UNIQUEIDENTIFIER NULL,
        [Channels] VARCHAR(64) NULL,
        [SendTime] NVARCHAR(512) NULL,
        [Active] BIT NULL,
        [LastRunKey] NVARCHAR(512) NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_GreetingRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_GreetingRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_GreetingRules] PRIMARY KEY ([GreetingRuleId]),
        CONSTRAINT [FK_com_GreetingRules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_GreetingRules_Tenant] ON [com].[GreetingRules] ([TenantId]);
END;
GO
