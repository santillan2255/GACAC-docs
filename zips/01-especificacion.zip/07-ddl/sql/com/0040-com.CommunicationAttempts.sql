-- com.CommunicationAttempts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.CommunicationAttempts', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[CommunicationAttempts] (
        [CommunicationAttemptId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CommunicationId] UNIQUEIDENTIFIER NOT NULL,
        [AttemptNumber] INT NOT NULL,
        [ConnectorId] UNIQUEIDENTIFIER NULL,
        [StartedAt] DATETIME2(7) NULL,
        [FinishedAt] DATETIME2(7) NULL,
        [Result] VARCHAR(64) NULL,
        [ProviderCode] NVARCHAR(512) NULL,
        [ProviderMessage] NVARCHAR(512) NULL,
        [Retryable] BIT NULL,
        [NextRetryAt] DATETIME2(7) NULL,
        [IntOperationId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunicationAttempts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunicationAttempts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_CommunicationAttempts] PRIMARY KEY ([CommunicationAttemptId]),
        CONSTRAINT [FK_com_CommunicationAttempts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_CommunicationAttempts_Tenant] ON [com].[CommunicationAttempts] ([TenantId]);
END;
GO
