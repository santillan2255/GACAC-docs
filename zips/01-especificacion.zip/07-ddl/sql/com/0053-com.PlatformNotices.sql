-- com.PlatformNotices — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.PlatformNotices', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[PlatformNotices] (
        [PlatformNoticeId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [Title] NVARCHAR(512) NOT NULL,
        [Body] NVARCHAR(512) NULL,
        [TargetTenantsId] UNIQUEIDENTIFIER NULL,
        [TargetRoles] NVARCHAR(512) NULL,
        [Permanence] VARCHAR(64) NULL,
        [StartsAt] DATETIME2(7) NULL,
        [EndsAt] DATETIME2(7) NULL,
        [SurveyId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PlatformNotices_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PlatformNotices_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_PlatformNotices] PRIMARY KEY ([PlatformNoticeId])
    );
END;
GO
