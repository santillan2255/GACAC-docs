-- com.CommunicationPreferences — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.CommunicationPreferences', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[CommunicationPreferences] (
        [CommunicationPreferenceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NOT NULL,
        [UserId] UNIQUEIDENTIFIER NULL,
        [ByPurpose] NVARCHAR(MAX) NULL,
        [ByType] NVARCHAR(MAX) NULL,
        [Locale] NVARCHAR(512) NULL,
        [QuietHours] NVARCHAR(MAX) NULL,
        [NewsletterMaxPerWeek] INT NULL,
        [InvoiceDigital] NVARCHAR(MAX) NULL,
        [UpdatedVia] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunicationPreferences_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunicationPreferences_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_CommunicationPreferences] PRIMARY KEY ([CommunicationPreferenceId]),
        CONSTRAINT [FK_com_CommunicationPreferences_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_CommunicationPreferences_Tenant] ON [com].[CommunicationPreferences] ([TenantId]);
END;
GO
