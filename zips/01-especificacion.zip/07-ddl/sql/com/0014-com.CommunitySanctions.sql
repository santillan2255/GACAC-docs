-- com.CommunitySanctions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.CommunitySanctions', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[CommunitySanctions] (
        [CommunitySanctionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [MembershipId] UNIQUEIDENTIFIER NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [ReasonCode] NVARCHAR(512) NULL,
        [CaseIdsId] UNIQUEIDENTIFIER NULL,
        [OffenseNumber] INT NULL,
        [StartsAt] DATETIME2(7) NULL,
        [EndsAt] DATETIME2(7) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [SuggestedBySystem] BIT NULL,
        [AppliedById] UNIQUEIDENTIFIER NULL,
        [RevokedById] UNIQUEIDENTIFIER NULL,
        [RevokeReason] NVARCHAR(512) NULL,
        [Appeal] NVARCHAR(MAX) NULL,
        [NotifiedAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunitySanctions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunitySanctions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_CommunitySanctions] PRIMARY KEY ([CommunitySanctionId]),
        CONSTRAINT [FK_com_CommunitySanctions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_CommunitySanctions_Tenant] ON [com].[CommunitySanctions] ([TenantId]);
END;
GO
