-- com.TrackedLinks — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.TrackedLinks', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[TrackedLinks] (
        [TrackedLinkId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CommunicationId] UNIQUEIDENTIFIER NOT NULL,
        [CampaignId] UNIQUEIDENTIFIER NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [TargetUrl] NVARCHAR(512) NULL,
        [Clicks] INT NOT NULL,
        [FirstClickAt] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_TrackedLinks_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_TrackedLinks_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_TrackedLinks] PRIMARY KEY ([TrackedLinkId]),
        CONSTRAINT [FK_com_TrackedLinks_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_TrackedLinks_Tenant] ON [com].[TrackedLinks] ([TenantId]);
END;
GO
