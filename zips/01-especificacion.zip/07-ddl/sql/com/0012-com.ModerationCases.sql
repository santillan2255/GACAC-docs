-- com.ModerationCases — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.ModerationCases', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[ModerationCases] (
        [ModerationCasId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TargetRefJson] NVARCHAR(MAX) NOT NULL,
        [Origin] VARCHAR(64) NOT NULL,
        [Priority] VARCHAR(64) NOT NULL,
        [RiskSnapshot] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Decision] BIT NULL,
        [HistoryJson] NVARCHAR(MAX) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_ModerationCases_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_ModerationCases_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_ModerationCases] PRIMARY KEY ([ModerationCasId]),
        CONSTRAINT [FK_com_ModerationCases_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_ModerationCases_Tenant] ON [com].[ModerationCases] ([TenantId]);
END;
GO
