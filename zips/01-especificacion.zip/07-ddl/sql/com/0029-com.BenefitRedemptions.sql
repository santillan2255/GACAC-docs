-- com.BenefitRedemptions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.BenefitRedemptions', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[BenefitRedemptions] (
        [BenefitRedemptionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [BenefitId] UNIQUEIDENTIFIER NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [UserId] UNIQUEIDENTIFIER NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [QrToken] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [IssuedAt] DATETIME2(7) NULL,
        [ExpiresAt] DATETIME2(7) NULL,
        [RedeemedAt] DATETIME2(7) NULL,
        [RedeemedById] UNIQUEIDENTIFIER NULL,
        [PartnerId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_BenefitRedemptions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_BenefitRedemptions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_BenefitRedemptions] PRIMARY KEY ([BenefitRedemptionId]),
        CONSTRAINT [FK_com_BenefitRedemptions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_BenefitRedemptions_Tenant] ON [com].[BenefitRedemptions] ([TenantId]);
END;
GO
