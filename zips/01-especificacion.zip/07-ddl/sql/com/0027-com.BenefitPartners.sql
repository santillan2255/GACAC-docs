-- com.BenefitPartners — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.BenefitPartners', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[BenefitPartners] (
        [BenefitPartnerId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [TaxId] NVARCHAR(512) NULL,
        [Contact] NVARCHAR(MAX) NULL,
        [AddressText] NVARCHAR(512) NULL,
        [ValidatorUserIdsId] UNIQUEIDENTIFIER NULL,
        [ValidationLinkEnabled] BIT NULL,
        [Active] BIT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_BenefitPartners_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_BenefitPartners_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_BenefitPartners] PRIMARY KEY ([BenefitPartnerId]),
        CONSTRAINT [FK_com_BenefitPartners_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_BenefitPartners_Tenant] ON [com].[BenefitPartners] ([TenantId]);
END;
GO
