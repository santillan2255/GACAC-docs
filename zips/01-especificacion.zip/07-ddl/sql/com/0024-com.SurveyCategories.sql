-- com.SurveyCategories — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.SurveyCategories', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[SurveyCategories] (
        [SurveyCategoryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Color] NVARCHAR(512) NULL,
        [Order] INT NULL,
        [Active] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SurveyCategories_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SurveyCategories_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_SurveyCategories] PRIMARY KEY ([SurveyCategoryId]),
        CONSTRAINT [FK_com_SurveyCategories_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_SurveyCategories_Tenant] ON [com].[SurveyCategories] ([TenantId]);
END;
GO
