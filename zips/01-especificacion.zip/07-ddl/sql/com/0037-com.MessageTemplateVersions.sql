-- com.MessageTemplateVersions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.MessageTemplateVersions', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[MessageTemplateVersions] (
        [MessageTemplateVersionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TemplateId] UNIQUEIDENTIFIER NOT NULL,
        [VersionNumber] INT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Subject] NVARCHAR(512) NULL,
        [Preheader] NVARCHAR(512) NULL,
        [BodyHtml] NVARCHAR(512) NULL,
        [BodyText] NVARCHAR(512) NULL,
        [Title] NVARCHAR(512) NULL,
        [ImageRef] NVARCHAR(512) NULL,
        [Attachments] NVARCHAR(MAX) NULL,
        [VariablesUsed] NVARCHAR(512) NOT NULL,
        [ThemeVersion] NVARCHAR(512) NULL,
        [DictionaryVersion] NVARCHAR(512) NULL,
        [SmsStats] NVARCHAR(MAX) NOT NULL,
        [PublishedAt] DATETIME2(7) NULL,
        [PublishedById] UNIQUEIDENTIFIER NULL,
        [ChangeNote] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_MessageTemplateVersions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_MessageTemplateVersions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_MessageTemplateVersions] PRIMARY KEY ([MessageTemplateVersionId]),
        CONSTRAINT [FK_com_MessageTemplateVersions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_MessageTemplateVersions_Tenant] ON [com].[MessageTemplateVersions] ([TenantId]);
END;
GO
