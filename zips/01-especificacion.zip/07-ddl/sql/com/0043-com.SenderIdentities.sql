-- com.SenderIdentities — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.SenderIdentities', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[SenderIdentities] (
        [SenderIdentityId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Channel] VARCHAR(64) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [FromName] NVARCHAR(512) NULL,
        [ReplyTo] NVARCHAR(512) NULL,
        [ConnectorId] UNIQUEIDENTIFIER NULL,
        [VerificationStatus] VARCHAR(64) NULL,
        [Default] BIT NULL,
        [Address] NVARCHAR(512) NOT NULL,
        [CredentialRef] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SenderIdentities_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SenderIdentities_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_SenderIdentities] PRIMARY KEY ([SenderIdentityId]),
        CONSTRAINT [FK_com_SenderIdentities_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_SenderIdentities_Tenant] ON [com].[SenderIdentities] ([TenantId]);
END;
GO
