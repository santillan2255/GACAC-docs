-- com.OutageNotices — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.OutageNotices', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[OutageNotices] (
        [OutageNoticeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] NVARCHAR(512) NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NOT NULL,
        [ZoneIdsId] UNIQUEIDENTIFIER NULL,
        [Reason] NVARCHAR(512) NOT NULL,
        [AreaJson] NVARCHAR(MAX) NOT NULL,
        [WindowJson] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [SourceJson] NVARCHAR(MAX) NOT NULL,
        [PublishOn] DATETIME2(7) NOT NULL,
        [NotifyChannels] VARCHAR(64) NOT NULL,
        [AffectedJson] NVARCHAR(MAX) NOT NULL,
        [UpdatesJson] NVARCHAR(MAX) NULL,
        [RescheduledFromId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_OutageNotices_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_OutageNotices_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_OutageNotices] PRIMARY KEY ([OutageNoticeId]),
        CONSTRAINT [FK_com_OutageNotices_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_OutageNotices_Tenant] ON [com].[OutageNotices] ([TenantId]);
END;
GO
