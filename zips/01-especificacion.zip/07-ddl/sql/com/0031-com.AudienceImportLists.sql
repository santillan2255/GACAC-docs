-- com.AudienceImportLists — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.AudienceImportLists', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[AudienceImportLists] (
        [AudienceImportListId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [FileObjectKey] NVARCHAR(512) NULL,
        [MatchBy] VARCHAR(64) NULL,
        [RowsTotal] INT NOT NULL,
        [RowsMatched] INT NOT NULL,
        [RowsUnmatched] INT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ImportedById] UNIQUEIDENTIFIER NULL,
        [ConfirmedAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AudienceImportLists_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AudienceImportLists_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_AudienceImportLists] PRIMARY KEY ([AudienceImportListId]),
        CONSTRAINT [FK_com_AudienceImportLists_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_AudienceImportLists_Tenant] ON [com].[AudienceImportLists] ([TenantId]);
END;
GO
