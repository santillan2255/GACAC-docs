-- com.SuppressionEntries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.SuppressionEntries', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[SuppressionEntries] (
        [SuppressionEntryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Channel] VARCHAR(64) NOT NULL,
        [AddressHmac] NVARCHAR(512) NOT NULL,
        [AddressMasked] NVARCHAR(512) NULL,
        [Reason] VARCHAR(64) NULL,
        [SourceCommunicationId] UNIQUEIDENTIFIER NULL,
        [Since] DATETIME2(7) NULL,
        [Until] DATETIME2(7) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LiftedById] UNIQUEIDENTIFIER NULL,
        [LiftEvidenceRef] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SuppressionEntries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SuppressionEntries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_SuppressionEntries] PRIMARY KEY ([SuppressionEntryId]),
        CONSTRAINT [FK_com_SuppressionEntries_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_SuppressionEntries_Tenant] ON [com].[SuppressionEntries] ([TenantId]);
END;
GO
