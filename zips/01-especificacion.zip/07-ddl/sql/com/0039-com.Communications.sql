-- com.Communications — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.Communications', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[Communications] (
        [CommunicationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CommunicationTypeCode] NVARCHAR(512) NOT NULL,
        [Purpose] VARCHAR(64) NOT NULL,
        [OriginJson] NVARCHAR(MAX) NOT NULL,
        [SourceRefJson] NVARCHAR(MAX) NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NOT NULL,
        [RecipientJson] NVARCHAR(MAX) NOT NULL,
        [Channel] VARCHAR(64) NOT NULL,
        [RenderJson] NVARCHAR(MAX) NOT NULL,
        [AttachmentsJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [StatusHistoryJson] NVARCHAR(MAX) NOT NULL,
        [FailureClass] VARCHAR(64) NULL,
        [AttemptCount] INT NOT NULL,
        [FallbackJson] NVARCHAR(MAX) NULL,
        [MilestoneJson] NVARCHAR(MAX) NOT NULL,
        [IdempotencyKey] NVARCHAR(512) NOT NULL,
        [ProofDocumentRef] NVARCHAR(MAX) NULL,
        [Environment] VARCHAR(64) NOT NULL,
        [LegalHold] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Communications_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Communications_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_Communications] PRIMARY KEY ([CommunicationId]),
        CONSTRAINT [FK_com_Communications_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_Communications_Tenant] ON [com].[Communications] ([TenantId]);
END;
GO
