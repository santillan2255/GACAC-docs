-- com.NewsletterRecipients — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.NewsletterRecipients', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[NewsletterRecipients] (
        [NewsletterRecipientId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [NewsletterId] UNIQUEIDENTIFIER NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NOT NULL,
        [UserId] UNIQUEIDENTIFIER NULL,
        [Fingerprint] NVARCHAR(512) NULL,
        [PostIdsId] UNIQUEIDENTIFIER NULL,
        [Included] BIT NULL,
        [IsExternal] BIT NULL,
        [CanEmail] BIT NULL,
        [CommunicationIdsId] UNIQUEIDENTIFIER NULL,
        [DeliveryStatus] VARCHAR(64) NULL,
        [SentAt] DATETIME2(7) NULL,
        [Error] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_NewsletterRecipients_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_NewsletterRecipients_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_NewsletterRecipients] PRIMARY KEY ([NewsletterRecipientId]),
        CONSTRAINT [FK_com_NewsletterRecipients_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_NewsletterRecipients_Tenant] ON [com].[NewsletterRecipients] ([TenantId]);
END;
GO
