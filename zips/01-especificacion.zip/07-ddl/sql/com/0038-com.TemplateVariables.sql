-- com.TemplateVariables — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.TemplateVariables', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[TemplateVariables] (
        [TemplateVariableId] UNIQUEIDENTIFIER NOT NULL,
        [Key] NVARCHAR(512) NOT NULL,
        [Label] NVARCHAR(512) NULL,
        [Type] VARCHAR(64) NULL,
        [Format] DATETIME2(7) NULL,
        [ProviderModule] NVARCHAR(512) NULL,
        [Example] NVARCHAR(512) NULL,
        [NullPolicy] VARCHAR(64) NULL,
        [DefaultValue] NVARCHAR(512) NULL,
        [Sensitive] BIT NULL,
        [CommunicationTypeCodes] NVARCHAR(512) NULL,
        [Legacy] NVARCHAR(MAX) NULL,
        [WspPosition] INT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_TemplateVariables_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_TemplateVariables_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_TemplateVariables] PRIMARY KEY ([TemplateVariableId])
    );
END;
GO
