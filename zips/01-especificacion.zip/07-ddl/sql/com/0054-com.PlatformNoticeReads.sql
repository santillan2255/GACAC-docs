-- com.PlatformNoticeReads — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.PlatformNoticeReads', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[PlatformNoticeReads] (
        [PlatformNoticeReadId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [NoticeId] UNIQUEIDENTIFIER NOT NULL,
        [MembershipId] UNIQUEIDENTIFIER NULL,
        [ReadAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PlatformNoticeReads_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PlatformNoticeReads_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_PlatformNoticeReads] PRIMARY KEY ([PlatformNoticeReadId]),
        CONSTRAINT [FK_com_PlatformNoticeReads_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_PlatformNoticeReads_Tenant] ON [com].[PlatformNoticeReads] ([TenantId]);
END;
GO
