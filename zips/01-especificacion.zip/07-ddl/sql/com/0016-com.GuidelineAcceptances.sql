-- com.GuidelineAcceptances — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.GuidelineAcceptances', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[GuidelineAcceptances] (
        [GuidelineAcceptanceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [MembershipId] UNIQUEIDENTIFIER NOT NULL,
        [GuidelinesVersion] NVARCHAR(512) NOT NULL,
        [AcceptedAt] DATETIME2(7) NULL,
        [Device] NVARCHAR(MAX) NULL,
        [IpHash] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_GuidelineAcceptances_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_GuidelineAcceptances_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_GuidelineAcceptances] PRIMARY KEY ([GuidelineAcceptanceId]),
        CONSTRAINT [FK_com_GuidelineAcceptances_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_GuidelineAcceptances_Tenant] ON [com].[GuidelineAcceptances] ([TenantId]);
END;
GO
