-- com.PushSubscriptions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.PushSubscriptions', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[PushSubscriptions] (
        [PushSubscriptionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [MembershipId] UNIQUEIDENTIFIER NOT NULL,
        [EndpointHash] NVARCHAR(512) NOT NULL,
        [Keys] NVARCHAR(MAX) NULL,
        [Device] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NULL,
        [LastSuccessAt] DATETIME2(7) NOT NULL,
        [Failures] INT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Endpoint] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PushSubscriptions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_PushSubscriptions] PRIMARY KEY ([PushSubscriptionId]),
        CONSTRAINT [FK_com_PushSubscriptions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_PushSubscriptions_Tenant] ON [com].[PushSubscriptions] ([TenantId]);
END;
GO
