-- com.MessagingUsage — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.MessagingUsage', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[MessagingUsage] (
        [MessagingUsageId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Period] NVARCHAR(512) NULL,
        [DayKey] NVARCHAR(512) NOT NULL,
        [Channel] VARCHAR(64) NOT NULL,
        [Purpose] VARCHAR(64) NOT NULL,
        [Module] NVARCHAR(512) NULL,
        [CommunicationTypeCode] NVARCHAR(512) NOT NULL,
        [Count] INT NOT NULL,
        [Segments] INT NOT NULL,
        [Conversations] INT NOT NULL,
        [CostAmount] DECIMAL(18,4) NOT NULL,
        [Currency] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_MessagingUsage_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_MessagingUsage_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_MessagingUsage] PRIMARY KEY ([MessagingUsageId]),
        CONSTRAINT [FK_com_MessagingUsage_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_MessagingUsage_Tenant] ON [com].[MessagingUsage] ([TenantId]);
END;
GO
