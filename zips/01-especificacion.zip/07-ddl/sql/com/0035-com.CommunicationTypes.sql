-- com.CommunicationTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.CommunicationTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[CommunicationTypes] (
        [CommunicationTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Module] NVARCHAR(512) NOT NULL,
        [TriggerEvents] NVARCHAR(512) NULL,
        [Purpose] VARCHAR(64) NOT NULL,
        [AudienceKind] VARCHAR(64) NOT NULL,
        [OptOut] VARCHAR(64) NOT NULL,
        [QuietHoursExempt] BIT NOT NULL,
        [Priority] VARCHAR(64) NOT NULL,
        [SendWindowJson] NVARCHAR(MAX) NULL,
        [TtlHours] INT NULL,
        [RequiredMilestone] VARCHAR(64) NOT NULL,
        [EvidenceRequired] BIT NOT NULL,
        [NotifKind] NVARCHAR(512) NOT NULL,
        [DeepLinkJson] NVARCHAR(MAX) NULL,
        [RecipientRule] VARCHAR(64) NOT NULL,
        [Grouping] VARCHAR(64) NULL,
        [TemplateIds] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunicationTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunicationTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_CommunicationTypes] PRIMARY KEY ([CommunicationTypeId]),
        CONSTRAINT [FK_com_CommunicationTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_CommunicationTypes_Tenant] ON [com].[CommunicationTypes] ([TenantId]);
END;
GO
