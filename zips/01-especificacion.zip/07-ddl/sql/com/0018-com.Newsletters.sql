-- com.Newsletters — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.Newsletters', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[Newsletters] (
        [NewsletterId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [RuleId] UNIQUEIDENTIFIER NOT NULL,
        [Subject] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Format] NVARCHAR(512) NULL,
        [Posts] NVARCHAR(MAX) NULL,
        [FeaturedPostId] UNIQUEIDENTIFIER NULL,
        [Lede] NVARCHAR(512) NULL,
        [LedeAi] BIT NULL,
        [GreetingTemplate] NVARCHAR(512) NULL,
        [VisibleInApp] BIT NULL,
        [Variants] NVARCHAR(MAX) NULL,
        [Totals] NVARCHAR(MAX) NOT NULL,
        [Actors] NVARCHAR(MAX) NULL,
        [AudienceSnapshotId] UNIQUEIDENTIFIER NULL,
        [RunKey] NVARCHAR(512) NULL,
        [Number] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Newsletters_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Newsletters_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_Newsletters] PRIMARY KEY ([NewsletterId]),
        CONSTRAINT [FK_com_Newsletters_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_Newsletters_Tenant] ON [com].[Newsletters] ([TenantId]);
END;
GO
