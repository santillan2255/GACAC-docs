-- com.Comments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.Comments', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[Comments] (
        [CommentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [PostId] UNIQUEIDENTIFIER NOT NULL,
        [ParentId] UNIQUEIDENTIFIER NULL,
        [Text] NVARCHAR(512) NOT NULL,
        [TextDisplayed] NVARCHAR(512) NOT NULL,
        [Media] NVARCHAR(MAX) NULL,
        [MentionsId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ModerationJson] NVARCHAR(MAX) NOT NULL,
        [AdminReplyJson] NVARCHAR(MAX) NULL,
        [EditHistoryJson] NVARCHAR(MAX) NOT NULL,
        [ReportsCount] INT NOT NULL,
        [GuidelinesVersion] NVARCHAR(512) NOT NULL,
        [ClientMutationId] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Comments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Comments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_Comments] PRIMARY KEY ([CommentId]),
        CONSTRAINT [FK_com_Comments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_Comments_Tenant] ON [com].[Comments] ([TenantId]);
END;
GO
