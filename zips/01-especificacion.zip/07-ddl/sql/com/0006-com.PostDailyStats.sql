-- com.PostDailyStats — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.PostDailyStats', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[PostDailyStats] (
        [PostDailyStatId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [PostId] UNIQUEIDENTIFIER NOT NULL,
        [Date] NVARCHAR(512) NOT NULL,
        [Impressions] INT NOT NULL,
        [Views] INT NOT NULL,
        [UniqueViewers] INT NOT NULL,
        [ReactionsByKey] NVARCHAR(512) NOT NULL,
        [Comments] INT NOT NULL,
        [Shares] INT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PostDailyStats_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PostDailyStats_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_PostDailyStats] PRIMARY KEY ([PostDailyStatId]),
        CONSTRAINT [FK_com_PostDailyStats_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_PostDailyStats_Tenant] ON [com].[PostDailyStats] ([TenantId]);
END;
GO
