-- com.SurveyInvitations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.SurveyInvitations', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[SurveyInvitations] (
        [SurveyInvitationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SurveyId] UNIQUEIDENTIFIER NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [UserId] UNIQUEIDENTIFIER NULL,
        [SourceEventId] UNIQUEIDENTIFIER NULL,
        [IdempotencyKey] NVARCHAR(512) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Channels] VARCHAR(64) NULL,
        [CommunicationIdsId] UNIQUEIDENTIFIER NULL,
        [SampledIn] BIT NULL,
        [ExpiresAt] DATETIME2(7) NULL,
        [RemindersSent] INT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SurveyInvitations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SurveyInvitations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_SurveyInvitations] PRIMARY KEY ([SurveyInvitationId]),
        CONSTRAINT [FK_com_SurveyInvitations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_SurveyInvitations_Tenant] ON [com].[SurveyInvitations] ([TenantId]);
END;
GO
