-- com.ModerationRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.ModerationRules', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[ModerationRules] (
        [ModerationRuleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [Config] NVARCHAR(MAX) NULL,
        [Action] VARCHAR(64) NULL,
        [AppliesTo] VARCHAR(64) NULL,
        [CategoryIdsId] UNIQUEIDENTIFIER NULL,
        [Priority] INT NULL,
        [Active] BIT NULL,
        [RuleVersion] INT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [PolicyId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_ModerationRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_ModerationRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_ModerationRules] PRIMARY KEY ([ModerationRuleId]),
        CONSTRAINT [FK_com_ModerationRules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_ModerationRules_Tenant] ON [com].[ModerationRules] ([TenantId]);
END;
GO
