-- com.SurveyTemplates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.SurveyTemplates', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[SurveyTemplates] (
        [SurveyTemplateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [Purpose] VARCHAR(64) NULL,
        [Questions] NVARCHAR(MAX) NULL,
        [Pages] NVARCHAR(MAX) NULL,
        [Scoring] NVARCHAR(MAX) NULL,
        [Consent] NVARCHAR(MAX) NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NULL,
        [PlatformTemplateId] UNIQUEIDENTIFIER NULL,
        [Active] BIT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SurveyTemplates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SurveyTemplates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_SurveyTemplates] PRIMARY KEY ([SurveyTemplateId]),
        CONSTRAINT [FK_com_SurveyTemplates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_SurveyTemplates_Tenant] ON [com].[SurveyTemplates] ([TenantId]);
END;
GO
