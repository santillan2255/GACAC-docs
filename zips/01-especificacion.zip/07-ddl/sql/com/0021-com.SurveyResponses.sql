-- com.SurveyResponses — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.SurveyResponses', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[SurveyResponses] (
        [SurveyResponsId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SurveyId] UNIQUEIDENTIFIER NOT NULL,
        [SurveyVersion] INT NULL,
        [InvitationId] UNIQUEIDENTIFIER NULL,
        [FieldAssignmentId] UNIQUEIDENTIFIER NULL,
        [UserId] UNIQUEIDENTIFIER NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [RespondentKey] NVARCHAR(512) NULL,
        [GuestKey] NVARCHAR(512) NULL,
        [GuestLabel] NVARCHAR(512) NULL,
        [Answers] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [StartedAt] DATETIME2(7) NULL,
        [LastSavedAt] DATETIME2(7) NULL,
        [SubmittedAt] DATETIME2(7) NULL,
        [Channel] VARCHAR(64) NOT NULL,
        [Device] NVARCHAR(MAX) NULL,
        [AttemptNumber] INT NOT NULL,
        [InvalidReason] NVARCHAR(512) NULL,
        [ScoreTotal] INT NOT NULL,
        [ScoreByGroup] NVARCHAR(MAX) NOT NULL,
        [ScoreBand] NVARCHAR(512) NOT NULL,
        [ConsentAcceptedAt] DATETIME2(7) NULL,
        [ConsentVersion] NVARCHAR(512) NULL,
        [Alerts] NVARCHAR(MAX) NULL,
        [Context] NVARCHAR(MAX) NULL,
        [ClientMutationId] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SurveyResponses_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_SurveyResponses_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_SurveyResponses] PRIMARY KEY ([SurveyResponsId]),
        CONSTRAINT [FK_com_SurveyResponses_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_SurveyResponses_Tenant] ON [com].[SurveyResponses] ([TenantId]);
END;
GO
