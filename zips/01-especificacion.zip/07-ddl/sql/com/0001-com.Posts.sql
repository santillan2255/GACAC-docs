-- com.Posts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.Posts', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[Posts] (
        [PostId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Post] NVARCHAR(512) NULL,
        [WEB_NOVEDADES] NVARCHAR(512) NULL,
        [NOTI_COOP] NVARCHAR(512) NULL,
        [Title] NVARCHAR(512) NOT NULL,
        [Body] NVARCHAR(512) NULL,
        [BodyText] NVARCHAR(512) NOT NULL,
        [Type] VARCHAR(64) NOT NULL,
        [CategoryId] UNIQUEIDENTIFIER NULL,
        [Section] NVARCHAR(512) NULL,
        [Layout] VARCHAR(64) NOT NULL,
        [Channels] VARCHAR(64) NOT NULL,
        [Origin] VARCHAR(64) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Priority] INT NULL,
        [ApprovalJson] NVARCHAR(MAX) NULL,
        [Audience] NVARCHAR(MAX) NOT NULL,
        [AudienceSnapshotId] UNIQUEIDENTIFIER NOT NULL,
        [AudienceSegmentId] UNIQUEIDENTIFIER NULL,
        [Slug] NVARCHAR(512) NOT NULL,
        [Notify] BIT NULL,
        [CommentModerationMode] VARCHAR(64) NOT NULL,
        [KbJson] NVARCHAR(MAX) NULL,
        [GreetingJson] NVARCHAR(MAX) NULL,
        [AiJson] NVARCHAR(MAX) NULL,
        [PiiWarningsJson] NVARCHAR(MAX) NOT NULL,
        [Counters] INT NOT NULL,
        [CopiedFromPostId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Posts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Posts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_Posts] PRIMARY KEY ([PostId]),
        CONSTRAINT [FK_com_Posts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_Posts_Tenant] ON [com].[Posts] ([TenantId]);
END;
GO
