-- com.EventRegistrations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.EventRegistrations', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[EventRegistrations] (
        [EventRegistrationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [EventId] UNIQUEIDENTIFIER NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NOT NULL,
        [UserId] UNIQUEIDENTIFIER NULL,
        [Companions] INT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [WaitlistPosition] INT NOT NULL,
        [QrToken] NVARCHAR(512) NULL,
        [CheckedInAt] DATETIME2(7) NULL,
        [CheckedInById] UNIQUEIDENTIFIER NULL,
        [ClientMutationId] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_EventRegistrations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_EventRegistrations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_EventRegistrations] PRIMARY KEY ([EventRegistrationId]),
        CONSTRAINT [FK_com_EventRegistrations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_EventRegistrations_Tenant] ON [com].[EventRegistrations] ([TenantId]);
END;
GO
