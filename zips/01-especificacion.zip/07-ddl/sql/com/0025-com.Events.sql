-- com.Events — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.Events', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[Events] (
        [EventId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Title] NVARCHAR(512) NOT NULL,
        [Description] NVARCHAR(512) NULL,
        [Type] VARCHAR(64) NULL,
        [StartsAt] DATETIME2(7) NULL,
        [EndsAt] DATETIME2(7) NULL,
        [Timezone] NVARCHAR(512) NULL,
        [Location] NVARCHAR(MAX) NULL,
        [Capacity] INT NULL,
        [RegistrationMode] VARCHAR(64) NULL,
        [MaxCompanions] INT NULL,
        [WaitlistEnabled] BIT NULL,
        [Audience] NVARCHAR(MAX) NULL,
        [Cover] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Reminders] NVARCHAR(MAX) NULL,
        [PostId] UNIQUEIDENTIFIER NULL,
        [ChangeLog] NVARCHAR(MAX) NULL,
        [Counters] NVARCHAR(MAX) NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Events_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Events_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_Events] PRIMARY KEY ([EventId]),
        CONSTRAINT [FK_com_Events_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_Events_Tenant] ON [com].[Events] ([TenantId]);
END;
GO
