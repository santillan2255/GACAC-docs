-- com.AppNotifications — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.AppNotifications', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[AppNotifications] (
        [AppNotificationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [MembershipId] UNIQUEIDENTIFIER NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [Title] NVARCHAR(512) NOT NULL,
        [Body] NVARCHAR(512) NULL,
        [Link] NVARCHAR(512) NULL,
        [Image] NVARCHAR(MAX) NULL,
        [RefType] NVARCHAR(512) NULL,
        [RefId] UNIQUEIDENTIFIER NULL,
        [SenderUserId] UNIQUEIDENTIFIER NULL,
        [SenderDisplay] NVARCHAR(512) NULL,
        [CommunicationId] UNIQUEIDENTIFIER NULL,
        [ReadAt] DATETIME2(7) NULL,
        [DismissedAt] DATETIME2(7) NULL,
        [ActionPending] BIT NULL,
        [ValidUntil] DATETIME2(7) NULL,
        [DedupeKey] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AppNotifications_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AppNotifications_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_AppNotifications] PRIMARY KEY ([AppNotificationId]),
        CONSTRAINT [FK_com_AppNotifications_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_AppNotifications_Tenant] ON [com].[AppNotifications] ([TenantId]);
END;
GO
