-- com.Surveys — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.Surveys', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[Surveys] (
        [SurveyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Purpose] VARCHAR(64) NOT NULL,
        [TriggerJson] NVARCHAR(MAX) NULL,
        [QuestionsJson] NVARCHAR(MAX) NOT NULL,
        [PagesJson] NVARCHAR(MAX) NULL,
        [SurveyVersion] INT NOT NULL,
        [VersionHistoryJson] NVARCHAR(MAX) NOT NULL,
        [Audience] NVARCHAR(MAX) NOT NULL,
        [AudienceSnapshotId] UNIQUEIDENTIFIER NOT NULL,
        [PresentationJson] NVARCHAR(MAX) NOT NULL,
        [Anonymous] BIT NOT NULL,
        [VoterUnit] VARCHAR(64) NOT NULL,
        [ResultVisibility] VARCHAR(64) NULL,
        [NonBindingNotice] BIT NOT NULL,
        [ConsentJson] NVARCHAR(MAX) NULL,
        [ScoringJson] NVARCHAR(MAX) NULL,
        [RemindersJson] NVARCHAR(MAX) NULL,
        [ReportScheduleJson] NVARCHAR(MAX) NULL,
        [PeriodicJson] NVARCHAR(MAX) NULL,
        [SamplingJson] NVARCHAR(MAX) NULL,
        [ExternalJson] NVARCHAR(MAX) NULL,
        [PrintQr] BIT NULL,
        [ExportAuditJson] NVARCHAR(MAX) NOT NULL,
        [AiCacheJson] NVARCHAR(MAX) NOT NULL,
        [ExternalId] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Surveys_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_Surveys_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_Surveys] PRIMARY KEY ([SurveyId]),
        CONSTRAINT [FK_com_Surveys_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_Surveys_Tenant] ON [com].[Surveys] ([TenantId]);
END;
GO
