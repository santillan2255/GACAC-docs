-- com.ModerationPolicies — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.ModerationPolicies', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[ModerationPolicies] (
        [ModerationPolicyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Scope: tenant] NVARCHAR(512) NULL,
        [Scope: category] NVARCHAR(512) NULL,
        [CategoryId] NVARCHAR(512) NULL,
        [CommentsEnabled] BIT NULL,
        [DefaultMode] VARCHAR(64) NULL,
        [AiEnabled] BIT NULL,
        [AiConnectorId] UNIQUEIDENTIFIER NULL,
        [RiskThresholds] NVARCHAR(MAX) NULL,
        [CategoryActions] NVARCHAR(MAX) NULL,
        [ReportThreshold] INT NULL,
        [MaxCommentsPerHour] INT NULL,
        [LinkPolicy] VARCHAR(64) NULL,
        [MaxLength] INT NULL,
        [ImageCommentsEnabled] BIT NULL,
        [GifEnabled] BIT NULL,
        [AutoCloseDays] INT NULL,
        [SanctionLadder] NVARCHAR(MAX) NULL,
        [ReincidenceWindowDays] INT NULL,
        [EvidenceRetentionDays] INT NULL,
        [SlaMinutes] NVARCHAR(MAX) NULL,
        [CurrentGuidelinesId] UNIQUEIDENTIFIER NULL,
        [Version] NVARCHAR(512) NULL,
        [PublishedAt] DATETIME2(7) NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_ModerationPolicies_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_ModerationPolicies_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_ModerationPolicies] PRIMARY KEY ([ModerationPolicyId]),
        CONSTRAINT [FK_com_ModerationPolicies_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_ModerationPolicies_Tenant] ON [com].[ModerationPolicies] ([TenantId]);
END;
GO
