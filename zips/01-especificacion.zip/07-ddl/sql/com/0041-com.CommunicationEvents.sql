-- com.CommunicationEvents — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.CommunicationEvents', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[CommunicationEvents] (
        [CommunicationEventId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CommunicationId] UNIQUEIDENTIFIER NOT NULL,
        [ProviderMessageId] NVARCHAR(512) NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [OccurredAt] DATETIME2(7) NULL,
        [ReceivedAt] DATETIME2(7) NOT NULL,
        [ProviderEventId] NVARCHAR(512) NOT NULL,
        [PayloadRef] NVARCHAR(512) NULL,
        [LinkId] UNIQUEIDENTIFIER NULL,
        [Provider] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunicationEvents_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_CommunicationEvents_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_CommunicationEvents] PRIMARY KEY ([CommunicationEventId]),
        CONSTRAINT [FK_com_CommunicationEvents_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_CommunicationEvents_Tenant] ON [com].[CommunicationEvents] ([TenantId]);
END;
GO
