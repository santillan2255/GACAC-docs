-- com.InvoiceMessages — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.InvoiceMessages', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[InvoiceMessages] (
        [InvoiceMessageId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CampaignId] UNIQUEIDENTIFIER NULL,
        [Text] NVARCHAR(512) NULL,
        [Area] VARCHAR(64) NULL,
        [Priority] INT NULL,
        [Audience] NVARCHAR(MAX) NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NULL,
        [Qr] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ApprovedById] UNIQUEIDENTIFIER NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [SegmentId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_InvoiceMessages_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_InvoiceMessages_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_InvoiceMessages] PRIMARY KEY ([InvoiceMessageId]),
        CONSTRAINT [FK_com_InvoiceMessages_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_InvoiceMessages_Tenant] ON [com].[InvoiceMessages] ([TenantId]);
END;
GO
