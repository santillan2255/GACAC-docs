-- com.AudienceSegments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.AudienceSegments', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[AudienceSegments] (
        [AudienceSegmentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Description] NVARCHAR(512) NULL,
        [OwnerUserId] UNIQUEIDENTIFIER NULL,
        [Visibility] VARCHAR(64) NULL,
        [Definition] NVARCHAR(MAX) NULL,
        [Evaluation] VARCHAR(64) NULL,
        [LastSnapshotId] UNIQUEIDENTIFIER NOT NULL,
        [LastCount] INT NOT NULL,
        [LastEvaluatedAt] DATETIME2(7) NOT NULL,
        [Active] BIT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AudienceSegments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AudienceSegments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_AudienceSegments] PRIMARY KEY ([AudienceSegmentId]),
        CONSTRAINT [FK_com_AudienceSegments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_AudienceSegments_Tenant] ON [com].[AudienceSegments] ([TenantId]);
END;
GO
