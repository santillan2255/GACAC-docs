-- com.PostReactions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.PostReactions', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[PostReactions] (
        [PostReactionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [PostId] UNIQUEIDENTIFIER NOT NULL,
        [MembershipId] UNIQUEIDENTIFIER NOT NULL,
        [Reaction] NVARCHAR(512) NULL,
        [ReactedAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PostReactions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_PostReactions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_PostReactions] PRIMARY KEY ([PostReactionId]),
        CONSTRAINT [FK_com_PostReactions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_PostReactions_Tenant] ON [com].[PostReactions] ([TenantId]);
END;
GO
