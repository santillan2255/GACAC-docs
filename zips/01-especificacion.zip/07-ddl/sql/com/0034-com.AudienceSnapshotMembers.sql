-- com.AudienceSnapshotMembers — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'com.AudienceSnapshotMembers', N'U') IS NULL
BEGIN
    CREATE TABLE [com].[AudienceSnapshotMembers] (
        [AudienceSnapshotMemberId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SnapshotId] UNIQUEIDENTIFIER NOT NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [AccountId] UNIQUEIDENTIFIER NULL,
        [ContractId] UNIQUEIDENTIFIER NULL,
        [UserId] UNIQUEIDENTIFIER NULL,
        [ResolvedChannels] VARCHAR(64) NULL,
        [ExcludedReason] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AudienceSnapshotMembers_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_com_AudienceSnapshotMembers_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_com_AudienceSnapshotMembers] PRIMARY KEY ([AudienceSnapshotMemberId]),
        CONSTRAINT [FK_com_AudienceSnapshotMembers_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_com_AudienceSnapshotMembers_Tenant] ON [com].[AudienceSnapshotMembers] ([TenantId]);
END;
GO
