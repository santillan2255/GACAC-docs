-- fac.ConsumptionChartGroups — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.ConsumptionChartGroups', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[ConsumptionChartGroups] (
        [ConsumptionChartGroupId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [GroupCode] NVARCHAR(512) NULL,
        [Description] NVARCHAR(512) NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NULL,
        [Periods] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_ConsumptionChartGroups_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_ConsumptionChartGroups_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_ConsumptionChartGroups] PRIMARY KEY ([ConsumptionChartGroupId]),
        CONSTRAINT [FK_fac_ConsumptionChartGroups_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_ConsumptionChartGroups_Tenant] ON [fac].[ConsumptionChartGroups] ([TenantId]);
END;
GO
