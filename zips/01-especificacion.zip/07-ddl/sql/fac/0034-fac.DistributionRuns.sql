-- fac.DistributionRuns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.DistributionRuns', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[DistributionRuns] (
        [DistributionRunId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [BillingRunId] UNIQUEIDENTIFIER NOT NULL,
        [ChannelsJson] NVARCHAR(MAX) NULL,
        [Grouping] VARCHAR(64) NULL,
        [OrderBy] NVARCHAR(MAX) NULL,
        [BatchSize] NVARCHAR(MAX) NULL,
        [WaitSeconds] NVARCHAR(MAX) NULL,
        [PrintOptions] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Counts] NVARCHAR(MAX) NULL,
        [OutputDocumentIdsId] UNIQUEIDENTIFIER NULL,
        [Draft → running → completed | completedWithIssues] NVARCHAR(512) NULL,
        [Running ⇄ paused] NVARCHAR(512) NULL,
        [Draft → cancelled] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_DistributionRuns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_DistributionRuns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_DistributionRuns] PRIMARY KEY ([DistributionRunId]),
        CONSTRAINT [FK_fac_DistributionRuns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_DistributionRuns_Tenant] ON [fac].[DistributionRuns] ([TenantId]);
END;
GO
