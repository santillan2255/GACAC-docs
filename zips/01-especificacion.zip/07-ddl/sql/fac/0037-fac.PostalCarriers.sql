-- fac.PostalCarriers — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.PostalCarriers', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[PostalCarriers] (
        [PostalCarrierId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NULL,
        [Amount] NVARCHAR(MAX) NULL,
        [Provider] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_PostalCarriers_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_PostalCarriers_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_PostalCarriers] PRIMARY KEY ([PostalCarrierId]),
        CONSTRAINT [FK_fac_PostalCarriers_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_PostalCarriers_Tenant] ON [fac].[PostalCarriers] ([TenantId]);
END;
GO
