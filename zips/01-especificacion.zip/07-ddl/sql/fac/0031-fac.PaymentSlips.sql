-- fac.PaymentSlips — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.PaymentSlips', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[PaymentSlips] (
        [PaymentSlipId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [LegalEntities] NVARCHAR(512) NULL,
        [Number] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [SummedSlip, installmentSlip] NVARCHAR(512) NULL,
        [SingleCoupon] NVARCHAR(512) NULL,
        [PaymentCoupons] NVARCHAR(512) NULL,
        [AccountId] NVARCHAR(512) NULL,
        [SlipGroupCode] NVARCHAR(512) NULL,
        [InvoiceIds] NVARCHAR(512) NULL,
        [InstallmentNo] NVARCHAR(512) NULL,
        [InstallmentCount] NVARCHAR(512) NULL,
        [DueDates { index, date, amount] NVARCHAR(512) NULL,
        [PaymentCodes] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active, superseded, cancelled, paid] NVARCHAR(512) NULL,
        [Paid] NVARCHAR(512) NULL,
        [SupersededById] NVARCHAR(512) NULL,
        [History] NVARCHAR(512) NULL,
        [{tenantId, legalEntityId, number}] NVARCHAR(512) NULL,
        [{tenantId, number}] NVARCHAR(512) NULL,
        [TALONFAC] NVARCHAR(512) NULL,
        [TALONFAC_HST] NVARCHAR(512) NULL,
        [InvoiceIdsId] UNIQUEIDENTIFIER NULL,
        [PaymentCodesJson] NVARCHAR(MAX) NULL,
        [HistoryJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_PaymentSlips_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_PaymentSlips_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_PaymentSlips] PRIMARY KEY ([PaymentSlipId]),
        CONSTRAINT [FK_fac_PaymentSlips_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_PaymentSlips_Tenant] ON [fac].[PaymentSlips] ([TenantId]);
END;
GO
