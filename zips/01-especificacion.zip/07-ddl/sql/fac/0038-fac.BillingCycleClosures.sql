-- fac.BillingCycleClosures — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingCycleClosures', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingCycleClosures] (
        [BillingCycleClosureId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [RunIdsJson] NVARCHAR(MAX) NOT NULL,
        [ReconciliationJson] NVARCHAR(MAX) NOT NULL,
        [TotalsJson] NVARCHAR(MAX) NOT NULL,
        [CarriedOverExceptionsJson] NVARCHAR(MAX) NULL,
        [NumberRangesJson] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ApprovalsJson] NVARCHAR(MAX) NULL,
        [ActaDocumentId] UNIQUEIDENTIFIER NULL,
        [ReopenJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingCycleClosures_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingCycleClosures_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingCycleClosures] PRIMARY KEY ([BillingCycleClosureId]),
        CONSTRAINT [FK_fac_BillingCycleClosures_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingCycleClosures_Tenant] ON [fac].[BillingCycleClosures] ([TenantId]);
END;
GO
