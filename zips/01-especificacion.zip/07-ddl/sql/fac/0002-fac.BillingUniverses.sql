-- fac.BillingUniverses — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingUniverses', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingUniverses] (
        [BillingUniversId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [CriteriaJson] NVARCHAR(MAX) NULL,
        [MembersJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [RecordedAt] DATETIME2(7) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingUniverses_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingUniverses_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingUniverses] PRIMARY KEY ([BillingUniversId]),
        CONSTRAINT [FK_fac_BillingUniverses_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingUniverses_Tenant] ON [fac].[BillingUniverses] ([TenantId]);
END;
GO
