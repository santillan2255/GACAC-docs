-- fac.BillingImportRows — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingImportRows', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingImportRows] (
        [BillingImportRowId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ImportId] UNIQUEIDENTIFIER NOT NULL,
        [RowNo] INT NOT NULL,
        [RawJson] NVARCHAR(MAX) NULL,
        [Mapped] NVARCHAR(MAX) NULL,
        [ErrorsJson] NVARCHAR(MAX) NULL,
        [ResultRef] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingImportRows_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingImportRows_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingImportRows] PRIMARY KEY ([BillingImportRowId]),
        CONSTRAINT [FK_fac_BillingImportRows_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingImportRows_Tenant] ON [fac].[BillingImportRows] ([TenantId]);
END;
GO
