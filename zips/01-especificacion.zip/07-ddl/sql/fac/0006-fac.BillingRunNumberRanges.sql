-- fac.BillingRunNumberRanges — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingRunNumberRanges', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingRunNumberRanges] (
        [BillingRunNumberRangeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [RunId] NVARCHAR(512) NULL,
        [VoucherTypeId] NVARCHAR(512) NULL,
        [NumberingVoucherTypeId] NVARCHAR(512) NULL,
        [PointOfSaleId] NVARCHAR(512) NULL,
        [FromNumber] NVARCHAR(512) NULL,
        [ToNumber] NVARCHAR(512) NULL,
        [Count] NVARCHAR(512) NULL,
        [AuthorizationType] NVARCHAR(512) NULL,
        [CAE, CAEA, CAI, CESP, none] NVARCHAR(512) NULL,
        [RequiresAuthorization] NVARCHAR(512) NULL,
        [BlockNo] NVARCHAR(512) NULL,
        [Releases { number, invoiceId, reason: arcaRejected|sequenceRelease, releasedAt, reassignedNumber }] NVARCHAR(512) NULL,
        [{tenantId, runId}] NVARCHAR(512) NULL,
        [FACTMES_COMP] NVARCHAR(512) NULL,
        [ReleasesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingRunNumberRanges_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingRunNumberRanges_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingRunNumberRanges] PRIMARY KEY ([BillingRunNumberRangeId]),
        CONSTRAINT [FK_fac_BillingRunNumberRanges_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingRunNumberRanges_Tenant] ON [fac].[BillingRunNumberRanges] ([TenantId]);
END;
GO
