-- fac.BilledPeriods — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BilledPeriods', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BilledPeriods] (
        [BilledPeriodId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ContractId] NVARCHAR(512) NULL,
        [ServiceId] NVARCHAR(512) NULL,
        [Period] NVARCHAR(512) NULL,
        [YYYY-MM] NVARCHAR(512) NULL,
        [{year, month}] NVARCHAR(512) NULL,
        [Sequence] NVARCHAR(512) NULL,
        [InvoiceId] NVARCHAR(512) NULL,
        [ServiceBlockId] NVARCHAR(512) NULL,
        [RunId] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active, released] NVARCHAR(512) NULL,
        [ReleasedByInvoiceId] NVARCHAR(512) NULL,
        [ReleasedAt] DATETIME2(7) NULL,
        [{tenantId, contractId, serviceId, period, sequence}] NVARCHAR(512) NULL,
        [Status = active] NVARCHAR(512) NULL,
        [PeriodYear] NVARCHAR(512) NULL,
        [PeriodMonth] NVARCHAR(512) NULL,
        [SERSOCULT_FAC] NVARCHAR(512) NULL,
        [SEC_PER] NVARCHAR(512) NULL,
        [CNT_FAC] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BilledPeriods_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BilledPeriods_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BilledPeriods] PRIMARY KEY ([BilledPeriodId]),
        CONSTRAINT [FK_fac_BilledPeriods_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BilledPeriods_Tenant] ON [fac].[BilledPeriods] ([TenantId]);
END;
GO
