-- fac.BarcodeAssignments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BarcodeAssignments', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BarcodeAssignments] (
        [BarcodeAssignmentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [FormatId] UNIQUEIDENTIFIER NOT NULL,
        [CollectorCode] NVARCHAR(512) NOT NULL,
        [DocumentTypesJson] NVARCHAR(MAX) NOT NULL,
        [AgreementCode] NVARCHAR(512) NULL,
        [IsDefault] BIT NULL,
        [PrintOnInvoice] BIT NULL,
        [ReadAtCounter] BIT NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BarcodeAssignments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BarcodeAssignments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BarcodeAssignments] PRIMARY KEY ([BarcodeAssignmentId]),
        CONSTRAINT [FK_fac_BarcodeAssignments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BarcodeAssignments_Tenant] ON [fac].[BarcodeAssignments] ([TenantId]);
END;
GO
