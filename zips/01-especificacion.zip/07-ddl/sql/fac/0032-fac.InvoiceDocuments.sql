-- fac.InvoiceDocuments — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.InvoiceDocuments', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[InvoiceDocuments] (
        [InvoiceDocumentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [InvoiceId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [StoredFileId] UNIQUEIDENTIFIER NOT NULL,
        [Sha256] NVARCHAR(MAX) NULL,
        [TemplateId] UNIQUEIDENTIFIER NULL,
        [TemplateVersion] INT NOT NULL,
        [GeneratedAt] DATETIME2(7) NULL,
        [Pages] NVARCHAR(MAX) NULL,
        [PasswordProtected] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceDocuments_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceDocuments_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_InvoiceDocuments] PRIMARY KEY ([InvoiceDocumentId]),
        CONSTRAINT [FK_fac_InvoiceDocuments_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_InvoiceDocuments_Tenant] ON [fac].[InvoiceDocuments] ([TenantId]);
END;
GO
