-- fac.BillingTemplates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingTemplates', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingTemplates] (
        [BillingTemplateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TemplateVersion] INT NOT NULL,
        [InvoiceClassCode] NVARCHAR(512) NOT NULL,
        [VoucherFamily] VARCHAR(64) NOT NULL,
        [ServicesJson] NVARCHAR(MAX) NOT NULL,
        [InstallmentsJson] NVARCHAR(MAX) NULL,
        [DueDateRulesJson] NVARCHAR(MAX) NOT NULL,
        [DueDateSchemeId] UNIQUEIDENTIFIER NULL,
        [OrderBy] VARCHAR(64) NOT NULL,
        [OptionsJson] NVARCHAR(MAX) NOT NULL,
        [PrintTemplateId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [PreviousVersionId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingTemplates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingTemplates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingTemplates] PRIMARY KEY ([BillingTemplateId]),
        CONSTRAINT [FK_fac_BillingTemplates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingTemplates_Tenant] ON [fac].[BillingTemplates] ([TenantId]);
END;
GO
