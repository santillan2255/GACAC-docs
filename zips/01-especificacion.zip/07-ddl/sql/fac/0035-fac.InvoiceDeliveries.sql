-- fac.InvoiceDeliveries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.InvoiceDeliveries', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[InvoiceDeliveries] (
        [InvoiceDeliveryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [InvoiceId] NVARCHAR(512) NULL,
        [DistributionRunId] NVARCHAR(512) NULL,
        [Channel] NVARCHAR(512) NULL,
        [Destination] NVARCHAR(512) NULL,
        [CommunicationId] NVARCHAR(512) NULL,
        [ProviderMessageId] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Attempts] NVARCHAR(512) NULL,
        [LastError] NVARCHAR(512) NULL,
        [IdempotencyKey] NVARCHAR(512) NULL,
        [PostalPieceNo] NVARCHAR(512) NULL,
        [RouteId] NVARCHAR(512) NULL,
        [RouteSequence] NVARCHAR(512) NULL,
        [DeliveredAt] DATETIME2(7) NULL,
        [ReturnReason] NVARCHAR(512) NULL,
        [RecordedBy] NVARCHAR(512) NULL,
        [ClientMutationId] NVARCHAR(512) NULL,
        [{tenantId, invoiceId}] NVARCHAR(512) NULL,
        [{tenantId, distributionRunId, status}] NVARCHAR(512) NULL,
        [{tenantId, idempotencyKey}] NVARCHAR(512) NULL,
        [Pending → sent → delivered → read] NVARCHAR(512) NULL,
        [Sent → failed → pending] NVARCHAR(512) NULL,
        [PRM-FAC-130] NVARCHAR(512) NULL,
        [Sent → bounced] NVARCHAR(512) NULL,
        [Pending → printed → handedToRoute → delivered | returned] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceDeliveries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceDeliveries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_InvoiceDeliveries] PRIMARY KEY ([InvoiceDeliveryId]),
        CONSTRAINT [FK_fac_InvoiceDeliveries_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_InvoiceDeliveries_Tenant] ON [fac].[InvoiceDeliveries] ([TenantId]);
END;
GO
