-- fac.InvoiceTemplates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.InvoiceTemplates', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[InvoiceTemplates] (
        [InvoiceTemplateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [Engine] NVARCHAR(512) NULL,
        [Html-pdf] NVARCHAR(512) NULL,
        [Layout] NVARCHAR(512) NULL,
        [Assets] NVARCHAR(512) NULL,
        [SelectionRules { priority, match: {forced, voucherClass, invoiceClassCode, serviceId, voucherTypeId, taxCondition, prepaid, electronic, summedSlip, alternative}, }] NVARCHAR(512) NULL,
        [PreviewedAt] DATETIME2(7) NULL,
        [Status] NVARCHAR(512) NULL,
        [TemplateVersion] NVARCHAR(512) NULL,
        [DocumentTemplates] NVARCHAR(512) NULL,
        [TemplateVersions] NVARCHAR(512) NULL,
        [SelectionRules] NVARCHAR(512) NULL,
        [DocumentTemplateId] NVARCHAR(512) NULL,
        [AssetsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceTemplates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceTemplates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_InvoiceTemplates] PRIMARY KEY ([InvoiceTemplateId]),
        CONSTRAINT [FK_fac_InvoiceTemplates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_InvoiceTemplates_Tenant] ON [fac].[InvoiceTemplates] ([TenantId]);
END;
GO
