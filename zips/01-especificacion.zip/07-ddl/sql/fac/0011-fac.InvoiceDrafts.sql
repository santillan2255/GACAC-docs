-- fac.InvoiceDrafts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.InvoiceDrafts', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[InvoiceDrafts] (
        [InvoiceDraftId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Invoices] NVARCHAR(512) NULL,
        [Header] NVARCHAR(512) NULL,
        [Lines] NVARCHAR(512) NULL,
        [DueDates] NVARCHAR(512) NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [Origin] NVARCHAR(512) NULL,
        [SourceInvoiceId] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Editing, validated, discarded, issued] NVARCHAR(512) NULL,
        [IssuedInvoiceId] NVARCHAR(512) NULL,
        [ValidationResult] NVARCHAR(512) NULL,
        [{tenantId, createdBy, status}] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceDrafts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceDrafts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_InvoiceDrafts] PRIMARY KEY ([InvoiceDraftId]),
        CONSTRAINT [FK_fac_InvoiceDrafts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_InvoiceDrafts_Tenant] ON [fac].[InvoiceDrafts] ([TenantId]);
END;
GO
