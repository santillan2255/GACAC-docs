-- fac.NumberSequences — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.NumberSequences', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[NumberSequences] (
        [NumberSequenceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [NumberingVoucherTypeId] UNIQUEIDENTIFIER NOT NULL,
        [PointOfSaleId] UNIQUEIDENTIFIER NOT NULL,
        [LastNumber] INT NULL,
        [LastAuthorizedNumber] INT NOT NULL,
        [AuthorizationType] VARCHAR(64) NULL,
        [Cai] NVARCHAR(MAX) NULL,
        [BillingGroupId] UNIQUEIDENTIFIER NULL,
        [LastSyncedWithArca] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [BlockedReason] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_NumberSequences_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_NumberSequences_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_NumberSequences] PRIMARY KEY ([NumberSequenceId]),
        CONSTRAINT [FK_fac_NumberSequences_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_NumberSequences_Tenant] ON [fac].[NumberSequences] ([TenantId]);
END;
GO
