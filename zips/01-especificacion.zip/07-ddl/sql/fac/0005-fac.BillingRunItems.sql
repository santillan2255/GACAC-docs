-- fac.BillingRunItems — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingRunItems', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingRunItems] (
        [BillingRunItemId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [RunId] UNIQUEIDENTIFIER NOT NULL,
        [ItemCode] NVARCHAR(512) NOT NULL,
        [UniverseVersion] INT NOT NULL,
        [BillingMode] VARCHAR(64) NOT NULL,
        [ContractsJson] NVARCHAR(MAX) NOT NULL,
        [IsSample] BIT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ExclusionJson] NVARCHAR(MAX) NULL,
        [ExceptionIdsJson] NVARCHAR(MAX) NULL,
        [PrebillJson] NVARCHAR(MAX) NULL,
        [ComparisonJson] NVARCHAR(MAX) NULL,
        [WarningsJson] NVARCHAR(MAX) NULL,
        [InvoiceIdsJson] NVARCHAR(MAX) NULL,
        [IdempotencyKey] NVARCHAR(512) NOT NULL,
        [Attempts] INT NOT NULL,
        [LastErrorJson] NVARCHAR(MAX) NULL,
        [CarriedOverToRunId] UNIQUEIDENTIFIER NULL,
        [PreReviewJson] NVARCHAR(MAX) NULL,
        [ServiceDependenciesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingRunItems_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingRunItems_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingRunItems] PRIMARY KEY ([BillingRunItemId]),
        CONSTRAINT [FK_fac_BillingRunItems_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingRunItems_Tenant] ON [fac].[BillingRunItems] ([TenantId]);
END;
GO
