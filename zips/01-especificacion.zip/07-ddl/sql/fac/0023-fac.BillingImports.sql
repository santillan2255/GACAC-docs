-- fac.BillingImports — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingImports', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingImports] (
        [BillingImportId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Format] VARCHAR(64) NOT NULL,
        [StoredFileId] UNIQUEIDENTIFIER NOT NULL,
        [Destination] VARCHAR(64) NULL,
        [Period] NVARCHAR(512) NULL,
        [ConceptId] UNIQUEIDENTIFIER NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Counts] NVARCHAR(MAX) NULL,
        [FileHash] NVARCHAR(512) NOT NULL,
        [Uploaded → validated → confirmed → applied | failed] NVARCHAR(512) NULL,
        [Uploaded/validated → cancelled] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingImports_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingImports_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingImports] PRIMARY KEY ([BillingImportId]),
        CONSTRAINT [FK_fac_BillingImports_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingImports_Tenant] ON [fac].[BillingImports] ([TenantId]);
END;
GO
