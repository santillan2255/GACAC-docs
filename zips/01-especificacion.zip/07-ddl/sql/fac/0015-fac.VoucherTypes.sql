-- fac.VoucherTypes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.VoucherTypes', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[VoucherTypes] (
        [VoucherTypeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] INT NOT NULL,
        [ArcaCode] INT NULL,
        [Letter] VARCHAR(64) NOT NULL,
        [VoucherClass] VARCHAR(64) NOT NULL,
        [Direction] VARCHAR(64) NOT NULL,
        [ReversalVoucherTypeId] UNIQUEIDENTIFIER NULL,
        [SharesNumberingWithId] UNIQUEIDENTIFIER NULL,
        [TaxConditionRestriction] VARCHAR(64) NOT NULL,
        [AllowsZeroPointOfSale] BIT NOT NULL,
        [DefaultForOperation] VARCHAR(64) NULL,
        [Family] NVARCHAR(512) NULL,
        [Active] BIT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_VoucherTypes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_VoucherTypes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_VoucherTypes] PRIMARY KEY ([VoucherTypeId]),
        CONSTRAINT [FK_fac_VoucherTypes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_VoucherTypes_Tenant] ON [fac].[VoucherTypes] ([TenantId]);
END;
GO
