-- fac.MassOperationItems — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.MassOperationItems', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[MassOperationItems] (
        [MassOperationItemId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [OperationId] UNIQUEIDENTIFIER NOT NULL,
        [TargetType] VARCHAR(64) NULL,
        [TargetId] UNIQUEIDENTIFIER NOT NULL,
        [BeforeJson] NVARCHAR(MAX) NULL,
        [AfterJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Reason] NVARCHAR(512) NULL,
        [NoteId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_MassOperationItems_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_MassOperationItems_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_MassOperationItems] PRIMARY KEY ([MassOperationItemId]),
        CONSTRAINT [FK_fac_MassOperationItems_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_MassOperationItems_Tenant] ON [fac].[MassOperationItems] ([TenantId]);
END;
GO
