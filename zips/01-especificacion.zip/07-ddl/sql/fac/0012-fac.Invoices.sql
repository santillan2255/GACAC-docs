-- fac.Invoices — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.Invoices', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[Invoices] (
        [InvoiceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [VoucherTypeId] UNIQUEIDENTIFIER NOT NULL,
        [VoucherClass] VARCHAR(64) NOT NULL,
        [ArcaVoucherCode] INT NULL,
        [Letter] VARCHAR(64) NOT NULL,
        [Direction] VARCHAR(64) NOT NULL,
        [Number] INT NOT NULL,
        [FullNumber] NVARCHAR(512) NOT NULL,
        [NumberAssignmentsJson] NVARCHAR(MAX) NULL,
        [IssueAttempt] INT NOT NULL,
        [EmissionSeq] INT NULL,
        [NumberSequenceId] UNIQUEIDENTIFIER NOT NULL,
        [Origin] VARCHAR(64) NOT NULL,
        [InvoiceClassCode] NVARCHAR(512) NOT NULL,
        [Period] NVARCHAR(512) NOT NULL,
        [BillingMode] VARCHAR(64) NOT NULL,
        [CustomerJson] NVARCHAR(MAX) NOT NULL,
        [IssueDate] DATETIME2(7) NOT NULL,
        [DueDatesJson] NVARCHAR(MAX) NOT NULL,
        [DueDateCapJson] NVARCHAR(MAX) NOT NULL,
        [LateAuthorizationGraceDays] INT NULL,
        [LateAuthorizationShiftJson] NVARCHAR(MAX) NULL,
        [NextDueDate] DATETIME2(7) NULL,
        [ServiceBlocksJson] NVARCHAR(MAX) NOT NULL,
        [LinesJson] NVARCHAR(MAX) NOT NULL,
        [TaxesJson] NVARCHAR(MAX) NULL,
        [TotalsJson] NVARCHAR(MAX) NOT NULL,
        [CommercialStatus] VARCHAR(64) NOT NULL,
        [FiscalJson] NVARCHAR(MAX) NOT NULL,
        [BlockJson] NVARCHAR(MAX) NULL,
        [ObligationsJson] NVARCHAR(MAX) NOT NULL,
        [PaymentCodesJson] NVARCHAR(MAX) NULL,
        [PaymentSlipIdsJson] NVARCHAR(MAX) NULL,
        [DocumentIdsJson] NVARCHAR(MAX) NULL,
        [RelationsSummaryJson] NVARCHAR(MAX) NULL,
        [Observations] NVARCHAR(512) NULL,
        [PrintMessagesJson] NVARCHAR(MAX) NULL,
        [FlagsJson] NVARCHAR(MAX) NULL,
        [CalculationTraceJson] NVARCHAR(MAX) NOT NULL,
        [IdempotencyKey] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_Invoices_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_Invoices_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_Invoices] PRIMARY KEY ([InvoiceId]),
        CONSTRAINT [FK_fac_Invoices_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_Invoices_Tenant] ON [fac].[Invoices] ([TenantId]);
END;
GO
