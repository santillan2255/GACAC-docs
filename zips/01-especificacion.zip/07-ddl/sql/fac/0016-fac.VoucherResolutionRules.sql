-- fac.VoucherResolutionRules — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.VoucherResolutionRules', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[VoucherResolutionRules] (
        [VoucherResolutionRuleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TaxCondition] NVARCHAR(512) NULL,
        [InvoiceVoucherTypeId] NVARCHAR(512) NULL,
        [DebitNoteVoucherTypeId] NVARCHAR(512) NULL,
        [CreditNoteVoucherTypeId] NVARCHAR(512) NULL,
        [PublicServiceInvoiceVoucherTypeId] NVARCHAR(512) NULL,
        [PublicServiceCreditVoucherTypeId] NVARCHAR(512) NULL,
        [MiPymeInvoice/Debit/CreditVoucherTypeId] NVARCHAR(512) NULL,
        [TicketVoucherTypeId] NVARCHAR(512) NULL,
        [MatrixVersion] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ServiceOverrides {serviceId, debitVoucherTypeId, creditVoucherTypeId}] NVARCHAR(512) NULL,
        [SERVICIOCOM_FAC] NVARCHAR(512) NULL,
        [COM_CRE] NVARCHAR(512) NULL,
        [SITIVA] NVARCHAR(512) NULL,
        [VatConditionSettingId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_VoucherResolutionRules_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_VoucherResolutionRules_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_VoucherResolutionRules] PRIMARY KEY ([VoucherResolutionRuleId]),
        CONSTRAINT [FK_fac_VoucherResolutionRules_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_VoucherResolutionRules_Tenant] ON [fac].[VoucherResolutionRules] ([TenantId]);
END;
GO
