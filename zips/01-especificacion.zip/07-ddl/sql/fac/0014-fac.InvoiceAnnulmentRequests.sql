-- fac.InvoiceAnnulmentRequests — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.InvoiceAnnulmentRequests', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[InvoiceAnnulmentRequests] (
        [InvoiceAnnulmentRequestId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [InvoiceIds] NVARCHAR(512) NULL,
        [Mode] NVARCHAR(512) NULL,
        [Annul, reverse, partialCredit, debitAdjustment] NVARCHAR(512) NULL,
        [Options] NVARCHAR(512) NULL,
        [{ revertConsumptions, allowRebilling, releaseCreditsDebits, revertStock, dueDates }] NVARCHAR(512) NULL,
        [Reason] NVARCHAR(512) NULL,
        [EvidenceIds] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft, pendingApproval, approved, rejected, executing, executed, partiallyExecuted, failed] NVARCHAR(512) NULL,
        [WorkflowInstanceId] NVARCHAR(512) NULL,
        [WorkflowId] NVARCHAR(512) NULL,
        [Excluded {invoiceId, reason}] NVARCHAR(512) NULL,
        [ResultInvoiceIds] NVARCHAR(512) NULL,
        [FiscalCheck] NVARCHAR(512) NULL,
        [{ checkedAt, result }] NVARCHAR(512) NULL,
        [ClsAnulacionFacturas] NVARCHAR(512) NULL,
        [RetroactiveDiffRunsAdjustmentRequestIds] NVARCHAR(512) NULL,
        [PartialCredit] NVARCHAR(512) NULL,
        [DebitAdjustment] NVARCHAR(512) NULL,
        [InvoiceIdsId] UNIQUEIDENTIFIER NULL,
        [EvidenceIdsId] UNIQUEIDENTIFIER NULL,
        [ResultInvoiceIdsId] UNIQUEIDENTIFIER NULL,
        [Number] NVARCHAR(512) NOT NULL,
        [Draft → pendingApproval → approved → executing → executed | partiallyExecuted | failed] NVARCHAR(512) NULL,
        [PendingApproval → rejected] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceAnnulmentRequests_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceAnnulmentRequests_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_InvoiceAnnulmentRequests] PRIMARY KEY ([InvoiceAnnulmentRequestId]),
        CONSTRAINT [FK_fac_InvoiceAnnulmentRequests_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_InvoiceAnnulmentRequests_Tenant] ON [fac].[InvoiceAnnulmentRequests] ([TenantId]);
END;
GO
