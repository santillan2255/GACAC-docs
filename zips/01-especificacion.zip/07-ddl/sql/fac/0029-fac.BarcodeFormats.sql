-- fac.BarcodeFormats — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BarcodeFormats', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BarcodeFormats] (
        [BarcodeFormatId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Scope] VARCHAR(64) NOT NULL,
        [Length] INT NOT NULL,
        [Alphanumeric] BIT NOT NULL,
        [DocumentsJson] NVARCHAR(MAX) NOT NULL,
        [SegmentsJson] NVARCHAR(MAX) NOT NULL,
        [CheckDigitsJson] NVARCHAR(MAX) NULL,
        [DecodersJson] NVARCHAR(MAX) NULL,
        [FallbackFormatId] UNIQUEIDENTIFIER NULL,
        [DueDateCapacity] INT NOT NULL,
        [TestVectorsJson] NVARCHAR(MAX) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BarcodeFormats_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BarcodeFormats_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BarcodeFormats] PRIMARY KEY ([BarcodeFormatId]),
        CONSTRAINT [FK_fac_BarcodeFormats_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BarcodeFormats_Tenant] ON [fac].[BarcodeFormats] ([TenantId]);
END;
GO
