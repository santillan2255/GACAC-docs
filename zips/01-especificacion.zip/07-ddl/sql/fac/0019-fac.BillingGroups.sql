-- fac.BillingGroups — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingGroups', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingGroups] (
        [BillingGroupId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [TaxId] NVARCHAR(512) NOT NULL,
        [MembersJson] NVARCHAR(MAX) NOT NULL,
        [Periodicity] VARCHAR(64) NOT NULL,
        [DueDateSchemeId] UNIQUEIDENTIFIER NULL,
        [DeliveryChannelsJson] NVARCHAR(MAX) NULL,
        [VoucherTypeOverrideId] UNIQUEIDENTIFIER NULL,
        [ForceDebitNote] BIT NOT NULL,
        [FiscalValidationJson] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [GroupVersion] INT NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingGroups_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingGroups_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingGroups] PRIMARY KEY ([BillingGroupId]),
        CONSTRAINT [FK_fac_BillingGroups_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingGroups_Tenant] ON [fac].[BillingGroups] ([TenantId]);
END;
GO
