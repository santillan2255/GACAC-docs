-- fac.BillingExceptions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingExceptions', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingExceptions] (
        [BillingExceptionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Period] NVARCHAR(512) NOT NULL,
        [ReasonCode] NVARCHAR(512) NOT NULL,
        [Category] VARCHAR(64) NOT NULL,
        [Stage] VARCHAR(64) NOT NULL,
        [Severity] VARCHAR(64) NOT NULL,
        [Message] NVARCHAR(512) NOT NULL,
        [MissingDataJson] NVARCHAR(MAX) NULL,
        [ExternalCode] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [OwnerModule] VARCHAR(64) NOT NULL,
        [NextAction] NVARCHAR(512) NOT NULL,
        [DeepLink] NVARCHAR(512) NULL,
        [DueAt] DATETIME2(7) NULL,
        [ResolutionJson] NVARCHAR(MAX) NULL,
        [ReprocessRunId] UNIQUEIDENTIFIER NULL,
        [HistoryJson] NVARCHAR(MAX) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingExceptions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingExceptions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingExceptions] PRIMARY KEY ([BillingExceptionId]),
        CONSTRAINT [FK_fac_BillingExceptions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingExceptions_Tenant] ON [fac].[BillingExceptions] ([TenantId]);
END;
GO
