-- fac.InvoiceExternalData — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.InvoiceExternalData', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[InvoiceExternalData] (
        [InvoiceExternalDataId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [InvoiceId] NVARCHAR(512) NULL,
        [AccountId] NVARCHAR(512) NULL,
        [ProviderCode] NVARCHAR(512) NULL,
        [Fields] NVARCHAR(512) NULL,
        [Items {description, amount}] NVARCHAR(512) NULL,
        [ImportId] NVARCHAR(512) NULL,
        [FAC_EXTRAS] NVARCHAR(512) NULL,
        [FAC_EXTRAS_ITEMS] NVARCHAR(512) NULL,
        [FieldsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceExternalData_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceExternalData_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_InvoiceExternalData] PRIMARY KEY ([InvoiceExternalDataId]),
        CONSTRAINT [FK_fac_InvoiceExternalData_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_InvoiceExternalData_Tenant] ON [fac].[InvoiceExternalData] ([TenantId]);
END;
GO
