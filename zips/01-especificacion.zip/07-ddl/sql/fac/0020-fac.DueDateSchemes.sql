-- fac.DueDateSchemes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.DueDateSchemes', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[DueDateSchemes] (
        [DueDateSchemeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [Scope] NVARCHAR(512) NULL,
        [{ serviceIds, cycleIds, invoiceClassCodes }] NVARCHAR(512) NULL,
        [DueCount] NVARCHAR(512) NULL,
        [Spacing { index, rule] NVARCHAR(512) NULL,
        [Mode] NVARCHAR(512) NULL,
        [FixedAmount, fixedPercentCompound, dailyPercent, byAmountRange, byDueIndex] NVARCHAR(512) NULL,
        [Rows { amountFrom, amountTo, dueIndexFrom, dueIndexTo, valueType: percent|fixed, value] NVARCHAR(512) NULL,
        [Compounding] NVARCHAR(512) NULL,
        [InterestConceptId] NVARCHAR(512) NULL,
        [IsDemo] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [SchemeVersion] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [TRAMASREC] NVARCHAR(512) NULL,
        [Spacing] NVARCHAR(512) NULL,
        [Rows] NVARCHAR(512) NULL,
        [DueDateSurchargeSchemes] NVARCHAR(512) NULL,
        [LateAuthorizationGraceDays] INT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_DueDateSchemes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_DueDateSchemes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_DueDateSchemes] PRIMARY KEY ([DueDateSchemeId]),
        CONSTRAINT [FK_fac_DueDateSchemes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_DueDateSchemes_Tenant] ON [fac].[DueDateSchemes] ([TenantId]);
END;
GO
