-- fac.BillingCycles — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingCycles', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingCycles] (
        [BillingCycleId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [ServiceId] UNIQUEIDENTIFIER NOT NULL,
        [UniverseId] UNIQUEIDENTIFIER NOT NULL,
        [TemplateId] UNIQUEIDENTIFIER NOT NULL,
        [Periodicity] VARCHAR(64) NOT NULL,
        [CalendarJson] NVARCHAR(MAX) NOT NULL,
        [DueDateSchemeId] UNIQUEIDENTIFIER NULL,
        [DeliveryDefaultsJson] NVARCHAR(MAX) NULL,
        [ApprovalPolicyJson] NVARCHAR(MAX) NOT NULL,
        [AutoCreateRun] BIT NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ConfigVersionId] UNIQUEIDENTIFIER NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingCycles_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingCycles_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingCycles] PRIMARY KEY ([BillingCycleId]),
        CONSTRAINT [FK_fac_BillingCycles_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingCycles_Tenant] ON [fac].[BillingCycles] ([TenantId]);
END;
GO
