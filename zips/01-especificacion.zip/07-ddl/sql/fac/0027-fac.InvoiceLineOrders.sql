-- fac.InvoiceLineOrders — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.InvoiceLineOrders', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[InvoiceLineOrders] (
        [InvoiceLineOrderId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Description] NVARCHAR(512) NULL,
        [Footer] NVARCHAR(MAX) NULL,
        [Order] INT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceLineOrders_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceLineOrders_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_InvoiceLineOrders] PRIMARY KEY ([InvoiceLineOrderId]),
        CONSTRAINT [FK_fac_InvoiceLineOrders_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_InvoiceLineOrders_Tenant] ON [fac].[InvoiceLineOrders] ([TenantId]);
END;
GO
