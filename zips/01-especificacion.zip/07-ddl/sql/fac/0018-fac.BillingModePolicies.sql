-- fac.BillingModePolicies — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingModePolicies', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingModePolicies] (
        [BillingModePolicyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [DefaultMode] NVARCHAR(512) NULL,
        [Separate, grouped] NVARCHAR(512) NULL,
        [Exceptions { scope: service|account|holder, refId, mode, validFromPeriod }] NVARCHAR(512) NULL,
        [PeriodicityRule] NVARCHAR(512) NULL,
        [NextGroupInvoice, separate, prorate] NVARCHAR(512) NULL,
        [MultipleSuppliesRule] NVARCHAR(512) NULL,
        [NegativeTotalPolicyByService { serviceId, policy: creditNote|futureCredit }] NVARCHAR(512) NULL,
        [PolicyVersion] NVARCHAR(512) NULL,
        [ValidFromPeriod] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingModePolicies_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingModePolicies_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingModePolicies] PRIMARY KEY ([BillingModePolicyId]),
        CONSTRAINT [FK_fac_BillingModePolicies_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingModePolicies_Tenant] ON [fac].[BillingModePolicies] ([TenantId]);
END;
GO
