-- fac.BillingRuns — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillingRuns', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillingRuns] (
        [BillingRunId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [CycleId] UNIQUEIDENTIFIER NULL,
        [ParentRunId] UNIQUEIDENTIFIER NULL,
        [ServiceIdsJson] NVARCHAR(MAX) NOT NULL,
        [Period] NVARCHAR(512) NOT NULL,
        [ServicePeriodsJson] NVARCHAR(MAX) NOT NULL,
        [Sequence] INT NOT NULL,
        [Target] VARCHAR(64) NOT NULL,
        [TargetAccountsJson] NVARCHAR(MAX) NULL,
        [FiltersJson] NVARCHAR(MAX) NULL,
        [IssueDate] DATETIME2(7) NOT NULL,
        [DueDatesJson] NVARCHAR(MAX) NOT NULL,
        [OrderBy] VARCHAR(64) NOT NULL,
        [OptionsJson] NVARCHAR(MAX) NOT NULL,
        [UniverseJson] NVARCHAR(MAX) NOT NULL,
        [RuleVersionsJson] NVARCHAR(MAX) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [AuthorizationPhase] VARCHAR(64) NOT NULL,
        [DistributionPhase] VARCHAR(64) NOT NULL,
        [CountersJson] NVARCHAR(MAX) NOT NULL,
        [TotalsJson] NVARCHAR(MAX) NULL,
        [ComparisonJson] NVARCHAR(MAX) NULL,
        [SampleJson] NVARCHAR(MAX) NULL,
        [ApprovalsJson] NVARCHAR(MAX) NULL,
        [ProgressJson] NVARCHAR(MAX) NULL,
        [PauseJson] NVARCHAR(MAX) NULL,
        [LockKey] NVARCHAR(512) NOT NULL,
        [JobIdsJson] NVARCHAR(MAX) NULL,
        [OverridesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingRuns_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillingRuns_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillingRuns] PRIMARY KEY ([BillingRunId]),
        CONSTRAINT [FK_fac_BillingRuns_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillingRuns_Tenant] ON [fac].[BillingRuns] ([TenantId]);
END;
GO
