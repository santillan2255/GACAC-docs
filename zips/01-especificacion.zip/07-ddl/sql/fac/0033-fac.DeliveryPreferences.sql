-- fac.DeliveryPreferences — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.DeliveryPreferences', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[DeliveryPreferences] (
        [DeliveryPreferenceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [HolderId] NVARCHAR(512) NULL,
        [AccountId] NVARCHAR(512) NULL,
        [BillingGroupId] NVARCHAR(512) NULL,
        [Channels] NVARCHAR(512) NULL,
        [Paper, email, whatsapp, app] NVARCHAR(512) NULL,
        [Emails] NVARCHAR(512) NULL,
        [Phones] NVARCHAR(512) NULL,
        [DigitalAdhesion] NVARCHAR(512) NULL,
        [{ adheredAt, source: portal|counter|migration, evidenceId }] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [{tenantId, holderId}] NVARCHAR(512) NULL,
        [EmailsJson] NVARCHAR(MAX) NULL,
        [PhonesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_DeliveryPreferences_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_DeliveryPreferences_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_DeliveryPreferences] PRIMARY KEY ([DeliveryPreferenceId]),
        CONSTRAINT [FK_fac_DeliveryPreferences_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_DeliveryPreferences_Tenant] ON [fac].[DeliveryPreferences] ([TenantId]);
END;
GO
