-- fac.BillableItems — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.BillableItems', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[BillableItems] (
        [BillableItemId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SourceModule] VARCHAR(64) NOT NULL,
        [SourceType] VARCHAR(64) NOT NULL,
        [SourceRefJson] NVARCHAR(MAX) NULL,
        [ConceptId] UNIQUEIDENTIFIER NOT NULL,
        [Description] NVARCHAR(512) NULL,
        [Amount] NVARCHAR(MAX) NOT NULL,
        [Period] NVARCHAR(512) NULL,
        [BasePeriod] NVARCHAR(512) NULL,
        [DueDate] DATETIME2(7) NULL,
        [ThirdPartyAgreementId] UNIQUEIDENTIFIER NULL,
        [ItemClass] VARCHAR(64) NOT NULL,
        [Currency] NVARCHAR(512) NOT NULL,
        [CalculationId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillableItems_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_BillableItems_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_BillableItems] PRIMARY KEY ([BillableItemId]),
        CONSTRAINT [FK_fac_BillableItems_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_BillableItems_Tenant] ON [fac].[BillableItems] ([TenantId]);
END;
GO
