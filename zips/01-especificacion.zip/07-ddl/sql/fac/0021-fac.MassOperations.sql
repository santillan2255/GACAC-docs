-- fac.MassOperations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.MassOperations', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[MassOperations] (
        [MassOperationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Type] NVARCHAR(512) NULL,
        [Recategorization, retroactive, invoiceModification, invoiceClassChange, block, unblock, creditByVouchers, installmentModification] NVARCHAR(512) NULL,
        [OwnerModule] NVARCHAR(512) NULL,
        [Params] NVARCHAR(512) NULL,
        [Filters] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Preview] NVARCHAR(512) NULL,
        [{ count, totals, generatedAt }] NVARCHAR(512) NULL,
        [Approvals] NVARCHAR(512) NULL,
        [Result] NVARCHAR(512) NULL,
        [{ applied, skipped, failed }] NVARCHAR(512) NULL,
        [JobId] NVARCHAR(512) NULL,
        [ClsRecategorizacion] NVARCHAR(512) NULL,
        [ClsRetroactivos] NVARCHAR(512) NULL,
        [ClsModificacionFacturas] NVARCHAR(512) NULL,
        [ClsModificacionCuotas] NVARCHAR(512) NULL,
        [ParamsJson] NVARCHAR(MAX) NULL,
        [ApprovalsJson] NVARCHAR(MAX) NULL,
        [Draft → previewed → pendingApproval → approved → applying → applied | partiallyApplied | failed] NVARCHAR(512) NULL,
        [Draft/previewed/pendingApproval → cancelled] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_MassOperations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_MassOperations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_MassOperations] PRIMARY KEY ([MassOperationId]),
        CONSTRAINT [FK_fac_MassOperations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_MassOperations_Tenant] ON [fac].[MassOperations] ([TenantId]);
END;
GO
