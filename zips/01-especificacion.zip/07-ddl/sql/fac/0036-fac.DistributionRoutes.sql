-- fac.DistributionRoutes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.DistributionRoutes', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[DistributionRoutes] (
        [DistributionRouteId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [CourierUserId] NVARCHAR(512) NULL,
        [PostalCarrierId] NVARCHAR(512) NULL,
        [Zones] NVARCHAR(512) NULL,
        [Stops { accountId, sequence }] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [SUMSOC] NVARCHAR(512) NULL,
        [ZonesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_DistributionRoutes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_DistributionRoutes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_DistributionRoutes] PRIMARY KEY ([DistributionRouteId]),
        CONSTRAINT [FK_fac_DistributionRoutes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_DistributionRoutes_Tenant] ON [fac].[DistributionRoutes] ([TenantId]);
END;
GO
