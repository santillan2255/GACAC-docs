-- fac.InvoiceRelations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'fac.InvoiceRelations', N'U') IS NULL
BEGIN
    CREATE TABLE [fac].[InvoiceRelations] (
        [InvoiceRelationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [OriginInvoiceId] NVARCHAR(512) NULL,
        [GeneratedInvoiceId] NVARCHAR(512) NULL,
        [RelationType] NVARCHAR(512) NULL,
        [Reversal, partialCredit, debitAdjustment, rebill, replica, manual, administrative, interestOn] DATETIME2(7) NULL,
        [AffectedServiceBlockIds] NVARCHAR(512) NULL,
        [Amount] NVARCHAR(512) NULL,
        [IsAnnulment] NVARCHAR(512) NULL,
        [ReportToTaxAuthority] NVARCHAR(512) NULL,
        [INFORMAR_CUIT] NVARCHAR(512) NULL,
        [Hidden] NVARCHAR(512) NULL,
        [NOMOSTRAR] NVARCHAR(512) NULL,
        [DiscountsInvoice] NVARCHAR(512) NULL,
        [BONIFICA_FACTURA] NVARCHAR(512) NULL,
        [Reason] NVARCHAR(512) NULL,
        [RequestId] NVARCHAR(512) NULL,
        [{tenantId, originInvoiceId}] NVARCHAR(512) NULL,
        [{tenantId, generatedInvoiceId}] NVARCHAR(512) NULL,
        [RELACION_COMP] NVARCHAR(512) NULL,
        [COMPROBANTES_ADM] NVARCHAR(512) NULL,
        [Administrative] NVARCHAR(512) NULL,
        [AffectedServiceBlockIdsId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceRelations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_fac_InvoiceRelations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_fac_InvoiceRelations] PRIMARY KEY ([InvoiceRelationId]),
        CONSTRAINT [FK_fac_InvoiceRelations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_fac_InvoiceRelations_Tenant] ON [fac].[InvoiceRelations] ([TenantId]);
END;
GO
