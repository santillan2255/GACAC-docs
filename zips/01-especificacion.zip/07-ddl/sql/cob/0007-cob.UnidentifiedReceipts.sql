-- cob.UnidentifiedReceipts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.UnidentifiedReceipts', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[UnidentifiedReceipts] (
        [UnidentifiedReceiptId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Channel] NVARCHAR(512) NULL,
        [Cash] NVARCHAR(512) NULL,
        [Agency] NVARCHAR(512) NULL,
        [Gateway] NVARCHAR(512) NULL,
        [Transfer] NVARCHAR(512) NULL,
        [DirectDebit] NVARCHAR(512) NULL,
        [Collector] NVARCHAR(512) NULL,
        [SourceRef] NVARCHAR(512) NULL,
        [Amount] NVARCHAR(512) NULL,
        [ReceivedAt] DATETIME2(7) NULL,
        [PayerData] NVARCHAR(512) NULL,
        [{ name, docType, docNumberMasked, cbuMasked, bankReference, freeText }] NVARCHAR(512) NULL,
        [CandidateObligationIds] NVARCHAR(512) NULL,
        [EvidenceStoredFileIds] NVARCHAR(512) NULL,
        [EvidenceFileIds] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Pending] NVARCHAR(512) NULL,
        [Identified] NVARCHAR(512) NULL,
        [Applied] NVARCHAR(512) NULL,
        [RefundRequested] NVARCHAR(512) NULL,
        [Refunded] NVARCHAR(512) NULL,
        [TransferredToCredit] NVARCHAR(512) NULL,
        [Voided] NVARCHAR(512) NULL,
        [AssignedTo] NVARCHAR(512) NULL,
        [EscalatedAt] DATETIME2(7) NULL,
        [Resolution] NVARCHAR(512) NULL,
        [{ holderId, currentAccountId, receiptId, creditBalanceId, approvedBy, at, verificationData }] NVARCHAR(512) NULL,
        [{tenantId, status, receivedAt}] NVARCHAR(512) NULL,
        [{tenantId, 'sourceRefId'}] NVARCHAR(512) NULL,
        [PayerDataJson] NVARCHAR(MAX) NULL,
        [CandidateObligationIdsId] UNIQUEIDENTIFIER NULL,
        [EvidenceStoredFileIdsId] UNIQUEIDENTIFIER NULL,
        [ResolutionJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_UnidentifiedReceipts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_UnidentifiedReceipts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_UnidentifiedReceipts] PRIMARY KEY ([UnidentifiedReceiptId]),
        CONSTRAINT [FK_cob_UnidentifiedReceipts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_UnidentifiedReceipts_Tenant] ON [cob].[UnidentifiedReceipts] ([TenantId]);
END;
GO
