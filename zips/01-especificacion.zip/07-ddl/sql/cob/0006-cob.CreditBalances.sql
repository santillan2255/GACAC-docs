-- cob.CreditBalances — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CreditBalances', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CreditBalances] (
        [CreditBalanceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CurrentAccountId] NVARCHAR(512) NULL,
        [HolderId] NVARCHAR(512) NULL,
        [ServiceId] NVARCHAR(512) NULL,
        [Origin] NVARCHAR(512) NULL,
        [Overpayment] NVARCHAR(512) NULL,
        [Advance] NVARCHAR(512) NULL,
        [OnAccount] NVARCHAR(512) NULL,
        [DuplicatePayment] NVARCHAR(512) NULL,
        [Rounding] NVARCHAR(512) NULL,
        [CreditNote] NVARCHAR(512) NULL,
        [AllocationReversal] NVARCHAR(512) NULL,
        [RetentionExcess] NVARCHAR(512) NULL,
        [CollectorExcess] NVARCHAR(512) NULL,
        [Migration] NVARCHAR(512) NULL,
        [GuaranteeRefund] NVARCHAR(512) NULL,
        [SourceRef] NVARCHAR(512) NULL,
        [Amount] NVARCHAR(512) NULL,
        [OpenAmount] NVARCHAR(512) NULL,
        [AutoApplicable] NVARCHAR(512) NULL,
        [ApplyOnNextInvoice] NVARCHAR(512) NULL,
        [PartialApplicationPct] NVARCHAR(512) NULL,
        [DueSchedule] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [ValidTo] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Open] NVARCHAR(512) NULL,
        [Consumed] NVARCHAR(512) NULL,
        [RefundRequested] NVARCHAR(512) NULL,
        [Refunded] NVARCHAR(512) NULL,
        [Voided] NVARCHAR(512) NULL,
        [Notes] NVARCHAR(512) NULL,
        [{tenantId, currentAccountId, status}] NVARCHAR(512) NULL,
        [{tenantId, 'sourceRefId'}] NVARCHAR(512) NULL,
        [ANTICIPOS] NVARCHAR(512) NULL,
        [IMP_ANT] NVARCHAR(512) NULL,
        [SDO_ANT] NVARCHAR(512) NULL,
        [ANTIFACTU] NVARCHAR(512) NULL,
        [CREDITOS_NOAUTOMATICOS] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CreditBalances_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CreditBalances_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CreditBalances] PRIMARY KEY ([CreditBalanceId]),
        CONSTRAINT [FK_cob_CreditBalances_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CreditBalances_Tenant] ON [cob].[CreditBalances] ([TenantId]);
END;
GO
