-- cob.PaymentTenders — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.PaymentTenders', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[PaymentTenders] (
        [PaymentTenderId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CashOperationId] UNIQUEIDENTIFIER NULL,
        [Method] VARCHAR(64) NULL,
        [Currency] NVARCHAR(MAX) NULL,
        [Amount] DECIMAL(18,4) NULL,
        [ExchangeRate] DECIMAL(18,4) NULL,
        [AmountInBase] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NULL,
        [HandoverId] UNIQUEIDENTIFIER NULL,
        [ThirdPartyCheckId] UNIQUEIDENTIFIER NULL,
        [SettlementId] UNIQUEIDENTIFIER NULL,
        [GatewayTransactionId] UNIQUEIDENTIFIER NULL,
        [DirectDebitBatchId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentTenders_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentTenders_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_PaymentTenders] PRIMARY KEY ([PaymentTenderId]),
        CONSTRAINT [FK_cob_PaymentTenders_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_PaymentTenders_Tenant] ON [cob].[PaymentTenders] ([TenantId]);
END;
GO
