-- cob.GatewayWebhookEvents — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.GatewayWebhookEvents', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[GatewayWebhookEvents] (
        [GatewayWebhookEventId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ConnectorId] UNIQUEIDENTIFIER NULL,
        [ReceivedAt] DATETIME2(7) NULL,
        [HeadersFiltered] NVARCHAR(MAX) NULL,
        [SignatureValid] NVARCHAR(MAX) NULL,
        [PayloadRef] NVARCHAR(512) NULL,
        [DedupeKey] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NULL,
        [Attempts] NVARCHAR(MAX) NULL,
        [LastError] NVARCHAR(MAX) NULL,
        [RelatedIntentId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_GatewayWebhookEvents_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_GatewayWebhookEvents_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_GatewayWebhookEvents] PRIMARY KEY ([GatewayWebhookEventId]),
        CONSTRAINT [FK_cob_GatewayWebhookEvents_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_GatewayWebhookEvents_Tenant] ON [cob].[GatewayWebhookEvents] ([TenantId]);
END;
GO
