-- cob.ExternalKeyAliases — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.ExternalKeyAliases', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[ExternalKeyAliases] (
        [ExternalKeyAliasId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Source] VARCHAR(64) NULL,
        [AgencyId] UNIQUEIDENTIFIER NULL,
        [ExternalKey] NVARCHAR(512) NULL,
        [CurrentAccountId] UNIQUEIDENTIFIER NULL,
        [AccountId] UNIQUEIDENTIFIER NULL,
        [ServiceId] UNIQUEIDENTIFIER NULL,
        [ValidFrom] DATETIME2(7) NULL,
        [ValidTo] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_ExternalKeyAliases_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_ExternalKeyAliases_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_ExternalKeyAliases] PRIMARY KEY ([ExternalKeyAliasId]),
        CONSTRAINT [FK_cob_ExternalKeyAliases_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_ExternalKeyAliases_Tenant] ON [cob].[ExternalKeyAliases] ([TenantId]);
END;
GO
