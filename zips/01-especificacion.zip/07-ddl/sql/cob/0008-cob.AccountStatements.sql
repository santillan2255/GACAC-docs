-- cob.AccountStatements — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.AccountStatements', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[AccountStatements] (
        [AccountStatementId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Number] NVARCHAR(512) NULL,
        [CurrentAccountId] NVARCHAR(512) NULL,
        [BillingGroupId] NVARCHAR(512) NULL,
        [CutoffDate] NVARCHAR(512) NULL,
        [PeriodFrom] NVARCHAR(512) NULL,
        [PeriodTo] NVARCHAR(512) NULL,
        [Lines] NVARCHAR(512) NULL,
        [{ obligationId, serviceId, document, dueDate, originalAmount, openAmount }] NVARCHAR(512) NULL,
        [TotalsByService] NVARCHAR(512) NULL,
        [{ serviceId, open }] NVARCHAR(512) NULL,
        [TotalOpen] NVARCHAR(512) NULL,
        [MinimumPayment] NVARCHAR(512) NULL,
        [CreditAvailable] NVARCHAR(512) NULL,
        [CouponId] NVARCHAR(512) NULL,
        [PaymentReferenceIds] NVARCHAR(512) NULL,
        [StoredFileId] NVARCHAR(512) NULL,
        [DeliveryChannels] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Issued] NVARCHAR(512) NULL,
        [Delivered] NVARCHAR(512) NULL,
        [Superseded] NVARCHAR(512) NULL,
        [{tenantId, currentAccountId, cutoffDate}] NVARCHAR(512) NULL,
        [LinesJson] NVARCHAR(MAX) NULL,
        [TotalsByServiceJson] NVARCHAR(MAX) NULL,
        [PaymentCouponId] UNIQUEIDENTIFIER NULL,
        [PaymentReferenceIdsId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AccountStatements_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AccountStatements_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_AccountStatements] PRIMARY KEY ([AccountStatementId]),
        CONSTRAINT [FK_cob_AccountStatements_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_AccountStatements_Tenant] ON [cob].[AccountStatements] ([TenantId]);
END;
GO
