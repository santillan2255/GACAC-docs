-- cob.CollectionExceptions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CollectionExceptions', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CollectionExceptions] (
        [CollectionExceptionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Type] VARCHAR(64) NULL,
        [SourceRef] NVARCHAR(512) NULL,
        [Severity] NVARCHAR(MAX) NULL,
        [AssignedTo] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Resolution] NVARCHAR(MAX) NULL,
        [DueAt] DATETIME2(7) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionExceptions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionExceptions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CollectionExceptions] PRIMARY KEY ([CollectionExceptionId]),
        CONSTRAINT [FK_cob_CollectionExceptions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CollectionExceptions_Tenant] ON [cob].[CollectionExceptions] ([TenantId]);
END;
GO
