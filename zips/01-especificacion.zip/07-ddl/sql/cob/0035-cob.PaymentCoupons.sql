-- cob.PaymentCoupons — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.PaymentCoupons', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[PaymentCoupons] (
        [PaymentCouponId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CouponNo] NVARCHAR(512) NULL,
        [LegalEntityId] NVARCHAR(512) NULL,
        [CurrentAccountId] NVARCHAR(512) NULL,
        [StatementId] NVARCHAR(512) NULL,
        [ObligationIds] NVARCHAR(512) NULL,
        [TotalsByDue] NVARCHAR(512) NULL,
        [{ seq, dueDate, amount }] NVARCHAR(512) NULL,
        [PaymentReferenceId] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [ValidUntil] NVARCHAR(512) NULL,
        [Legacy] NVARCHAR(512) NULL,
        [{ talonNumber, installment }] NVARCHAR(512) NULL,
        [TALONFAC] NVARCHAR(512) NULL,
        [TALONFAC_PAGO] NVARCHAR(512) NULL,
        [ObligationIdsId] UNIQUEIDENTIFIER NULL,
        [TotalsByDueJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [Number] NVARCHAR(512) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentCoupons_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentCoupons_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_PaymentCoupons] PRIMARY KEY ([PaymentCouponId]),
        CONSTRAINT [FK_cob_PaymentCoupons_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_PaymentCoupons_Tenant] ON [cob].[PaymentCoupons] ([TenantId]);
END;
GO
