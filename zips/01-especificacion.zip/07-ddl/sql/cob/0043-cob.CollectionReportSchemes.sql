-- cob.CollectionReportSchemes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CollectionReportSchemes', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CollectionReportSchemes] (
        [CollectionReportSchemeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Name] NVARCHAR(512) NULL,
        [ProductIdsId] UNIQUEIDENTIFIER NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NULL,
        [TaxIdsId] UNIQUEIDENTIFIER NULL,
        [ReportCode] NVARCHAR(512) NULL,
        [Code] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionReportSchemes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionReportSchemes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CollectionReportSchemes] PRIMARY KEY ([CollectionReportSchemeId]),
        CONSTRAINT [FK_cob_CollectionReportSchemes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CollectionReportSchemes_Tenant] ON [cob].[CollectionReportSchemes] ([TenantId]);
END;
GO
