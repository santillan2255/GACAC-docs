-- cob.DirectDebitBatches — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.DirectDebitBatches', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[DirectDebitBatches] (
        [DirectDebitBatcheId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AgencyId] UNIQUEIDENTIFIER NULL,
        [ExportId] UNIQUEIDENTIFIER NULL,
        [DebitDate] DATETIME2(7) NULL,
        [ItemsJson] NVARCHAR(MAX) NULL,
        [Totals] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [PresentationDate] DATETIME2(7) NULL,
        [Sequence] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_DirectDebitBatches_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_DirectDebitBatches_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_DirectDebitBatches] PRIMARY KEY ([DirectDebitBatcheId]),
        CONSTRAINT [FK_cob_DirectDebitBatches_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_DirectDebitBatches_Tenant] ON [cob].[DirectDebitBatches] ([TenantId]);
END;
GO
