-- cob.CollectionReconciliations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CollectionReconciliations', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CollectionReconciliations] (
        [CollectionReconciliationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Date] DATETIME2(7) NULL,
        [ScopeJson] NVARCHAR(MAX) NULL,
        [Gross] NVARCHAR(MAX) NULL,
        [Fees] NVARCHAR(MAX) NULL,
        [FeeVat] NVARCHAR(MAX) NULL,
        [Retentions] NVARCHAR(MAX) NULL,
        [ExpectedNet] NVARCHAR(MAX) NULL,
        [BankCredited] NVARCHAR(MAX) NULL,
        [Difference] NVARCHAR(MAX) NULL,
        [ItemsJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ClosedById] UNIQUEIDENTIFIER NULL,
        [MinutesStoredFileId] UNIQUEIDENTIFIER NULL,
        [AgencyId] UNIQUEIDENTIFIER NULL,
        [TreasuryMovementIdsId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionReconciliations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionReconciliations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CollectionReconciliations] PRIMARY KEY ([CollectionReconciliationId]),
        CONSTRAINT [FK_cob_CollectionReconciliations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CollectionReconciliations_Tenant] ON [cob].[CollectionReconciliations] ([TenantId]);
END;
GO
