-- cob.AgencyDebtExports — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.AgencyDebtExports', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[AgencyDebtExports] (
        [AgencyDebtExportId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AgencyId] UNIQUEIDENTIFIER NULL,
        [LayoutJson] NVARCHAR(MAX) NULL,
        [Operation] VARCHAR(64) NULL,
        [Filters] NVARCHAR(MAX) NULL,
        [Period] NVARCHAR(MAX) NULL,
        [StoredFileId] UNIQUEIDENTIFIER NULL,
        [ControlStoredFileId] UNIQUEIDENTIFIER NULL,
        [FileName] NVARCHAR(512) NULL,
        [RecordCount] INT NULL,
        [TotalsJson] NVARCHAR(MAX) NULL,
        [ApiJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [SentVia] NVARCHAR(MAX) NULL,
        [OperationId] UNIQUEIDENTIFIER NULL,
        [Sequence] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AgencyDebtExports_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AgencyDebtExports_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_AgencyDebtExports] PRIMARY KEY ([AgencyDebtExportId]),
        CONSTRAINT [FK_cob_AgencyDebtExports_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_AgencyDebtExports_Tenant] ON [cob].[AgencyDebtExports] ([TenantId]);
END;
GO
