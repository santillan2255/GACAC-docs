-- cob.LedgerEntries — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.LedgerEntries', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[LedgerEntries] (
        [LedgerEntryId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [EntryNo] NVARCHAR(MAX) NOT NULL,
        [Direction] VARCHAR(64) NOT NULL,
        [Kind] VARCHAR(64) NOT NULL,
        [Amount] NVARCHAR(MAX) NOT NULL,
        [SourceRefJson] NVARCHAR(MAX) NOT NULL,
        [EffectiveDate] DATETIME2(7) NOT NULL,
        [RecordedAt] DATETIME2(7) NOT NULL,
        [ReversalOfId] UNIQUEIDENTIFIER NULL,
        [AuthorizedById] UNIQUEIDENTIFIER NULL,
        [OperationId] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_LedgerEntries_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_LedgerEntries_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_LedgerEntries] PRIMARY KEY ([LedgerEntryId]),
        CONSTRAINT [FK_cob_LedgerEntries_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_LedgerEntries_Tenant] ON [cob].[LedgerEntries] ([TenantId]);
END;
GO
