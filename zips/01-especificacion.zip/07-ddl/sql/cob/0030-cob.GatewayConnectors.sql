-- cob.GatewayConnectors — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.GatewayConnectors', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[GatewayConnectors] (
        [GatewayConnectorId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Provider] VARCHAR(64) NULL,
        [Name] NVARCHAR(512) NULL,
        [Environment] VARCHAR(64) NULL,
        [BaseUrls] NVARCHAR(MAX) NULL,
        [CredentialRef] NVARCHAR(512) NOT NULL,
        [CapabilitiesJson] NVARCHAR(MAX) NULL,
        [ChannelsJson] NVARCHAR(MAX) NULL,
        [AllowedMethods] NVARCHAR(MAX) NULL,
        [ExcludedMethods] NVARCHAR(MAX) NULL,
        [CardDataMode] VARCHAR(64) NOT NULL,
        [ExcludedCardBrands] NVARCHAR(512) NULL,
        [ExcludedInstallments] NVARCHAR(MAX) NULL,
        [MinAmount] DECIMAL(18,4) NULL,
        [ReuseWindowMinutes] INT NULL,
        [ReconciliationWindowDays] INT NULL,
        [QrMerchantDataJson] NVARCHAR(MAX) NULL,
        [SettlementAgencyId] UNIQUEIDENTIFIER NULL,
        [FeeSchedule] NVARCHAR(MAX) NULL,
        [DirectDebitCutoffDay] NVARCHAR(MAX) NULL,
        [WebhookTokenRef] NVARCHAR(512) NOT NULL,
        [HealthJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ConnectionId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_GatewayConnectors_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_GatewayConnectors_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_GatewayConnectors] PRIMARY KEY ([GatewayConnectorId]),
        CONSTRAINT [FK_cob_GatewayConnectors_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_GatewayConnectors_Tenant] ON [cob].[GatewayConnectors] ([TenantId]);
END;
GO
