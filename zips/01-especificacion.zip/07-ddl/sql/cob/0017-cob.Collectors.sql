-- cob.Collectors — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.Collectors', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[Collectors] (
        [CollectorId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [PersonId] UNIQUEIDENTIFIER NULL,
        [CashRegisterId] UNIQUEIDENTIFIER NULL,
        [Zones] NVARCHAR(MAX) NULL,
        [LimitsJson] NVARCHAR(MAX) NULL,
        [AllowedMethods] NVARCHAR(MAX) NULL,
        [CommissionJson] NVARCHAR(MAX) NULL,
        [DeviceIdsId] UNIQUEIDENTIFIER NULL,
        [ReceiptSeries] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_Collectors_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_Collectors_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_Collectors] PRIMARY KEY ([CollectorId]),
        CONSTRAINT [FK_cob_Collectors_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_Collectors_Tenant] ON [cob].[Collectors] ([TenantId]);
END;
GO
