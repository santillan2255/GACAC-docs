-- cob.CurrentAccounts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CurrentAccounts', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CurrentAccounts] (
        [CurrentAccountId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [HolderId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [AccountIdsId] UNIQUEIDENTIFIER NOT NULL,
        [BillingGroupId] UNIQUEIDENTIFIER NULL,
        [Mode] VARCHAR(64) NOT NULL,
        [ServiceId] UNIQUEIDENTIFIER NULL,
        [ContractIdsId] UNIQUEIDENTIFIER NULL,
        [AllocationPolicyId] UNIQUEIDENTIFIER NULL,
        [MinimumPaymentPolicy] NVARCHAR(MAX) NULL,
        [ElectronicPaymentCode] NVARCHAR(512) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CurrentAccounts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CurrentAccounts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CurrentAccounts] PRIMARY KEY ([CurrentAccountId]),
        CONSTRAINT [FK_cob_CurrentAccounts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CurrentAccounts_Tenant] ON [cob].[CurrentAccounts] ([TenantId]);
END;
GO
