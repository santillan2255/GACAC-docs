-- cob.StaticQrCodes — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.StaticQrCodes', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[StaticQrCodes] (
        [StaticQrCodeId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CashRegisterId] NVARCHAR(512) NULL,
        [ConnectorId] NVARCHAR(512) NULL,
        [ExternalQrId] NVARCHAR(512) NULL,
        [PayloadRef] NVARCHAR(512) NULL,
        [ImageStoredFileId] NVARCHAR(512) NULL,
        [ImageFileId] NVARCHAR(512) NULL,
        [CurrentTransaction] NVARCHAR(512) NULL,
        [{ reference, amount, intentId, loadedAt }] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Inactive] NVARCHAR(512) NULL,
        [CAJAS_QR] NVARCHAR(512) NULL,
        [QR] NVARCHAR(512) NULL,
        [QR_ID] NVARCHAR(512) NULL,
        [GatewayConnectorId] UNIQUEIDENTIFIER NULL,
        [CurrentTransactionJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_StaticQrCodes_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_StaticQrCodes_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_StaticQrCodes] PRIMARY KEY ([StaticQrCodeId]),
        CONSTRAINT [FK_cob_StaticQrCodes_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_StaticQrCodes_Tenant] ON [cob].[StaticQrCodes] ([TenantId]);
END;
GO
