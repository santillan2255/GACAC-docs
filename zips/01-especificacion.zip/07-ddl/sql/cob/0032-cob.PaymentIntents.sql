-- cob.PaymentIntents — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.PaymentIntents', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[PaymentIntents] (
        [PaymentIntentId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [IntentNo] NVARCHAR(MAX) NOT NULL,
        [ConnectorId] UNIQUEIDENTIFIER NOT NULL,
        [Type] VARCHAR(64) NOT NULL,
        [OriginChannel] VARCHAR(64) NOT NULL,
        [PayerJson] NVARCHAR(MAX) NULL,
        [ItemsJson] NVARCHAR(MAX) NOT NULL,
        [AmountsJson] NVARCHAR(MAX) NOT NULL,
        [AllowedMethods] VARCHAR(64) NOT NULL,
        [Concept] NVARCHAR(512) NOT NULL,
        [ExpiresAt] DATETIME2(7) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ExternalId] NVARCHAR(512) NULL,
        [ExternalRefsJson] NVARCHAR(MAX) NULL,
        [Metadata] NVARCHAR(MAX) NULL,
        [MandateId] UNIQUEIDENTIFIER NULL,
        [SharesJson] NVARCHAR(MAX) NULL,
        [ReusedFromId] UNIQUEIDENTIFIER NULL,
        [TransactionIdsId] UNIQUEIDENTIFIER NULL,
        [ReceiptId] UNIQUEIDENTIFIER NULL,
        [StatusHistoryJson] NVARCHAR(MAX) NOT NULL,
        [UncertainSince] DATETIME2(7) NULL,
        [IdempotencyKey] NVARCHAR(512) NOT NULL,
        [GatewayConnectorId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentIntents_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentIntents_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_PaymentIntents] PRIMARY KEY ([PaymentIntentId]),
        CONSTRAINT [FK_cob_PaymentIntents_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_PaymentIntents_Tenant] ON [cob].[PaymentIntents] ([TenantId]);
END;
GO
