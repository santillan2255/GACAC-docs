-- cob.ThirdPartyBillers — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.ThirdPartyBillers', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[ThirdPartyBillers] (
        [ThirdPartyBillerId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [LinkedAccountId] UNIQUEIDENTIFIER NULL,
        [BarcodeType] NVARCHAR(MAX) NULL,
        [ThirdPartyNumber] INT NULL,
        [VoucherTypeId] UNIQUEIDENTIFIER NULL,
        [ProductId] UNIQUEIDENTIFIER NULL,
        [FeeJson] NVARCHAR(MAX) NULL,
        [BillingTypeId] UNIQUEIDENTIFIER NULL,
        [AllowsPartial] BIT NULL,
        [AllowsOverdue] BIT NULL,
        [AllowsMultiple] BIT NULL,
        [AllowsRefund] BIT NULL,
        [MinAmount] DECIMAL(18,4) NULL,
        [IsDonationEntity] BIT NULL,
        [SummaryServiceConnectorId] UNIQUEIDENTIFIER NULL,
        [Active] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_ThirdPartyBillers_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_ThirdPartyBillers_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_ThirdPartyBillers] PRIMARY KEY ([ThirdPartyBillerId]),
        CONSTRAINT [FK_cob_ThirdPartyBillers_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_ThirdPartyBillers_Tenant] ON [cob].[ThirdPartyBillers] ([TenantId]);
END;
GO
