-- cob.CashSessions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CashSessions', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CashSessions] (
        [CashSessionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CashRegisterId] NVARCHAR(512) NULL,
        [UserId] NVARCHAR(512) NULL,
        [BusinessDate] NVARCHAR(512) NULL,
        [OpenedAt] DATETIME2(7) NULL,
        [ClosedAt] DATETIME2(7) NULL,
        [OpeningFloat] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Expected] NVARCHAR(512) NULL,
        [{ method, currency, amount }] NVARCHAR(512) NULL,
        [Declared] NVARCHAR(512) NULL,
        [{ method, currency, amount, denominations? }] NVARCHAR(512) NULL,
        [Differences] NVARCHAR(512) NULL,
        [{ method, currency, amount, justification, approvedBy, adjustmentEntryId }] NVARCHAR(512) NULL,
        [IntegrityIssues] NVARCHAR(512) NULL,
        [CloseGroupId] NVARCHAR(512) NULL,
        [HandoverId] NVARCHAR(512) NULL,
        [Notes] NVARCHAR(512) NULL,
        [{tenantId, cashRegisterId, status}] NVARCHAR(512) NULL,
        [Open] NVARCHAR(512) NULL,
        [{tenantId, userId, businessDate}] NVARCHAR(512) NULL,
        [CAJAS] NVARCHAR(512) NULL,
        [APERTURA] NVARCHAR(512) NULL,
        [CIERRE] NVARCHAR(512) NULL,
        [TOT_EFE] NVARCHAR(512) NULL,
        [TOT_CHE] NVARCHAR(512) NULL,
        [TOT_RET] NVARCHAR(512) NULL,
        [TOT_TAR] NVARCHAR(512) NULL,
        [TOT_DIF] NVARCHAR(512) NULL,
        [TOTAL] NVARCHAR(512) NULL,
        [OBS_CAJ] NVARCHAR(512) NULL,
        [OpeningFloatJson] NVARCHAR(MAX) NULL,
        [ExpectedJson] NVARCHAR(MAX) NULL,
        [DeclaredJson] NVARCHAR(MAX) NULL,
        [DifferencesJson] NVARCHAR(MAX) NULL,
        [IntegrityIssuesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CashSessions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CashSessions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CashSessions] PRIMARY KEY ([CashSessionId]),
        CONSTRAINT [FK_cob_CashSessions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CashSessions_Tenant] ON [cob].[CashSessions] ([TenantId]);
END;
GO
