-- cob.CollectionAgencies — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CollectionAgencies', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CollectionAgencies] (
        [CollectionAgencyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Type] VARCHAR(64) NULL,
        [AgreementCode] NVARCHAR(512) NULL,
        [ConceptCode] NVARCHAR(512) NULL,
        [BarcodeJson] NVARCHAR(MAX) NULL,
        [CashRegisterId] UNIQUEIDENTIFIER NULL,
        [TreasuryAccountId] UNIQUEIDENTIFIER NULL,
        [ReferenceMode] VARCHAR(64) NULL,
        [MaxAcceptedDue] VARCHAR(64) NULL,
        [DueDateCapacity] INT NULL,
        [AllowsPartial] BIT NULL,
        [SurchargeDeferral] VARCHAR(64) NULL,
        [FeeJson] NVARCHAR(MAX) NULL,
        [BankPostingMode] VARCHAR(64) NULL,
        [AutoReconciled] BIT NULL,
        [AmountTolerance] DECIMAL(18,4) NULL,
        [TransportJson] NVARCHAR(MAX) NULL,
        [ExcludeDirectDebitAdhered] BIT NULL,
        [Status] VARCHAR(64) NULL,
        [ExportLayoutId] UNIQUEIDENTIFIER NULL,
        [ImportLayoutId] UNIQUEIDENTIFIER NULL,
        [ControlLayoutId] UNIQUEIDENTIFIER NULL,
        [FileLayoutIdsId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionAgencies_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionAgencies_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CollectionAgencies] PRIMARY KEY ([CollectionAgencyId]),
        CONSTRAINT [FK_cob_CollectionAgencies_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CollectionAgencies_Tenant] ON [cob].[CollectionAgencies] ([TenantId]);
END;
GO
