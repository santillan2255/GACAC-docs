-- cob.Chargebacks — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.Chargebacks', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[Chargebacks] (
        [ChargebackId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ConnectorId] UNIQUEIDENTIFIER NULL,
        [GatewayTransactionId] UNIQUEIDENTIFIER NULL,
        [IntentId] UNIQUEIDENTIFIER NULL,
        [ReceiptId] UNIQUEIDENTIFIER NULL,
        [Amount] DECIMAL(18,4) NULL,
        [Reason] NVARCHAR(512) NULL,
        [NotifiedAt] DATETIME2(7) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ReversalAllocationIdsId] UNIQUEIDENTIFIER NULL,
        [ChargeObligationIdsId] UNIQUEIDENTIFIER NULL,
        [BlockedAccountIdsId] UNIQUEIDENTIFIER NULL,
        [EvidenceStoredFileIdsId] UNIQUEIDENTIFIER NULL,
        [ExternalId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_Chargebacks_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_Chargebacks_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_Chargebacks] PRIMARY KEY ([ChargebackId]),
        CONSTRAINT [FK_cob_Chargebacks_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_Chargebacks_Tenant] ON [cob].[Chargebacks] ([TenantId]);
END;
GO
