-- cob.AgencyPublishedDebts — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.AgencyPublishedDebts', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[AgencyPublishedDebts] (
        [AgencyPublishedDebtId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AgencyId] UNIQUEIDENTIFIER NULL,
        [ExportId] UNIQUEIDENTIFIER NULL,
        [TargetRef] NVARCHAR(512) NULL,
        [Period] NVARCHAR(MAX) NULL,
        [Concept] NVARCHAR(MAX) NULL,
        [Identifier] NVARCHAR(MAX) NULL,
        [Index] NVARCHAR(MAX) NULL,
        [DueAmounts] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AgencyPublishedDebts_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AgencyPublishedDebts_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_AgencyPublishedDebts] PRIMARY KEY ([AgencyPublishedDebtId]),
        CONSTRAINT [FK_cob_AgencyPublishedDebts_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_AgencyPublishedDebts_Tenant] ON [cob].[AgencyPublishedDebts] ([TenantId]);
END;
GO
