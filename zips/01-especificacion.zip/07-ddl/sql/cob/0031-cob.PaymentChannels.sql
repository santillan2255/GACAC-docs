-- cob.PaymentChannels — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.PaymentChannels', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[PaymentChannels] (
        [PaymentChannelId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [NameKey] NVARCHAR(512) NULL,
        [IconStoredFileId] UNIQUEIDENTIFIER NULL,
        [GatewayConnectorId] UNIQUEIDENTIFIER NULL,
        [Methods] NVARCHAR(MAX) NULL,
        [VisibleInJson] NVARCHAR(MAX) NULL,
        [Order] INT NULL,
        [Active] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentChannels_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentChannels_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_PaymentChannels] PRIMARY KEY ([PaymentChannelId]),
        CONSTRAINT [FK_cob_PaymentChannels_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_PaymentChannels_Tenant] ON [cob].[PaymentChannels] ([TenantId]);
END;
GO
