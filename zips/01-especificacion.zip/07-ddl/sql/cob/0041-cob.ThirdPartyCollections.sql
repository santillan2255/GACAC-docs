-- cob.ThirdPartyCollections — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.ThirdPartyCollections', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[ThirdPartyCollections] (
        [ThirdPartyCollectionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ThirdPartyBillerId] UNIQUEIDENTIFIER NULL,
        [ObligationId] UNIQUEIDENTIFIER NULL,
        [Barcode] NVARCHAR(512) NULL,
        [DocumentRef] NVARCHAR(512) NULL,
        [DueDate] DATETIME2(7) NULL,
        [Amount] DECIMAL(18,4) NULL,
        [Fee] DECIMAL(18,4) NULL,
        [ReceiptId] UNIQUEIDENTIFIER NULL,
        [SummaryNumber] INT NULL,
        [RenderedToThirdPartyAt] DATETIME2(7) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [CashOperationId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_ThirdPartyCollections_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_ThirdPartyCollections_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_ThirdPartyCollections] PRIMARY KEY ([ThirdPartyCollectionId]),
        CONSTRAINT [FK_cob_ThirdPartyCollections_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_ThirdPartyCollections_Tenant] ON [cob].[ThirdPartyCollections] ([TenantId]);
END;
GO
