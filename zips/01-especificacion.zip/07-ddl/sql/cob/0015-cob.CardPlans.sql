-- cob.CardPlans — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CardPlans', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CardPlans] (
        [CardPlanId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Brand] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [Processor] NVARCHAR(512) NULL,
        [MerchantNumber] NVARCHAR(512) NULL,
        [CardType] NVARCHAR(512) NULL,
        [Debit] NVARCHAR(512) NULL,
        [Credit] NVARCHAR(512) NULL,
        [PresentationMode] NVARCHAR(512) NULL,
        [AutoOnClose] NVARCHAR(512) NULL,
        [Treasury] NVARCHAR(512) NULL,
        [UsableInCash] NVARCHAR(512) NULL,
        [CashSurcharge] NVARCHAR(512) NULL,
        [{ pct, amount }] NVARCHAR(512) NULL,
        [InstallmentPlans] NVARCHAR(512) NULL,
        [{ installments, surchargeType: pct|amount, value }] NVARCHAR(512) NULL,
        [SurchargeProductId] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [TARJETAS] NVARCHAR(512) NULL,
        [COD_TARJ] NVARCHAR(512) NULL,
        [NOM_TARJ] NVARCHAR(512) NULL,
        [COD_PROV] NVARCHAR(512) NULL,
        [COMERCIO] NVARCHAR(512) NULL,
        [PER_DEB] NVARCHAR(512) NULL,
        [PRESEN] NVARCHAR(512) NULL,
        [USO_CAJA] NVARCHAR(512) NULL,
        [POR_CAJA] NVARCHAR(512) NULL,
        [IMP_CAJA] NVARCHAR(512) NULL,
        [COD_PRO] NVARCHAR(512) NULL,
        [TARJETAS_RECARGO] NVARCHAR(512) NULL,
        [CUOTAS] NVARCHAR(512) NULL,
        [RECARGO_TIPO] NVARCHAR(512) NULL,
        [RECARGO_VALOR] NVARCHAR(512) NULL,
        [CashSurchargeJson] NVARCHAR(MAX) NULL,
        [InstallmentPlansJson] NVARCHAR(MAX) NULL,
        [SurchargeConceptId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CardPlans_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CardPlans_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CardPlans] PRIMARY KEY ([CardPlanId]),
        CONSTRAINT [FK_cob_CardPlans_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CardPlans_Tenant] ON [cob].[CardPlans] ([TenantId]);
END;
GO
