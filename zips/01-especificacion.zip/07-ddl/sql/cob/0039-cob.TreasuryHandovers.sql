-- cob.TreasuryHandovers — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.TreasuryHandovers', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[TreasuryHandovers] (
        [TreasuryHandoverId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SessionIdsId] UNIQUEIDENTIFIER NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NULL,
        [DeliveredById] UNIQUEIDENTIFIER NULL,
        [ReceivedById] UNIQUEIDENTIFIER NULL,
        [ContentsJson] NVARCHAR(MAX) NULL,
        [ReportStoredFileId] UNIQUEIDENTIFIER NULL,
        [Status] VARCHAR(64) NOT NULL,
        [DeliveredAt] DATETIME2(7) NULL,
        [ReceivedAt] DATETIME2(7) NULL,
        [Observations] NVARCHAR(512) NULL,
        [CashSessionIdsId] UNIQUEIDENTIFIER NULL,
        [Number] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_TreasuryHandovers_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_TreasuryHandovers_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_TreasuryHandovers] PRIMARY KEY ([TreasuryHandoverId]),
        CONSTRAINT [FK_cob_TreasuryHandovers_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_TreasuryHandovers_Tenant] ON [cob].[TreasuryHandovers] ([TenantId]);
END;
GO
