-- cob.GatewayTransactions — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.GatewayTransactions', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[GatewayTransactions] (
        [GatewayTransactionId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ConnectorId] UNIQUEIDENTIFIER NULL,
        [IntentId] UNIQUEIDENTIFIER NULL,
        [ExternalPaymentId] NVARCHAR(512) NULL,
        [Type] VARCHAR(64) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Channel] NVARCHAR(MAX) NULL,
        [GrossAmount] DECIMAL(18,4) NULL,
        [GrossFee] DECIMAL(18,4) NULL,
        [NetFee] DECIMAL(18,4) NULL,
        [FeeVat] NVARCHAR(MAX) NULL,
        [NetAmount] DECIMAL(18,4) NULL,
        [FeeEstimated] BIT NULL,
        [PaidAt] DATETIME2(7) NULL,
        [AvailableAt] DATETIME2(7) NULL,
        [PayerMaskedJson] NVARCHAR(MAX) NULL,
        [EvidenceStoredFileId] UNIQUEIDENTIFIER NULL,
        [ReceivedVia] VARCHAR(64) NULL,
        [CashOperationId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_GatewayTransactions_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_GatewayTransactions_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_GatewayTransactions] PRIMARY KEY ([GatewayTransactionId]),
        CONSTRAINT [FK_cob_GatewayTransactions_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_GatewayTransactions_Tenant] ON [cob].[GatewayTransactions] ([TenantId]);
END;
GO
