-- cob.CollectorSettlements — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CollectorSettlements', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CollectorSettlements] (
        [CollectorSettlementId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CollectorId] UNIQUEIDENTIFIER NULL,
        [RoundIdsId] UNIQUEIDENTIFIER NULL,
        [CollectedTotal] DECIMAL(18,4) NULL,
        [HandedOverTotal] DECIMAL(18,4) NULL,
        [Difference] NVARCHAR(MAX) NULL,
        [Justification] NVARCHAR(MAX) NULL,
        [CashSessionId] UNIQUEIDENTIFIER NULL,
        [CommissionBase] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectorSettlements_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectorSettlements_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CollectorSettlements] PRIMARY KEY ([CollectorSettlementId]),
        CONSTRAINT [FK_cob_CollectorSettlements_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CollectorSettlements_Tenant] ON [cob].[CollectorSettlements] ([TenantId]);
END;
GO
