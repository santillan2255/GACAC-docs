-- cob.AgencySettlements — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.AgencySettlements', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[AgencySettlements] (
        [AgencySettlementId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AgencyId] UNIQUEIDENTIFIER NULL,
        [Source] VARCHAR(64) NULL,
        [StoredFileId] UNIQUEIDENTIFIER NULL,
        [FileHash] NVARCHAR(MAX) NULL,
        [PresentationDate] DATETIME2(7) NULL,
        [HeaderJson] NVARCHAR(MAX) NULL,
        [FooterJson] NVARCHAR(MAX) NULL,
        [ReadJson] NVARCHAR(MAX) NULL,
        [Warnings] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ConfirmedById] UNIQUEIDENTIFIER NULL,
        [ConfirmedAt] DATETIME2(7) NULL,
        [CashOperationId] UNIQUEIDENTIFIER NULL,
        [FeeTotal] DECIMAL(18,4) NULL,
        [ExpectedCreditJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AgencySettlements_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AgencySettlements_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_AgencySettlements] PRIMARY KEY ([AgencySettlementId]),
        CONSTRAINT [FK_cob_AgencySettlements_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_AgencySettlements_Tenant] ON [cob].[AgencySettlements] ([TenantId]);
END;
GO
