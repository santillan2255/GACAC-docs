-- cob.CollectionRounds — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CollectionRounds', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CollectionRounds] (
        [CollectionRoundId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CollectorId] UNIQUEIDENTIFIER NULL,
        [PlannedDate] DATETIME2(7) NULL,
        [ItemsJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionRounds_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionRounds_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CollectionRounds] PRIMARY KEY ([CollectionRoundId]),
        CONSTRAINT [FK_cob_CollectionRounds_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CollectionRounds_Tenant] ON [cob].[CollectionRounds] ([TenantId]);
END;
GO
