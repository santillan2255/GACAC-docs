-- cob.DirectDebitMandates — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.DirectDebitMandates', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[DirectDebitMandates] (
        [DirectDebitMandateId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CurrentAccountId] UNIQUEIDENTIFIER NOT NULL,
        [AccountId] UNIQUEIDENTIFIER NOT NULL,
        [ServiceIdsId] UNIQUEIDENTIFIER NULL,
        [Channel] VARCHAR(64) NOT NULL,
        [AgencyId] UNIQUEIDENTIFIER NOT NULL,
        [GatewayConnectorId] UNIQUEIDENTIFIER NOT NULL,
        [MediumType] VARCHAR(64) NOT NULL,
        [CbuEncrypted] NVARCHAR(MAX) NOT NULL,
        [CbuMasked] NVARCHAR(512) NOT NULL,
        [CardToken] NVARCHAR(MAX) NOT NULL,
        [CardTokenType] VARCHAR(64) NOT NULL,
        [Brand] VARCHAR(64) NOT NULL,
        [Last4] NVARCHAR(512) NOT NULL,
        [HolderName] NVARCHAR(512) NOT NULL,
        [HolderCuit] NVARCHAR(512) NOT NULL,
        [PeriodFrom] NVARCHAR(MAX) NOT NULL,
        [SignedAt] DATETIME2(7) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ExternalId] NVARCHAR(512) NOT NULL,
        [ExclusionsJson] NVARCHAR(MAX) NULL,
        [ConsecutiveRejections] INT NOT NULL,
        [LastRejectCode] NVARCHAR(512) NULL,
        [CancelledAt] DATETIME2(7) NOT NULL,
        [Source] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_DirectDebitMandates_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_DirectDebitMandates_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_DirectDebitMandates] PRIMARY KEY ([DirectDebitMandateId]),
        CONSTRAINT [FK_cob_DirectDebitMandates_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_DirectDebitMandates_Tenant] ON [cob].[DirectDebitMandates] ([TenantId]);
END;
GO
