-- cob.Allocations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.Allocations', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[Allocations] (
        [AllocationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [ObligationId] UNIQUEIDENTIFIER NOT NULL,
        [CreditType] VARCHAR(64) NOT NULL,
        [CreditRefJson] NVARCHAR(MAX) NOT NULL,
        [Component] VARCHAR(64) NOT NULL,
        [Amount] DECIMAL(18,4) NOT NULL,
        [PrevOpenAmount] DECIMAL(18,4) NOT NULL,
        [PolicyJson] NVARCHAR(MAX) NOT NULL,
        [Sequence] INT NOT NULL,
        [EffectiveDate] DATETIME2(7) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [ReversedById] UNIQUEIDENTIFIER NULL,
        [ReversalReason] NVARCHAR(512) NULL,
        [AuthorizedById] UNIQUEIDENTIFIER NULL,
        [OperationId] NVARCHAR(512) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_Allocations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_Allocations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_Allocations] PRIMARY KEY ([AllocationId]),
        CONSTRAINT [FK_cob_Allocations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_Allocations_Tenant] ON [cob].[Allocations] ([TenantId]);
END;
GO
