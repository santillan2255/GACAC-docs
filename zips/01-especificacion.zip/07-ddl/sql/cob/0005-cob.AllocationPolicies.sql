-- cob.AllocationPolicies — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.AllocationPolicies', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[AllocationPolicies] (
        [AllocationPolicyId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [NameKey] NVARCHAR(512) NULL,
        [Scope] NVARCHAR(512) NULL,
        [{ serviceIds, channels: [cash, collector, agency, directDebit, gateway, coupon, internal] }] NVARCHAR(512) NULL,
        [Strategy] NVARCHAR(512) NULL,
        [Explicit] NVARCHAR(512) NULL,
        [OldestFirst] NVARCHAR(512) NULL,
        [ServicePriority] NVARCHAR(512) NULL,
        [PayerChoice] NVARCHAR(512) NULL,
        [AgeReference] NVARCHAR(512) NULL,
        [FirstDue] NVARCHAR(512) NULL,
        [LastDue] NVARCHAR(512) NULL,
        [ComponentOrder] NVARCHAR(512) NULL,
        [PartialAllowedByChannel] NVARCHAR(512) NULL,
        [MinimumCoverage] NVARCHAR(512) NULL,
        [Surcharges] NVARCHAR(512) NULL,
        [None] NVARCHAR(512) NULL,
        [RemainderTreatment] NVARCHAR(512) NULL,
        [CreditBalance] NVARCHAR(512) NULL,
        [PendingApplication] NVARCHAR(512) NULL,
        [CrossServiceAllowed] NVARCHAR(512) NULL,
        [Never] NVARCHAR(512) NULL,
        [Policy] NVARCHAR(512) NULL,
        [CashValidations] NVARCHAR(512) NULL,
        [{ fullNotifiedDebt, oldestFirst, oldestFirstByService, installmentsInOrder, fullCoupon, severity: error|warning }] NVARCHAR(512) NULL,
        [Version] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Draft] NVARCHAR(512) NULL,
        [Published] NVARCHAR(512) NULL,
        [Retired] NVARCHAR(512) NULL,
        [ValidFrom] NVARCHAR(512) NULL,
        [{tenantId, code, version}] NVARCHAR(512) NULL,
        [ScopeJson] NVARCHAR(MAX) NULL,
        [ServicePriorityJson] NVARCHAR(MAX) NULL,
        [ComponentOrderJson] NVARCHAR(MAX) NULL,
        [PartialAllowedByChannelJson] NVARCHAR(MAX) NULL,
        [CashValidationsJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AllocationPolicies_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AllocationPolicies_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_AllocationPolicies] PRIMARY KEY ([AllocationPolicyId]),
        CONSTRAINT [FK_cob_AllocationPolicies_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_AllocationPolicies_Tenant] ON [cob].[AllocationPolicies] ([TenantId]);
END;
GO
