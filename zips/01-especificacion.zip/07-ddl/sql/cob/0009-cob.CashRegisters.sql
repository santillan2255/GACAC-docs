-- cob.CashRegisters — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CashRegisters', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CashRegisters] (
        [CashRegisterId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [Name] NVARCHAR(512) NULL,
        [BranchId] NVARCHAR(512) NULL,
        [Type] NVARCHAR(512) NULL,
        [Counter] NVARCHAR(512) NULL,
        [AgencyVirtual] NVARCHAR(512) NULL,
        [Collector] NVARCHAR(512) NULL,
        [DigitalChannel] NVARCHAR(512) NULL,
        [Remote] NVARCHAR(512) NULL,
        [FixedUserId] NVARCHAR(512) NULL,
        [AgencyId] NVARCHAR(512) NULL,
        [CollectorId] NVARCHAR(512) NULL,
        [ConnectorId] NVARCHAR(512) NULL,
        [AllowedMethods] NVARCHAR(512) NULL,
        [Limits] NVARCHAR(512) NULL,
        [{ maxPerOperation, maxCashOnHand }] NVARCHAR(512) NULL,
        [StaticQrCodeId] NVARCHAR(512) NULL,
        [PrinterProfile] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [Inactive] NVARCHAR(512) NULL,
        [{tenantId, code}] NVARCHAR(512) NULL,
        [CAJASJP] NVARCHAR(512) NULL,
        [BANCOSCAJA] NVARCHAR(512) NULL,
        [USERSCOD_CAJ] NVARCHAR(512) NULL,
        [LimitsJson] NVARCHAR(MAX) NULL,
        [WorkstationId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CashRegisters_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CashRegisters_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CashRegisters] PRIMARY KEY ([CashRegisterId]),
        CONSTRAINT [FK_cob_CashRegisters_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CashRegisters_Tenant] ON [cob].[CashRegisters] ([TenantId]);
END;
GO
