-- cob.CollectionAccountingGroups — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.CollectionAccountingGroups', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[CollectionAccountingGroups] (
        [CollectionAccountingGroupId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NOT NULL,
        [Name] NVARCHAR(512) NOT NULL,
        [Status] VARCHAR(64) NOT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionAccountingGroups_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_CollectionAccountingGroups_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_CollectionAccountingGroups] PRIMARY KEY ([CollectionAccountingGroupId]),
        CONSTRAINT [FK_cob_CollectionAccountingGroups_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_CollectionAccountingGroups_Tenant] ON [cob].[CollectionAccountingGroups] ([TenantId]);
END;
GO
