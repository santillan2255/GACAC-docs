-- cob.AgencyNoveltyFiles — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.AgencyNoveltyFiles', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[AgencyNoveltyFiles] (
        [AgencyNoveltyFileId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [AgencyId] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [Novelty] NVARCHAR(512) NULL,
        [Delinquency] NVARCHAR(512) NULL,
        [StoredFileId] NVARCHAR(512) NULL,
        [FileHash] NVARCHAR(512) NULL,
        [Lines] NVARCHAR(512) NULL,
        [{ action: add|remove|update, accountKey, mediumMasked, period, amount, dueDate, presentationDate, result, message }] NVARCHAR(512) NULL,
        [Status] NVARCHAR(512) NULL,
        [Imported] NVARCHAR(512) NULL,
        [Applied] NVARCHAR(512) NULL,
        [Rejected] NVARCHAR(512) NULL,
        [LinesJson] NVARCHAR(MAX) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AgencyNoveltyFiles_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AgencyNoveltyFiles_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_AgencyNoveltyFiles] PRIMARY KEY ([AgencyNoveltyFileId]),
        CONSTRAINT [FK_cob_AgencyNoveltyFiles_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_AgencyNoveltyFiles_Tenant] ON [cob].[AgencyNoveltyFiles] ([TenantId]);
END;
GO
