-- cob.Obligations — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.Obligations', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[Obligations] (
        [ObligationId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [LegalEntityId] UNIQUEIDENTIFIER NOT NULL,
        [BillingGroupId] UNIQUEIDENTIFIER NULL,
        [SourceType] VARCHAR(64) NOT NULL,
        [SourceDocumentId] UNIQUEIDENTIFIER NOT NULL,
        [SourceDocumentJson] NVARCHAR(MAX) NOT NULL,
        [SourceLineKey] NVARCHAR(512) NOT NULL,
        [Period] NVARCHAR(512) NULL,
        [IssueDate] DATETIME2(7) NOT NULL,
        [DueScheduleJson] NVARCHAR(MAX) NOT NULL,
        [DueScheduleShiftJson] NVARCHAR(MAX) NULL,
        [FiscalGateJson] NVARCHAR(MAX) NULL,
        [Amount] NVARCHAR(MAX) NOT NULL,
        [ComponentsJson] NVARCHAR(MAX) NULL,
        [ItemClass] VARCHAR(64) NOT NULL,
        [OpenAmount] DECIMAL(18,4) NOT NULL,
        [OpenComponentsJson] NVARCHAR(MAX) NOT NULL,
        [BalanceStatus] VARCHAR(64) NOT NULL,
        [LifecycleJson] NVARCHAR(MAX) NULL,
        [CollectionBlockJson] NVARCHAR(MAX) NULL,
        [DirectDebitMandateId] UNIQUEIDENTIFIER NULL,
        [PaymentReferenceIdsId] UNIQUEIDENTIFIER NULL,
        [GeneratedInCash] BIT NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [RecordedAt] DATETIME2(7) NOT NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_Obligations_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_Obligations_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_Obligations] PRIMARY KEY ([ObligationId]),
        CONSTRAINT [FK_cob_Obligations_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_Obligations_Tenant] ON [cob].[Obligations] ([TenantId]);
END;
GO
