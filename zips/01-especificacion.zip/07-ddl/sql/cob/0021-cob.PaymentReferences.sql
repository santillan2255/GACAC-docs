-- cob.PaymentReferences — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.PaymentReferences', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[PaymentReferences] (
        [PaymentReferenceId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Kind] VARCHAR(64) NULL,
        [TargetId] UNIQUEIDENTIFIER NULL,
        [Code] NVARCHAR(512) NULL,
        [CheckDigit] NVARCHAR(MAX) NULL,
        [BarcodesJson] NVARCHAR(MAX) NULL,
        [ElectronicCode] NVARCHAR(512) NULL,
        [QrPayload] NVARCHAR(MAX) NULL,
        [ValidUntil] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentReferences_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentReferences_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_PaymentReferences] PRIMARY KEY ([PaymentReferenceId]),
        CONSTRAINT [FK_cob_PaymentReferences_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_PaymentReferences_Tenant] ON [cob].[PaymentReferences] ([TenantId]);
END;
GO
