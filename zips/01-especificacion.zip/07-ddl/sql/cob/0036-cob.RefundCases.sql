-- cob.RefundCases — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.RefundCases', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[RefundCases] (
        [RefundCasId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [CaseNo] INT NULL,
        [CurrentAccountId] UNIQUEIDENTIFIER NULL,
        [HolderId] UNIQUEIDENTIFIER NULL,
        [SourceRef] NVARCHAR(512) NULL,
        [Cause] NVARCHAR(MAX) NULL,
        [Amount] DECIMAL(18,4) NULL,
        [CorrectiveDocumentId] UNIQUEIDENTIFIER NULL,
        [DestinationJson] NVARCHAR(MAX) NULL,
        [RequestedById] UNIQUEIDENTIFIER NULL,
        [ApprovedById] UNIQUEIDENTIFIER NULL,
        [WorkflowInstanceId] UNIQUEIDENTIFIER NULL,
        [Status] NVARCHAR(MAX) NULL,
        [ExecutionJson] NVARCHAR(MAX) NULL,
        [ReconciliationId] UNIQUEIDENTIFIER NULL,
        [PaymentOrderId] UNIQUEIDENTIFIER NULL,
        [Number] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_RefundCases_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_RefundCases_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_RefundCases] PRIMARY KEY ([RefundCasId]),
        CONSTRAINT [FK_cob_RefundCases_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_RefundCases_Tenant] ON [cob].[RefundCases] ([TenantId]);
END;
GO
