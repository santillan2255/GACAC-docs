-- cob.PaymentMethods — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.PaymentMethods', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[PaymentMethods] (
        [PaymentMethodId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Code] NVARCHAR(512) NULL,
        [NameKey] NVARCHAR(512) NULL,
        [Kind] NVARCHAR(512) NULL,
        [PaymentTendersMethod] NVARCHAR(512) NULL,
        [LedgerAccountId] NVARCHAR(512) NULL,
        [RequiresManualData] NVARCHAR(512) NULL,
        [AllowsChange] NVARCHAR(512) NULL,
        [AllowedChannels] NVARCHAR(512) NULL,
        [Currency] NVARCHAR(512) NULL,
        [IsDefaultInCash] NVARCHAR(512) NULL,
        [Active] NVARCHAR(512) NULL,
        [TIP_VAL] NVARCHAR(512) NULL,
        [CTA_CONTA] NVARCHAR(512) NULL,
        [DATO_MANUAL] NVARCHAR(512) NULL,
        [VUELTO] NVARCHAR(512) NULL,
        [FORMAPA] NVARCHAR(512) NULL,
        [FPITEMS] NVARCHAR(512) NULL,
        [FPALIC_IVA] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentMethods_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_PaymentMethods_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_PaymentMethods] PRIMARY KEY ([PaymentMethodId]),
        CONSTRAINT [FK_cob_PaymentMethods_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_PaymentMethods_Tenant] ON [cob].[PaymentMethods] ([TenantId]);
END;
GO
