-- cob.AgencySettlementLines — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.AgencySettlementLines', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[AgencySettlementLines] (
        [AgencySettlementLineId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [SettlementId] UNIQUEIDENTIFIER NULL,
        [LineNo] INT NULL,
        [RawMasked] NVARCHAR(MAX) NULL,
        [ParsedJson] NVARCHAR(MAX) NULL,
        [ResolutionJson] NVARCHAR(MAX) NULL,
        [ExpectedAmount] DECIMAL(18,4) NULL,
        [Result] VARCHAR(64) NULL,
        [MessagesJson] NVARCHAR(MAX) NULL,
        [Selected] BIT NULL,
        [Action] VARCHAR(64) NULL,
        [ReceiptId] UNIQUEIDENTIFIER NULL,
        [UnidentifiedId] UNIQUEIDENTIFIER NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AgencySettlementLines_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_AgencySettlementLines_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_AgencySettlementLines] PRIMARY KEY ([AgencySettlementLineId]),
        CONSTRAINT [FK_cob_AgencySettlementLines_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_AgencySettlementLines_Tenant] ON [cob].[AgencySettlementLines] ([TenantId]);
END;
GO
