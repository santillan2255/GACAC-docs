-- cob.ExternalObligationImports — generado generate_exhaustive_ddl.py (2026-11-19)

IF OBJECT_ID(N'cob.ExternalObligationImports', N'U') IS NULL
BEGIN
    CREATE TABLE [cob].[ExternalObligationImports] (
        [ExternalObligationImportId] UNIQUEIDENTIFIER NOT NULL,
        [TenantId] UNIQUEIDENTIFIER NOT NULL,
        [Format] VARCHAR(64) NULL,
        [StoredFileId] UNIQUEIDENTIFIER NULL,
        [LinesJson] NVARCHAR(MAX) NULL,
        [Status] VARCHAR(64) NOT NULL,
        [Source] NVARCHAR(MAX) NULL,
        [FileHash] NVARCHAR(512) NULL,
        [LegacyJson] NVARCHAR(MAX) NULL,
        [CreatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_ExternalObligationImports_CreatedAt] DEFAULT (SYSUTCDATETIME()),
        [CreatedBy] UNIQUEIDENTIFIER NULL,
        [UpdatedAt] DATETIME2(7) NOT NULL
            CONSTRAINT [DF_cob_ExternalObligationImports_UpdatedAt] DEFAULT (SYSUTCDATETIME()),
        [UpdatedBy] UNIQUEIDENTIFIER NULL,
        [RowVersion] ROWVERSION NOT NULL,
        CONSTRAINT [PK_cob_ExternalObligationImports] PRIMARY KEY ([ExternalObligationImportId]),
        CONSTRAINT [FK_cob_ExternalObligationImports_Tenants] FOREIGN KEY ([TenantId]) REFERENCES [pla].[Tenants] ([TenantId])
    );
    CREATE INDEX [IX_cob_ExternalObligationImports_Tenant] ON [cob].[ExternalObligationImports] ([TenantId]);
END;
GO
